       01  GSC-CALC-PARMS.                                                      
      ******************************************************************        
      *    PARAMETERS FOR GSCFACT (SALE CREDIT FACTOR)                          
      ******************************************************************        
           05  GSC-FIND-FACTOR                PIC X.                            
           05  GSC-FIND.                                                        
               10  GSC-PREM-DUE-DATE.                                           
                   15  GSC-PREM-DUE-YYYY      PIC 9(4).                         
                   15  GSC-PREM-DUE-MM        PIC 9(2).                         
                   15  GSC-PREM-DUE-DD        PIC 9(2).                         
               10  GSC-PRODUCT-CODE           PIC X.                            
               10  GSC-FY-RN-TYPE             PIC XX.                           
                   88  GSC-FY                       VALUE 'FY'.                 
                   88  GSC-RN                       VALUE 'RN'.                 
                   88  GSC-FY-RN                    VALUE '**'.                 
               10  GSC-WHICH-FACTORS          PIC X.                            
                   88  GSC-CURR-OLD-FACTOR          VALUE 'B'.                  
      *                                                                         
           05  GSC-RETURN-AREA.                                                 
               10  GSC-RET-SCALE              PIC X(3).                         
               10  GSC-RET-FLAG               PIC X.                            
                   88  GSC-RET-CURR-FLAG          VALUE 'C'.                    
               10  GSC-RET-FY-CURR-FACTOR     PIC S9(3)V9(3).                   
               10  GSC-RET-FY-OLD-FACTOR      PIC S9(3)V9(3).                   
               10  GSC-RET-RN-CURR-FACTOR     PIC S9(3)V9(3).                   
               10  GSC-RET-RN-OLD-FACTOR      PIC S9(3)V9(3).                   
               10  GSC-CALC-RET-CODE          PIC X(1).                         
                   88  GSC-CALC-RET-SUCCESS         VALUE '0'.                  
