       03  (ID)-GCOMRLS2.                                                       
      *****************************************************************         
      *                                                               *         
      *       INTERMEDIATE GIPSY COMMISSION RELEASE RECORD            *         
      *                                                               *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *       CREATED BY MCGIMUR                                      *         
      *           THIS IS A CLONE OF THE GCOMRLSE WITHOUT THE KEY INFO*         
      *                                                               *         
      *************************************************************** *         
      * CHANGE HISTORY                                                *         
      * MMMYY  USERID     DETAILS                                     *         
      *************************************************************** *         
      *                                                               *         
      *****************************************************************         
           05  (ID)-GCRL-VLNO       VALUE +0 COMP-3   PIC S9(3).        00011000
           05  (ID)-GCRL-GROUP      VALUE +0 COMP-3   PIC S9(15).       00012000
           05  (ID)-GCRL-SUB-ACCOUNT VALUE SPACES     PIC X(4).         00012000
           05  (ID)-GCRL-FUND       VALUE +0 COMP-3   PIC S9(3).        00013000
           05  (ID)-GCRL-LBUS       VALUE +0          PIC S9(2).        00014000
           05  (ID)-GCRL-PLAN-TYPE  VALUE +0          PIC S9.           00015000
           05  (ID)-GCRL-POLSPEX    VALUE +0 COMP-3   PIC S9(9).        00016000
           05  (ID)-GCRL-BRANCH     VALUE +0 COMP-3   PIC S9(5).        00017000
           05  (ID)-GCRL-CURRENCY   VALUE +0 COMP-3   PIC S9(2).        00018000
           05  (ID)-GCRL-MODE       VALUE +0 COMP-3   PIC S9(2).        00019000
           05  (ID)-GCRL-BILCL      VALUE +0          PIC S9.           00020000
           05  (ID)-GCRL-ACCT-EFFECTIVE-DATE.                           00030000
               10  (ID)-GCRL-EFF-CC VALUE 0           PIC 99.           00040000
               10  (ID)-GCRL-EFF-YY VALUE 0           PIC 99.           00040000
               10  (ID)-GCRL-EFF-MM VALUE 0           PIC 99.           00040000
               10  (ID)-GCRL-EFF-DD VALUE 0           PIC 99.           00040000
           05  (ID)-GCRL-BILLING-NAME VALUE SPACES    PIC X(25).        00060000
           05  (ID)-GCRL-PREMNO     VALUE +0 COMP-3   PIC S9(3).        00070000
           05  (ID)-GCRL-PRORATEMO  VALUE +0 COMP-3   PIC S9(2).        00080000
           05  (ID)-GCRL-PREM-DUE-DATE.                                 00090000
               10  (ID)-GCRL-PREM-CC VALUE 0          PIC 99.           00040000
               10  (ID)-GCRL-PREM-YY VALUE 0          PIC 99.           00040000
               10  (ID)-GCRL-PREM-MM VALUE 0          PIC 99.           00040000
               10  (ID)-GCRL-PREM-DD VALUE 0          PIC 99.           00040000
           05  (ID)-GCRL-PMOD       VALUE +0 COMP-3   PIC S9.           00100000
           05  (ID)-GCRL-MAN        VALUE +0 COMP-3   PIC S9(5).        00110000
           05  (ID)-GCRL-SPCL       VALUE +0          PIC S9(2).        00120000
           05  (ID)-GCRL-UNDCL      VALUE +0          PIC S9(2).        00130000
           05  (ID)-GCRL-SEX        VALUE +0 COMP-3   PIC S9.           00140000
           05  (ID)-GCRL-CEDED      VALUE +0 COMP-3   PIC S9.           00150000
           05  (ID)-GCRL-SCALE      VALUE SPACES      PIC X(3).         00150000
           05  (ID)-GCRL-TRANSFER-CODE.                                 00160000
               10  (ID)-GCRL-TRAN-BALYR VALUE 0 COMP-3 PIC 9.           00170000
               10  (ID)-GCRL-TRAN-REASON VALUE 0 COMP-3 PIC 9(2).       00180000
           05  (ID)-GCRL-TRANSFER-DATE.                                 00190000
               10  (ID)-GCRL-TRAN-CC VALUE 0          PIC 99.           00040000
               10  (ID)-GCRL-TRAN-YY VALUE 0          PIC 99.           00040000
               10  (ID)-GCRL-TRAN-MM VALUE 0          PIC 99.           00040000
               10  (ID)-GCRL-TRAN-DD VALUE 0          PIC 99.           00040000
           05  (ID)-GCRL-FOGL-CODE  VALUE 0           PIC 9(10).        00200000
           05  FILLER               VALUE ZERO        PIC 9(16).        00201000
           05  FILLER               VALUE SPACES      PIC X(5).         00201000
           05  (ID)-GCRL-DIRCOMIND  VALUE 'G'         PIC X.            00220000
           05  (ID)-GCRL-AGENT-DATA COMP-3.                             00230000
               10  (ID)-GCRL-AGENT-CODE VALUE +0      PIC S9(6).        00240000
               10  (ID)-GCRL-CONTRACT-TYPE VALUE +0   PIC S9(3).        00241000
               10  (ID)-GCRL-CLASS      VALUE  0      PIC 9(3).         00241000
               10  (ID)-GCRL-MGR    VALUE +0          PIC S9(3).        00242000
               10  (ID)-GCRL-SHARE  VALUE +0          PIC S9(3)V99.     00243000
               10  (ID)-GCRL-ASSIGNEE VALUE +0        PIC S9(5).        00244000
               10  (ID)-GCRL-CAUSE  VALUE +0          PIC S9(3).        00245000
               10  (ID)-GCRL-PARTICULARS-CODE VALUE +0 PIC S9(5).       00245000
           05  (ID)-GCRL-UNIQUE-ID.                                     00250000
               10  (ID)-GCRL-SOURCE VALUE 0           PIC 99.           00250000
               10  (ID)-GCRL-RECEIVE-DATE.                              00030000
                   15  (ID)-GCRL-REC-CENTURY VALUE 0  PIC 99.           00040000
                   15  (ID)-GCRL-REC-YEAR VALUE 0     PIC 99.           00040000
                   15  (ID)-GCRL-REC-MONTH VALUE 0    PIC 99.           00040000
                   15  (ID)-GCRL-REC-DAY VALUE 0      PIC 99.           00040000
               10  (ID)-GCRL-AUDIT-NUMBER VALUE 0 COMP-3 PIC 9(5).      00250000
               10  (ID)-GCRL-AUDIT-TYPE VALUE 0        PIC 9.           00250000
           05  (ID)-GCRL-PROCESS-DETAILS.                               00250000
               10  (ID)-GCRL-STATUS     VALUE 0        PIC 99.          00250000
               10  (ID)-GCRL-ERROR-CODE VALUE 0 COMP-3 PIC 9(5).        00250000
               10  (ID)-GCRL-PROCESS-DATE.                              00030000
                   15  (ID)-GCRL-PROC-CC VALUE 0       PIC 99.          00040000
                   15  (ID)-GCRL-PROC-YY VALUE 0       PIC 99.          00040000
                   15  (ID)-GCRL-PROC-MM VALUE 0       PIC 99.          00040000
                   15  (ID)-GCRL-PROC-DD VALUE 0       PIC 99.          00040000
               10  (ID)-GCRL-END-DATE.                                  00030000
                   15  (ID)-GCRL-END-CC VALUE 0        PIC 99.          00040000
                   15  (ID)-GCRL-END-YY VALUE 0        PIC 99.          00040000
                   15  (ID)-GCRL-END-MM VALUE 0        PIC 99.          00040000
                   15  (ID)-GCRL-END-DD VALUE 0        PIC 99.          00040000
           05  (ID)-GCRL-CONVRSN-RATE COMP-3   PIC S9(4)V9(5).                  
           05  (ID)-GCRL-FORWRD-PRODCR COMP-3  PIC S9(7).                       
                                                                                
           05  RECOVERED-AREA.                                                  
            10  (ID)-GCRL-COMM-FORWARD-PRODUCER COMP-3 PIC S9(7).               
            10  (ID)-GCRL-OVRD-FORWARD-PRODUCER COMP-3 PIC S9(7).               
            10  (ID)-GCRL-GLS-LOB                    PIC 99.                    
            10  (ID)-GCRL-GLS-PRODUCT-CODE COMP-3    PIC S9(5).                 
            10  (ID)-GCRL-GLS-PARIND                 PIC 9.                     
                                                                                
           05  (ID)-GCRL-FORWARD-CREDIT-PRDCR COMP-3 PIC S9(7).                 
           05  (ID)-GCRL-MATCH-SEQUENCE-NO  COMP-3    PIC S9(07).               
           05  (ID)-GCRL-VARS.                                          00250000
             10  (ID)-GCRL-VARIABLE-DATA COMP-3 OCCURS 10 TIMES.        00260000
               15  (ID)-GCRL-CODE                  PIC S9(3).           00270000
               15  (ID)-GCRL-CRAMT                 PIC S9(11).          00280000
               15  GCRL-CCAMT REDEFINES (ID)-GCRL-CRAMT PIC S9(10)V9.   00280000
               15  GCRL-CMAMT REDEFINES (ID)-GCRL-CRAMT PIC S9(09)V99.  00280000
              15  GCRL-CPAMT REDEFINES (ID)-GCRL-CRAMT PIC S9(06)V9(5). 00280000
