      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE GFO-NUMBER OF GC-TGFO TO                                        
               GFO-NUMBER OF GWCORGFO                                           
           .                                                                    
