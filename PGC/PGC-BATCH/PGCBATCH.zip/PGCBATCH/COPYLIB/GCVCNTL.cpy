      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           IF LAST-GIPSY-DAILY-RUN-YEAR OF GWCORCNTL  NOT NUMERIC               
               MOVE ZEROS TO LAST-GIPSY-DAILY-RUN-YEAR OF GC-TCNTL              
           ELSE                                                                 
               MOVE LAST-GIPSY-DAILY-RUN-YEAR OF GWCORCNTL                      
               TO LAST-GIPSY-DAILY-RUN-YEAR OF GC-TCNTL                         
           END-IF.                                                              
                                                                                
           IF LAST-GIPSY-DAILY-RUN-DAY OF GWCORCNTL  NOT NUMERIC                
               MOVE ZEROS TO LAST-GIPSY-DAILY-RUN-DAY OF GC-TCNTL               
           ELSE                                                                 
               MOVE LAST-GIPSY-DAILY-RUN-DAY OF GWCORCNTL                       
               TO LAST-GIPSY-DAILY-RUN-DAY OF GC-TCNTL                          
           END-IF.                                                              
                                                                                
           IF LAST-RECON-RUN-YEAR OF GWCORCNTL  NOT NUMERIC                     
               MOVE ZEROS TO LAST-RECON-RUN-YEAR OF GC-TCNTL                    
           ELSE                                                                 
               MOVE LAST-RECON-RUN-YEAR OF GWCORCNTL                            
               TO LAST-RECON-RUN-YEAR OF GC-TCNTL                               
           END-IF.                                                              
                                                                                
           IF LAST-RECON-RUN-DAY OF GWCORCNTL  NOT NUMERIC                      
               MOVE ZEROS TO LAST-RECON-RUN-DAY OF GC-TCNTL                     
           ELSE                                                                 
               MOVE LAST-RECON-RUN-DAY OF GWCORCNTL                             
               TO LAST-RECON-RUN-DAY OF GC-TCNTL                                
           END-IF.                                                              
                                                                                
           IF LAST-REN-PREM-RUN-YEAR OF GWCORCNTL  NOT NUMERIC                  
               MOVE ZEROS TO LAST-REN-PREM-RUN-YEAR OF GC-TCNTL                 
           ELSE                                                                 
               MOVE LAST-REN-PREM-RUN-YEAR OF GWCORCNTL                         
               TO LAST-REN-PREM-RUN-YEAR OF GC-TCNTL                            
           END-IF.                                                              
                                                                                
           IF LAST-REN-PREM-RUN-DAY OF GWCORCNTL  NOT NUMERIC                   
               MOVE ZEROS TO LAST-REN-PREM-RUN-DAY OF GC-TCNTL                  
           ELSE                                                                 
               MOVE LAST-REN-PREM-RUN-DAY OF GWCORCNTL                          
               TO LAST-REN-PREM-RUN-DAY OF GC-TCNTL                             
           END-IF.                                                              
                                                                                
           IF LAST-REN-COMM-RUN-YEAR OF GWCORCNTL  NOT NUMERIC                  
               MOVE ZEROS TO LAST-REN-COMM-RUN-YEAR OF GC-TCNTL                 
           ELSE                                                                 
               MOVE LAST-REN-COMM-RUN-YEAR OF GWCORCNTL                         
               TO LAST-REN-COMM-RUN-YEAR OF GC-TCNTL                            
           END-IF.                                                              
                                                                                
           IF LAST-REN-COMM-RUN-DAY OF GWCORCNTL  NOT NUMERIC                   
               MOVE ZEROS TO LAST-REN-COMM-RUN-DAY OF GC-TCNTL                  
           ELSE                                                                 
               MOVE LAST-REN-COMM-RUN-DAY OF GWCORCNTL                          
               TO LAST-REN-COMM-RUN-DAY OF GC-TCNTL                             
           END-IF.                                                              
                                                                                
           MOVE COMM-SCR-RECON-IND OF GWCORCNTL                                 
               TO COMM-SCR-RECON-IND OF GC-TCNTL.                               
                                                                                
           MOVE NAP-RECON-IND OF GWCORCNTL                                      
               TO NAP-RECON-IND OF GC-TCNTL.                                    
                                                                                
           MOVE RECON-DATE-UPDATE-IND OF GWCORCNTL                              
               TO RECON-DATE-UPDATE-IND OF GC-TCNTL.                            
                                                                                
