       01  WNA-NAME-ADDRESS.                                            00001000
           05  WNATRIDENT                          PIC XXX.             00002000
           05  WNALENGTH                   COMP-3  PIC S9(5).           00003000
           05  WNAPOST-CODE                        PIC X(6).            00004000
           05  WNAIDENT                            PIC XX.              00005000
           05  WNAUNDEFINED                        PIC X(27).           00006000
           05  WNA-NAME-ADDRESS-AREA.                                   00007000
               10  WNA-NAME-ADDR   OCCURS 5 TIMES.                      00008000
                   15  WNA-LINE                        PIC X(30).       00009000
                   15  WNA-DELIM                       PIC X.           00010000
               10  WNA-LAST-ADDR-LINE.                                  00011000
                   15  WNA-LAST-LINE                   PIC X(21).       00012000
                   15  WNA-LAST-DELIM                  PIC X.           00013000
