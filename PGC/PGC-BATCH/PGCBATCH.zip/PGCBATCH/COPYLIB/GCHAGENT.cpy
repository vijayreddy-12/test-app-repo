      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE AGENT-NUMBER OF GC-TAGENT TO                                    
               AGENT-NUMBER OF GWCORAGENT                                       
           .                                                                    
