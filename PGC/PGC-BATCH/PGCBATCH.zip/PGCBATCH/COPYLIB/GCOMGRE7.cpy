       01  GCOMGRE7.                                                            
      *************************************************************             
      *                                                           *             
      *      COMMISSION HISTORY RENEWAL EXTRACT RECORD            *             
      *                                                           *             
      *************************************************************             
      * 06SEP90, IAN BUCKNELL, ADDED GFO AND BRANCH TO EXTRACT.   *             
      *************************************************************             
                                                                                
           05  GCEX-GFO                               PIC X(5).                 
           05  GCEX-GROUP-NUMBER                      PIC X(7).                 
           05  GCEX-GROUP-ACCOUNT                     PIC XXX.                  
           05  GCEX-BRANCH                            PIC X(5).                 
           05  GCEX-RENEW-EFF-DATE.                                             
               10  GCEX-REN-EFF-YEAR           COMP-3 PIC S999.                 
               10  GCEX-REN-EFF-DAY            COMP-3 PIC S999.                 
           05  GCEX-REN-LIFE-AMT               COMP-3 PIC S9(9)V99.             
           05  GCEX-REN-LTD-AMT                COMP-3 PIC S9(9)V99.             
           05  GCEX-REN-A-S-AMT                COMP-3 PIC S9(9)V99.             
           05  GCEX-NEXT-ANNIVERSARY.                                           
               10  GCEX-NEXT-ANNIV-YEAR        COMP-3 PIC S999.                 
               10  GCEX-NEXT-ANNIV-DAY         COMP-3 PIC S999.                 
           05  GCEX-ACCT-EFF-DATE.                                              
               10  GCEX-ACCT-EFF-YEAR          COMP-3 PIC S999.                 
               10  GCEX-ACCT-EFF-DAY           COMP-3 PIC S999.                 
           05  FILLER                                 PIC X(6).                 
