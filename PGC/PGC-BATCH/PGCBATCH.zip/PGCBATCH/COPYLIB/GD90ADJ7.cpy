        01  GFMEDD90-ADJUST-RECORD.                                             
      *****************************************************************         
      *     D90 ADJUSTMENT RECORD                                     *         
      *                                                               *         
      *****************************************************************         
      *          HISTORY....                                          *         
      *****************************************************************         
      *       CREATED BY GFMEDD90                                     *         
      *       USED    BY GPRBILLS                                     *         
      *                                                               *         
      *       REC TYPE     '2'                                        *         
      *       REC LENGTH   129                                        *         
      *                                                               *         
      *****************************************************************         
      * JUN/93 M. PRANGE                                              *         
      *      - REMOVED FIELD GD90AR-GRP-ORD-TAX-AMT                   *         
      *      - ADDED   FIELD GD90AR-TAX-CODE.                         *         
      *****************************************************************         
            05  GD90AR-RECORD-LENGTH         COMP SYNC PIC S9(4).       00002000
            05  FILLER                                 PIC XX.          00003000
            05  GD90AR-RECORD-TYPE                     PIC X.           00004000
            05  GD90AR-PRODUCT                         PIC X.           00004100
            05  GD90AR-GROUP-OFFICE                    PIC X(5).        00005000
GNE         05  GD90AR-GROUP-NUMBER          COMP-3    PIC S9(7).       00006000
            05  GD90AR-ACCOUNT                         PIC XXX.         00007000
            05  GD90AR-DIVISION              COMP-3    PIC S9(3).       00007100
            05  GD90AR-ORDER                           PIC X.           00008000
            05  GD90AR-CERT-NAME.                                       00009000
                10  GD90AR-CN-CERTIFICATE    COMP-3    PIC S9(9).       00010000
                10  GD90AR-CN-NAME                     PIC X(25).       00011001
            05  GD90AR-NAME-CERT REDEFINES GD90AR-CERT-NAME.            00012000
                10  GD90AR-NC-NAME                     PIC X(25).       00013001
                10  GD90AR-NC-CERTIFICATE    COMP-3    PIC S9(9).       00014000
            05  GD90AR-DETAIL-IDENT                    PIC X.           00015000
            05  GD90AR-EFFECTIVE-DATE        COMP-3.                    00016000
                10  GD90AR-EFFECTIVE-YEAR              PIC S9(3).       00017000
                10  GD90AR-EFFECTIVE-DAY               PIC S9(3).       00018000
            05  GD90AR-DETAIL-REMARKS                  PIC X(20).       00019000
            05  GD90AR-TOTAL-PREMIUM         COMP-3    PIC S9(7)V99.    00020000
            05  GD90AR-TAX-IND                         PIC X(1).        00021000
            05  GD90AR-TAX-CODE                        PIC X(2).        00021100
GNE         05  GD90AR-FILLER                          PIC X(22).       00021200
            05  GD90AR-NO-OF-CODES           COMP-3    PIC S9(3).       00022000
            05  GD90AR-COVERAGE-DATA OCCURS 3 TIMES.                    00023000
                10  GD90AR-COVERAGE-CODE     COMP-3    PIC S9(3).       00024000
                10  GD90AR-PREMIUM-ADJUST    COMP-3    PIC S9(7)V99.    00025000
