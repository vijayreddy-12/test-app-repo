      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORGRACCT                          10/26/10  17:05  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORGRACCT.                                                         
           05  GROUP-ACCOUNT.                                                   
               10  GROUP-NUMBER                         PIC X(7).               
               10  GR-ACCOUNT                           PIC X(3).               
           05  LAST-RECON-DATE.                                                 
               10  LAST-RECON-YEAR            COMP-3    PIC S9(3).              
               10  LAST-RECON-DAY             COMP-3    PIC S9(3).              
           05  NEXT-RECON-DATE.                                                 
               10  NEXT-RECON-YEAR            COMP-3    PIC S9(3).              
               10  NEXT-RECON-DAY             COMP-3    PIC S9(3).              
           05  RENEWAL-EFFECTIVE-DATE.                                          
               10  RENEWAL-EFFECTIVE-YEAR     COMP-3    PIC S9(3).              
               10  RENEWAL-EFFECTIVE-DAY      COMP-3    PIC S9(3).              
           05  RENEW-COMP-ADVANCED-IND                  PIC X.                  
           05  COMP-LIVES                               PIC 9(7).               
