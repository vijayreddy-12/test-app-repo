       01  WMAGTTR.                                                     00001000
                 05  W-GAGTRIDENT                PIC XXX.               00002000
                 05  W-GAGLENGTH       COMP-3    PIC S9(5).             00003000
                 05  W-GAGAGENT-CODE             PIC 9(6).              00004000
                 05  W-GAGACCOUNT                PIC X.                 00005000
                 05  W-GAGAGENT-BRANCH           PIC X(5).              00006000
                 05  W-GAGRENEW-COMM-PD   COMP-3   PIC S9(7)V99.        00006100
                 05  W-GAGRENEW-COMM-EARN COMP-3   PIC S9(7)V99.        00006200
                 05  W-GAGSALES-CRED-PD   COMP-3   PIC S9(7)V99.        00006300
                 05  W-GAGSALES-CRED-EARN COMP-3   PIC S9(7)V99.        00006400
                 05  W-GAGCASE-CNT-PD     COMP-3   PIC S9(7)V99.        00006500
                 05  W-GAGCASE-CNT-EARN   COMP-3   PIC S9(7)V99.        00006600
                 05  W-GAGNAP-PAID1       COMP-3   PIC S9(7)V99.        00006700
                 05  W-GAGNAP-EARNED1     COMP-3   PIC S9(7)V99.        00006800
                 05  W-GAGNAP-PAID2       COMP-3   PIC S9(7)V99.        00006900
                 05  W-GAGNAP-EARNED2     COMP-3   PIC S9(7)V99.        00007000
                 05  W-GAGPAYMENT-PLAN.                                 00007100
                     07  W-GAGPAYMENT-TYPE         PIC X.               00008000
                     07  W-GAGCANN-COUNTER         PIC X.               00009000
                     07  W-GAGPERCENT-DEFER        PIC S9(5)V99  COMP-3.00010000
                     07  W-GAGANNUALIZED-PAID      PIC S9(7)V99  COMP-3.00011000
                     07  W-GAGANNUALIZED-EARN      PIC S9(7)V99  COMP-3.00012000
                 05  W-GAGUNDEFINED1               PIC X(60).           00013000
                 05  W-GAGAGENTS-INF   OCCURS 5 TIMES.                  00014000
                     07  W-GAGCOMM-IND             PIC X.               00015000
                     07  W-GAGSTART-DATE COMP-3.                        00016000
                         09 W-GAGSTART-YEAR        PIC S9(3).           00017000
                         09 W-GAGSTART-DAY         PIC S9(3).           00018000
                     07  W-GAGSTOP-DATE  COMP-3.                        00019000
                         09 W-GAGSTOP-YEAR         PIC S9(3).           00020000
                         09 W-GAGSTOP-DAY          PIC S9(3).           00021000
                     07  W-GAGFIRST-YEAR COMP-3.                        00022000
                         09  W-GAGFRST-LIFE        PIC S9(3)V99.        00023000
                         09  W-GAGFRST-LTD         PIC S9(3)V99.        00024000
                         09  W-GAGFRST-A-S         PIC S9(3)V99.        00025000
                         09  W-GAGFRST-ADMIN-FEE   PIC S9(3)V99.        00026000
                     07  W-GAGUNDEFINED2           PIC X(12).           00027000
                     07  W-GAGRENEWAL    COMP-3.                        00028000
                         09  W-GAGREN-LIFE         PIC S9(3)V99.        00029000
                         09  W-GAGREN-LTD          PIC S9(3)V99.        00030000
                         09  W-GAGREN-A-S          PIC S9(3)V99.        00031000
                         09  W-GAGREN-ADMIN-FEE    PIC S9(3)V99.        00032000
                     07  W-GAGUNDEFINED3           PIC X(12).           00033000
                     07  W-GAGSCALE                PIC X(3).            00034000
                     07  W-GAGLTD-SCALE            PIC X(3).            00035000
                     07  W-GAGFLAT-RATE     COMP-3 PIC S999V99.         00036000
                     07  W-GAGLTD-FLAT-RATE COMP-3 PIC S999V99.         00037000
                     07  W-GAGPOINT                PIC X.               00038000
