      *================================================================*        
      *  CBCVDBSS - Post conversion subschema control work area        *        
      *================================================================*        
      *  This copybook has been cloned into a new version called                
      *  GGRCVDBS for use by certain GIPC programs. The GIPC version            
      *  treats both error-status values 4404 and 4405 as the same.             
      *  Without this change, many GIPC programs would either loop or           
      *  abend with a 4405 error when they should not have.                     
      *                                                                         
      *  !! Note - if you change GWFCVDBS, you should also                      
      *            change GGRCVDBS so that both copybooks                       
      *            remain in synch.                                             
      *================================================================*        
           20  DBLINK-SUBSCHEMA-CTRL.                                           
               25  FILLER                   PIC X(16)                           
                   VALUE 'START CBCVDBSS'.                                      
               25  PROGRAM-NAME             PIC X(8)       VALUE SPACE.         
               25  ERROR-STATUS             PIC X(4)       VALUE '1400'.        
                   88  SUGGESTED-INIT-VALUE   VALUE '1400'.                     
                   88  DB-STATUS-OK           VALUE '0000'.                     
                   88  ANY-STATUS             VALUE '0000' THRU '9999'.         
                   88  ANY-ERROR-STATUS       VALUE '0001' THRU '9999'.         
                   88  DB-ANY-ERROR           VALUE '0001' THRU '9999'.         
                   88  DB-REC-NOT-FOUND       VALUE '0326'.                     
                   88  DB-INDEX-NOT-FOUND     VALUE '1726'.                     
                   88  DB-END-OF-SET          VALUE '0307'.                     
                   88  DB-END-OF-AREA         VALUE '0307'.                     
                   88  DB-END-OF-INDEX        VALUE '0307'.                     
                   88  DB-NO-CURRENCY         VALUE '0306'.                     
                   88  DB-DUP-REC             VALUE '1205'.                     
                   88  DB-SET-NOT-EMPTY       VALUE '0230'.                     
                   88  DC-DEADLOCK                                              
                       VALUE '3101' '3201' '3401' '3901'.                       
                   88  DC-NO-STORAGE                                            
                       VALUE '3202' '3402'.                                     
                   88  DC-AREA-ID-UNK         VALUE '4303'.                     
                   88  DC-QUEUE-ID-UNK        VALUE '4404'.                     
                   88  DC-REC-NOT-FOUND                                         
                       VALUE '4305' '4405'.                                     
                   88  DC-RESOURCE-NOT-AVAIL  VALUE '3908'.                     
                   88  DC-RESOURCE-AVAIL      VALUE '3909'.                     
                   88  DC-NEW-STORAGE         VALUE '3210'.                     
                   88  DC-MAX-TASKS           VALUE '3711'.                     
                   88  DC-REC-REPLACED        VALUE '4317'.                     
                   88  DC-TRUNCATED-DATA                                        
                       VALUE '4319' '4419' '4519' '4719'.                       
                   88  DC-ATTN-INT                                              
                       VALUE '4525' '4625'.                                     
                   88  DC-SECOND-STARTPAGE    VALUE '4604'.                     
                   88  DC-DETAIL-NOT-FOUND    VALUE '4664'.                     
                   88  DC-NO-MORE-UPD-DETAILS VALUE '4668'.                     
                   88  DC-MAX-SPACE-REACHED   VALUE '4668'.                     
                   88  DC-NO-DETAILS          VALUE '4672'.                     
                   88  DC-FIRST-PAGE-SENT     VALUE '4676'.                     
                   88  DC-OPER-CANCEL         VALUE '4743'.                     
                   88  QUEUE-ID-NOT-FOUND     VALUE '4404'.                     
                   88  QUEUE-REC-NOT-FOUND    VALUE '4405'.                     
                   88  SCRATCH-AREA-NOT-FOUND VALUE '4303'.                     
                   88  SCRATCH-REC-NOT-FOUND  VALUE '4305'.                     
                   88  SCRATCH-REC-REPLACED   VALUE '4317'.                     
                   88  BATCH-ACCEPTABLE-ERROR-STATUS                            
                                              VALUE '0000'.                     
                   88  ADSO-ACCEPTABLE-ERROR-STATUS                             
                                              VALUE '0000' '0307'               
                                                    '0326' '1601'               
                                                    '1707' '1726'               
                                                    '2001'                      
                                                    '4303' '4305'               
                                                    '4317' '4404'               
                                                    '4405' '5149'.              
               25  FILLER  REDEFINES ERROR-STATUS.                              
                   30  MAJ-CODE             PIC X(2).                           
                   30  MIN-CODE             PIC X(2).                           
                       88  DB-END             VALUE '07'.                       
                       88  DBKEY-DEADLOCK     VALUE '29'.                       
FCBC           25  ML-SQLCODE-DISP  REDEFINES ERROR-STATUS                      
                                            PIC -999.                           
FCBC           25  ML-VSAM-STATUS   REDEFINES ERROR-STATUS                      
                                            PIC 9999.                           
FCBC           25  ML-CICS-STATUS   REDEFINES ERROR-STATUS                      
                                            PIC X(4).                           
                                                                                
               25  DBKEY                    PIC S9(8)                           
                           VALUE +0.                                            
               25  FILLER REDEFINES DBKEY.                                      
                   30  DBKEY-1-4            PIC 9(4).                           
                   30  DBKEY-5-8            PIC 9(4).                           
               25  RECORD-NAME              PIC X(16)       VALUE SPACE.        
               25  AREA-NAME                PIC X(16)       VALUE SPACE.        
               25  ERROR-SET                PIC X(16)       VALUE SPACE.        
               25  ERROR-RECORD             PIC X(16)       VALUE SPACE.        
               25  ERROR-AREA               PIC X(16)       VALUE SPACE.        
               25  DIRECT-DBKEY             PIC S9(8)                           
                           VALUE +0.                                            
               25  DIRECT-DBK REDEFINES DIRECT-DBKEY PIC S9(8).                 
               25  DATABASE-STATUS.                                             
                   30  DBSTATMENT-CODE      PIC X(2)        VALUE SPACE.        
                   30  DBSTATUS-CODE        PIC X(5)        VALUE SPACE.        
               25  DML-SEQUENCE             PIC 9(8)        VALUE ZERO.         
               25  DB-NAME                  PIC X(8)        VALUE SPACE.        
               25  COMMIT-COUNTER-SS        PIC S9(8)  COMP VALUE +0.           
               25  DBLINK-PROGRAM-NAME      PIC X(8)        VALUE SPACE.        
               25  DBLINK-INIT-HV-FLAG      PIC X           VALUE 'Y'.          
               25  DBLINK-LOOP-FLAG         PIC X           VALUE 'Y'.          
      * TOTAL LENGTH 512                                                        
               25  FILLER                   PIC X(351)      VALUE SPACE.        
      *===================== END CBCVDBSS COPY ========================*        
                                                                                
