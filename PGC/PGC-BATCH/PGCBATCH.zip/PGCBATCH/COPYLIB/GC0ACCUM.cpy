      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORACCUM' TO DBLINK-CURR-PARAGRAPH.                 
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORACCUM' TO RECORD-NAME.                                    
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORACCUM TO DBLINK-RECORD-MADE-CURRENT.                
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORACCUM-EXIT                                   
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE GROUP-NUMBER OF GC-TACCUM TO DBLINK-GWCORACCUM-01           
               MOVE GR-ACCOUNT OF GC-TACCUM TO DBLINK-GWCORACCUM-02             
               MOVE PREM-DUE-YEAR OF GC-TACCUM TO DBLINK-GWCORACCUM-03          
               MOVE PREM-DUE-DAY OF GC-TACCUM TO DBLINK-GWCORACCUM-04           
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORACCUM TO DBLINK-VIEW-NAME-CURRENT.                  
           MOVE DBLINK-GWCORACCUM-KEY TO DBLINK-VIEW-200-CURRENT.               
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-ACCUM  M/A                                                   
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-GRACCT-ACCUM-F                          
           MOVE GROUP-NUMBER OF GC-TACCUM TO DBLINK-GRACCT-ACCUM-01.            
           MOVE GR-ACCOUNT OF GC-TACCUM TO DBLINK-GRACCT-ACCUM-02.              
           MOVE PREM-DUE-YEAR OF GC-TACCUM TO DBLINK-GRACCT-ACCUM-03.           
           MOVE PREM-DUE-DAY OF GC-TACCUM TO DBLINK-GRACCT-ACCUM-04.            
