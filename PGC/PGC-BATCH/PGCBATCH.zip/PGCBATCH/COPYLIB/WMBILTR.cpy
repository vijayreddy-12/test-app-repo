       01  WMBILTR.                                                     00001000
               05  W-GBITRIDENT                    PIC XXX.             00002000
               05  W-GBILENGTH           COMP-3    PIC S9(5).           00003000
               05  W-GBIMOST-OUTSTANDING COMP-3.                        00004000
                   07  W-GBIDUE-DATE.                                   00005000
                       09  W-GBIDUE-YEAR           PIC S9(3).           00006000
                       09  W-GBIDUE-DAY            PIC S9(3).           00007000
                   07  W-GBIBILL.                                       00008000
                       09  W-GBILIFE               PIC S9(7)V99.        00009000
                       09  W-GBILTD                PIC S9(7)V99.        00010000
                       09  W-GBIA-S                PIC S9(7)V99.        00011000
                       09  W-GBIADMIN-FEE          PIC S9(7)V99.        00012000
                   07  W-GBIPOSITION               PIC S9(3).           00013000
               05  W-GBINO-HIST-SEG        COMP-3  PIC S9(3).           00014000
               05  W-GBIUNDEFINED1                 PIC X(23).           00015000
               05  W-GBIHISTORY-INFO OCCURS 25 TIMES.                   00016000
                   07  W-GBIHIST-DUE-DATE COMP-3.                       00017000
                       09  W-GBIHIST-DUE-YEAR      PIC S9(3).           00018000
                       09  W-GBIHIST-DUE-DAY       PIC S9(3).           00019000
                   07  W-GBIHIST-PREPARED-DATE COMP-3.                  00020000
                       09  W-GBIHIST-PREPARED-YEAR PIC S9(3).           00021000
                       09  W-GBIHIST-PREPARED-DAY  PIC S9(3).           00022000
                   07  W-GBI-PREM-DUE      COMP-3  PIC S9(7)V99.        00023000
                   07  W-GBICERT-HOLDERS   COMP-3  PIC S9(7).           00024000
                   07  W-GBIHIST-ADMIN-FEE COMP-3  PIC S9(7)V99.        00025000
                   07  W-GBINO-COV-LINES   COMP-3  PIC S9(3).           00026000
                   07  W-GBIUNDEFINED2             PIC X.               00027000
                   07  W-GBISTATS-BY-COVERAGE OCCURS 10 TIMES COMP-3.   00028000
                       09  W-GBICOV-CODE           PIC S9(3).           00029000
                       09  W-GBIAMT-BILLED         PIC S9(7)V99.        00030000
                       09  W-GBINO-LIVES           PIC S9(5).           00031000
                       09  W-GBIVOL                PIC S9(9).           00032000
