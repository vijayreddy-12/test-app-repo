       01  FCCSPLNM-I-O-MODULE-NAMES.                                           
           05  FCCSPLNM-TABLE-DATA.                                             
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORACCUM'.                                          
               10  FCCSPLIO-GWCORACCUM             PIC X(8)                     
                   VALUE 'GC3ACCUM'.                                            
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORADVPSM'.                                         
               10  FCCSPLIO-GWCORADVPSM             PIC X(8)                    
                   VALUE 'GC3ADVPS'.                                            
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORAGENT'.                                          
               10  FCCSPLIO-GWCORAGENT             PIC X(8)                     
                   VALUE 'GC3AGENT'.                                            
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORCASECNT'.                                        
               10  FCCSPLIO-GWCORCASECNT             PIC X(8)                   
                   VALUE 'GC3CASEC'.                                            
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORCNTL'.                                           
               10  FCCSPLIO-GWCORCNTL             PIC X(8)                      
                   VALUE 'GC3CNTL'.                                             
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORCOMP'.                                           
               10  FCCSPLIO-GWCORCOMP             PIC X(8)                      
                   VALUE 'GC3COMP'.                                             
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORGFO'.                                            
               10  FCCSPLIO-GWCORGFO              PIC X(8)                      
                   VALUE 'GC3GFO'.                                              
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORGRACCT'.                                         
               10  FCCSPLIO-GWCORGRACCT             PIC X(8)                    
                   VALUE 'GC3GRACT'.                                            
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORGROUP'.                                          
               10  FCCSPLIO-GWCORGROUP             PIC X(8)                     
                   VALUE 'GC3GROUP'.                                            
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORPAYBASIS'.                                       
               10  FCCSPLIO-GWCORPAYBASIS             PIC X(8)                  
                   VALUE 'GC3PAYB'.                                             
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORRENEWAL'.                                        
               10  FCCSPLIO-GWCORRENEWAL             PIC X(8)                   
                   VALUE 'GC3RNEWL'.                                            
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
               10  FILLER                         PIC X(16)                     
                   VALUE 'GWCORTRANS'.                                          
               10  FCCSPLIO-GWCORTRANS             PIC X(8)                     
                   VALUE 'GC3TRAN'.                                             
               10  FILLER                         PIC S9(9)                     
                   VALUE +0  COMP.                                              
           05  FCCSPLNM-TABLE-DATA-REDEF    REDEFINES                           
                                            FCCSPLNM-TABLE-DATA.                
               10  FCCSPLNM-TABLE-ENTRY     OCCURS 12 TIMES                     
                                            ASCENDING KEY                       
                                            FCCSPLNM-RECORD-NAME                
                                            INDEXED BY FCCSPLNM-INDEX.          
                   15  FCCSPLNM-RECORD-NAME       PIC X(16).                    
                   15  FCCSPLNM-I-O-MODULE-NAME                                 
                                                  PIC X(8).                     
                   15  FCCSPLNM-RECORD-ADDR       PIC S9(9) COMP.               
