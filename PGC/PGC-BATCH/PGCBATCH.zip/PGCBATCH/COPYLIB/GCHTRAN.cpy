      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE TRANS-TYPE OF GC-TTRAN TO                                       
               TRANS-TYPE OF GWCORTRANS                                         
           MOVE TRANS-DETAILS-TEXT OF GC-TTRAN TO                               
               TRANS-DETAILS OF GWCORTRANS                                      
           .                                                                    
