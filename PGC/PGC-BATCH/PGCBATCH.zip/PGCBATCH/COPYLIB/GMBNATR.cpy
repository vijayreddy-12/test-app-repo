       01  GMBNATR.                                                             
      ******************************************************************        
      *    FEB/91 PRANGE        - ADDED GBN-NAAD-PROC-DATE                      
      ******************************************************************        
           05  GBNTRIDENT                      PIC XXX.                         
           05  GBNLENGTH           COMP-3      PIC S9(5).                       
           05  GBNPOST-CODE                    PIC X(6).                        
           05  GBN-NAAD-PROC-DATE.                                              
               10  GBN-NAAD-PROC-YEAR          PIC S9(3)    COMP-3.             
               10  GBN-NAAD-PROC-DAY           PIC S9(3)    COMP-3.             
           05  GBNUNDEFINED                    PIC X(25).                       
           05  GBNBILL-NAME-ADDR               PIC X(177).                      
