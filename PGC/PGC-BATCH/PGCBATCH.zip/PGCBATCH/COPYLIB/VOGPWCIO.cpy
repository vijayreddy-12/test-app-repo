      *================================================================         
      *    COPYBOOK: VOGPWCIO                                                   
      *    PROTOCOL FOR VO/GIPSY WRAPER (VOGPWRAP) READ REQUESTS                
      *----------------------------------------------------------------         
      *    APR/05 F. DAZA - CREATED                                             
      *----------------------------------------------------------------         
           05  VOGPWRAP-INPUT.                                                  
               10  VGWI-SOURCE-SYSTEM         PIC X(01).                        
                   88  VGWI-VALID-SOURCE      VALUE 'V', 'G', ' '.              
                   88  VGWI-SOURCE-GIPSY      VALUE 'G'.                        
                   88  VGWI-SOURCE-VO         VALUE 'V'.                        
                   88  VGWI-SOURCE-UNKNOWN    VALUE ' '.                        
               10  VGWI-REQUEST               PIC X(16).                        
                   88  VGWI-OPEN-FILES        VALUE 'OPEN FILES    '.           
                   88  VGWI-READ-KEYED        VALUE 'READ KEYED    '.           
                   88  VGWI-READ-NEXT-WG      VALUE 'READ NEXT W/G '.           
                   88  VGWI-READ-NEXT         VALUE 'READ NEXT     '.           
                   88  VGWI-END-READ-NEXT     VALUE 'END READ NEXT '.           
                   88  VGWI-CLOSE-FILES       VALUE 'CLOSE FILES   '.           
               10  VGWI-COVERAGE-TYPE         PIC X(03).                        
                   88  VGWI-COV-COVDB         VALUE 'COV'.                      
                   88  VGWI-COV-NONCOV        VALUE 'NCV'.                      
                   88  VGWI-COV-ANY           VALUE '   '.                      
               10  VGWI-GROUP                 PIC 9(07).                        
               10  VGWI-ACCOUNT               PIC X(05).                        
               10  VGWI-LR-NAME               PIC X(16).                        
                   88  VGWI-LR-GIPSY-EXP      VALUE 'GIPSY EXPANDED'.           
                   88  VGWI-LR-VO-RAW         VALUE 'VO RAW DATA   '.           
                   88  VGWI-LR-DEFAULT        VALUE 'DEFAULT       '.           
           05  VOGPWRAP-OUTPUT.                                                 
               10  VGWO-RET-CODE              PIC X(02).                        
                   88  VGWO-RET-OK            VALUE '00'.                       
                   88  VGWO-RET-WARNING       VALUE '01' THRU '09'.             
                   88  VGWO-RET-ERROR         VALUE '10' THRU '89'.             
                   88  VGWO-RET-SEVERE-ERROR  VALUE '90' THRU '99'.             
               10  VGWO-RET-MESSAGE           PIC X(80).                        
               10  VGWO-GROUP                 PIC 9(07).                        
               10  VGWO-ACCOUNT               PIC X(05).                        
               10  VGWO-SOURCE-SYSTEM         PIC X(01).                        
                   88  VGWO-SOURCE-GIPSY      VALUE 'G'.                        
                   88  VGWO-SOURCE-VO         VALUE 'V'.                        
               10  VGWO-COVERAGE-TYPE         PIC X(03).                        
                   88  VGWO-COV-COVDB         VALUE 'COV'.                      
                   88  VGWO-COV-NONCOV        VALUE 'NCV'.                      
