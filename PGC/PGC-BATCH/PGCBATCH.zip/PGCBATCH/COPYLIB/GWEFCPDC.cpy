                                                                                
       997-CALL-DATE-ROUTINE.                                                   
           CALL GC2DATE USING GAC-DATE-PARMS.                                   
       997-EXIT.   EXIT.                                                        
                                                                                
       998-GET-DATE-TIME.                                                       
           CALL GC2DATE USING GAC-DATE-PARMS.                                   
                                                                                
           ACCEPT  WS-SYSTEM-TIME FROM TIME.                                    
       998-EXIT.   EXIT.                                                        
                                                                                
       999-CALL-GWEFCBNK.                                                       
           CALL GWEFCBNK USING IOM-REQUEST-PARMS.                               
       999-EXIT.   EXIT.                                                        
