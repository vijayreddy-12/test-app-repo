      ******************************************************************        
      *    THIS COPYBOOK IS USED IN THE GROUP TABLES UTILITY.                   
      *    KEEP MAX LENGTH = 15000 WHICH IS THE MAX FOR THE FILE BUT            
      *    NOT THIS PARTICULAR RECORD TYPE.                                     
      *    THE LOCATION OF THE "KEY" AND "AUDIT" DATA AREAS IS STANDARD         
      *    FOR ALL RECORDS IN THE FILE.                                         
      *                                                                         
      *    SALE CREDIT RATE RECORDS. KEY NAME = 'SCRATES '.                     
      *    NOTE: EFF DATE IS COMPLEMENTED FROM 9999/12/31. RECORDS              
      *          ARE THEN STORED IN DESCENDING ORDER BY EFF YEAR.               
      *          E.G. JAN 1/90 = 1990/01/01 IS STORED AS 8009/11/30.            
      *    MAX SIZE FOR SALES CREDIT FACTOR RECORD IS:                          
      *        KEY (25) + AUDIT (25) + FIXED (100) + VAR (99*9) = 891           
      ******************************************************************        
           05  GTABSC-REC-DATA.                                                 
               10  GTABSC-KEY.                                                  
                   15  GTABSC-NAME               PIC X(8).                      
                       88  GTABSC-NAME-88              VALUE 'SCRATES '.        
                   15  GTABSC-EFF-DATE.                                         
                       20  GTABSC-EFF-YEAR       PIC 9(4).                      
                       20  GTABSC-EFF-MONTH      PIC 9(2).                      
                       20  GTABSC-EFF-DAY        PIC 9(2).                      
                   15  FILLER                    PIC X(9).                      
               10  GTABSC-AUDIT-DATA.                                           
                   15  GTABSC-DATE-STAMP.                                       
                       20  GTABSC-DATE-STAMP-Y PIC 9(4).                        
                       20  GTABSC-DATE-STAMP-M PIC 9(2).                        
                       20  GTABSC-DATE-STAMP-D PIC 9(2).                        
                   15  GTABSC-TIME-STAMP.                                       
                       20  GTABSC-TIME-STAMP-H PIC 9(2).                        
                       20  GTABSC-TIME-STAMP-M PIC 9(2).                        
                       20  GTABSC-TIME-STAMP-S PIC 9(2).                        
                   15  GTABSC-USERID             PIC X(8).                      
                   15  FILLER                    PIC X(3).                      
               10  GTABSC-TABLE-DATA.                                           
                   15  GTABSC-COMMISSION-SCALE   PIC X(3).                      
                   15  GTABSC-TABLE-SIZE         PIC 9(2).                      
                   15  GTABSC-COMMENTS           PIC X(95).                     
                   15  GTABSC-INFORMATION OCCURS 99 TIMES.                      
                       20  GTABSC-FY-RN          PIC X(2).                      
                       20  GTABSC-PRODUCT-CODE   PIC X(1).                      
                       20  GTABSC-FACTOR         PIC 9(3)V9(3).                 
               10 FILLER                         PIC X(13860).                  
