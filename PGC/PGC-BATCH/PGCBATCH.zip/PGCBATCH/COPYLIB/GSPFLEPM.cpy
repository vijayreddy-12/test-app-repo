                                                                                
      *  FILE PARAMETERS FOR GSPLIRT - NOTE THAT SYS018 IS OBSOLETE             
                                                                                
       01  TAPE-PARAMETERS.                                             00061000
           03  TAPE-SYS011     PIC X(6)            VALUE 'SYS071'.      00061100
           03  TAPE-SYS012     PIC X(6)            VALUE 'SYS072'.      00062000
           03  TAPE-SYS013     PIC X(6)            VALUE 'SYS073'.      00062100
           03  TAPE-SYS014     PIC X(6)            VALUE 'SYS074'.      00062200
           03  TAPE-SYS015     PIC X(6)            VALUE 'SYS075'.      00062300
           03  TAPE-SYS016     PIC X(6)            VALUE 'SYS076'.      00063000
           03  TAPE-SYS017     PIC X(6)            VALUE 'SYS077'.      00064000
           03  TAPE-SYS018     PIC X(6)            VALUE 'SYS018'.      00065000
           03  TAPE-SYS019     PIC X(6)            VALUE 'SYS079'.      00065000
           03  TAPE-SYS020     PIC X(6)            VALUE 'SYS070'.      00065000
                                                                        00066000
           03  TAPE-RETURN     PIC S9      COMP-3  VALUE +0.            00067000
                                                                        00066000
           03  TAPE-RSIZ11     PIC 9(5)            VALUE 19056.         00068390
           03  TAPE-RSIZ12     PIC 9(5)            VALUE 19056.         00068680
           03  TAPE-RSIZ13     PIC 9(5)            VALUE 19056.         00068970
           03  TAPE-RSIZ14     PIC 9(5)            VALUE 19056.         00069260
           03  TAPE-RSIZ15     PIC 9(5)            VALUE 19056.         00069550
           03  TAPE-RSIZ16     PIC 9(5)            VALUE 01000.         00070000
           03  TAPE-RSIZ17     PIC 9(5)            VALUE 07289.         00071000
           03  TAPE-RSIZ18     PIC 9(5)            VALUE 00080.         00072000
           03  TAPE-RSIZ19     PIC 9(5)            VALUE 00116.         00072000
           03  TAPE-RSIZ20     PIC 9(5)            VALUE 00304.         00072000
                                                                        00066000
           03  TAPE-BSIZ11     PIC 9(5)            VALUE 19060.         00073390
           03  TAPE-BSIZ12     PIC 9(5)            VALUE 19060.         00073680
           03  TAPE-BSIZ13     PIC 9(5)            VALUE 19060.         00073970
           03  TAPE-BSIZ14     PIC 9(5)            VALUE 19060.         00074260
           03  TAPE-BSIZ15     PIC 9(5)            VALUE 19060.         00074550
           03  TAPE-BSIZ16     PIC 9(5)            VALUE 01004.         00075000
           03  TAPE-BSIZ17     PIC 9(5)            VALUE 07293.         00076000
           03  TAPE-BSIZ18     PIC 9(5)            VALUE 00800.         00077000
           03  TAPE-BSIZ19     PIC 9(5)            VALUE 01164.         00077000
           03  TAPE-BSIZ20     PIC 9(5)            VALUE 23412.         00077000
                                                                        00066000
           03  TAPE-FRMT11     PIC XX              VALUE 'VB'.          00078100
           03  TAPE-FRMT12     PIC XX              VALUE 'VB'.          00079000
           03  TAPE-FRMT13     PIC XX              VALUE 'VB'.          00079100
           03  TAPE-FRMT14     PIC XX              VALUE 'VB'.          00079200
           03  TAPE-FRMT15     PIC XX              VALUE 'VB'.          00079300
           03  TAPE-FRMT16     PIC XX              VALUE 'VB'.          00080000
           03  TAPE-FRMT17     PIC XX              VALUE 'VB'.          00081000
           03  TAPE-FRMT18     PIC XX              VALUE 'FB'.          00082000
           03  TAPE-FRMT19     PIC XX              VALUE 'VB'.          00082000
           03  TAPE-FRMT20     PIC XX              VALUE 'VB'.          00082000
                                                                        00066000
           03  TAPE-CNTR11     PIC S9(7)   COMP-3  VALUE +0.            00084000
           03  TAPE-CNTR12     PIC S9(7)   COMP-3  VALUE +0.            00084100
           03  TAPE-CNTR13     PIC S9(7)   COMP-3  VALUE +0.            00084200
           03  TAPE-CNTR14     PIC S9(7)   COMP-3  VALUE +0.            00084300
           03  TAPE-CNTR15     PIC S9(7)   COMP-3  VALUE +0.            00084400
           03  TAPE-CNTR16     PIC S9(7)   COMP-3  VALUE +0.            00085000
           03  TAPE-CNTR17     PIC S9(7)   COMP-3  VALUE +0.            00086000
           03  TAPE-CNTR18     PIC S9(7)   COMP-3  VALUE +0.            00087000
           03  TAPE-CNTR19     PIC S9(7)   COMP-3  VALUE +0.            00087000
           03  TAPE-CNTR20     PIC S9(7)   COMP-3  VALUE +0.            00087000
