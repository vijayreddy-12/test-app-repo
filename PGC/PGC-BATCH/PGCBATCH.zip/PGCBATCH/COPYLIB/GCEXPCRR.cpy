      *  01  CCOMTRANS-REC. SAG10C24                                            
      *                                                                         
           03  CCOMMRELEASE-REC.                                                
            04  CR-STANDRD.                                                     
               05  CRVLNO                COMP-3    PIC S999.                    
               05  CRPOLNO               COMP-3    PIC S9(15).                  
               05  CRSUB-ACCOUNT                   PIC X(4).                    
               05  CRFUND                COMP-3    PIC S999.                    
               05  CRLBUS                          PIC S99.                     
               05  CRPLNTYPE                       PIC S9.                      
                                                                                
               05  CRPOLSPEX             COMP-3    PIC S9(9).                   
               05  CRGRPSPEX REDEFINES CRPOLSPEX.                               
                   07 CRGRPTYPE          DISPLAY   PIC 99.                      
                   07 CRGRPIND           DISPLAY   PIC X.                       
                   07 CRGRPFILL          DISPLAY   PIC XX.                      
                                                                                
               05  CRAGCY                COMP-3    PIC S9(5).                   
               05  CRCURR                COMP-3    PIC S99.                     
               05  CRMODE                COMP-3    PIC S99.                     
               05  CRBILCL                         PIC S9.                      
               05 CRPYDATE                         PIC 9(8).                    
               05 FILLER REDEFINES CRPYDATE.                                    
                   07  CRPCC                       PIC 99.                      
                   07  CRPYY                       PIC 99.                      
                   07  CRPMM                       PIC 99.                      
                   07  CRPDD                       PIC 99.                      
               05  CRSURNAME                       PIC X(25).                   
               05  CRPREMNO              COMP-3    PIC S999.                    
               05  CRPRORATEMO           COMP-3    PIC S99.                     
               05  CRRPT-DUEDATE                   PIC 9(8).                    
               05 FILLER REDEFINES CRRPT-DUEDATE.                               
                   07  CRRPTCC                     PIC 99.                      
                   07  CRRPTYY                     PIC 99.                      
                   07  CRRPTMM                     PIC 99.                      
                   07  CRRPTDD                     PIC 99.                      
               05  CRPMOD                COMP-3    PIC S9.                      
               05  CRMAN                 COMP-3    PIC S9(5).                   
               05  CRSPCL                          PIC S99.                     
               05  CRUNDCL                         PIC S99.                     
               05  FILLER REDEFINES CRUNDCL.                                    
                 07  CRUNDCL1                      PIC S9.                      
                 07  CRUNDCL2                      PIC 9.                       
               05  CRSEX                 COMP-3    PIC S9.                      
               05  CRCEDED               COMP-3    PIC S9.                      
               05  CRSCALE                         PIC XXX.                     
                                                                                
               05  CRTRANSFER-CODE.                                             
                   07  CRTRANSFER-BALYR  COMP-3    PIC 9.                       
                   07  CRTRANSFER-REASON COMP-3    PIC 99.                      
               05  CRTRANSFER-DATE                 PIC 9(8).                    
               05  FILLER REDEFINES  CRTRANSFER-DATE.                           
                   07  CRTRANSCC                   PIC 99.                      
                   07  CRTRANSYY                   PIC 99.                      
                   07  CRTRANSMM                   PIC 99.                      
                   07  CRTRANSDD                   PIC 99.                      
                                                                                
               05  CRPRODUCT-CODE                  PIC 9(10).                   
               05  CRPRODUCT-CODEX REDEFINES CRPRODUCT-CODE  PIC X(10).         
               05  CRPROD REDEFINES CRPRODUCT-CODE.                             
                   07  FILLER                      PIC 9(4).                    
                   07  CRPC510                     PIC 9(6).                    
               05  FILLER REDEFINES CRPRODUCT-CODE.                             
                   07  CRPC14.                                                  
                     09  CRPC12                    PIC 99.                      
                     09  CRPC34                    PIC 99.                      
                   07  CRPC56                      PIC 99.                      
                   07  CRPC710.                                                 
                     09  CRPC7                     PIC 9.                       
                     09  CRPC8                     PIC 9.                       
                     09  CRPC910                   PIC 99.                      
               05  CRCOMPANY             COMP-3    PIC 999.                     
               05  CRPAYROLLCTR                    PIC 9(6).                    
               05  CRCREDRL-DATE                   PIC 9(8).                    
               05  FILLER REDEFINES CRCREDRL-DATE.                              
                   07  CRCRD-CENT                  PIC 99.                      
                   07  CRCRD-YEAR                  PIC 99.                      
                   07  CRCRD-MONTH                 PIC 99.                      
                   07  CRCRD-DAY                   PIC 99.                      
               05  CRBLSUB                         PIC XXX.                     
               05  CRORPHAN                        PIC X.                       
               05  CRRESTRICT-FLAG                 PIC X.                       
               05  CRDIRCOMIND                     PIC X.                       
                                                                                
               05  AGENT-DATA            COMP-3.                                
                   07  CRAGTCODE                   PIC S9(6).                   
                   07  CRCONTRACTTYPE              PIC S9(3).                   
                   07  CRAGTTYPE REDEFINES CRCONTRACTTYPE PIC S99.              
                   07  CRCONTRACT-CLASS            PIC 9(3).                    
      *  ANNUALIZATION                                                          
                   07  CRMGR                       PIC S999.                    
                   07  CRSHARE                     PIC S9(3)V99.                
                   07  CRSHARE-REDEF REDEFINES CRSHARE                          
                                                   PIC S9(5).                   
                   07  CRASSIGNEE                  PIC S9(5).                   
                   07  CRCAUSE                     PIC S999.                    
                   07  CRPARTICULARS-CODE          PIC S9(5).                   
                                                                                
               05  UNIQUE-ID.                                                   
                  07 CRSOURCE                      PIC 99.                      
                  07 CRRECEIVE-DATE.                                            
                     09  CRRECEIVECC               PIC 99.                      
                     09  CRRECEIVEYY               PIC 99.                      
                     09  CRRECEIVEMM               PIC 99.                      
                     09  CRRECEIVEDD               PIC 99.                      
                  07 CRAUDIT-NUMBER      COMP-3    PIC 9(5).                    
                  07 CRAUDIT-TYPE                  PIC 9.                       
                                                                                
               05  PROCESS-DETAILS.                                             
                  07  CRSTATUS                     PIC 99.                      
                  07  CRERROR-CODE       COMP-3    PIC 9(5).                    
                  07  CRPROCESS-DATE.                                           
                      09  CRPROCESSCC              PIC 99.                      
                      09  CRPROCESSYY              PIC 99.                      
                      09  CRPROCESSMM              PIC 99.                      
                      09  CRPROCESSDD              PIC 99.                      
                  07  CRPEND-DATE.                                              
                      09  CRPENDCC                 PIC 99.                      
                      09  CRPENDYY                 PIC 99.                      
                      09  CRPENDMM                 PIC 99.                      
                      09  CRPENDDD                 PIC 99.                      
                                                                                
               05  CRCONVERSION-RATE     COMP-3    PIC S9(4)V9(5).              
               05  CRFORWARD-PRODUCER    COMP-3    PIC S9(7).                   
                                                                                
               05  RECOVERED-AREA                  PIC X(14).                   
               05  FILLER REDEFINES RECOVERED-AREA.                             
                10  CRPAYCOMM-FORWARD-PRODUCER COMP-3    PIC S9(7).             
                10  CRPAYOVRD-FORWARD-PRODUCER COMP-3    PIC S9(7).             
                10  CR-GLS-LOB                           PIC 99.                
                10  CR-GLS-PRODUCT-CODE         COMP-3   PIC S9(5).             
                10  CR-GLS-PARIND                        PIC 9.                 
                                                                                
               05  CRFORWARD-CREDIT-PRODUCER   COMP-3    PIC S9(7).             
               05  CRMATCH-SEQUENCE-NO         COMP-3    PIC S9(07).            
                                                                                
            04  CR-VARI.                                                        
               05  CVARIABLE-DATA COMP-3 OCCURS 10 TIMES.                       
                   07  CRCODE                      PIC S9(3).                   
                   07  CRAMT                       PIC S9(11).                  
                   07  CCAMT REDEFINES CRAMT       PIC S9(10)V9.                
                   07  CMAMT REDEFINES CRAMT       PIC S9(09)V99.               
                   07  CPAMT REDEFINES CRAMT       PIC S9(06)V9(5).             
      *****************************************************************         
      *                                                               *         
      * AGCCRREX - THIS COPYBOOK DEFINES A SET OF COMMISSION RELATED  *         
      *            FIELDS THAT SUPPLEMENT THE DATA ON A COMMISSION    *         
      *            RELEASE RECORD (CRR).                              *         
      *                                                               *         
      *            THE ADDITIONAL DATA IS REQUIRED BY SOME OF OUR     *         
      *            INTER-CORPORATE PARTNERS.  FIRST PARTNER IS        *         
      *            GREAT WEST LIFE AND THE FIRST ADMIN SYSTEMS        *         
      *            USING THIS LAYOUT ARE CLAS AND PS.                 *         
      *                                                               *         
      * DATE WRITTEN - OCTOBER 2000                                   *         
      *                                                               *         
      * AUTHOR - AL TAYLOR                                            *         
      *                                                               *         
      * MAINTENANCE LOG:                                              *         
      * ----------------                                              *         
      *                                                               *         
      * DATE    AUTHOR        DESCRIPTION                             *         
      * ----    ------        -----------                             *         
      *                                                               *         
      *****************************************************************         
               03  AGCCRREX-DATA.                                               
                   05  AGCCRREX-INSURANCE-BEGINS-DATE     PIC 9(8).             
                   05  AGCCRREX-COVERAGE-STATUS.                                
                       10 AGCCRREX-COVERAGE-STATUS-GWL PIC X(1).                
                       10 F                            PIC X(4).                
                   05  AGCCRREX-COVERAGE-TYPE.                                  
                       10 AGCCRREX-COVERAGE-TYPE-GWL   PIC X(5).                
                       10 F                            PIC X(5).                
                   05  AGCCRREX-PRODUCT-CODE.                                   
                       10 AGCCRREX-PRODUCT-CODE-GWL    PIC X(5).                
                       10 F                            PIC X(5).                
                   05  AGCCRREX-COVERAGE-FACE-AMT                               
                                              PIC S9(11)V99.                    
                   05  AGCCRREX-TRANSACTION-TYPE.                               
                       10 AGCCRREX-TRANSACTION-TYPE-GWL  PIC X(8).              
                       10 F                              PIC X(2).              
                   05  AGCCRREX-MONTHLY-PREMIUM-AMT                             
                                              PIC S9(11)V99.                    
                   05  AGCCRREX-TERM-CONV-IND.                                  
                       10 AGCCRREX-TERM-CONV-IND-GWL   PIC X(1).                
                       10 F                            PIC X(4).                
                   05  AGCCRREX-RECORD-STATUS.                                  
                       10 AGCCRREX-RECORD-STATUS-GWL   PIC X(1).                
                       10 F                            PIC X(4).                
                   05  F                               PIC X(121).              
                                                                                
                                                                                
