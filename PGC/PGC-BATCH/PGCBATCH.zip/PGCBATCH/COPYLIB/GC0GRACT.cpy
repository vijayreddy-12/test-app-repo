      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORGRACCT' TO DBLINK-CURR-PARAGRAPH.                
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORGRACCT' TO RECORD-NAME.                                   
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORGRACCT TO DBLINK-RECORD-MADE-CURRENT.               
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORGRACCT-EXIT                                  
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE GROUP-NUMBER OF GC-TGRACT TO DBLINK-GWCORGRACCT-01          
               MOVE GR-ACCOUNT OF GC-TGRACT TO DBLINK-GWCORGRACCT-02            
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORGRACCT TO DBLINK-VIEW-NAME-CURRENT.                 
           MOVE DBLINK-GWCORGRACCT-KEY TO DBLINK-VIEW-200-CURRENT.              
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-ACCUM                                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORGRACCT-01 TO DBLINK-GRACCT-ACCUM-01.                
           MOVE DBLINK-GWCORGRACCT-02 TO DBLINK-GRACCT-ACCUM-02.                
           MOVE LOW-VALUES TO DBLINK-GRACCT-ACCUM-KEY-M.                        
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-CASECNT                                                      
      *%****************************** *                                        
           MOVE DBLINK-GWCORGRACCT-01 TO DBLINK-GRACCT-CASECNT-01.              
           MOVE DBLINK-GWCORGRACCT-02 TO DBLINK-GRACCT-CASECNT-02.              
           MOVE LOW-VALUES TO DBLINK-GRACCT-CASECNT-KEY-M.                      
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-COMP                                                         
      *%****************************** *                                        
           MOVE DBLINK-GWCORGRACCT-01 TO DBLINK-GRACCT-COMP-01.                 
           MOVE DBLINK-GWCORGRACCT-02 TO DBLINK-GRACCT-COMP-02.                 
           MOVE LOW-VALUES TO DBLINK-GRACCT-COMP-KEY-M.                         
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-RENEWAL                                                      
      *%****************************** *                                        
           MOVE DBLINK-GWCORGRACCT-01 TO DBLINK-GRACCT-RENEWAL-01.              
           MOVE DBLINK-GWCORGRACCT-02 TO DBLINK-GRACCT-RENEWAL-02.              
           MOVE LOW-VALUES TO DBLINK-GRACCT-RENEWAL-KEY-M.                      
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET GROUP-GRACCT  M/A                                                   
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-GROUP-GRACCT-F                          
           MOVE GROUP-NUMBER OF GC-TGRACT TO DBLINK-GROUP-GRACCT-01.            
           MOVE GROUP-GRACT-TS OF GC-TGRACT TO DBLINK-GROUP-GRACCT-02.          
