      **************************************************************            
      *   COPY BOOK TO REDIFINE GAESECUR-ARGUMENTS-IN-OUT                       
      **************************************************************            
              10 GAESECSP REDEFINES GAESECUR-ARGUMENTS-IN-OUT.                  
                 15  GAESECSP-OPERID        PIC X(3).                           
                 15  GAESECSP-GROUP         PIC X(7).                           
                 15  GAESECSP-RESPONSE      PIC X.                              
                 15  FILLER                 PIC X(189).                         
