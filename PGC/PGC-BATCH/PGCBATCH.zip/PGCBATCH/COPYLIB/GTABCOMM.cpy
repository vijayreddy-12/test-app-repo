      *****************************************************************         
      *    THIS COPYBOOK IS USED IN THE GROUP TABLES UTILITY.                   
      *    KEEP MAX LENGTH = 15000 WHICH IS THE MAX FOR THE FILE BUT            
      *    NOT THIS PARTICULAR RECORD TYPE.                                     
      *    THE LOCATION OF THE "KEY" AND "AUDIT" DATA AREAS IS STANDARD         
      *    FOR ALL RECORDS IN THE FILE.                                         
      *                                                                         
      *    COMMISSION SCALE RECORDS. KEY NAME = 'COMMSCAL'                      
      *    NOTE: POLICY YEAR IS COMPLEMENTED FROM 999. THE RECORDS              
      *          ARE THEN STORED IN DESCENDING ORDER BY POLICY YEAR.            
      *          E.G. YEAR 1 IS STORED AS 998.                                  
      *               YEAR 5 IS STORED AS 994.                                  
      *    MAX SIZE FOR COMMISSION SCALE RECORD:                                
      *        KEY (25) + AUDIT (25) + FIXED (100) + VAR (80*16) = 1430         
      *****************************************************************         
           05  GTABCOMM-REC-DATA.                                               
               10  GTABCOMM-KEY.                                                
                   15  GTABCOMM-NAME             PIC X(8).                      
                       88  GTABCOMM-NAME-COMMSCAL      VALUE 'COMMSCAL'.        
                   15  GTABCOMM-SCALE            PIC X(3).                      
                   15  GTABCOMM-POLICY-YEAR      PIC 9(3).                      
                   15  FILLER                    PIC X(11).                     
               10  GTABCOMM-AUDIT-DATA.                                         
                   15  GTABCOMM-DATE-STAMP.                                     
                       20  GTABCOMM-DATE-STAMP-Y PIC 9(4).                      
                       20  GTABCOMM-DATE-STAMP-M PIC 9(2).                      
                       20  GTABCOMM-DATE-STAMP-D PIC 9(2).                      
                   15  GTABCOMM-TIME-STAMP.                                     
                       20  GTABCOMM-TIME-STAMP-H PIC 9(2).                      
                       20  GTABCOMM-TIME-STAMP-M PIC 9(2).                      
                       20  GTABCOMM-TIME-STAMP-S PIC 9(2).                      
                   15  GTABCOMM-USERID           PIC X(8).                      
                   15  FILLER                    PIC X(3).                      
               10  GTABCOMM-TABLE-DATA.                                         
                   15  GTABCOMM-COMMENTS         PIC X(50).                     
                   15  FILLER                    PIC X(48).                     
                   15  GTABCOMM-BAND-CNT         PIC 9(2).                      
                   15  GTABCOMM-BAND-ENTRY OCCURS 80 TIMES.                     
                       20  GTABCOMM-BAND-AMT     PIC 9(9).                      
                       20  GTABCOMM-BAND-AMT-S   PIC X(1).                      
                       20  GTABCOMM-BAND-PCT     PIC 9(3)V9(2).                 
                       20  GTABCOMM-BAND-PCT-S   PIC X(1).                      
               10  FILLER                        PIC X(13570).                  
