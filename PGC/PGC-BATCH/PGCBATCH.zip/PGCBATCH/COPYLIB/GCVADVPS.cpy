      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           IF NEXT-RENEW-YEAR OF GWCORADVPSM  NOT NUMERIC                       
               MOVE ZEROS TO NEXT-RENEW-YEAR OF GC-TADVPS                       
           ELSE                                                                 
               MOVE NEXT-RENEW-YEAR OF GWCORADVPSM                              
               TO NEXT-RENEW-YEAR OF GC-TADVPS                                  
           END-IF.                                                              
                                                                                
           IF NEXT-RENEW-DAY OF GWCORADVPSM  NOT NUMERIC                        
               MOVE ZEROS TO NEXT-RENEW-DAY OF GC-TADVPS                        
           ELSE                                                                 
               MOVE NEXT-RENEW-DAY OF GWCORADVPSM                               
               TO NEXT-RENEW-DAY OF GC-TADVPS                                   
           END-IF.                                                              
                                                                                
           MOVE COMM-SCALE OF GWCORADVPSM                                       
               TO COMM-SCALE OF GC-TADVPS.                                      
                                                                                
           IF PSM-PREM-ADV OF GWCORADVPSM  NOT NUMERIC                          
               MOVE ZEROS TO PSM-PREM-ADV OF GC-TADVPS                          
           ELSE                                                                 
               MOVE PSM-PREM-ADV OF GWCORADVPSM                                 
               TO PSM-PREM-ADV OF GC-TADVPS                                     
           END-IF.                                                              
                                                                                
