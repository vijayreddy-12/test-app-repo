      *================================================================         
      *    COPYBOOK: VODPCIO                                                    
      *    PROTOCOL FOR VO DATA PROVIDER (VODPCIO)                              
      *----------------------------------------------------------------         
      *    APR/05 F. DAZA - CREATED                                             
      *----------------------------------------------------------------         
           05  VODPCIO-INPUT.                                                   
               10  VODPI-REQUEST              PIC X(16).                        
                   88  VODPI-OPEN-FILE        VALUE 'OPEN FILE      '.          
                   88  VODPI-READ-KEYED       VALUE 'READ KEYED    '.           
                   88  VODPI-READ-NEXT-WG     VALUE 'READ NEXT W/G '.           
                   88  VODPI-READ-NEXT        VALUE 'READ NEXT     '.           
                   88  VODPI-END-READ-NEXT    VALUE 'END READ NEXT '.           
                   88  VODPI-CLOSE-FILE       VALUE 'CLOSE FILE     '.          
               10  VODPI-COVERAGE-TYPE        PIC X(03).                        
                   88  VODPI-COV-COVDB        VALUE 'COV'.                      
                   88  VODPI-COV-NONCOV       VALUE 'NCV'.                      
                   88  VODPI-COV-ANY          VALUE '   '.                      
               10  VODPI-GROUP                PIC 9(07).                        
               10  VODPI-ACCOUNT              PIC X(05).                        
               10  VODPI-LR-NAME              PIC X(16).                        
                   88  VODPI-LR-GIPSY-EXP     VALUE 'GIPSY EXPANDED'.           
                   88  VODPI-LR-VO-RAW        VALUE 'VO RAW DATA   '.           
                   88  VODPI-LR-DEFAULT       VALUE 'DEFAULT       '.           
           05  VODPCIO-OUTPUT.                                                  
               10  VODPO-RET-CODE             PIC X(02).                        
                   88  VODPO-RET-OK           VALUE '00'.                       
                   88  VODPO-RET-WARNING      VALUE '01' THRU '09'.             
                   88  VODPO-RET-ERROR        VALUE '10' THRU '89'.             
                   88  VODPO-RET-SEVERE-ERROR VALUE '90' THRU '99'.             
               10  VODPO-RET-MESSAGE          PIC X(80).                        
               10  VODPO-DATA.                                                  
                   15 VODPO-GROUP             PIC 9(07).                        
                   15 VODPO-ACCOUNT           PIC X(05).                        
                   15 VODPO-COVERAGE-TYPE     PIC X(03).                        
                       88  VODPO-COV-COVDB    VALUE 'COV'.                      
                       88  VODPO-COV-NONCOV   VALUE 'NCV'.                      
                   15 VODPO-MAPPED-RECORD     PIC X(15700).                     
