      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORACCUM                           11/02/10  07:16  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORACCUM.                                                          
           05  PREM-DUE-DATE.                                                   
               10  PREM-DUE-YEAR              COMP-3    PIC S9(3).              
               10  PREM-DUE-DAY               COMP-3    PIC S9(3).              
           05  PREM-AMT-PAID                  COMP-3    PIC S9(9)V99.           
           05  COMM-AMT-EARNED                COMP-3    PIC S9(9)V99.           
           05  SALES-CREDITS-AMT-EARNED       COMP-3    PIC S9(9)V99.           
