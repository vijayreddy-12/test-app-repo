      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE LAST-GIPSY-DAILY-RUN-YEAR OF GC-TCNTL TO                        
               LAST-GIPSY-DAILY-RUN-YEAR OF GWCORCNTL                           
           MOVE LAST-GIPSY-DAILY-RUN-DAY OF GC-TCNTL TO                         
               LAST-GIPSY-DAILY-RUN-DAY OF GWCORCNTL                            
           MOVE LAST-RECON-RUN-YEAR OF GC-TCNTL TO                              
               LAST-RECON-RUN-YEAR OF GWCORCNTL                                 
           MOVE LAST-RECON-RUN-DAY OF GC-TCNTL TO                               
               LAST-RECON-RUN-DAY OF GWCORCNTL                                  
           MOVE LAST-REN-PREM-RUN-YEAR OF GC-TCNTL TO                           
               LAST-REN-PREM-RUN-YEAR OF GWCORCNTL                              
           MOVE LAST-REN-PREM-RUN-DAY OF GC-TCNTL TO                            
               LAST-REN-PREM-RUN-DAY OF GWCORCNTL                               
           MOVE LAST-REN-COMM-RUN-YEAR OF GC-TCNTL TO                           
               LAST-REN-COMM-RUN-YEAR OF GWCORCNTL                              
           MOVE LAST-REN-COMM-RUN-DAY OF GC-TCNTL TO                            
               LAST-REN-COMM-RUN-DAY OF GWCORCNTL                               
           MOVE COMM-SCR-RECON-IND OF GC-TCNTL TO                               
               COMM-SCR-RECON-IND OF GWCORCNTL                                  
           MOVE NAP-RECON-IND OF GC-TCNTL TO                                    
               NAP-RECON-IND OF GWCORCNTL                                       
           MOVE RECON-DATE-UPDATE-IND OF GC-TCNTL TO                            
               RECON-DATE-UPDATE-IND OF GWCORCNTL.                              
