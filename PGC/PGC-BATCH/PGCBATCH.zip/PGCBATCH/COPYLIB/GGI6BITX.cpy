       01  GGI6BITX.                                                            
      *****************************************************************         
      * NEW FOR GIPSY RELEASE #1, SEPTEMBER 1989                                
      *   TITLES AREA BELOW WILL CONTAIN THE *EXPANDED* VERSION OF THE          
      *   COMPRESSED 'GGITITLES-AREA' FIELD IN 'GMASTER'.  TRANSLATION          
      *   TO/FROM THE MASTER RECORD IS ACCOMPLISHED USING ROUTINE               
      *   'GUTBITS6'.  (I. BUCKNELL)                                            
      *****************************************************************         
           05  B6-GGITITLES-EXPANDED.                                           
               10  B6-GGITITLES-LIST.                                           
                   15  B6-GGITITLES        OCCURS 9 TIMES.                      
                       20  B6-GGITITLE-LINE1                PIC X(9).           
                       20  B6-GGITITLE-LINE2                PIC X(9).           
               10  B6-GGIPREM-OR-VOL-LIST.                                      
                   15  B6-GGIPREM-OR-VOL   OCCURS 9 TIMES   PIC X.              
