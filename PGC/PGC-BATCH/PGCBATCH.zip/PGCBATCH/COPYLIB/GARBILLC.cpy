      *01  M-F-C-Bill.                                                          
      *---------------------------------------------------------------*         
      * BILLING PAYMENT DATA DEFINITION - (FOR XML USAGE)             *         
      *---------------------------------------------------------------*         
           05  RECORD-TYPE                          PIC X(1).                   
DATE1      05  PROCESS-DATE                         PIC X(8).                   
           05  GROUP-INFORMATION.                                               
               10  POLICY                           PIC X(10).                  
               10  ACCOUNT                          PIC X(3).                   
               10  MAILING-DIVISION                 PIC X(3).                   
           05  PAYMENT-INFORMATION.                                             
               10  PAYMENT-AMOUNT                   PIC S9(7)V99                
                   SIGN LEADING SEPARATE.                                       
DATE1          10  PAYMENT-DATE                     PIC X(8).                   
               10  PAYMENT-REG-TAX                  PIC X(1).                   
               10  PAYMENT-TAX-CODE                 PIC X(2).                   
               10  PAYMENT-ORDER                    PIC X(1).                   
