      *****************************************************************         
      *                                                                         
      *          IFPRMEXT - IN FORCE 1ST PREMIUM EXTRACT RECORD                 
      *                                                                         
      *          CREATED BY GFMPREMX                                            
      *          USED    BY GWCOCPRM                                            
      *****************************************************************         
      * 11SEP90, IAN BUCKNELL, CREATED FOR SUPPORT RELEASE 3 (COMM)             
      *****************************************************************         
       01  IFPRMEXT-RECORD.                                                     
           05  IFPRMEXT-GFO                  PIC X(05)    VALUE SPACES.         
REN        05  IFPRMEXT-GROUP        COMP-3  PIC S9(7)    VALUE +0.             
           05  IFPRMEXT-ACCT                 PIC X(03)    VALUE SPACES.         
           05  IFPRMEXT-GPSY-PREM    COMP-3  PIC S9(9)V99 VALUE +0.             
           05  IFPRMEXT-SCALE                PIC X(03)    VALUE SPACES.         
           05  IFPRMEXT-SCALE-LTD            PIC X(03)    VALUE SPACES.         
           05  IFPRMEXT-PRODUCER             PIC X(06)    VALUE SPACES.         
