       01  WMTAXTR.                                                     00010000
           03  W-GTX-TAXES.                                             04080000
               05  W-GTX-TRIDENT                 PIC X(3).                      
               05  W-GTX-LENGTH                  PIC S9(5)      COMP-3.         
               05  W-GTX-OUTSTANDING.                                           
                   10  W-GTX-OUTST-CNT           PIC S9(3)      COMP-3.         
                   10  W-GTX-OUTST-ENTRY OCCURS 13 TIMES.                       
                       15  W-GTX-OUTST-TAX-CODE  PIC X(2).                      
                       15  W-GTX-OUTST-TAX-AMT   PIC S9(7)V9(2) COMP-3.         
               05  W-GTX-FILLER1                 PIC X(51).                     
               05  W-GTX-HIST-CNT                PIC S9(3)      COMP-3.         
               05  W-GTX-HISTORY.                                               
                   10  W-GTX-HIST-ENTRY OCCURS 25 TIMES.                        
                       15  W-GTX-HIST-DUE-DATE.                                 
                           20  W-GTX-HIST-DUE-YEAR                              
                                                 PIC S9(3)      COMP-3.         
                           20  W-GTX-HIST-DUE-DAY                               
                                                 PIC S9(3)      COMP-3.         
                       15  W-GTX-HIST-TAX-CNT    PIC S9(3)      COMP-3.         
                       15  W-GTX-FILLER3         PIC X(1).                      
                       15  W-GTX-HIST-ENTRY2 OCCURS 13 TIMES.                   
                           20  W-GTX-HIST-TAX-CODE                              
                                                 PIC X(2).                      
                           20  W-GTX-HIST-TAX-AMT                               
                                                 PIC S9(7)V9(2) COMP-3.         
