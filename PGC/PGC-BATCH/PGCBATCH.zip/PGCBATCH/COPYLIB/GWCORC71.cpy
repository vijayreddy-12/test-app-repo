      ******************************************************************        
      *                                                                *        
      *         COMMISSION - RECONCILIATION EXTRACT RECORD             *        
      *                                                                *        
      ******************************************************************        
       01  EXT-RECON-COMM-RECORD.                                               
           05  EXT-COMM-SORT-KEY.                                               
REN            10  EXT-COMM-GROUP-NUMBER         PIC X(7)  VALUE SPACES.        
               10  EXT-COMM-GROUP-NUMBER-N                                      
REN                    REDEFINES EXT-COMM-GROUP-NUMBER     PIC 9(7).            
               10  EXT-COMM-GROUP-ACCOUNT        PIC XXX   VALUE SPACES.        
               10  EXT-COMM-AGENT-NUMBER         PIC 9(6)  VALUE ZERO.          
               10  EXT-COMM-EFF-DATE.                                           
                   15  EXT-COMM-EFF-YEAR  COMP-3 PIC S999  VALUE ZERO.          
                   15  EXT-COMM-EFF-DAY   COMP-3 PIC S999  VALUE ZERO.          
           05  EXT-RECON-COMM-DATA.                                             
               10  EXT-COMM-GFO-NUMBER           PIC 9(5)  VALUE ZERO.          
               10  EXT-COMM-BR-NUMBER            PIC 9(5)  VALUE ZERO.          
               10  EXT-COMM-COMP-TYPE            PIC X     VALUE SPACE.         
               10  EXT-COMM-COMP-REASON          PIC X     VALUE SPACE.         
               10  EXT-COMM-COMP-DISP            PIC X     VALUE SPACE.         
               10  EXT-COMM-COV-TYPE             PIC X     VALUE SPACE.         
               10  EXT-COMM-COMP-AMT     COMP-3 PIC S9(9)V99 VALUE ZERO.        
               10  EXT-COMM-MONTHS        COMP-3 PIC S999  VALUE ZERO.          
               10  EXT-COMM-REC-TYPE             PIC X     VALUE SPACE.         
               10  FILLER                        PIC X(14) VALUE SPACES.        
