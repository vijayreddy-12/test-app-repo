      *01  M-F-C-Bill-Group-end                                                 
      *---------------------------------------------------------------*         
      * BILLING GROUP END DATA DEFINITION - (FOR XML USAGE)           *         
      *---------------------------------------------------------------*         
           05  BILL-INFORMATION.                                                
               10  RECORD-TYPE                      PIC X(1).                   
DATE1          10  PROCESS-DATE                     PIC X(8).                   
               10  GROUP-INFORMATION.                                           
                   15  POLICY                       PIC X(10).                  
                   15  ACCOUNT                      PIC X(3).                   
                   15  MAILING-DIVISION             PIC X(3).                   
               10  GENERATED-INFORMATION.                                       
                   15  GROUP-PAD-STATUS             PIC X(1).                   
DATE1              15  GROUP-PAD-DATE               PIC X(8).                   
                   15  LOCAL-PHONE-NUMBER           PIC X(14).                  
                   15  TOLL-FREE-NUMBER             PIC X(14).                  
                   15  NUM-OF-ERRORS VALUE ZERO     PIC 9(3).                   
TIMES1             15  GROUP-ERRORS                 OCCURS 25 TIMES.            
                       20  GROUP-ERROR-CODE         PIC X(3).                   
TIMES2             15  NUM-OF-COLS   VALUE ZERO     PIC 9(3).                   
TIMES2             15  COLUMN-DATA                  OCCURS 36 TIMES.            
ATTRIB                 20  COL                      PIC 9(1).                   
ATTRIB                 20  COV-CODE                 PIC X(3).                   
                       20  FIELD-TYPE               PIC X(1).                   
                       20  TITLE-1                  PIC X(9).                   
                       20  TITLE-2                  PIC X(9).                   
