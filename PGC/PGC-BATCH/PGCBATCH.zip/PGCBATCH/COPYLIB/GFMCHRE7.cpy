       01  GI-CH-CHANGE-RECORD.                                                 
      *************************************************************             
      *                                                           *             
      *                  FM CHANGE RECORD                         *             
      *                                                           *             
      *********************************************************** *             
      *          HISTORY....                                      *             
      *********************************************************** *             
      *                                                           *             
      *       CREATED BY   GFMWRIDL, GFMEDM2D, GFMINTM2 & 4       *             
      *       USED    BY   GPRCHNGS                               *             
      *                                                           *             
      *  SEP/89   MARCUS   ADD SRT-FIELDS AS PART OF GPSY-REL-1   *             
      *                    REQ #  240  ALPHA+                     *             
      *  OCT/90   PRANGE   ADDED GI-P5B-NEXT-RENEWAL-DATE         *             
      *                    (REL # 3)                              *             
      *                                                           *             
      *       REC TYPE     'N'                                    *             
      *       REC LENGTH   61                                     *             
      *                                                           *             
      *************************************************************             
                                                                                
           05  GI-CH-REC-LENGTH               COMP   PIC S9(4).                 
           05  FILLER                                PIC XX.                    
           05  GI-CH-RECORD-TYPE                     PIC X.                     
           05  GI-CH-FORM                            PIC X.                     
GNE        05  GI-CH-GROUP               COMP-3      PIC S9(7).                 
           05  GI-CH-ACCOUNT                         PIC XXX.                   
           05  GI-CH-ORDER                           PIC X.                     
           05  GI-CH-NAME-CERT.                                                 
               10  GI-CH-NAME1                       PIC X(32).                 
               10  GI-CH-CERT1           COMP-3      PIC S9(9).                 
           05  GI-CH-CERT-NAME     REDEFINES GI-CH-NAME-CERT.                   
               10  GI-CH-CERT2           COMP-3      PIC S9(9).                 
               10  GI-CH-NAME2                       PIC X(32).                 
           05  GI-CH-SRT-FIELDS.                                                
               10  GI-CH-SRT-PCODE                   PIC X.                     
               10  GI-CH-SRT-BRANCH-GFO              PIC X(5).                  
           05  GI-CH-EFFDATE.                                                   
               10  GI-CH-EFFYEAR         COMP-3      PIC S9(3).                 
               10  GI-CH-EFFDAY          COMP-3      PIC S9(3).                 
GNE   *    05  FILLER                                PIC X(1).                  
       01  GI-M2D-CHNG-AREA REDEFINES GI-CH-CHANGE-RECORD.                      
           05  GI-M2D-REC-LENGTH                     PIC S9(4) COMP.            
           05  FILLER                                PIC XX.                    
           05  GI-M2D-REC-TYPE                       PIC X.                     
           05  GI-M2D-FORM                           PIC X.                     
           05  GI-M2D-SRT-FIELDS.                                               
               10  GI-M2D-SRT-PCODE                  PIC X.                     
               10  GI-M2D-SRT-BRANCH-GFO             PIC X(5).                  
           05  GI-M2D-COUNTRY                        PIC X.                     
GNE        05  GI-M2D-GROUP               COMP-3     PIC S9(7).                 
           05  GI-M2D-ACCOUNT                        PIC XXX.                   
           05  GI-M2D-ORDER                          PIC X.                     
           05  GI-M2D-NEXT-ANNIVERSARY-DATE.                                    
               10  GI-M2D-N-A-YEAR           COMP-3  PIC S999.                  
               10  GI-M2D-N-A-DAY            COMP-3  PIC S999.                  
           05  GI-P5B-NEXT-RENEWAL-DATE REDEFINES                               
                                        GI-M2D-NEXT-ANNIVERSARY-DATE.           
               10  GI-P5B-NR-YEAR            COMP-3  PIC S999.                  
               10  GI-P5B-NR-DAY             COMP-3  PIC S999.                  
GNE        05  FILLER                                PIC X(36).                 
