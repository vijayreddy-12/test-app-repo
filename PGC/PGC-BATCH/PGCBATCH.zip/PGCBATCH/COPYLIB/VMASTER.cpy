       01  VMASTER.                                                             
      *****************************************************************         
      *     VO CONTRACT MASTER VSAM FILE                              *         
      *****************************************************************         
      *    APR/05 F. MUELLER                                          *         
      *           - CREATED FOR VO CLIENT CONTRACT INTEGRATION        *         
      *             WITH LEGACY GLH SYSTEMS                           *         
      *           - MODELLED AFTER GIPSY MASTER VSAM FORMAT           *         
      *****************************************************************         
      *         GENERAL INFORMATION                                   *         
      *****************************************************************         
           03  VGI-KEY-INFORMATION.                                             
               05  VGI-POLICY-NUM                PIC S9(7) COMP-3.              
               05  VGI-LOCATION-NUM              PIC X(5).                      
                                                                                
           03  VGI-GENERAL-INFORMATION.                                         
               05  VGI-MASTER-IDENT              PIC X.                         
               05  VGI-COV-LOC-CODE              PIC X.                         
               05  VGI-IDENTITY                  PIC X(5).                      
               05  VGI-BRANCH                    PIC X(5).                      
               05  VGI-GROUP-REP                 PIC 9(5).                      
               05  VGI-GROUP-REP2                PIC 9(5).                      
               05  VGI-GROUP-OFFICE              PIC X(5).                      
               05  VGI-SHARING-OFFICE            PIC X(5).                      
               05  VGI-CLAIMS-OFFICE             PIC X(5).                      
               05  VGI-COUNTRY                   PIC X.                         
               05  VGI-CURRENCY                  PIC X.                         
               05  VGI-RESIDENCE                 PIC XX.                        
               05  VGI-LANGUAGE                  PIC X.                         
               05  VGI-PRODUCT-CODE              PIC X.                         
               05  VGI-POLICY-ACCT               PIC X.                         
               05  VGI-ACCT-TYPE.                                               
                   10 VGI-TYPE                   PIC X.                         
                   10 VGI-UW-TYPE                PIC X.                         
               05  VGI-COVERAGE-CODE             PIC X.                         
               05  VGI-BENEFIT-SEL               PIC X.                         
               05  VGI-STD-IND-CLASS-CODE        PIC 9(5).                      
               05  VGI-CONTRIBUTION              PIC X.                         
               05  VGI-BENEFIT-LINK              PIC X.                         
               05  VGI-TAX                       PIC X.                         
               05  VGI-WITHHOLDING               PIC X.                         
               05  VGI-EMPLOYEE-LIST             PIC X.                         
               05  VGI-HANDLING-CODE             PIC X.                         
               05  VGI-ARREARS-IND               PIC X.                         
               05  VGI-ARREARS-COUNTER           PIC S9(3) COMP-3.              
               05  VGI-ARREARS-STATUS            PIC X.                         
               05  VGI-REDUCTION-AGES.                                          
                   10  VGI-RED-AGE-LIFE          PIC S9(3) COMP-3.              
                   10  VGI-RED-AGE-LTD           PIC S9(3) COMP-3.              
                   10  VGI-RED-AGE-AD-D          PIC S9(3) COMP-3.              
                   10  VGI-RED-AGE-MEDICAL       PIC S9(3) COMP-3.              
                   10  VGI-RED-AGE-DENTAL        PIC S9(3) COMP-3.              
                   10  VGI-RED-AGE-WI            PIC S9(3) COMP-3.              
               05  VGI-TERMINATION-AGES.                                        
                   10  VGI-TERM-AGE-LIFE         PIC S9(3) COMP-3.              
                   10  VGI-TERM-AGE-LTD          PIC S9(3) COMP-3.              
                   10  VGI-TERM-AGE-AD-D         PIC S9(3) COMP-3.              
                   10  VGI-TERM-WAIT-PERIOD-LTD  PIC S9(3) COMP-3.              
                   10  VGI-TERM-AGE-MEDICAL      PIC S9(3) COMP-3.              
                   10  VGI-TERM-AGE-DENTAL       PIC S9(3) COMP-3.              
                   10  VGI-TERM-AGE-WI           PIC S9(3) COMP-3.              
               05  VGI-STEP-DOWN                 PIC X.                         
               05  VGI-CHANGE-DATE               PIC X.                         
               05  VGI-ACCOUNT-STATUS            PIC XX.                        
               05  VGI-DATES.                                                   
DATE1              10  VGI-NEXT-ANNIVERSARY      PIC X(8).                      
DATE1              10  VGI-CLAIMS-SUSPENDED      PIC X(8).                      
DATE1              10  VGI-CONTRACT-ISSUE        PIC X(8).                      
DATE1              10  VGI-ACCT-EFFECTIVE        PIC X(8).                      
DATE1              10  VGI-PAID-TO-DATE          PIC X(8).                      
DATE1              10  VGI-LAST-CHANGE-DATE      PIC X(8).                      
DATE1              10  VGI-LAST-ACCOUNTING-DATE  PIC X(8).                      
               05  VGI-POL-ARREARS               PIC S9(3) COMP-3.              
               05  VGI-CASHFLOW-LST-POL-YR       PIC 9(4).                      
               05  VGI-CASHFLOW-CURR-POL-YR      PIC 9(4).                      
               05  VGI-BILL-STAT-FORMAT.                                        
                   10  VGI-BILLING-AGENT         PIC 9(6).                      
                   10  VGI-BILLING-TYPE          PIC XX.                        
                   10  VGI-LISTING-CERTIFICATE   PIC X.                         
                   10  VGI-LISTING-ORDER         PIC X.                         
                   10  VGI-STAT-OPTION.                                         
                       15  VGI-LIST-BILLING      PIC X.                         
                       15  VGI-EMP-CHANGE-LIST   PIC X.                         
                       15  VGI-WORK-SHEET        PIC X.                         
                       15  VGI-SUMMARY           PIC X.                         
               05  VGI-CLAIMS-INFORMATION.                                      
                   10  VGI-CARRYOVER-IND.                                       
                       15  VGI-CARRYOVER-HC     PIC X.                          
                       15  VGI-CARRYOVER-DE     PIC X.                          
                   10  VGI-ELIGIBLE-BENEFITS    PIC X.                          
                   10  VGI-PRIVATE-DUTY-NURSING PIC 9(2).                       
                   10  VGI-DENTAL-PLAN-IND      PIC X.                          
                   10  VGI-LAB-FEES             PIC XX.                         
               05  VGI-FOGL-CODE OCCURS 6 TIMES.                                
                   10 VGI-FOGL-BENEFIT          PIC X(4).                       
                   10 VGI-FOGL-REINS            PIC X(2).                       
                   10 VGI-FOGL-GRP-TYPE         PIC X.                          
                   10 VGI-FOGL-AGT-TYPE         PIC X.                          
                   10 VGI-FOGL-ADMIN-AREA       PIC X.                          
                   10 VGI-FOGL-LIVES-RANGE      PIC X.                          
               05  VGI-FUND-TYPE OCCURS 6 TIMES PIC X.                          
               05  VGI-BILLING-OVERIDE.                                         
                   10 VGI-BILLING-OVERIDE-IND   PIC X.                          
                   10 VGI-BILLING-OR-TELE-NUM   PIC X(11).                      
               05  VGI-PH-EOB                   PIC X.                          
               05  VGI-ADMIN-AREA               PIC X(1).                       
               05  VGI-LIVES-RANGE              PIC X(1).                       
               05  VGI-MAIL-INSTRUCTION         PIC X(1).                       
               05  VGI-UNDEFINED                PIC X(26).                      
                                                                                
      *****************************************************************         
      *      STATISTICS INFORMATION                                   *         
      *****************************************************************         
           03  VST-STATISTICS.                                                  
               05  VST-PAID-IND                 PIC X.                          
               05  VST-OUTSTANDING.                                             
                   10  VST-OUT-LIFE             PIC S9(7)V99 COMP-3.            
                   10  VST-OUT-LTD              PIC S9(7)V99 COMP-3.            
                   10  VST-OUT-A-S              PIC S9(7)V99 COMP-3.            
                   10  VST-OUT-ADMIN-FEE        PIC S9(7)V99 COMP-3.            
               05  VST-PREMIUM-IND              PIC X.                          
               05  VST-ADVANCE                  PIC S9(7)V99 COMP-3.            
               05  VST-CALENDAR-YEAR-TO-DATE.                                   
                   10  VST-CAL-YTD-LIFE.                                        
                       15  VST-CAL-YTD-LI-BILLED PIC S9(7)V99 COMP-3.           
                       15  VST-CAL-YTD-LI-PAID   PIC S9(7)V99 COMP-3.           
                   10  VST-CAL-YTD-A-S.                                         
                       15  VST-CAL-YTD-AS-BILLED PIC S9(7)V99 COMP-3.           
                       15  VST-CAL-YTD-AS-PAID   PIC S9(7)V99 COMP-3.           
                   10  VST-CAL-YTD-LTD.                                         
                       15  VST-CAL-YTD-LTD-BILLED PIC S9(7)V99 COMP-3.          
                       15  VST-CAL-YTD-LTD-PAID   PIC S9(7)V99 COMP-3.          
                   10  VST-CAL-YTD-ADMIN-FEE      COMP-3.                       
                       15  VST-CAL-YTD-ADMIN-FEE-BILLED PIC S9(7)V99.           
                       15  VST-CAL-YTD-ADMIN-FEE-PAID   PIC S9(7)V99.           
               05  VST-PREMIUMS.                                                
                   10  VST-PREM-LIFE            PIC S9(7)V99 COMP-3.            
                   10  VST-PREM-LTD             PIC S9(7)V99 COMP-3.            
                   10  VST-PREM-AD-D            PIC S9(7)V99 COMP-3.            
                   10  VST-PREM-WI              PIC S9(7)V99 COMP-3.            
                   10  VST-PREM-EHC.                                            
                       15  VST-PREM-EHC-SINGLE  PIC S9(7)V99 COMP-3.            
                       15  VST-PREM-EHC-FAMILY1 PIC S9(7)V99 COMP-3.            
                       15  VST-PREM-EHC-FAMILY2 PIC S9(7)V99 COMP-3.            
                   10  VST-PREM-DEN.                                            
                       15  VST-PREM-DEN-SINGLE  PIC S9(7)V99 COMP-3.            
                       15  VST-PREM-DEN-FAMILY1 PIC S9(7)V99 COMP-3.            
                       15  VST-PREM-DEN-FAMILY2 PIC S9(7)V99 COMP-3.            
               05  VST-CURR-MONTH-PREM-ADJ.                                     
                   10  VST-PREM-ADJ-LIFE        PIC S9(5)V99 COMP-3.            
                   10  VST-PREM-ADJ-LTD         PIC S9(5)V99 COMP-3.            
                   10  VST-PREM-ADJ-AD-D        PIC S9(5)V99 COMP-3.            
                   10  VST-PREM-ADJ-WI          PIC S9(5)V99 COMP-3.            
                   10  VST-PREM-ADJ-EHC         COMP-3.                         
                       15  VST-PREM-ADJ-EHC-SINGLE  PIC S9(5)V99.               
                       15  VST-PREM-ADJ-EHC-FAMILY1 PIC S9(5)V99.               
                       15  VST-PREM-ADJ-EHC-FAMILY2 PIC S9(5)V99.               
                   10  VST-PREM-ADJ-DEN         COMP-3.                         
                       15  VST-PREM-ADJ-DEN-SINGLE  PIC S9(5)V99.               
                       15  VST-PREM-ADJ-DEN-FAMILY1 PIC S9(5)V99.               
                       15  VST-PREM-ADJ-DEN-FAMILY2 PIC S9(5)V99.               
               05  VST-PROJECTED-LOSS-RATIO.                                    
                   10  VST-PROJ-LR-PREV-POLYR   PIC S9(4)V9 COMP-3.             
                   10  VST-PROJ-LR-CURR-POLYR   PIC S9(4)V9 COMP-3.             
               05  VST-ACCEPT-LOSS-PREV         PIC S9(4)V9 COMP-3.             
               05  VST-PART                     PIC S9(7) COMP-3.               
               05  VST-NON-PART                 PIC S9(5) COMP-3.               
               05  VST-UNDEFINED                PIC X(33).                      
TIMES3         05  VST-NUM-COV-CODES      COMP  PIC 9(4).                       
TIMES3         05  VST-STATS-BY-COV OCCURS 15 TIMES.                            
                   10  VST-STAT-COV-CODE        PIC X(3).                       
                   10  VST-STAT-VOL             PIC S9(9) COMP-3.               
                   10  VST-STAT-LIVES           PIC S9(7) COMP-3.               
                                                                                
      *****************************************************************         
      *         BILLING NAME AND ADDRESS INFORMATION                  *         
      *****************************************************************         
           03  VBN-BILLING-NAME-ADDRESS.                                        
               05  VBN-POSTAL-CODE              PIC X(6).                       
DATE1          05  VBN-NAAD-PROC-DATE           PIC X(8).                       
               05  VBN-BILLING-NAME             PIC X(30).                      
               05  VBN-BILLING-ADDRESS   OCCURS 5 TIMES.                        
                   10  VBN-ADDRESS-LINE         PIC X(30).                      
               05  VBN-PARSED-BILLING-ADDRESS.                                  
                   10  ADDRESS-TYPE-CD          PIC 9(2).                       
                   10  CONFIDENTIAL-FLG         PIC X(1).                       
                   10  ADDRESS-NM               PIC X(50).                      
                   10  CONTACT-NM               PIC X(30).                      
                   10  ADDITIONAL-ADDR-NM       PIC X(40).                      
                   10  STREET-ADDRESS-NM        PIC X(40).                      
                   10  SUITE-NM                 PIC X(30).                      
                   10  CITY-NM                  PIC X(30).                      
                   10  PROVINCE                 PIC X(2).                       
                   10  POSTAL-NUM               PIC X(15).                      
                   10  COUNTRY                  PIC X(3).                       
                                                                                
      *****************************************************************         
      *         CLAIMS NAME AND ADDRESS INFORMATION                   *         
      *****************************************************************         
           03  VCN-CLAIMS-NAME-ADDRESS.                                         
               05  VCN-POSTAL-CODE              PIC X(6).                       
               05  VCN-CLAIMS-NAME              PIC X(30).                      
               05  VCN-CLAIMS-ADDRESS    OCCURS 5 TIMES.                        
                   10  VCN-ADDRESS-LINE         PIC X(30).                      
               05  VCN-PARSED-CLAIMS-ADDRESS.                                   
                   10  ADDRESS-TYPE-CD          PIC 9(2).                       
                   10  CONFIDENTIAL-FLG         PIC X(1).                       
                   10  ADDRESS-NM               PIC X(50).                      
                   10  CONTACT-NM               PIC X(30).                      
                   10  ADDITIONAL-ADDR-NM       PIC X(40).                      
                   10  STREET-ADDRESS-NM        PIC X(40).                      
                   10  SUITE-NM                 PIC X(30).                      
                   10  CITY-NM                  PIC X(30).                      
                   10  PROVINCE                 PIC X(2).                       
                   10  POSTAL-NUM               PIC X(15).                      
                   10  COUNTRY                  PIC X(3).                       
                                                                                
      *****************************************************************         
      *         OTHER NAME AND ADDRESS INFORMATION                    *         
      *****************************************************************         
           03  VON-OTHER-NAME-ADDRESS.                                          
               05  VON-POSTAL-CODE              PIC X(6).                       
               05  VON-IDENT                    PIC XX.                         
               05  VON-OTHER-NAME               PIC X(30).                      
               05  VON-OTHER-ADDRESS     OCCURS 5 TIMES.                        
                   10  VON-ADDRESS-LINE         PIC X(30).                      
               05  VON-PARSED-OTHER-ADDRESS.                                    
                   10  ADDRESS-TYPE-CD          PIC 9(2).                       
                   10  CONFIDENTIAL-FLG         PIC X(1).                       
                   10  ADDRESS-NM               PIC X(50).                      
                   10  CONTACT-NM               PIC X(30).                      
                   10  ADDITIONAL-ADDR-NM       PIC X(40).                      
                   10  STREET-ADDRESS-NM        PIC X(40).                      
                   10  SUITE-NM                 PIC X(30).                      
                   10  CITY-NM                  PIC X(30).                      
                   10  PROVINCE                 PIC X(2).                       
                   10  POSTAL-NUM               PIC X(15).                      
                   10  COUNTRY                  PIC X(3).                       
                                                                                
      *****************************************************************         
      *         PREMIUM SPLIT INFORMATION                             *         
      *****************************************************************         
           03  VPS-PREMIUM-SPLIT-INFORMATION.                                   
               05  VPS-PREMIUM-SPLIT OCCURS 10 TIMES.                           
                   10  VPS-CODE                 PIC X.                          
DATE1              10  VPS-START-DATE           PIC X(8).                       
DATE1              10  VPS-STOP-DATE            PIC X(8).                       
                   10  VPS-FIRST-YEAR.                                          
                       15  VPS-FRST-LIFE        PIC S9(5)V99 COMP-3.            
                       15  VPS-FRST-LTD         PIC S9(5)V99 COMP-3.            
                       15  VPS-FRST-A-S         PIC S9(5)V99 COMP-3.            
                                                                                
      *****************************************************************         
      *         AGENTS INFORMATION                                    *         
      *****************************************************************         
           03  VAG-AGENT-INFORMATION.                                           
               05  VAG-AGENT       OCCURS 4 TIMES.                              
                   10  VAG-AGENT-CODE           PIC 9(6).                       
                   10  VAG-ACCOUNT              PIC X.                          
                   10  VAG-AGENT-BRANCH         PIC X(5).                       
                   10  VAG-RENEW-COMM-PD        PIC S9(7)V99 COMP-3.            
                   10  VAG-RENEW-COMM-EARN      PIC S9(7)V99 COMP-3.            
                   10  VAG-SALES-CRED-PD        PIC S9(7)V99 COMP-3.            
                   10  VAG-SALES-CRED-EARN      PIC S9(7)V99 COMP-3.            
                   10  VAG-CASE-CNT-PD          PIC S9(7)V99 COMP-3.            
                   10  VAG-CASE-CNT-EARN        PIC S9(7)V99 COMP-3.            
                   10  VAG-NAP-PAID1            PIC S9(7)V99 COMP-3.            
                   10  VAG-NAP-EARNED1          PIC S9(7)V99 COMP-3.            
                   10  VAG-NAP-PAID2            PIC S9(7)V99 COMP-3.            
                   10  VAG-NAP-EARNED2          PIC S9(7)V99 COMP-3.            
                   10  VAG-PAYMENT-PLAN.                                        
                       15  VAG-PAYMENT-TYPE     PIC X.                          
                       15  VAG-CANN-COUNTER     PIC X.                          
                       15  VAG-PERCENT-DEFER    PIC S9(5)V99 COMP-3.            
                       15  VAG-ANNUALIZED-PAID  PIC S9(7)V99 COMP-3.            
                       15  VAG-ANNUALIZED-EARN  PIC S9(7)V99 COMP-3.            
                   10  VAG-AGENT-SCALE    OCCURS 5 TIMES.                       
                       15  VAG-COMM-IND         PIC X.                          
DATE1                  15  VAG-START-DATE       PIC X(8).                       
DATE1                  15  VAG-STOP-DATE        PIC X(8).                       
                       15  VAG-FIRST-YEAR.                                      
                           20  VAG-FRST-LIFE      PIC S9(3)V99 COMP-3.          
                           20  VAG-FRST-LTD       PIC S9(3)V99 COMP-3.          
                           20  VAG-FRST-A-S       PIC S9(3)V99 COMP-3.          
                           20  VAG-FRST-ADMIN-FEE PIC S9(3)V99 COMP-3.          
                       15  VAG-RENEWAL.                                         
                           20  VAG-REN-LIFE       PIC S9(3)V99 COMP-3.          
                           20  VAG-REN-LTD        PIC S9(3)V99 COMP-3.          
                           20  VAG-REN-A-S        PIC S9(3)V99 COMP-3.          
                           20  VAG-REN-ADMIN-FEE  PIC S9(3)V99 COMP-3.          
                       15  VAG-SCALE              PIC X(3).                     
                       15  VAG-LTD-SCALE          PIC X(3).                     
                       15  VAG-FLAT-RATE          PIC S9(3)V99 COMP-3.          
                       15  VAG-LTD-FLAT-RATE      PIC S9(3)V99 COMP-3.          
                       15  VAG-POINT              PIC X.                        
                                                                                
      *****************************************************************         
      *         TERMINATION INFORMATION                               *         
      *****************************************************************         
           03  VTM-TERMINATIONS.                                                
               05  VTM-TERM-HISTORY OCCURS 5 TIMES.                             
DATE1              10  VTM-EFFECTIVE-DATE       PIC X(8).                       
DATE1              10  VTM-PROCESSED-DATE       PIC X(8).                       
DATE1              10  VTM-PURGE-DATE           PIC X(8).                       
                   10  VTM-CODE                 PIC XX.                         
                   10  VTM-REINSTATEMENT.                                       
DATE1                  15  VTM-REIN-DATE        PIC X(8).                       
                       15  VTM-REIN-CODE        PIC X(2).                       
                                                                                
      *****************************************************************         
      *        BILLING AND TAX HISTORY INFORMATION                    *         
      *****************************************************************         
           03  VBI-BILLING-INFORMATION.                                         
               05  VBI-MOST-OUTSTANDING.                                        
DATE1              10  VBI-DUE-DATE             PIC X(8).                       
                   10  VBI-BILL.                                                
                       15  VBI-LIFE             PIC S9(7)V99 COMP-3.            
                       15  VBI-LTD              PIC S9(7)V99 COMP-3.            
                       15  VBI-A-S              PIC S9(7)V99 COMP-3.            
                       15  VBI-ADMIN-FEE        PIC S9(7)V99 COMP-3.            
                   10  VBI-POSITION             PIC S9(3)  COMP-3.              
                   10  VBI-TAX.                                                 
TIMES4                 15  VBI-TAX-CNT          PIC 9(4) COMP.                  
TIMES4                 15  VBI-TAX-ENTRY  OCCURS 13 TIMES.                      
                           20  VBI-TAX-CODE     PIC X(2).                       
                           20  VBI-TAX-AMT      PIC S9(7)V99.                   
               05  VBI-HISTORY-CNT              PIC 9(4) COMP.                  
               05  VBI-HISTORY-INFO OCCURS 25 TIMES.                            
DATE1              10  VBI-HIST-DUE-DATE        PIC X(8).                       
DATE1              10  VBI-HIST-PREPARED-DATE   PIC X(8).                       
                   10  VBI-PREM-DUE             PIC S9(7)V99.                   
                   10  VBI-CERT-HOLDERS         PIC S9(7).                      
                   10  VBI-HIST-ADMIN-FEE       PIC S9(7)V99 COMP-3.            
TIMES2             10  VBI-NO-COV-LINES         PIC 9(4) COMP.                  
TIMES2             10  VBI-STATS-BY-COVERAGE OCCURS 10 TIMES.                   
                       15  VBI-COV-CODE         PIC X(3).                       
                       15  VBI-AMT-BILLED       PIC S9(7)V99 COMP-3.            
                       15  VBI-NO-LIVES         PIC S9(5) COMP-3.               
                       15  VBI-VOL              PIC 9(9)  COMP-3.               
                   10  VBI-TAX-HISTORY.                                         
TIMES6                 15  VBI-HIST-TAX-CNT     PIC 9(4) COMP.                  
TIMES6                 15  VBI-HIST-TAX-ENTRY OCCURS 13 TIMES.                  
                           20  VBI-HIST-TAX-CODE  PIC X(2).                     
                           20  VBI-HIST-TAX-AMT   PIC S9(7)V99 COMP-3.          
                                                                                
      *****************************************************************         
      *        COMMISSION INFORMATION                                 *         
      *****************************************************************         
           03  VCS-COMMISSION-INFORMATION.                                      
DATE1          05  VCS-COMM-PROCESSED-DATE          PIC X(8).                   
DATE1          05  VCS-COMM-TERM-LASTBILL-DATE      PIC X(8).                   
DATE1          05  VCS-ORPHAN-TERM-PROCESS-DT       PIC X(8).                   
               05  VCS-COMM-FILLER                  PIC X(54).                  
