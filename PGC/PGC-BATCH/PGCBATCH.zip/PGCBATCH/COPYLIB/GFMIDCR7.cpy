       01  GI-FM-CERT-REQUEST.                                                  
      *************************************************************             
      *                                                           *             
      *            FM ID CERT REQUEST CARD - D71                  *             
      *                                                           *             
      *********************************************************** *             
      *          HISTORY....                                      *             
      *       CREATED BY GFMWRIDL, GFMDIDLI                       *             
      *       USED    BY                                          *             
      *                                                           *             
      *       REC TYPE     '3'                                    *             
      *       REC LENGTH   342                                    *             
      *                                                           *             
      *       GIPSY RELEASE # 1      DEC/89                       *             
      *                                                           *             
      *       MOVE PRODUCT-CODE AND GROUP-OFFICE                  *             
      *       TO THE END OF THE RECORD SO THAT THE                *             
      *       ID CERTS WILL BE IN GROUP/ACCT ORDER                *             
      *                             M BURTON                      *             
      *                                                           *             
      *       FEB 90     ADDED FILLER OF SIX AFTER GI-FM-FORM     *             
      *                  TO CORRECT THE PROD PROBLEM OF THE       *             
      *                  STAFF PLAN GROUP'S WALLET ID'S COMING    *             
      *                  THROUGH THE REGULAR STREAM               *             
      *       IF THIS FILLER IS REMOVED 'GFMSEQIO' MUST BE        *             
      *       MODIFIED                          M BURTON          *             
      *                                                           *             
      *       SEP/91 M PRANGE                                     *             
      *            - REMOVED BENEFICIARY NAME FROM WALLET-IDS     *             
      *                                                           *             
      *************************************************************             
                                                                                
           05  GI-FM-REC-LENGTH    VALUE +342 COMP   PIC S9(4).                 
           05  FILLER              VALUE LOW-VALUES  PIC XX.                    
           05  GI-FM-RECORD-TYPE   VALUE '3'         PIC X.                     
           05  GI-FM-FORM                            PIC X.                     
           05  FILLER              VALUE SPACES      PIC X(6).                  
GNE        05  GI-FM-GROUP               COMP-3      PIC S9(7).                 
           05  GI-FM-ACCOUNT                         PIC XXX.                   
           05  GI-FM-DIVISION            COMP-3      PIC S9(3).                 
           05  GI-FM-ORDER                           PIC X.                     
           05  GI-FM-NAME-CERT.                                                 
               10  GI-FM-NAME1                       PIC X(29).                 
               10  GI-FM-CERT1           COMP-3      PIC S9(9).                 
           05  GI-FM-CERT-NAME     REDEFINES GI-FM-NAME-CERT.                   
               10  GI-FM-CERT2           COMP-3      PIC S9(9).                 
               10  GI-FM-NAME2                       PIC X(29).                 
           05  GI-FM-FILLER                          PIC X(32).                 
           05  GI-FM-EFFECTIVE-DATE.                                            
               10  GI-FM-EFFECTIVE-YEAR  COMP-3      PIC S9(3).                 
               10  GI-FM-EFFECTIVE-DAY   COMP-3      PIC S9(3).                 
           05  GI-FM-CLASS                           PIC XX.                    
           05  GI-FM-S-F                             PIC X.                     
           05  GI-FM-COVERAGE-DATA.                                             
               10  GI-FM-NUM-CODES       COMP-3      PIC S9(3).                 
               10  GI-FM-COV-DATA        OCCURS 20 TIMES.                       
                   15  GI-FM-COV-CODE    COMP-3      PIC S9(3).                 
                   15  GI-FM-VOLUME      COMP-3      PIC S9(7).                 
                   15  GI-FM-SELECTION-IND           PIC XX.                    
                   15  GI-FM-PREMIUM     COMP-3      PIC S9(5)V99.              
           05  GI-FM-PRODUCT                         PIC X.                     
           05  GI-FM-GRP-OFF                         PIC X(5).                  
