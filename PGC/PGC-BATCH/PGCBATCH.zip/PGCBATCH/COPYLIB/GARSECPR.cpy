      **************************************************************            
      *   COPY BOOK TO REDIFINE GAESECSP.                                       
      **************************************************************            
              10 GBSECPAR REDEFINES GAESECSP.                                   
                  15 GBSECPAR-RESPONSE                PIC X.                    
                  15 GBSECPAR-CLAIM-TYPE              PIC XX.                   
                    88 GBSECPAR-VALID-CLAIM-TYPE VALUE 'LD'                     
                                                       'WI'                     
                                                       'HC'                     
                                                       'DE'                     
                                                       'TL'.                    
                  15 GBSECPAR-AMOUNT                  PIC S9(7)V99.             
                  15 GBSECPAR-RESOURCE-KEY            PIC X(8).                 
                  15 FILLER                           PIC X(180).               
