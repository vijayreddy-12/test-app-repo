      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE PREM-DUE-YEAR OF GC-TACCUM TO                                   
               PREM-DUE-YEAR OF GWCORACCUM                                      
           MOVE PREM-DUE-DAY OF GC-TACCUM TO                                    
               PREM-DUE-DAY OF GWCORACCUM                                       
           MOVE PREM-AMT-PAID OF GC-TACCUM TO                                   
               PREM-AMT-PAID OF GWCORACCUM                                      
           MOVE COMM-AMT-EARNED OF GC-TACCUM TO                                 
               COMM-AMT-EARNED OF GWCORACCUM                                    
           MOVE SALES-CREDITS-AMT-EARNED OF GC-TACCUM TO                        
               SALES-CREDITS-AMT-EARNED OF GWCORACCUM.                          
