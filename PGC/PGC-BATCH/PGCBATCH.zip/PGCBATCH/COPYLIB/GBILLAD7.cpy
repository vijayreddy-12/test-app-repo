       01  GBA-BILL-ADJ-RECORD.                                                 
      *************************************************************             
      *                                                           *             
      *               GIPSY BILLING ADJUSTMENT RECORD             *             
      *                                                           *             
      *                                                           *             
      *********************************************************** *             
      *          HISTORY....                                      *             
      *********************************************************** *             
      *                                                           *             
      *       CREATED BY  GFMNBILL                                *             
      *       USED    BY  GCHECKAJ                                *             
      *                   GPRBILLS                                *             
      *                                                           *             
      *       REC TYPE     '2'                                    *             
      *       REC LENGTH   556                                    *             
      *                                                           *             
      *************************************************************             
           05  GBA-RECORD-LENGTH   COMP VALUE +556     PIC S9(4).       00008000
           05  FILLER              VALUE LOW-VALUES    PIC XX.          00009000
           05  GBA-RECORD-TYPE            VALUE '2'    PIC X.           00010000
           05  GBA-PRODUCT                             PIC X.           00010100
           05  GBA-GROUP-OFFICE                        PIC X(5).        00011000
GNE        05  GBA-GROUP                  COMP-3       PIC S9(7).       00012000
           05  GBA-ACCOUNT                             PIC X(3).        00013000
           05  GBA-DIVISION               COMP-3       PIC S9(3).       00013100
           05  GBA-ORDER                               PIC X.           00014000
           05  GBA-NAME-CERT.                                           00015000
               10  GBA-NAME-1                          PIC X(25).       00016001
               10  GBA-CERT-1             COMP-3       PIC S9(9).       00017000
           05  GBA-CERT-NAME REDEFINES GBA-NAME-CERT.                   00018000
               10  GBA-CERT-2             COMP-3       PIC S9(9).       00019000
               10  GBA-NAME-2                          PIC X(25).       00020001
           05  GBA-DETAIL-IDENT           VALUE 'T'    PIC X.           00021000
           05  GBA-EFFECTIVE-DATE.                                      00022000
               10  GBA-EFF-YEAR           COMP-3       PIC S9(3).       00023000
               10  GBA-EFF-DAY            COMP-3       PIC S9(3).       00024000
           05  GBA-ADJ-MODE                            PIC XX.          00025000
           05  GBA-TOTAL-PREMIUM          COMP-3       PIC S9(7)V99.    00026000
           05  GBA-NUM-COV-CODES          COMP-3       PIC S9(3).       00027000
           05  GBA-COVERAGE-DATA OCCURS 38 TIMES.                       00028000
               10  GBA-COV-CODE           COMP-3       PIC S9(3).       00029000
               10  GBA-VOLUME             COMP-3       PIC S9(7).       00030000
               10  GBA-SEL-IND                         PIC XX.          00031000
               10  GBA-PREM-ADJ-AMOUNT    COMP-3       PIC S9(8)V999.   00032000
