       01  GTELENOS.                                                            
      ******************************************************************        
      *  THE SERVICE-OFFICES MUST BE IN NUMERICAL SEQUENCE IN TABLE             
      *  LAST TABLE ENTRY IS DEFAULT.                                           
      *                                                                         
      *  AUG/90 M PRANGE.                                                       
      *       - CHANGES MADE TO TOLL FREE NUMBERS.                              
      *  APR/91 M PRANGE.                                                       
      *       - ADD 16 NEW ENTRIES. INCREASED "CITY" FROM 18 TO 24.             
      *  APR/93 I.BUCKNELL                                                      
      *       - CHANGES MADE TO TOLL FREE NUMBERS.                              
      *  Nov/93 D. Maja                                                         
      *       - Changed some area codes from 416 to 905 and removed             
      *       - obsolete entries (request 1523).                                
      *  Nov/94 B. Beaubien                                                     
      *       - remove local phone numbers form table                           
      *  Jan/95 Z. Perisic                                                      
      *       - Halifax phone change (request 1892)                             
      *  Apr/95 Z. Perisic                                                      
      *       - Add new gfo 15170 Toronto Mt. Pleasant                          
      *  Aug/95 Z. Perisic                                                      
      *       - add phone no to existing one CH.Req 1944                        
      *  Dec/95 A. Nikelski                                                     
      *       - add phone numbers for new branches 11800, 11810, 11820,         
      *         and 11830                                                       
nal   *  Jun/96 A. Ma                                                           
nal   *       - add phone numbers for converted NAL customers (GIPSY            
nal   *         group number 21000-29999) claim office 99999                    
nal   *         (issue 0056)                                                    
      *  Oct/99 B. Beaubien     ISAM task log 8952                              
      *       - remove obsolete local phone number 519-747-5484                 
      *  nov/01 C. Arsene       ISAM task log 20363                             
      *       - remove obsolete local phone number for Ottawa & Montreal        
      *  Aug/02 C. Arsene       GBSS task log 23785                             
      *       - Standardize all 1-800 #'s on Gipsy Head Office Bills            
      *         to 1-800-268-6195.                                              
      * Feb/05-C Arsene - GBSS TASK 37699 - TOLL FREE ENGLISH OR FRENCH         
      *          CLAIM OFFICE = 99999 AND GFO = 99999 IF FRENCH /               
      *          CLAIM OFFICE = 99999 AND GFO = ***** IF ENGLISH                
      ******************************************************************        
           05  FILLER                    PIC X(11)     VALUE                    
               '00548 15020'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00548 15040'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00548 *****'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00549 10490'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-445-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00549 *****'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-445-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00550 *****'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10380'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10400'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10420'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10430'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10450'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10470'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10480'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10510'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10520'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10570'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10680'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10690'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10850'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 10870'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 11800'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 11810'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 11820'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 11830'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15020'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15040'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15100'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15170'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15360'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15420'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15430'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15470'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15490'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15500'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15550'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15570'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '00558 15750'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-445-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
nal            '99999 99999'.                                                   
nal        05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-445-2727                         '.        
nal        05  FILLER                    PIC X(11)     VALUE                    
nal            '99999 *****'.                                                   
nal        05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
           05  FILLER                    PIC X(11)     VALUE                    
               '***** *****'.                                                   
           05  FILLER                    PIC X(54)     VALUE                    
               '               1-866-318-2727                         '.        
       01  TELEPHONE-TABLE REDEFINES GTELENOS.                                  
nal        05  TELEPHONE-ENTRY OCCURS 40 TIMES.                                 
               10  TELEPHONE-CLMS-OFF              PIC 9(5).                    
               10  FILLER                          PIC X(1).                    
               10  TELEPHONE-GFO                   PIC 9(5).                    
               10  TELEPHONE-LOCAL                 PIC X(14).                   
               10  FILLER                          PIC X(1).                    
               10  TELEPHONE-TOLL-FREE             PIC X(14).                   
               10  FILLER                          PIC X(1).                    
               10  TELEPHONE-CITY                  PIC X(24).                   
