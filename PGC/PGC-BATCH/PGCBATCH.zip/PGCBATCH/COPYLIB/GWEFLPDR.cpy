      *****************************************************************         
      *                     EFT PAD REQUEST                           *         
      *                                                               *         
      * FILENAME:      GWEFLPDR                                       *         
      * DATE CREATED:  SEPTEMBER 8, 1999                              *         
      * DESCRIPTION :  THIS DESCRIBES THE LINKAGE SECTION TO REQUEST  *         
      *                AN ENTRY FOR THE EFT SYSTEM.                   *         
      *                ITS FIRST IMPLEMENTATION WILL REQUEST A PAD FOR*         
      *                PREMIUM PAYMENT FOR GISPY BILLING (IN GPRBILLS,*         
      *                WHICH IS CALLED FROM GPRINTAL)                 *         
      *                                                               *         
      *-HISTORY-----------------------------------------------------  *         
      *  SEQ  DATE       DESIGNER   DESCRIPTION                                 
      *  001  SEP 1999   JEFF YEE   CREATED                                     
      *****************************************************************         
          05 REQ-KEY.                                                           
             10 REQ-RECORD-TYPE.                                                
                15 REQ-SOURCE                    PIC X(08).                     
                15 REQ-FUNCTION                  PIC X(08).                     
                15 REQ-PROD-LINE                 PIC X(08).                     
                15 REQ-ADMIN-TYPE                PIC X(02).                     
             10 REQ-KEY-TYPE                     PIC X(04).                     
                88 REQ-GROUP-ACCOUNT-KEY                   VALUE 'GRPA'.        
                88 REQ-GROUP-CERT-KEY                      VALUE 'GRPC'.        
                88 REQ-PROVIDER-KEY                        VALUE 'PROV'.        
             10 REQ-KEY-DATA                     PIC X(20).                     
          05 REQ-DATA-IN.                                                       
             10 REQ-EFF-DATE-IN                  PIC 9(08).                     
             10 REQ-AMOUNT                       PIC S9(07)V99.                 
             10 REQ-REASON-CODE                  PIC X(01).                     
                88 REQ-UPDATE                              VALUE 'U'.           
                88 REQ-INQUIRY                             VALUE 'I'.           
                88 REQ-AUDIT-ONLY                          VALUE 'A'.           
                88 REQ-DONE                                VALUE 'D'.           
             10 REQ-ENTRY-ID                     PIC X(09).                     
             10 REQ-MAINTAINER-ID                PIC X(08).                     
          05 REQ-DATA-OUT.                                                      
             10 REQ-EFF-DATE-OUT                 PIC 9(08).                     
             10 REQ-BATCH-ID                     PIC X(06).                     
             10 REQ-STATUS                       PIC X(01).                     
                88 REQ-PAD-NOT-FOUND                      VALUE 'N'.            
                88 REQ-PAD-TERMINATED                     VALUE 'T'.            
                88 REQ-PAD-IN-EFFECT                      VALUE 'E'.            
                88 REQ-PAD-IN-FUTURE                      VALUE 'F'.            
                88 REQ-PAD-COMPLETED                      VALUE 'C'.            
                88 REQ-PAD-SUSPENDED                      VALUE 'S'.            
                88 REQ-PAD-LOGIC-ABORTED                  VALUE 'A'.            
