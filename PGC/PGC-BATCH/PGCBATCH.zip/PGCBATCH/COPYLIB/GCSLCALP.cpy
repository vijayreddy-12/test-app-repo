       01  GCSL-CALC-PARMS.                                                     
      ******************************************************************        
      *    PARAMETERS FOR GCSLDATS (COMMISSION SCALE TABLES ACCESS)             
      ******************************************************************        
           05  GCSL-BASE-PREMIUM          PIC S9(7)V99 COMP-3.                  
           05  GCSL-CURR-PREMIUM          PIC S9(7)V99 COMP-3.                  
           05  GCSL-COMMISSION            PIC S9(7)V99 COMP-3.                  
      *                                                                         
           05  GCSL-CALC-RETURN-AREA.                                           
               10  GCSL-CALC-RET-CODE     PIC X(1).                             
                   88  GCSL-CALC-RET-SUCCESS        VALUE '0'.                  
                   88  GCSL-CALC-RET-FAILURE        VALUE '1'.                  
