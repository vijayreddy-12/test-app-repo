      *****************************************************************         
      * GROUP BENEFIT SYSTEM STAFF PLAN GROUP NUMBERS         TABLE 005         
      *                                                                         
      *       IF ENTRIES ARE ADDED/DELETED IN THE TABLE-LIST AREA,              
      *       PLEASE ENSURE THAT THE OCCURS CLAUSE IN THE TABLE-ENTRY           
      *       AREA IS ADJUSTED CORRECTLY.                                       
      *                                                                         
      *                                                                         
      * JAN/2013 C MUNCAN - UPDATED LIST TO CONTAIN ALL STAFF PLAN              
      *                     NUMBERS THAT ARE IN BUSINESS LIST FROM              
      *                     TASK LOG # 183553 AND COPYBOOK XC4CFRET             
      *                   - RECOMPILE THESE PROGRAMS TO PICK UP CHANGES         
      *                     MTABLE   (CIIB/LNKB) - GLHNEW                       
      *                     GAESTAFP (CIIB/LNKU) - GLHNEW                       
      *                                                                         
      *****************************************************************         
           05  MSTAFPLN-TABLE-ID       PIC X(3)  VALUE '005'.                   
           05  MSTAFPLN-KEY-LENGTH     PIC S9(4) COMP VALUE +7.                 
           05  MSTAFPLN-RETURN-LENGTH  PIC S9(4) COMP VALUE ZERO.               
                                                                                
           05  MSTAFPLN-TABLE-LIST.                                             
               10  FILLER              PIC X(7) VALUE '0000018'.                
               10  FILLER              PIC X(7) VALUE '0000030'.                
               10  FILLER              PIC X(7) VALUE '0001403'.                
               10  FILLER              PIC X(7) VALUE '0001404'.                
               10  FILLER              PIC X(7) VALUE '0001405'.                
               10  FILLER              PIC X(7) VALUE '0007800'.                
               10  FILLER              PIC X(7) VALUE '0037741'.                
               10  FILLER              PIC X(7) VALUE '0037901'.                
               10  FILLER              PIC X(7) VALUE '0038607'.                
               10  FILLER              PIC X(7) VALUE '0048023'.                
               10  FILLER              PIC X(7) VALUE '0048024'.                
               10  FILLER              PIC X(7) VALUE '0048025'.                
               10  FILLER              PIC X(7) VALUE '0048026'.                
               10  FILLER              PIC X(7) VALUE '0074130'.                
               10  FILLER              PIC X(7) VALUE '0084580'.                
               10  FILLER              PIC X(7) VALUE '0084581'.                
               10  FILLER              PIC X(7) VALUE '0090539'.                
               10  FILLER              PIC X(7) VALUE '0091300'.                
               10  FILLER              PIC X(7) VALUE '0094050'.                
               10  FILLER              PIC X(7) VALUE '0094051'.                
               10  FILLER              PIC X(7) VALUE '0094520'.                
               10  FILLER              PIC X(7) VALUE '0095050'.                
               10  FILLER              PIC X(7) VALUE '0095499'.                
               10  FILLER              PIC X(7) VALUE '0095541'.                
               10  FILLER              PIC X(7) VALUE '0095542'.                
               10  FILLER              PIC X(7) VALUE '0096275'.                
               10  FILLER              PIC X(7) VALUE '0097481'.                
               10  FILLER              PIC X(7) VALUE '0097486'.                
               10  FILLER              PIC X(7) VALUE '0097487'.                
               10  FILLER              PIC X(7) VALUE '0098491'.                
               10  FILLER              PIC X(7) VALUE '0098492'.                
               10  FILLER              PIC X(7) VALUE '0098667'.                
               10  FILLER              PIC X(7) VALUE '0099496'.                
               10  FILLER              PIC X(7) VALUE '0099497'.                
               10  FILLER              PIC X(7) VALUE '0901585'.                
                                                                                
           05  MSTAFPLN-TABLE     REDEFINES MSTAFPLN-TABLE-LIST.                
               10  MSTAFPLN-TABLE-ENTRY OCCURS 35 TIMES                         
                                       INDEXED BY MSTAFPLN-IDX.                 
                   15  MSTAFPLN-GROUP  PIC X(7).                                
