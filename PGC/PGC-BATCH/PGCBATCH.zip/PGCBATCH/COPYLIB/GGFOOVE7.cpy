           03  GGO-OVERDUE.                                                     
      *****************************************************************         
      *     GIPSY GFO OVER DUE RECORD                                 *         
      *                                                               *         
      *       CREATED BY INTM5                                        *         
      *       USED    BY GPRSOARR                                     *         
      *                                                               *         
      *       REC TYPE     'H'                                        *         
      *       REC LENGTH   77                                         *         
      *                                                               *         
      *****************************************************************         
      *                        HISTORY                                *         
      *****************************************************************         
      *                                                               *         
      * SEP/89 MARCUS DRURY -  GPSY-REL-1                             *         
      *                        ADD REPORT-TYPE                        *         
      *                                       1) HEAD OFFICE          *         
      *                                       2) PRODUCER             *         
      *                                       3) GROUP OFFICE (GFO)   *         
      *                        ADD PROD-CODE                          *         
      *                        ADD SRT-FIELDS                         *         
      *                        REC LENGTH  WAS 57.                    *         
      *                                                               *         
      * JAN/90 MARCUS DRURY -  CHANGE SORT OF H.O. REPORT TO INCLUDE  *         
      *                        PROD-CD. ALPHA'S       WILL BE AN 'A'  *         
      *                                 OMEGA'S + CSP WILL BE A  ' '  *         
      *****************************************************************         
               05  OVR-LENGTH                 PIC S9(4) COMP SYNC.              
               05  FILLER                     PIC XX.                           
               05  OVR-RECTYPE                PIC X.                            
               05  OVR-REPORT                 PIC X.                            
               05  OVR-REPORT-NUMBER          PIC 9.                            
               05  OVR-SRT-FIELDS.                                              
                   10  OVR-SRT-HEAD-OFF.                                        
                       15  OVR-SRT-HO-PCODE   PIC X.                            
GNE                    15  OVR-SRT-HO-GROUP   PIC 9(7).                         
                       15  OVR-SRT-HO-ACCT    PIC XXX.                          
                       15  OVR-SRT-HO-FILLER1 PIC X(4).                         
                       15  OVR-SRT-HO-FILLER2 PIC X(6).                         
                   10  OVR-SRT-BRANCH    REDEFINES OVR-SRT-HEAD-OFF.            
                       15  OVR-SRT-BR-GFO-BR  PIC X(5).                         
                       15  OVR-SRT-BR-BKR-AGT PIC 9(6).                         
GNE                    15  OVR-SRT-BR-GROUP   PIC 9(7).                         
                       15  OVR-SRT-BR-ACCT    PIC XXX.                          
                   10  OVR-SRT-PRODUCER  REDEFINES OVR-SRT-BRANCH.              
                       15  OVR-SRT-PD-GFO     PIC X(5).                         
GNE                    15  OVR-SRT-PD-GROUP   PIC 9(7).                         
                       15  OVR-SRT-PD-ACCT    PIC XXX.                          
                       15  OVR-SRT-PD-AGENT   PIC 9(6).                         
               05  OVR-GRPOFF                 PIC X(5).                         
GNE            05  OVR-GROUP                  PIC S9(7) COMP-3.                 
               05  OVR-ACCT                   PIC X(3).                         
               05  OVR-IDENT                  PIC X(5).                         
               05  OVR-TYPE                   PIC X.                            
               05  OVR-ARRSIND                PIC X.                            
               05  OVR-PREM30                 PIC S9(7)V99 COMP-3.              
               05  OVR-PREM60                 PIC S9(7)V99 COMP-3.              
               05  OVR-PREM90                 PIC S9(7)V99 COMP-3.              
               05  OVR-PREM120                PIC S9(7)V99 COMP-3.              
               05  OVR-PREMTOTL               PIC S9(9)V99 COMP-3.              
               05  OVR-ACCSTAT                PIC XX.                           
               05  OVR-EFFDATE                PIC X(4).                         
               05  OVR-ARRSTAT                PIC X.                            
               05  OVR-PCODE                  PIC X.                            
