      *****************************************************************         
      *                    BANK INFO COPYBOOK                         *         
      *                                                               *         
      * FILENAME    :  GWEFRBNK                                       *         
      * DATE CREATED:  SEPTEMBER 8, 1999                              *         
      * DESCRIPTION :  THIS DESCRIBES THE BANK INFORMATION REQUIRED   *         
      *                                                               *         
      *-HISTORY-----------------------------------------------------  *         
      *  SEQ  DATE       DESIGNER   DESCRIPTION                                 
      *  001  SEP 1999   JEFF YEE   CREATED                                     
      *****************************************************************         
          05 BNK-INFO-KEY.                                                      
             10 BNK-PRE-KEY.                                                    
                  15 BNK-RECORD-TYPE.                                           
                     20 BNK-SOURCE               PIC X(08).                     
                     20 BNK-FUNCTION             PIC X(08).                     
                     20 BNK-PROD-LINE            PIC X(08).                     
                        88 BNK-ALL-PRODUCTS            VALUE '********'.        
                     20 BNK-ADMIN-TYPE           PIC X(02).                     
                        88 BNK-ALL-ADMIN-TYPES             VALUE '**'.          
                  15 BNK-KEY-TYPE                PIC X(04).                     
                     88 BNK-GROUP-ACCOUNT-KEY              VALUE 'GRPA'.        
                     88 BNK-GROUP-CERT-KEY                 VALUE 'GRPC'.        
                     88 BNK-PROVIDER-KEY                   VALUE 'PROV'.        
                  15 BNK-KEY-DATA                PIC X(20).                     
             10 BNK-EFF-DATE-COMPLEMENT          PIC 9(08).                     
             10 BNK-MNT-DATE-COMPLEMENT          PIC 9(08).                     
             10 BNK-MNT-SEQ-COMPLEMENT           PIC 9(02).                     
          05 BNK-GENERAL-DATA.                                                  
             10 BNK-STATUS                       PIC X(01).                     
                88 BNK-VALID-STATUS   VALUE 'A' 'S' 'T' 'V'.                    
                88 BNK-ACTIVE                              VALUE 'A'.           
                88 BNK-SUSPENDED                           VALUE 'S'.           
                88 BNK-TERMINATED                          VALUE 'T'.           
                88 BNK-VOID                                VALUE 'V'.           
                88 BNK-PURGED                              VALUE 'P'.           
             10 BNK-REASON-CODE                  PIC X(03).                     
                88 BNK-VALID-REASONS VALUE 'FPA' 'VPA' 'OTH'.                   
                88 BNK-FORCED-PARTICIPATION                VALUE 'FPA'.         
                88 BNK-VOLUNT-PARTICIPATION                VALUE 'VPA'.         
                88 BNK-OTHER                               VALUE 'OTH'.         
             10 BNK-COMMENT-TEXT                 PIC X(80).                     
             10 BNK-MAINTAINER-ID                PIC X(08).                     
             10 BNK-APPROVER-ID                  PIC X(08).                     
             10 BNK-CUSTOMER-NAME                PIC X(22).                     
             10 BNK-LAG-UNIT                     PIC X(01).                     
                88 BNK-LAG-CALENDER                        VALUE 'C'.           
                88 BNK-LAG-MONTH-DAY                       VALUE 'M'.           
                88 BNK-LAG-NONE                            VALUE 'N'.           
             10 BNK-LAG-PERIOD                   PIC 9(02).                     
             10 BNK-AUTO-FEEDBACK-IND            PIC X(01).                     
                88 BNK-NO-FEEDBACK                         VALUE ' '.           
                88 BNK-LETTER                              VALUE 'L'.           
          05 BNK-BANK-DATA.                                                     
             10 BNK-DEBIT.                                                      
                15 BNK-DR-CURRENCY               PIC X(03).                     
                15 BNK-DR-ACCOUNT-TYPE           PIC X(02).                     
                   88 BNK-DR-BANK-ACCOUNT                  VALUE 'BA'.          
                   88 BNK-DR-CREDIT-CARD                   VALUE 'CC'.          
                   88 BNK-DR-INVESTMENT-ACCOUNT            VALUE 'IA'.          
                15 BNK-DR-ACCOUNT                PIC X(30).                     
                15 FILLER REDEFINES BNK-DR-ACCOUNT.                             
                   20 BNK-DR-BANK-NUM            PIC 9(04).                     
                   20 BNK-DR-TRANSIT-NUM         PIC 9(05).                     
                   20 BNK-DR-ACCOUNT-NUM         PIC X(18).                     
             10 BNK-CREDIT.                                                     
                15 BNK-CR-CURRENCY               PIC X(03).                     
                15 BNK-CR-ACCOUNT-TYPE           PIC X(02).                     
                   88 BNK-CR-BANK-ACCOUNT                  VALUE 'BA'.          
                   88 BNK-CR-CREDIT-CARD                   VALUE 'CC'.          
                   88 BNK-CR-INVESTMENT-ACCOUNT            VALUE 'IA'.          
                15 BNK-CR-ACCOUNT                PIC X(30).                     
                15 FILLER REDEFINES BNK-CR-ACCOUNT.                             
                   20 BNK-CR-BANK-NUM            PIC 9(04).                     
                   20 BNK-CR-TRANSIT-NUM         PIC 9(05).                     
                   20 BNK-CR-ACCOUNT-NUM         PIC X(18).                     
             10 BNK-RETURN.                                                     
                15 BNK-RT-CURRENCY               PIC X(03).                     
                15 BNK-RT-BANK-NUM               PIC 9(04).                     
                15 BNK-RT-TRANSIT-NUM            PIC X(05).                     
                15 BNK-RT-ACCOUNT-NUM            PIC X(18).                     
          05 FILLER                              PIC X(50).                     
