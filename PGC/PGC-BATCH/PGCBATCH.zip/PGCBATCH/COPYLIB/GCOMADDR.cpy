      *************************************************************             
      *      COMMISSIONS ADVISOR ADDRESS EXTRACT RECORD           *             
      *           USED TO UPDATE THE ADVISOR TABLE                *             
      *               RECORD LENGTH 137                           *             
      *************************************************************             
         05  AEXTRACT-HEADER.                                                   
             10  AEXTRACT-HDR-RECTYPE         PIC X(1).                         
             10  AEXTRACT-FILE-TYPE           PIC X(10).                        
             10  AEXTRACT-SYSTEM-IDENTIFIER   PIC X(10).                        
             10  AEXTRACT-SEQUENCE-NUMBER     PIC 9(7).                         
             10  AEXTRACT-TOTAL-DETAIL-REC    PIC 9(9).                         
             10  AEXTRACT-DATE                PIC X(8).                         
             10  FILLER                       PIC X(92).                        
         05  AEXTRACT-DETAIL REDEFINES AEXTRACT-HEADER.                         
             10  AEXTRACT-DET-RECTYPE         PIC X(1).                         
             10  AEXTRACT-ADVISOR-NUMBER      PIC 9(6).                         
             10  AEXTRACT-ADVISOR-NAME1       PIC X(25).                        
             10  AEXTRACT-ADVISOR-NAME2       PIC X(25).                        
             10  AEXTRACT-ADDR1               PIC X(25).                        
             10  AEXTRACT-ADDR2               PIC X(25).                        
             10  AEXTRACT-ADDR3               PIC X(30).                        
