      *=================================================================        
      *=                                                              =*        
      *=  PRODUCER PROFILE VSAM FILE RECORD LAYOUT                    =*00000120
      *=   COPIED FROM 'PEN.PSR.PROD.COPYLIB'                         =*        
      *=================================================================        
                                                                                
       01  SRPRODVS-RECORD.                                                     
           05  PRODVS-KEY.                                                      
               10  PRODVS-AGENT-CODE               PIC X(06).                   
           05  PRODVS-ACTIVE-CODE                  PIC X(06).                   
           05  PRODVS-FIRST-NAME                   PIC X(15).                   
           05  PRODVS-LAST-NAME                    PIC X(20).                   
           05  PRODVS-CORPORATE-NAME               PIC X(60).                   
           05  PRODVS-CONT-NAME     OCCURS  2  TIMES.                           
               10  PRODVS-CONTACT-NAME             PIC X(60).                   
           05  PRODVS-STREET-ADDR   OCCURS  2  TIMES.                           
               10  PRODVS-STREET-ADDRESS           PIC X(30).                   
           05  PRODVS-CITY                         PIC X(25).                   
           05  PRODVS-PROVINCE                     PIC X(02).                   
           05  PRODVS-POSTAL-CODE                  PIC X(07).                   
           05  PRODVS-TELEPHONE     OCCURS  2  TIMES.                           
               10  PRODVS-BUSINESS-PHONE           PIC X(14).                   
               10  PRODVS-EXTENSION                PIC X(04).                   
           05  PRODVS-FAX-NUMBER                   PIC X(14).                   
           05  PRODVS-PRODUCER-STATUS              PIC X(01).                   
           05  PRODVS-PRODUCER-LOCATION            PIC X(01).                   
           05  PRODVS-STATMENT-FLAG                PIC X(01).                   
           05  PRODVS-PRE-RENEWAL-FLAG             PIC X(01).                   
           05  PRODVS-LANG-CODE                    PIC X(01).                   
               88  PRODVS-LANG-ENGLISH             VALUE 'E'.                   
               88  PRODVS-LANG-FRENCH              VALUE 'F'.                   
           05  PRODVS-CONTRACT-CLASS               PIC 9(02).                   
           05  PRODVS-BRANCH-CODE                  PIC 9(05).                   
+N27ZM     05  PRODVS-TELE-RESTRICT                PIC X(01).                   
 N27ZM     05  FILLER                              PIC X(16).                   
