       01  FIELD-OFFICE-FILE.                                           00010000
           10  FOF-BRANCH-NUMBER             PIC X(5).                  00020000
           10  FOF-COUNTRY                   PIC X(1).                  00030000
           10  FOF-RESIDENCE                 PIC X(2).                  00040000
           10  FOF-CURRENCY.                                            00050000
               15  FOF-CURRENCY-1            PIC X(1)                   00060000
                                 OCCURS 10 TIMES.                       00070000
           10  FOF-SV-BRANCH                 PIC X(5).                  00080000
           10  FOF-STATUS                    PIC X(1).                  00090000
           10  FOF-TYPE                      PIC X(1).                  00100000
           10  FOF-MANAGER-CODE              PIC S9(7) COMP-3.          00110000
           10  FOF-LAST-TRANS-DATE.                                     00120000
                 15  FOF-LT-YEAR             PIC S9(3) COMP-3.          00130000
                 15  FOF-LT-DAY              PIC S9(3) COMP-3.          00140000
           10  FOF-SALES-AREA                PIC X(3).                  00150000
           10  FOF-MLI-MANAGER-CODE   COMP-3 PIC S9(3).                 00160000
           10  FILLER                        PIC X(19).                 00170000
           10  FOF-BRANCH-NAME               PIC X(25).                 00180000
           10  FOF-ADDRESS-LINES.                                       00190000
               15  FOF-ADDRESS-ONE           PIC X(25).                 00200000
               15  FOF-ADDRESS-TWO           PIC X(25).                 00210000
               15  FOF-ADDRESS-THREE         PIC X(25).                 00220000
               15  FOF-ADDRESS-FOUR          PIC X(25).                 00230000
               15  FOF-ADDRESS-FIVE          PIC X(25).                 00240000
           10  FILLER   REDEFINES FOF-ADDRESS-LINES.                    00250000
               15  FOF-ADDRESS               PIC X(25)                  00260000
                               OCCURS 5 TIMES.                          00270000
           10  FOF-IND-BRANCH  COMP          PIC S9(2).                 00280000
           10  FOF-IND-BRANCH-R                                         00290000
                               REDEFINES FOF-IND-BRANCH                 00300000
                                             PIC X(2).                  00310000
           10  FOF-GROUP-BRANCH COMP         PIC S9(2).                 00320000
           10  FOF-GROUP-BRANCH-R                                       00330000
                               REDEFINES FOF-GROUP-BRANCH               00340000
                                             PIC X(2).                  00350000
           10  FOF-SEC-BRANCH.                                          00360000
                 15  FOF-SBRANCH             PIC XXXXX                  00370001
                               OCCURS 80 TIMES.                         00380001
