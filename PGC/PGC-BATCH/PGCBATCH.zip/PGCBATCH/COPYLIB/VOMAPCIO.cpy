      *================================================================         
      *    COPYBOOK: VOMAPCIO                                                   
      *    PROTOCOL FOR VO MAPPER                                               
      *----------------------------------------------------------------         
      *    APR/05 F. DAZA - CREATED                                             
      *----------------------------------------------------------------         
           05  VOMAPPER-INPUT.                                                  
               10  VOMI-VO-RECORD             PIC X(11400).                     
               10  VOMI-LR-NAME               PIC X(16).                        
                   88  VOMI-LR-GIPSY-EXP-C    VALUE 'GIPSY EXP CICS'.           
                   88  VOMI-LR-GIPSY-EXP-I    VALUE 'GIPSY EXP IDMS'.           
                   88  VOMI-LR-GIPSY-EXP      VALUE 'GIPSY EXPANDED'.           
                   88  VOMI-LR-VO-RAW         VALUE 'VO RAW DATA   '.           
                   88  VOMI-LR-DEFAULT        VALUE 'DEFAULT       '.           
           05  VOMAPPER-OUTPUT.                                                 
               10  VOMO-MAPPED-RECORD.                                          
                   15  VOMO-MAPPED-FILLER     PIC X(04).                        
                   15  VOMO-MAPPED-DATA       PIC X(15696).                     
               10  VOMO-RET-CODE              PIC X(02).                        
                   88  VOMO-RET-OK            VALUE '00'.                       
                   88  VOMO-RET-WARNING       VALUE '01' THRU '09'.             
                   88  VOMO-RET-ERROR         VALUE '10' THRU '89'.             
                   88  VOMO-RET-SEVERE-ERROR  VALUE '90' THRU '99'.             
               10  VOMO-RET-MESSAGE           PIC X(80).                        
