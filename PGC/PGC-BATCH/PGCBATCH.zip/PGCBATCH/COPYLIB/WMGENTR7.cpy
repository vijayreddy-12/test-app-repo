       01  WMGENTR.                                                             
      *****************************************************************         
      *     WORK GIPSY MASTER GENERAL INFORMATION TRAILER             *         
      *                                                               *         
      *       CREATED BY  ....MANY....                                *         
      *       USED    BY  ....MANY....                                *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *   ====> PART OF GIPSY-REL-1                                   *         
      *                                                               *         
      *    I BUCKNELL SEP/89   (CHANGES)                              *         
      *                                                               *         
      *          CHANGE THE GGIBENEFIT-COMB TO THE COMPRESSED FORMAT  *         
      *             THIS AREA IS CREATED VIA AN ASM PGM GUTBITS6      *         
      *                                                               *         
      *    DEC/89 M. PRANGE                                           *         
      *           - ADDED FIELDS W-GGIADMIN-AREA & W-GGILIVES-RANGE   *         
      *           - RENAME W-GGIFOGL-SOURCE   TO W-GGIFOGL-ADMIN-AREA *         
      *                    W-GGIFOGL-CONSTANT TO W-GGIFOGL-LIVES-RANGE*         
      *                                                               *         
      *    SEP/91 M. PRANGE                                           *         
      *           - ADDED W-GGIMAIL-INSTRUCTION                       *         
      *****************************************************************         
               05  W-GGIRECORD-LENGTH    COMP SYNC PIC S9(4).                   
               05  FILLER                          PIC XX.                      
GNE            05  W-GGIGROUP-NUMBER     COMP-3    PIC S9(7).                   
               05  W-GGIACCOUNT                    PIC XXX.                     
               05  W-GGIMASTER-IDENT               PIC X.                       
               05  W-GGIIDENTITY                   PIC X(5).                    
               05  W-GGIBRANCH                     PIC X(5).                    
               05  W-GGIGROUP-REP                  PIC 9(5).                    
               05  W-GGIGROUP-REP2                 PIC 9(5).                    
               05  W-GGIGROUP-OFFICE               PIC X(5).                    
               05  W-GGISHARING-OFFICE             PIC X(5).                    
               05  W-GGICLAIMS-OFFICE              PIC X(5).                    
               05  W-GGICOUNTRY                    PIC X.                       
               05  W-GGICURRENCY                   PIC X.                       
               05  W-GGIRESIDENCE                  PIC XX.                      
               05  W-GGILANGUAGE                   PIC X.                       
               05  W-GGIPRODUCT-CODE               PIC X.                       
               05  W-GGIPOLICY-ACCT                PIC X.                       
               05  W-GGIACCT-TYPE.                                              
                   07  W-GGITYPE                   PIC X.                       
                   07  W-GGIUW-TYPE                PIC X.                       
               05  W-GGICOVERAGE-CODE              PIC X.                       
               05  W-GGIBENEFIT-SEL                PIC X.                       
               05  W-GGISTD-IND-CLASS-CODE  COMP-3 PIC S9(5).                   
               05  W-GGICONTRIBUTION               PIC X.                       
               05  W-GGIBENEFIT-LINK               PIC X.                       
               05  W-GGITAX                        PIC X.                       
               05  W-GGIWITHHOLDING                PIC X.                       
               05  W-GGIEMPLOYEE-LIST              PIC X.                       
               05  W-GGIHANDLING-CODE              PIC X.                       
               05  W-GGIARREARS-IND                PIC X.                       
               05  W-GGIARREARS-COUNTER  COMP-3    PIC S999.                    
               05  W-GGIARREARS-STATUS             PIC X.                       
               05  W-GGIREDUCTION-AGES   COMP-3.                                
                   07  W-GGIRED-AGE-LIFE           PIC S999.                    
                   07  W-GGIRED-AGE-LTD            PIC S999.                    
                   07  W-GGIRED-AGE-AD-D           PIC S999.                    
                   07  W-GGIRED-AGE-MEDICAL        PIC S999.                    
                   07  W-GGIRED-AGE-DENTAL         PIC S999.                    
                   07  W-GGIRED-AGE-WEEK-INDEM     PIC S999.                    
               05  W-GGITERMINATION-AGES     COMP-3.                            
                   07  W-GGITERM-AGE-LIFE          PIC S999.                    
                   07  W-GGITERM-AGE-LTD           PIC S999.                    
                   07  W-GGITERM-AGE-AD-D          PIC S999.                    
                   07  W-GGITERM-WAIT-PERIOD-LTD   PIC S999.                    
                   07  W-GGITERM-AGE-MEDICAL       PIC S999.                    
                   07  W-GGITERM-AGE-DENTAL        PIC S999.                    
                   07  W-GGITERM-AGE-WEEK-INDEM    PIC S999.                    
               05  W-GGISTEP-DOWN                  PIC X.                       
               05  W-GGICHANGE-DATE                PIC X.                       
               05  W-GGIACCOUNT-STATUS             PIC XX.                      
               05  W-GGIDATES            COMP-3.                                
                   07  W-GGINEXT-ANNIVERSARY.                                   
                       09  W-GGINEXT-ANNIV-YEAR    PIC S9(3).                   
                       09  W-GGINEXT-ANNIV-DAY     PIC S9(3).                   
                   07  W-GGICLAIMS-SUSPENDED.                                   
                       09  W-GGICLAIM-SUSP-YEAR    PIC S9(3).                   
                       09  W-GGICLAIM-SUSP-DAY     PIC S9(3).                   
                   07  W-GGICONTRACT-ISSUE.                                     
                       09  W-GGIISSUE-YEAR         PIC S9(3).                   
                       09  W-GGIISSUE-DAY          PIC S9(3).                   
                   07  W-GGI-ACCT-EFFECTIVE.                                    
                       09  W-GGI-ACCT-EFF-YEAR     PIC S9(3).                   
                       09  W-GGI-ACCT-EFF-DAY      PIC S9(3).                   
                   07  W-GGIPAID-TO-DATE.                                       
                       09  W-GGIPAID-TO-YEAR       PIC S9(3).                   
                       09  W-GGIPAID-TO-DAY        PIC S9(3).                   
                   07  W-GGILAST-CHANGE-DATE.                                   
                       09  W-GGILAST-CHANGE-YEAR   PIC S9(3).                   
                       09  W-GGILAST-CHANGE-DAY    PIC S9(3).                   
                   07  W-GGILAST-ACCOUNTING-DATE.                               
                       09  W-GGILAST-ACCTG-YEAR    PIC S9(3).                   
                       09  W-GGILAST-ACCTG-DAY     PIC S9(3).                   
               05  W-GGIPOL-ARREARS        COMP-3  PIC S9(2).                   
               05  W-GGICASHFLOW-LST-POL-YR  COMP-3  PIC S9(3).                 
               05  W-GGICASHFLOW-CURR-POL-YR COMP-3  PIC S9(3).                 
               05  W-GGIBILL-STAT-FORMAT.                                       
                   07  W-GGIBILLING-AGENT          PIC 9(6).                    
                   07  W-GGIBILLING-TYPE           PIC XX.                      
                   07  W-GGILISTING-CERTIFICATE    PIC X.                       
                   07  W-GGILISTING-ORDER          PIC X.                       
                   07  W-GGISTAT-OPTION.                                        
                       09  W-GGILIST-BILLING       PIC X.                       
                       09  W-GGIEMP-CHANGE-LIST    PIC X.                       
                       09  W-GGIWORK-SHEET         PIC X.                       
                       09  W-GGISUMMARY            PIC X.                       
               05  W-GGIBENEFIT-COMB.                                           
      *****************************************************************         
      * GIPSY RELEASE #1, SEPTEMBER 1989                                        
      *   TITLES AREA BELOW CHANGED TO INCREASE NUMBER OF COLUMNS FROM          
      *   7 TO 9.  'GGITITLES-AREA' IS *COMPRESSED* DATA CONSISTING OF          
      *   6-BIT CHARACTER CODES.  TRANSLATION TO/FROM AN EXPANSION              
      *   WORK AREA (COPYBOOK 'GGI6BITX') IS ACCOMPLISHED USING RTN             
      *   'GUTBITS6'.  (I. BUCKNELL)                                            
      *****************************************************************         
                   07  W-GGINUM-COV-CODES-LIST.                                 
                       09  W-GGINUM-COV-CODES OCCURS 9 TIMES                    
                                   COMP-3          PIC S9(3).                   
                   07  W-GGITITLES-AREA            PIC X(129).                  
                   07  W-GGICOV-CODES-LIST.                                     
                       09  W-GGICOV-CODES OCCURS 36 TIMES                       
                                   COMP-3          PIC S9(3).                   
               05  W-GGIBASIC-ADMIN-FEE OCCURS 4 TIMES.                         
                   07  W-GGIBASIC-ADMIN-AMT        PIC S9(7)V99 COMP-3.         
                   07  W-GGIBASIC-ADMIN-IND        PIC X.                       
                   07  W-GGIBASIC-ADMIN-REASON     PIC XX.                      
               05  W-GGIOTHER-ADMIN-FEE.                                        
                   07  W-GGIOTHER-ADMIN-AMT        PIC S9(7)V99 COMP-3.         
                   07  W-GGIOTHER-ADMIN-IND        PIC X.                       
                   07  W-GGIOTHER-ADMIN-REASON     PIC X(25).                   
               05  W-GGIPRACTICE-BILLING.                                       
                   07  W-GGIPRAC-BILL-REQ-TYPE     PIC X.                       
                   07  W-GGIPRAC-BILL-FROM-DATE    COMP-3.                      
                       09  W-GGIPRAC-BILL-FROM-YR  PIC S9(3).                   
                       09  W-GGIPRAC-BILL-FROM-DAY PIC S9(3).                   
                   07  W-GGIPRAC-BILL-TO-DATE      COMP-3.                      
                       09  W-GGIPRAC-BILL-TO-YR    PIC S9(3).                   
                       09  W-GGIPRAC-BILL-TO-DAY   PIC S9(3).                   
                   07  W-GGIPRAC-BILL-REQUESTOR    PIC X(15).                   
               05  W-GGICLAIMS-INFORMATION.                                     
                   10  W-GGICARRYOVER-IND.                                      
                       15  W-GGICARRYOVER-HC         PIC X.                     
                       15  W-GGICARRYOVER-DE         PIC X.                     
                   10  W-GGIELIGIBLE-BENEFITS        PIC X.                     
                   10  W-GGIPRIVATE-DUTY-NURSING     PIC 99.                    
                   10  W-GGIDENTAL-PLAN-IND          PIC X.                     
                   10  W-GGILAB-FEES                 PIC XX.                    
               05  W-GGIFOGL-CODE OCCURS 6 TIMES.                               
                   10  W-GGIFOGL-BENEFIT             PIC X(4).                  
                   10  W-GGIFOGL-REINS               PIC X(2).                  
                   10  W-GGIFOGL-GRP-TYPE            PIC X.                     
                   10  W-GGIFOGL-AGT-TYPE            PIC X.                     
                   10  W-GGIFOGL-ADMIN-AREA          PIC X.                     
                   10  W-GGIFOGL-LIVES-RANGE         PIC X.                     
               05  W-GGIFUND-TYPE OCCURS 6 TIMES     PIC X.                     
               05  W-GGIBILLING-OVERIDE.                                        
                   10 W-GGIBILLING-OVERIDE-IND       PIC X.                     
                   10 W-GGIBILLING-OR-TELE-NUM       PIC X(11).                 
               05  W-GGIPH-EOB                       PIC X.                     
               05  W-GGIADMIN-AREA                   PIC X(1).                  
               05  W-GGILIVES-RANGE                  PIC X(1).                  
               05  W-GGIMAIL-INSTRUCTION             PIC X(1).                  
               05  W-GGIUNDEFINED                    PIC X(14).                 
