       01  WMRINTR.                                                     00001000
               05  W-GRITRIDENT                    PIC XXX.             00002000
               05  W-GRILENGTH           COMP-3    PIC S9(5).           00003000
               05  W-GRIEFFECTIVE-DATE   COMP-3.                        00004000
                   07  W-GRIEFFECTIVE-YEAR         PIC S9(3).           00005000
                   07  W-GRIEFFECTIVE-DAY          PIC S9(3).           00006000
               05  W-GRITYPE                       PIC X.               00007000
               05  W-GRICOMPANY                    PIC X.               00008000
               05  W-GRIBENEFIT                    PIC X.               00009000
               05  W-GRISHARE-QUOTA-PER  COMP-3    PIC S9(3)V99.        00010000
               05  W-GRIRETENTION-MAX    COMP-3    PIC S9(7).           00011000
               05  W-GRICO-INSURANCE-PER COMP-3    PIC S9(3)V99.        00012000
               05  W-GRIREINSURANCE-RATE COMP-3.                        00013000
                   07  W-GRIRATE-SINGLE            PIC S9(3)V99.        00014000
                   07  W-GRIRATE-FAMILY            PIC S9(3)V99.        00015000
               05  W-GRISELF-BILL-PER    COMP-3    PIC S9(3)V99.        00016000
               05  W-GRIMAJ-MED-MAX      COMP-3    PIC S9(9).           00017000
               05  W-GRIEXEMPT-CLASSES             PIC X(10).           00018000
               05  W-GRIUNDEFINED                  PIC X(20).           00019000
