      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORADVPSM                          11/02/10  07:16  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORADVPSM.                                                         
           05  GROUP-ADV-KEY.                                                   
               10  NEXT-RENEW-DATE.                                             
                   15  NEXT-RENEW-YEAR        COMP-3    PIC S9(3).              
                   15  NEXT-RENEW-DAY         COMP-3    PIC S9(3).              
               10  COMM-SCALE                           PIC X(3).               
           05  PSM-PREM-ADV                   COMP-3    PIC S9(9)V99.           
