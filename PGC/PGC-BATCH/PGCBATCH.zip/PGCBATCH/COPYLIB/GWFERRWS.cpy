       01  GWFERRWS.                                                            
           05  WS-ABEND-CODE                        PIC X(4).                   
           05  WS-SQLCODE   REDEFINES WS-ABEND-CODE PIC ---9.                   
           05  WS-CICS-CODE REDEFINES WS-ABEND-CODE PIC 9(4).                   
           05  WS-VSAM-CODE REDEFINES WS-ABEND-CODE PIC X(4).                   
