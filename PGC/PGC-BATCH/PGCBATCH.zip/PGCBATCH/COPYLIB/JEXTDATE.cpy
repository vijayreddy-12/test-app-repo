      ******************************************************************        
      *    ACCOUNTING SYSTEM INTERFACE DATE RECORD.                             
      *    KEEP THIS RECORD SIZE THE SAME AS IN 'JEXTRACT'                      
      *                                                                         
      *    MAX RECORD LENGTH OF THE FILE = VB-23472 (INCLUDES RDW)              
      *                                                                         
SUSP05*    THIS RECORD LAYOUT HAS LENGTH = 584 = (4 + 580).                     
      ******************************************************************        
SUSP05*                                                                         
SUSP05*    MAY/06 F. DAZA.                                                      
SUSP05*         - INCREASED RECORD LENGTH BY 50 BYTES TO MATCH JEXTRACT         
SUSP05*           (SUSPENSE IMPROVEMENT POJECT)                                 
      ******************************************************************        
           05  JEXTDATE-RECTYPE                        PIC X(1).                
               88  JEXTDATE-RECTYPE-DATE                   VALUE 'D'.           
           05  FILLER                                  PIC X(1).                
           05  JEXTDATE-FEEDER-SYSTEM                  PIC X(1).                
           05  FILLER                                  PIC X(1).                
           05  JEXTDATE-RUN-NUMBER                     PIC 9(2).                
           05  FILLER                                  PIC X(1).                
           05  JEXTDATE-RUN-LOW-DATE.                                           
               10  JEXTDATE-RUN-LOW-YYYY               PIC 9(4).                
               10  JEXTDATE-RUN-LOW-MM                 PIC 9(2).                
               10  JEXTDATE-RUN-LOW-DD                 PIC 9(2).                
           05  FILLER                                  PIC X(1).                
           05  JEXTDATE-RUN-HIGH-DATE.                                          
               10  JEXTDATE-RUN-HIGH-YYYY              PIC 9(4).                
               10  JEXTDATE-RUN-HIGH-MM                PIC 9(2).                
               10  JEXTDATE-RUN-HIGH-DD                PIC 9(2).                
SUSP05     05  FILLER                                  PIC X(556).              
