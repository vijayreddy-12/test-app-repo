      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  VOCOMEXT          -  VO COMMISSION EXTRACT FEED                        
      *                                                                         
      *  HUB:  VO AND MAINFRAME COMMISSIONS FEED MERGE                          
      ******************************************************                    
       01  VO-COMM-EXTRACT.                                                     
           05  VOCOMX-GROUP-NUMBER               PIC X(7).                      
           05  VOCOMX-GR-ACCOUNT                 PIC X(3).                      
           05  VOCOMX-REC-TYPE                   PIC X.                         
           05  VOCOMX-VERSION-NUMBER.                                           
               10  VOCOMX-FILE-NUMBER            PIC 9(9).                      
               10  VOCOMX-RECORD-COUNT           PIC 9(9).                      
               10  FILLER                        PIC X(71).                     
           05  VOCOMX-DATE-RECORD REDEFINES VOCOMX-VERSION-NUMBER.              
               10  VOCOMX-FILE-DATE.                                            
                   15  VOCOMX-FILE-YYYY          PIC 9(4).                      
                   15  VOCOMX-FILE-MM            PIC 99.                        
                   15  VOCOMX-FILE-DD            PIC 99.                        
               10  FILLER                        PIC X(81).                     
           05  VOCOMX-COMMISSION     REDEFINES VOCOMX-DATE-RECORD.              
               10  VOCOMX-COMM-COMP-EFFDATE.                                    
                   15  VOCOMX-COMM-COMP-EFFYYYY  PIC 9(4).                      
                   15  VOCOMX-COMM-COMP-EFFMM    PIC 99.                        
                   15  VOCOMX-COMM-COMP-EFFDD    PIC 99.                        
               10  VOCOMX-COMM-AGENT-NUMBER      PIC 9(6).                      
               10  VOCOMX-COMM-GFO-NUMBER        PIC 9(5).                      
               10  VOCOMX-COMM-COMP-TYPE         PIC X.                         
               10  VOCOMX-COMM-COMP-DISP         PIC X.                         
               10  VOCOMX-COMM-GROUP-REP         PIC 9(5).                      
               10  VOCOMX-COMM-COMP-PROCDATE.                                   
                   15  VOCOMX-COMM-COMP-PROCYYYY PIC 9(4).                      
                   15  VOCOMX-COMM-COMP-PROCMM   PIC 99.                        
                   15  VOCOMX-COMM-COMP-PROCDD   PIC 99.                        
               10  VOCOMX-COMM-COV-TYPE          PIC X.                         
               10  VOCOMX-COMM-COMP-AMT          PIC 9(9).99.                   
               10  VOCOMX-COMM-COMP-AMT-SGN      PIC X.                         
               10  VOCOMX-COMM-COMP-REASON       PIC X.                         
               10  VOCOMX-COMM-RECON-IND         PIC X.                         
               10  VOCOMX-COMM-AGENT-SPLIT       PIC 9(3).99.                   
               10  VOCOMX-COMM-AGENT-SPLIT-SGN   PIC X.                         
               10  VOCOMX-COMM-PREM-AMT          PIC 9(9).99.                   
               10  VOCOMX-COMM-PREM-AMT-SGN      PIC X.                         
               10  VOCOMX-COMM-NEXT-RECONDATE.                                  
                   15  VOCOMX-COMM-NEXT-RECONYYYY                               
                                                 PIC 9(4).                      
                   15  VOCOMX-COMM-NEXT-RECONMM  PIC 99.                        
                   15  VOCOMX-COMM-NEXT-RECONDD  PIC 99.                        
               10  VOCOMX-COMM-ACCT-EFFDATE.                                    
                   15  VOCOMX-COMM-ACCT-EFFYYYY  PIC 9(4).                      
                   15  VOCOMX-COMM-ACCT-EFFMM    PIC 99.                        
                   15  VOCOMX-COMM-ACCT-EFFDD    PIC 99.                        
               10  VOCOMX-COMM-NEXT-RECON-IND    PIC X.                         
               10  FILLER                        PIC XX.                        
           05  VOCOMX-PREMIUM        REDEFINES VOCOMX-COMMISSION.               
               10  VOCOMX-PREM-PREM-DUEDATE.                                    
                   15  VOCOMX-PREM-PREM-DUEYYYY  PIC 9(4).                      
                   15  VOCOMX-PREM-PREM-DUEMM    PIC 99.                        
                   15  VOCOMX-PREM-PREM-DUEDD    PIC 99.                        
               10  VOCOMX-PREM-PREM-AMT          PIC 9(9).99.                   
               10  VOCOMX-PREM-PREM-AMT-SGN      PIC X.                         
               10  VOCOMX-PREM-COV-TYPE          PIC X.                         
               10  VOCOMX-PREM-NEXT-RECONDATE.                                  
                   15  VOCOMX-PREM-NEXT-RECONYYYY                               
                                                 PIC 9(4).                      
                   15  VOCOMX-PREM-NEXT-RECONMM  PIC 99.                        
                   15  VOCOMX-PREM-NEXT-RECONDD  PIC 99.                        
               10  VOCOMX-PREM-ACCT-EFFDATE.                                    
                   15  VOCOMX-PREM-ACCT-EFFYYYY  PIC 9(4).                      
                   15  VOCOMX-PREM-ACCT-EFFMM    PIC 99.                        
                   15  VOCOMX-PREM-ACCT-EFFDD    PIC 99.                        
               10  VOCOMX-PREM-NEXT-RECON-IND    PIC X.                         
               10  FILLER                        PIC X(50).                     
