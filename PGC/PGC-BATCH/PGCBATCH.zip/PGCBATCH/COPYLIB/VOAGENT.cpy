      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  VOAGENT   -  VO AGENT FILE                                             
      *  SVOAGENT  -  SORTED VO AGENT FILE                                      
      *                                                                         
      *  HUB:  AGENT FILE AND PAY BASIS DATA EXTRACT/MERGE                      
      ******************************************************                    
                                                                                
       01  VO-AGENT-RECORD.                                                     
           05  VOAGT-IDENTIFIER.                                                
               10  VOAGT-FILE-TYPE          PIC X(8) VALUE 'VOAGENT'.           
               10  VOAGT-RECORD-TYPE        PIC X.                              
                   88  VOAGT-HDR-REC        VALUE '0'.                          
                   88  VOAGT-DTL-REC        VALUE '1'.                          
           05  VOAGT-HDR.                                                       
               10  VOAGT-FILE-NUMBER        PIC 9(7).                           
               10  VOAGT-REC-COUNT          PIC 9(9).                           
               10  FILLER                   PIC X(33).                          
           05  VOAGT-DTL REDEFINES VOAGT-HDR.                                   
               10  VOAGT-AGENT-CODE         PIC 9(7).                           
               10  VOAGT-PAY-BASIS-EFF-DATE PIC X(8).                           
               10  VOAGT-PAY-BASIS-IND      PIC X.                              
               10  VOAGT-BRANCH-CODE        PIC X(5).                           
               10  VOAGT-AGENT-NAME         PIC X(25).                          
               10  VOAGT-CONTRACT-CLASS     PIC 9(3).                           
           05  FILLER                       PIC X(22).                          
                                                                                
