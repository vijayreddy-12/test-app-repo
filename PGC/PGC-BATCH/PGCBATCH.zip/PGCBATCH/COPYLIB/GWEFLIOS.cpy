      *****************************************************************         
      *                I/O PARMS  SUBROUTINE MODULE                   *         
      *                                                               *         
      * FILENAME    :  GWEFLIOS                                       *         
      * DATE CREATED:  SEPTEMBER 8, 1999                              *         
      * DESCRIPTION :  DESCRIBES THE DATA REQUIRED (LINKAGE SECTION)  *         
      *            SENT BETWEEN EFT I/O MAINLINES AND I/O SUBROUTINES *         
      *-HISTORY-----------------------------------------------------  *         
      *  SEQ  DATE       DESIGNER   DESCRIPTION                                 
      *  001  SEP 1999   JEFF YEE   CREATED                                     
      *****************************************************************         
           05 EFT-IOS-KEY-TYPE                      PIC X(05).                  
              88 EFT-IOS-MAIN          VALUE 'MAIN '.                           
              88 EFT-IOS-BY-STAT-TYPE  VALUE 'STATT'.                           
              88 EFT-IOS-BY-STAT-ID    VALUE 'STATI'.                           
           05 EFT-IOS-VERB                          PIC X(02).                  
              88 EFT-IOS-START-BROWSE  VALUE 'SB'.                              
              88 EFT-IOS-READ-NEXT     VALUE 'RN'.                              
              88 EFT-IOS-READ-PREV     VALUE 'RP'.                              
              88 EFT-IOS-READ-GTEQ     VALUE 'RG'.                              
              88 EFT-IOS-READ-EQUAL    VALUE 'RE'.                              
              88 EFT-IOS-END-BROWSE    VALUE 'EB'.                              
              88 EFT-IOS-WRITE         VALUE 'WR'.                              
              88 EFT-IOS-UPDATE        VALUE 'UD'.                              
              88 EFT-IOS-DELETE        VALUE 'D '.                              
              88 EFT-IOS-CLOSE         VALUE 'C '.                              
           05 EFT-IOS-ERROR-DATA.                                               
              10 EFT-IOS-STATUS                     PIC X(02).                  
                 88 EFT-IOS-STATUS-OK      VALUE 'OK'.                          
                 88 EFT-IOS-ERROR   VALUE 'ER' 'NF' 'NS' 'WR' 'DR' 'SB'         
                                          'RN' 'RP' 'EB' 'LE' 'R ' 'RW'         
                                            .                                   
                 88 EFT-IOS-NOT-FOUND       VALUE 'NF'.                         
                 88 EFT-IOS-NOT-SUPPORTED   VALUE 'NS'.                         
                 88 EFT-IOS-WRITE-FAILED    VALUE 'WR'.                         
                 88 EFT-IOS-DUP-RECORD      VALUE 'DR'.                         
                 88 EFT-IOS-STARTBR-FAILED  VALUE 'SB'.                         
                 88 EFT-IOS-READNEXT-FAILED VALUE 'RN'.                         
                 88 EFT-IOS-READPREV-FAILED VALUE 'RP'.                         
                 88 EFT-IOS-ENDBR-FAILED    VALUE 'EB'.                         
                 88 EFT-IOS-LOGIC-ERROR     VALUE 'LE'.                         
                 88 EFT-IOS-READ-FAILED     VALUE 'R '.                         
                 88 EFT-IOS-REWRITE-FAILED  VALUE 'RW'.                         
                 88 EFT-IOS-CLOSE-FAILED    VALUE 'CF'.                         
              10 EFT-IOS-ERROR-TEXT                 PIC X(50).                  
           05 EFT-IOS-RECORD-DATA                   PIC X(500).                 
