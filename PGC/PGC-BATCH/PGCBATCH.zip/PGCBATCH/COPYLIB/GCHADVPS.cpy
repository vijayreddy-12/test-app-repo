      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE NEXT-RENEW-YEAR OF GC-TADVPS TO                                 
               NEXT-RENEW-YEAR OF GWCORADVPSM                                   
           MOVE NEXT-RENEW-DAY OF GC-TADVPS TO                                  
               NEXT-RENEW-DAY OF GWCORADVPSM                                    
           MOVE COMM-SCALE OF GC-TADVPS TO                                      
               COMM-SCALE OF GWCORADVPSM                                        
           MOVE PSM-PREM-ADV OF GC-TADVPS TO                                    
               PSM-PREM-ADV OF GWCORADVPSM.                                     
