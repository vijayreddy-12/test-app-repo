      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           IF PAY-BASIS-EFF-YEAR OF GWCORPAYBASIS  NOT NUMERIC                  
               MOVE ZEROS TO PAY-BASIS-EFF-YEAR OF GC-TPAYB                     
           ELSE                                                                 
               MOVE PAY-BASIS-EFF-YEAR OF GWCORPAYBASIS                         
               TO PAY-BASIS-EFF-YEAR OF GC-TPAYB                                
           END-IF.                                                              
                                                                                
           IF PAY-BASIS-EFF-DAY OF GWCORPAYBASIS  NOT NUMERIC                   
               MOVE ZEROS TO PAY-BASIS-EFF-DAY OF GC-TPAYB                      
           ELSE                                                                 
               MOVE PAY-BASIS-EFF-DAY OF GWCORPAYBASIS                          
               TO PAY-BASIS-EFF-DAY OF GC-TPAYB                                 
           END-IF.                                                              
                                                                                
           MOVE PAY-BASIS-IND OF GWCORPAYBASIS                                  
               TO PAY-BASIS-IND OF GC-TPAYB.                                    
                                                                                
           IF PAY-BASIS-PROC-YEAR OF GWCORPAYBASIS  NOT NUMERIC                 
               MOVE ZEROS TO PAY-BASIS-PROC-YEAR OF GC-TPAYB                    
           ELSE                                                                 
               MOVE PAY-BASIS-PROC-YEAR OF GWCORPAYBASIS                        
               TO PAY-BASIS-PROC-YEAR OF GC-TPAYB                               
           END-IF.                                                              
                                                                                
           IF PAY-BASIS-PROC-DAY OF GWCORPAYBASIS  NOT NUMERIC                  
               MOVE ZEROS TO PAY-BASIS-PROC-DAY OF GC-TPAYB                     
           ELSE                                                                 
               MOVE PAY-BASIS-PROC-DAY OF GWCORPAYBASIS                         
               TO PAY-BASIS-PROC-DAY OF GC-TPAYB                                
           END-IF.                                                              
                                                                                
           IF PAY-BASIS-END-YEAR OF GWCORPAYBASIS  NOT NUMERIC                  
               MOVE ZEROS TO PAY-BASIS-END-YEAR OF GC-TPAYB                     
           ELSE                                                                 
               MOVE PAY-BASIS-END-YEAR OF GWCORPAYBASIS                         
               TO PAY-BASIS-END-YEAR OF GC-TPAYB                                
           END-IF.                                                              
                                                                                
           IF PAY-BASIS-END-DAY OF GWCORPAYBASIS  NOT NUMERIC                   
               MOVE ZEROS TO PAY-BASIS-END-DAY OF GC-TPAYB                      
           ELSE                                                                 
               MOVE PAY-BASIS-END-DAY OF GWCORPAYBASIS                          
               TO PAY-BASIS-END-DAY OF GC-TPAYB                                 
           END-IF.                                                              
                                                                                
