      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORADG-WORK-RECORD                 10/26/10  17:04  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORADG-WORK-RECORD.                                                
           05  GWCOEADG-W-GROUP-ACCOUNT.                                        
               10  GWCOEADG-W-GROUP-NUMBER              PIC X(7).               
               10  GWCOEADG-W-GR-ACCOUNT                PIC X(3).               
           05  GWCOEADG-W-ACCT-EFF-DATE.                                        
               10  GWCOEADG-W-ACCT-EFF-YEAR   COMP-3    PIC S9(3).              
               10  GWCOEADG-W-ACCT-EFF-DAY    COMP-3    PIC S9(3).              
           05  GWCOEADG-W-NEXT-RENEW-DATE.                                      
               10  GWCOEADG-W-NEXT-RENEW-YEAR                                   
                                              COMP-3    PIC S9(3).              
               10  GWCOEADG-W-NEXT-RENEW-DAY  COMP-3    PIC S9(3).              
           05  GWCOEADG-W-ACTION-SWITCH                 PIC X                   
                   VALUE SPACES.                                                
               88  GROUP-ADDED                         VALUE '1'.               
               88  GRACCT-ADDED                        VALUE '2'.               
           05  GWCOEADG-W-LAST-RECON-DATE-EXT           PIC X(7).               
           05  GWCOEADG-W-NEXT-RECON-DATE-EXT           PIC X(7).               
           05  GWCOEADG-W-ACCT-EFF-DATE-EXT             PIC X(7).               
           05  GWCOEADG-W-NEXT-RENEW-DATE-EXT           PIC X(7).               
