      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  PAYBXTR   -  COMMISSIONS PAY BASIS EXTRACT FILE                        
      *  SPAYBXTR  -  SORTED COMMISSIONS PAY BASIS EXTRACT FILE                 
      *                                                                         
      *  HUB:  AGENT FILE AND PAY BASIS DATA EXTRACT/MERGE                      
      ******************************************************                    
                                                                                
       01  PAYBASIS-EXTRACT.                                                    
           05  PBXT-AGENT-CODE         PIC 9(7).                                
           05  PBXT-EFF-DATE.                                                   
               10  PBXT-EFF-YEAR       PIC S9(3) COMP-3.                        
               10  PBXT-EFF-DAY        PIC S9(3) COMP-3.                        
           05  PBXT-PAY-BASIS-IND      PIC X.                                   
           05  FILLER                  PIC X(68).                               
                                                                                
