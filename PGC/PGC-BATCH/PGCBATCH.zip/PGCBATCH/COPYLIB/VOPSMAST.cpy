      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  VOPSMAST  -  VO PSMASTER FILE                                          
      *  (VSAM FILE; KEY IS VOPSM-GROUP-NUMBER)                                 
      *                                                                         
      *  HUB:  PSMASTER ROUTER (VOCOMM VOPSM/PSM)                               
      *                                                                         
      ******************************************************                    
                                                                                
       01  VOPSMASTER-RECORD.                                                   
           05  VOPSM-GROUP-NUMBER       COMP-3  PIC S9(07).                     
           05  VOPSM-POLICY-YEAR        COMP-3  PIC S9(03).                     
           05  VOPSM-NXT-RNEW-DATE.                                             
               10  VOPSM-NXT-RNEW-YEAR  COMP-3  PIC S9(04).                     
               10  VOPSM-NXT-RNEW-MONTH COMP-3  PIC S9(02).                     
               10  VOPSM-NXT-RNEW-DAY   COMP-3  PIC S9(02).                     
           05  VOPSM-COMB-EFF           OCCURS 5.                               
               10  VOPSM-EFF-DATE.                                              
                   15  VOPSM-EFF-YEAR    COMP-3  PIC S9(04).                    
                   15  VOPSM-EFF-MONTH   COMP-3  PIC S9(02).                    
                   15  VOPSM-EFF-DAY     COMP-3  PIC S9(02).                    
               10  VOPSM-COMB-IND                PIC  X(01).                    
