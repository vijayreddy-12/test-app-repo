       01  GBC-BILL-CURR-RECORD.                                                
      *****************************************************************         
      *                                                               *         
      *               GIPSY BILLING CURRENT RECORD                    *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *  NOV/89 M. PRANGE.                                            *         
      *         - ADDED GBC-DETAIL-TERM-DATE                          *         
      *  MAR/90 M. PRANGE.                                            *         
      *         - ADDED GBC-DETAIL-ISSUE-DATE                         *         
      *         - ADDED GBC-DETAIL-REINST-DATE                        *         
      *  JUN/93 M. PRANGE.                                            *         
      *         - ADDED GBC-TAX-CODE                                  *         
      *************************************************************** *         
      *       CREATED BY   GFMNBILL                                   *         
      *       USED    BY   GPRBILLS                                   *         
      *                                                               *         
      *       REC TYPE     '2'                                        *         
      *       REC LENGTH   BASE OF 101.....                           *         
      *                                                               *         
      *****************************************************************         
           05  GBC-RECORD-LENGTH   COMP                PIC S9(4).       00008000
           05  FILLER              VALUE LOW-VALUES    PIC XX.          00009000
           05  GBC-RECORD-TYPE            VALUE '2'    PIC X.           00010000
           05  GBC-PRODUCT                             PIC X.           00010100
           05  GBC-GROUP-OFFICE                        PIC X(5).        00011000
GNE        05  GBC-GROUP                  COMP-3       PIC S9(7).       00012000
           05  GBC-ACCOUNT                             PIC X(3).        00013000
           05  GBC-DIVISION               COMP-3       PIC S9(3).       00013100
           05  GBC-ORDER                               PIC X.           00014000
           05  GBC-NAME-CERT.                                           00015000
               10  GBC-NAME-1                          PIC X(25).       00016001
               10  GBC-CERT-1             COMP-3       PIC S9(9).       00017000
           05  GBC-CERT-NAME REDEFINES GBC-NAME-CERT.                   00018000
               10  GBC-CERT-2             COMP-3       PIC S9(9).       00019000
               10  GBC-NAME-2                          PIC X(25).       00020001
           05  GBC-DETAIL-IDENT           VALUE 'S'    PIC X.           00021000
           05  GBC-CLASS                               PIC XX.          00022000
           05  GBC-TOTAL-PREMIUM          COMP-3       PIC S9(7)V99.    00023000
           05  GBC-TAXABLE-IND                         PIC X.           00024000
           05  GBC-DETAIL-TERM-DATE.                                    00025000
               10  GBC-DETAIL-TERM-YEAR   COMP-3       PIC S9(3).               
               10  GBC-DETAIL-TERM-DAY    COMP-3       PIC S9(3).               
           05  GBC-DETAIL-ISSUE-DATE.                                   00025000
               10  GBC-DETAIL-ISSUE-YEAR  COMP-3       PIC S9(3).               
               10  GBC-DETAIL-ISSUE-DAY   COMP-3       PIC S9(3).               
           05  GBC-DETAIL-REINST-DATE.                                  00025000
               10  GBC-DETAIL-REINST-YEAR COMP-3       PIC S9(3).               
               10  GBC-DETAIL-REINST-DAY  COMP-3       PIC S9(3).               
           05  GBC-TAX-CODE                            PIC X(2).        00025000
GNE        05  GBC-FILLER                              PIC X(6).        00025000
           05  GBC-NUM-COV-CODES          COMP-3       PIC S9(3).       00026000
           05  GBC-COVERAGE-ENTRIES.                                    00027000
             07  GBC-COVERAGE-DATA OCCURS 38 TIMES.                     00028000
               10  GBC-COV-CODE           COMP-3       PIC S9(3).       00029000
               10  GBC-VOLUME             COMP-3       PIC S9(7).       00030000
               10  GBC-SEL-IND                         PIC XX.          00031000
               10  GBC-BILLED-PREMIUM     COMP-3       PIC S9(8)V999.   00032000
