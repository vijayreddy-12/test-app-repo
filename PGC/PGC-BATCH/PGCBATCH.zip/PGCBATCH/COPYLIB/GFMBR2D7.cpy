       01  GFMBILLING-RECORD-2D.                                                
      *****************************************************************         
      *     GIPSY BILLING RECORD 2D                                   *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                                    
      *                                                                         
      *   SEP/89 PRANGE   - INCREASED COLUMNS FROM 7 TO 9                       
      *                     REC LENGTH INCREASES FROM 572 TO 614.               
      *   MAY/89 PRANGE   - ADDED GFM2D-CLAIMS-OFFICE.                          
      *                                                                         
      *************************************************************** *         
      *                                                               *         
      *       CREATED BY  GFMINTM4                                    *         
      *       USED    BY  GPRBILLS                                    *         
      *                                                               *         
      *       REC TYPE     '2'                                        *         
      *       REC LENGTH   614                                        *         
      *                                                               *         
      *****************************************************************         
           05  GFM2D-RECORD-LENGTH         COMP SYNC PIC S9(4).                 
           05  FILLER                                PIC XX.                    
           05  GFM2D-RECORD-TYPE     VALUE '2'       PIC X.                     
           05  GFM2D-PRODUCT                         PIC X.                     
           05  GFM2D-GROUP-OFFICE                    PIC X(5).                  
GNE        05  GFM2D-GROUP-NUMBER          COMP-3    PIC S9(7).                 
           05  GFM2D-ACCOUNT                         PIC XXX.                   
           05  GFM2D-DIVISION              COMP-3    PIC S9(3).                 
           05  GFM2D-ORDER           VALUE 'D'       PIC X.                     
           05  GFM2D-STATEMENT-TYPE                  PIC X.                     
           05  GFM2D-STATEMENT-DATES       COMP-3.                              
               10  GFM2D-FROM-DATE.                                             
                   15  GFM2D-FROM-YEAR               PIC S9(3).                 
                   15  GFM2D-FROM-DAY                PIC S9(3).                 
               10  GFM2D-TO-DATE.                                               
                   15  GFM2D-TO-YEAR                 PIC S9(3).                 
                   15  GFM2D-TO-DAY                  PIC S9(3).                 
               10  GFM2D-PREPARED-DATE.                                         
                   15  GFM2D-PREPARED-YEAR           PIC S9(3).                 
                   15  GFM2D-PREPARED-DAY            PIC S9(3).                 
               10  GFM2D-PREMIUM-DUE-DATE.                                      
                   15  GFM2D-PREMIUM-DUE-YEAR        PIC S9(3).                 
                   15  GFM2D-PREMIUM-DUE-DAY         PIC S9(3).                 
           05  GFM2D-BILLING-NAME-ADDRESS.                                      
               10  GFM2D-BNA                  OCCURS 6 TIMES.                   
                   15  GFM2D-NAME-ADDRESS-LINES      PIC X(30).                 
                   15  GFM2D-NAME-ADDRESS-DELIMITER  PIC X.                     
           05  GFM2D-BILLING-FORMAT.                                            
               10  GFM2D-BILLING-FORMAT-TYPE         PIC XX.                    
               10  GFM2D-BFS-OPTIONS.                                           
                   15  GFM2D-BFSO-LIST-BILLING       PIC X.                     
                   15  GFM2D-BFSO-CHANGE-BILLING     PIC X.                     
           05  GFM2D-BENEFIT-COMBINATIONS.                                      
               10  GFM2D-BC-NO-CODES-LIST.                                      
                   15  GFM2D-BC-NO-OF-CODES OCCURS 9 TIMES                      
                                            COMP-3   PIC S9(3).                 
               10  GFM2D-BC-TITLES-LIST.                                        
                   15  GFM2D-BC-TITLES      OCCURS 9 TIMES.                     
                       20  GFM2D-BC-TITLE-LINE1      PIC X(9).                  
                       20  GFM2D-BC-TITLE-LINE2      PIC X(9).                  
               10  GFM2D-BC-PREM-VOL-LIST.                                      
                   15  GFM2D-BC-PREM-OR-VOL OCCURS 9 TIMES                      
                                                     PIC X.                     
               10  GFM2D-BC-CODES-LIST.                                         
                   15  GFM2D-BC-CODES       OCCURS 36 TIMES                     
                                            COMP-3   PIC S9(3).                 
           05  GFM2D-CURRENCY                        PIC X.                     
           05  GFM2D-GROUP-OFFICE-NAME               PIC X(25).                 
           05  GFM2D-IDENTITY                        PIC X(5).                  
           05  GFM2D-COUNTRY                         PIC X.                     
           05  GFM2D-LANGUAGE                        PIC X.                     
           05  GFM2D-REQUESTOR                       PIC X(15).                 
           05  GFM2D-BRANCH                          PIC X(5).                  
           05  GFM2D-RESIDENCE                       PIC X(2).                  
           05  GFM2D-BILLING-AGENT                   PIC X(6).                  
           05  GFM2D-AGENT-NAME                      PIC X(25).                 
           05  GFM2D-BILLING-NUM-IND                 PIC X(1).                  
           05  GFM2D-BILLING-NUMBER                  PIC 9(11).                 
           05  GFM2D-CLAIMS-OFFICE                   PIC X(5).                  
GNE        05  FILLER                                PIC X(22).                 
