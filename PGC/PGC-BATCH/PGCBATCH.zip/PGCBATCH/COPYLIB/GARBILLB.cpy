      *01  M-F-C-BillMember.                                                    
      *---------------------------------------------------------------*         
      * BILLING MEMBER DATA DEFINITION - (FOR XML USAGE)              *         
      *---------------------------------------------------------------*         
           05  RECORD-TYPE                          PIC X(1).                   
DATE1      05  PROCESS-DATE                         PIC X(8).                   
           05  GROUP-INFORMATION.                                               
               10  POLICY                           PIC X(10).                  
               10  ACCOUNT                          PIC X(3).                   
           05  MEMBER.                                                          
               10  MAILING-DIVISION             PIC X(3).                       
ATTRIB         10  I-D                          PIC X(12).                      
               10  CERTIFICATE                  PIC X(12).                      
               10  MEMBER-NAME                  PIC X(25).                      
               10  CLASS-CODE                   PIC X(2).                       
               10  TOTAL-PREMIUM                PIC S9(7)V99                    
                   SIGN LEADING SEPARATE.                                       
               10  TAX-STATUS.                                                  
ATTRIB             15  TC                       PIC X.                          
               10  TAX-CODE.                                                    
ATTRIB             15  TC                       PIC X(2).                       
DATE1          10  TERM-DATE                    PIC X(8).                       
DATE1          10  ISSUE-DATE                   PIC X(8).                       
DATE1          10  REINST-DATE                  PIC X(8).                       
TIMES3         10  NUM-OF-MEMBER-BENEFITS       PIC 9(3).                       
TIMES3         10  MEMBER-BENEFIT  OCCURS 8 TIMES.                              
ATTRIB             15  COV-CODE                 PIC X(3).                       
                   15  VOLUME                   PIC S9(9)                       
                       SIGN LEADING SEPARATE.                                   
                   15  BILLED-PREMIUM           PIC S9(7)V999                   
                       SIGN LEADING SEPARATE.                                   
                   15  SELECT-IND.                                              
ATTRIB                 20  TC                   PIC X.                          
