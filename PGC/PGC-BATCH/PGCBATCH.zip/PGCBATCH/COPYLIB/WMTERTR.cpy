       01  WMTERTR.                                                     00001000
           03  W-GTMTRIDENT                        PIC XXX.             00002000
           03  W-GTMLENGTH       COMP-3            PIC S9(5).           00003000
           03  W-GTMUNDEFINED                      PIC X(10).           00004000
           03  W-GTMTERMINATION-HISTORY OCCURS 5 TIMES.                 00005000
               05  W-GTMEFFECTIVE-DATE   COMP-3.                        00006000
                   07  W-GTMEFFECTIVE-YEAR         PIC S9(3).           00007000
                   07  W-GTMEFFECTIVE-DAY          PIC S9(3).           00008000
               05  W-GTMPROCESSED-DATE   COMP-3.                        00009000
                   07  W-GTMPROCESSED-YEAR         PIC S9(3).           00010000
                   07  W-GTMPROCESSED-DAY          PIC S9(3).           00011000
               05  W-GTMPURGE-DATE       COMP-3.                        00012000
                   07  W-GTMPURGE-YEAR             PIC S9(3).           00013000
                   07  W-GTMPURGE-DAY              PIC S9(3).           00014000
               05  W-GTMCODE                       PIC XX.              00015000
               05  W-GTMREINSTATEMENT-INFO.                             00016000
                   07  W-GTMREIN-DATE   COMP-3.                         00017000
                       09  W-GTMREIN-YEAR          PIC S9(3).           00018000
                       09  W-GTMREIN-DAY           PIC S9(3).           00019000
                   07  W-GTMREIN-CODE              PIC X(2).            00020000
