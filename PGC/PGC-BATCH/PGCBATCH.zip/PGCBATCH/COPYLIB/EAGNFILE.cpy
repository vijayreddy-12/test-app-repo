       01  AGENT-NAME-FILE.                                                     
           05  AGT-KEY.                                                         
               10  AGT-CODE             COMP-3 PIC S9(7).                       
               10  AGT-ACCOUNT                 PIC X(1).                        
           05  AGT-BRANCH-CODE                 PIC X(5).                        
           05  AGT-CONTRACT-TYPE               PIC X(1).                        
           05  AGT-CONTRACT-STATUS             PIC X(1).                        
           05  AGT-CONTRACT-DATE.                                               
               10  AGT-CONTRACT-YR      COMP-3 PIC S9(3).                       
               10  AGT-CONTRACT-DAY     COMP-3 PIC S9(3).                       
           05  AGT-NAME                        PIC X(25).                       
           05  AGT-LAST-TRANS-DATE.                                             
               10  AGT-LAST-TRANS-YR    COMP-3 PIC S9(3).                       
               10  AGT-LAST-TRANS-DAY   COMP-3 PIC S9(3).                       
           05  AGT-ACTIVE-IND                  PIC X(1).                        
           05  AGT-IND-ANN                     PIC X(1).                        
           05  AGT-GRP-ANN                     PIC X(1).                        
           05  AGT-SIN-SSN-IND                 PIC X(1).                        
           05  AGT-SIN-SSN-IRS          COMP-3 PIC 9(9).                        
           05  AGT-UNIT-CODE            COMP-3 PIC 9(7).                        
           05  AGT-UNIT-ACCOUNT                PIC X(1).                        
           05  AGT-UNIT-TYPE                   PIC X(1).                        
           05  AGT-MLI-INDICATOR               PIC X(1).                        
           05  AGT-MLI-CONTRACT-TYPE    COMP-3 PIC S9(3).                       
           05  AGT-MLI-CONTRACT-CLASS   COMP-3 PIC S9(3).                       
           05  FILLER                          PIC X(1).                        
           05  AGT-LINKED-BR-GFO        COMP-3 PIC S9(5).                       
           05  AGT-LINKED-BR-GFO-CHAR   REDEFINES                               
               AGT-LINKED-BR-GFO               PIC X(3).                        
           05  FILLER                          PIC X(1).                        
