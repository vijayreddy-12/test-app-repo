      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  VOCRFEXT          -  VO COMMISSION RELEASE FEED                        
      *                                                                         
      *  HUB:  VO AND MAINFRAME COMMISSIONS FEED MERGE                          
      ******************************************************                    
       01  VO-RLSE-EXTRACT.                                                     
           05  VORLSE-GROUP-NUMBER               PIC X(7).                      
           05  VORLSE-GR-ACCOUNT                 PIC X(3).                      
           05  VORLSE-REC-TYPE                   PIC X.                         
           05  VORLSE-VERSION-NUMBER.                                           
               10  VORLSE-FILE-NUMBER            PIC 9(9).                      
               10  VORLSE-RECORD-COUNT           PIC 9(9).                      
               10  FILLER                        PIC X(121).                    
           05  VORLSE-COMMISSION     REDEFINES VORLSE-VERSION-NUMBER.           
               10  VORLSE-VLNO                   PIC 9.                         
               10  VORLSE-BRANCH                 PIC 9(5).                      
               10  VORLSE-BRANCH-X REDEFINES VORLSE-BRANCH                      
                                                 PIC X(5).                      
               10  VORLSE-CURRENCY               PIC 9.                         
               10  VORLSE-ACCT-EFFDATE.                                         
                   15  VORLSE-ACCT-EFFCC         PIC 99.                        
                   15  VORLSE-ACCT-EFFYY         PIC 99.                        
                   15  VORLSE-ACCT-EFFMM         PIC 99.                        
                   15  VORLSE-ACCT-EFFDD         PIC 99.                        
               10  VORLSE-BILLING-NAME           PIC X(25).                     
               10  VORLSE-PREMNO                 PIC 9(3).                      
               10  VORLSE-PREM-DUEDATE.                                         
                   15  VORLSE-PREM-DUECC         PIC 99.                        
                   15  VORLSE-PREM-DUEYY         PIC 99.                        
                   15  VORLSE-PREM-DUEMM         PIC 99.                        
                   15  VORLSE-PREM-DUEDD         PIC 99.                        
               10  VORLSE-MAN                    PIC 9(5).                      
               10  VORLSE-SCALE                  PIC X(3).                      
               10  VORLSE-FOGL-CODE              PIC 9(10).                     
               10  VORLSE-AGENT-CODE             PIC 9(6).                      
               10  VORLSE-SHARE                  PIC 9(3).99.                   
               10  VORLSE-SHARE-SGN              PIC X.                         
               10  VORLSE-CODE-1                 PIC 9(3).                      
               10  VORLSE-CMAMT-1                PIC 9(9).99.                   
               10  VORLSE-CMAMT-1-SGN            PIC X.                         
               10  VORLSE-CODE-2                 PIC 9(3).                      
               10  VORLSE-CMAMT-2                PIC 9(9).99.                   
               10  VORLSE-CMAMT-2-SGN            PIC X.                         
               10  VORLSE-CODE-3                 PIC 9(3).                      
               10  VORLSE-CPAMT-3                PIC 9(6).9(5).                 
               10  VORLSE-CPAMT-3-SGN            PIC X.                         
               10  FILLER                        PIC X(9).                      
