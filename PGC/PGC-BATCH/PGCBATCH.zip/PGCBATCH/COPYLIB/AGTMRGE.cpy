      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  AGTMRGE   -  MERGED AGENT PAY BASIS FILE                               
      *  SAGTMRGE  -  SORTED MERGED AGENT PAY BASIS FILE                        
      *                                                                         
      *  HUB:  AGENT FILE AND PAY BASIS DATA EXTRACT/MERGE                      
      ******************************************************                    
                                                                                
       01  AGENT-MERGE-RECORD.                                                  
           05  AGTMRG-DATA.                                                     
               10  AGTMRG-AGENT-CODE         PIC 9(7).                          
               10  AGTMRG-PAY-BASIS-EFF-DATE PIC X(8).                          
               10  AGTMRG-PAY-BASIS-IND      PIC X.                             
               10  AGTMRG-BRANCH-CODE        PIC X(5).                          
               10  AGTMRG-AGENT-NAME         PIC X(25).                         
               10  AGTMRG-CONTRACT-CLASS     PIC 9(3).                          
           05  FILLER                        PIC X(31).                         
                                                                                
