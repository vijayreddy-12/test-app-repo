      *================================================================*        
      *  CBCVDBNT - GENERAL PROGRAM DOCUMENTATION                      *        
      *================================================================*        
      *    Program Structure                                           *        
      *         The program structure is left intact from the IDMS/R   *        
      *         version.  Additional work areas and their use include: *        
      *            DBLINK-COMMAREA                                     *        
      *               This area is used to hold the flags and other    *        
      *               variables necessary to properly emulate the      *        
      *               IDMS Accesses in an SQL environment.             *        
      *                                                                *        
      *            CVnnnnVa Member                                     *        
      *               This SQL INCLUDE member is the output of a       *        
      *               DCLGEN and includes an SQL DECLARE TABLE and     *        
      *               the associated generated data area using the     *        
      *               SQL names.                                       *        
      *                                                                *        
      *            CMnnnnVa Member                                     *        
      *               This COPY member is created by DBLink.  It is    *        
      *               a duplicate of the IDMS/R schema record from     *        
      *               IDD with foreign keys, sequencers and set        *        
      *               flags added to the end.                          *        
      *                                                                *        
      *         Additional subroutines which may be found at the end   *        
      *         of the procedure division include:                     *        
      *           901-TEST-set-name (IF EMPTY)                         *        
      *               This subroutine is used to test the existence    *        
      *               of one or more rows in an associated table.      *        
      *               It replicates the IF EMPTY function.             *        
      *                                                                *        
      *           902-SELECT-EQUAL                                     *        
      *               This subroutine is used to retrieve the proper   *        
      *               SQL row when a non-specific FIND/OBTAIN DBKEY    *        
      *               was coded in IDMS.                               *        
      *                                                                *        
      *           903-set-name (CONNECT)                               *        
      *               This subroutine is used to initialize the        *        
      *               foreign key elements of a row using the          *        
      *               primary key values in the associated table.      *        
      *                                                                *        
      *           904-ISRT-record-name (STORE)                         *        
      *               This subroutine INSERTs a specific SQL row.      *        
      *                                                                *        
      *           904-UPDT-record-name (MODIFY)                        *        
      *               This subroutine UPDATEs a specific SQL row.      *        
      *                                                                *        
      *           905-record-name (ERASE)                              *        
      *               This subroutine ERASEs a specific SQL row.       *        
      *                                                                *        
      *           905-ALL-record-name (ERASE ALL)                      *        
      *               This subroutine ERASEs a specific SQL row        *        
      *               and all rows in logically related tables.        *        
      *                                                                *        
      *           905-PERM-record-name (ERASE PERMANENT)               *        
      *               This subroutine ERASEs a specific SQL row        *        
      *               and selected rows in logically related tables.   *        
      *                                                                *        
      *           906-00N-record-name (FIND WITHIN area)               *        
      *               This subroutine is used to retrieve a            *        
      *               set of SQL rows.  A CURSOR is OPENed and the     *        
      *               rows are FETCHed one at a time each time the     *        
      *               subroutine is performed.                         *        
      *                                                                *        
      *           906-00N-set-name (FIND WITHIN set)                   *        
      *               This subroutine is used to retrieve a            *        
      *               set of SQL rows.  A CURSOR is OPENed and the     *        
      *               rows are FETCHed one at a time each time the     *        
      *               subroutine is performed.  The records in the     *        
      *               set are limited by the key of the owner          *        
      *               relation and the relationship flag.              *        
      *                                                                *        
      *           906-01-record-name (FIND DBKEY)                      *        
      *               This subroutine is used to retrieve the          *        
      *               primary key of a specific SQL row prior          *        
      *               to executing a SELECT in theP906-05 routine.     *        
      *                                                                *        
      *           906-02-nn-record-name (FIND USING)                   *        
      *               This subroutine is used to retrieve a            *        
      *               specific SQL row based on the key provided       *        
      *               by the owner relationship and the sort key.      *        
      *                                                                *        
      *           906-04-set-name (FIND OWNER)                         *        
      *               This subroutine is used to retrieve a            *        
      *               specific SQL row based on the foreign key        *        
      *               of a related table.                              *        
      *                                                                *        
      *           906-05-record-name (FIND CALC)                       *        
      *               This subroutine is used to retrieve a            *        
      *               specific SQL row based on the primary key.       *        
      *                                                                *        
      *           980-GET-DBKEY-ENTRY                                  *        
      *               This subroutine is used in programs to retrieve  *        
      *               a specific DBKEY entry from the DBKEY table      *        
      *                                                                *        
      *           981-PUT-DBKEY-ENTRY                                  *        
      *               This subroutine is used in programs to place     *        
      *               a specific DBKEY entry into the DBKEY table.     *        
      *                                                                *        
      *           985-CURR-record-name                                 *        
      *               This subroutine sets data-related currency for a *        
      *               record by moving its primary key values into all *        
      *               associated RECORD and SET key fields.            *        
      *                                                                *        
      *           986-RESET-KEYS                                       *        
      *               This subroutine is used to reset the values of   *        
      *               RECORD and SET key areas to an initial value.    *        
      *                                                                *        
      *           991-CLOSE-CURSORS                                    *        
      *               This subroutine is used to close specifically    *        
      *               requested SQL CURSORs.                           *        
      *                                                                *        
      *           992-LOCK-TABLE                                       *        
      *               This subroutine is used to LOCK or reLOCK        *        
      *               specifically requested SQL Tables or Views.      *        
      *                                                                *        
      *           993-GET-DBKEY-TABLE                                  *        
      *               This subroutine is used in online programs to    *        
      *               retrieve the logical DBKEYS from temporary       *        
      *               storage.                                         *        
      *                                                                *        
      *           994-PUT-DBKEY-TABLE                                  *        
      *               This subroutine is used in online programs to    *        
      *               save the logical DBKEYS in temporary storage.    *        
      *                                                                *        
      *           995-GET-RECORD                                       *        
      *               This subroutine is used to MOVE a specific       *        
      *               record area from the input/output area to the    *        
      *               processing area.                                 *        
      *                                                                *        
      *           996-COMMIT                                           *        
      *               This subroutine issues the SQL COMMIT            *        
      *               command.                                         *        
      *                                                                *        
      *           997-ROLLBACK                                         *        
      *               This subroutine issues the SQL ROLLBACK          *        
      *               command.                                         *        
      *                                                                *        
      *           998-GET-TIMESTAMP                                    *        
      *               This subroutine issues an include to bring in th *        
      *               logic to acquire the current timestamp.          *        
      *                                                                *        
      *===================== END CBCVDBNT COPY ========================*        
                                                                                
