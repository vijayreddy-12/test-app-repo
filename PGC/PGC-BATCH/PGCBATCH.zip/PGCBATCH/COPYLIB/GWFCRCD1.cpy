       01  DBLINK-CURSOR-CODES.                                                 
               10  DBLINK-AGENT-CASECNT-F-CODE                                  
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-CASECNT-E-CODE                                  
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-COMP-F-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-COMP-E-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-PAYBASIS-F-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-PAYBASIS-E-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GFO-COMP-F-CODE   PIC X(1)        VALUE 'C'.          
               10  DBLINK-GFO-COMP-E-CODE   PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-ACCUM-F-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-ACCUM-E-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-CASECNT-F-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-CASECNT-E-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-COMP-F-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-COMP-E-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-RENEWAL-F-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-RENEWAL-E-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-ADVPSM-F-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-ADVPSM-E-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-GRACCT-F-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-GRACCT-E-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORAGENT-N-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORAGENT-N-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORCASECNT-N-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCASECNT-N-FLAG                                   
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORCNTL-N-CODE  PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCNTL-N-FLAG  PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORGFO-N-CODE   PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGFO-N-FLAG   PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORGROUP-N-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGROUP-N-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORRENEWAL-N-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORRENEWAL-N-FLAG                                   
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORGRACCT-N-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGRACCT-N-FLAG                                    
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORADVPSM-N-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORADVPSM-N-FLAG                                    
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORACCUM-N-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORACCUM-N-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORPAYBASIS-N-CODE                                  
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORPAYBASIS-N-FLAG                                  
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORCOMP-N-CODE  PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCOMP-N-FLAG  PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORTRANS-N-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORTRANS-N-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORAGENT-P-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORAGENT-P-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORCASECNT-P-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCASECNT-P-FLAG                                   
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORCNTL-P-CODE  PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCNTL-P-FLAG  PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORGFO-P-CODE   PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGFO-P-FLAG   PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORGROUP-P-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGROUP-P-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORRENEWAL-P-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORRENEWAL-P-FLAG                                   
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORGRACCT-P-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGRACCT-P-FLAG                                    
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORADVPSM-P-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORADVPSM-P-FLAG                                    
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORACCUM-P-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORACCUM-P-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORPAYBASIS-P-CODE                                  
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORPAYBASIS-P-FLAG                                  
                                            PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORCOMP-P-CODE  PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCOMP-P-FLAG  PIC X(1)        VALUE 'N'.          
               10  DBLINK-GWCORTRANS-P-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORTRANS-P-FLAG PIC X(1)        VALUE 'N'.          
               10  DBLINK-AGENT-CASECNT-N-CODE                                  
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-COMP-N-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-PAYBASIS-N-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GFO-COMP-N-CODE   PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-ACCUM-N-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-CASECNT-N-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-COMP-N-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-RENEWAL-N-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-ADVPSM-N-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-GRACCT-N-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-CASECNT-P-CODE                                  
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-COMP-P-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-AGENT-PAYBASIS-P-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GFO-COMP-P-CODE   PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-ACCUM-P-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-CASECNT-P-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-COMP-P-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GRACCT-RENEWAL-P-CODE                                 
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-ADVPSM-P-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GROUP-GRACCT-P-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORACCUM-D-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORADVPSM-D-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORAGENT-D-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCASECNT-D-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCNTL-D-CODE  PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORCOMP-D-CODE  PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGFO-D-CODE   PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGRACCT-D-CODE                                    
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORGROUP-D-CODE PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORPAYBASIS-D-CODE                                  
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORRENEWAL-D-CODE                                   
                                            PIC X(1)        VALUE 'C'.          
               10  DBLINK-GWCORTRANS-D-CODE PIC X(1)        VALUE 'C'.          
