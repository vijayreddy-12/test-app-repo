      *************************************************************             
      *      COMMISSIONS DATA LOADER EXTRACT RECORD               *             
      *           FOR SUPPLEMENTAL STATEMENTS                     *             
      *               RECORD LENGTH 137                           *             
      *************************************************************             
         05  DLEXTRACT-HEADER.                                                  
             10  LEXTRACT-HDR-RECTYPE         PIC X(1).                         
             10  LEXTRACT-FILE-TYPE           PIC X(10).                        
             10  LEXTRACT-SYSTEM-IDENTIFIER   PIC X(10).                        
             10  LEXTRACT-SEQUENCE-NUMBER     PIC 9(7).                         
             10  LEXTRACT-TOTAL-DETAIL-REC    PIC 9(9).                         
             10  LEXTRACT-DATE                PIC X(8).                         
             10  FILLER                       PIC X(92).                        
         05  DLEXTRACT-DETAIL REDEFINES DLEXTRACT-HEADER.                       
             10  LEXTRACT-DET-RECTYPE         PIC X(1).                         
             10  LEXTRACT-ADVISOR-NUMBER      PIC 9(6).                         
             10  LEXTRACT-GROUP-ACCOUNT-NAME  PIC X(25).                        
             10  LEXTRACT-CONTRACT            PIC X(10).                        
             10  LEXTRACT-BILLING-DIVISION    PIC X(5).                         
             10  LEXTRACT-ACCOUNT-STATUS      PIC X(1).                         
             10  LEXTRACT-PRODUCT-CODE        PIC X(1).                         
             10  LEXTRACT-BENEFIT-GROUPING    PIC X(10).                        
             10  LEXTRACT-COMMISSION-ACTIVITY PIC X(3).                         
             10  LEXTRACT-FROM-DATE.                                            
                 15  LEXTRACT-FROM-DATE-YYYY  PIC 9(4).                         
                 15  LEXTRACT-FROM-DATE-MM    PIC 9(2).                         
                 15  LEXTRACT-FROM-DATE-DD    PIC 9(2).                         
             10  LEXTRACT-TO-DATE.                                              
                 15  LEXTRACT-TO-DATE-YYYY    PIC 9(4).                         
                 15  LEXTRACT-TO-DATE-MM      PIC 9(2).                         
                 15  LEXTRACT-TO-DATE-DD      PIC 9(2).                         
             10  LEXTRACT-EFF-DATE.                                             
                 15  LEXTRACT-EFF-DATE-YYYY   PIC 9(4).                         
                 15  LEXTRACT-EFF-DATE-MM     PIC 9(2).                         
                 15  LEXTRACT-EFF-DATE-DD     PIC 9(2).                         
             10  LEXTRACT-YEAR-INDICATOR      PIC X(1).                         
             10  LEXTRACT-COMMISSION-BASE     PIC -999999999.99.                
             10  LEXTRACT-SPLIT               PIC 999.99.                       
             10  LEXTRACT-SCALE               PIC X(4).                         
             10  LEXTRACT-FLAT-RATE           PIC 999.99.                       
             10  LEXTRACT-COMP-TYPE           PIC X(01).                        
             10  LEXTRACT-COMP-AMT            PIC -99999999.99.                 
             10  LEXTRACT-PROC-DATE.                                            
                 15  LEXTRACT-PROC-DATE-YYYY  PIC 9(4).                         
                 15  LEXTRACT-PROC-DATE-MM    PIC 9(2).                         
                 15  LEXTRACT-PROC-DATE-DD    PIC 9(2).                         
