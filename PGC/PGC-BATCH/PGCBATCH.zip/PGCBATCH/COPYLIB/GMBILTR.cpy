       01  GMBILTR.                                                     00001000
               05  GBITRIDENT                      PIC XXX.             00002000
               05  GBILENGTH           COMP-3      PIC S9(5).           00003000
               05  GBIMOST-OUTSTANDING COMP-3.                          00004000
                   07  GBIDUE-DATE.                                     00005000
                       09  GBIDUE-YEAR             PIC S9(3).           00006000
                       09  GBIDUE-DAY              PIC S9(3).           00007000
                   07  GBIBILL.                                         00008000
                       09  GBILIFE                 PIC S9(7)V99.        00009000
                       09  GBILTD                  PIC S9(7)V99.        00010000
                       09  GBIA-S                  PIC S9(7)V99.        00011000
                       09  GBIADMIN-FEE            PIC S9(7)V99.        00012000
                   07  GBIPOSITION                 PIC S9(3).           00013000
               05  GBINO-HIST-SEG          COMP-3  PIC S9(3).           00014000
               05  GBIUNDEFINED1                   PIC X(23).           00015000
               05  GBIHISTORY-INFO OCCURS 25 TIMES.                     00016000
                   07  GBIHIST-DUE-DATE COMP-3.                         00017000
                       09  GBIHIST-DUE-YEAR        PIC S9(3).           00018000
                       09  GBIHIST-DUE-DAY         PIC S9(3).           00019000
                   07  GBIHIST-PREPARED-DATE COMP-3.                    00020000
                       09  GBIHIST-PREPARED-YEAR   PIC S9(3).           00021000
                       09  GBIHIST-PREPARED-DAY    PIC S9(3).           00022000
                   07  GBI-PREM-DUE        COMP-3  PIC S9(7)V99.        00023000
                   07  GBICERT-HOLDERS     COMP-3  PIC S9(7).           00024000
                   07  GBIHIST-ADMIN-FEE   COMP-3  PIC S9(7)V99.        00025000
                   07  GBINO-COV-LINES     COMP-3  PIC S9(3).           00026000
                   07  GBIUNDEFINED2               PIC X.               00027000
                   07  GBISTATS-BY-COVERAGE OCCURS 10 TIMES COMP-3.     00028000
                       09  GBICOV-CODE             PIC S9(3).           00029000
                       09  GBIAMT-BILLED           PIC S9(7)V99.        00030000
                       09  GBINO-LIVES             PIC S9(5).           00031000
                       09  GBIVOL                  PIC S9(9).           00032000
