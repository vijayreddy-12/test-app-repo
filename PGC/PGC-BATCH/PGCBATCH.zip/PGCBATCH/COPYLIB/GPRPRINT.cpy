       01  GPRPRINT.                                                    00001000
           03  PRINT-SYS022        PIC X(6)           VALUE 'SYS022'.   00002000
           03  PRINT-SYS023        PIC X(6)           VALUE 'SYS023'.   00003000
           03  PRINT-SYS024        PIC X(6)           VALUE 'SYS024'.   00004000
           03  PRINT-SYS025        PIC X(6)           VALUE 'SYS025'.   00005000
           03  PRINT-SYS026        PIC X(6)           VALUE 'SYS026'.   00006000
           03  PRINT-SYS027        PIC X(6)           VALUE 'SYS027'.   00007000
           03  PRINT-SYS028        PIC X(6)           VALUE 'SYS028'.   00008000
           03  PRINT-SYS029        PIC X(6)           VALUE 'SYS029'.   00009000
           03  PRINT-RETURN        PIC S9(1)  COMP-3  VALUE +0.         00010000
           03  PRINT-RECSIZE       PIC 9(5)           VALUE 00133.      00011000
           03  PRINT-BLKSIZE       PIC 9(5)           VALUE 03990.      00012000
           03  PRINT-FORMAT        PIC X(2)           VALUE 'FB'.       00013000
           03  PRINT-SYS022-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00014000
           03  PRINT-SYS023-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00015000
           03  PRINT-SYS024-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00016000
           03  PRINT-SYS025-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00017000
           03  PRINT-SYS026-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00018000
           03  PRINT-SYS027-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00019000
           03  PRINT-SYS028-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00020000
           03  PRINT-SYS029-COUNT  PIC S9(7)  COMP-3  VALUE +0.         00021000
