       01  GMIDCTR.                                                     00001000
               05  GICTRIDENT                      PIC XXX.             00002000
               05  GICLENGTH               COMP-3  PIC S9(5).           00003000
               05  GIUNDEFINED1                    PIC X(20).           00004000
               05  GICCOVERAGE-INFO OCCURS 10 TIMES.                    00005000
                   10  GICCLASSES.                                      00006000
                       15  GICCLASS OCCURS 5 TIMES PIC XX.              00007000
                   10  GICCOVERAGE-CODES.                               00008000
                       15  GICCOVERAGE-CODE        PIC XX               00009000
                                    OCCURS 10 TIMES.                    00010000
                   10  GIUNDEFINED2                PIC X(9).            00011000
