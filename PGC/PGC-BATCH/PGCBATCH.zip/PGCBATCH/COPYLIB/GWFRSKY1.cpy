       01  DBLINK-RECORD-SET-KEYS.                                              
        02  DBLINK-KEYS.                                                        
            25  DBLINK-RECORD-KEYS.                                             
             30  DBLINK-REC-SET-KEYS-FLAG   PIC X(1)        VALUE 'Y'.          
              88  DBLINK-KEYS-INIT-REQD                     VALUE 'Y'.          
             30  DBLINK-GWCORACCUM-KEY.                                         
                45  DBLINK-GWCORACCUM-01    PIC X(7)        VALUE SPACE.        
                45  DBLINK-GWCORACCUM-02    PIC X(3)        VALUE SPACE.        
                45  DBLINK-GWCORACCUM-03    PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORACCUM-04    PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-GWCORADVPSM-KEY.                                        
                45  DBLINK-GWCORADVPSM-01   PIC X(7)        VALUE SPACE.        
                45  DBLINK-GWCORADVPSM-02   PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORADVPSM-03   PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORADVPSM-04   PIC X(3)        VALUE SPACE.        
             30  DBLINK-GWCORAGENT-KEY.                                         
                45  DBLINK-GWCORAGENT-01    PIC X(6)        VALUE SPACE.        
             30  DBLINK-GWCORCASECNT-KEY.                                       
                45  DBLINK-GWCORCASECNT-01  PIC X(7)        VALUE SPACE.        
                45  DBLINK-GWCORCASECNT-02  PIC X(3)        VALUE SPACE.        
                45  DBLINK-GWCORCASECNT-03  PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORCASECNT-04  PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORCASECNT-05  PIC X(26)       VALUE ZERO.         
             30  DBLINK-GWCORCNTL-KEY.                                          
                45  DBLINK-GWCORCNTL-01     PIC X(8)        VALUE SPACE.        
             30  DBLINK-GWCORCOMP-KEY.                                          
                45  DBLINK-GWCORCOMP-01     PIC X(7)        VALUE SPACE.        
                45  DBLINK-GWCORCOMP-02     PIC X(3)        VALUE SPACE.        
                45  DBLINK-GWCORCOMP-03     PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORCOMP-04     PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORCOMP-05     PIC X(26)       VALUE ZERO.         
             30  DBLINK-GWCORGFO-KEY.                                           
                45  DBLINK-GWCORGFO-01      PIC X(5)        VALUE SPACE.        
             30  DBLINK-GWCORGRACCT-KEY.                                        
                45  DBLINK-GWCORGRACCT-01   PIC X(7)        VALUE SPACE.        
                45  DBLINK-GWCORGRACCT-02   PIC X(3)        VALUE SPACE.        
             30  DBLINK-GWCORGROUP-KEY.                                         
                45  DBLINK-GWCORGROUP-01    PIC X(7)        VALUE SPACE.        
             30  DBLINK-GWCORPAYBASIS-KEY.                                      
                45  DBLINK-GWCORPAYBASIS-01 PIC X(6)        VALUE SPACE.        
                45  DBLINK-GWCORPAYBASIS-02 PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORPAYBASIS-03 PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORPAYBASIS-04 PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GWCORPAYBASIS-05 PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-GWCORRENEWAL-KEY.                                       
                45  DBLINK-GWCORRENEWAL-01  PIC X(7)        VALUE SPACE.        
                45  DBLINK-GWCORRENEWAL-02  PIC X(3)        VALUE SPACE.        
                45  DBLINK-GWCORRENEWAL-03  PIC X(26)       VALUE ZERO.         
             30  DBLINK-GWCORTRANS-KEY.                                         
                45  DBLINK-GWCORTRANS-01    PIC X(26)       VALUE ZERO.         
             30  DBLINK-IDENTITIES.                                             
              35  DBLINK-RECORD-IDENTITIES.                                     
               40  DBLINK-GWCORCASECNT-ID-KEY                                   
                                            PIC S9(9)  COMP VALUE ZERO.         
               40  DBLINK-GWCORCOMP-ID-KEY  PIC S9(9)  COMP VALUE ZERO.         
             30  FILLER                     PIC X(256)      VALUE SPACE.        
            25  DBLINK-SET-KEYS.                                                
             26  DBLINK-SET-KEYS-G.                                             
             30  DBLINK-AGENT-CASECNT-KEY.                                      
              35  DBLINK-AGENT-CASECNT-KEY-O.                                   
                45  DBLINK-AGENT-CASECNT-01 PIC X(6)        VALUE SPACE.        
              35  DBLINK-AGENT-CASECNT-KEY-M.                                   
               40  DBLINK-AGENT-CASECNT-KEY-S.                                  
                45  DBLINK-AGENT-CASECNT-02 PIC X(26)       VALUE ZERO.         
             30  DBLINK-AGENT-COMP-KEY.                                         
              35  DBLINK-AGENT-COMP-KEY-O.                                      
                45  DBLINK-AGENT-COMP-01    PIC X(6)        VALUE SPACE.        
              35  DBLINK-AGENT-COMP-KEY-M.                                      
               40  DBLINK-AGENT-COMP-KEY-S.                                     
                45  DBLINK-AGENT-COMP-02    PIC X(26)       VALUE ZERO.         
             30  DBLINK-AGENT-PAYBASIS-KEY.                                     
              35  DBLINK-AGENT-PAYBASIS-KEY-O.                                  
                45  DBLINK-AGENT-PAYBASIS-01                                    
                                            PIC X(6)        VALUE SPACE.        
              35  DBLINK-AGENT-PAYBASIS-KEY-M.                                  
               40  DBLINK-AGENT-PAYBASIS-KEY-U.                                 
                45  DBLINK-AGENT-PAYBASIS-02                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-AGENT-PAYBASIS-03                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-AGENT-PAYBASIS-04                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-AGENT-PAYBASIS-05                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-GFO-COMP-KEY.                                           
              35  DBLINK-GFO-COMP-KEY-O.                                        
                45  DBLINK-GFO-COMP-01      PIC X(5)        VALUE SPACE.        
              35  DBLINK-GFO-COMP-KEY-M.                                        
               40  DBLINK-GFO-COMP-KEY-S.                                       
                45  DBLINK-GFO-COMP-02      PIC X(26)       VALUE ZERO.         
             30  DBLINK-GRACCT-ACCUM-KEY.                                       
              35  DBLINK-GRACCT-ACCUM-KEY-O.                                    
                45  DBLINK-GRACCT-ACCUM-01  PIC X(7)        VALUE SPACE.        
                45  DBLINK-GRACCT-ACCUM-02  PIC X(3)        VALUE SPACE.        
              35  DBLINK-GRACCT-ACCUM-KEY-M.                                    
               40  DBLINK-GRACCT-ACCUM-KEY-U.                                   
                45  DBLINK-GRACCT-ACCUM-03  PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GRACCT-ACCUM-04  PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-GRACCT-CASECNT-KEY.                                     
              35  DBLINK-GRACCT-CASECNT-KEY-O.                                  
                45  DBLINK-GRACCT-CASECNT-01                                    
                                            PIC X(7)        VALUE SPACE.        
                45  DBLINK-GRACCT-CASECNT-02                                    
                                            PIC X(3)        VALUE SPACE.        
              35  DBLINK-GRACCT-CASECNT-KEY-M.                                  
               40  DBLINK-GRACCT-CASECNT-KEY-U.                                 
                45  DBLINK-GRACCT-CASECNT-03                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GRACCT-CASECNT-04                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
               40  DBLINK-GRACCT-CASECNT-KEY-S.                                 
                45  DBLINK-GRACCT-CASECNT-05                                    
                                            PIC X(26)       VALUE ZERO.         
             30  DBLINK-GRACCT-COMP-KEY.                                        
              35  DBLINK-GRACCT-COMP-KEY-O.                                     
                45  DBLINK-GRACCT-COMP-01   PIC X(7)        VALUE SPACE.        
                45  DBLINK-GRACCT-COMP-02   PIC X(3)        VALUE SPACE.        
              35  DBLINK-GRACCT-COMP-KEY-M.                                     
               40  DBLINK-GRACCT-COMP-KEY-U.                                    
                45  DBLINK-GRACCT-COMP-03   PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GRACCT-COMP-04   PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
               40  DBLINK-GRACCT-COMP-KEY-S.                                    
                45  DBLINK-GRACCT-COMP-05   PIC X(26)       VALUE ZERO.         
             30  DBLINK-GRACCT-RENEWAL-KEY.                                     
              35  DBLINK-GRACCT-RENEWAL-KEY-O.                                  
                45  DBLINK-GRACCT-RENEWAL-01                                    
                                            PIC X(7)        VALUE SPACE.        
                45  DBLINK-GRACCT-RENEWAL-02                                    
                                            PIC X(3)        VALUE SPACE.        
              35  DBLINK-GRACCT-RENEWAL-KEY-M.                                  
               40  DBLINK-GRACCT-RENEWAL-KEY-S.                                 
                45  DBLINK-GRACCT-RENEWAL-03                                    
                                            PIC X(26)       VALUE ZERO.         
             30  DBLINK-GROUP-ADVPSM-KEY.                                       
              35  DBLINK-GROUP-ADVPSM-KEY-O.                                    
                45  DBLINK-GROUP-ADVPSM-01  PIC X(7)        VALUE SPACE.        
              35  DBLINK-GROUP-ADVPSM-KEY-M.                                    
               40  DBLINK-GROUP-ADVPSM-KEY-U.                                   
                45  DBLINK-GROUP-ADVPSM-02  PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GROUP-ADVPSM-03  PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-GROUP-ADVPSM-04  PIC X(3)        VALUE SPACE.        
             30  DBLINK-GROUP-GRACCT-KEY.                                       
              35  DBLINK-GROUP-GRACCT-KEY-O.                                    
                45  DBLINK-GROUP-GRACCT-01  PIC X(7)        VALUE SPACE.        
              35  DBLINK-GROUP-GRACCT-KEY-M.                                    
               40  DBLINK-GROUP-GRACCT-KEY-S.                                   
                45  DBLINK-GROUP-GRACCT-02  PIC X(26)       VALUE ZERO.         
             30  FILLER                     PIC X(256)      VALUE SPACE.        
             26  DBLINK-SET-FLAGS.                                              
             30  DBLINK-AGENT-CASECNT-F     PIC X(1)        VALUE SPACE.        
             30  DBLINK-AGENT-COMP-F        PIC X(1)        VALUE SPACE.        
             30  DBLINK-AGENT-PAYBASIS-F    PIC X(1)        VALUE SPACE.        
             30  DBLINK-GFO-COMP-F          PIC X(1)        VALUE SPACE.        
             30  DBLINK-GRACCT-ACCUM-F      PIC X(1)        VALUE SPACE.        
             30  DBLINK-GRACCT-CASECNT-F    PIC X(1)        VALUE SPACE.        
             30  DBLINK-GRACCT-COMP-F       PIC X(1)        VALUE SPACE.        
             30  DBLINK-GRACCT-RENEWAL-F    PIC X(1)        VALUE SPACE.        
             30  DBLINK-GROUP-ADVPSM-F      PIC X(1)        VALUE SPACE.        
             30  DBLINK-GROUP-GRACCT-F      PIC X(1)        VALUE SPACE.        
             30  FILLER                     PIC X(16)       VALUE SPACE.        
             26  DBLINK-WS-KEYS.                                                
             30  DBLINK-WS-AGENT-PAYBASIS-KEY.                                  
                45  DBLINK-WS-AGENT-PAYBASIS-02                                 
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-AGENT-PAYBASIS-03                                 
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-AGENT-PAYBASIS-04                                 
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-AGENT-PAYBASIS-05                                 
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-WS-GRACCT-ACCUM-KEY.                                    
                45  DBLINK-WS-GRACCT-ACCUM-03                                   
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-GRACCT-ACCUM-04                                   
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-WS-GRACCT-CASECNT-KEY.                                  
                45  DBLINK-WS-GRACCT-CASECNT-03                                 
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-GRACCT-CASECNT-04                                 
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-WS-GRACCT-COMP-KEY.                                     
                45  DBLINK-WS-GRACCT-COMP-03                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-GRACCT-COMP-04                                    
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
             30  DBLINK-WS-GROUP-ADVPSM-KEY.                                    
                45  DBLINK-WS-GROUP-ADVPSM-02                                   
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-GROUP-ADVPSM-03                                   
                                            PIC S9(3)       COMP-3              
                       VALUE ZERO.                                              
                45  DBLINK-WS-GROUP-ADVPSM-04                                   
                                            PIC X(3)        VALUE SPACE.        
             30  FILLER                     PIC X(256)      VALUE SPACE.        
