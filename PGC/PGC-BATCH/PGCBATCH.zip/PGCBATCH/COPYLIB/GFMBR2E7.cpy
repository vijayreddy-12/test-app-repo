        01  GFMBILLING-RECORD-2E.                                               
      *****************************************************************         
      *     GIPSY BILLING      RECORD                                 *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *       CREATED BY GFMINTM4                                     *         
      *                  GPBILLFM                                     *         
      *                                                               *         
      *       USED    BY GPRBILLS                                     *         
      *                  GTAXBILL                                     *         
      *                                                               *         
      *       REC TYPE     '2'                                        *         
      *       REC LENGTH   219 + .....                                *         
      *                                                               *         
      *****************************************************************         
      *     JUN/93 M. PRANGE                                                    
      *          - CHANGES TO HANDLE MULTIPLE TAXES.                            
      *****************************************************************         
            05  GFM2E-RECORD-LENGTH         COMP SYNC PIC S9(4).                
            05  FILLER                                PIC XX.                   
            05  GFM2E-RECORD-TYPE     VALUE '2'       PIC X.                    
            05  GFM2E-PRODUCT                         PIC X.                    
            05  GFM2E-GROUP-OFFICE                    PIC X(5).                 
GNE         05  GFM2E-GROUP-NUMBER            COMP-3  PIC S9(7).                
            05  GFM2E-ACCOUNT                         PIC XXX.                  
            05  GFM2E-DIVISION                COMP-3  PIC S9(3).                
            05  GFM2E-ORDER           VALUE 'E'       PIC X.                    
            05  GFM2E-INSURED-LIVES           COMP-3  PIC S9(7).                
            05  GFM2E-PREM-DUE-LAST-MTH       COMP-3  PIC S9(7)V99.             
            05  GFM2E-GROSS-PREM-DUE-THIS-MTH COMP-3  PIC S9(7)V99.             
            05  GFM2E-NET-PREM-DUE-THIS-MTH   COMP-3  PIC S9(7)V99.             
                                                                                
            05  GFM2E-GROUP-TAX-IND                   PIC X(1).                 
            05  GFM2E-TAX-PREV-TOTAL          COMP-3  PIC S9(7)V9(2).           
            05  GFM2E-TAX-CURR-TOTAL          COMP-3  PIC S9(7)V9(2).           
            05  GFM2E-TAX-TABLE-CNT           COMP-3  PIC S9(3).        00057270
            05  GFM2E-TAX-TABLE.                                        00057280
                10  GFM2E-TAX-TABLE-ENTRY OCCURS 13 TIMES.                      
                    15  GFM2E-TAX-CODE                PIC X(2).                 
                    15  GFM2E-TAX-PREV-AMT    COMP-3  PIC S9(7)V9(2).           
                    15  GFM2E-TAX-CURR-AMT    COMP-3  PIC S9(7)V9(2).           
                                                                                
GNE         05  FILLER                                PIC X(9).                 
            05  GFM2E-NO-OF-CODES             COMP-3  PIC S9(3).                
            05  GFM2E-COV-INFO OCCURS 38 TIMES.                                 
                10  GFM2E-COVERAGE-CODE       COMP-3  PIC S9(3).                
                10  GFM2E-VOLUME              COMP-3  PIC S9(9).                
                10  GFM2E-BILLED-PREMIUM      COMP-3  PIC S9(7)V99.             
