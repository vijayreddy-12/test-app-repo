      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORADVPSM' TO DBLINK-CURR-PARAGRAPH.                
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORADVPSM' TO RECORD-NAME.                                   
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORADVPSM TO DBLINK-RECORD-MADE-CURRENT.               
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORADVPSM-EXIT                                  
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE GROUP-NUMBER OF GC-TADVPS TO DBLINK-GWCORADVPSM-01          
               MOVE NEXT-RENEW-YEAR OF GC-TADVPS TO                             
                   DBLINK-GWCORADVPSM-02                                        
               MOVE NEXT-RENEW-DAY OF GC-TADVPS TO DBLINK-GWCORADVPSM-03        
               MOVE COMM-SCALE OF GC-TADVPS TO DBLINK-GWCORADVPSM-04            
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORADVPSM TO DBLINK-VIEW-NAME-CURRENT.                 
           MOVE DBLINK-GWCORADVPSM-KEY TO DBLINK-VIEW-200-CURRENT.              
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET GROUP-ADVPSM  M/A                                                   
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-GROUP-ADVPSM-F                          
           MOVE GROUP-NUMBER OF GC-TADVPS TO DBLINK-GROUP-ADVPSM-01.            
           MOVE NEXT-RENEW-YEAR OF GC-TADVPS TO DBLINK-GROUP-ADVPSM-02.         
           MOVE NEXT-RENEW-DAY OF GC-TADVPS TO DBLINK-GROUP-ADVPSM-03.          
           MOVE COMM-SCALE OF GC-TADVPS TO DBLINK-GROUP-ADVPSM-04.              
