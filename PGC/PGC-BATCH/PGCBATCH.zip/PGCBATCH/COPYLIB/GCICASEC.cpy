      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORCASECNT                         10/26/10  17:05  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORCASECNT.                                                        
           05  AGT-CASE-CNT-DATE.                                               
               10  AGT-CASE-CNT-YEAR          COMP-3    PIC S9(3).              
               10  AGT-CASE-CNT-DAY           COMP-3    PIC S9(3).              
           05  AGT-CASE-CNT-AMT               COMP-3    PIC S9V99.              
           05  AGENT-SPLIT                    COMP-3    PIC S9(3)V99.           
