       01  WMNOTTR.                                                     WMNOTTR 
                 05  W-GSNTRIDENT                PIC XXX.               WMNOTTR 
                 05  W-GSNLENGTH       COMP-3    PIC S9(5).             WMNOTTR 
                 05  W-GSNCODE                   PIC XX.                WMNOTTR 
                 05  W-GSNSPEC-NOTES-INFO.                              WMNOTTR 
                     07  W-GSNSTART-DATE   COMP-3.                      WMNOTTR 
                         09  W-GSNSTART-YEAR       PIC S9(3).           WMNOTTR 
                         09  W-GSNSTART-DAY        PIC S9(3).           WMNOTTR 
                     07  W-GSNSTOP-DATE    COMP-3.                      WMNOTTR 
                         09  W-GSNSTOP-YEAR        PIC S9(3).           WMNOTTR 
                         09  W-GSNSTOP-DAY         PIC S9(3).           WMNOTTR 
                     07  W-GSNINFO               PIC X(25).             WMNOTTR 
                 05  W-GSNUNDEFINED              PIC X(20).             WMNOTTR 
