      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE AGT-CASE-CNT-YEAR OF GC-TCASEC TO                               
               AGT-CASE-CNT-YEAR OF GWCORCASECNT                                
           MOVE AGT-CASE-CNT-DAY OF GC-TCASEC TO                                
               AGT-CASE-CNT-DAY OF GWCORCASECNT                                 
           MOVE AGT-CASE-CNT-AMT OF GC-TCASEC TO                                
               AGT-CASE-CNT-AMT OF GWCORCASECNT                                 
           MOVE AGENT-SPLIT OF GC-TCASEC TO                                     
               AGENT-SPLIT OF GWCORCASECNT.                                     
