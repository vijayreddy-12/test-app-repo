      *****************************************************************         
      *     TAPE PARMS                                                *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *   ====> PART OF GIPSY-REL-1    REQ # 240 (ALPHA+)             *         
      *                                                               *         
      *    M DRURY   AUG/89                                           *         
      *                                                               *         
      *          MODIFY SYS011-REC  FROM  00021 TO 27.                *         
      *                 SYS011-BLK  FROM  00021 TO 2700.              *         
      *                              PROD CODE   1                    *         
      *                              GFO         5                    *         
      *                                                               *         
      *****************************************************************         
       01  GPRTPARM.                                                            
           03  TAPE-SYS011          PIC X(6)           VALUE 'SYS011'.          
           03  TAPE-SYS014          PIC X(6)           VALUE 'SYS074'.          
           03  TAPE-RETURN          PIC S9(1)  COMP-3  VALUE +0.                
           03  TAPE-SYS011-RECSIZE  PIC 9(5)           VALUE 00027.             
           03  TAPE-SYS011-BLKSIZE  PIC 9(5)           VALUE 02700.             
           03  TAPE-SYS011-FORMAT   PIC X(2)           VALUE 'FB'.              
           03  TAPE-SYS011-COUNT    PIC S9(7)  COMP-3  VALUE +0.                
           03  TAPE-SYS014-RECSIZE  PIC 9(5)           VALUE 19056.             
           03  TAPE-SYS014-BLKSIZE  PIC 9(5)           VALUE 19060.             
           03  TAPE-SYS014-FORMAT   PIC X(2)           VALUE 'VB'.              
           03  TAPE-SYS014-COUNT    PIC S9(7)  COMP-3  VALUE +0.                
