       01  GMSTSTR.                                                     00001000
               05  GSTTRIDENT                      PIC XXX.             00002000
               05  GSTLENGTH           COMP-3      PIC S9(5).           00003000
               05  GSTPAID-IND                     PIC X.               00004000
               05  GSTOUTSTANDING      COMP-3.                          00005000
                   07  GSTOUT-LIFE                 PIC S9(7)V99.        00006000
                   07  GSTOUT-LTD                  PIC S9(7)V99.        00007000
                   07  GSTOUT-A-S                  PIC S9(7)V99.        00008000
                   07  GSTOUT-ADMIN-FEE            PIC S9(7)V99.        00009000
               05  GSTPREMIUM-IND                  PIC X.               00010000
               05  GSTADVANCE          COMP-3      PIC S9(7)V99.        00011000
               05  GSTCALENDAR-YEAR-TO-DATE                             00012000
                                       COMP-3.                          00013000
                   07  GSTCAL-YTD-LIFE.                                 00014000
                       09  GSTCAL-YTD-LI-BILLED    PIC S9(7)V99.        00015000
                       09  GSTCAL-YTD-LI-PAID      PIC S9(7)V99.        00016000
                   07  GSTCAL-YTD-A-S.                                  00017000
                       09  GSTCAL-YTD-AS-BILLED    PIC S9(7)V99.        00018000
                       09  GSTCAL-YTD-AS-PAID      PIC S9(7)V99.        00019000
                   07  GSTCAL-YTD-LTD.                                  00020000
                       09  GSTCAL-YTD-LTD-BILLED   PIC S9(7)V99.        00021000
                       09  GSTCAL-YTD-LTD-PAID     PIC S9(7)V99.        00022000
                   07  GSTCAL-YTD-ADMIN-FEE.                            00023000
                       09  GSTCAL-YTD-ADMIN-FEE-BILLED PIC S9(7)V99.    00024000
                       09  GSTCAL-YTD-ADMIN-FEE-PAID   PIC S9(7)V99.    00025000
               05  GSTPREMIUMS         COMP-3.                          00026000
                   07  GSTPREM-LIFE                PIC S9(7)V99.        00027000
                   07  GSTPREM-LTD                 PIC S9(7)V99.        00028000
                   07  GSTPREM-AD-D                PIC S9(7)V99.        00029000
                   07  GSTPREM-WI                  PIC S9(7)V99.        00030000
                   07  GSTPREM-EHC.                                     00031000
                       09  GSTPREM-EHC-SINGLE      PIC S9(7)V99.        00032000
                       09  GSTPREM-EHC-FAMILY1     PIC S9(7)V99.        00033000
                       09  GSTPREM-EHC-FAMILY2     PIC S9(7)V99.        00034000
                   07  GSTPREM-DEN.                                     00035000
                       09  GSTPREM-DEN-SINGLE      PIC S9(7)V99.        00036000
                       09  GSTPREM-DEN-FAMILY1     PIC S9(7)V99.        00037000
                       09  GSTPREM-DEN-FAMILY2     PIC S9(7)V99.        00038000
               05  GSTCURR-MONTH-PREM-ADJ                               00039000
                                       COMP-3.                          00040000
                   07  GSTPREM-ADJ-LIFE            PIC S9(5)V99.        00041000
                   07  GSTPREM-ADJ-LTD             PIC S9(5)V99.        00042000
                   07  GSTPREM-ADJ-AD-D            PIC S9(5)V99.        00043000
                   07  GSTPREM-ADJ-WI              PIC S9(5)V99.        00044000
                   07  GSTPREM-ADJ-EHC.                                 00045000
                       09  GSTPREM-ADJ-EHC-SINGLE  PIC S9(5)V99.        00046000
                       09  GSTPREM-ADJ-EHC-FAMILY1 PIC S9(5)V99.        00047000
                       09  GSTPREM-ADJ-EHC-FAMILY2 PIC S9(5)V99.        00048000
                   07  GSTPREM-ADJ-DEN.                                 00049000
                       09  GSTPREM-ADJ-DEN-SINGLE  PIC S9(5)V99.        00050000
                       09  GSTPREM-ADJ-DEN-FAMILY1 PIC S9(5)V99.        00051000
                       09  GSTPREM-ADJ-DEN-FAMILY2 PIC S9(5)V99.        00052000
               05  GSTPROJECTED-LOSS-RATIO  COMP-3.                     00053000
                   07  GSTPROJ-LR-PREV-POLYR       PIC S9(4)V9.         00054000
                   07  GSTPROJ-LR-CURR-POLYR       PIC S9(4)V9.         00055000
               05  GSTACCEPT-LOSS-PREV     COMP-3  PIC S9(4)V9.         00056000
               05  GSTPART                 COMP-3  PIC S9(7).           00057000
               05  GSTNON-PART             COMP-3  PIC S9(5).           00058000
               05  GSTUNDEFINED                    PIC X(33).           00059000
               05  GSTNUM-COV-CODES        COMP-3  PIC S9(3).           00060000
               05  GSTSTATS-BY-COV OCCURS 15 TIMES COMP-3.              00061000
                   07  GSTSTAT-COV-CODE            PIC S9(3).           00062000
                   07  GSTSTAT-VOL                 PIC S9(9).           00063000
                   07  GSTSTAT-LIVES               PIC S9(7).           00064000
