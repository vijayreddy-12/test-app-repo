      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           IF PREM-DUE-YEAR OF GWCORACCUM  NOT NUMERIC                          
               MOVE ZEROS TO PREM-DUE-YEAR OF GC-TACCUM                         
           ELSE                                                                 
               MOVE PREM-DUE-YEAR OF GWCORACCUM                                 
               TO PREM-DUE-YEAR OF GC-TACCUM                                    
           END-IF.                                                              
                                                                                
           IF PREM-DUE-DAY OF GWCORACCUM  NOT NUMERIC                           
               MOVE ZEROS TO PREM-DUE-DAY OF GC-TACCUM                          
           ELSE                                                                 
               MOVE PREM-DUE-DAY OF GWCORACCUM                                  
               TO PREM-DUE-DAY OF GC-TACCUM                                     
           END-IF.                                                              
                                                                                
           IF PREM-AMT-PAID OF GWCORACCUM  NOT NUMERIC                          
               MOVE ZEROS TO PREM-AMT-PAID OF GC-TACCUM                         
           ELSE                                                                 
               MOVE PREM-AMT-PAID OF GWCORACCUM                                 
               TO PREM-AMT-PAID OF GC-TACCUM                                    
           END-IF.                                                              
                                                                                
           IF COMM-AMT-EARNED OF GWCORACCUM  NOT NUMERIC                        
               MOVE ZEROS TO COMM-AMT-EARNED OF GC-TACCUM                       
           ELSE                                                                 
               MOVE COMM-AMT-EARNED OF GWCORACCUM                               
               TO COMM-AMT-EARNED OF GC-TACCUM                                  
           END-IF.                                                              
                                                                                
           IF SALES-CREDITS-AMT-EARNED OF GWCORACCUM  NOT NUMERIC               
               MOVE ZEROS TO SALES-CREDITS-AMT-EARNED OF GC-TACCUM              
           ELSE                                                                 
               MOVE SALES-CREDITS-AMT-EARNED OF GWCORACCUM                      
               TO SALES-CREDITS-AMT-EARNED OF GC-TACCUM                         
           END-IF.                                                              
                                                                                
