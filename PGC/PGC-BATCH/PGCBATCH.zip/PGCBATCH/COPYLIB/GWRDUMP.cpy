       01 GWRDUMP.                                                              
      ****************************************************************          
      * JAN 2011 - TRUDY - CREATED                                              
      ****************************************************************          
           03  GWRDUMP-RECORD.                                                  
             05  GWRDUMP-PROGRAM-NAME          PIC X(08).                       
             05  GWRDUMP-ERROR-MESSAGE         PIC X(58).                       
             05  GWRDUMP-ACTION                PIC X(16).                       
             05  GWRDUMP-LR-NAME               PIC X(32).                       
             05  GWRDUMP-ERROR-STATUS.                                          
                 10  GWRDUMP-LR-STATUS         PIC X(08).                       
                 10  GWRDUMP-SQL-CODE          PIC S9(09).                      
             05  GWRDUMP-GROUP                 PIC 9(07).                       
             05  GWRDUMP-ACCOUNT               PIC X(03).                       
             05  GWRDUMP-CERTIFICATE.                                           
                 10  GWRDUMP-CERTIFICATE-N     PIC 9(10).                       
             05  GWRDUMP-SEVERITY              PIC X.                           
                 88  GWRDUMP-FATAL-ERROR       VALUE 'F'.                       
                 88  GWRDUMP-WARNING           VALUE 'W'.                       
