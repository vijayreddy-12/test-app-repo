      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00000010
      * THESE TABLES MUST BE KEPT IN SYNC.                            * 00000020
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00000030
                                                                        00000040
       01  FILLER                   PIC X(32)         VALUE             00000100
           'WS-TEMP-VALID-AGENT             '.                          00000200
                                                                        00000300
       01  WS-TEMP-VALID-AGENT.                                         00000400
           05  WS-TEMP-AGENT.                                           00000500
               10  WS-TEMP-AGENT-CODE        PIC 9(6).                  00000600
           05  WS-TEMP-AGENT-BRANCH          PIC X(5).                  00000700
           05  WS-TEMP-PAY-BASIS             PIC X.                     00000800
           05  WS-TEMP-CONSTANT-AGENT-INFO.                             00000900
               10  WS-TEMP-LIFE-PERCENT      PIC S9(3)V99  COMP-3.      00001000
               10  WS-TEMP-LTD-PERCENT       PIC S9(3)V99  COMP-3.      00001100
               10  WS-TEMP-A-S-PERCENT       PIC S9(3)V99  COMP-3.      00001200
               10  WS-TEMP-REG-SCALE         PIC X(3).                  00001300
               10  WS-TEMP-LTD-SCALE         PIC X(3).                  00001400
               10  WS-TEMP-REG-RATE          PIC S9(3)V99  COMP-3.      00001500
               10  WS-TEMP-LTD-RATE          PIC S9(3)V99  COMP-3.      00001600
               10  WS-TEMP-COMM-IND          PIC X.                     00001700
                                                                        00001800
       01  FILLER                   PIC X(32)         VALUE             00001900
           'WS-FY-VALID-AGENT-TABLE         '.                          00002000
                                                                        00002100
       01  WS-FY-VALID-AGENT-TABLE.                                     00002200
           05  WS-FY-VALID-AGENT OCCURS 4 TIMES.                        00002300
               10  WS-FY-AGENT.                                         00002400
                   15  WS-FY-AGENT-CODE          PIC 9(6).              00002500
               10  WS-FY-AGENT-BRANCH            PIC X(5).              00002600
               10  WS-FY-PAY-BASIS               PIC X.                 00002700
               10  WS-FY-CONSTANT-AGENT-INFO.                           00002800
                   15  WS-FY-LIFE-PERCENT        PIC S9(3)V99  COMP-3.  00002900
                   15  WS-FY-LTD-PERCENT         PIC S9(3)V99  COMP-3.  00003000
                   15  WS-FY-A-S-PERCENT         PIC S9(3)V99  COMP-3.  00003100
                   15  WS-FY-REG-SCALE           PIC X(3).              00003200
                   15  WS-FY-LTD-SCALE           PIC X(3).              00003300
                   15  WS-FY-REG-RATE            PIC S9(3)V99  COMP-3.  00003400
                   15  WS-FY-LTD-RATE            PIC S9(3)V99  COMP-3.  00003500
                   15  WS-FY-COMM-IND            PIC X.                 00003600
                                                                        00003700
       01  FILLER                   PIC X(32)         VALUE             00003800
           'WS-RN-VALID-AGENT-TABLE         '.                          00003900
                                                                        00004000
       01  WS-RN-VALID-AGENT-TABLE.                                     00004100
           05  WS-RN-VALID-AGENT OCCURS 4 TIMES.                        00004200
               10  WS-RN-AGENT.                                         00004300
                   15  WS-RN-AGENT-CODE          PIC 9(6).              00004400
               10  WS-RN-AGENT-BRANCH            PIC X(5).              00004500
               10  WS-RN-PAY-BASIS               PIC X.                 00004600
               10  WS-RN-CONSTANT-AGENT-INFO.                           00004700
                   15  WS-RN-LIFE-PERCENT        PIC S9(3)V99  COMP-3.  00004800
                   15  WS-RN-LTD-PERCENT         PIC S9(3)V99  COMP-3.  00004900
                   15  WS-RN-A-S-PERCENT         PIC S9(3)V99  COMP-3.  00005000
                   15  WS-RN-REG-SCALE           PIC X(3).              00005100
                   15  WS-RN-LTD-SCALE           PIC X(3).              00005200
                   15  WS-RN-REG-RATE            PIC S9(3)V99  COMP-3.  00005300
                   15  WS-RN-LTD-RATE            PIC S9(3)V99  COMP-3.  00005400
                   15  WS-RN-COMM-IND            PIC X.                 00005500
      /                                                                 00005600
       01  FILLER                   PIC X(32)         VALUE             00005700
           'WS-VALID-AGENT-TABLE            '.                          00005800
                                                                        00005900
       01  WS-VALID-AGENT-TABLE.                                        00006000
           05  WS-VALID-AGENT OCCURS 4 TIMES.                           00006100
               10  WS-AGENT.                                            00006200
                   15  WS-AGENT-CODE             PIC 9(6).              00006300
               10  WS-AGENT-BRANCH               PIC X(5).              00006400
               10  WS-PAY-BASIS                  PIC X.                 00006500
               10  WS-CONSTANT-AGENT-INFO.                              00006600
                   15  WS-LIFE-PERCENT           PIC S9(3)V99  COMP-3.  00006700
                   15  WS-LTD-PERCENT            PIC S9(3)V99  COMP-3.  00006800
                   15  WS-A-S-PERCENT            PIC S9(3)V99  COMP-3.  00006900
                   15  WS-AGT-REG-SCALE          PIC X(3).              00007000
                   15  WS-AGT-LTD-SCALE          PIC X(3).              00007100
                   15  WS-AGT-REG-RATE           PIC S9(3)V99  COMP-3.  00007200
                   15  WS-AGT-LTD-RATE           PIC S9(3)V99  COMP-3.  00007300
                   15  WS-COMM-IND               PIC X.                 00007400
