      *01  M-F-C-BillMemAdj1.                                                   
      *---------------------------------------------------------------*         
      * BILLING MEMBER ADJUSTMENT 1 DATA DEFINITION                   *         
      *    FOR XML USAGE                                              *         
      *---------------------------------------------------------------*         
           05  RECORD-TYPE                          PIC X(1).                   
DATE1      05  PROCESS-DATE                         PIC X(8).                   
           05  GROUP-INFORMATION.                                               
               10  POLICY                           PIC X(10).                  
               10  ACCOUNT                          PIC X(3).                   
           05  MEMBER-ADJUSTMENT1.                                              
               10  MAILING-DIVISION             PIC X(3).                       
ATTRIB         10  I-D                          PIC X(12).                      
               10  CERTIFICATE                  PIC X(12).                      
               10  MEMBER-NAME                  PIC X(25).                      
DATE1          10  EFFECTIVE-DATE               PIC X(8).                       
               10  ADJUST-MODE                  PIC X(2).                       
               10  TOTAL-PREMIUM                PIC S9(7)V99                    
                   SIGN LEADING SEPARATE.                                       
TIMES1         10  NUM-OF-MEMBER-BENEFITS       PIC 9(3).                       
TIMES1         10  MEMBER-BENEFIT  OCCURS 38 TIMES.                             
ATTRIB             15  COV-CODE                 PIC 9(3).                       
                   15  VOLUME                   PIC S9(7)                       
                       SIGN LEADING SEPARATE.                                   
                   15  PREM-ADJUST-AMOUNT       PIC S9(8)V999                   
                       SIGN LEADING SEPARATE.                                   
                   15  SELECT-IND.                                              
ATTRIB                 20  TC                   PIC X(2).                       
