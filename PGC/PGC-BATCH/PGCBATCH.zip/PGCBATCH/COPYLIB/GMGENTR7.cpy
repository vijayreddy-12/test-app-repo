       01  GMGENTR.                                                             
      *****************************************************************         
      *     GIPSY MASTER GENERAL INFORMATION TRAILER                  *         
      *                                                               *         
      *       CREATED BY ... MANY ....                                *         
      *       USED    BY ... MANY ....                                *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *   ====> PART OF GIPSY-REL-1                                   *         
      *                                                               *         
      *    I BUCKNELL  SEP/89   (CHANGES)                             *         
      *                                                               *         
      *          CHANGE THE GGIBENEFIT-COMB TO THE COMPRESSED FORMAT  *         
      *             THIS AREA IS CREATED VIA AN ASM PGM GUTBITS6      *         
      *                                                               *         
      *    DEC/89 M. PRANGE                                           *         
      *           - ADDED FIELDS GGIADMIN-AREA & GGILIVES-RANGE       *         
      *           - RENAMED GGIFOGL-SOURCE   TO GGIFOGL-ADMIN-AREA    *         
      *                     GGIFOGL-CONSTANT TO GGIFOGL-LIVES-RANGE   *         
      *    SEP/91 K. AYSCOUGH                                         *         
      *           - ADD GGIMAIL-IND  TO THE SCREEN                    *         
      *****************************************************************         
               05  GGIRECORD-LENGTH    COMP SYNC   PIC S9(4).                   
               05  FILLER                          PIC XX.                      
GNE            05  GGIGROUP-NUMBER     COMP-3      PIC S9(7).                   
               05  GGIACCOUNT                      PIC XXX.                     
               05  GGIMASTER-IDENT                 PIC X.                       
               05  GGIIDENTITY                     PIC X(5).                    
               05  GGIBRANCH                       PIC X(5).                    
               05  GGIGROUP-REP                    PIC 9(5).                    
               05  GGIGROUP-REP2                   PIC 9(5).                    
               05  GGIGROUP-OFFICE                 PIC X(5).                    
               05  GGISHARING-OFFICE               PIC X(5).                    
               05  GGICLAIMS-OFFICE                PIC X(5).                    
               05  GGICOUNTRY                      PIC X.                       
               05  GGICURRENCY                     PIC X.                       
               05  GGIRESIDENCE                    PIC XX.                      
               05  GGILANGUAGE                     PIC X.                       
               05  GGIPRODUCT-CODE                 PIC X.                       
               05  GGIPOLICY-ACCT                  PIC X.                       
               05  GGIACCT-TYPE.                                                
                   07 GGITYPE                      PIC X.                       
                   07 GGIUW-TYPE                   PIC X.                       
               05  GGICOVERAGE-CODE                PIC X.                       
               05  GGIBENEFIT-SEL                  PIC X.                       
               05  GGISTD-IND-CLASS-CODE   COMP-3  PIC S9(5).                   
               05  GGICONTRIBUTION                 PIC X.                       
               05  GGIBENEFIT-LINK                 PIC X.                       
               05  GGITAX                          PIC X.                       
               05  GGIWITHHOLDING                  PIC X.                       
               05  GGIEMPLOYEE-LIST                PIC X.                       
               05  GGIHANDLING-CODE                PIC X.                       
               05  GGIARREARS-IND                  PIC X.                       
               05  GGIARREARS-COUNTER  COMP-3      PIC S999.                    
               05  GGIARREARS-STATUS               PIC X.                       
               05  GGIREDUCTION-AGES   COMP-3.                                  
                   07  GGIRED-AGE-LIFE             PIC S999.                    
                   07  GGIRED-AGE-LTD              PIC S999.                    
                   07  GGIRED-AGE-AD-D             PIC S999.                    
                   07  GGIRED-AGE-MEDICAL          PIC S999.                    
                   07  GGIRED-AGE-DENTAL           PIC S999.                    
                   07  GGIRED-AGE-WEEK-INDEM       PIC S999.                    
               05  GGITERMINATION-AGES     COMP-3.                              
                   07  GGITERM-AGE-LIFE            PIC S999.                    
                   07  GGITERM-AGE-LTD             PIC S999.                    
                   07  GGITERM-AGE-AD-D            PIC S999.                    
                   07  GGITERM-WAIT-PERIOD-LTD     PIC S999.                    
                   07  GGITERM-AGE-MEDICAL         PIC S999.                    
                   07  GGITERM-AGE-DENTAL          PIC S999.                    
                   07  GGITERM-AGE-WEEK-INDEM      PIC S999.                    
               05  GGISTEP-DOWN                    PIC X.                       
               05  GGICHANGE-DATE                  PIC X.                       
               05  GGIACCOUNT-STATUS               PIC XX.                      
               05  GGIDATES            COMP-3.                                  
                   07  GGINEXT-ANNIVERSARY.                                     
                       09  GGINEXT-ANNIV-YEAR      PIC S9(3).                   
                       09  GGINEXT-ANNIV-DAY       PIC S9(3).                   
                   07  GGICLAIMS-SUSPENDED.                                     
                       09  GGICLAIM-SUSP-YEAR      PIC S9(3).                   
                       09  GGICLAIM-SUSP-DAY       PIC S9(3).                   
                   07  GGICONTRACT-ISSUE.                                       
                       09  GGIISSUE-YEAR           PIC S9(3).                   
                       09  GGIISSUE-DAY            PIC S9(3).                   
                   07  GGI-ACCT-EFFECTIVE.                                      
                       09  GGI-ACCT-EFF-YEAR       PIC S9(3).                   
                       09  GGI-ACCT-EFF-DAY        PIC S9(3).                   
                   07  GGIPAID-TO-DATE.                                         
                       09  GGIPAID-TO-YEAR         PIC S9(3).                   
                       09  GGIPAID-TO-DAY          PIC S9(3).                   
                   07  GGILAST-CHANGE-DATE.                                     
                       09  GGILAST-CHANGE-YEAR     PIC S9(3).                   
                       09  GGILAST-CHANGE-DAY      PIC S9(3).                   
                   07  GGILAST-ACCOUNTING-DATE.                                 
                       09  GGILAST-ACCTG-YEAR      PIC S9(3).                   
                       09  GGILAST-ACCTG-DAY       PIC S9(3).                   
               05  GGIPOL-ARREARS          COMP-3  PIC S9(2).                   
               05  GGICASHFLOW-LST-POL-YR  COMP-3  PIC S9(3).                   
               05  GGICASHFLOW-CURR-POL-YR COMP-3  PIC S9(3).                   
               05  GGIBILL-STAT-FORMAT.                                         
                   07  GGIBILLING-AGENT            PIC 9(6).                    
                   07  GGIBILLING-TYPE             PIC XX.                      
                   07  GGILISTING-CERTIFICATE      PIC X.                       
                   07  GGILISTING-ORDER            PIC X.                       
                   07  GGISTAT-OPTION.                                          
                       09  GGILIST-BILLING         PIC X.                       
                       09  GGIEMP-CHANGE-LIST      PIC X.                       
                       09  GGIWORK-SHEET           PIC X.                       
                       09  GGISUMMARY              PIC X.                       
               05  GGIBENEFIT-COMB.                                             
      *****************************************************************         
      * GIPSY RELEASE #1, SEPTEMBER 1989                                        
      *   TITLES AREA BELOW CHANGED TO INCREASE NUMBER OF COLUMNS FROM          
      *   7 TO 9.  'GGITITLES-AREA' IS *COMPRESSED* DATA CONSISTING OF          
      *   6-BIT CHARACTER CODES.  TRANSLATION TO/FROM AN EXPANSION              
      *   WORK AREA (COPYBOOK 'GGI6BITX') IS ACCOMPLISHED USING RTN             
      *   'GUTBITS6'.  (I. BUCKNELL)                                            
      *****************************************************************         
                   07  GGINUM-COV-CODES-LIST.                                   
                       09  GGINUM-COV-CODES OCCURS 9 TIMES                      
                                   COMP-3          PIC S9(3).                   
                   07  GGITITLES-AREA              PIC X(129).                  
                   07  GGICOV-CODES-LIST.                                       
                       09  GGICOV-CODES OCCURS 36 TIMES                         
                                   COMP-3          PIC S9(3).                   
               05  GGIBASIC-ADMIN-FEE OCCURS 4 TIMES.                           
                   07  GGIBASIC-ADMIN-AMT          PIC S9(7)V99 COMP-3.         
                   07  GGIBASIC-ADMIN-IND          PIC X.                       
                   07  GGIBASIC-ADMIN-REASON       PIC XX.                      
               05  GGIOTHER-ADMIN-FEE.                                          
                   07  GGIOTHER-ADMIN-AMT          PIC S9(7)V99 COMP-3.         
                   07  GGIOTHER-ADMIN-IND          PIC X.                       
                   07  GGIOTHER-ADMIN-REASON       PIC X(25).                   
               05  GGIPRACTICE-BILLING.                                         
                   07  GGIPRAC-BILL-REQ-TYPE       PIC X.                       
                   07  GGIPRAC-BILL-FROM-DATE      COMP-3.                      
                       09  GGIPRAC-BILL-FROM-YR    PIC S9(3).                   
                       09  GGIPRAC-BILL-FROM-DAY   PIC S9(3).                   
                   07  GGIPRAC-BILL-TO-DATE        COMP-3.                      
                       09  GGIPRAC-BILL-TO-YR      PIC S9(3).                   
                       09  GGIPRAC-BILL-TO-DAY     PIC S9(3).                   
                   07  GGIPRAC-BILL-REQUESTOR      PIC X(15).                   
               05  GGICLAIMS-INFORMATION.                                       
                   10  GGICARRYOVER-IND.                                        
                       15  GGICARRYOVER-HC         PIC X.                       
                       15  GGICARRYOVER-DE         PIC X.                       
                   10  GGIELIGIBLE-BENEFITS        PIC X.                       
                   10  GGIPRIVATE-DUTY-NURSING     PIC 99.                      
                   10  GGIDENTAL-PLAN-IND          PIC X.                       
                   10  GGILAB-FEES                 PIC XX.                      
               05  GGIFOGL-CODE OCCURS 6 TIMES.                                 
                   10  GGIFOGL-BENEFIT             PIC X(4).                    
                   10  GGIFOGL-REINS               PIC X(2).                    
                   10  GGIFOGL-GRP-TYPE            PIC X.                       
                   10  GGIFOGL-AGT-TYPE            PIC X.                       
                   10  GGIFOGL-ADMIN-AREA          PIC X.                       
                   10  GGIFOGL-LIVES-RANGE         PIC X.                       
               05  GGIFUND-TYPE OCCURS 6 TIMES     PIC X.                       
               05  GGIBILLING-OVERIDE.                                          
                   10 GGIBILLING-OVERIDE-IND       PIC X.                       
                   10 GGIBILLING-OR-TELE-NUM       PIC X(11).                   
               05  GGIPH-EOB                       PIC X.                       
               05  GGIADMIN-AREA                   PIC X(1).                    
               05  GGILIVES-RANGE                  PIC X(1).                    
               05  GGIMAIL-IND                     PIC X(1).                    
               05  GGIUNDEFINED                    PIC X(14).                   
