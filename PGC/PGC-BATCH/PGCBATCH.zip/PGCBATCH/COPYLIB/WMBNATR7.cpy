       01  WMBNATR7.                                                            
      ******************************************************************        
      *    FEB/91 PRANGE          - ADDED W-GBN-NAAD-PROC-DATE.                 
      ******************************************************************        
           05  W-GBNTRIDENT                    PIC XXX.                         
           05  W-GBNLENGTH           COMP-3    PIC S9(5).                       
           05  W-GBNPOST-CODE                  PIC X(6).                        
           05  W-GBN-NAAD-PROC-DATE.                                            
               10  W-GBN-NAAD-PROC-YEAR        PIC S9(3)      COMP-3.           
               10  W-GBN-NAAD-PROC-DAY         PIC S9(3)      COMP-3.           
           05  W-GBNUNDEFINED                  PIC X(16).                       
           05  W-GBNBILL-NAME-ADDR             PIC X(186).                      
