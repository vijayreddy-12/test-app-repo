      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE GROUP-NUMBER OF GC-TCOMP TO                                     
               GROUP-NUMBER OF GWCORCOMP                                        
           MOVE GR-ACCOUNT OF GC-TCOMP TO                                       
               GR-ACCOUNT OF GWCORCOMP                                          
           MOVE COMP-EFF-YEAR OF GC-TCOMP TO                                    
               COMP-EFF-YEAR OF GWCORCOMP                                       
           MOVE COMP-EFF-DAY OF GC-TCOMP TO                                     
               COMP-EFF-DAY OF GWCORCOMP                                        
           MOVE AGENT-NUMBER OF GC-TCOMP TO                                     
               AGENT-NUMBER OF GWCORCOMP                                        
           MOVE GFO-NUMBER OF GC-TCOMP TO                                       
               GFO-NUMBER OF GWCORCOMP                                          
           MOVE GROUP-REP OF GC-TCOMP TO                                        
               GROUP-REP OF GWCORCOMP                                           
           MOVE COMP-PROCESS-YEAR OF GC-TCOMP TO                                
               COMP-PROCESS-YEAR OF GWCORCOMP                                   
           MOVE COMP-PROCESS-DAY OF GC-TCOMP TO                                 
               COMP-PROCESS-DAY OF GWCORCOMP                                    
           MOVE COV-TYPE OF GC-TCOMP TO                                         
               COV-TYPE OF GWCORCOMP                                            
           MOVE COMP-TYPE OF GC-TCOMP TO                                        
               COMP-TYPE OF GWCORCOMP                                           
           MOVE COMP-AMT OF GC-TCOMP TO                                         
               COMP-AMT OF GWCORCOMP                                            
           MOVE COMP-REASON OF GC-TCOMP TO                                      
               COMP-REASON OF GWCORCOMP                                         
           MOVE RECON-IND OF GC-TCOMP TO                                        
               RECON-IND OF GWCORCOMP                                           
           MOVE COMP-DISP OF GC-TCOMP TO                                        
               COMP-DISP OF GWCORCOMP                                           
           MOVE AGENT-SPLIT OF GC-TCOMP TO                                      
               AGENT-SPLIT OF GWCORCOMP                                         
           MOVE PREM-AMT OF GC-TCOMP TO                                         
               PREM-AMT OF GWCORCOMP                                            
           MOVE PREM-SOURCE OF GC-TCOMP TO                                      
               PREM-SOURCE OF GWCORCOMP                                         
           MOVE AD-D-AMT OF GC-TCOMP TO                                         
               AD-D-AMT OF GWCORCOMP                                            
           MOVE WI-AMT OF GC-TCOMP TO                                           
               WI-AMT OF GWCORCOMP                                              
           MOVE EHC-AMT OF GC-TCOMP TO                                          
               EHC-AMT OF GWCORCOMP                                             
           MOVE DE-AMT OF GC-TCOMP TO                                           
               DE-AMT OF GWCORCOMP.                                             
