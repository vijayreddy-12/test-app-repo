      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  GCOMDACR          -  VO COMMISSION EXTRACT COMPARE                     
      *                                                                         
      *  HUB:  VO AND MAINFRAME COMMISSIONS FEED MERGE                          
      ******************************************************                    
       01  GCOMDACR.                                                            
           05  GDACR-RECORD-LENGTH  VALUE +304 COMP   PIC S9(4).        00008000
           05  GDACR-FILLER         VALUE LOW-VALUES  PIC XX.           00009000
           05  GDACR-VLNO           VALUE +0 COMP-3   PIC S9(3).        00011000
           05  GDACR-GROUP          VALUE +0 COMP-3   PIC S9(15).       00012000
           05  GDACR-SUB-ACCOUNT    VALUE SPACES      PIC X(4).         00012000
           05  GDACR-FUND           VALUE +0 COMP-3   PIC S9(3).        00013000
           05  GDACR-LBUS           VALUE +0          PIC S9(2).        00014000
           05  GDACR-PLAN-TYPE      VALUE +0          PIC S9.           00015000
           05  GDACR-POLSPEX        VALUE +0 COMP-3   PIC S9(9).        00016000
           05  GDACR-BRANCH         VALUE +0 COMP-3   PIC S9(5).        00017000
           05  GDACR-CURRENCY       VALUE +0 COMP-3   PIC S9(2).        00018000
           05  GDACR-MODE           VALUE +0 COMP-3   PIC S9(2).        00019000
           05  GDACR-BILCL          VALUE +0          PIC S9.           00020000
           05  GDACR-ACCT-EFFECTIVE-DATE.                               00030000
               10  GDACR-EFF-CC     VALUE 0           PIC 99.           00040000
               10  GDACR-EFF-YY     VALUE 0           PIC 99.           00040000
               10  GDACR-EFF-MM     VALUE 0           PIC 99.           00040000
               10  GDACR-EFF-DD     VALUE 0           PIC 99.           00040000
           05  GDACR-BILLING-NAME   VALUE SPACES      PIC X(25).        00060000
           05  GDACR-PREMNO         VALUE +0 COMP-3   PIC S9(3).        00070000
           05  GDACR-PRORATEMO      VALUE +0 COMP-3   PIC S9(2).        00080000
           05  GDACR-PREM-DUE-DATE.                                     00090000
               10  GDACR-PREM-CC    VALUE 0           PIC 99.           00040000
               10  GDACR-PREM-YY    VALUE 0           PIC 99.           00040000
               10  GDACR-PREM-MM    VALUE 0           PIC 99.           00040000
               10  GDACR-PREM-DD    VALUE 0           PIC 99.           00040000
           05  GDACR-PMOD           VALUE +0 COMP-3   PIC S9.           00100000
           05  GDACR-MAN            VALUE +0 COMP-3   PIC S9(5).        00110000
           05  GDACR-SPCL           VALUE +0          PIC S9(2).        00120000
           05  GDACR-UNDCL          VALUE +0          PIC S9(2).        00130000
           05  GDACR-SEX            VALUE +0 COMP-3   PIC S9.           00140000
           05  GDACR-CEDED          VALUE +0 COMP-3   PIC S9.           00150000
           05  GDACR-SCALE          VALUE SPACES      PIC X(3).         00150000
           05  GDACR-TRANSFER-CODE.                                     00160000
               10  GDACR-TRAN-BALYR VALUE  0 COMP-3   PIC 9.            00170000
               10  GDACR-TRAN-REASON VALUE 0 COMP-3   PIC 9(2).         00180000
           05  GDACR-TRANSFER-DATE.                                     00190000
               10  GDACR-TRAN-CC    VALUE 0           PIC 99.           00040000
               10  GDACR-TRAN-YY    VALUE 0           PIC 99.           00040000
               10  GDACR-TRAN-MM    VALUE 0           PIC 99.           00040000
               10  GDACR-TRAN-DD    VALUE 0           PIC 99.           00040000
           05  GDACR-FOGL-CODE      VALUE 0           PIC 9(10).        00200000
           05  FILLER               VALUE ZERO        PIC 9(16).        00201000
           05  FILLER               VALUE SPACES      PIC X(5).         00201000
           05  GDACR-DIRCOMIND      VALUE 'G'         PIC X.            00220000
           05  GDACR-AGENT-DATA COMP-3.                                 00230000
               10  GDACR-AGENT-CODE VALUE +0          PIC S9(6).        00240000
               10  GDACR-CONTRACT-TYPE  VALUE +0      PIC S9(3).        00241000
               10  GDACR-CLASS          VALUE  0      PIC 9(3).         00241000
               10  GDACR-MGR        VALUE +0          PIC S9(3).        00242000
               10  GDACR-SHARE      VALUE +0          PIC S9(3)V99.     00243000
               10  GDACR-ASSIGNEE   VALUE +0          PIC S9(5).        00244000
               10  GDACR-CAUSE      VALUE +0          PIC S9(3).        00245000
               10  GDACR-PARTICULARS-CODE VALUE +0    PIC S9(5).        00245000
           05  GDACR-UNIQUE-ID.                                         00250000
               10  GDACR-SOURCE     VALUE 0           PIC 99.           00250000
               10  GDACR-RECEIVE-DATE.                                  00030000
                   15  GDACR-REC-CENTURY VALUE 0      PIC 99.           00040000
                   15  GDACR-REC-YEAR   VALUE 0       PIC 99.           00040000
                   15  GDACR-REC-MONTH  VALUE 0       PIC 99.           00040000
                   15  GDACR-REC-DAY    VALUE 0       PIC 99.           00040000
               10  GDACR-AUDIT-NUMBER   VALUE 0 COMP-3 PIC 9(5).        00250000
               10  GDACR-AUDIT-TYPE     VALUE 0        PIC 9.           00250000
           05  GDACR-PROCESS-DETAILS.                                   00250000
               10  GDACR-STATUS         VALUE 0        PIC 99.          00250000
               10  GDACR-ERROR-CODE     VALUE 0 COMP-3 PIC 9(5).        00250000
               10  GDACR-PROCESS-DATE.                                  00030000
                   15  GDACR-PROC-CC    VALUE 0        PIC 99.          00040000
                   15  GDACR-PROC-YY    VALUE 0        PIC 99.          00040000
                   15  GDACR-PROC-MM    VALUE 0        PIC 99.          00040000
                   15  GDACR-PROC-DD    VALUE 0        PIC 99.          00040000
               10  GDACR-END-DATE.                                      00030000
                   15  GDACR-END-CC     VALUE 0        PIC 99.          00040000
                   15  GDACR-END-YY     VALUE 0        PIC 99.          00040000
                   15  GDACR-END-MM     VALUE 0        PIC 99.          00040000
                   15  GDACR-END-DD     VALUE 0        PIC 99.          00040000
           05  FILLER                   VALUE SPACES   PIC X(31).               
           05  GDACR-VARS.                                              00250000
               10  GDACR-VARIABLE-DATA COMP-3 OCCURS 10 TIMES.          00260000
                   15  GDACR-CODE                      PIC S9(3).       00270000
                   15  GDACR-CRAMT                     PIC S9(11).      00280000
                   15  GDACR-CCAMT REDEFINES GDACR-CRAMT                00280000
                                                       PIC S9(10)V9.    00280000
                   15  GDACR-CMAMT REDEFINES GDACR-CRAMT                00280000
                                                       PIC S9(09)V99.   00280000
                   15  GDACR-CPAMT REDEFINES GDACR-CRAMT                00280000
                                                       PIC S9(06)V9(5). 00280000
