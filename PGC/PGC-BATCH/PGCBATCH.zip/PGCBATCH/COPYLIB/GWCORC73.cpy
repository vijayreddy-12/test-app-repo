      ******************************************************************        
      *                                                                *        
      *        RECON DATES - RECONCILIATION EXTRACT RECORD             *        
      *                                                                *        
      ******************************************************************        
       01  EXT-RECON-DATE-RECORD.                                               
           05  EXT-DATE-SORT-KEY.                                               
REN            10  EXT-DATE-GROUP-NUMBER          PIC X(7) VALUE SPACES.        
               10  EXT-DATE-GROUP-ACCOUNT         PIC XXX  VALUE SPACES.        
           05  EXT-RECON-DATE-DATA.                                             
               10  EXT-LAST-RECON-DATE.                                         
                   15  EXT-LAST-RECON-YEAR COMP-3 PIC S999 VALUE ZERO.          
                   15  EXT-LAST-RECON-DAY  COMP-3 PIC S999 VALUE ZERO.          
               10  EXT-NEXT-RECON-DATE.                                         
                   15  EXT-NEXT-RECON-YEAR COMP-3 PIC S999 VALUE ZERO.          
                   15  EXT-NEXT-RECON-DAY  COMP-3 PIC S999 VALUE ZERO.          
               10  FILLER                        PIC X(20) VALUE SPACES.        
