      ******************************************************************00001003
      *                                                                *00002003
      *          DATE CONTROL RECORD FOR RUNNING COMMISSIONS           *00003003
      *          PRODUCTION JOBS.                                      *00003103
      *                                                                *00003203
      ******************************************************************00004003
       01  FILE-CONTROL-DATE-RECORD.                                    00008006
           05  FILLER                        PIC X(10) VALUE LOW-VALUES.        
           05  FILE-CONTROL-DATE.                                       00010506
               10  FILLER                    PIC S9(3) COMP-3.          00010607
               10  FILLER                    PIC S9(3) COMP-3.          00010707
           05  FILLER                        PIC X(41) VALUE SPACES.            
