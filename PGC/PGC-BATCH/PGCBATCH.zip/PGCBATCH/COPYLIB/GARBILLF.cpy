      *01  M-F-C-BillMemAdj2.                                                   
      *---------------------------------------------------------------*         
      * BILLING MEMBER ADJUSTMENT 2 DATA DEFINITION                   *         
      *    FOR XML USAGE (MATCHES UP WITH GD90AR ADJUSTMENT           *         
      *---------------------------------------------------------------*         
           05  RECORD-TYPE                          PIC X(1).                   
DATE1      05  PROCESS-DATE                         PIC X(8).                   
           05  GROUP-INFORMATION.                                               
               10  POLICY                           PIC X(10).                  
               10  ACCOUNT                          PIC X(3).                   
           05  MEMBER-ADJUSTMENT2.                                              
               10  MAILING-DIVISION             PIC X(3).                       
ATTRIB         10  I-D                          PIC X(12).                      
               10  CERTIFICATE                  PIC X(12).                      
               10  MEMBER-NAME                  PIC X(25).                      
DATE1          10  EFFECTIVE-DATE               PIC X(8).                       
               10  DETAIL-REMARKS               PIC X(20).                      
               10  TOTAL-PREMIUM                PIC S9(7)V99                    
                   SIGN LEADING SEPARATE.                                       
               10  TAX-STATUS.                                                  
ATTRIB             15  TC                       PIC X.                          
               10  TAX-CODE.                                                    
ATTRIB             15  TC                       PIC X(2).                       
TIMES1         10  NUM-OF-MEMBER-BENEFITS       PIC 9(3).                       
TIMES1         10  MEMBER-BENEFIT  OCCURS 3 TIMES.                              
ATTRIB             15  COV-CODE                 PIC 9(3).                       
                   15  PREMIUM-ADJUST           PIC S9(7)V99                    
                       SIGN LEADING SEPARATE.                                   
