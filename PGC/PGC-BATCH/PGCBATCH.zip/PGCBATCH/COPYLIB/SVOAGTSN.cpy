      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  SVOAGTSN          -  (SORTED) SENT VO AGENTS FILE                      
      *  VOAGENT.SVOAGTSN  -  VO AGENT IN SVOAGTSN FORMAT FILE                  
      *                                                                         
      *  HUB:  AGENT FILE AND PAY BASIS DATA EXTRACT/MERGE                      
      ******************************************************                    
                                                                                
       01  AGENT-SENT-RECORD.                                                   
           05  AGTSN-DATA.                                                      
               10  AGTSN-AGENT-CODE         PIC 9(7).                           
               10  AGTSN-PAY-BASIS-EFF-DATE PIC X(8).                           
               10  AGTSN-PAY-BASIS-IND      PIC X.                              
               10  AGTSN-BRANCH-CODE        PIC X(5).                           
               10  AGTSN-AGENT-NAME         PIC X(25).                          
               10  AGTSN-CONTRACT-CLASS     PIC 9(3).                           
           05  FILLER                       PIC X(31).                          
                                                                                
