      *================================================================*        
      *  CBCVDBWS - The portion of the subschema control work area     *        
      *  that is not passed with currency.                             *        
      *================================================================*        
       01  DBLINK-COMMAREA.                                                     
           05  FILLER                       PIC X(16)                           
                   VALUE 'START DBLINKWS'.                                      
           05  DBLINK-AREA-LENGTHS.                                             
               10  DBLINK-LENGTH-1          PIC S9(9) COMP  VALUE ZERO.         
               10  DBLINK-LENGTH-2          PIC S9(9) COMP  VALUE ZERO.         
               10  DBLINK-LENGTH-3          PIC S9(9) COMP  VALUE ZERO.         
               10  DBLINK-LENGTH-4          PIC S9(9) COMP  VALUE ZERO.         
           05  DBLINK-PASSED-WORK-FIELDS.                                       
               10  DBLINK-VIEW-NAME-WORK    PIC X(18)       VALUE SPACE.        
               10  DBLINK-VIEW-NAME-CURRENT PIC X(18)       VALUE SPACE.        
               10  DBLINK-VIEW-200          PIC X(200)      VALUE SPACE.        
               10  DBLINK-VIEW-200-CURRENT  PIC X(200)      VALUE SPACE.        
               10  DBLINK-SAVE-RECORD-KEY   PIC X(200)      VALUE SPACE.        
               10  DBLINK-SAVE-DBKEY        PIC S9(8) COMP  VALUE ZERO.         
               10  DBLINK-RECORD-MADE-CURRENT PIC X(18)     VALUE SPACE.        
               10  DBLINK-SET-NAME-WORK     PIC X(18)       VALUE SPACE.        
               10  DBLINK-TYPE-SELECT       PIC X(1)        VALUE SPACE.        
                   88  DBLINK-SELECT-CONNECT      VALUE 'C'.                    
                   88  DBLINK-SELECT-FIND         VALUE 'F'.                    
                   88  DBLINK-SELECT-OBTAIN       VALUE 'O'.                    
                   88  DBLINK-SELECT-STORE        VALUE 'S'.                    
                   88  DBLINK-SELECT-MODIFY       VALUE 'M'.                    
                   88  DBLINK-SELECT-ERASE        VALUE 'E' 'P' 'S'.            
                   88  DBLINK-SELECT-ERASE-PERM   VALUE 'P'.                    
                   88  DBLINK-SELECT-ERASE-SELECT VALUE 'S'.                    
               10  DBLINK-TYPE-GET          PIC X(1)        VALUE SPACE.        
                   88  DBLINK-GET-CALC          VALUE 'C'.                      
                   88  DBLINK-GET-DUPLICATE     VALUE 'D'.                      
                   88  DBLINK-GET-FIRST         VALUE 'F'.                      
                   88  DBLINK-GET-DBKEY         VALUE 'K'.                      
                   88  DBLINK-GET-LAST          VALUE 'L'.                      
                   88  DBLINK-GET-NEXT          VALUE 'N'.                      
                   88  DBLINK-GET-PRIOR         VALUE 'P'.                      
                   88  DBLINK-GET-CURR          VALUE 'Q'.                      
                   88  DBLINK-GET-SORTED        VALUE 'T'.                      
                   88  DBLINK-GET-USING         VALUE 'U'.                      
                   88  DBLINK-GET-OWNER         VALUE 'W'.                      
               10  DBLINK-LR-MOVE-TO-IDMS-FLAG  PIC X(1)    VALUE SPACE.        
               10  DBLINK-TYPE-GET-LR       PIC X(1)        VALUE SPACE.        
MAN            10  DBLINK-LR-STATUS         PIC X(16)       VALUE SPACE.        
MAN                88  DBLINK-LR-ERROR          VALUE 'LR-ERROR'.               
MAN                88  DBLINK-LR-FOUND          VALUE 'LR-FOUND'.               
                   88  DBLINK-LR-NOT-FOUND      VALUE 'LR-NOT-FOUND'            
                                                      'LR-ERROR'.               
               10  LR-DO-CNT                PIC 9(2)        VALUE ZERO.         
               10  LR-ERROR-STATUS          PIC X(16)       OCCURS 10.          
               10  DBLINK-TYPE-LOCK         PIC X(1)        VALUE SPACE.        
                   88  DBLINK-LOCK-EXCLUSIVE    VALUE 'E'.                      
                   88  DBLINK-LOCK-SHARE        VALUE 'S'.                      
                   88  DBLINK-NO-LOCK           VALUE 'N'.                      
                   88  DBLINK-LOCK-AGAIN        VALUE 'R'.                      
               10  DBLINK-TYPE-LOCK-2       PIC X(1)        VALUE SPACE.        
                   88  DBLINK-LOCK-AGAIN-2      VALUE 'R'.                      
               10  DBLINK-ERROR-STATUS-WORK PIC X(4)        VALUE SPACE.        
               10  COMMIT-COUNTER-WS        PIC S9(8)  COMP VALUE +0.           
           05  DBLINK-CONSTANTS.                                                
               10  DBLINK-CALC              PIC X(1)        VALUE 'C'.          
               10  DBLINK-CONNECT           PIC X(1)        VALUE 'C'.          
               10  DBLINK-CLOSED            PIC X(1)        VALUE 'C'.          
               10  DBLINK-DUPLICATE         PIC X(1)        VALUE 'D'.          
               10  DBLINK-ERASE             PIC X(1)        VALUE 'E'.          
               10  DBLINK-ERASE-PERM        PIC X(1)        VALUE 'P'.          
               10  DBLINK-ERASE-SELECT      PIC X(1)        VALUE 'S'.          
               10  DBLINK-EMPTY             PIC X(1)        VALUE 'E'.          
               10  DBLINK-EXCLUSIVE         PIC X(1)        VALUE 'E'.          
               10  DBLINK-FIRST             PIC X(1)        VALUE 'F'.          
               10  DBLINK-IF                PIC X(1)        VALUE 'I'.          
               10  DBLINK-DBKEY             PIC X(1)        VALUE 'K'.          
               10  DBLINK-LAST              PIC X(1)        VALUE 'L'.          
               10  DBLINK-MODIFY            PIC X(1)        VALUE 'M'.          
               10  DBLINK-NEXT              PIC X(1)        VALUE 'N'.          
               10  DBLINK-NO                PIC X(1)        VALUE 'N'.          
               10  DBLINK-NONE              PIC X(1)        VALUE 'N'.          
               10  DBLINK-NOT-MEMBER        PIC X(1)        VALUE 'N'.          
               10  DBLINK-OPEN              PIC X(1)        VALUE 'O'.          
               10  DBLINK-PRIOR             PIC X(1)        VALUE 'P'.          
               10  DBLINK-RELOCK            PIC X(1)        VALUE 'R'.          
               10  DBLINK-SHARE             PIC X(1)        VALUE 'S'.          
               10  DBLINK-STORE             PIC X(1)        VALUE 'S'.          
               10  DBLINK-SORTED            PIC X(1)        VALUE 'T'.          
               10  DBLINK-USING             PIC X(1)        VALUE 'U'.          
               10  DBLINK-OWNER             PIC X(1)        VALUE 'W'.          
               10  DBLINK-MEMBER            PIC X(1)        VALUE 'Y'.          
               10  DBLINK-YES               PIC X(1)        VALUE 'Y'.          
               10  DBLINK-CURR              PIC X(1)        VALUE 'Q'.          
               10  DBLINK-CURRENT           PIC X(8)                            
                       VALUE 'CURRENT'.                                         
               10  DBLINK-RESET             PIC X(8)                            
                       VALUE 'RESET'.                                           
               10  DBLINK-OBTAIN            PIC X(8)                            
                       VALUE 'OBTAIN'.                                          
               10  DBLINK-FIND              PIC X(8)                            
                       VALUE 'FIND'.                                            
               10  DBLINK-SET               PIC X(8)                            
                       VALUE 'SET'.                                             
               10  DBLINK-SET-DBKEY         PIC X(8)                            
                       VALUE 'DBKEY'.                                           
               10  DBLINK-SCHEMA            PIC X(8)                            
                       VALUE 'SCHEMA'.                                          
               10  DBLINK-DBKEY-ERROR       PIC X(4)                            
                       VALUE '0302'.                                            
               10  DBLINK-NOT-FOUND         PIC X(4)                            
                       VALUE '0326'.                                            
               10  DBLINK-END-OF-RCDS       PIC X(4)                            
                       VALUE '0307'.                                            
               10  DBLINK-NO-CURRENCY       PIC X(4)                            
                       VALUE '0306'.                                            
               10  DBLINK-NO-CURRENCY-IF-E  PIC X(4)                            
                       VALUE '1606'.                                            
               10  DBLINK-NO-CURRENCY-IF-M  PIC X(4)                            
                       VALUE '1601'.                                            
               10  DBLINK-NO-CURRENCY-SET   PIC X(4)                            
                       VALUE '0306'.                                            
               10  DBLINK-NO-CURRENCY-ERASE PIC X(4)                            
                       VALUE '0225'.                                            
               10  DBLINK-ERASE-NOT-EMPTY   PIC X(4)                            
                       VALUE '0230'.                                            
               10  DBLINK-ERASE-NON-EMPTY   PIC X(4)                            
                       VALUE '0230'.                                            
               10  DBLINK-STORE-DUP         PIC X(4)                            
                       VALUE '1205'.                                            
               10  DBLINK-MODIFY-DUP        PIC X(4)                            
                       VALUE '0805'.                                            
               10  DBLINK-AREA-NOT-READY-IF PIC X(4)                            
                       VALUE '1601'.                                            
               10  DBLINK-ACCEPT-FAIL       PIC X(4)                            
                       VALUE '1500'.                                            
               10  DBLINK-SQL-ERROR         PIC X(4)                            
                       VALUE '9999'.                                            
           05  DBLINK-OTHER-WORK-AREAS.                                         
               10  DBLINK-LOW-VALUES        PIC X(256)      VALUE               
                                                            LOW-VALUES.         
               10  DBLINK-HIGH-VALUES       PIC X(256)      VALUE               
                                                            HIGH-VALUES.        
               10  DBLINK-RUN-DATE.                                             
                   15  DBLINK-RUN-DATE-MO   PIC 9(2).                           
                   15  FILLER               PIC X(1).                           
                   15  DBLINK-RUN-DATE-DY   PIC 9(2).                           
                   15  FILLER               PIC X(1).                           
                   15  DBLINK-RUN-DATE-YR   PIC 9(2).                           
               10  DBLINK-TIME.                                                 
                   15  DBLINK-TIME-N        PIC 9(8)        VALUE ZERO.         
               10  FILLER REDEFINES DBLINK-TIME.                                
                   15  DBLINK-TIME-HR       PIC X(2).                           
                   15  DBLINK-TIME-MIN      PIC X(2).                           
                   15  DBLINK-TIME-SEC      PIC X(2).                           
                   15  DBLINK-TIME-TENTHS   PIC 9(2).                           
               10  DBLINK-CURSOR-NAME-WORK  PIC X(18)       VALUE SPACE.        
               10  DBLINK-HOLD-VIEW         PIC X(600)      VALUE SPACE.        
               10  DBLINK-RESP              PIC S9(4) COMP  VALUE ZERO.         
               10  DBLINK-NOTIFY-VALUE      PIC S9(8) COMP  VALUE ZERO.         
               10  DBLINK-SET-ADDRESS       PIC S9(8) COMP  VALUE ZERO.         
               10  DBLINK-MEMBER-COUNT      PIC S9(8) COMP  VALUE ZERO.         
               10  DBLINK-MEMBER-COUNT-D    PIC S9(8) COMP  VALUE ZERO.         
      *        10  DBLINK-HOLD-ID-KEY       PIC S9(9) COMP  VALUE ZERO.         
               10  DBLINK-INSERT-DBKEY-COUNTER                                  
                                            PIC S9(8) COMP  VALUE ZERO.         
               10  DBLINK-SEQUENCER         PIC S9(9) COMP  VALUE ZERO.         
               10  DBLINK-CURR-PARAGRAPH    PIC X(30)      VALUE SPACE.         
               10  DBLINK-SQL-ERROR-MESSAGE.                                    
                   15  DBLINK-SQL-ERROR-LEN          PIC S9(4) COMP             
                                                           VALUE +960.          
                   15  DBLINK-ERROR-MESSAGE         PIC X(120).                 
                   15  DBLINK-SQL-ERROR-MESSAGE-TEXT PIC X(960)                 
                                                           VALUE SPACE.         
                   15  FILLER REDEFINES DBLINK-SQL-ERROR-MESSAGE-TEXT.          
                       20  DBLINK-SQL-ERROR-TEXT    PIC X(120) OCCURS 8.        
                   15  FILLER REDEFINES DBLINK-SQL-ERROR-MESSAGE-TEXT.          
                       20  DBLINK-SQL-ERROR-TEXTO   PIC X(60) OCCURS 16.        
                   15  DBLINK-SQL-ERROR-TEXT-LEN     PIC S9(9)  COMP            
                       VALUE +120.                                              
               10  DBLINK-ABEND-ROUTINE           PIC X(8) VALUE SPACE.         
               10  DBLINK-RETURN-CODE             PIC 9(9) COMP                 
                           VALUE ZERO.                                          
               10  ZZ-ABEND-CODE REDEFINES DBLINK-RETURN-CODE                   
                                                  PIC S9(8) COMP.               
               10  DBLINK-CLEANUP-CODE            PIC S9(8) COMP                
                           VALUE +0.                                            
               10  DBLINK-SUB                     PIC S9(4) COMP                
                           VALUE +0.                                            
               10  DBLINK-RUN-DATE-2N             PIC 9(6).                     
               10  DBLINK-RUN-DATE-2 REDEFINES                                  
                   DBLINK-RUN-DATE-2N.                                          
                   15  DBLINK-RUN-DATE-2-YR       PIC 9(2).                     
                   15  DBLINK-RUN-DATE-2-MO       PIC 9(2).                     
                   15  DBLINK-RUN-DATE-2-DY       PIC 9(2).                     
               10  DBLINK-DEFAULT-DATE            PIC X(10).                    
               10  DBLINK-DEFAULT-TIME            PIC X(8).                     
               10  DBLINK-LOW-DATE                PIC X(10).                    
               10  DBLINK-HIGH-DATE               PIC X(10).                    
               10  DBLINK-LOW-TIME                PIC X(8).                     
               10  DBLINK-HIGH-TIME               PIC X(8).                     
               10  DBLINK-TIMESTAMP               PIC X(26).                    
               10  DBLINK-ABSTIME                 PIC 9(15).                    
               10  DBLINK-CURR-IO-NUM             PIC 9(4).                     
               10  DBLINK-SAVE-ERROR-STATUS       PIC X(4).                     
               10  DBLINK-NO-CURR-DBKEY           PIC S9(1)                     
                           VALUE -1.                                            
               10  DBLINK-TRUE-FALSE-FLAG         PIC X.                        
                   88  DBLINK-TRUE  VALUE 'T'.                                  
                   88  DBLINK-FALSE VALUE 'F'.                                  
               10  DBLINK-TRUE-FALSE-FLAG1        PIC X.                        
                   88  DBLINK-TRUE1  VALUE 'T'.                                 
                   88  DBLINK-FALSE1 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG2        PIC X.                        
                   88  DBLINK-TRUE2  VALUE 'T'.                                 
                   88  DBLINK-FALSE2 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG3        PIC X.                        
                   88  DBLINK-TRUE3  VALUE 'T'.                                 
                   88  DBLINK-FALSE3 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG4        PIC X.                        
                   88  DBLINK-TRUE4  VALUE 'T'.                                 
                   88  DBLINK-FALSE4 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG5        PIC X.                        
                   88  DBLINK-TRUE5  VALUE 'T'.                                 
                   88  DBLINK-FALSE5 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG6        PIC X.                        
                   88  DBLINK-TRUE6  VALUE 'T'.                                 
                   88  DBLINK-FALSE6 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG7        PIC X.                        
                   88  DBLINK-TRUE7  VALUE 'T'.                                 
                   88  DBLINK-FALSE7 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG8        PIC X.                        
                   88  DBLINK-TRUE8  VALUE 'T'.                                 
                   88  DBLINK-FALSE8 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG9        PIC X.                        
                   88  DBLINK-TRUE9  VALUE 'T'.                                 
                   88  DBLINK-FALSE9 VALUE 'F'.                                 
               10  DBLINK-TRUE-FALSE-FLAG10       PIC X.                        
                   88  DBLINK-TRUE10  VALUE 'T'.                                
                   88  DBLINK-FALSE10 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG11       PIC X.                        
                   88  DBLINK-TRUE11  VALUE 'T'.                                
                   88  DBLINK-FALSE11 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG12       PIC X.                        
                   88  DBLINK-TRUE12  VALUE 'T'.                                
                   88  DBLINK-FALSE12 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG13       PIC X.                        
                   88  DBLINK-TRUE13  VALUE 'T'.                                
                   88  DBLINK-FALSE13 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG14       PIC X.                        
                   88  DBLINK-TRUE14  VALUE 'T'.                                
                   88  DBLINK-FALSE14 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG15       PIC X.                        
                   88  DBLINK-TRUE15  VALUE 'T'.                                
                   88  DBLINK-FALSE15 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG16       PIC X.                        
                   88  DBLINK-TRUE16  VALUE 'T'.                                
                   88  DBLINK-FALSE16 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG17       PIC X.                        
                   88  DBLINK-TRUE17  VALUE 'T'.                                
                   88  DBLINK-FALSE17 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG18       PIC X.                        
                   88  DBLINK-TRUE18  VALUE 'T'.                                
                   88  DBLINK-FALSE18 VALUE 'F'.                                
               10  DBLINK-TRUE-FALSE-FLAG19       PIC X.                        
                   88  DBLINK-TRUE19  VALUE 'T'.                                
                   88  DBLINK-FALSE19 VALUE 'F'.                                
               10  DBLINK-LOW-TIMESTAMP           PIC X(26)                     
                           VALUE '1800-01-01-00.00.00.000000'.                  
               10  DBLINK-HIGH-TIMESTAMP          PIC X(26)                     
                           VALUE '2999-12-31-23.59.59.999999'.                  
               10  DBLINK-NINES                   PIC S9(13) COMP-3             
                           VALUE +9999999999999.                                
               10  DBLINK-MINUS-NINES             PIC S9(13) COMP-3             
                           VALUE -9999999999999.                                
               10  DBLINK-COMP-2-LOW-V      PIC X(2) VALUE X'8000'.             
               10  DBLINK-COMP-2-LOW                                            
                   REDEFINES DBLINK-COMP-2-LOW-V  PIC S9(4) COMP.               
               10  DBLINK-COMP-2-HIGH-V     PIC X(2) VALUE X'7FFF'.             
               10  DBLINK-COMP-2-HIGH                                           
                   REDEFINES DBLINK-COMP-2-HIGH-V PIC S9(4) COMP.               
               10  DBLINK-COMP-4-LOW-V      PIC X(4) VALUE X'80000000'.         
               10  DBLINK-COMP-4-LOW                                            
                   REDEFINES DBLINK-COMP-4-LOW-V  PIC S9(8) COMP.               
               10  DBLINK-COMP-4-HIGH-V     PIC X(4) VALUE X'7FFFFFFF'.         
               10  DBLINK-COMP-4-HIGH                                           
                   REDEFINES DBLINK-COMP-4-HIGH-V PIC S9(8) COMP.               
               10  DBLINK-COMP-8-LOW-V      PIC X(8)                            
                   VALUE X'8000000000000000'.                                   
               10  DBLINK-COMP-8-LOW                                            
                   REDEFINES DBLINK-COMP-8-LOW-V  PIC S9(16) COMP.              
               10  DBLINK-COMP-8-HIGH-V     PIC X(8)                            
                   VALUE X'7FFFFFFFFFFFFFFF'.                                   
               10  DBLINK-COMP-8-HIGH                                           
                   REDEFINES DBLINK-COMP-8-HIGH-V PIC S9(16) COMP.              
      *===================== END CBCVDBWS COPY ========================*        
                                                                                
