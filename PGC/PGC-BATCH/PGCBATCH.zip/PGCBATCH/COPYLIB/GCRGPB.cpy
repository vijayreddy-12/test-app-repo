      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORGPB-RECORD                      10/26/10  17:05  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORGPB-RECORD.                                                     
           05  GWCOEGPB-ACTION-CODE                     PIC X(6).               
           05  GWCOEGPB-GROUP.                                                  
               10  GWCOEGPB-GROUP-NUMBER                PIC 9(7).               
           05  GWCOEGPB-GR-ACCOUNT                      PIC X(3).               
           05  GWCOEGPB-ACCT-EFF-DATE.                                          
               10  FILLERX                    COMP-3    PIC S9(3).              
               10  FILLERX                    COMP-3    PIC S9(3).              
           05  GWCOEGPB-TRANS-EFF-DATE.                                         
               10  GWCOEGPB-TRANS-EFF-YEAR    COMP-3    PIC S9(3).              
               10  GWCOEGPB-TRANS-EFF-DAY     COMP-3    PIC S9(3).              
           05  GWCOEGPB-AGENT-CODE.                                             
               10  GWCOEGPB-AGENT-NUMBER                PIC 9(6).               
           05  GWCOEGPB-AGENT-START-DATE.                                       
               10  FILLERX                    COMP-3    PIC S9(3).              
               10  FILLERX                    COMP-3    PIC S9(3).              
           05  GWCOEGPB-AGENT-PAY-BASIS-FY              PIC X.                  
           05  GWCOEGPB-AGENT-PAY-BASIS-RN              PIC X.                  
           05  GWCOEGPB-RETURN-CODE           COMP      PIC S9(4).              
