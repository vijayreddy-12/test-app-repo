      **************************************************************            
      *   COPY BOOK TO BE USED TO PASS PARAMETERS                               
      *   TO SECURITY PROGRAM GAESECUR                                          
      **************************************************************            
          05  GAESECUR-PROTOCOL.                                                
              10  GAESECUR-RETURN-CODE             PIC X(4).                    
      ***** ---------------------------------------------------- ****           
      *       IF RETURN-CODE > 0 AND < 1000 -- INCORRECT DATA       *           
      *       IF RETURN-CODE > 1000 NO ACCESS TO THE RESOURCE RULE  *           
      ***** ---------------------------------------------------- ****           
              10  GAESECUR-SERVICE                 PIC X(8).                    
                88 GAESECUR-VALID-SERVICE  VALUES 'STAFPLAN'                    
                                                  'DOLLIMIT'                    
                                                  'RESOURCE'                    
                                                  'CLAIMTYP'                    
                                                  'UID'.                        
              10  GAESECUR-OPERATION               PIC X(8).                    
                88 GAESECUR-VALID-OPERATION VALUES 'UPDATE  '                   
                                                   'VIEW    '.                  
              10  GAESECUR-USERID                  PIC X(8).                    
      ***** ---------------------------------------------------- ****           
      *       'Y' TO ASK ACF2 TO SEND SECURITY VIOLATION MESSAGE    *           
      *       'N' YOU SEND THE SECURITY VIOLATION MESSAGE           *           
      *      (IF THE USER HASN'T GOT ACCESS TO THE RESOURCE RULE)   *           
      ***** ---------------------------------------------------- ****           
              10  GAESECUR-SECURITY-ACTION         PIC X.                       
                88 GAESECUR-VALID-SECURITY-ACTION VALUES 'N'                    
                                                         'Y'.                   
              10  GAESECUR-SYSTEM-ID               PIC XX.                      
                88 GAESECUR-VALID-SYSTEM-ID VALUES 'KX'                         
                                                   'GB'                         
                                                   'GC'                         
                                                   'GG'                         
                                                   'GQ'                         
                                                   'GZ'                         
                                                   'GW'.                        
              10  GAESECUR-FILLER                  PIC X.                       
              10  GAESECUR-ARGUMENTS-IN-OUT        PIC X(200).                  
