      *****************************************************************         
      *                       EFT HISTORY                             *         
      *                                                               *         
      * FILENAME    : GWEFRHST                                        *         
      * DATE CREATED: SEPTEMBER 8, 1999                               *         
      * DESCRIPTION : THIS DESCRIBES THE DATA REQUIRED FOR THE HISTORY*         
      *               FILE.                                           *         
      *-HISTORY-----------------------------------------------------  *         
      *  SEQ  DATE       DESIGNER   DESCRIPTION                                 
      *  001  SEP 1999   JEFF YEE   CREATED                                     
BM002 *  002  NOV 1999   MELANSON   RE-FORMATED                                 
      *****************************************************************         
          05 HST-ALT-KEY-STAT-TYPE.                                             
             10 HST-STATUS-CURR-ALT1            PIC X(01).                      
             10 HST-KEY.                                                        
                15 HST-PRE-KEY.                                                 
                   20 HST-RECORD-TYPE.                                          
                      25 HST-SOURCE             PIC X(08).                      
                      25 HST-FUNCTION           PIC X(08).                      
                      25 HST-PROD-LINE          PIC X(08).                      
                         88 HST-ALL-PRODUCTS          VALUE '********'.         
                      25 HST-ADMIN-TYPE         PIC X(02).                      
                         88 HST-ALL-ADMIN-TYPES          VALUE '**'.            
                   20 HST-KEY-TYPE              PIC X(04).                      
                      88 HST-GROUP-ACCOUNT-KEY           VALUE 'GRPA'.          
                      88 HST-GROUP-CERT-KEY              VALUE 'GRPC'.          
                      88 HST-PROVIDER-KEY                VALUE 'PROV'.          
                   20 HST-KEY-DATA              PIC X(20).                      
                15 HST-REC-ID.                                                  
                   20 HST-BATCH-ID.                                             
                      25 HST-SOURCE-ID          PIC X(02).                      
                      25 HST-SOURCE-SEQ         PIC 9(04).                      
                   20 HST-ENTRY-ID              PIC X(09).                      
                15 HST-MNT-SEQ-COMPLEMENT       PIC 9(02).                      
          05 HST-ALT-KEY-STAT-ID.                                               
             10 HST-STATUS                      PIC X(01).                      
                88 HST-VALID-STATUS VALUE 'R' 'S' 'T' 'C' 'F'.                  
                88 HST-REQUEST                            VALUE 'R'.            
                88 HST-SUSPENDED                          VALUE 'S'.            
                88 HST-TRANSMITTED                        VALUE 'T'.            
                88 HST-COMPLETE                           VALUE 'C'.            
                88 HST-FAILED                             VALUE 'F'.            
             10 HST-STATUS-IND                  PIC X(01).                      
                88 HST-CURR-STATUS        VALUE 'C'.                            
                88 HST-PREV-STATUS        VALUE 'P'.                            
             10 HST-REC-ID-ALT2                 PIC X(15).                      
BM002        10 HST-MNT-SEQ-COMPLEMENT-ALT2     PIC 9(02).                      
          05 HST-GENERIC-DATA.                                                  
BM002        10 HST-MNT-DATE                    PIC 9(08).                      
BM002        10 HST-MNT-TIME                    PIC 9(08).                      
             10 HST-FILE-SEQ                    PIC 9(04).                      
             10 HST-DUE-DATE                    PIC 9(08).                      
             10 HST-AMOUNT                      PIC S9(07)V99.                  
             10 HST-REASON-CODE                 PIC X(03).                      
                88 HST-VALID-REASON     VALUE 'SRQ' 'NSF' 'BBI' 'OTH'           
                                              'REP' 'FOE' 'FCE' 'VOI'           
                                              'REV'                  .          
                88 HST-SYSTEM-REQUEST                     VALUE 'SRQ'.          
                88 HST-NSF                                VALUE 'NSF'.          
                88 HST-BAD-BANK-INFO                      VALUE 'BBI'.          
                88 HST-OTHER                              VALUE 'OTH'.          
                88 HST-REPRESENTED                        VALUE 'REP'.          
                88 HST-FIXED-OUR-ERROR                    VALUE 'FOE'.          
                88 HST-FIXED-CLIENT-ERROR                 VALUE 'FCE'.          
                88 HST-RECORD-VOIDED                      VALUE 'VOI'.          
                88 HST-REVERSED                           VALUE 'REV'.          
             10 HST-COMMENT-TEXT                PIC X(80).                      
             10 HST-MAINTAINER-ID               PIC X(08).                      
                88  HST-BANK-RETURN-MOD VALUE 'GWEFCRTN'.                       
                88  HST-PAD-REQUEST-MOD VALUE 'GWEFCPDR'.                       
                88  HST-TRANSMIT-MOD    VALUE 'GWEFCTRN'.                       
             10 HST-APPROVER-ID                 PIC X(08).                      
             10 HST-CUSTOMER-NAME               PIC X(30).                      
          05 HST-BANK-DATA.                                                     
             10 HST-DEBIT.                                                      
                15 HST-DR-CURRENCY              PIC X(03).                      
                15 HST-DR-ACCOUNT-TYPE          PIC X(02).                      
                   88 HST-DR-BANK-ACCOUNT                 VALUE 'BA'.           
                   88 HST-DR-CREDIT-CARD                  VALUE 'CC'.           
                   88 HST-DR-INVESTMENT-ACCOUNT           VALUE 'IA'.           
                15 HST-DR-ACCOUNT               PIC X(30).                      
                15 FILLER REDEFINES HST-DR-ACCOUNT.                             
                   20 HST-DR-BANK-NUM           PIC 9(04).                      
                   20 HST-DR-TRANSIT-NUM        PIC 9(05).                      
                   20 HST-DR-ACCOUNT-NUM        PIC X(18).                      
             10 HST-CREDIT.                                                     
                15 HST-CR-CURRENCY              PIC X(03).                      
                15 HST-CR-ACCOUNT-TYPE          PIC X(02).                      
                   88 HST-CR-BANK-ACCOUNT                 VALUE 'BA'.           
                   88 HST-CR-CREDIT-CARD                  VALUE 'CC'.           
                   88 HST-CR-INVESTMENT-ACCOUNT           VALUE 'IA'.           
                15 HST-CR-ACCOUNT                PIC X(30).                     
                15 FILLER REDEFINES HST-CR-ACCOUNT.                             
                   20 HST-CR-BANK-NUM           PIC 9(04).                      
                   20 HST-CR-TRANSIT-NUM        PIC 9(05).                      
                   20 HST-CR-ACCOUNT-NUM        PIC X(18).                      
             10 HST-RETURN.                                                     
                15 HST-RT-CURRENCY              PIC X(03).                      
                15 HST-RT-BANK-NUM              PIC 9(04).                      
                15 HST-RT-TRANSIT-NUM           PIC 9(05).                      
                15 HST-RT-ACCOUNT-NUM           PIC X(18).                      
          05 FILLER                             PIC X(74).                      
