      *****************************************************************         
      *              EFT REQUEST FILE HEADER/TRAILER                  *         
      *                                                               *         
      * FILENAME    :  QWEFIRQF                                       *         
      * DATE CREATED:  SEPTEMBER 17, 1999                             *         
      * DESCRIPTION :  DESCRIBES THE INFORMATION AVAILABLE IN THE     *         
      *                TRAILER OF THE REQUEST FILE                    *         
      *-HISTORY-----------------------------------------------------  *         
      *  SEQ  DATE       DESIGNER   DESCRIPTION                       *         
      *  001  SEP 1999   JEFF YEE   CREATED                           *         
      *****************************************************************         
          05 EFTREQ-RECORD-TYPE                      PIC X(12).                 
             88  EFTREQ-HEADER  VALUE 'EFT HEADER  '.                           
             88  EFTREQ-TRAILER VALUE 'EFT TRAILER '.                           
          05 EFTREQ-BATCH-ID.                                                   
             10 EFTREQ-SOURCE-ID                     PIC X(02).                 
             10 EFTREQ-SOURCE-SEQ                    PIC 9(04).                 
          05 EFTREQ-PREV-INFO.                                                  
             10 EFTREQ-PREV-DATE                     PIC 9(08).                 
             10 EFTREQ-PREV-SEQ                      PIC 9(04).                 
          05 EFTREQ-CURR-INFO.                                                  
             10 EFTREQ-CURR-DATE                     PIC 9(08).                 
             10 EFTREQ-CURR-SEQ                      PIC 9(04).                 
          05 EFTREQ-HEADER-FILLER                    PIC X(385).                
          05 EFTREQ-TRAILER-DATA REDEFINES EFTREQ-HEADER-FILLER.                
             10 EFTREQ-TOTAL-RECORDS                 PIC 9(09).                 
             10 EFTREQ-TOTAL-AMOUNT                  PIC S9(10)V9(02).          
             10 EFTREQ-TRAILER-FILLER                PIC X(364).                
