        01  GFMBILLING-EXCEPTIONS.                                              
      *****************************************************************         
      *     GIPSY BILLING EXCEPTIONS RECORD                           *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *       CREATED BY GFMEDD90                                     *         
      *                  GFMINTM4                                     *         
      *       USED    BY GPRBILEX                                     *         
      *                                                               *         
      *       REC TYPE     'V'                                        *         
      *       REC LENGTH   728 FROM D90                               *         
      *                    643 FROM INTM4                             *         
      *****************************************************************         
            05  GFMBE-RECORD-LENGTH         COMP SYNC PIC S9(4).                
            05  FILLER                                PIC XX.                   
            05  GFMBE-RECORD-TYPE                     PIC X.                    
GNE         05  GFMBE-GROUP-NUMBER          COMP-3    PIC S9(7).                
            05  GFMBE-ACCOUNT                         PIC XXX.                  
            05  GFMBE-ORDER                           PIC X.                    
            05  GFMBE-D90-DATA.                                                 
                10  GFMBE-D90-CERTIFICATE   COMP-3    PIC S9(9).                
                10  GFMBE-D90-REMARKS                 PIC X(20).                
                10  GFMBE-D90-EFFECTIVE-DATE COMP-3.                            
                    15  GFMBE-D90-EFFECTIVE-YEAR      PIC S9(3).                
                    15  GFMBE-D90-EFFECTIVE-DAY       PIC S9(3).                
                10  GFMBE-D90-NO-OF-CODES   COMP-3    PIC S9(3).                
                10  GFMBE-D90-COVERAGE-INFO OCCURS 3 TIMES.                     
                    15  GFMBE-D90-CODE      COMP-3    PIC S9(3).                
                    15  GFMBE-D90-PREM-ADJ  COMP-3    PIC S9(7)V99.             
GNE             10  FILLER                            PIC X(624).               
            05  GFMBE-STATISTICS-DATA REDEFINES GFMBE-D90-DATA.                 
                10  GFMBE-STAT-PREMIUMS     COMP-3.                             
                    15  GFMBE-PREM-LIFE               PIC S9(7)V99.             
                    15  GFMBE-PREM-LTD                PIC S9(7)V99.             
                    15  GFMBE-PREM-ADD                PIC S9(7)V99.             
                    15  GFMBE-PREM-WI                 PIC S9(7)V99.             
                    15  GFMBE-PREM-EHC-SIN            PIC S9(7)V99.             
                    15  GFMBE-PREM-EHC-FAM1           PIC S9(7)V99.             
                    15  GFMBE-PREM-EHC-FAM2           PIC S9(7)V99.             
                    15  GFMBE-PREM-DEN-SIN            PIC S9(7)V99.             
                    15  GFMBE-PREM-DEN-FAM1           PIC S9(7)V99.             
                    15  GFMBE-PREM-DEN-FAM2           PIC S9(7)V99.             
                10  GFMBE-STAT-PREMIUM-ADJUSTMENTS COMP-3.                      
                    15  GFMBE-PADJ-LIFE               PIC S9(7)V99.             
                    15  GFMBE-PADJ-LTD                PIC S9(7)V99.             
                    15  GFMBE-PADJ-ADD                PIC S9(7)V99.             
                    15  GFMBE-PADJ-WI                 PIC S9(7)V99.             
                    15  GFMBE-PADJ-EHC-SIN            PIC S9(7)V99.             
                    15  GFMBE-PADJ-EHC-FAM1           PIC S9(7)V99.             
                    15  GFMBE-PADJ-EHC-FAM2           PIC S9(7)V99.             
                    15  GFMBE-PADJ-DEN-SIN            PIC S9(7)V99.             
                    15  GFMBE-PADJ-DEN-FAM1           PIC S9(7)V99.             
                    15  GFMBE-PADJ-DEN-FAM2           PIC S9(7)V99.             
                10  GFMBE-STAT-INSURED-LIVES  COMP-3  PIC S9(7).                
                10  GFMBE-STAT-NO-OF-CODES    COMP-3  PIC S9(3).                
                10  GFMBE-STAT-COV-INFO OCCURS 15 TIMES.                        
                    15  GFMBE-STAT-COVERAGE-CODE COMP-3 PIC S9(3).              
                    15  GFMBE-STAT-VOLUME        COMP-3 PIC S9(9).              
                    15  GFMBE-STAT-LIVES         COMP-3 PIC S9(7).              
            08  GFMBE-BILLING-INFO.                                             
                10  GFMBE-BILL-PREPARED-DATE COMP-3.                            
                    15  GFMBE-BILL-PREPARED-YEAR      PIC S9(3).                
                    15  GFMBE-BILL-PREPARED-DAY       PIC S9(3).                
                10  GFMBE-BILL-PREMIUM-DUE  COMP-3    PIC S9(7)V99.             
                10  GFMBE-BILL-INSURED-LIVES COMP-3   PIC S9(7).                
                10  GFMBE-BILL-ADMIN-FEE    COMP-3    PIC S9(7)V99.             
                10  GFMBE-BILL-NO-OF-CODES  COMP-3    PIC S9(3).                
                10  GFMBE-BILL-COV-INFO.                                        
                  12  GFMBE-COV-INFO OCCURS 15 TIMES.                           
                    15  GFMBE-BILL-COV-CODE COMP-3    PIC S9(3).                
                    15  GFMBE-BILL-AMT-BILLED COMP-3  PIC S9(7)V99.             
                    15  GFMBE-BILL-D90-ADJ    COMP-3  PIC S9(7)V99.             
                    15  GFMBE-BILL-LIVES      COMP-3  PIC S9(7).                
                    15  GFMBE-BILL-VOLUME     COMP-3  PIC S9(9).                
                10  FILLER                            PIC X(25).                
            05  GFMBE-REVISED-BILLING REDEFINES GFMBE-D90-DATA.                 
                10  GFMBE-REV-BILL-PREM-DUE-DATE COMP-3.                        
                    15  GFMBE-REV-BILL-PREM-DUE-YEAR      PIC S9(3).            
                    15  GFMBE-REV-BILL-PREM-DUE-DAY       PIC S9(3).            
                10  GFMBE-REV-BILL-PREPARED-DATE COMP-3.                        
                    15  GFMBE-REV-BILL-PREPARED-YEAR      PIC S9(3).            
                    15  GFMBE-REV-BILL-PREPARED-DAY       PIC S9(3).            
                10  GFMBE-REV-BILL-PREMIUM-DUE  COMP-3    PIC S9(7)V99.         
                10  GFMBE-REV-BILL-NO-CERTS     COMP-3    PIC S9(7).            
                10  GFMBE-REV-BILL-ADMIN-FEE    COMP-3    PIC S9(7)V99.         
                10  GFMBE-REV-BILL-NO-OF-CODES  COMP-3    PIC S9(3).            
                10  GFMBE-REV-BILL-COV-INFO OCCURS 10 TIMES.                    
                    15  GFMBE-REV-BILL-COV-CODE COMP-3    PIC S9(3).            
                    15  GFMBE-REV-BILL-AMT-BILLED COMP-3  PIC S9(7)V99.         
                    15  GFMBE-REV-BILL-LIVES      COMP-3  PIC S9(5).            
                    15  GFMBE-REV-BILL-VOLUME     COMP-3  PIC S9(9).            
                10  FILLER                            PIC X(25).                
            05  GFMBE-BILLING-HIST-IMBALANCE REDEFINES GFMBE-D90-DATA.          
                10  GFMBE-BILL-IMB-PREM-DUE-DATE COMP-3.                        
                    15  GFMBE-BILL-IMB-PREM-DUE-YEAR      PIC S9(3).            
                    15  GFMBE-BILL-IMB-PREM-DUE-DAY       PIC S9(3).            
                10  GFMBE-BILL-IMB-PREPARED-DATE COMP-3.                        
                    15  GFMBE-BILL-IMB-PREPARED-YEAR      PIC S9(3).            
                    15  GFMBE-BILL-IMB-PREPARED-DAY       PIC S9(3).            
                10  GFMBE-BILL-IMB-PREMIUM-DUE  COMP-3    PIC S9(7)V99.         
                10  GFMBE-BILL-IMB-NO-CERTS     COMP-3    PIC S9(7).            
                10  GFMBE-BILL-IMB-ADMIN-FEE    COMP-3    PIC S9(7)V99.         
                10  GFMBE-BILL-IMB-NO-OF-CODES  COMP-3    PIC S9(3).            
                10  GFMBE-BILL-IMB-COV-INFO OCCURS 10 TIMES.                    
                    15  GFMBE-BILL-IMB-COV-CODE COMP-3    PIC S9(3).            
                    15  GFMBE-BILL-IMB-AMT-BILLED COMP-3  PIC S9(7)V99.         
                    15  GFMBE-BILL-IMB-LIVES      COMP-3  PIC S9(5).            
                    15  GFMBE-BILL-IMB-VOLUME     COMP-3  PIC S9(9).            
            08  GFMBE-BILLING-CALC-INFO.                                        
                10  GFMBE-BCI-PREPARED-DATE COMP-3.                             
                    15  GFMBE-BCI-PREPARED-YEAR      PIC S9(3).                 
                    15  GFMBE-BCI-PREPARED-DAY       PIC S9(3).                 
                10  GFMBE-BCI-PREMIUM-DUE  COMP-3    PIC S9(7)V99.              
                10  GFMBE-BCI-INSURED-LIVES COMP-3   PIC S9(7).                 
                10  GFMBE-BCI-ADMIN-FEE    COMP-3    PIC S9(7)V99.              
                10  GFMBE-BCI-NO-OF-CODES  COMP-3    PIC S9(3).                 
                10  GFMBE-BCI-COV-INFO.                                         
                  12  GFMBE-COV-INFO OCCURS 15 TIMES.                           
                    15  GFMBE-BCI-COV-CODE COMP-3    PIC S9(3).                 
                    15  GFMBE-BCI-AMT-BILLED COMP-3  PIC S9(7)V99.              
                    15  GFMBE-BCI-D90-ADJ    COMP-3  PIC S9(7)V99.              
                    15  GFMBE-BCI-LIVES      COMP-3  PIC S9(7).                 
                    15  GFMBE-BCI-VOLUME     COMP-3  PIC S9(9).                 
                10  FILLER                            PIC X(25).                
