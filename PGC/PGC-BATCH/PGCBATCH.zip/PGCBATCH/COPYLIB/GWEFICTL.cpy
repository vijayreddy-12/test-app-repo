      *****************************************************************         
      *                     CONTROL RECORD                            *         
      *                                                               *         
      * FILENAME    :  GWEFICTL                                       *         
      * DATE CREATED:  SEPTEMBER 17, 1999                             *         
      * DESCRIPTION :  DESCRIBES THE DATA WITHIN THE CONTROL FILE READ*         
      *                BY THE PAD REQUEST & PAD LOAD PROGRAMS.        *         
      *                         (GWEFCPDR & GWEFCPDL)                 *         
      *-HISTORY-----------------------------------------------------  *         
      *  SEQ  DATE       DESIGNER   DESCRIPTION                       *         
      *  001  SEP 1999   JEFF YEE   CREATED                           *         
      *****************************************************************         
          05 CTRL-RECORD-TYPE                                 PIC X(04).        
             88 CTRL-PAD-REQUEST                        VALUE 'REQ'.            
             88 CTRL-PAD-LOAD                           VALUE 'LOAD'.           
          05 CTRL-PAD-REQ-LOAD.                                                 
             10 CTRL-BATCH-ID.                                                  
                15 CTRL-SOURCE-ID                             PIC X(02).        
                15 CTRL-SOURCE-SEQ                            PIC 9(04).        
             10 CTRL-PREV-DATE                                PIC 9(08).        
             10 CTRL-PREV-SEQ                                 PIC 9(04).        
