       01  GPRMXTR7.                                                            
      ******************************************************************        
      *          PREMIUM HISTORY EXTRACT RECORD                                 
      ******************************************************************        
      *    NOV/90 M. PRANGE.                                                    
      *         - RENAMED GPXT-NEXT-ANNIVERSARY-DATE TO                         
      *                   GPXT-NEXT-RECON-DATE                                  
      *         - ADDED GPXT-RECON-DATE-IND (A = ANNIV, R = RENEWAL)            
      ******************************************************************        
           05  GPXT-AGENT-COMP-KEY.                                             
               10  GPXT-GROUP-ACCOUNT.                                          
REN                15  GPXT-GROUP-NUMBER              PIC X(7).                 
                   15  GPXT-GR-ACCOUNT                PIC X(3).                 
               10  GPXT-REC-TYPE                      PIC X.                    
               10  GPXT-GROUP-COMP-KEY.                                         
                   15  GPXT-PREM-DUE-DATE.                                      
                       20  GPXT-PREM-DUE-YEAR  COMP-3 PIC S9(3).                
                       20  GPXT-PREM-DUE-DAY   COMP-3 PIC S9(3).                
           05  GPXT-PREM-AMT                   COMP-3 PIC S9(9)V99.             
           05  GPXT-COV-TYPE                          PIC X.                    
           05  GPXT-NEXT-RECON-DATE.                                            
               10  GPXT-NEXT-RECON-YEAR        COMP-3 PIC S9(3).                
               10  GPXT-NEXT-RECON-DAY         COMP-3 PIC S9(3).                
           05  GPXT-ACCT-EFFECTIVE-DATE.                                        
               10  GPXT-ACCT-EFFECTIVE-YEAR    COMP-3 PIC S9(3).                
               10  GPXT-ACCT-EFFECTIVE-DAY     COMP-3 PIC S9(3).                
           05  GPXT-NEXT-RECON-IND                    PIC X(1).                 
           05  FILLER                                 PIC X(48).                
