       01  GCSLPARM.                                                            
      ******************************************************************        
      *    PARAMETERS FOR GCSLDATS (COMMISSION SCALE TABLES ACCESS)             
      ******************************************************************        
           05  GCSL-CALL-TYPE             PIC X(1).                             
               88  GCSL-ADD-CALL                    VALUE 'A'.                  
               88  GCSL-RETRIEVE-CALL               VALUE 'R'.                  
               88  GCSL-LAST-CALL                   VALUE 'L'.                  
           05  GCSL-SCALE-CODE            PIC X(3).                             
           05  GCSL-START-YEAR            PIC 9(3).                             
      *                                                                         
           05  GCSL-RETURN-AREA.                                                
               10  GCSL-RET-CODE          PIC X(1).                             
                   88  GCSL-RET-SUCCESS             VALUE '0'.                  
                   88  GCSL-RET-FAILURE             VALUE '1'.                  
