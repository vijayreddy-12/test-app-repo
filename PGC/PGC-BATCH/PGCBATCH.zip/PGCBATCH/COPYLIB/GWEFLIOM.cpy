      *****************************************************************         
      *                 I/O PARMS - MAIN MODULE                       *         
      *                                                               *         
      * FILENAME    :  GWEFLIOM                                       *         
      * DATE CREATED:  SEPTEMBER 8, 1999                              *         
      * DESCRIPTION :  DESCRIBES THE DATA REQUIRED (LINKAGE SECTION)  *         
      *                SENT TO THE EFT I/O MAINLINES                  *         
      *---                                                            *         
      *   THE KEY DATA FIELDS FROM BOTH BANK INFO AND EFT HISTORY ARE *         
      * SIMILAR, AND THIS DATA CAN BE RETAINED BETWEEN CALLS FROM EACH*         
      *NOTE: IT IS THE RESPONSABILITY OF THE PROGRAMMER TO DETERMINE  *         
      *      WHEN THE FIELDS ARE TO BE RE-SET.                        *         
      *---                                                            *         
      * SUB FIELDS OF VARIOUS KEYS IN THIS MEMBER ARE STORED ON THE   *         
      * RECORD IN COMPLEMENTED FORM.  THIS IS TO ENSURE THAT KEYS ARE *         
      * IN REVERSE CHRONOLOGICAL ORDER (LAST IN/FIRST OUT)            *         
      *    IN THIS MEMBER, HOWEVER, THESE FIELDS ARE NOT STORED IN THE*         
      * COMPLEMENTED FORM.                                            *         
      *-HISTORY-----------------------------------------------------  *         
      *  SEQ  DATE       DESIGNER   DESCRIPTION                                 
      *  001  SEP 1999   JEFF YEE   CREATED                                     
BM002 *  002  NOV 1999   MELANSON   -ADDED VERBS 'NEXT SEQ' PREV SEQ'           
      *       JAN 2000   MELANSON   -REMOVED ELEMENTS FOR OBSOLETE KEY          
      *****************************************************************         
           05 EFT-IOM-KEY                          PIC X(05).                   
              88 EFT-IOM-MAIN             VALUE 'MAIN '.                        
              88 EFT-IOM-BY-STAT-TYPE     VALUE 'STATT'.                        
              88 EFT-IOM-BY-STAT-ID       VALUE 'STATI'.                        
           05 EFT-IOM-VERB                         PIC X(03).                   
              88 EFT-IOM-OPEN-FILE        VALUE 'OP '.                          
              88 EFT-IOM-READ-KEYED       VALUE 'RK '.                          
              88 EFT-IOM-START-BROWSE     VALUE 'SB '.                          
              88 EFT-IOM-READ-FIRST       VALUE 'RF '.                          
              88 EFT-IOM-READ-NEXT        VALUE 'RN '.                          
              88 EFT-IOM-READ-NEXT-THREAD VALUE 'RNT'.                          
              88 EFT-IOM-READ-NEXT-VALID  VALUE 'RNV'.                          
              88 EFT-IOM-READ-PREV        VALUE 'RP '.                          
              88 EFT-IOM-READ-PREV-THREAD VALUE 'RPT'.                          
              88 EFT-IOM-READ-PREV-VALID  VALUE 'RPV'.                          
              88 EFT-IOM-END-BROWSE       VALUE 'EB '.                          
              88 EFT-IOM-WRITE            VALUE 'WR '.                          
              88 EFT-IOM-RE-WRITE         VALUE 'RWR'.                          
              88 EFT-IOM-UPDATE           VALUE 'UD '.                          
              88 EFT-IOM-DELETE           VALUE 'DEL'.                          
              88 EFT-IOM-CLOSE-FILE       VALUE 'CF '.                          
           05 EFT-IOM-INPUT-KEY-DATA.                                           
              10 EFT-IOM-COMMON-KEY-FIELDS.                                     
                 15 EFT-IOM-RECORD-TYPE            PIC X(26).                   
                 15 EFT-IOM-KEY-TYPE               PIC X(04).                   
                 15 EFT-IOM-KEY-DATA               PIC X(20).                   
              10 BNK-IOM-KEY-DATA.                                              
                 15 BNK-IOM-EFF-DATE               PIC 9(08).                   
                 15 BNK-IOM-MNT-DATE               PIC 9(08).                   
                 15 BNK-IOM-MNT-SEQ                PIC 9(02).                   
              10 HST-IOM-KEY-DATA.                                              
                 15 HST-IOM-REC-ID                 PIC X(15).                   
                 15 HST-IOM-MNT-SEQ                PIC 9(02).                   
                 15 HST-IOM-ALT-KEY-DATA.                                       
                    25 HST-IOM-STATUS              PIC X(01).                   
                    25 HST-IOM-STATUS-IND          PIC X(01).                   
           05 EFT-IOM-ERROR-DATA.                                               
              10 EFT-IOM-STATUS                     PIC X(02).                  
                88 EFT-IOM-STATUS-OK      VALUE 'OK'.                           
                88 EFT-IOM-ERROR   VALUE 'ER' 'NF' 'NS' 'WR' 'DR' 'SB'          
                                    'RN' 'RP' 'EB' 'LE' 'R ' 'RW' 'BD'          
                                    'BK'                                        
                                   .                                            
                88 EFT-IOM-NOT-FOUND       VALUE 'NF'.                          
                88 EFT-IOM-NOT-SUPPORTED   VALUE 'NS'.                          
                88 EFT-IOM-WRITE-FAILED    VALUE 'WR'.                          
                88 EFT-IOM-DUP-RECORD      VALUE 'DR'.                          
                88 EFT-IOM-STARTBR-FAILED  VALUE 'SB'.                          
                88 EFT-IOM-READNEXT-FAILED VALUE 'RN'.                          
                88 EFT-IOM-READPREV-FAILED VALUE 'RP'.                          
                88 EFT-IOM-ENDBR-FAILED    VALUE 'EB'.                          
                88 EFT-IOM-LOGIC-ERROR     VALUE 'LE'.                          
                88 EFT-IOM-READ-FAILED     VALUE 'R '.                          
                88 EFT-IOM-REWRITE-FAILED  VALUE 'RW'.                          
                88 EFT-IOM-BAD-DATA        VALUE 'BD'.                          
                88 EFT-IOM-BAD-KEY         VALUE 'BK'.                          
             10 EFT-IOM-ERROR-TEXT                 PIC X(50).                   
           05 EFT-IOM-RECORD-DATA                  PIC X(500).                  
