       01  GCOMRLSE.                                                            
      *****************************************************************         
      *                                                               *         
      *          GIPSY COMMISSION RELEASE RECORD                      *         
      *                                                               *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *       CREATED BY GFMACCOM & GFMCOMMS                          *         
      *                                                               *         
      *       REC TYPE     'D,W'                                      *         
      *       REC LENGTH   316  (WAS 315)                             *         
      *                                                               *         
      *************************************************************** *         
      * JUN90 - A SCHLEICHER - CHANGED COPYBOOK TO ACCOMIDATE NEW     *         
      *                        FIELDS & CHANGES FROM AGENCY           *         
      * FEB11 - C MUNCAN     - UPDATED TO 7 DIGIT GROUP NUMBER AND    *         
      *                        UPDATED RECORD LENGTH                  *         
      *                                                               *         
      *****************************************************************         
REN        05  GCRL-RECORD-LENGTH   VALUE +316 COMP   PIC S9(4).        00008000
           05  GCRL-FILLER          VALUE LOW-VALUES  PIC XX.           00009000
           05  GCRL-RECORD-TYPE     VALUE SPACES      PIC X.            00010000
           05  GCRL-KEY.                                                00010100
               10  GCRL-KEY-GROUP   VALUE +0 COMP-3   PIC S9(7).        00010200
               10  GCRL-KEY-ACCOUNT VALUE SPACES      PIC X(3).         00010300
               10  GCRL-KEY-AGENT   VALUE +0 COMP-3   PIC S9(6).        00010400
           05  GCRL-VLNO            VALUE +0 COMP-3   PIC S9(3).        00011000
           05  GCRL-GROUP           VALUE +0 COMP-3   PIC S9(15).       00012000
           05  GCRL-SUB-ACCOUNT     VALUE SPACES      PIC X(4).         00012000
           05  GCRL-FUND            VALUE +0 COMP-3   PIC S9(3).        00013000
           05  GCRL-LBUS            VALUE +0          PIC S9(2).        00014000
           05  GCRL-PLAN-TYPE       VALUE +0          PIC S9.           00015000
           05  GCRL-POLSPEX         VALUE +0 COMP-3   PIC S9(9).        00016000
           05  GCRL-BRANCH          VALUE +0 COMP-3   PIC S9(5).        00017000
           05  GCRL-CURRENCY        VALUE +0 COMP-3   PIC S9(2).        00018000
           05  GCRL-MODE            VALUE +0 COMP-3   PIC S9(2).        00019000
           05  GCRL-BILCL           VALUE +0          PIC S9.           00020000
           05  GCRL-ACCT-EFFECTIVE-DATE.                                00030000
               10  GCRL-EFF-CC      VALUE 0           PIC 99.           00040000
               10  GCRL-EFF-YY      VALUE 0           PIC 99.           00040000
               10  GCRL-EFF-MM      VALUE 0           PIC 99.           00040000
               10  GCRL-EFF-DD      VALUE 0           PIC 99.           00040000
           05  GCRL-BILLING-NAME    VALUE SPACES      PIC X(25).        00060000
           05  GCRL-PREMNO          VALUE +0 COMP-3   PIC S9(3).        00070000
           05  GCRL-PRORATEMO       VALUE +0 COMP-3   PIC S9(2).        00080000
           05  GCRL-PREM-DUE-DATE.                                      00090000
               10  GCRL-PREM-CC     VALUE 0           PIC 99.           00040000
               10  GCRL-PREM-YY     VALUE 0           PIC 99.           00040000
               10  GCRL-PREM-MM     VALUE 0           PIC 99.           00040000
               10  GCRL-PREM-DD     VALUE 0           PIC 99.           00040000
           05  GCRL-PMOD            VALUE +0 COMP-3   PIC S9.           00100000
           05  GCRL-MAN             VALUE +0 COMP-3   PIC S9(5).        00110000
           05  GCRL-SPCL            VALUE +0          PIC S9(2).        00120000
           05  GCRL-UNDCL           VALUE +0          PIC S9(2).        00130000
           05  GCRL-SEX             VALUE +0 COMP-3   PIC S9.           00140000
           05  GCRL-CEDED           VALUE +0 COMP-3   PIC S9.           00150000
           05  GCRL-SCALE           VALUE SPACES      PIC X(3).         00150000
           05  GCRL-TRANSFER-CODE.                                      00160000
               10  GCRL-TRAN-BALYR  VALUE  0 COMP-3   PIC 9.            00170000
               10  GCRL-TRAN-REASON VALUE  0 COMP-3   PIC 9(2).         00180000
           05  GCRL-TRANSFER-DATE.                                      00190000
               10  GCRL-TRAN-CC     VALUE 0           PIC 99.           00040000
               10  GCRL-TRAN-YY     VALUE 0           PIC 99.           00040000
               10  GCRL-TRAN-MM     VALUE 0           PIC 99.           00040000
               10  GCRL-TRAN-DD     VALUE 0           PIC 99.           00040000
           05  GCRL-FOGL-CODE       VALUE 0           PIC 9(10).        00200000
           05  FILLER               VALUE ZERO        PIC 9(16).        00201000
           05  FILLER               VALUE SPACES      PIC X(5).         00201000
           05  GCRL-DIRCOMIND       VALUE 'G'         PIC X.            00220000
           05  GCRL-AGENT-DATA COMP-3.                                  00230000
               10  GCRL-AGENT-CODE  VALUE +0          PIC S9(6).        00240000
               10  GCRL-CONTRACT-TYPE   VALUE +0      PIC S9(3).        00241000
               10  GCRL-CLASS           VALUE  0      PIC 9(3).         00241000
               10  GCRL-MGR         VALUE +0          PIC S9(3).        00242000
               10  GCRL-SHARE       VALUE +0          PIC S9(3)V99.     00243000
               10  GCRL-ASSIGNEE    VALUE +0          PIC S9(5).        00244000
               10  GCRL-CAUSE       VALUE +0          PIC S9(3).        00245000
               10  GCRL-PARTICULARS-CODE VALUE +0     PIC S9(5).        00245000
           05  GCRL-UNIQUE-ID.                                          00250000
               10  GCRL-SOURCE      VALUE 0           PIC 99.           00250000
               10  GCRL-RECEIVE-DATE.                                   00030000
                   15  GCRL-REC-CENTURY VALUE 0       PIC 99.           00040000
                   15  GCRL-REC-YEAR    VALUE 0       PIC 99.           00040000
                   15  GCRL-REC-MONTH   VALUE 0       PIC 99.           00040000
                   15  GCRL-REC-DAY     VALUE 0       PIC 99.           00040000
               10  GCRL-AUDIT-NUMBER    VALUE 0 COMP-3 PIC 9(5).        00250000
               10  GCRL-AUDIT-TYPE      VALUE 0        PIC 9.           00250000
           05  GCRL-PROCESS-DETAILS.                                    00250000
               10  GCRL-STATUS          VALUE 0        PIC 99.          00250000
               10  GCRL-ERROR-CODE      VALUE 0 COMP-3 PIC 9(5).        00250000
               10  GCRL-PROCESS-DATE.                                   00030000
                   15  GCRL-PROC-CC     VALUE 0        PIC 99.          00040000
                   15  GCRL-PROC-YY     VALUE 0        PIC 99.          00040000
                   15  GCRL-PROC-MM     VALUE 0        PIC 99.          00040000
                   15  GCRL-PROC-DD     VALUE 0        PIC 99.          00040000
               10  GCRL-END-DATE.                                       00030000
                   15  GCRL-END-CC      VALUE 0        PIC 99.          00040000
                   15  GCRL-END-YY      VALUE 0        PIC 99.          00040000
                   15  GCRL-END-MM      VALUE 0        PIC 99.          00040000
                   15  GCRL-END-DD      VALUE 0        PIC 99.          00040000
           05  FILLER                   VALUE SPACES   PIC X(31).               
           05  GCRL-VARS.                                               00250000
               10  GCRL-VARIABLE-DATA COMP-3 OCCURS 10 TIMES.           00260000
                   15  GCRL-CODE                       PIC S9(3).       00270000
                   15  GCRL-CRAMT                      PIC S9(11).      00280000
                   15  GCRL-CCAMT REDEFINES GCRL-CRAMT PIC S9(10)V9.    00280000
                   15  GCRL-CMAMT REDEFINES GCRL-CRAMT PIC S9(09)V99.   00280000
                   15  GCRL-CPAMT REDEFINES GCRL-CRAMT PIC S9(06)V9(5). 00280000
