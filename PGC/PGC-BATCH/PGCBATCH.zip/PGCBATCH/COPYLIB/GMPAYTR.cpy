       01  GMPAYTR.                                                     00001000
               05  GPATRIDENT                      PIC XXX.             00002000
               05  GPALENGTH           COMP-3      PIC S9(5).           00003000
               05  GPAUNDEFINED                    PIC X(20).           00004000
               05  GPAPAYMENT-INFO OCCURS 60 TIMES.                     00005000
                   07  GPAPAYMENT-DATE COMP-3.                          00006000
                       09  GPAPAY-YEAR             PIC S9(3).           00007000
                       09  GPAPAY-DAY              PIC S9(3).           00008000
                   07  GPAPAY-AMOUNT   COMP-3      PIC S9(7)V99.        00009000
                   07  GPAPAY-TYPE                 PIC X.               00010000
                   07  GPAPAY-APPLIED-DATE COMP-3.                      00011000
                       09  GPAPAY-APP-YEAR         PIC S9(3).           00012000
                       09  GPAPAY-APP-DAY          PIC S9(3).           00013000
