      ******************************************************************        
      *                                                                *        
      *          NAPS - RECONCILIATION EXTRACT RECORD                  *        
      *                                                                *        
      ******************************************************************        
       01  EXT-RECON-NAP-RECORD.                                                
           05  EXT-NAP-SORT-KEY.                                                
REN            10  EXT-NAP-GROUP-NUMBER        PIC X(7)    VALUE SPACES.        
               10  EXT-NAP-GROUP-NUMBER-N                                       
REN                REDEFINES EXT-NAP-GROUP-NUMBER          PIC 9(7).            
               10  EXT-NAP-GROUP-ACCOUNT       PIC XXX     VALUE SPACES.        
               10  EXT-NAP-AGENT-NUMBER        PIC 9(6)    VALUE ZERO.          
               10  EXT-NAP-GFO-NUMBER          PIC 9(5)    VALUE ZERO.          
           05  EXT-RECON-NAP-DATA.                                              
               10  EXT-NAP-COMP-TYPE           PIC X       VALUE SPACE.         
               10  EXT-NAP-COMP-REASON         PIC X       VALUE SPACE.         
               10  EXT-NAP-COMP-DISP           PIC X       VALUE SPACE.         
               10  EXT-NAP-COMP-AMT     COMP-3 PIC S9(9)V99 VALUE ZERO.         
               10  EXT-NAP-MONTHS       COMP-3 PIC S999    VALUE ZERO.          
               10  FILLER                      PIC X(20)   VALUE SPACES.        
