      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORGROUP' TO DBLINK-CURR-PARAGRAPH.                 
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORGROUP' TO RECORD-NAME.                                    
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORGROUP TO DBLINK-RECORD-MADE-CURRENT.                
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORGROUP-EXIT                                   
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE GROUP-NUMBER OF GC-TGROUP TO DBLINK-GWCORGROUP-01           
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORGROUP TO DBLINK-VIEW-NAME-CURRENT.                  
           MOVE DBLINK-GWCORGROUP-KEY TO DBLINK-VIEW-200-CURRENT.               
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET GROUP-ADVPSM                                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORGROUP-01 TO DBLINK-GROUP-ADVPSM-01.                 
           MOVE LOW-VALUES TO DBLINK-GROUP-ADVPSM-KEY-M.                        
                                                                                
      *%****************************** *                                        
      *%SET GROUP-GRACCT                                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORGROUP-01 TO DBLINK-GROUP-GRACCT-01.                 
           MOVE LOW-VALUES TO DBLINK-GROUP-GRACCT-KEY-M.                        
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
