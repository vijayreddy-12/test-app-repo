       01  WMIDCTR.                                                     00001000
               05  W-GICTRIDENT                    PIC XXX.             00002000
               05  W-GICLENGTH            COMP-3   PIC S9(5).           00003000
               05  W-GIUNDEFINED1                  PIC X(20).           00004000
               05  W-GICCOVERAGE-INFO OCCURS 10 TIMES.                  00005000
                   10  W-GICCLASSES.                                    00006000
                       15  W-GICCLASS              PIC XX               00007000
                                    OCCURS 5 TIMES.                     00008000
                   10  W-GICCOVERAGE-CODES.                             00009000
                       15  W-GICCOVERAGE-CODE      PIC XX               00010000
                                    OCCURS 10 TIMES.                    00011000
                   10  W-GIUNDEFINED2              PIC X(9).            00012000
