      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           MOVE TRANS-TYPE OF GWCORTRANS                                        
               TO TRANS-TYPE OF GC-TTRAN.                                       
                                                                                
           MOVE 348 TO TRANS-DETAILS-LEN OF GC-TTRAN.                           
           MOVE TRANS-DETAILS OF GWCORTRANS                                     
               TO TRANS-DETAILS-TEXT OF GC-TTRAN.                               
