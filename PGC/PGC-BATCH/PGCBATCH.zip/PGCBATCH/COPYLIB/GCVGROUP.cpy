      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           MOVE GROUP-NUMBER OF GWCORGROUP                                      
               TO GROUP-NUMBER OF GC-TGROUP.                                    
