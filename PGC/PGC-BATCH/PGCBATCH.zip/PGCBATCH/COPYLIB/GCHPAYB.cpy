      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE PAY-BASIS-EFF-YEAR OF GC-TPAYB TO                               
               PAY-BASIS-EFF-YEAR OF GWCORPAYBASIS                              
           MOVE PAY-BASIS-EFF-DAY OF GC-TPAYB TO                                
               PAY-BASIS-EFF-DAY OF GWCORPAYBASIS                               
           MOVE PAY-BASIS-IND OF GC-TPAYB TO                                    
               PAY-BASIS-IND OF GWCORPAYBASIS                                   
           MOVE PAY-BASIS-PROC-YEAR OF GC-TPAYB TO                              
               PAY-BASIS-PROC-YEAR OF GWCORPAYBASIS                             
           MOVE PAY-BASIS-PROC-DAY OF GC-TPAYB TO                               
               PAY-BASIS-PROC-DAY OF GWCORPAYBASIS                              
           MOVE PAY-BASIS-END-YEAR OF GC-TPAYB TO                               
               PAY-BASIS-END-YEAR OF GWCORPAYBASIS                              
           MOVE PAY-BASIS-END-DAY OF GC-TPAYB TO                                
               PAY-BASIS-END-DAY OF GWCORPAYBASIS.                              
