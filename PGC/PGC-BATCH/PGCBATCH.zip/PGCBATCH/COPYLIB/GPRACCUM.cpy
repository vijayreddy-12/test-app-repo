       01  GPRACCUM.                                                    00001000
      ******************************************************************        
      *    DEC/91 M. PRANGE                                                     
      *         - ADDED OVERAGE EXPIRY LETTER & REPORT                          
      *         - REMOVED RXPLUS REFERENCE                                      
      ******************************************************************        
           03  ACCUM-LAPSE-MAIL     COMP-3   VALUE +0   PIC S9(5).      00002000
           03  ACCUM-OVERDUE        COMP-3   VALUE +0   PIC S9(5).      00003000
           03  ACCUM-PEND           COMP-3   VALUE +0   PIC S9(5).      00004000
           03  ACCUM-PATRANREG      COMP-3   VALUE +0   PIC S9(5).      00005000
           03  ACCUM-TRANREG        COMP-3   VALUE +0   PIC S9(5).      00006000
           03  ACCUM-DETCHNGS       COMP-3   VALUE +0   PIC S9(5).      00007000
           03  ACCUM-NAP            COMP-3   VALUE +0   PIC S9(5).      00007100
           03  ACCUM-1STYRCOM       COMP-3   VALUE +0   PIC S9(5).      00007200
           03  ACCUM-REMIND         COMP-3   VALUE +0   PIC S9(5).      00007300
           03  ACCUM-ARREARS        COMP-3   VALUE +0   PIC S9(5).      00007400
           03  ACCUM-LTDPREM        COMP-3   VALUE +0   PIC S9(5).      00007500
           03  ACCUM-EXCEPTION      COMP-3   VALUE +0   PIC S9(5).      00007600
           03  ACCUM-CR-CONTROL     COMP-3   VALUE +0   PIC S9(5).      00007700
           03  ACCUM-CR-SUMMARY     COMP-3   VALUE +0   PIC S9(5).      00007800
           03  ACCUM-OVERAGE-LETTER COMP-3   VALUE +0   PIC S9(5).              
           03  ACCUM-OVERAGE-REPORT COMP-3   VALUE +0   PIC S9(5).              
           03  ACCUM-BILL-US-OTH    COMP-3   VALUE +0   PIC S9(5).      00008000
           03  ACCUM-BILL-ENG-OTH   COMP-3   VALUE +0   PIC S9(5).      00009000
           03  ACCUM-BILL-FR-OTH    COMP-3   VALUE +0   PIC S9(5).      00010000
           03  ACCUM-BILL-US-SGPS   COMP-3   VALUE +0   PIC S9(5).      00011000
           03  ACCUM-BILL-ENG-SGPS  COMP-3   VALUE +0   PIC S9(5).      00012000
           03  ACCUM-BILL-FR-SGPS   COMP-3   VALUE +0   PIC S9(5).      00013000
           03  ACCUM-ID-US-OTH      COMP-3   VALUE +0   PIC S9(5).      00014000
           03  ACCUM-ID-ENG-OTH     COMP-3   VALUE +0   PIC S9(5).      00015000
           03  ACCUM-ID-FR-OTH      COMP-3   VALUE +0   PIC S9(5).      00016000
           03  ACCUM-ID-US-SPGS     COMP-3   VALUE +0   PIC S9(5).      00017000
           03  ACCUM-ID-ENG-SPGS    COMP-3   VALUE +0   PIC S9(5).      00018000
           03  ACCUM-ID-FR-SPGS     COMP-3   VALUE +0   PIC S9(5).      00019000
           03  ACCUM-LABELS         COMP-3   VALUE +0   PIC S9(5).      00020000
           03  ACCUM-CERT-US-OTH    COMP-3   VALUE +0   PIC S9(5).      00021000
           03  ACCUM-CERT-ENG-OTH   COMP-3   VALUE +0   PIC S9(5).      00022000
           03  ACCUM-CERT-FR-OTH    COMP-3   VALUE +0   PIC S9(5).      00022100
           03  ACCUM-CERT-US-SPGS   COMP-3   VALUE +0   PIC S9(5).      00022200
           03  ACCUM-CERT-ENG-SPGS  COMP-3   VALUE +0   PIC S9(5).      00022300
           03  ACCUM-CERT-FR-SPGS   COMP-3   VALUE +0   PIC S9(5).      00022400
           03  ACCUM-LAPSE-ENG      COMP-3   VALUE +0   PIC S9(5).      00022500
           03  ACCUM-LAPSE-FR       COMP-3   VALUE +0   PIC S9(5).      00022600
