       01  GIPSY-P-A-TRANS-RECORD.                                              
      *****************************************************************         
      *     GIPSY PREMIUM AND ACCOUNTING TRANSACTION RECORD.          *         
      *                                                               *         
      *       CREATED BY                                              *         
      *       USED    BY                                              *         
      *                                                               *         
      *       REC TYPE     'J'                                        *         
      *       REC LENGTH   +75                                        *         
      *                                                               *         
      *****************************************************************         
      * JUN/93 M. PRANGE                                                        
      *      - ADDED GJREC-TAX-CODE. NON-TAX RELATED RECORDS WILL HAVE          
      *        SPACES IN THIS FIELD.                                            
      *****************************************************************         
           05  GJREC-LNGTH         COMP            PIC S9(4).                   
           05  FILLER                              PIC XX.                      
           05  GJREC-TYPE                          PIC X.                       
GNE        05  GJREC-GROUP         COMP-3          PIC S9(7).                   
           05  GJREC-ACCT                          PIC X(3).                    
           05  GJREC-TRANSACTION-DATE  COMP-3.                                  
               10  GJREC-TRANS-YEAR                PIC S9(3).                   
               10  GJREC-TRANS-DAY                 PIC S9(3).                   
           05  GJREC-AG-CODE                       PIC X(6).                    
           05  GJREC-AG-ACCT                       PIC X(1).                    
           05  GJREC-GLCODE.                                                    
               10  FILLER                          PIC X(4).                    
               10  GJREC-GLCODE-5                  PIC X.                       
               10  FILLER                          PIC XX.                      
           05  GJREC-PAY-TYPE                      PIC X.                       
           05  GJREC-ACTION-CODE.                                               
               10  GJREC-COMM-IND                  PIC X.                       
               10  FILLER                          PIC XX.                      
           05  GJREC-COUNTRY                       PIC X.                       
           05  GJREC-CURRENCY                      PIC X.                       
           05  GJREC-PREM-AMT      COMP-3          PIC S9(7)V99.                
           05  GJREC-LAST-ACCOUNTING-DATE  COMP-3.                              
               10  GJREC-LAST-ACCT-YEAR            PIC S9(3).                   
               10  GJREC-LAST-ACCT-DAY             PIC S9(3).                   
           05  GJREC-COMM-STATUS                   PIC X.                       
           05  GJREC-AGENT-PERCENT COMP-3          PIC S9(3)V99.                
           05  GJREC-COMM-RATE     COMP-3          PIC S9(3)V99.                
           05  GJREC-COMM-AMT      COMP-3          PIC S9(7)V99.                
           05  GJREC-DUE-DATE.                                                  
               10  GJREC-DUE-YEAR           COMP-3 PIC S9(3).                   
               10  GJREC-DUE-DAY            COMP-3 PIC S9(3).                   
           05  GJREC-FIRST-YR-COMM                 PIC X.                       
           05  GJREC-TAX-CODE                      PIC X(2).                    
GNE        05  FILLER                              PIC X(11).                   
