      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORCNTL                            10/26/10  17:05  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORCNTL.                                                           
           05  LAST-GIPSY-DAILY-RUN-DATE.                                       
               10  LAST-GIPSY-DAILY-RUN-YEAR  COMP-3    PIC S9(3).              
               10  LAST-GIPSY-DAILY-RUN-DAY   COMP-3    PIC S9(3).              
           05  LAST-RECON-RUN-DATE.                                             
               10  LAST-RECON-RUN-YEAR        COMP-3    PIC S9(3).              
               10  LAST-RECON-RUN-DAY         COMP-3    PIC S9(3).              
           05  LAST-REN-PREM-RUN-DATE.                                          
               10  LAST-REN-PREM-RUN-YEAR     COMP-3    PIC S9(3).              
               10  LAST-REN-PREM-RUN-DAY      COMP-3    PIC S9(3).              
           05  LAST-REN-COMM-RUN-DATE.                                          
               10  LAST-REN-COMM-RUN-YEAR     COMP-3    PIC S9(3).              
               10  LAST-REN-COMM-RUN-DAY      COMP-3    PIC S9(3).              
           05  COMM-SCR-RECON-IND                       PIC X.                  
           05  NAP-RECON-IND                            PIC X.                  
           05  RECON-DATE-UPDATE-IND                    PIC X.                  
