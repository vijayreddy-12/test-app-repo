      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           MOVE GROUP-NUMBER OF GWCORCOMP                                       
               TO GROUP-NUMBER OF GC-TCOMP.                                     
                                                                                
           MOVE GR-ACCOUNT OF GWCORCOMP                                         
               TO GR-ACCOUNT OF GC-TCOMP.                                       
                                                                                
           IF COMP-EFF-YEAR OF GWCORCOMP  NOT NUMERIC                           
               MOVE ZEROS TO COMP-EFF-YEAR OF GC-TCOMP                          
           ELSE                                                                 
               MOVE COMP-EFF-YEAR OF GWCORCOMP                                  
               TO COMP-EFF-YEAR OF GC-TCOMP                                     
           END-IF.                                                              
                                                                                
           IF COMP-EFF-DAY OF GWCORCOMP  NOT NUMERIC                            
               MOVE ZEROS TO COMP-EFF-DAY OF GC-TCOMP                           
           ELSE                                                                 
               MOVE COMP-EFF-DAY OF GWCORCOMP                                   
               TO COMP-EFF-DAY OF GC-TCOMP                                      
           END-IF.                                                              
                                                                                
           MOVE AGENT-NUMBER OF GWCORCOMP                                       
               TO AGENT-NUMBER OF GC-TCOMP.                                     
                                                                                
           MOVE GFO-NUMBER OF GWCORCOMP                                         
               TO GFO-NUMBER OF GC-TCOMP.                                       
                                                                                
           IF GROUP-REP OF GWCORCOMP  NOT NUMERIC                               
               MOVE ZEROS TO GROUP-REP OF GC-TCOMP                              
           ELSE                                                                 
               MOVE GROUP-REP OF GWCORCOMP                                      
               TO GROUP-REP OF GC-TCOMP                                         
           END-IF.                                                              
                                                                                
           IF COMP-PROCESS-YEAR OF GWCORCOMP  NOT NUMERIC                       
               MOVE ZEROS TO COMP-PROCESS-YEAR OF GC-TCOMP                      
           ELSE                                                                 
               MOVE COMP-PROCESS-YEAR OF GWCORCOMP                              
               TO COMP-PROCESS-YEAR OF GC-TCOMP                                 
           END-IF.                                                              
                                                                                
           IF COMP-PROCESS-DAY OF GWCORCOMP  NOT NUMERIC                        
               MOVE ZEROS TO COMP-PROCESS-DAY OF GC-TCOMP                       
           ELSE                                                                 
               MOVE COMP-PROCESS-DAY OF GWCORCOMP                               
               TO COMP-PROCESS-DAY OF GC-TCOMP                                  
           END-IF.                                                              
                                                                                
           MOVE COV-TYPE OF GWCORCOMP                                           
               TO COV-TYPE OF GC-TCOMP.                                         
                                                                                
           MOVE COMP-TYPE OF GWCORCOMP                                          
               TO COMP-TYPE OF GC-TCOMP.                                        
                                                                                
           IF COMP-AMT OF GWCORCOMP  NOT NUMERIC                                
               MOVE ZEROS TO COMP-AMT OF GC-TCOMP                               
           ELSE                                                                 
               MOVE COMP-AMT OF GWCORCOMP                                       
               TO COMP-AMT OF GC-TCOMP                                          
           END-IF.                                                              
                                                                                
           MOVE COMP-REASON OF GWCORCOMP                                        
               TO COMP-REASON OF GC-TCOMP.                                      
                                                                                
           MOVE RECON-IND OF GWCORCOMP                                          
               TO RECON-IND OF GC-TCOMP.                                        
                                                                                
           MOVE COMP-DISP OF GWCORCOMP                                          
               TO COMP-DISP OF GC-TCOMP.                                        
                                                                                
           IF AGENT-SPLIT OF GWCORCOMP  NOT NUMERIC                             
               MOVE ZEROS TO AGENT-SPLIT OF GC-TCOMP                            
           ELSE                                                                 
               MOVE AGENT-SPLIT OF GWCORCOMP                                    
               TO AGENT-SPLIT OF GC-TCOMP                                       
           END-IF.                                                              
                                                                                
           IF PREM-AMT OF GWCORCOMP  NOT NUMERIC                                
               MOVE ZEROS TO PREM-AMT OF GC-TCOMP                               
           ELSE                                                                 
               MOVE PREM-AMT OF GWCORCOMP                                       
               TO PREM-AMT OF GC-TCOMP                                          
           END-IF.                                                              
                                                                                
           MOVE PREM-SOURCE OF GWCORCOMP                                        
               TO PREM-SOURCE OF GC-TCOMP.                                      
                                                                                
           IF AD-D-AMT OF GWCORCOMP  NOT NUMERIC                                
               MOVE ZEROS TO AD-D-AMT OF GC-TCOMP                               
           ELSE                                                                 
               MOVE AD-D-AMT OF GWCORCOMP                                       
               TO AD-D-AMT OF GC-TCOMP                                          
           END-IF.                                                              
                                                                                
           IF WI-AMT OF GWCORCOMP  NOT NUMERIC                                  
               MOVE ZEROS TO WI-AMT OF GC-TCOMP                                 
           ELSE                                                                 
               MOVE WI-AMT OF GWCORCOMP                                         
               TO WI-AMT OF GC-TCOMP                                            
           END-IF.                                                              
                                                                                
           IF EHC-AMT OF GWCORCOMP  NOT NUMERIC                                 
               MOVE ZEROS TO EHC-AMT OF GC-TCOMP                                
           ELSE                                                                 
               MOVE EHC-AMT OF GWCORCOMP                                        
               TO EHC-AMT OF GC-TCOMP                                           
           END-IF.                                                              
                                                                                
           IF DE-AMT OF GWCORCOMP  NOT NUMERIC                                  
               MOVE ZEROS TO DE-AMT OF GC-TCOMP                                 
           ELSE                                                                 
               MOVE DE-AMT OF GWCORCOMP                                         
               TO DE-AMT OF GC-TCOMP                                            
           END-IF.                                                              
                                                                                
