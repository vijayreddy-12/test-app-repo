      *************************************************************             
      *      COMMISSIONS ADVISOR ADDRESS INPUT RECORD             *             
      *               RECORD LENGTH 136                           *             
      *************************************************************             
         05  COMTABLE-DETAIL.                                                   
             10  COMTABLE-ADVISOR-NUMBER      PIC 9(6).                         
             10  COMTABLE-ADVISOR-NAME1       PIC X(25).                        
             10  COMTABLE-ADVISOR-NAME2       PIC X(25).                        
             10  COMTABLE-ADDR1               PIC X(25).                        
             10  COMTABLE-ADDR2               PIC X(25).                        
             10  COMTABLE-ADDR3               PIC X(30).                        
