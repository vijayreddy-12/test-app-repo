      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORCOMP                            10/26/10  17:05  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORCOMP.                                                           
           05  AGENT-COMP-KEY.                                                  
               10  GROUP-ACCOUNT.                                               
                   15  GROUP-NUMBER                     PIC X(7).               
                   15  GR-ACCOUNT                       PIC X(3).               
               10  GROUP-COMP-KEY.                                              
                   15  COMP-EFF-DATE.                                           
                     20  COMP-EFF-YEAR        COMP-3    PIC S9(3).              
                     20  COMP-EFF-DAY         COMP-3    PIC S9(3).              
           05  AGENT-NUMBER                             PIC X(6).               
           05  GFO-NUMBER                               PIC X(5).               
           05  GROUP-REP                                PIC 9(5).               
           05  COMP-PROCESS-DATE.                                               
               10  COMP-PROCESS-YEAR          COMP-3    PIC S9(3).              
               10  COMP-PROCESS-DAY           COMP-3    PIC S9(3).              
           05  COV-TYPE                                 PIC X.                  
           05  COMP-TYPE                                PIC X.                  
           05  COMP-AMT                       COMP-3    PIC S9(9)V99.           
           05  COMP-REASON                              PIC X.                  
           05  RECON-IND                                PIC X.                  
           05  COMP-DISP                                PIC X.                  
           05  AGENT-SPLIT                    COMP-3    PIC S9(3)V99.           
           05  PREM-AMT                       COMP-3    PIC S9(9)V99.           
           05  PREM-SOURCE                              PIC X(2).               
           05  A-S-PREM-BREAKDOWN.                                              
               10  AD-D-AMT                   COMP-3    PIC S9(9)V99.           
               10  WI-AMT                     COMP-3    PIC S9(9)V99.           
               10  EHC-AMT                    COMP-3    PIC S9(9)V99.           
               10  DE-AMT                     COMP-3    PIC S9(9)V99.           
