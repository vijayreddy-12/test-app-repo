      *================================================================         
      *    COPYBOOK: VOMAPCTN                                                   
      *    Character set translation strings for VOMAPPER                       
      *----------------------------------------------------------------         
      *    Aug/06 F. MUELLER - CREATED                                          
      *----------------------------------------------------------------         
       01  LOWERCASE-AND-FRENCH            PIC X(79)                            
           VALUE 'abcdefghijklmnopqrstuvwxyz�됟⫋���ۥ�㨞�ܚ�ޘ�����        
      -          '������ʾ�����������������'.                                   
                                                                                
       01  UPPERCASE-AND-ENGLISH           PIC X(79)                            
           VALUE 'ABCDEFGHIJKLMNOPQRSTUVWXYZAAAAAACNEEEEIIIIBAAAAAACNEEE        
      -          'EIIIIYOOOOOUUUUYOOOOOUUUU'.                                   
                                                                                
