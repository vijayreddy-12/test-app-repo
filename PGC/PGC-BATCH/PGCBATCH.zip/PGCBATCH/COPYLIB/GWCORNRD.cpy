      ******************************************************************00010000
      * RUN DATE RECORD LAYOUT FOR RUNNING RENEWAL COMMISSIONS         *00030000
      ******************************************************************00060000
                                                                        00070000
       01  PROGRAM-RUN-DATE-RECORD.                                     01181000
           05  PROGRAM-RUN-DATE.                                        01181100
               10  PROGRAM-RUN-DAY        VALUE ZERO      PIC 99.       01182000
               10  PROGRAM-RUN-MTH        VALUE SPACES    PIC XXX.      01183000
               10  PROGRAM-RUN-YEAR       VALUE ZERO      PIC 99.       01184000
           05  FILLER                                 PIC X(73).        01185000
