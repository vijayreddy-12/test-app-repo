      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           MOVE COV-TYPE OF GWCORRENEWAL                                        
               TO COV-TYPE OF GC-TRNEWL.                                        
                                                                                
           IF RENEWAL-AMOUNT OF GWCORRENEWAL  NOT NUMERIC                       
               MOVE ZEROS TO RENEWAL-AMOUNT OF GC-TRNEWL                        
           ELSE                                                                 
               MOVE RENEWAL-AMOUNT OF GWCORRENEWAL                              
               TO RENEWAL-AMOUNT OF GC-TRNEWL                                   
           END-IF.                                                              
