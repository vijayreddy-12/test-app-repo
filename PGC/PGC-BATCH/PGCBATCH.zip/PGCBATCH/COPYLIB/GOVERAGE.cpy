       01  GOVERAGE.                                                            
      ******************************************************************        
      *    OVERAGE LETTERS/REPORT EXTRACT.                                      
      *    TYPE 'X' EXTRACTS. CREATED IN PROGRAM 'GFMOVRAG'.                    
      ******************************************************************        
           05  GOVERAGE-LENGTH                    PIC S9(4)      COMP.          
           05  GOVERAGE-LV                        PIC X(2).                     
           05  GOVERAGE-SORT-KEY.                                               
               10  GOVERAGE-RECTYPE               PIC X(1).                     
                   88  GOVERAGE-RECTYPE-X                     VALUE 'X'.        
               10  GOVERAGE-SUBTYPE               PIC X(1).                     
                   88  GOVERAGE-SUBTYPE-LETTER                VALUE 'L'.        
                   88  GOVERAGE-SUBTYPE-REPORT                VALUE 'R'.        
               10  GOVERAGE-GROUP                 PIC 9(7).                     
               10  GOVERAGE-ACCT                  PIC X(3).                     
               10  GOVERAGE-CERT                  PIC 9(9).                     
               10  GOVERAGE-LANGUAGE              PIC X(1).                     
               10  FILLER                         PIC X(26).                    
           05  GOVERAGE-DATA-AREA                 PIC X(500).                   
      *                                                                         
      *    REPORT EXTRACT FIELDS                                                
      *                                                                         
           05  GOVERAGE-REPORT-FIELDS REDEFINES GOVERAGE-DATA-AREA.             
               10  GOVERAGE-R-CERT-NAME           PIC X(32).                    
               10  GOVERAGE-R-EXPIRY-DATE.                                      
                   15  GOVERAGE-R-EXPIRY-YEAR     PIC S9(3)      COMP-3.        
                   15  GOVERAGE-R-EXPIRY-DAY      PIC S9(3)      COMP-3.        
               10  FILLER                         PIC X(464).                   
      *                                                                         
      *    LETTER EXTRACT FIELDS                                                
      *                                                                         
           05  GOVERAGE-LETTER-FIELDS REDEFINES GOVERAGE-DATA-AREA.             
               10  GOVERAGE-L-CERT-NAME           PIC X(32).                    
               10  GOVERAGE-L-EXPIRY-DATE.                                      
                   15  GOVERAGE-L-EXPIRY-YEAR     PIC S9(3)      COMP-3.        
                   15  GOVERAGE-L-EXPIRY-DAY      PIC S9(3)      COMP-3.        
               10  GOVERAGE-L-GROUP-NAME-ADDRESS.                               
                   15  GOVERAGE-L-NAAD-ENTRY OCCURS 6 TIMES.                    
                       20  GOVERAGE-L-NAAD-LINE   PIC X(30).                    
               10  FILLER                         PIC X(284).                   
