      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           MOVE GFO-NUMBER OF GWCORGFO                                          
               TO GFO-NUMBER OF GC-TGFO.                                        
