      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORRENEWAL' TO DBLINK-CURR-PARAGRAPH.               
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORRENEWAL' TO RECORD-NAME.                                  
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORRENEWAL TO DBLINK-RECORD-MADE-CURRENT.              
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORRENEWAL-EXIT                                 
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE GROUP-NUMBER OF GC-TRNEWL TO DBLINK-GWCORRENEWAL-01         
               MOVE GR-ACCOUNT OF GC-TRNEWL TO DBLINK-GWCORRENEWAL-02           
               MOVE GRACT-RNEWL-TS OF GC-TRNEWL TO                              
                   DBLINK-GWCORRENEWAL-03                                       
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORRENEWAL TO DBLINK-VIEW-NAME-CURRENT.                
           MOVE DBLINK-GWCORRENEWAL-KEY TO DBLINK-VIEW-200-CURRENT.             
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-RENEWAL  M/A                                                 
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-GRACCT-RENEWAL-F                        
           MOVE GROUP-NUMBER OF GC-TRNEWL TO DBLINK-GRACCT-RENEWAL-01.          
           MOVE GR-ACCOUNT OF GC-TRNEWL TO DBLINK-GRACCT-RENEWAL-02.            
           MOVE GRACT-RNEWL-TS OF GC-TRNEWL TO DBLINK-GRACCT-RENEWAL-03.        
