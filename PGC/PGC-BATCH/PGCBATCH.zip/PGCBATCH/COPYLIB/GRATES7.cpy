      ***************************************************************   00010000
      *  IF ANY OF THE FILLER X(21) IS USED, CHANGES MUST BE MADE   *   00020000
      *  IN THE WORK TABLE IN GFMRATES PROGRAM.                     *   00030000
      ***************************************************************   00040000
                                                                        00050000
       01  GROUP-RATES-RECORD.                                          00060000
           05  GRLENGTH                     COMP    PIC S9(4).          00070000
           05  FILLER                               PIC XX.             00080000
           05  GRATES-RECORD.                                           00090000
             10  GRKEY.                                                 00100000
               15  GRBASE-KEY.                                          00110000
                 20  GRGROUP-ACCOUNT.                                   00120000
                     25  GRGROUP-NUMBER       COMP-3  PIC S9(7).        00130000
                     25  GRACCOUNT                    PIC X(3).         00140000
                 20  GRIDENT                          PIC X.            00150000
               15  GRREST-KEY.                                          00160000
                 20  GRCOV-CODE               COMP-3  PIC S9(3).        00170000
                 20  GREFFECTIVE-DATE         COMP-3.                   00180000
                     25  GREFFECTIVE-YEAR             PIC S9(3).        00190000
                     25  GREFFECTIVE-DAY              PIC S9(3).        00200000
                 20  GRPROCESSED-DATE         COMP-3.                   00210000
                     25  GRPROCESSED-YEAR             PIC S9(3).        00220000
                     25  GRPROCESSED-DAY              PIC S9(3).        00230000
                 20  GRCLASSES.                                         00240000
                     25  GRCLASS OCCURS 10 TIMES      PIC XX.           00250000
             10  GRREST-RATE-RECORD.                                    00260000
               15  GROTH-INFO.                                          00270000
                 20  GREND-DATE               COMP-3.                   00280000
                     25  GREND-YEAR                   PIC S9(3).        00290000
                     25  GREND-DAY                    PIC S9(3).        00300000
                 20  GRWAIVER-OF-PREM                 PIC X.            00310000
                 20  GRUW-IDENT                       PIC XXX.          00320000
                 20  GRREASON                         PIC XX.           00330000
                 20  GRFILLER                         PIC X(21).        00340000
               15  GRCOV-INFO.                                          00350000
                 20  GRNUM-COV-CODE           COMP-3  PIC S9(3).        00360000
                 20  GREHC-COV-INFO.                                    00370000
                   25  GREHC-DATA OCCURS 10 TIMES.                      00380000
                     30  GREHC-COV-CODE       COMP-3  PIC S9(3).        00390000
                     30  GREHC-STD-RATES      COMP-3.                   00400000
                         35  GREHC-STD-SIN            PIC S9(4)V999.    00410000
                         35  GREHC-STD-FAM1           PIC S9(4)V999.    00420000
                         35  GREHC-STD-FAM2           PIC S9(4)V999.    00430000
                     30  GREHC-CURR-RATES     COMP-3.                   00440000
                         35  GREHC-ACTUAL-SIN         PIC S9(4)V999.    00450000
                         35  GREHC-ACTUAL-FAM1        PIC S9(4)V999.    00460000
                         35  GREHC-ACTUAL-FAM2        PIC S9(4)V999.    00470000
                 20  GRDEN-COV-INFO REDEFINES GREHC-COV-INFO.           00480000
                   25  GRDEN-DATA OCCURS 10 TIMES.                      00490000
                     30  GRDEN-COV-CODE       COMP-3  PIC S9(3).        00500000
                     30  GRDEN-STD-RATES      COMP-3.                   00510000
                         35  GRDEN-STD-SIN            PIC S9(4)V999.    00520000
                         35  GRDEN-STD-FAM1           PIC S9(4)V999.    00530000
                         35  GRDEN-STD-FAM2           PIC S9(4)V999.    00540000
                     30  GRDEN-CURR-RATES     COMP-3.                   00550000
                         35  GRDEN-ACTUAL-SIN         PIC S9(4)V999.    00560000
                         35  GRDEN-ACTUAL-FAM1        PIC S9(4)V999.    00570000
                         35  GRDEN-ACTUAL-FAM2        PIC S9(4)V999.    00580000
                 20  GRLIFE-COV-INFO REDEFINES GREHC-COV-INFO.          00590000
                   25  GRLI-DATA OCCURS 12 TIMES.                       00600000
                     30  GRLI-COV-CODE        COMP-3  PIC S9(3).        00610000
                     30  GRLI-DEPENDENT-LIFE.                           00620000
                         35  GRLI-DL-FACTOR   COMP-3  PIC S9(5).        00630000
                         35  GRLI-DL-STD      COMP-3  PIC S99V9(7).     00640000
                         35  GRLI-DL-ACTUAL   COMP-3  PIC S99V9(7).     00650000
                     30  GRLI-RATE-TABLES REDEFINES GRLI-DEPENDENT-LIFE.00660000
                         35  GRLI-RATE-TABLE          PIC XXX.          00670000
                         35  GRLI-AVG-AGE-IND         PIC X.            00680000
                         35  GRLI-PERC-ADJ    COMP-3  PIC S9V9(2).      00690000
                     30  GRLI-AVG-RATES REDEFINES GRLI-DEPENDENT-LIFE.  00700000
                         35  GRLI-AVG-STD     COMP-3  PIC S99V9(7).     00710000
                         35  GRLI-AVG-ACTUAL  COMP-3  PIC S99V9(7).     00720000
                 20  GRADD-COV-INFO REDEFINES GREHC-COV-INFO.           00730000
                   25  GRADD-DATA OCCURS 4 TIMES.                       00740000
                     30  GRADD-COV-CODE       COMP-3  PIC S9(3).        00750000
                     30  GRADD-STD            COMP-3  PIC S99V999.      00760000
                     30  GRADD-ACTUAL         COMP-3  PIC S99V999.      00770000
                 20  GRWI-COV-INFO REDEFINES GREHC-COV-INFO.            00780000
                   25  GRWI-DATA OCCURS 1 TIMES.                        00790000
                     30  GRWI-COV-CODE        COMP-3  PIC S9(3).        00800000
                     30  GRWI-STD             COMP-3  PIC S9(2)V999.    00810000
                     30  GRWI-ACTUAL          COMP-3  PIC S9(2)V999.    00820000
                 20  GRLTD-COV-INFO REDEFINES GREHC-COV-INFO.           00830000
                   25  GRLTD-DATA OCCURS 1 TIMES.                       00840000
                     30  GRLTD-COV-CODE       COMP-3  PIC S9(3).        00850000
                     30  GRLTD-STD            COMP-3  PIC SV9(7).       00860000
                     30  GRLTD-ACTUAL         COMP-3  PIC SV9(7).       00870000
