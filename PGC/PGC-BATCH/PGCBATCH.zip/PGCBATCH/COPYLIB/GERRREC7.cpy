      *****************************************************************         
      *     GIPSY GPRINTAL  EFFOR FILE                                *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *   ====> PART OF GIPSY-REL-1    REQ # 240 (ALPHA+)             *         
      *                                                               *         
      *    M DRURY   SEP/89                                           *         
      *                                                               *         
      *          ADD  6 POSITIONS    PCODE  --  1                     *         
      *                              GFO    --  5                     *         
      *                                                               *         
      *       CREATED BY                                              *         
      *                  GPRBILLS         REC TYPE     '2'            *         
      *                  GPRIDCER         REC TYPE     '3'            *         
      *                  GPRADLAB         REC TYPE     '4'            *         
      *                  GPRCERTL         REC TYPE     '5'            *         
      *                  GPRLAPNT         REC TYPE     '6'            *         
      *                  GPRSOAR1,2,3     REC TYPE     'H'            *         
      *                     ?             REC TYPE     'I'            *         
      *                  GPRAGCOM         REC TYPE     'Q'            *         
      *                     ?             REC TYPE     'S'            *         
      *                  GPRARRLS         REC TYPE     'T'            *         
      *                                                               *         
      *       USED    BY GERRORPT                                     *         
      *                                                               *         
      *       REC LENGTH  27                                          *         
      *                                                               *         
      *****************************************************************         
       01  ERR-REC.                                                             
           03  E-REC-TYPE              PIC X(1)           VALUE SPACES.         
           03  E-PROD-CD               PIC X     VALUE    LOW-VALUES.           
           03  E-OFFICE                PIC X(5)  VALUE    LOW-VALUES.           
           03  E-NORM.                                                          
REN            05  E-GROUP             PIC S9(7)  COMP-3  VALUE +0.             
               05  E-ACCT              PIC X(3)           VALUE SPACES.         
               05  FILLER  VALUE SPACES PIC X.                                  
           03  FILLER REDEFINES E-NORM.                                         
               05  E-AGENT             PIC  X(6).                               
               05  E-AACCT             PIC  X(1).                               
REN            05  FILLER              PIC  X(1).                               
           03  E-CERT                  PIC S9(9)  COMP-3  VALUE +0.             
           03  E-CODE.                                                          
               05  E-CODE1             PIC X(1)           VALUE SPACES.         
               05  FILLER              PIC X(2)           VALUE SPACES.         
           03  E-COUNTRY               PIC X(1)           VALUE SPACES.         
REN        03  FILLER                  PIC X(3)           VALUE SPACES.         
