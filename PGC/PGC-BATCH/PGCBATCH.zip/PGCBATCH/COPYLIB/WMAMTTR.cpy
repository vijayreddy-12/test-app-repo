       01  WMAMTTR.                                                     00001000
               05  W-GAMTRIDENT                    PIC XXX.             00002000
               05  W-GAMLENGTH            COMP-3   PIC S9(5).           00003000
               05  W-GAMUNDEFINED1                 PIC X(10).           00004000
               05  W-GAMAMENDMENT-HISTORY OCCURS 15 TIMES.              00005000
                   07  W-GAMEFFECTIVE-DATE   COMP-3.                    00006000
                       09  W-GAMEFFECTIVE-YEAR     PIC S9(3).           00007000
                       09  W-GAMEFFECTIVE-DAY      PIC S9(3).           00008000
                   07  W-GAMPROCESSED-DATE   COMP-3.                    00009000
                       09  W-GAMPROCESSED-YEAR     PIC S9(3).           00010000
                       09  W-GAMPROCESSED-DAY      PIC S9(3).           00011000
                   07  W-GAMREASON                 PIC X(20).           00012000
                   07  W-GAMUNDEFINED2             PIC X(4).            00013000
