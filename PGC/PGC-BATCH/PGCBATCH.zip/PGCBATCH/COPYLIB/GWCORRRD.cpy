      ******************************************************************00010001
      * RUN DATE RECORD LAYOUT FOR RUNNING COMMISSION RECONCILIATION   *00030003
      ******************************************************************00060001
                                                                        00070001
       01  PROGRAM-RUN-DATE-RECORD.                                     01181002
           05  PROGRAM-RUN-DATE.                                        01181102
               10  PROGRAM-RUN-DAY        VALUE ZERO      PIC 99.       01182002
               10  PROGRAM-RUN-MTH        VALUE SPACES    PIC XXX.      01183002
               10  PROGRAM-RUN-YEAR       VALUE ZERO      PIC 99.       01184002
           05  FILLER                                 PIC X(73).        01185000
