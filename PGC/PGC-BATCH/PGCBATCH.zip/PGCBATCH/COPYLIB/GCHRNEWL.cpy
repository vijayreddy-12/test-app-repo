      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE HOST VARIABLES TO RECORD                                      
           MOVE COV-TYPE OF GC-TRNEWL TO                                        
               COV-TYPE OF GWCORRENEWAL                                         
           MOVE RENEWAL-AMOUNT OF GC-TRNEWL TO                                  
               RENEWAL-AMOUNT OF GWCORRENEWAL                                   
           .                                                                    
