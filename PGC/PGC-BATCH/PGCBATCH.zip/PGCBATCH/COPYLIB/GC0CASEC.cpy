      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORCASECNT' TO DBLINK-CURR-PARAGRAPH.               
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORCASECNT' TO RECORD-NAME.                                  
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORCASECNT TO DBLINK-RECORD-MADE-CURRENT.              
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORCASECNT-EXIT                                 
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE GROUP-NUMBER OF GC-TCASEC TO DBLINK-GWCORCASECNT-01         
               MOVE GR-ACCOUNT OF GC-TCASEC TO DBLINK-GWCORCASECNT-02           
               MOVE AGT-CASE-CNT-YEAR OF GC-TCASEC TO                           
                   DBLINK-GWCORCASECNT-03                                       
               MOVE AGT-CASE-CNT-DAY OF GC-TCASEC TO                            
                   DBLINK-GWCORCASECNT-04                                       
               MOVE GRACT-CASEC-TS OF GC-TCASEC TO                              
                   DBLINK-GWCORCASECNT-05                                       
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORCASECNT TO DBLINK-VIEW-NAME-CURRENT.                
           MOVE DBLINK-GWCORCASECNT-KEY TO DBLINK-VIEW-200-CURRENT.             
           MOVE FC-IDENT TO DBLINK-GWCORCASECNT-ID-KEY                          
           MOVE DBLINK-GWCORCASECNT-ID-KEY TO DBKEY.                            
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET AGENT-CASECNT  M/A                                                  
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-AGENT-CASECNT-F                         
           MOVE AGENT-NUMBER OF GC-TCASEC TO DBLINK-AGENT-CASECNT-01.           
           MOVE AGENT-CASEC-TS OF GC-TCASEC TO DBLINK-AGENT-CASECNT-02.         
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-CASECNT  M/A                                                 
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-GRACCT-CASECNT-F                        
           MOVE GROUP-NUMBER OF GC-TCASEC TO DBLINK-GRACCT-CASECNT-01.          
           MOVE GR-ACCOUNT OF GC-TCASEC TO DBLINK-GRACCT-CASECNT-02.            
           MOVE AGT-CASE-CNT-YEAR OF GC-TCASEC TO                               
               DBLINK-GRACCT-CASECNT-03.                                        
           MOVE AGT-CASE-CNT-DAY OF GC-TCASEC TO                                
               DBLINK-GRACCT-CASECNT-04.                                        
           MOVE GRACT-CASEC-TS OF GC-TCASEC TO DBLINK-GRACCT-CASECNT-05.        
