      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           IF AGT-CASE-CNT-YEAR OF GWCORCASECNT  NOT NUMERIC                    
               MOVE ZEROS TO AGT-CASE-CNT-YEAR OF GC-TCASEC                     
           ELSE                                                                 
               MOVE AGT-CASE-CNT-YEAR OF GWCORCASECNT                           
               TO AGT-CASE-CNT-YEAR OF GC-TCASEC                                
           END-IF.                                                              
                                                                                
           IF AGT-CASE-CNT-DAY OF GWCORCASECNT  NOT NUMERIC                     
               MOVE ZEROS TO AGT-CASE-CNT-DAY OF GC-TCASEC                      
           ELSE                                                                 
               MOVE AGT-CASE-CNT-DAY OF GWCORCASECNT                            
               TO AGT-CASE-CNT-DAY OF GC-TCASEC                                 
           END-IF.                                                              
                                                                                
           IF AGT-CASE-CNT-AMT OF GWCORCASECNT  NOT NUMERIC                     
               MOVE ZEROS TO AGT-CASE-CNT-AMT OF GC-TCASEC                      
           ELSE                                                                 
               MOVE AGT-CASE-CNT-AMT OF GWCORCASECNT                            
               TO AGT-CASE-CNT-AMT OF GC-TCASEC                                 
           END-IF.                                                              
                                                                                
           IF AGENT-SPLIT OF GWCORCASECNT  NOT NUMERIC                          
               MOVE ZEROS TO AGENT-SPLIT OF GC-TCASEC                           
           ELSE                                                                 
               MOVE AGENT-SPLIT OF GWCORCASECNT                                 
               TO AGENT-SPLIT OF GC-TCASEC                                      
           END-IF.                                                              
                                                                                
