      **** TLU111  ******* BEGIN OF RECORD DESCRIPTION ****************         
      *                                                               *         
      *    TLU111  = NAL GROUP NUMBER TABLE                           *         
      *                                                               *         
      *     X(15)  = RECORD LENGTH                                    *         
      *                                                               *         
      *---------------------------------------------------------------*         
      *                                                               *         
      * 27-JUN-96  = A.MA    (CREATED)                                *         
      *                                                               *         
      *****************************************************************         
      *                                                                         
      *01  TLU111.                                                              
      *                                                                         
           05 TLU111-RECORD                   PIC X(80).                        
           05 TLU111-HEADER REDEFINES TLU111-RECORD.                            
              10 FILLER                       PIC X(01).                        
                 88 IS-TLU111-HEADER                     VALUE '$'.             
              10 TLU111-ID                    PIC 9(03).                        
                 88 IS-TLU111                            VALUE 111.             
              10 TLU111-IN-PARM               PIC 9(05).                        
              10 TLU111-OUT-PARM              PIC 9(05).                        
           05 TLU111-NAL-GROUP REDEFINES TLU111-RECORD.                         
      *                                                                         
      **** FIRST ARGUMENT                                                       
      *                                                                         
              10 TLU111-GROUP                 PIC 9(07).                        
      *                                                                         
      **** SECOND ARGUMENT                                                      
      *                                                                         
              10 TLU111-CII-EFF-DATE          PIC 9(08).                        
      *                                                                         
      *                                                                         
      **** THIRD ARGUMENT                                                       
      *                                                                         
              10 TLU111-GROUP-EFF-DATE        PIC 9(08).                        
      *                                                                         
           05 TLU111-TRAILER REDEFINES TLU111-RECORD.                           
              10 TLU111-TRAILER-DETAILS       PIC X(23).                        
                 88 IS-TLU111-TRAILER                                           
                        VALUE '$$$$$$$$$$$$$$$$$$$$$$$'.                        
      *                                                                         
      **** TLU111  ******* END OF RECORD DESCRIPTION ******************         
