      *      CREATED BY CONVERT/DB V8R04 ON 09/28/10 AT 06:51         *         
      *      MOVE RECORD DATA TO HOST VARIABLES                                 
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT                                     
               TO GROUP-NUMBER OF GC-TGRACT.                                    
                                                                                
           MOVE GR-ACCOUNT OF GWCORGRACCT                                       
               TO GR-ACCOUNT OF GC-TGRACT.                                      
                                                                                
           IF LAST-RECON-YEAR OF GWCORGRACCT  NOT NUMERIC                       
               MOVE ZEROS TO LAST-RECON-YEAR OF GC-TGRACT                       
           ELSE                                                                 
               MOVE LAST-RECON-YEAR OF GWCORGRACCT                              
               TO LAST-RECON-YEAR OF GC-TGRACT                                  
           END-IF.                                                              
                                                                                
           IF LAST-RECON-DAY OF GWCORGRACCT  NOT NUMERIC                        
               MOVE ZEROS TO LAST-RECON-DAY OF GC-TGRACT                        
           ELSE                                                                 
               MOVE LAST-RECON-DAY OF GWCORGRACCT                               
               TO LAST-RECON-DAY OF GC-TGRACT                                   
           END-IF.                                                              
                                                                                
           IF NEXT-RECON-YEAR OF GWCORGRACCT  NOT NUMERIC                       
               MOVE ZEROS TO NEXT-RECON-YEAR OF GC-TGRACT                       
           ELSE                                                                 
               MOVE NEXT-RECON-YEAR OF GWCORGRACCT                              
               TO NEXT-RECON-YEAR OF GC-TGRACT                                  
           END-IF.                                                              
                                                                                
           IF NEXT-RECON-DAY OF GWCORGRACCT  NOT NUMERIC                        
               MOVE ZEROS TO NEXT-RECON-DAY OF GC-TGRACT                        
           ELSE                                                                 
               MOVE NEXT-RECON-DAY OF GWCORGRACCT                               
               TO NEXT-RECON-DAY OF GC-TGRACT                                   
           END-IF.                                                              
                                                                                
           IF RENEWAL-EFFECTIVE-YEAR OF GWCORGRACCT  NOT NUMERIC                
               MOVE ZEROS TO RENEWAL-EFFECTIVE-YEAR OF GC-TGRACT                
           ELSE                                                                 
               MOVE RENEWAL-EFFECTIVE-YEAR OF GWCORGRACCT                       
               TO RENEWAL-EFFECTIVE-YEAR OF GC-TGRACT                           
           END-IF.                                                              
                                                                                
           IF RENEWAL-EFFECTIVE-DAY OF GWCORGRACCT  NOT NUMERIC                 
               MOVE ZEROS TO RENEWAL-EFFECTIVE-DAY OF GC-TGRACT                 
           ELSE                                                                 
               MOVE RENEWAL-EFFECTIVE-DAY OF GWCORGRACCT                        
               TO RENEWAL-EFFECTIVE-DAY OF GC-TGRACT                            
           END-IF.                                                              
                                                                                
           MOVE RENEW-COMP-ADVANCED-IND OF GWCORGRACCT                          
               TO RENEW-COMP-ADVANCED-IND OF GC-TGRACT.                         
                                                                                
           IF COMP-LIVES OF GWCORGRACCT  NOT NUMERIC                            
               MOVE ZEROS TO COMP-LIVES OF GC-TGRACT                            
           ELSE                                                                 
               MOVE COMP-LIVES OF GWCORGRACCT                                   
               TO COMP-LIVES OF GC-TGRACT                                       
           END-IF.                                                              
                                                                                
