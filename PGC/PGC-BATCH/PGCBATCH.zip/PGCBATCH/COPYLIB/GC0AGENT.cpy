      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORAGENT' TO DBLINK-CURR-PARAGRAPH.                 
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORAGENT' TO RECORD-NAME.                                    
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORAGENT TO DBLINK-RECORD-MADE-CURRENT.                
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORAGENT-EXIT                                   
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE AGENT-NUMBER OF GC-TAGENT TO DBLINK-GWCORAGENT-01           
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORAGENT TO DBLINK-VIEW-NAME-CURRENT.                  
           MOVE DBLINK-GWCORAGENT-KEY TO DBLINK-VIEW-200-CURRENT.               
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET AGENT-CASECNT                                                       
      *%****************************** *                                        
           MOVE DBLINK-GWCORAGENT-01 TO DBLINK-AGENT-CASECNT-01.                
           MOVE LOW-VALUES TO DBLINK-AGENT-CASECNT-KEY-M.                       
                                                                                
      *%****************************** *                                        
      *%SET AGENT-COMP                                                          
      *%****************************** *                                        
           MOVE DBLINK-GWCORAGENT-01 TO DBLINK-AGENT-COMP-01.                   
           MOVE LOW-VALUES TO DBLINK-AGENT-COMP-KEY-M.                          
                                                                                
      *%****************************** *                                        
      *%SET AGENT-PAYBASIS                                                      
      *%****************************** *                                        
           MOVE DBLINK-GWCORAGENT-01 TO DBLINK-AGENT-PAYBASIS-01.               
           MOVE LOW-VALUES TO DBLINK-AGENT-PAYBASIS-KEY-M.                      
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
