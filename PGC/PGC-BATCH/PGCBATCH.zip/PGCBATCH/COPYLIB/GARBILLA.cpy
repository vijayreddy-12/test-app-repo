      *01  M-F-C-Bill.                                                          
      *---------------------------------------------------------------*         
      * BILLING BASE DATA DEFINITION - (FOR XML USAGE)                *         
      *---------------------------------------------------------------*         
           05  BILL-INFORMATION.                                                
               10  RECORD-TYPE                      PIC X(1).                   
DATE1          10  PROCESS-DATE                     PIC X(8).                   
               10  GROUP-INFORMATION.                                           
                   15  POLICY                       PIC X(10).                  
                   15  ACCOUNT                      PIC X(3).                   
                   15  MAILING-DIVISION             PIC X(3).                   
                   15  PRODUCT.                                                 
ATTRIB                 20  TC                       PIC X.                      
                   15  STATEMENT-TYPE.                                          
ATTRIB                 20  TC                       PIC X.                      
DATE1              15  FROM-DATE                    PIC X(8).                   
DATE1              15  TO-DATE                      PIC X(8).                   
DATE1              15  PREPARED-DATE                PIC X(8).                   
DATE1              15  PREMIUM-DUE-DATE             PIC X(8).                   
                   15  IDENTITY                     PIC X(5).                   
TIMESN             15  NUM-OF-NA-LINES              PIC 9(3).                   
TIMESN             15  NA-LINES  OCCURS 6 TIMES.                                
                       20  NAME-ADDRESS             PIC X(30).                  
                       20  NAME-ADDRESS-DELIMITER   PIC X(1).                   
                   15  COUNTRY                      PIC X(1).                   
                   15  LOGO                         PIC X(30).                  
                   15  REQUESTOR                    PIC X(15).                  
                   15  BILL-FORMAT-TYPE.                                        
ATTRIB                 20  TC                       PIC X(2).                   
                   15  LIST-BILLING.                                            
ATTRIB                 20  TC                       PIC X.                      
                   15  CHANGE-BILLING.                                          
ATTRIB                 20  TC                       PIC X.                      
                   15  BILLING-NUM-IND              PIC X(1).                   
                   15  BILLING-NUMBER               PIC 9(11).                  
                   15  CURRENCY-CODE.                                           
ATTRIB                 20  TC                       PIC X.                      
                   15  LANGUAGE.                                                
ATTRIB                 20  TC                       PIC X.                      
                   15  GROUP-OFFICE.                                            
ATTRIB                 20  TC                       PIC X(5).                   
                   15  GROUP-OFFICE-NAME            PIC X(25).                  
                   15  BRANCH.                                                  
ATTRIB                 20  TC                       PIC X(5).                   
                   15  CLAIMS-OFFICE.                                           
ATTRIB                 20  TC                       PIC X(5).                   
                   15  RESIDENCE.                                               
ATTRIB                 20  TC                       PIC X(2).                   
                   15  AGENT                        PIC X(6).                   
                   15  AGENT-NAME                   PIC X(25).                  
                   15  TAX-STATUS.                                              
ATTRIB                 20  TC                       PIC X.                      
                   15  INSURED-LIVES                PIC S9(7)                   
                       SIGN LEADING SEPARATE.                                   
                   15  PREV-PREMIUM-DUE             PIC S9(7)V99                
                       SIGN LEADING SEPARATE.                                   
                   15  GROSS-PREMIUM-DUE            PIC S9(7)V99                
                       SIGN LEADING SEPARATE.                                   
                   15  NET-PREMIUM-DUE              PIC S9(7)V99                
                       SIGN LEADING SEPARATE.                                   
                   15  PREV-TAX-TOTAL               PIC S9(7)V99                
                       SIGN LEADING SEPARATE.                                   
                   15  CURR-TAX-TOTAL               PIC S9(7)V99                
                       SIGN LEADING SEPARATE.                                   
TIMES1             15  NUM-OF-TAX-ENTRIES           PIC 9(3).                   
TIMES1             15  TAXES    OCCURS 8 TIMES.                                 
ATTRIB                 20  TAX-CODE                 PIC X(2).                   
                       20  PREV-TAX-AMOUNT          PIC S9(7)V99                
                           SIGN LEADING SEPARATE.                               
                       20  CURR-TAX-AMOUNT          PIC S9(7)V99                
                           SIGN LEADING SEPARATE.                               
                   15  NUM-OF-MEMBERS               PIC 9(5).                   
TIMES1             15  NUM-OF-BENEFITS              PIC 9(3).                   
TIMES2             15  BENEFIT  OCCURS 38 TIMES.                                
ATTRIB                 20  I-D                      PIC X(3).                   
                       20  LIVES                    PIC S9(7)                   
                           SIGN LEADING SEPARATE.                               
                       20  VOLUME                   PIC S9(9)                   
                           SIGN LEADING SEPARATE.                               
                       20  BILLED-PREMIUM           PIC S9(7)V99                
                           SIGN LEADING SEPARATE.                               
