       01  GNA-NAME-ADDRESS.                                                    
      ******************************************************************        
      *    FEB/91 PRANGE        - ADDED GNA-NAAD-PROC-DATE.                     
      *    MAY/13 TAYLOAL       - GRONE; CLONED FROM GMNADTR                    
      ******************************************************************        
           05  GNATRIDENT                          PIC XXX.                     
           05  GNALENGTH                   COMP-3  PIC S9(5).                   
           05  GNAPOST-CODE                        PIC X(6).                    
           05  GNA-030-DATA.                                                    
               10  GNA-030-NAAD-PROC-DATE.                                      
                   15  GNA-030-NAAD-PROC-YEAR      PIC S9(3)    COMP-3.         
                   15  GNA-030-NAAD-PROC-DAY       PIC S9(3)    COMP-3.         
               10  GNA-030-UNDEFINED               PIC X(16).                   
           05  GNA-040-DATA REDEFINES GNA-030-DATA.                             
               10  GNA-040-UNDEFINED               PIC X(20).                   
           05  GNA-045-DATA REDEFINES GNA-030-DATA.                             
               10  GNA-045-IDENT                   PIC X(2).                    
               10  GNA-045-UNDEFINED               PIC X(18).                   
           05  GNA-NAME-ADDR                       PIC X(186).                  
