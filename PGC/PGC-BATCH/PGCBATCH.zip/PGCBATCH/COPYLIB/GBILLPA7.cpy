       01  GBILLING-PAYMENT-RECORD.                                             
      *****************************************************************         
      *                                                               *         
      *     BILLING PAYMENT RECORD.                                             
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *       CREATED BY   GFMINTM4                                   *         
      *                    GFMPREMS                                   *         
      *                    GFMPRMQT                                   *         
      *                                                               *         
      *       USED    BY   GPRBILLS                                   *         
      *                    GPBILLFM                                   *         
      *                    GPRCBIL1                                   *         
      *                                                               *         
      *       REC TYPE     '2'                                        *         
      *       REC LENGTH   60                                         *         
      *                                                               *         
      *****************************************************************         
      *    JUN/93 M. PRANGE                                                     
      *         - ADDED FIELD GBILL-PAY-TAX-CODE                                
      *****************************************************************         
           05  GBILL-PAY-RECORD-LENGTH     COMP SYNC PIC S9(4).         00070000
           05  FILLER                                PIC XX.            00080000
           05  GBILL-PAY-RECORD-TYPE     VALUE '2'   PIC X.             00090000
           05  GBILL-PAY-PRODUCT                     PIC X.             00100000
           05  GBILL-PAY-GROUP-OFFICE                PIC X(5).          00110000
GNE        05  GBILL-PAY-GROUP-NUMBER      COMP-3    PIC S9(7).         00120000
           05  GBILL-PAY-ACCOUNT                     PIC XXX.           00130000
           05  GBILL-PAY-DIVISION          COMP-3    PIC S9(3).         00131000
           05  GBILL-PAY-ORDER                       PIC X.             00140000
           05  GBILL-PAY-PAYMENT-DATE      COMP-3.                      00150000
               10  GBILL-PAY-PAYMENT-YEAR            PIC S9(3).         00160000
               10  GBILL-PAY-PAYMENT-DAY             PIC S9(3).         00170000
           05  FILLER                                PIC XXX.           00180000
           05  GBILL-PAY-PAYMENT-AMOUNT    COMP-3    PIC S9(7)V99.      00190000
           05  GBILL-PAY-REG-TAX                     PIC X.             00200000
           05  GBILL-PAY-TAX-CODE                    PIC X(2).          00200000
GNE        05  FILLER                                PIC X(24).         00210000
