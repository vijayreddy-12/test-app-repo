       01  GRECONDT.                                                            
      ******************************************************************        
      *    CREATED IN PROGRAM 'GFMINTM4'.                                       
      *                                                                         
      *    NEW RECONCIALATION DATE EXTRACT RECORD FOR TERMINATED GROUPS.        
      ******************************************************************        
           05  GRECONDT-REC-TYPE        PIC X(1).                               
REN        05  GRECONDT-GROUP           PIC S9(7)     COMP-3.                   
           05  GRECONDT-ACCT            PIC X(3).                               
           05  GRECONDT-STATUS          PIC X(2).                               
           05  GRECONDT-EFF-DATE.                                               
               10  GRECONDT-EFF-YEAR    PIC S9(3)     COMP-3.                   
               10  GRECONDT-EFF-DAY     PIC S9(3)     COMP-3.                   
           05  GRECONDT-PRO-DATE.                                               
               10  GRECONDT-PRO-YEAR    PIC S9(3)     COMP-3.                   
               10  GRECONDT-PRO-DAY     PIC S9(3)     COMP-3.                   
           05  FILLER                   PIC X(33).                              
