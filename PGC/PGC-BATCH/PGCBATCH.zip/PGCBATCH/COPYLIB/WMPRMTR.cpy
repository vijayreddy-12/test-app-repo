       01  WMPRMTR.                                                     00001000
               05  W-GPSTRIDENT                    PIC XXX.             00002000
               05  W-GPSLENGTH           COMP-3    PIC S9(5).           00003000
               05  W-GPSUNDEFINED1                 PIC X(20).           00004000
               05  W-GPSPREM-SPLIT-INFO.                                00005000
                 06  W-GPSPREM-INFO OCCURS 10 TIMES.                    00006000
                   07  W-GPSCODE                   PIC X.               00007000
                   07  W-GPSTART-DATE    COMP-3.                        00008000
                       09  W-GPSSTART-YEAR         PIC S9(3).           00009000
                       09  W-GPSSTART-DAY          PIC S9(3).           00010000
                   07  W-GPSSTOP-DATE    COMP-3.                        00011000
                       09  W-GPSSTOP-YEAR          PIC S9(3).           00012000
                       09  W-GPSSTOP-DAY           PIC S9(3).           00013000
                   07  W-GPSFIRST-YEAR   COMP-3.                        00014000
                       09  W-GPSFRST-LIFE          PIC S9(5)V99.        00015000
                       09  W-GPSFRST-LTD           PIC S9(5)V99.        00016000
                       09  W-GPSFRST-A-S           PIC S9(5)V99.        00017000
                   07  W-GPSUNDEFINED2             PIC X(20).           00018000
               05  W-GPSFLAT-AMOUNT REDEFINES W-GPSPREM-SPLIT-INFO.     00019000
               06  W-GPSFLAT-AMNT   OCCURS 10 TIMES.                    00020000
                   07  W-GPSUNDEFINED3             PIC X(9).            00021000
                   07  W-GPSFLAT-AMT.                                   00022000
                       09  W-GPSORIGINAL COMP-3    PIC S9(5)V99.        00023000
                       09  W-GPSREMAINING COMP-3   PIC S9(5)V99.        00024000
                   07  W-GPSUNDEFINED4             PIC X(24).           00025000
