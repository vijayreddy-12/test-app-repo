      ******************************************************                    
      *  COMMISSIONS SYSTEM                                                     
      *  VOPSMEXT  -  VO PSMASTER EXTRACT RECORD                                
      *  (THIS IS THE FILE THAT COMES FROM VO)                                  
      *                                                                         
      *  HUB:  VO PSMASTER POPULATE/UPDATE PROCESSING                           
      *                                                                         
SC1018*  OCT-2018 - ADDED RENEWAL NOTICE PERIOD AT THE END OF LAYOUT            
      ******************************************************                    
                                                                                
       01  VOPSMEXT-RECORD.                                                     
           05  VOPSMX-GROUP-NUMBER                PIC 9(07).                    
           05  VOPSMX-POLICY-YEAR                 PIC 9(03).                    
           05  VOPSMX-NXT-RNEW-DATE.                                            
               10  VOPSMX-NXT-RNEW-YEAR           PIC 9(04).                    
               10  VOPSMX-NXT-RNEW-MONTH          PIC 9(02).                    
               10  VOPSMX-NXT-RNEW-DAY            PIC 9(02).                    
           05  VOPSMX-COMB-EFF           OCCURS 5.                              
               10  VOPSMX-EFF-DATE.                                             
                   15  VOPSMX-EFF-YEAR            PIC 9(04).                    
                   15  VOPSMX-EFF-MONTH           PIC 9(02).                    
                   15  VOPSMX-EFF-DAY             PIC 9(02).                    
               10  VOPSMX-COMB-IND                PIC X(01).                    
SC1018     05  VOPSMX-REN-NOT-PER                 PIC 9(03).                    
