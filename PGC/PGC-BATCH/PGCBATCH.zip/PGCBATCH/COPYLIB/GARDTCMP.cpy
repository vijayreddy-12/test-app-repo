      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GARDTCMP                             10/26/10  17:02  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GARDTCMP.                                                            
           05  GARDTCMP-DATE-AREA.                                              
               10  GARDTCMP-YYYYMMDD.                                           
                   15  GARDTCMP-YYYY                    PIC 9(4).               
                   15  GARDTCMP-MM                      PIC 9(2).               
                   15  GARDTCMP-DD                      PIC 9(2).               
               10  GARDTCMP-FORMATTED-YYYYMMDD.                                 
                   15  GARDTCMP-FORMATTED-YYYY          PIC 9(4).               
                   15  GARDTCMP-FORMATTED-MM            PIC 9(2).               
                   15  GARDTCMP-FORMATTED-DD            PIC 9(2).               
