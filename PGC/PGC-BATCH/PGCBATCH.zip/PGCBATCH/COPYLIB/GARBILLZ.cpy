      *01  M-F-C-Bill-Trailer                                                   
      *---------------------------------------------------------------*         
      * BILLING TRAILER DATA DEFINITION - (FOR XML USAGE)             *         
      *---------------------------------------------------------------*         
           05  BILL-INFORMATION.                                                
               10  RECORD-TYPE      VALUE 'Z'       PIC X(1).                   
DATE1          10  PROCESS-DATE     VALUE SPACES    PIC X(8).                   
DATE1          10  PREPARED-DATE    VALUE SPACES    PIC X(8).                   
DATE1          10  PREMIUM-DUE-DATE VALUE SPACES    PIC X(8).                   
               10  COPY-IND         VALUE SPACES    PIC X(1).                   
               10  RECORD-COUNT     VALUE ZERO      PIC 9(9).                   
