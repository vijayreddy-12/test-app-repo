                                                                        00010000
      *  THESE ARE THE PRINT PARAMETERS FOR GSPLIRT                     00020000
      *   HISTORY                                                       00030001
      *                                                                 00040001
      *   JUN-17-87  THOM     - ADD SYS027 FOR ERROR REG                00050002
      *                       - SEE REQUESTS 532,534                    00060001
      *   JAN-19-88  MARCUS   - ADD SYS028,29                           00061005
      *                       - SEE REQUESTS 605                        00062004
      *                                                                 00070001
      *  NOTE-WHEN ADDING NEW PRINT PARAMETERS, CHANGE OCCURS           00080002
      *       CLAUSES IN GSPTRAN1 FOR REDEFINE OF THESE PARMS.          00090002
      *                                                                 00100002
                                                                        00110000
       01  PRINT-PARAMETERS.                                            00120000
           03  PRINT-SYS022        PIC X(6)            VALUE 'SYS022'.  00130000
           03  PRINT-SYS023        PIC X(6)            VALUE 'SYS023'.  00140000
           03  PRINT-SYS024        PIC X(6)            VALUE 'SYS024'.  00150000
           03  PRINT-SYS025        PIC X(6)            VALUE 'SYS025'.  00160000
           03  PRINT-SYS026        PIC X(6)            VALUE 'SYS026'.  00170000
           03  PRINT-SYS027        PIC X(6)            VALUE 'SYS027'.  00180000
           03  PRINT-SYS028        PIC X(6)            VALUE 'SYS028'.  00190003
           03  PRINT-SYS029        PIC X(6)            VALUE 'SYS029'.  00191004
                                                                        00200000
           03  PRINT-RETURN22      PIC S9      COMP-3  VALUE +0.        00210000
           03  PRINT-RETURN23      PIC S9      COMP-3  VALUE +0.        00220000
           03  PRINT-RETURN24      PIC S9      COMP-3  VALUE +0.        00230000
           03  PRINT-RETURN25      PIC S9      COMP-3  VALUE +0.        00240000
           03  PRINT-RETURN26      PIC S9      COMP-3  VALUE +0.        00250000
           03  PRINT-RETURN27      PIC S9      COMP-3  VALUE +0.        00260000
           03  PRINT-RETURN28      PIC S9      COMP-3  VALUE +0.        00270003
           03  PRINT-RETURN29      PIC S9      COMP-3  VALUE +0.        00271004
                                                                        00280000
           03  PRINT-RECSIZE       PIC 9(5)            VALUE 00133.     00290000
                                                                        00300000
           03  PRINT-BLKSIZE       PIC 9(5)            VALUE 03990.     00310000
                                                                        00320000
           03  PRINT-FORMATT       PIC XX              VALUE 'FB'.      00330000
                                                                        00340000
           03  PRINT-COUNTER22     PIC S9(7)   COMP-3  VALUE +0.        00350000
           03  PRINT-COUNTER23     PIC S9(7)   COMP-3  VALUE +0.        00360000
           03  PRINT-COUNTER24     PIC S9(7)   COMP-3  VALUE +0.        00370000
           03  PRINT-COUNTER25     PIC S9(7)   COMP-3  VALUE +0.        00380000
           03  PRINT-COUNTER26     PIC S9(7)   COMP-3  VALUE +0.        00390000
           03  PRINT-COUNTER27     PIC S9(7)   COMP-3  VALUE +0.        00400000
           03  PRINT-COUNTER28     PIC S9(7)   COMP-3  VALUE +0.        00410003
           03  PRINT-COUNTER29     PIC S9(7)   COMP-3  VALUE +0.        00411004
                                                                        00420000
           03  PAGE-CTR22          PIC S9(5)   COMP-3  VALUE +0.        00430000
           03  PAGE-CTR23          PIC S9(5)   COMP-3  VALUE +0.        00440000
           03  PAGE-CTR24          PIC S9(5)   COMP-3  VALUE +0.        00450000
           03  PAGE-CTR25          PIC S9(5)   COMP-3  VALUE +0.        00460000
           03  PAGE-CTR26          PIC S9(5)   COMP-3  VALUE +0.        00470000
           03  PAGE-CTR27          PIC S9(5)   COMP-3  VALUE +0.        00480000
           03  PAGE-CTR28          PIC S9(5)   COMP-3  VALUE +0.        00490003
           03  PAGE-CTR29          PIC S9(5)   COMP-3  VALUE +0.        00500004
