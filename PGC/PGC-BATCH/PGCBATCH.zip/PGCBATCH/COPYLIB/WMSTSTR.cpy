       01  WWMSTSTR.                                                    00001000
               05  W-GSTTRIDENT                    PIC XXX.             00002000
               05  W-GSTLENGTH           COMP-3    PIC S9(5).           00003000
               05  W-GSTPAID-IND                   PIC X.               00004000
               05  W-GSTOUTSTANDING      COMP-3.                        00005000
                   07  W-GSTOUT-LIFE               PIC S9(7)V99.        00006000
                   07  W-GSTOUT-LTD                PIC S9(7)V99.        00007000
                   07  W-GSTOUT-A-S                PIC S9(7)V99.        00008000
                   07  W-GSTOUT-ADMIN-FEE          PIC S9(7)V99.        00009000
               05  W-GSTPREMIUM-IND                PIC X.               00010000
               05  W-GSTADVANCE          COMP-3    PIC S9(7)V99.        00011000
               05  W-GSTCALENDAR-YEAR-TO-DATE                           00012000
                                       COMP-3.                          00013000
                   07  W-GSTCAL-YTD-LIFE.                               00014000
                       09  W-GSTCAL-YTD-LI-BILLED  PIC S9(7)V99.        00015000
                       09  W-GSTCAL-YTD-LI-PAID    PIC S9(7)V99.        00016000
                   07  W-GSTCAL-YTD-A-S.                                00017000
                       09  W-GSTCAL-YTD-AS-BILLED  PIC S9(7)V99.        00018000
                       09  W-GSTCAL-YTD-AS-PAID    PIC S9(7)V99.        00019000
                   07  W-GSTCAL-YTD-LTD.                                00020000
                       09  W-GSTCAL-YTD-LTD-BILLED PIC S9(7)V99.        00021000
                       09  W-GSTCAL-YTD-LTD-PAID   PIC S9(7)V99.        00022000
                   07  W-GSTCAL-YTD-ADMIN-FEE.                          00023000
                       09  W-GSTCAL-YTD-ADMIN-FEE-BILLED PIC S9(7)V99.  00024000
                       09  W-GSTCAL-YTD-ADMIN-FEE-PAID   PIC S9(7)V99.  00025000
               05  W-GSTPREMIUMS         COMP-3.                        00026000
                   07  W-GSTPREM-LIFE              PIC S9(7)V99.        00027000
                   07  W-GSTPREM-LTD               PIC S9(7)V99.        00028000
                   07  W-GSTPREM-AD-D              PIC S9(7)V99.        00029000
                   07  W-GSTPREM-WI                PIC S9(7)V99.        00030000
                   07  W-GSTPREM-EHC.                                   00031000
                       09  W-GSTPREM-EHC-SINGLE    PIC S9(7)V99.        00032000
                       09  W-GSTPREM-EHC-FAMILY1   PIC S9(7)V99.        00033000
                       09  W-GSTPREM-EHC-FAMILY2   PIC S9(7)V99.        00034000
                   07  W-GSTPREM-DEN.                                   00035000
                       09  W-GSTPREM-DEN-SINGLE    PIC S9(7)V99.        00036000
                       09  W-GSTPREM-DEN-FAMILY1   PIC S9(7)V99.        00037000
                       09  W-GSTPREM-DEN-FAMILY2   PIC S9(7)V99.        00038000
               05  W-GSTCURR-MONTH-PREM-ADJ                             00039000
                                       COMP-3.                          00040000
                   07  W-GSTPREM-ADJ-LIFE          PIC S9(5)V99.        00041000
                   07  W-GSTPREM-ADJ-LTD           PIC S9(5)V99.        00042000
                   07  W-GSTPREM-ADJ-AD-D          PIC S9(5)V99.        00043000
                   07  W-GSTPREM-ADJ-WI            PIC S9(5)V99.        00044000
                   07  W-GSTPREM-ADJ-EHC.                               00045000
                       09  W-GSTPREM-ADJ-EHC-SINGLE  PIC S9(5)V99.      00046000
                       09  W-GSTPREM-ADJ-EHC-FAMILY1 PIC S9(5)V99.      00047000
                       09  W-GSTPREM-ADJ-EHC-FAMILY2 PIC S9(5)V99.      00048000
                   07  W-GSTPREM-ADJ-DEN.                               00049000
                       09  W-GSTPREM-ADJ-DEN-SINGLE  PIC S9(5)V99.      00050000
                       09  W-GSTPREM-ADJ-DEN-FAMILY1 PIC S9(5)V99.      00051000
                       09  W-GSTPREM-ADJ-DEN-FAMILY2 PIC S9(5)V99.      00052000
               05  W-GSTPROJECTED-LOSS-RATIO COMP-3.                    00053000
                   07  W-GSTPROJ-LR-PREV-POLYR     PIC S9(4)V9.         00054000
                   07  W-GSTPROJ-LR-CURR-POLYR     PIC S9(4)V9.         00055000
               05  W-GSTACCEPT-LOSS-PREV   COMP-3  PIC S9(4)V9.         00056000
               05  W-GSTPART               COMP-3  PIC S9(7).           00057000
               05  W-GSTNON-PART           COMP-3  PIC S9(5).           00058000
               05  W-GSTUNDEFINED                  PIC X(33).           00059000
               05  W-GSTNUM-COV-CODES      COMP-3  PIC S9(3).           00060000
               05  W-GSTSTATS-BY-COV OCCURS 15 TIMES COMP-3.            00061000
                   07  W-GSTSTAT-COV-CODE          PIC S9(3).           00062000
                   07  W-GSTSTAT-VOL               PIC S9(9).           00063000
                   07  W-GSTSTAT-LIVES             PIC S9(7).           00064000
