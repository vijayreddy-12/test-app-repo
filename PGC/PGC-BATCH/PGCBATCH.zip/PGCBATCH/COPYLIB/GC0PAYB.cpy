      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORPAYBASIS' TO DBLINK-CURR-PARAGRAPH.              
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORPAYBASIS' TO RECORD-NAME.                                 
           MOVE 'GW-COMP-AREA1' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORPAYBASIS TO DBLINK-RECORD-MADE-CURRENT.             
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORPAYBASIS-EXIT                                
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE AGENT-NUMBER OF GC-TPAYB TO DBLINK-GWCORPAYBASIS-01         
               MOVE PAY-BASIS-EFF-YEAR OF GC-TPAYB TO                           
                   DBLINK-GWCORPAYBASIS-02                                      
               MOVE PAY-BASIS-EFF-DAY OF GC-TPAYB TO                            
                   DBLINK-GWCORPAYBASIS-03                                      
               MOVE PAY-BASIS-END-YEAR OF GC-TPAYB TO                           
                   DBLINK-GWCORPAYBASIS-04                                      
               MOVE PAY-BASIS-END-DAY OF GC-TPAYB TO                            
                   DBLINK-GWCORPAYBASIS-05                                      
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORPAYBASIS TO DBLINK-VIEW-NAME-CURRENT.               
           MOVE DBLINK-GWCORPAYBASIS-KEY TO DBLINK-VIEW-200-CURRENT.            
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET AGENT-PAYBASIS  M/A                                                 
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-AGENT-PAYBASIS-F                        
           MOVE AGENT-NUMBER OF GC-TPAYB TO DBLINK-AGENT-PAYBASIS-01.           
           MOVE PAY-BASIS-EFF-YEAR OF GC-TPAYB TO                               
               DBLINK-AGENT-PAYBASIS-02.                                        
           MOVE PAY-BASIS-EFF-DAY OF GC-TPAYB TO                                
               DBLINK-AGENT-PAYBASIS-03.                                        
           MOVE PAY-BASIS-END-YEAR OF GC-TPAYB TO                               
               DBLINK-AGENT-PAYBASIS-04.                                        
           MOVE PAY-BASIS-END-DAY OF GC-TPAYB TO                                
               DBLINK-AGENT-PAYBASIS-05.                                        
