       01  GCOMDATE.                                                            
      *************************************************************             
      *                                                           *             
      *          COMMISSION DATE RECORD                           *             
      *                                                           *             
      *************************************************************             
                                                                                
           05  GDAT-AGENT-COMP-KEY.                                             
               10  GDAT-GROUP-ACCOUNT.                                          
REN                15  GDAT-GROUP-NUMBER  VALUE LOW-VALUES  PIC X(7).           
                   15  GDAT-GR-ACCOUNT    VALUE LOW-VALUES  PIC X(3).           
               10  GDAT-REC-TYPE          VALUE 'D'         PIC X.              
               10  GDAT-GROUP-COMP-KEY.                                         
                   15  GDAT-RUN-DATE.                                           
                       20  GDAT-RUN-YEAR       COMP-3       PIC S9(3).          
                       20  GDAT-RUN-DAY        COMP-3       PIC S9(3).          
GNE        05  FILLER                     VALUE SPACES      PIC X(62).  00015000
