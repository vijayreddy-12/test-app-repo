      *      CREATED BY CONVERT/DB V8R01 ON 11/04/10 AT 08:29         *         
           MOVE '985-CURR-GWCORCOMP' TO DBLINK-CURR-PARAGRAPH.                  
                                                                                
      *%****************************** *                                        
      *%INITIALIZE DBLINK SUBSCHEMA-CTRL                                        
      *%****************************** *                                        
           MOVE ZEROS TO ERROR-STATUS.                                          
           MOVE SPACES TO ERROR-AREA.                                           
           MOVE SPACES TO ERROR-SET.                                            
           MOVE SPACES TO ERROR-RECORD.                                         
           MOVE 'GWCORCOMP' TO RECORD-NAME.                                     
           MOVE 'GW-COMP-AREA2' TO AREA-NAME.                                   
                                                                                
      *%****************************** *                                        
      *%CLOSE ALL RECORD-RELATED CURSORS                                        
      *%****************************** *                                        
           MOVE DBLINK-GWCORCOMP TO DBLINK-RECORD-MADE-CURRENT.                 
           MOVE ' ' TO DBLINK-CURSOR-NAME-WORK.                                 
           PERFORM 991-CLOSE-CURSORS                                            
              THRU 991-CLOSE-CURSORS-EXIT.                                      
           IF ERROR-STATUS = DBLINK-SQL-ERROR                                   
               GO TO 985-CURR-GWCORCOMP-EXIT                                    
           END-IF.                                                              
           MOVE ' ' TO DBLINK-RECORD-MADE-CURRENT.                              
                                                                                
      *%****************************** *                                        
      *%SET RECORD KEY                                                          
      *%****************************** *                                        
           IF DBLINK-TYPE-GET NOT = DBLINK-CURR                                 
               MOVE GROUP-NUMBER OF GC-TCOMP TO DBLINK-GWCORCOMP-01             
               MOVE GR-ACCOUNT OF GC-TCOMP TO DBLINK-GWCORCOMP-02               
               MOVE COMP-EFF-YEAR OF GC-TCOMP TO DBLINK-GWCORCOMP-03            
               MOVE COMP-EFF-DAY OF GC-TCOMP TO DBLINK-GWCORCOMP-04             
               MOVE GRACT-COMP-TS OF GC-TCOMP TO DBLINK-GWCORCOMP-05            
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET CURRENT OF RUN-UNIT                                                 
      *%****************************** *                                        
           MOVE DBLINK-GWCORCOMP TO DBLINK-VIEW-NAME-CURRENT.                   
           MOVE DBLINK-GWCORCOMP-KEY TO DBLINK-VIEW-200-CURRENT.                
           MOVE FC-IDENT TO DBLINK-GWCORCOMP-ID-KEY                             
           MOVE DBLINK-GWCORCOMP-ID-KEY TO DBKEY.                               
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS WHICH RECORD OWNS                                     
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET KEYS FOR SETS IN WHICH RECORD IS MEMBER                             
      *%****************************** *                                        
                                                                                
      *%****************************** *                                        
      *%SET AGENT-COMP  M/A                                                     
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-AGENT-COMP-F                            
           MOVE AGENT-NUMBER OF GC-TCOMP TO DBLINK-AGENT-COMP-01.               
           MOVE AGENT-COMP-TS OF GC-TCOMP TO DBLINK-AGENT-COMP-02.              
                                                                                
      *%****************************** *                                        
      *%SET GFO-COMP  M/M                                                       
      *%****************************** *                                        
           MOVE DBLINK-NOT-MEMBER TO DBLINK-GFO-COMP-F                          
           IF GFO-COMP-FLAG = DBLINK-MEMBER                                     
               MOVE GFO-COMP-FLAG TO DBLINK-GFO-COMP-F                          
               MOVE GFO-NUMBER OF GC-TCOMP TO DBLINK-GFO-COMP-01                
               MOVE GFO-COMP-TS OF GC-TCOMP TO DBLINK-GFO-COMP-02               
           END-IF.                                                              
                                                                                
      *%****************************** *                                        
      *%SET GRACCT-COMP  M/A                                                    
      *%****************************** *                                        
           MOVE DBLINK-MEMBER TO DBLINK-GRACCT-COMP-F                           
           MOVE GROUP-NUMBER OF GC-TCOMP TO DBLINK-GRACCT-COMP-01.              
           MOVE GR-ACCOUNT OF GC-TCOMP TO DBLINK-GRACCT-COMP-02.                
           MOVE COMP-EFF-YEAR OF GC-TCOMP TO DBLINK-GRACCT-COMP-03.             
           MOVE COMP-EFF-DAY OF GC-TCOMP TO DBLINK-GRACCT-COMP-04.              
           MOVE GRACT-COMP-TS OF GC-TCOMP TO DBLINK-GRACCT-COMP-05.             
