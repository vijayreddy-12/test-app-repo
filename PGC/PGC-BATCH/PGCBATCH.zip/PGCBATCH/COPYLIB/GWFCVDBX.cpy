      *================================================================*        
      *  CBCVDBXD - Parms for IDDTECNV (date conversion) subroutine    *        
      *================================================================*        
       01  DBLINKX-DATE-TIME-PARMS.                                             
                                                                                
           05  DBLINKX-REQUEST-CODE         PIC X(1)    VALUE SPACE.            
               88  DBLINKX-DATE-IDMS-TO-SQL             VALUE '1'.              
               88  DBLINKX-DATE-SQL-TO-IDMS             VALUE '2'.              
               88  DBLINKX-TIME-IDMS-TO-SQL             VALUE '3'.              
               88  DBLINKX-TIME-SQL-TO-IDMS             VALUE '4'.              
               88  DBLINKX-DATE-CONVERSION              VALUE '1' '2'.          
               88  DBLINKX-TIME-CONVERSION              VALUE '3' '4'.          
                                                                                
           05  DBLINKX-RETURN-CODE          PIC X(1)    VALUE SPACE.            
               88  DBLINKX-OK                           VALUE '0'.              
               88  DBLINKX-ERROR-OCCURRED               VALUE '1'               
                                                         THRU '9'.              
               88  DBLINKX-INVALID-REQUEST-CODE         VALUE '1'.              
               88  DBLINKX-INVALID-FORMAT-TYPE          VALUE '2'.              
               88  DBLINKX-INVALID-IDMS-DATE            VALUE '3'.              
               88  DBLINKX-INVALID-IDMS-TIME            VALUE '4'.              
               88  DBLINKX-MISC-ERROR                   VALUE '9'.              
                                                                                
           05  DBLINKX-SQL-DATE-FORMAT      PIC X(1)    VALUE SPACE.            
               88  DBLINKX-SQL-DATE-ISO                 VALUE '1'.              
               88  DBLINKX-SQL-DATE-USA                 VALUE '2'.              
               88  DBLINKX-SQL-DATE-EUR                 VALUE '3'.              
               88  DBLINKX-SQL-DATE-JIS                 VALUE '4'.              
               88  DBLINKX-VALID-SQL-DATE-FORMAT        VALUE '1'               
                                                         THRU '4'.              
           05  DBLINKX-SQL-TIME-FORMAT      PIC X(1)    VALUE SPACE.            
               88  DBLINKX-SQL-TIME-ISO                 VALUE '1'.              
               88  DBLINKX-SQL-TIME-USA                 VALUE '2'.              
               88  DBLINKX-SQL-TIME-EUR                 VALUE '3'.              
               88  DBLINKX-SQL-TIME-JIS                 VALUE '4'.              
               88  DBLINKX-VALID-SQL-TIME-FORMAT        VALUE '1'               
                                                         THRU '4'.              
           05  DBLINKX-IDMS-DATE-FORMAT     PIC X(2)    VALUE SPACE.            
               88  DBLINKX-IDMS-DATE-YYYYMMDD           VALUE '01'.             
               88  DBLINKX-IDMS-DATE-YYMMDD             VALUE '02'.             
               88  DBLINKX-IDMS-DATE-MMDDYY             VALUE '03'.             
               88  DBLINKX-IDMS-DATE-YYDDD              VALUE '04'.             
               88  DBLINKX-IDMS-DATE-CCYYDDD            VALUE '05'.             
               88  DBLINKX-IDMS-DATE-YYYYDDD            VALUE '05'.             
               88  DBLINKX-IDMS-DATE-MMDDCCYY           VALUE '06'.             
               88  DBLINKX-IDMS-DATE-MMDDYYYY           VALUE '06'.             
               88  DBLINKX-IDMS-DATE-CYYMMDD            VALUE '07'.             
               88  DBLINKX-IDMS-DATE-DDMMMYY            VALUE '09'.             
               88  DBLINKX-VALID-IDMS-DATE-FORMAT       VALUE '01'              
                                                         THRU '09'.             
                                                                                
           05  DBLINKX-IDMS-TIME-FORMAT     PIC X(2)    VALUE SPACE.            
               88  DBLINKX-IDMS-TIME-HHMMSS             VALUE '51'.             
               88  DBLINKX-IDMS-TIME-HHCMMCSS           VALUE '52'.             
               88  DBLINKX-IDMS-TIME-HHMMSSNNN          VALUE '53'.             
               88  DBLINKX-IDMS-TIME-HHMM               VALUE '54'.             
               88  DBLINKX-IDMS-TIME-HHMMSSSS           VALUE '55'.             
               88  DBLINKX-IDMS-TIME-HHMMX              VALUE '56'.             
               88  DBLINKX-IDMS-TIME-HHMMNNN            VALUE '57'.             
               88  DBLINKX-VALID-IDMS-TIME-FORMAT       VALUE '51'              
                                                         THRU '57'.             
           05  DBLINKX-NULL-SQL-DATE-ISO    PIC X(10)   VALUE                   
                                                        '0001-01-01'.           
           05  DBLINKX-NULL-SQL-DATE-USA    PIC X(10)   VALUE                   
                                                        '01/01/0001'.           
           05  DBLINKX-NULL-SQL-DATE-EUR    PIC X(10)   VALUE                   
                                                        '01.01.0001'.           
           05  DBLINKX-NULL-SQL-DATE-JIS    PIC X(10)   VALUE                   
                                                        '0001-01-01'.           
           05  DBLINKX-NULL-SQL-TIME-ISO    PIC X(8)    VALUE                   
                                                        '00.00.00'.             
           05  DBLINKX-NULL-SQL-TIME-USA    PIC X(8)    VALUE                   
                                                        '00:00 AM'.             
           05  DBLINKX-NULL-SQL-TIME-EUR    PIC X(8)    VALUE                   
                                                        '00.00.00'.             
           05  DBLINKX-NULL-SQL-TIME-JIS    PIC X(8)    VALUE                   
                                                        '00:00:00'.             
           05  DBLINKX-NULL-TIMESTAMP       PIC X(26)   VALUE                   
                                         '0001-01-01-00.00.00.000000'.          
           05  FILLER                       PIC X(200)  VALUE SPACES.           
           05  DBLINKX-INPUT-PARM           PIC X(32)   VALUE SPACE.            
           05  DBLINKX-INPUT-PARM-00        REDEFINES                           
                                            DBLINKX-INPUT-PARM                  
                                            PIC X(32).                          
           05  DBLINKX-INPUT-00             REDEFINES                           
                                            DBLINKX-INPUT-PARM                  
                                            PIC X(32).                          
           05  DBLINKX-INPUT-04-GROUP       REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-04         PIC 9(4).                           
               10  FILLER                   PIC X(28).                          
           05  DBLINKX-INPUT-PARM-04-GROUP  REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-PARM-04    PIC 9(4).                           
               10  FILLER                   PIC X(28).                          
           05  DBLINKX-INPUT-05-GROUP       REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-05         PIC 9(5).                           
               10  FILLER                   PIC X(27).                          
           05  DBLINKX-INPUT-PARM-05-GROUP  REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-PARM-05    PIC 9(5).                           
               10  FILLER                   PIC X(27).                          
           05  DBLINKX-INPUT-06-GROUP       REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-06         PIC 9(6).                           
               10  FILLER                   PIC X(26).                          
           05  DBLINKX-INPUT-PARM-06-GROUP  REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-PARM-06    PIC 9(6).                           
               10  FILLER                   PIC X(26).                          
           05  DBLINKX-INPUT-07-GROUP       REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-07         PIC 9(7).                           
               10  FILLER                   PIC X(25).                          
           05  DBLINKX-INPUT-PARM-07-GROUP  REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-PARM-07    PIC 9(7).                           
               10  FILLER                   PIC X(25).                          
           05  DBLINKX-INPUT-08-GROUP       REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-08         PIC 9(8).                           
               10  FILLER                   PIC X(24).                          
           05  DBLINKX-INPUT-PARM-08-GROUP  REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-PARM-08    PIC 9(8).                           
               10  FILLER                   PIC X(24).                          
           05  DBLINKX-INPUT-09-GROUP       REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-09         PIC 9(9).                           
               10  FILLER                   PIC X(23).                          
           05  DBLINKX-INPUT-PARM-09-GROUP  REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-PARM-09    PIC 9(9).                           
               10  FILLER                   PIC X(23).                          
           05  DBLINKX-INPUT-10-GROUP       REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-10         PIC 9(10).                          
               10  FILLER                   PIC X(22).                          
           05  DBLINKX-INPUT-PARM-10-GROUP  REDEFINES                           
                                            DBLINKX-INPUT-PARM.                 
               10  DBLINKX-INPUT-PARM-10    PIC 9(10).                          
               10  FILLER                   PIC X(22).                          
           05  DBLINKX-OUTPUT-PARM          PIC X(32)   VALUE SPACE.            
           05  DBLINKX-OUTPUT-00            REDEFINES                           
                                            DBLINKX-OUTPUT-PARM                 
                                            PIC X(32).                          
           05  DBLINKX-OUTPUT-PARM-00       REDEFINES                           
                                            DBLINKX-OUTPUT-PARM                 
                                            PIC X(32).                          
           05  DBLINKX-OUTPUT-04-GROUP      REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-04        PIC 9(4).                           
               10  FILLER                   PIC X(28).                          
           05  DBLINKX-OUTPUT-PARM-04-GROUP REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-PARM-04   PIC 9(4).                           
               10  FILLER                   PIC X(28).                          
           05  DBLINKX-OUTPUT-05-GROUP      REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-05        PIC 9(5).                           
               10  FILLER                   PIC X(27).                          
           05  DBLINKX-OUTPUT-PARM-05-GROUP REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-PARM-05   PIC 9(5).                           
               10  FILLER                   PIC X(27).                          
           05  DBLINKX-OUTPUT-06-GROUP      REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-06        PIC 9(6).                           
               10  FILLER                   PIC X(26).                          
           05  DBLINKX-OUTPUT-PARM-06-GROUP REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-PARM-06   PIC 9(6).                           
               10  FILLER                   PIC X(26).                          
           05  DBLINKX-OUTPUT-07-GROUP      REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-07        PIC 9(7).                           
               10  FILLER                   PIC X(25).                          
           05  DBLINKX-OUTPUT-PARM-07-GROUP REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-PARM-07   PIC 9(7).                           
               10  FILLER                   PIC X(25).                          
           05  DBLINKX-OUTPUT-08-GROUP      REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-08        PIC 9(8).                           
               10  FILLER                   PIC X(24).                          
           05  DBLINKX-OUTPUT-PARM-08-GROUP REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-PARM-08   PIC 9(8).                           
               10  FILLER                   PIC X(24).                          
           05  DBLINKX-OUTPUT-09-GROUP      REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-09        PIC 9(9).                           
               10  FILLER                   PIC X(23).                          
           05  DBLINKX-OUTPUT-PARM-09-GROUP REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-PARM-09   PIC 9(9).                           
               10  FILLER                   PIC X(23).                          
           05  DBLINKX-OUTPUT-10-GROUP      REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-10        PIC 9(10).                          
               10  FILLER                   PIC X(22).                          
           05  DBLINKX-OUTPUT-PARM-10-GROUP REDEFINES                           
                                            DBLINKX-OUTPUT-PARM.                
               10  DBLINKX-OUTPUT-PARM-10   PIC 9(10).                          
               10  FILLER                   PIC X(22).                          
      *===================== END CBCVDBXD COPY ========================*        
                                                                                
