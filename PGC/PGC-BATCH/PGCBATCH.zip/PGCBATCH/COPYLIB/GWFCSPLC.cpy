           20  FCCSPLCA-C.                                                      
               25  FILLER                   PIC X(16)                           
                   VALUE 'START FCCSPLCA'.                                      
             25  FCCSPL-CONTROL-FIELDS.                                         
               30  FCCSPL-RETURN-CODE       PIC X.                              
                   88  FCCSPL-SUCCESSFUL-RETURN       VALUE '0'.                
                   88  FCCSPL-ABNORMAL-RETURN         VALUE '1'.                
               30  FCCSPL-PROGRAM-NAME      PIC X(8).                           
               30  FCCSPL-IO-MODULE-NAME    PIC X(8).                           
               30  FCCSPL-DML-SEQ-NO        PIC 9(4).                           
               30  FCCSPL-ERROR-MESSAGE     PIC X(80).                          
               30  FCCSPL-PROGRAM-QUEUE     PIC X(8).                           
               30  FCCSPL-RECORD-QUEUE      PIC X(8).                           
               30  FCCSPL-CURRTABL-QUEUE.                                       
                   35  FCCSPL-CURRTABL-TERM PIC X(4).                           
                   35  FCCSPL-CURRTABL-Q-ID PIC X(4).                           
               30  FCCSPL-CBRSKEYS-QUEUE.                                       
                   35  FCCSPL-CBRSKEYS-TERM PIC X(4).                           
                   35  FCCSPL-CBRSKEYS-Q-ID PIC X(4).                           
               30  FCCSPL-CBRSKEYS-LENGTH   PIC S9(4)         COMP.             
               30  FCCSPL-CICS-RESP         PIC S9(8)         COMP.             
               30  FCCSPL-SQLCODE           PIC -999.                           
               30  FCCSPL-NUM-ADDR          PIC 9(3)          COMP-3.           
               30  FCCSPL-SYNCH-ERROR-FLAG  PIC X.                              
               30  FCCSPL-PGM-IDMS-SQL-FLAG PIC X.                              
                   88  FCCSPL-PGM-IDMS-YES            VALUE 'I' 'B'.            
                   88  FCCSPL-PGM-SQL-YES             VALUE 'D' 'B'.            
                   88  FCCSPL-PGM-IDMS-ONLY           VALUE 'I'.                
                   88  FCCSPL-PGM-SQL-ONLY            VALUE 'D'.                
                   88  FCCSPL-PGM-IDMS-AND-SQL        VALUE 'B'.                
               30  FCCSPL-REC-IDMS-SQL-FLAG PIC X.                              
                   88  FCCSPL-REC-IDMS-YES            VALUE 'I' 'B'.            
                   88  FCCSPL-REC-SQL-YES             VALUE 'D' 'B'.            
                   88  FCCSPL-REC-IDMS-ONLY           VALUE 'I'.                
                   88  FCCSPL-REC-SQL-ONLY            VALUE 'D'.                
                   88  FCCSPL-REC-IDMS-AND-SQL        VALUE 'B'.                
               30  FCCSPL-IDMS-SQL-FLAG     PIC X.                              
                   88  FCCSPL-IDMS-YES                VALUE 'I' 'B'.            
                   88  FCCSPL-SQL-YES                 VALUE 'D' 'B'.            
                   88  FCCSPL-IDMS-ONLY               VALUE 'I'.                
                   88  FCCSPL-SQL-ONLY                VALUE 'D'.                
                   88  FCCSPL-IDMS-AND-SQL            VALUE 'B'.                
      *                                                                         
      * THIS NEXT STRUCTURE IS PASSED TO FCADDR                                 
      * CHANGES TO THIS STRUCTURE WILL REQUIRE CHANGES TO FCADDR                
      *                                                                         
             25  FCCSPL-ADDRESS-AREA.                                           
             30  FCCSPL-ADDRESS-COUNT       PIC S9(4) COMP SYNC.                
             30  FCCSPL-ADDRESSES.                                              
               35  FCCSPL-ADDRESS-BASE      OCCURS 75 TIMES                     
                                            PIC S9(9) COMP.                     
             30  FCCSPL-ADDRESSES-REDEF     REDEFINES FCCSPL-ADDRESSES.         
               35  FCCSPL-ADDR-METHOD       POINTER.                            
               35  FCCSPL-ADDR-I-O-MODULE   POINTER.                            
               35  FCCSPL-ADDRESS-3         POINTER.                            
               35  FCCSPL-ADDRESS-4         POINTER.                            
               35  FCCSPL-ADDRESS-5         POINTER.                            
               35  FCCSPL-ADDRESS-6         POINTER.                            
               35  FCCSPL-ADDRESS-7         POINTER.                            
               35  FCCSPL-ADDRESS-8         POINTER.                            
               35  FCCSPL-ADDRESS-9         POINTER.                            
               35  FCCSPL-ADDRESS-10        POINTER.                            
               35  FCCSPL-ADDRESS-11        POINTER.                            
               35  FCCSPL-ADDRESS-12        POINTER.                            
               35  FCCSPL-ADDRESS-13        POINTER.                            
               35  FCCSPL-ADDRESS-14        POINTER.                            
               35  FCCSPL-ADDRESS-15        POINTER.                            
               35  FCCSPL-ADDRESS-16        POINTER.                            
               35  FCCSPL-ADDRESS-17        POINTER.                            
               35  FCCSPL-ADDRESS-18        POINTER.                            
               35  FCCSPL-ADDRESS-19        POINTER.                            
               35  FCCSPL-ADDRESS-20        POINTER.                            
               35  FCCSPL-ADDRESS-21        POINTER.                            
               35  FCCSPL-ADDRESS-22        POINTER.                            
               35  FCCSPL-ADDRESS-23        POINTER.                            
               35  FCCSPL-ADDRESS-24        POINTER.                            
               35  FCCSPL-ADDRESS-25        POINTER.                            
               35  FCCSPL-ADDRESS-26        POINTER.                            
               35  FCCSPL-ADDRESS-27        POINTER.                            
               35  FCCSPL-ADDRESS-28        POINTER.                            
               35  FCCSPL-ADDRESS-29        POINTER.                            
               35  FCCSPL-ADDRESS-30        POINTER.                            
               35  FCCSPL-ADDRESS-31        POINTER.                            
               35  FCCSPL-ADDRESS-32        POINTER.                            
               35  FCCSPL-ADDRESS-33        POINTER.                            
               35  FCCSPL-ADDRESS-34        POINTER.                            
               35  FCCSPL-ADDRESS-35        POINTER.                            
               35  FCCSPL-ADDRESS-36        POINTER.                            
               35  FCCSPL-ADDRESS-37        POINTER.                            
               35  FCCSPL-ADDRESS-38        POINTER.                            
               35  FCCSPL-ADDRESS-39        POINTER.                            
               35  FCCSPL-ADDRESS-40        POINTER.                            
               35  FCCSPL-ADDRESS-41        POINTER.                            
               35  FCCSPL-ADDRESS-42        POINTER.                            
               35  FCCSPL-ADDRESS-43        POINTER.                            
               35  FCCSPL-ADDRESS-44        POINTER.                            
               35  FCCSPL-ADDRESS-45        POINTER.                            
               35  FCCSPL-ADDRESS-46        POINTER.                            
               35  FCCSPL-ADDRESS-47        POINTER.                            
               35  FCCSPL-ADDRESS-48        POINTER.                            
               35  FCCSPL-ADDRESS-59        POINTER.                            
               35  FCCSPL-ADDRESS-50        POINTER.                            
               35  FCCSPL-ADDRESS-51        POINTER.                            
               35  FCCSPL-ADDRESS-52        POINTER.                            
               35  FCCSPL-ADDRESS-53        POINTER.                            
               35  FCCSPL-ADDRESS-54        POINTER.                            
               35  FCCSPL-ADDRESS-55        POINTER.                            
               35  FCCSPL-ADDRESS-56        POINTER.                            
               35  FCCSPL-ADDRESS-57        POINTER.                            
               35  FCCSPL-ADDRESS-58        POINTER.                            
               35  FCCSPL-ADDRESS-59        POINTER.                            
               35  FCCSPL-ADDRESS-60        POINTER.                            
               35  FCCSPL-ADDRESS-61        POINTER.                            
               35  FCCSPL-ADDRESS-62        POINTER.                            
               35  FCCSPL-ADDRESS-63        POINTER.                            
               35  FCCSPL-ADDRESS-64        POINTER.                            
               35  FCCSPL-ADDRESS-65        POINTER.                            
               35  FCCSPL-ADDRESS-66        POINTER.                            
               35  FCCSPL-ADDRESS-67        POINTER.                            
               35  FCCSPL-ADDRESS-68        POINTER.                            
               35  FCCSPL-ADDRESS-69        POINTER.                            
               35  FCCSPL-ADDRESS-70        POINTER.                            
               35  FCCSPL-ADDRESS-71        POINTER.                            
               35  FCCSPL-ADDRESS-72        POINTER.                            
               35  FCCSPL-ADDRESS-73        POINTER.                            
               35  FCCSPL-ADDRESS-74        POINTER.                            
               35  FCCSPL-ADDRESS-75        POINTER.                            
             30  FCCSPL-ADDRESS-MATRIX      REDEFINES FCCSPL-ADDRESSES.         
               35  FCCSPL-ADDRESS           OCCURS 75 TIMES                     
                                            POINTER.                            
                                                                                
             25  FCCSPL-MISCELLANEOUS-FIELDS.                                   
               30  FCCSPL-METHOD-NAME       PIC X(40).                          
               30  FCCSPL-RECORD-NAME       PIC X(16).                          
               30  FCCSPL-SET-NAME          PIC X(16).                          
               30  FCCSPL-AREA-NAME         PIC X(16).                          
               30  FCCSPL-SORTKEY           PIC X(200).                         
               30  FCCSPL-KEY               PIC X(200).                         
               30  FCCSPL-DBKEY-VALUE       PIC S9(8)         COMP.             
               30  FCCSPL-A-DBKEY           PIC S9(9)         COMP.             
               30  FCCSPL-ADDR-DBKEY        REDEFINES FCCSPL-A-DBKEY            
                                            POINTER.                            
               30  FCCSPL-A-RECORD          PIC S9(9)         COMP.             
               30  FCCSPL-ADDR-RECORD       REDEFINES FCCSPL-A-RECORD           
                                            POINTER.                            
               30  FCCSPL-IF-TEST-FIELD     PIC X.                              
                   88  FCCSPL-EMPTY                   VALUE '1'.                
                   88  FCCSPL-NOT-EMPTY               VALUE '2'.                
                   88  FCCSPL-MEMBER                  VALUE '3'.                
                   88  FCCSPL-NOT-MEMBER              VALUE '4'.                
               30  FCCSPL-OBTAIN-NTH-VALUE  PIC S9(8)         COMP.             
               30  FCCSPL-ACCEPT-TYPE       PIC X(16).                          
                   88  FCCSPL-ACCEPT-CURRENT          VALUE 'CURRENT'           
                                                            'MOVE'.             
                   88  FCCSPL-ACCEPT-RECORD           VALUE 'RECORD'.           
                   88  FCCSPL-ACCEPT-SET              VALUE 'SET'.              
               30  FCCSPL-ACCEPT-SUBTYPE    PIC X(16).                          
                   88  FCCSPL-ACCEPT-OWNER            VALUE 'OWNER'.            
                   88  FCCSPL-ACCEPT-NEXT             VALUE 'NEXT'.             
                   88  FCCSPL-ACCEPT-PRIOR            VALUE 'PRIOR'.            
               30  FCCSPL-COMMIT-TYPE       PIC X(16).                          
                   88  FCCSPL-TYPE-COMMIT             VALUE  SPACES.            
                   88  FCCSPL-TYPE-COMMIT-ALL         VALUE 'ALL'.              
               30  FCCSPL-ERASE-TYPE        PIC X(16).                          
                   88  FCCSPL-TYPE-ERASE              VALUE  SPACES.            
                   88  FCCSPL-TYPE-ERASE-ALL          VALUE 'ALL'.              
                   88  FCCSPL-TYPE-ERASE-PERMANENT    VALUE 'PERMANENT'.        
                   88  FCCSPL-TYPE-ERASE-SELECTIVE    VALUE 'SELECTIVE'.        
               30  FCCSPL-RETURN-TYPE       PIC X(16).                          
                   88  FCCSPL-TYPE-USING              VALUE 'USING'.            
                   88  FCCSPL-TYPE-FIRST              VALUE 'FIRST'.            
                   88  FCCSPL-TYPE-LAST               VALUE 'LAST'.             
                   88  FCCSPL-TYPE-NEXT               VALUE 'NEXT'.             
                   88  FCCSPL-TYPE-PRIOR              VALUE 'PRIOR'.            
               30  FCCSPL-FIND-OR-OBTAIN    PIC X(16).                          
                   88  FCCSPL-TYPE-FIND               VALUE 'FIND'.             
                   88  FCCSPL-TYPE-OBTAIN             VALUE 'OBTAIN'.           
               30  FCCSPL-OBTAIN-CALC-TYPE  PIC X(16).                          
                   88  FCCSPL-TYPE-OBTAIN-CALC        VALUE 'CALC'.             
                   88  FCCSPL-TYPE-OBTAIN-DUPLICATE   VALUE                     
                       'DUPLICATE'.                                             
               30  FCCSPL-OBTAIN-CURR-TYPE  PIC X(16).                          
                   88  FCCSPL-TYPE-OBTAIN-CURR-ANY    VALUE ' '                 
                                                            'ANY'.              
                   88  FCCSPL-OBTAIN-CURR-RECORD      VALUE 'RECORD'.           
               30  FCCSPL-OBTAIN-DBKEY-TYPE PIC X(16).                          
                   88  FCCSPL-OBTAIN-DBKEY-ANY        VALUE ' '                 
                                                            'ANY'.              
                   88  FCCSPL-OBTAIN-DBKEY-RECORD     VALUE 'RECORD'.           
               30  FCCSPL-OBTAIN-FLNPN-TYPE PIC X(16).                          
                   88  FCCSPL-OBTAIN-FLNPN-ANY        VALUE ' '                 
                                                            'ANY'.              
                   88  FCCSPL-OBTAIN-FLNPN-RECORD     VALUE 'RECORD'.           
               30  FCCSPL-OBTAIN-FLNPN-FLAG PIC X(16).                          
                   88  FCCSPL-OBTAIN-FLNPN-AREA       VALUE 'AREA'.             
                   88  FCCSPL-OBTAIN-FLNPN-SET        VALUE 'SET'.              
               30  FCCSPL-READY-AREANAME    PIC X(16).                          
                   88  FCCSPL-READY-ALL               VALUE ' '.                
                   88  FCCSPL-READY-AREA              VALUE 'AREA'.             
               30  FCCSPL-READY-UPD-RET     PIC X(16).                          
                   88  FCCSPL-READY-RETRIEVAL         VALUE                     
                       'RETRIEVAL'.                                             
                   88  FCCSPL-READY-UPDATE            VALUE                     
                       'UPDATE'.                                                
               30  FCCSPL-READY-SHR-PRO-EXC PIC X(16).                          
                   88  FCCSPL-READY-SHARED            VALUE ' '.                
                   88  FCCSPL-READY-PROTECTED         VALUE                     
                       'PROTECTED'.                                             
                   88  FCCSPL-READY-EXCLUSIVE         VALUE                     
                       'EXCLUSIVE'.                                             
             25  FCCSPL-PGM-NAME              PIC X(8).                         
             25  FCCSPL-REC-NAME              PIC X(16).                        
             25  FCCSPLLK-SQLCODE             PIC S999.                         
             25  FCCSPL-PGM-IDMS-SQL-PRC-FLAG PIC X.                            
               88  FCCSPL-PGM-PRC-IDMS-SQL-UNKNOW     VALUE ' '.                
               88  FCCSPL-PGM-PRC-NOT-FOUND           VALUE 'X'.                
               88  FCCSPL-PGM-PRC-IDMS-YES            VALUE 'I' 'B'.            
               88  FCCSPL-PGM-PRC-SQL-YES             VALUE 'D' 'B'.            
               88  FCCSPL-PGM-PRC-IDMS-ONLY           VALUE 'I'.                
               88  FCCSPL-PGM-PRC-SQL-ONLY            VALUE 'D'.                
               88  FCCSPL-PGM-PRC-IDMS-AND-SQL        VALUE 'B'.                
             25  FCCSPL-ID                    PIC X(32).                        
             25  FCCSPL-EVALUATE-ERROR-FLAG   PIC X.                            
             25  FCCSPL-DEBUG-FLAG              PIC X     VALUE '0'.            
                 88  FCCSPL-DEBUG-OFF                     VALUE '0'.            
                 88  FCCSPL-BATCH-DEBUG-DISPLAY           VALUE '1'             
                                                                '5'.            
                 88  FCCSPL-BATCH-DEBUG-TRACE             VALUE '2'             
                                                                '5'.            
                 88  FCCSPL-BATCH-DEBUG-STATS             VALUE '3'             
                                                                '5'.            
                 88  FCCSPL-BATCH-DEBUG-ALL               VALUE '5'.            
                 88  FCCSPL-ONLINE-DEBUG-DISPLAY          VALUE '6'             
                                                                '9'.            
                 88  FCCSPL-ONLINE-DEBUG-TRACE            VALUE '7'             
                                                                '9'.            
                 88  FCCSPL-ONLINE-DEBUG-ALL              VALUE '9'.            
             25  FCCSPL-CURR-IO-NUM           PIC 9(4).                         
             25  FCCSPL-IOMOD-SQLCA.                                            
               30  FCCSPL-IOMOD-SQLCAID       PIC X(8).                         
               30  FCCSPL-IOMOD-SQLCABC       PIC S9(9) COMP-4.                 
               30  FCCSPL-IOMOD-SQLCODE       PIC S9(9) COMP-4.                 
               30  FCCSPL-IOMOD-SQLERRM.                                        
                   35  FCCSPL-IOMOD-SQLERRML  PIC S9(4) COMP-4.                 
                   35  FCCSPL-IOMOD-SQLERRMC  PIC X(70).                        
               30  FCCSPL-IOMOD-SQLERRP       PIC X(8).                         
               30  FCCSPL-IOMOD-SQLERRD       OCCURS 6 TIMES                    
                                              PIC S9(9) COMP-4.                 
               30  FCCSPL-IOMOD-SQLWARN.                                        
                   35  FCCSPL-IOMOD-SQLWARN0  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN1  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN2  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN3  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN4  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN5  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN6  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN7  PIC X.                            
               30  FCCSPL-IOMOD-SQLEXT.                                         
                   35  FCCSPL-IOMOD-SQLWARN8  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARN9  PIC X.                            
                   35  FCCSPL-IOMOD-SQLWARNA  PIC X.                            
                   35  FCCSPL-IOMOD-SQLSTATE  PIC X(5).                         
             25  FCCSPLLK-BEGIN-THREAD-FLAG PIC X.                              
                   88  FCCSPLLK-THREAD-NOT-ACTIVE       VALUE 'N'.              
                   88  FCCSPLLK-THREAD-ACTIVE           VALUE 'Y'.              
             25  FCCSPLLK-RECORD-NAME           PIC X(16).                      
             25  FCCSPL-CURR-REC-NAME           PIC X(16).                      
             25  FCCSPL-CURR-REC-KEY            PIC X(100).                     
             25  FCCSPL-DEBUG-INTERIM-COUNTER   PIC 9(7).                       
             25  FCCSPL-INSERT-UPDATE-FLAG      PIC X.                          
             25  FCCSPL-FIND-OBTAIN-TYPE        PIC X(16).                      
                   88  FCCSPL-TYPE-KEEP             VALUE 'KEEP'.               
                   88  FCCSPL-TYPE-EXCLUSIVE        VALUE 'EXCLUSIVE'.          
             25  FCCSPL-NOTIFY-VALUE            PIC S9(8) COMP.                 
             25  FCCSPL-KEEP-LONG-TYPE          PIC X(2).                       
             25  FCCSPL-KEEP-LONG-ID            PIC X(16).                      
             25  FCCSPL-LOCK-MODE               PIC X(16).                      
             25  FCCSPL-VARDATA                 PIC X(400).                     
      *                                                                         
      * THIS NEXT FILLER BRINGS THE LENGTH OF THIS COPYBOOK UP TO 2048          
      *                                                                         
             25  FILLER                         PIC X(063).                     
