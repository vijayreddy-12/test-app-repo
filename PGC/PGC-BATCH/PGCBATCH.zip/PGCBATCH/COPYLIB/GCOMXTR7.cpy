       01  GCOMXTRT.                                                            
      ******************************************************************        
      *          COMMISSION HISTORY EXTRACT RECORD                              
      ******************************************************************        
      *    NOV/90 M. PRANGE.                                                    
      *         - RENAMED GCXT-NEXT-ANNIVERSARY-DATE TO                         
      *                   GCXT-NEXT-RECON-DATE                                  
      *         - ADDED GCXT-RECON-DATE-IND (A = ANNIV, R = RENEWAL)            
      ******************************************************************        
           05  GCXT-AGENT-COMP-KEY.                                             
               10  GCXT-GROUP-ACCOUNT.                                          
REN                15  GCXT-GROUP-NUMBER              PIC X(7).                 
                   15  GCXT-GR-ACCOUNT                PIC X(3).                 
               10  GCXT-REC-TYPE                      PIC X.                    
               10  GCXT-GROUP-COMP-KEY.                                         
                   15  GCXT-COMP-EFF-DATE.                                      
                       20  GCXT-COMP-EFF-YEAR  COMP-3 PIC S9(3).                
                       20  GCXT-COMP-EFF-DAY   COMP-3 PIC S9(3).                
           05  GCXT-AGENT-NUMBER                      PIC X(6).                 
           05  GCXT-GFO-NUMBER                        PIC X(5).                 
           05  GCXT-COMP-TYPE                         PIC X.                    
           05  GCXT-COMP-DISP                         PIC X.                    
         03  GCXT-REMAINDER.                                                    
           05  GCXT-GROUP-REP                         PIC 9(5).                 
           05  GCXT-COMP-PROCESS-DATE.                                          
               10  GCXT-COMP-PROCESS-YEAR      COMP-3 PIC S9(3).                
               10  GCXT-COMP-PROCESS-DAY       COMP-3 PIC S9(3).                
           05  GCXT-COV-TYPE                          PIC X.                    
           05  GCXT-COMP-AMT                   COMP-3 PIC S9(9)V99.             
           05  GCXT-COMP-REASON                       PIC X.                    
           05  GCXT-RECON-IND                         PIC X.                    
           05  GCXT-AGENT-SPLIT                COMP-3 PIC S9(3)V99.             
           05  GCXT-PREM-AMT                   COMP-3 PIC S9(9)V99.             
           05  GCXT-NEXT-RECON-DATE.                                            
               10  GCXT-NEXT-RECON-YEAR        COMP-3 PIC S9(3).                
               10  GCXT-NEXT-RECON-DAY         COMP-3 PIC S9(3).                
           05  GCXT-ACCT-EFFECTIVE-DATE.                                        
               10  GCXT-ACCT-EFFECTIVE-YEAR    COMP-3 PIC S9(3).                
               10  GCXT-ACCT-EFFECTIVE-DAY     COMP-3 PIC S9(3).                
           05  GCXT-NEXT-RECON-IND                    PIC X(1).                 
GNE        05  FILLER                                 PIC X(13).                
