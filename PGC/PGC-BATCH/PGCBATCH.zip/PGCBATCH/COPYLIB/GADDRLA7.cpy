        01  LABEL-REC.                                                          
      *****************************************************************         
      *     GIPSY ADDRESS LABEL RECORD                                *         
      *                                                               *         
      *       CREATED BY INTM4                                        *         
      *       USED    BY GPRADLAB                                     *         
      *                                                               *         
      *       REC TYPE     '4'                                        *         
      *       REC LENGTH   61                                         *         
      *                                                               *         
      *****************************************************************         
            03  LAB-LEN   COMP SYNC                PIC S9(4).                   
            03  FILLER                             PIC XX.                      
            03  LAB-REC-TYPE VALUE '4'             PIC X.                       
            03  LAB-FORM                           PIC X.                       
            03  LAB-GRP-OFF                        PIC X(5).                    
GNE         03  LAB-GROUP     COMP-3               PIC S9(7).                   
            03  LAB-ACCT                           PIC XXX.                     
            03  LAB-ORD                            PIC X.                       
            03  LAB-PAY.                                                        
                05  LAB-PDATE                      PIC X(4).                    
                05  LAB-FILL1                      PIC X(3).                    
                05  LAB-PAMT  COMP-3               PIC S9(7)V99.                
GNE             05  LAB-FILL2                      PIC X(36).                   
            03  LAB-PROD-CODE                      PIC X.                       
