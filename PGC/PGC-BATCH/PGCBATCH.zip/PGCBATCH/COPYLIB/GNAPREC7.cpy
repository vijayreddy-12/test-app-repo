       01  GNAPREC.                                                             
      *************************************************************             
      *                                                           *             
      *          GIPSY NET ANNUALIZED PREMIUM RECORD              *             
      *                                                           *             
      *********************************************************** *             
      *          HISTORY....                                      *             
      *********************************************************** *             
      *                                                           *             
      *       CREATED BY  GFMEDPRM                                *             
      *       USED    BY  GPRNAPPR                                *             
      *                                                           *             
      *       REC TYPE     'F,P'                                  *             
      *       REC LENGTH   118                                    *             
      *                                                           *             
      * FEB11 - C MUNCAN    - UPDATED TO 7 DIGIT GROUP NUMBER AND *             
      *                       UPDATED RECORD LENGTH               *             
      *                                                           *             
      *************************************************************             
                                                                                
           05  GNAP-RECORD-LENGTH   COMP VALUE +118  PIC S9(4).                 
           05  GNAP-FILLER          VALUE LOW-VALUES PIC XX.                    
           05  GNAP-RECORD-TYPE     VALUE SPACES     PIC X.                     
           05  GNAP-KEY.                                                        
               10  GNAP-GFO-OFFICE                   PIC X(5).                  
               10  GNAP-GFO-REP                      PIC X(5).                  
REN            10  GNAP-GROUP                        PIC X(7).                  
               10  GNAP-ACCOUNT                      PIC X(3).                  
               10  GNAP-AGENT-CODE                   PIC X(6).                  
           05  GNAP-FOGL-CODE                        PIC X(10).                 
           05  GNAP-PREM-TYPE                        PIC X(2).                  
           05  GNAP-AMOUNT          COMP-3           PIC S9(7)V99.              
           05  GNAP-REP-NAME                         PIC X(20).                 
           05  GNAP-GROUP-NAME                       PIC X(30).                 
REN   *    05  FILLER               VALUE SPACES     PIC X(20).                 
REN        05  FILLER               VALUE SPACES     PIC X(18).                 
