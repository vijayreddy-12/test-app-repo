           03  GGO-ARREARS.                                                     
      *****************************************************************         
      *     GIPSY GFO ARREARS  RECORD                                 *         
      *                                                               *         
      *       CREATED BY INTM5                                        *         
      *       USED    BY GPRSOARR                                     *         
      *                                                               *         
      *       REC TYPE     'H'                                        *         
      *       REC LENGTH   78                                         *         
      *                                                               *         
      *****************************************************************         
      *                        HISTORY                                *         
      *****************************************************************         
      *                                                               *         
      * SEP/89 MARCUS DRURY -  GPSY-REL-1                             *         
      *                        ADD REPORT-TYPE                        *         
      *                                       1) HEAD OFFICE          *         
      *                                       2) PRODUCER             *         
      *                                       3) GROUP OFFICE (GFO)   *         
      *                        ADD PROD-CODE                          *         
      *                        ADD SRT-FIELDS                         *         
      *                        REC LENGTH  WAS 57.                    *         
      *                                                               *         
      * JAN/90 MARCUS DRURY -  CHANGE SORT OF H.O. REPORT TO INCLUDE  *         
      *                        PROD-CODE.                             *         
      *                        ALPHA'S        WILL BE AN  'A'         *         
      *                        OMEGA'S + CSP  WILL BE A   ' '         *         
      *                                                               *         
      *                                                               *         
      * JUN/98 JUDY ELKINS  -  CHANGE SORT OF PRODUCES'S REPORT       *         
      *                        FROM GFO, GROUP, ACCT, AGENT TO        *         
      *                        GFO, REP, GROUP, ACCT FOR THE          *         
      *                        ALPHA/RGO CHANGES                      *         
      *                     -  ADD ARR-AGENT TO RECORD                *         
      *****************************************************************         
               05  ARR-LENGTH                  PIC S9(4) COMP SYNC.             
               05  FILLER                      PIC XX.                          
               05  ARR-TYPE                    PIC X.                           
               05  ARR-REPORT                  PIC X.                           
               05  ARR-REPORT-NUMBER           PIC 9.                           
               05  ARR-SRT-FIELDS.                                              
                   10  ARR-SRT-HEAD-OFF.                                        
                       15  ARR-SRT-HO-PCODE    PIC X.                           
GNE                    15  ARR-SRT-HO-GROUP    PIC 9(7).                        
                       15  ARR-SRT-HO-ACCT     PIC XXX.                         
                       15  ARR-SRT-HO-FILLER1  PIC X(4).                        
                       15  ARR-SRT-HO-FILLER2  PIC X(6).                        
                   10  ARR-SRT-BRANCH    REDEFINES ARR-SRT-HEAD-OFF.            
                       15  ARR-SRT-BR-GFO-BR   PIC X(5).                        
                       15  ARR-SRT-BR-BKR-AGT  PIC 9(6).                        
                       15  ARR-SRT-BR-PCODE    PIC X.                           
GNE                    15  ARR-SRT-BR-GROUP    PIC 9(7)  COMP-3.                
                       15  ARR-SRT-BR-ACCT     PIC XXX.                         
GNE                    15  FILLER              PIC XX.                          
                   10  ARR-SRT-PRODUCER  REDEFINES ARR-SRT-BRANCH.              
                       15  ARR-SRT-PD-GFO      PIC X(5).                        
                       15  ARR-SRT-PD-REP      PIC 9(5).                        
GNE                    15  ARR-SRT-PD-GROUP    PIC 9(7).                        
                       15  ARR-SRT-PD-ACCT     PIC XXX.                         
                       15  FILLER              PIC X.                           
               05  ARR-GRPOFF                  PIC X(5).                        
GNE            05  ARR-GROUP                   PIC S9(7)      COMP-3.           
               05  ARR-ACCOUNT                 PIC X(3).                        
               05  ARR-BRANCH                  PIC X(5).                        
               05  ARR-OVERDATE                PIC X(4).                        
               05  ARR-OVERPREM                PIC S9(7)V99    COMP-3.          
               05  ARR-CURRPREM                PIC S9(7)V99    COMP-3.          
               05  ARR-TOTLPREM                PIC S9(7)V99    COMP-3.          
               05  ARR-SUSPDATE                PIC X(4).                        
               05  ARR-GRPIND                  PIC X.                           
               05  ARR-PCODE                   PIC X.                           
               05  ARR-AGENT                   PIC 9(6).                        
               05  FILLER       REDEFINES ARR-AGENT.                            
                   10  ARR-REP                 PIC 9(5).                        
                   10  FILLER                  PIC X.                           
GNE            05  FILLER                      PIC X(5).                        
