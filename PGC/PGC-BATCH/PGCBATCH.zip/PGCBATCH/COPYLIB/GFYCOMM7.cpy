      *****************************************************************         
      *     GIPSY FIRST YEAR COMMISIONS                               *         
      *                                                               *         
      *************************************************************** *         
      *          HISTORY....                                          *         
      *************************************************************** *         
      *                                                               *         
      *   ====> PART OF GIPSY-REL-1    REQ # 240 (ALPHA+)             *         
      *                                                               *         
      *    M DRURY   SEP/89                                           *         
      *                                                               *         
      *          ADD  6 POSITIONS    PCODE  --  1                     *         
      *                              OFFICE --  6                     *         
      *          FILLER WAS   38                                      *         
      *                                                               *         
      *       CREATED BY    GFMACOMM                                  *         
      *                     GFMCOMMS                                  *         
      *       USED    BY    GPRAGCOM                                  *         
      *                                                               *         
      *       REC TYPE     'Q'                                        *         
      *       REC LENGTH    GFMACOMM   79                             *         
      *                     GFMCOMMS   75                             *         
      *                                                               *         
      *****************************************************************         
       01  GFYCOMMS.                                                            
           03  GFY-RECLNGTH                        PIC S9(4)    COMP.           
           03  FILLER                              PIC XX.                      
           03  GFY-KEYFIELDS.                                                   
               05  GFY-CC-FLD.                                                  
                   07  GFY-SEG1.                                                
                       09  GFY-SEG2.                                            
                           11  GFY-SEG3.                                        
                               13  GFY-RECTYPE     PIC X.                       
                           11  GFY-BRANCH          PIC X(5).                    
                       09  GFY-AGENTCD             PIC X(6).                    
GNE            05  GFY-GROUP                       PIC S9(7)    COMP-3.         
               05  GFY-GRPACCT                     PIC X(3).                    
               05  GFY-PAYDATE.                                                 
                   10  GFY-PAYYEAR                 PIC S9(3)    COMP-3.         
                   10  GFY-PAYDAY                  PIC S9(3)    COMP-3.         
           03  GFY-PREMAMNT                        PIC S9(7)V99 COMP-3.         
           03  GFY-COMMAMNT                        PIC S9(7)V99 COMP-3.         
           03  GFY-FST-YR-TYPE                     PIC X.                       
           03  GFY-PROD-CODE                       PIC X.                       
           03  GFY-OFFICE                          PIC X(5).                    
GNE        03  FILLER                              PIC X(31).                   
