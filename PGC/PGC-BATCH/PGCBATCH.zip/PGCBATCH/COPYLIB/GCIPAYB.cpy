      *---------------------------------------------------------------*         
      *                                                               *         
      *  RECORD GWCORPAYBASIS                        10/26/10  17:06  *         
      *                                                               *         
      *---------------------------------------------------------------*         
       01  GWCORPAYBASIS.                                                       
           05  PAY-BASIS-EFF-DATE.                                              
               10  PAY-BASIS-EFF-YEAR         COMP-3    PIC S9(3).              
               10  PAY-BASIS-EFF-DAY          COMP-3    PIC S9(3).              
           05  PAY-BASIS-IND                            PIC X.                  
           05  PAY-BASIS-PROC-DATE.                                             
               10  PAY-BASIS-PROC-YEAR        COMP-3    PIC S9(3).              
               10  PAY-BASIS-PROC-DAY         COMP-3    PIC S9(3).              
           05  PAY-BASIS-END-DATE.                                              
               10  PAY-BASIS-END-YEAR         COMP-3    PIC S9(3).              
               10  PAY-BASIS-END-DAY          COMP-3    PIC S9(3).              
