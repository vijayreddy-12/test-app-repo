      ******************************************************************        
      *    ACCOUNTING SYSTEM INTERFACE RECORD.                                  
      *    KEEP THIS RECORD SIZE THE SAME AS IN 'JEXTDATE'                      
      *                                                                         
      *    MAX RECORD LENGTH OF THE FILE = VB-23472 (INCLUDES RCW)              
      *                                                                         
SUSP03*    THIS RECORD LAYOUT HAS LENGTH = 584 = (4 + 580).                     
      ******************************************************************        
      *    FEB/1993 PRANGE                                                      
      *           - ADDED FIELDS: JEXTRACT-PREV-MICR-INFORMATION                
      *                           JEXTRACT-AGENT                                
      *                           JEXTRACT-DUE-DATE                             
      *                                                                         
      *    APR/1994 CURRIKA                                                     
      *           - ADDED FIELDS: JEXTRACT-FIRST-TIME-FLAG                      
      *                           JEXTRACT-REASON-CODE                          
      *                                                                         
      *    MAY/1995 M. KELLY                                                    
      *           - ADDED NEW FEED FROM DALI                                    
      *           - ADDED FIELDS: JEXTRACT-GROUP-OFFICE                         
      *                           JEXTRACT-PRODUCT-CATEGORY                     
      *                           JEXTRACT-CLASS-CODE                           
      *                           JEXTRACT-TAX-RATE                             
      *                           JEXTRACT-PROV-ACCOUNT                         
      *                                                                         
      *    JUL/1995 M. PRANGE                                                   
      *           - ADDED LOOKUP VALUE OF 'L' FOR FIELDS                        
      *             JEXTRACT-STAFF-PLAN AND JEXTRACT-MAP-FOGL-CODE              
      *             TO ACCOMODATE CLIENTS II ACCOUNTING INTERFACE.              
      *                                                                         
      *    AUG/1995 M. PRANGE                                                   
      *           - ADDED JEXTRACT-ORIGINATING-SYSTEM TO ACCOMODATE             
      *             CLIENTS II AND DMS INTERFACES.                              
      *                                                                         
      *             NOTE: IF LEFT BLANK IT WILL BE DEFAULTED BY                 
      *                   DISBURSEMENTS TO THE FEEDER SYSTEM.                   
      *                                                                         
      *    MAY/1996 K. CURRIE                                                   
      *           - ADDED JEXTRACT-SUBMISSION-TYPE TO DISTINGUISH               
      *             MEMBER SUBMITTED CLAIMS FROM PHARMACY SUBMITTED             
      *             CLAIMS FOR 'ECLIPSE' GROUPS.                                
      *                                                                         
      *             NOTE: THIS FIELD WILL ONLY BE POPULATED IF                  
      *                   JEXTRACT-TPA-ID = 'E'.                                
      *    SEP/1996 K. SANDANAYAKE                                              
      *           - ADDED JEXTRACT-CLAIM-PROCESS-DATE AND                       
      *             JEXTRACT-PHARMACY-NO FOR ESI REMITTANCE FEED                
      *             CLAIMS AND ADJUSTMENTS                                      
      *                                                                         
      *             NOTE: THESE FIELDS WILL ONLY BE POPULATED FOR               
      *                   REMITTANCE FEED ACCOUNTING ONLY                       
      *                                                                         
      *    960124   R.LEE-KIM                                                   
      *           - ADDED JEXTRACT-DRUG-PAY-TYPE TO DISTINGUISH                 
      *             REIMBURSE FROM DIRECT DRUG PLAN. THIS IS FOR                
      *             FUTURE USE.                                                 
      *                                                                         
      *    970430   C.BERCH                                                     
      *           - ADDED 88 LEVEL 'S' UNDER TPA-ID FIELD FOR NCI               
      *             SUSPENSE ACCOUNTS                                           
      *                                                                         
SUSP01*    060406 - F. DAZA                                                     
SUSP01*             INTRODUCED CHEQUE-NUMBER, BENEFIT-TYPE                      
SUSP01*             AND ADJUDICATOR-ID                                          
SUSP01*             SUSPENSE IMPROVEMENT PROYECT                                
      *                                                                         
SUSP03*    060506 - F. DAZA                                                     
SUSP03*             INTRODUCED CLEARING TAG FIELDS FOR THE                      
SUSP03*             SUSPENSE IMPROVEMENT PROYECT                                
      *                                                                         
      *                                                                         
SUSP10*    050606 - F. DAZA                                                     
SUSP10*             INTRODUCED FIELDS FOR THE WORLD ACCESS CLAIMS               
SUSP10*             SUSPENSE IMPROVEMENT PROYECT                                
      *                                                                         
      *    SEP 2018  RANDY LEE KIM                                              
      *         - ADC EXTERNAL REMITTANCE: NEW JEXTRACT-CLAIM-ID                
      *           FIELD WITHIN JEXTRACT-CHEQUE-REMARKS                          
      ******************************************************************        
           05  JEXTRACT-RECTYPE                        PIC X(1).                
               88  JEXTRACT-RECTYPE-DATE                   VALUE 'D'.           
               88  JEXTRACT-RECTYPE-RECORD                 VALUE 'R'.           
      *                                                                         
           05  JEXTRACT-FEEDER-SYSTEM                  PIC X(1).                
               88  JEXTRACT-FEEDER-CLAIMS                  VALUE 'A'.           
               88  JEXTRACT-FEEDER-BILL                    VALUE 'B'.           
               88  JEXTRACT-FEEDER-COMMISSIONS             VALUE 'C'.           
               88  JEXTRACT-FEEDER-GIPSY                   VALUE 'G'.           
               88  JEXTRACT-FEEDER-DALI                    VALUE 'D'.           
           05  JEXTRACT-REQUIREMENTS.                                           
               10  JEXTRACT-REQ-ACCRUAL-FLAG           PIC X(1).                
                   88  JEXTRACT-REQ-ACCRUAL-NA             VALUE 'N'.           
                   88  JEXTRACT-REQ-ACCRUAL                VALUE 'A'.           
                   88  JEXTRACT-REQ-ACCRUAL-REVERSAL       VALUE 'R'.           
               10  JEXTRACT-REQ-CASH-FLAG              PIC X(1).                
                   88  JEXTRACT-REQ-CASH-NA                VALUE 'N'.           
                   88  JEXTRACT-REQ-CHECK-SUSPENSE         VALUE 'S'.           
                   88  JEXTRACT-REQ-CASH-ONLY              VALUE 'C'.           
               10  JEXTRACT-REQ-CASHMAN-FLAG           PIC X(1).                
                   88  JEXTRACT-REQ-CASHMAN-YES            VALUE 'Y'.           
                   88  JEXTRACT-REQ-CASHMAN-NO             VALUE 'N'.           
           05  JEXTRACT-EFF-DATE.                                               
               10  JEXTRACT-EFF-YYYY                   PIC 9(4).                
               10  JEXTRACT-EFF-MM                     PIC 9(2).                
               10  JEXTRACT-EFF-DD                     PIC 9(2).                
           05  JEXTRACT-STAFF-PLAN                     PIC X(1).                
               88  JEXTRACT-STAFF-PLAN-YES                 VALUE 'Y'.           
               88  JEXTRACT-STAFF-PLAN-NO                  VALUE 'N'.           
               88  JEXTRACT-STAFF-PLAN-LOOKUP              VALUE 'L'.           
           05  JEXTRACT-ASO-PLAN                       PIC X(1).                
           05  JEXTRACT-PAYCENTRE-X.                                            
               10  JEXTRACT-PAYCENTRE                  PIC 9(5).                
           05  JEXTRACT-GROUP-X.                                                
               10  JEXTRACT-GROUP                      PIC 9(7).                
           05  JEXTRACT-GROUP-ACCT                     PIC X(3).                
           05  JEXTRACT-CERTIFICATE-X.                                          
               10  JEXTRACT-CERTIFICATE                PIC 9(9).                
           05  JEXTRACT-BENEFIT-X.                                              
               10  JEXTRACT-BENEFIT                    PIC 9(3).                
           05  JEXTRACT-REISSUE-FLAG                   PIC X(1).                
               88  JEXTRACT-REISSUE-NO                     VALUE 'N'.           
               88  JEXTRACT-REISSUE-YES                    VALUE 'Y'.           
           05  JEXTRACT-TPA-ID                         PIC X(1).                
               88  JEXTRACT-TPA-NA                         VALUE 'N'.           
               88  JEXTRACT-TPA-ECLIPSE                    VALUE 'E'.           
               88  JEXTRACT-TPA-RXPLUS                     VALUE 'R'.           
               88  JEXTRACT-TPA-NCI-SUSPENSE               VALUE 'S'.           
SUSP10         88  JEXTRACT-TPA-WORLD-ACCESS               VALUE 'W'.           
           05  JEXTRACT-CURRENCY                       PIC X(1).                
           05  JEXTRACT-LANGUAGE                       PIC X(1).                
           05  JEXTRACT-RESIDENCE-X.                                            
               10  JEXTRACT-RESIDENCE                  PIC 9(2).                
           05  JEXTRACT-MAP-FOGL-CODE                  PIC X(1).                
               88  JEXTRACT-MAP-FOGL-CODE-NO               VALUE 'N'.           
               88  JEXTRACT-MAP-FOGL-CODE-YES              VALUE 'Y'.           
               88  JEXTRACT-MAP-FOGL-CODE-LOOKUP           VALUE 'L'.           
           05  JEXTRACT-FOGL-CODE                      PIC X(10).               
           05  JEXTRACT-PAYMENT-TYPE                   PIC X(2).                
           05  JEXTRACT-MICR-INFORMATION.                                       
               10  JEXTRACT-MICR-SYSTEM                PIC X(1).                
               10  JEXTRACT-MICR-NO-X.                                          
                   15  JEXTRACT-MICR-NO                PIC 9(9).                
           05  JEXTRACT-BANK-INFORMATION               PIC X(25).               
           05  JEXTRACT-MNEMONIC                       PIC X(8).                
           05  JEXTRACT-AMT                            PIC S9(9)V9(2)           
                                               SIGN TRAILING SEPARATE.          
           05  JEXTRACT-ACCT-OVERRIDES                 PIC X(1).                
           05  JEXTRACT-DEBIT-ACCT-NO                  PIC X(6).                
           05  JEXTRACT-CREDIT-ACCT-NO                 PIC X(6).                
           05  JEXTRACT-PAYEE-NAME                     PIC X(32).               
           05  JEXTRACT-ADDRESS-TABLE.                                          
               10  JEXTRACT-ADDRESS-ENTRY OCCURS 7 TIMES.                       
                   15  JEXTRACT-ADDRESS-LINE           PIC X(40).               
           05  JEXTRACT-CHEQUE-REMARKS-ALL.                                     
               10  JEXTRACT-CHEQUE-REMARKS             PIC X(18).               
               10  JEXTRACT-CLAIM-ID                   PIC X(16).               
           05  JEXTRACT-ERROR-COUNT                    PIC 9(3).                
      *                                                                         
           05  JEXTRACT-PREV-MICR-INFORMATION.                                  
               10  JEXTRACT-PREV-MICR-SYSTEM           PIC X(1).                
               10  JEXTRACT-PREV-MICR-NO-X.                                     
                   15  JEXTRACT-PREV-MICR-NO           PIC 9(9).                
           05  JEXTRACT-AGENT-X.                                                
               10  JEXTRACT-AGENT                      PIC 9(7).                
           05  JEXTRACT-DUE-DATE.                                               
               10  JEXTRACT-DUE-YYYY                   PIC 9(4).                
               10  JEXTRACT-DUE-MM                     PIC 9(2).                
               10  JEXTRACT-DUE-DD                     PIC 9(2).                
           05  JEXTRACT-FIRST-TIME-FLAG                PIC X.                   
           05  JEXTRACT-REASON-CODE                    PIC X(4).                
           05  JEXTRACT-GROUP-OFFICE                   PIC X(4).                
           05  JEXTRACT-PRODUCT-CATEGORY               PIC X.                   
           05  JEXTRACT-CLASS-CODE                     PIC X.                   
           05  JEXTRACT-TAX-RATE                       PIC X.                   
           05  JEXTRACT-PROV-ACCOUNT                   PIC X(5).                
           05  JEXTRACT-ORIGINATING-SYSTEM             PIC X(1).                
               88  JEXTRACT-ORIG-SYS-ACES                  VALUE 'A'.           
               88  JEXTRACT-ORIG-SYS-BILL                  VALUE 'B'.           
               88  JEXTRACT-ORIG-SYS-COMMISSIONS           VALUE 'C'.           
               88  JEXTRACT-ORIG-SYS-GIPSY                 VALUE 'G'.           
               88  JEXTRACT-ORIG-SYS-DALI                  VALUE 'D'.           
               88  JEXTRACT-ORIG-SYS-CLIENTS2              VALUE '2'.           
               88  JEXTRACT-ORIG-SYS-LCS                   VALUE 'L'.           
           05  JEXTRACT-SUBMISSION-TYPE                PIC X(1).                
               88  JEXTRACT-MEMBER-SUBMITTED               VALUE 'M'.           
               88  JEXTRACT-PHARMACY-SUBMITTED             VALUE 'P'.           
           05  JEXTRACT-CLAIM-PROCESS-DATE             PIC X(8).                
           05  JEXTRACT-PHARMACY-NO                    PIC X(10).               
           05  JEXTRACT-DRUG-PAY-TYPE                  PIC X(1).                
           05  JEXTRACT-CHEQUE-NUMBER                  PIC X(8).                
SUSP01     05  JEXTRACT-BENEFIT-TYPE                   PIC X(2).                
SUSP01     05  JEXTRACT-ADJUDICATOR-ID                 PIC X(3).                
SUSP03     05  JEXTRACT-CLEARING-TAG                   PIC 9(07).               
SUSP03     05  JEXTRACT-CLEARING-TAG-X REDEFINES JEXTRACT-CLEARING-TAG.         
SUSP03         10 JEXTRACT-CLTAG-ISP-CARRIER           PIC 9(02).               
SUSP03         10 JEXTRACT-CLTAG-FILE-SEQ              PIC 9(03).               
SUSP03         10 JEXTRACT-CLTAG-FILE-YY               PIC 9(02).               
SUSP10     05  JEXTRACT-MEMBER-ID                      PIC X(02).               
SUSP10     05  JEXTRACT-SERVICE-CODE                   PIC X(02).               
SUSP10     05  JEXTRACT-SERVICE-DATE                   PIC 9(07).               
SUSP10     05  JEXTRACT-SERVICE-TO-DATE                PIC 9(07).               
SUSP10     05  FILLER                                  PIC X(01).               
