           03  LAPSE-NOTICE-RECORD.                                             
      *****************************************************************         
      *     GIPSY LAPS-NOTICE  RECORD                                 *         
      *                                                               *         
      *       CREATED BY INTM5                                        *         
      *       USED    BY  GPRLAPNT                                    *         
      *                                                               *         
      *       REC TYPE     '6'                                        *         
      *       REC LENGTH   63                                         *         
      *                                                               *         
      *****************************************************************         
      *                      HISTORY                                  *         
      *****************************************************************         
      *                                                               *         
      *   JAN/90  M. DRURY   - ADD EXTRA FIELD FOR PROD-CD SORT       *         
      *                        ALPHA'S       WILL BE AN  'A'          *         
      *                        OMEGA'S + CSP WILL BE A   ' '.         *         
      *                        REMOVE GRPOFF FORM SORT KEY            *         
      *                                                               *         
              05  LST-LENGTH                PIC  S9(4) COMP SYNC.               
              05  FILLER                    PIC  XX.                            
              05  LST-CURR-KEY.                                                 
                  07  LSTREC-TYPE           PIC  X(01).                         
                  07  LST-RCOMP.                                                
                     09  LSTFORM            PIC  X(01).                         
                     09  LSTPCODE           PIC  X.                             
                     09  LSTCOMP.                                               
GNE                      11  LSTGROUP COMP-3 PIC S9(07).                        
                         11  LSTACCT        PIC  X(03).                         
              05  LSTGRPOFF                 PIC  X(05).                         
              05  LSTOVDUE-DATE             PIC  X(04).                         
              05  LSTCUR-DATE               PIC  X(04).                         
              05  LSTOVDUE-PREM     COMP-3  PIC S9(07)V99.                      
              05  LSTCUR-PREM       COMP-3  PIC S9(07)V99.                      
              05  LSTTOT-PREM       COMP-3  PIC S9(07)V99.                      
GNE           05  FILLER                    PIC  X(11).                         
