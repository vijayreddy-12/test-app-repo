--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TGFO TABLE  (                                       
                GFO_NUMBER                     CHAR(5) NOT NULL)                
           END-EXEC.                                                            
       01  GC-TGFO.                                                             
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  GFO-NUMBER                      PIC X(5).                        
