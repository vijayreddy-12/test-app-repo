--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TTRAN TABLE  (                                      
                TRANS_TYPE             CHAR(2) NOT NULL WITH DEFAULT,           
                TRANS_DETAILS          VARCHAR(348)                             
                                       NOT NULL WITH DEFAULT,                   
                DIRECT_DBKEY           TIMESTAMP NOT NULL)                      
           END-EXEC.                                                            
       01  GC-TTRAN.                                                            
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  TRANS-TYPE                      PIC X(2).                        
           05  TRANS-DETAILS.                                                   
               49  TRANS-DETAILS-LEN           PIC S9(4) COMP.                  
               49  TRANS-DETAILS-TEXT          PIC X(348).                      
           05  DIRECT-DBKEY                    PIC X(26).                       
