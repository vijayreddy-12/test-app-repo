--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TGROUP TABLE  (                                     
                GROUP_NUMBER                   CHAR(7) NOT NULL)                
           END-EXEC.                                                            
       01  GC-TGROUP.                                                           
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  GROUP-NUMBER                    PIC X(7).                        
           05  GROUP-NUMBER-9 REDEFINES                                         
               GROUP-NUMBER                    PIC 9(7).                        
