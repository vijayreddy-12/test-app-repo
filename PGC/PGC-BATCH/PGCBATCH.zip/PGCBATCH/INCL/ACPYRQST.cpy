      ******************************************************************        
      * DCLGEN TABLE(DBCYTD1.APPLICATION_COPY_REQUEST)                 *        
      *        LIBRARY(BRANDHA.PERS.COPYLIB(ACPYRQST))                 *        
      *        ACTION(REPLACE)                                         *        
      *        LANGUAGE(COBOL)                                         *        
      *        APOST                                                   *        
      *        INDVAR(YES)                                             *        
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *        
      ******************************************************************        
           EXEC SQL DECLARE APPLICATION_COPY_REQUEST TABLE                      
           ( REQUEST_ID                     INTEGER NOT NULL,                   
             REQUEST_COMMENT                CHAR(80) NOT NULL,                  
             REQUEST_USERID                 CHAR(8) NOT NULL,                   
             REQUEST_TS                     TIMESTAMP NOT NULL                  
           ) END-EXEC.                                                          
      ******************************************************************        
      * COBOL DECLARATION FOR TABLE DBCYTD1.APPLICATION_COPY_REQUEST   *        
      ******************************************************************        
       01  DCLAPPLICATION-COPY-REQUEST.                                         
           10 REQUEST-ID           PIC S9(9) USAGE COMP.                        
           10 REQUEST-COMMENT      PIC X(80).                                   
           10 REQUEST-USERID       PIC X(8).                                    
           10 REQUEST-TS           PIC X(26).                                   
      ******************************************************************        
      * INDICATOR VARIABLE STRUCTURE                                   *        
      ******************************************************************        
       01  IAPPLICATION-COPY-REQUEST.                                           
           10 INDSTRUC           PIC S9(4) USAGE COMP OCCURS 4 TIMES.           
      ******************************************************************        
      * THE NUMBER OF COLUMNS DESCRIBED BY THIS DECLARATION IS 4       *        
      ******************************************************************        
