--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TRNEWL TABLE  (                                     
                COV_TYPE               CHAR(1) NOT NULL WITH DEFAULT,           
                RENEWAL_AMOUNT         DEC(11,2) NOT NULL WITH DEFAULT,         
                GROUP_NUMBER           CHAR(7) NOT NULL,                        
                GR_ACCOUNT             CHAR(3) NOT NULL,                        
                GRACT_RNEWL_TS         TIMESTAMP NOT NULL)                      
           END-EXEC.                                                            
       01  GC-TRNEWL.                                                           
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  COV-TYPE                        PIC X.                           
           05  RENEWAL-AMOUNT                  PIC S9(9)V99      COMP-3.        
           05  GROUP-ACCOUNT.                                                   
               10  GROUP-NUMBER                PIC X(7).                        
               10  GROUP-NUMBER-9 REDEFINES                                     
                   GROUP-NUMBER                PIC 9(7).                        
               10  GR-ACCOUNT                  PIC X(3).                        
           05  GRACT-RNEWL-TS                  PIC X(26).                       
