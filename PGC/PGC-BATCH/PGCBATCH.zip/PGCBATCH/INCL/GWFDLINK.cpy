      *================================================================*        
      *  DBLINKTM - OBTAIN TIME FROM SQL                               *        
      *================================================================*        
                                                                                
           EXEC SQL                                                             
               SET :DBLINK-TIMESTAMP = CURRENT TIMESTAMP                        
           END-EXEC.                                                            
                                                                                
      *===================== END DBLINKTM COPY ========================*        
                                                                                
