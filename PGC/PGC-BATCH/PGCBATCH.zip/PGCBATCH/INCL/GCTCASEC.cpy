--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TCASEC TABLE  (                                     
                AGT_CASE_CNT_YEAR              DEC(3) NOT NULL,                 
                AGT_CASE_CNT_DAY               DEC(3) NOT NULL,                 
                AGT_CASE_CNT_DT         DATE                                    
                    NOT NULL WITH DEFAULT,                                      
                AGT_CASE_CNT_AMT               DEC(3,2)                         
                    NOT NULL WITH DEFAULT,                                      
                AGENT_SPLIT                    DEC(5,2)                         
                    NOT NULL WITH DEFAULT,                                      
                FC_IDENT                       INT                              
                    NOT NULL WITH DEFAULT                                       
                                               ,                                
                GROUP_NUMBER                   CHAR(7) NOT NULL,                
                GR_ACCOUNT                     CHAR(3) NOT NULL,                
                GRACT_CASEC_TS                 TIMESTAMP NOT NULL,              
                AGENT_NUMBER                   CHAR(6)                          
                    NOT NULL WITH DEFAULT,                                      
                AGENT_CASEC_TS                 TIMESTAMP                        
                    NOT NULL WITH DEFAULT)                                      
           END-EXEC.                                                            
       01  GC-TCASEC.                                                           
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  AGT-CASE-CNT-DATE.                                               
               10  AGT-CASE-CNT-YEAR           PIC S9(3)         COMP-3.        
               10  AGT-CASE-CNT-DAY            PIC S9(3)         COMP-3.        
           05  AGT-CASE-CNT-DT                 PIC X(10).                       
           05  AGT-CASE-CNT-AMT                PIC S9V99         COMP-3.        
           05  AGENT-SPLIT                     PIC S9(3)V99      COMP-3.        
           05  FC-IDENT                        PIC S9(9)         COMP.          
           05  GROUP-ACCOUNT.                                                   
               10  GROUP-NUMBER                PIC X(7).                        
               10  GROUP-NUMBER-9 REDEFINES                                     
                   GROUP-NUMBER                PIC 9(7).                        
               10  GR-ACCOUNT                  PIC X(3).                        
           05  GRACT-CASEC-TS                  PIC X(26).                       
           05  AGENT-NUMBER                    PIC X(6).                        
           05  AGENT-CASEC-TS                  PIC X(26).                       
