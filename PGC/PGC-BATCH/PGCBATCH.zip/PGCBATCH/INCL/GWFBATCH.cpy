      *================================================================*        
      *  ECBATCH - BATCH ERROR ROUTINE                                 *        
      *================================================================*        
                                                                                
       BATCH-ERROR-RTN.                                                         
                                                                                
           DISPLAY ' '.                                                         
                                                                                
           DISPLAY '******************************************'.                
           DISPLAY '                                          '.                
           DISPLAY '       PROGRAM HAS ABENDED                '.                
           DISPLAY '                                          '.                
           DISPLAY '******************************************'.                
           DISPLAY ' '.                                                         
           DISPLAY ' '.                                                         
           DISPLAY '******************************************'.                
                                                                                
           IF SQLCODE = ZERO                                                    
               DISPLAY '*** SQLCODE               = +0'                         
               MOVE ERROR-STATUS TO FCCSPL-SQLCODE                              
                                    DBLINK-RETURN-CODE                          
           ELSE                                                                 
               MOVE SQLCODE TO FCCSPL-SQLCODE                                   
                               DBLINK-RETURN-CODE                               
               DISPLAY '*** SQLCODE               = ' FCCSPL-SQLCODE            
           END-IF                                                               
                                                                                
           DISPLAY '*** ERROR-STATUS          = ' ERROR-STATUS                  
           DISPLAY '*** FCCSPL-PROGRAM-NAME   = ' FCCSPL-PROGRAM-NAME           
           DISPLAY '*** FCCSPL-DML-SEQ-NO     = ' FCCSPL-DML-SEQ-NO             
           DISPLAY '*** FCCSPL-METHOD-NAME    = ' FCCSPL-METHOD-NAME            
           DISPLAY '*** FCCSPL-RECORD-NAME    = ' FCCSPL-RECORD-NAME            
           DISPLAY '*** FCCSPL-SET-NAME       = ' FCCSPL-SET-NAME               
           DISPLAY '*** FCCSPL-AREA-NAME      = ' FCCSPL-AREA-NAME              
           DISPLAY '*** FCCSPL-IO-MODULE-NAME = ' FCCSPL-IO-MODULE-NAME         
           DISPLAY '*** DBLINK-CURR-PARAGRAPH = ' DBLINK-CURR-PARAGRAPH         
           DISPLAY '*** DBLINK-CURR-IO-NUM    = ' DBLINK-CURR-IO-NUM            
           DISPLAY '******************************************'.                
                                                                                
           CALL 'DSNTIAR' USING                                                 
                       FCCSPL-IOMOD-SQLCA                                       
                       DBLINK-SQL-ERROR-MESSAGE                                 
                       DBLINK-SQL-ERROR-TEXT-LEN                                
           IF RETURN-CODE = ZERO                                                
               DISPLAY DBLINK-SQL-ERROR-TEXT(1)                                 
               DISPLAY DBLINK-SQL-ERROR-TEXT(2)                                 
               DISPLAY DBLINK-SQL-ERROR-TEXT(3)                                 
               DISPLAY DBLINK-SQL-ERROR-TEXT(4)                                 
               DISPLAY DBLINK-SQL-ERROR-TEXT(5)                                 
               DISPLAY DBLINK-SQL-ERROR-TEXT(6)                                 
               DISPLAY DBLINK-SQL-ERROR-TEXT(7)                                 
               DISPLAY DBLINK-SQL-ERROR-TEXT(8)                                 
           ELSE                                                                 
               MOVE     RETURN-CODE  TO  FCCSPL-SQLCODE                         
               DISPLAY '++++++++++++++++++++++++++++++++++++++++'               
               DISPLAY '*** CALL TO DSNTIAR WAS UNSUCCESSFUL ***'               
               DISPLAY '*** RETURN CODE  = ' FCCSPL-SQLCODE                     
               DISPLAY '++++++++++++++++++++++++++++++++++++++++'.              
                                                                                
           DISPLAY 'SQLERRD3    = '  SQLERRD(03).                               
           DISPLAY 'SQLERRD5    = '  SQLERRD(05).                               
           DISPLAY 'SQLWARN0    = '  SQLWARN0.                                  
           DISPLAY 'SQLWARN1    = '  SQLWARN1.                                  
           DISPLAY 'SQLWARN2    = '  SQLWARN2.                                  
           DISPLAY 'SQLWARN3    = '  SQLWARN3.                                  
           DISPLAY 'SQLWARN4    = '  SQLWARN4.                                  
           DISPLAY 'SQLWARN6    = '  SQLWARN6.                                  
           DISPLAY ' '.                                                         
           DISPLAY '+++++++++++++++++++++++++++++++++++++++++++'.               
           DISPLAY 'DOING ROLLBACK                             '.               
           DISPLAY '+++++++++++++++++++++++++++++++++++++++++++'.               
                                                                                
           EXEC SQL                                                             
               ROLLBACK                                                         
           END-EXEC.                                                            
                                                                                
           IF  SQLCODE  =  +0                                                   
               DISPLAY '+++++++++++++++++++++++++++++++++++++++++++'            
               DISPLAY 'ROLLBACK SUCCESSFUL                        '            
               DISPLAY '+++++++++++++++++++++++++++++++++++++++++++'            
           ELSE                                                                 
               MOVE  SQLCODE  TO  FCCSPL-SQLCODE                                
               DISPLAY '+++++++++++++++++++++++++++++++++++++++++++'            
               DISPLAY 'ROLLBACK UNSUCCESSFUL                      '            
               DISPLAY '*** RETURN CODE  = ' FCCSPL-SQLCODE                     
               DISPLAY '+++++++++++++++++++++++++++++++++++++++++++'.           
                                                                                
      *****************************                                             
      *    FORCE ABEND                                                          
      *****************************                                             
           MOVE DBLINK-RETURN-CODE TO RETURN-CODE.                              
           MOVE 'CEE3ABD' TO DBLINK-ABEND-ROUTINE                               
           MOVE +1        TO DBLINK-CLEANUP-CODE                                
           CALL DBLINK-ABEND-ROUTINE                                            
                USING DBLINK-RETURN-CODE                                        
                      DBLINK-CLEANUP-CODE.                                      
                                                                                
       BATCH-ERROR-RTN-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *===================== END ECBATCH COPY =========================*        
                                                                                
