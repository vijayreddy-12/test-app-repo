--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TAGENT TABLE  (                                     
                AGENT_NUMBER                   CHAR(6) NOT NULL)                
           END-EXEC.                                                            
       01  GC-TAGENT.                                                           
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  AGENT-NUMBER                    PIC X(6).                        
