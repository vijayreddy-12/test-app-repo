      *================================================================*        
      *  CBCVDBLT - KEEP LONGTERM TABLE                                *        
      *================================================================*        
FXXTOK     EXEC SQL DECLARE TFCKEP TABLE                                        
           ( FC_EIBTRMID            CHAR(4)       NOT NULL,                     
             FC_KEEP_LONG_ID        CHAR(16)      NOT NULL,                     
             FC_KEEP_LONG_TYPE      CHAR(8)       NOT NULL,                     
             FC_KEEP_LONG_REC       CHAR(16)      NOT NULL,                     
             FC_KEEP_LONG_DATA      VARCHAR(3900) NOT NULL )                    
           END-EXEC.                                                            
       01  FC-KEEP-LONGTERM.                                                    
           10  FC-EIBTRMID                 PIC  X(4).                           
           10  FC-KEEP-LONG-ID             PIC  X(16).                          
           10  FC-KEEP-LONG-TYPE           PIC  X(8).                           
           10  FC-KEEP-LONG-REC            PIC  X(16).                          
           10  FC-KEEP-LONG-DATA.                                               
               49  FC-KEEP-LONG-DATA-LEN   PIC  S9(4)   COMP.                   
               49  FC-KEEP-LONG-DATA-TEXT  PIC  X(3900).                        
      *===================== END CBCVDBLT COPY ========================*        
                                                                                
