--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TPAYB TABLE  (                                      
                PAY_BASIS_EFF_YEAR             DEC(3) NOT NULL,                 
                PAY_BASIS_EFF_DAY              DEC(3) NOT NULL,                 
                PAY_BASIS_EFF_DT        DATE                                    
                                  NOT NULL WITH DEFAULT,                        
                PAY_BASIS_IND                  CHAR(1)                          
                                  NOT NULL WITH DEFAULT,                        
                PAY_BASIS_PROC_YEAR            DEC(3)                           
                                  NOT NULL WITH DEFAULT,                        
                PAY_BASIS_PROC_DAY             DEC(3)                           
                                  NOT NULL WITH DEFAULT,                        
                PAY_BASIS_PROC_DT                                               
                             DATE NOT NULL WITH DEFAULT,                        
                PAY_BASIS_END_YEAR             DEC(3) NOT NULL,                 
                PAY_BASIS_END_DAY              DEC(3) NOT NULL,                 
                PAY_BASIS_END_DT                                                
                              DATE NOT NULL WITH DEFAULT,                       
                AGENT_NUMBER                   CHAR(6) NOT NULL)                
           END-EXEC.                                                            
       01  GC-TPAYB.                                                            
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  PAY-BASIS-EFF-DATE.                                              
               10  PAY-BASIS-EFF-YEAR          PIC S9(3)         COMP-3.        
               10  PAY-BASIS-EFF-DAY           PIC S9(3)         COMP-3.        
           05  PAY-BASIS-EFF-DT                PIC X(10).                       
           05  PAY-BASIS-IND                   PIC X.                           
           05  PAY-BASIS-PROC-DATE.                                             
               10  PAY-BASIS-PROC-YEAR         PIC S9(3)         COMP-3.        
               10  PAY-BASIS-PROC-DAY          PIC S9(3)         COMP-3.        
           05  PAY-BASIS-PROC-DT               PIC X(10).                       
           05  PAY-BASIS-END-DATE.                                              
               10  PAY-BASIS-END-YEAR          PIC S9(3)         COMP-3.        
               10  PAY-BASIS-END-DAY           PIC S9(3)         COMP-3.        
           05  PAY-BASIS-END-DT                PIC X(10).                       
           05  AGENT-NUMBER                    PIC X(6).                        
