--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TGRACT TABLE  (                                     
                GROUP_NUMBER                   CHAR(7) NOT NULL,                
                GR_ACCOUNT                     CHAR(3) NOT NULL,                
                LAST_RECON_YEAR                                                 
                           DEC(3) NOT NULL WITH DEFAULT,                        
                LAST_RECON_DAY                                                  
                           DEC(3) NOT NULL WITH DEFAULT,                        
                LAST_RECON_DT                                                   
                           DATE NOT NULL WITH DEFAULT,                          
                NEXT_RECON_YEAR                                                 
                           DEC(3) NOT NULL WITH DEFAULT,                        
                NEXT_RECON_DAY                                                  
                           DEC(3) NOT NULL WITH DEFAULT,                        
                NEXT_RECON_DT                                                   
                           DATE NOT NULL WITH DEFAULT,                          
                RENEWAL_EFFECTIVE_YEAR                                          
                           DEC(3) NOT NULL WITH DEFAULT,                        
                RENEWAL_EFFECTIVE_DAY                                           
                           DEC(3) NOT NULL WITH DEFAULT,                        
                RENEWAL_EFFECTIVE_DT                                            
                           DATE NOT NULL WITH DEFAULT,                          
                RENEW_COMP_ADVANCED_IND                                         
                           CHAR(1) NOT NULL WITH DEFAULT,                       
                COMP_LIVES                                                      
                           DEC(7) NOT NULL WITH DEFAULT,                        
                GROUP_GRACT_TS                                                  
                           TIMESTAMP NOT NULL WITH DEFAULT)                     
           END-EXEC.                                                            
       01  GC-TGRACT.                                                           
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  GROUP-ACCOUNT.                                                   
               10  GROUP-NUMBER                PIC X(7).                        
               10  GROUP-NUMBER-9 REDEFINES                                     
                   GROUP-NUMBER                PIC 9(7).                        
               10  GR-ACCOUNT                  PIC X(3).                        
           05  LAST-RECON-DATE.                                                 
               10  LAST-RECON-YEAR             PIC S9(3)         COMP-3.        
               10  LAST-RECON-DAY              PIC S9(3)         COMP-3.        
           05  LAST-RECON-DT                   PIC X(10).                       
           05  NEXT-RECON-DATE.                                                 
               10  NEXT-RECON-YEAR             PIC S9(3)         COMP-3.        
               10  NEXT-RECON-DAY              PIC S9(3)         COMP-3.        
           05  NEXT-RECON-DT                   PIC X(10).                       
           05  RENEWAL-EFFECTIVE-DATE.                                          
               10  RENEWAL-EFFECTIVE-YEAR      PIC S9(3)         COMP-3.        
               10  RENEWAL-EFFECTIVE-DAY       PIC S9(3)         COMP-3.        
           05  RENEWAL-EFFECTIVE-DT            PIC X(10).                       
           05  RENEW-COMP-ADVANCED-IND         PIC X.                           
           05  COMP-LIVES                      PIC S9(7)         COMP-3.        
           05  GROUP-GRACT-TS                  PIC X(26).                       
