--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TACCUM TABLE  (                                     
                PREM_DUE_YEAR                  DEC(3) NOT NULL,                 
                PREM_DUE_DAY                   DEC(3) NOT NULL,                 
                PREM_DUE_DT    DATE NOT NULL WITH DEFAULT,                      
                PREM_AMT_PAID          DEC(11,2) NOT NULL WITH DEFAULT,         
                COMM_AMT_EARNED        DEC(11,2) NOT NULL WITH DEFAULT,         
                SALES_CREDITS_AMT_EARNED       DEC(11,2)                        
                                                 NOT NULL WITH DEFAULT,         
                GROUP_NUMBER                   CHAR(7) NOT NULL,                
                GR_ACCOUNT                     CHAR(3) NOT NULL)                
           END-EXEC.                                                            
       01  GC-TACCUM.                                                           
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  PREM-DUE-DATE.                                                   
               10  PREM-DUE-YEAR               PIC S9(3)         COMP-3.        
               10  PREM-DUE-DAY                PIC S9(3)         COMP-3.        
           05  PREM-DUE-DT                     PIC X(10).                       
           05  PREM-AMT-PAID                   PIC S9(9)V99      COMP-3.        
           05  COMM-AMT-EARNED                 PIC S9(9)V99      COMP-3.        
           05  SALES-CREDITS-AMT-EARNED        PIC S9(9)V99      COMP-3.        
           05  GROUP-ACCOUNT.                                                   
               10  GROUP-NUMBER                PIC X(7).                        
               10  GROUP-NUMBER-9 REDEFINES                                     
                   GROUP-NUMBER                PIC 9(7).                        
               10  GR-ACCOUNT                  PIC X(3).                        
