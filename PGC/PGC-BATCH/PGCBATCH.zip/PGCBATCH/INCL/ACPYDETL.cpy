      ******************************************************************        
      * DCLGEN TABLE(DBCYTD1.APPLICATION_COPY_DETAIL)                  *        
      *        LIBRARY(BRANDHA.PERS.COPYLIB(ACPYDETL))                 *        
      *        ACTION(REPLACE)                                         *        
      *        LANGUAGE(COBOL)                                         *        
      *        APOST                                                   *        
      *        INDVAR(YES)                                             *        
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *        
      ******************************************************************        
           EXEC SQL DECLARE APPLICATION_COPY_DETAIL TABLE                       
           ( REQUEST_ID                     INTEGER NOT NULL,                   
             DETAIL_SEQNO                   INTEGER NOT NULL,                   
             APPLICATION                    CHAR(10) NOT NULL,                  
             CONTRACT                       INTEGER  NOT NULL,                  
             ACCOUNT                        CHAR(3) NOT NULL,                   
             START_CERT                     CHAR(10) NOT NULL,                  
             END_CERT                       CHAR(10) NOT NULL,                  
             FROM_REGION                    CHAR(2) NOT NULL,                   
             TO_REGION                      CHAR(2) NOT NULL,                   
             CAN_ONLY_IND                   CHAR(1) NOT NULL,                   
             PROTECTED_IND                  CHAR(1) NOT NULL,                   
             EXCEPTION_IND                  CHAR(1) NOT NULL,                   
             COPY_TS                        TIMESTAMP NOT NULL,                 
             COPY_DT                        DATE NOT NULL                       
           ) END-EXEC.                                                          
      ******************************************************************        
      * COBOL DECLARATION FOR TABLE DBCYTD1.APPLICATION_COPY_DETAIL    *        
      ******************************************************************        
       01  DCLAPPLICATION-COPY-DETAIL.                                          
           10 REQUEST-ID           PIC S9(9) USAGE COMP.                        
           10 DETAIL-SEQNO         PIC S9(9) USAGE COMP.                        
           10 APPLICATION          PIC X(10).                                   
           10 CONTRACT             PIC S9(9) USAGE COMP.                        
           10 ACCOUNT              PIC X(3).                                    
           10 START-CERT           PIC X(10).                                   
           10 END-CERT             PIC X(10).                                   
           10 FROM-REGION          PIC X(2).                                    
           10 TO-REGION            PIC X(2).                                    
           10 CAN-ONLY-IND         PIC X(1).                                    
           10 PROTECTED-IND        PIC X(1).                                    
           10 EXCEPTION-IND        PIC X(1).                                    
           10 COPY-TS              PIC X(26).                                   
           10 COPY-DT              PIC X(10).                                   
      ******************************************************************        
      * INDICATOR VARIABLE STRUCTURE                                   *        
      ******************************************************************        
       01  IAPPLICATION-COPY-DETAIL.                                            
           10 INDSTRUC           PIC S9(4) USAGE COMP OCCURS 14 TIMES.          
      ******************************************************************        
      * THE NUMBER OF COLUMNS DESCRIBED BY THIS DECLARATION IS 14      *        
      ******************************************************************        
