--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TCOMP TABLE  (                                      
                GROUP_NUMBER       CHAR(7) NOT NULL,                            
                GR_ACCOUNT         CHAR(3) NOT NULL,                            
                COMP_EFF_YEAR      DEC(3) NOT NULL,                             
                COMP_EFF_DAY       DEC(3) NOT NULL,                             
                COMP_EFF_DT        DATE                                         
                                   NOT NULL WITH DEFAULT,                       
                AGENT_NUMBER       CHAR(6) NOT NULL WITH DEFAULT,               
                GFO_NUMBER         CHAR(5) NOT NULL WITH DEFAULT,               
                GROUP_REP          DEC(5) NOT NULL WITH DEFAULT,                
                COMP_PROCESS_YEAR  DEC(3) NOT NULL WITH DEFAULT,                
                COMP_PROCESS_DAY   DEC(3) NOT NULL WITH DEFAULT,                
                COMP_PROCESS_DT    DATE                                         
                                   NOT NULL WITH DEFAULT,                       
                COV_TYPE           CHAR(1) NOT NULL WITH DEFAULT,               
                COMP_TYPE          CHAR(1) NOT NULL WITH DEFAULT,               
                COMP_AMT           DEC(11,2) NOT NULL WITH DEFAULT,             
                COMP_REASON        CHAR(1) NOT NULL WITH DEFAULT,               
                RECON_IND          CHAR(1) NOT NULL WITH DEFAULT,               
                COMP_DISP          CHAR(1) NOT NULL WITH DEFAULT,               
                AGENT_SPLIT        DEC(5,2) NOT NULL WITH DEFAULT,              
                PREM_AMT           DEC(11,2) NOT NULL WITH DEFAULT,             
                PREM_SOURCE        CHAR(2) NOT NULL WITH DEFAULT,               
                AD_D_AMT           DEC(11,2) NOT NULL WITH DEFAULT,             
                WI_AMT             DEC(11,2) NOT NULL WITH DEFAULT,             
                EHC_AMT            DEC(11,2) NOT NULL WITH DEFAULT,             
                DE_AMT             DEC(11,2) NOT NULL WITH DEFAULT,             
                FC_IDENT           INT NOT NULL WITH DEFAULT                    
                                               ,                                
                GRACT_COMP_TS      TIMESTAMP NOT NULL,                          
                GFO_COMP_FLAG      CHAR(1) NOT NULL WITH DEFAULT,               
                GFO_COMP_TS        TIMESTAMP NOT NULL WITH DEFAULT,             
                AGENT_COMP_TS      TIMESTAMP NOT NULL WITH DEFAULT)             
           END-EXEC.                                                            
       01  GC-TCOMP.                                                            
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  GROUP-ACCOUNT.                                                   
               10  GROUP-NUMBER                PIC X(7).                        
               10  GROUP-NUMBER-9 REDEFINES                                     
                   GROUP-NUMBER                PIC 9(7).                        
               10  GR-ACCOUNT                  PIC X(3).                        
           05  COMP-EFF-DATE.                                                   
               10  COMP-EFF-YEAR               PIC S9(3)         COMP-3.        
               10  COMP-EFF-DAY                PIC S9(3)         COMP-3.        
           05  COMP-EFF-DT                     PIC X(10).                       
           05  AGENT-NUMBER                    PIC X(6).                        
           05  GFO-NUMBER                      PIC X(5).                        
           05  GROUP-REP                       PIC S9(5)         COMP-3.        
           05  COMP-PROCESS-DATE.                                               
               10  COMP-PROCESS-YEAR           PIC S9(3)         COMP-3.        
               10  COMP-PROCESS-DAY            PIC S9(3)         COMP-3.        
           05  COMP-PROCESS-DT                 PIC X(10).                       
           05  COV-TYPE                        PIC X.                           
           05  COMP-TYPE                       PIC X.                           
           05  COMP-AMT                        PIC S9(9)V99      COMP-3.        
           05  COMP-REASON                     PIC X.                           
           05  RECON-IND                       PIC X.                           
           05  COMP-DISP                       PIC X.                           
           05  AGENT-SPLIT                     PIC S9(3)V99      COMP-3.        
           05  PREM-AMT                        PIC S9(9)V99      COMP-3.        
           05  PREM-SOURCE                     PIC X(2).                        
           05  AD-D-AMT                        PIC S9(9)V99      COMP-3.        
           05  WI-AMT                          PIC S9(9)V99      COMP-3.        
           05  EHC-AMT                         PIC S9(9)V99      COMP-3.        
           05  DE-AMT                          PIC S9(9)V99      COMP-3.        
           05  FC-IDENT                        PIC S9(9)         COMP.          
           05  GRACT-COMP-TS                   PIC X(26).                       
           05  GFO-COMP-FLAG                   PIC X(1).                        
           05  GFO-COMP-TS                     PIC X(26).                       
           05  AGENT-COMP-TS                   PIC X(26).                       
