--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TCNTL TABLE  (                                      
                LAST_GIPSY_DAILY_RUN_YEAR      DEC(3)                           
                            NOT NULL WITH DEFAULT,                              
                LAST_GIPSY_DAILY_RUN_DAY       DEC(3)                           
                            NOT NULL WITH DEFAULT,                              
                LAST_GIPSY_DAILY_RUN_DT DATE                                    
                            NOT NULL WITH DEFAULT,                              
                LAST_RECON_RUN_YEAR            DEC(3)                           
                            NOT NULL WITH DEFAULT,                              
                LAST_RECON_RUN_DAY             DEC(3)                           
                            NOT NULL WITH DEFAULT,                              
                LAST_RECON_RUN_DT       DATE                                    
                            NOT NULL WITH DEFAULT,                              
                LAST_REN_PREM_RUN_YEAR         DEC(3)                           
                            NOT NULL WITH DEFAULT,                              
                LAST_REN_PREM_RUN_DAY          DEC(3)                           
                            NOT NULL WITH DEFAULT,                              
                LAST_REN_PREM_RUN_DT    DATE                                    
                             NOT NULL WITH DEFAULT,                             
                LAST_REN_COMM_RUN_YEAR         DEC(3)                           
                             NOT NULL WITH DEFAULT,                             
                LAST_REN_COMM_RUN_DAY          DEC(3)                           
                             NOT NULL WITH DEFAULT,                             
                LAST_REN_COMM_RUN_DT    DATE                                    
                              NOT NULL WITH DEFAULT,                            
                COMM_SCR_RECON_IND             CHAR(1)                          
                              NOT NULL WITH DEFAULT,                            
                NAP_RECON_IND                  CHAR(1)                          
                              NOT NULL WITH DEFAULT,                            
                RECON_DATE_UPDATE_IND          CHAR(1)                          
                              NOT NULL WITH DEFAULT,                            
                DIRECT_OOAK_DBKEY              CHAR(8) NOT NULL)                
           END-EXEC.                                                            
       01  GC-TCNTL.                                                            
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  LAST-GIPSY-DAILY-RUN-DATE.                                       
               10  LAST-GIPSY-DAILY-RUN-YEAR   PIC S9(3)         COMP-3.        
               10  LAST-GIPSY-DAILY-RUN-DAY    PIC S9(3)         COMP-3.        
           05  LAST-GIPSY-DAILY-RUN-DT         PIC X(10).                       
           05  LAST-RECON-RUN-DATE.                                             
               10  LAST-RECON-RUN-YEAR         PIC S9(3)         COMP-3.        
               10  LAST-RECON-RUN-DAY          PIC S9(3)         COMP-3.        
           05  LAST-RECON-RUN-DT               PIC X(10).                       
           05  LAST-REN-PREM-RUN-DATE.                                          
               10  LAST-REN-PREM-RUN-YEAR      PIC S9(3)         COMP-3.        
               10  LAST-REN-PREM-RUN-DAY       PIC S9(3)         COMP-3.        
           05  LAST-REN-PREM-RUN-DT            PIC X(10).                       
           05  LAST-REN-COMM-RUN-DATE.                                          
               10  LAST-REN-COMM-RUN-YEAR      PIC S9(3)         COMP-3.        
               10  LAST-REN-COMM-RUN-DAY       PIC S9(3)         COMP-3.        
           05  LAST-REN-COMM-RUN-DT            PIC X(10).                       
           05  COMM-SCR-RECON-IND              PIC X.                           
           05  NAP-RECON-IND                   PIC X.                           
           05  RECON-DATE-UPDATE-IND           PIC X.                           
           05  DIRECT-OOAK-DBKEY               PIC X(8).                        
