--    *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           EXEC SQL DECLARE TADVPS TABLE  (                                     
                NEXT_RENEW_YEAR                DEC(3) NOT NULL,                 
                NEXT_RENEW_DAY                 DEC(3) NOT NULL,                 
                NEXT_RENEW_DT  DATE NOT NULL WITH DEFAULT,                      
                COMM_SCALE                     CHAR(3) NOT NULL,                
                PSM_PREM_ADV           DEC(11,2) NOT NULL WITH DEFAULT,         
                GROUP_NUMBER                   CHAR(7) NOT NULL)                
           END-EXEC.                                                            
       01  GC-TADVPS.                                                           
      *      CREATED BY CONVERT/DB V8R08 ON 09/28/10 AT 09:15         *         
           05  NEXT-RENEW-DATE.                                                 
               10  NEXT-RENEW-YEAR             PIC S9(3)         COMP-3.        
               10  NEXT-RENEW-DAY              PIC S9(3)         COMP-3.        
           05  NEXT-RENEW-DT                   PIC X(10).                       
           05  COMM-SCALE                      PIC X(3).                        
           05  PSM-PREM-ADV                    PIC S9(9)V99      COMP-3.        
           05  GROUP-NUMBER                    PIC X(7).                        
           05  GROUP-NUMBER-9 REDEFINES                                         
               GROUP-NUMBER                    PIC 9(7).                        
