       ID DIVISION.                                                             
GNE                                                                             
       PROGRAM-ID. GSPTRAN2.                                                    
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      *    THIS MODULE IS CALLED BY GSPTRAN1 TO FORMAT GROUP                    
      *    MASTER TRAILERS 000 THRU 045 FOR THE TRANS REG.                      
      *                                                                         
      *    - REVISED HEADINGS FOR QUEBEC TAX AND ADDED                          
      *      POLICYHOLDERS EXPLANATION OF BENEFITS CODE,                        
      *      C. PETERSON   JUL87                                                
      ******************************************************************        
      *****************************************************************         
      *    RELEASE # 1.                                                         
      *    - COLUMN TITLES MUST NOW BE UNCOMPRESSED IN MASTER RECORD.           
      *    DEC/89 M. PRANGE.                                                    
      *    - WANT GGIADMIN-AREA AND GGILIVES-RANGE TO PRINT.                    
      *    SEP/91 M. PRANGE.                                                    
      *    - WANT GGIMAIL-INSTRUCTION TO PRINT.                                 
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77  COMMENT                         PIC X(50)  VALUE                     
           '*****  START OF WORKING STORAGE FOR GSPTRAN2 *****'.                
MAN07  77  SEGMENT-SUB                     PIC S9(4) COMP.                      
       77  NO-PRT-LINES-IN-OCCUR   COMP    PIC S9(4).                           
       77  COV-SUB                 COMP    PIC S9(4).                           
       77  BEN-LOOP-SUB            COMP    PIC S9(4).                           
       77  NO-COV-CODES-MOVED-SUB  COMP    PIC S9(4).                           
       77  PRT-COV-CODE-SUB        COMP    PIC S9(4).                           
       77  ADMIN-SUB               COMP    PIC S9(4).                           
                                                                                
       01  TEST-010-SEGMENT.                                                    
           03  TEST-SUB                  PIC S999 COMP-3.                       
           03  SEG-REM                   PIC S9   COMP-3.                       
                                                                                
       01  WK-GENERAL-BEN.                                                      
           07  WK-NUM-CODES                PIC ZZ9.                             
           07  FILLER                      PIC X(8)  VALUE SPACES.              
           07  WK-TITLES.                                                       
               09  W-GGITITLE-LINE1        PIC X(9).                            
               09  FILLER                  PIC XX    VALUE SPACES.              
               09  W-GGITITLE-LINE2        PIC X(9).                            
           07  FILLER                      PIC X(4)  VALUE SPACES.              
           07  WK-COVERAGE-CODES OCCURS 13 TIMES.                               
               09  WK-COV-CODE             PIC 999.                             
               09  FILLER                  PIC X.                               
                                                                                
       01  WK-OTHER-ADMIN.                                                      
           07  W-GGIOTHER-ADMIN-AMT        PIC ZZZZZZ9.99.                      
           07  FILLER                      PIC XX   VALUE SPACES.               
           07  W-GGIOTHER-ADMIN-IND        PIC X.                               
           07  FILLER                      PIC X    VALUE SPACES.               
           07  W-GGIOTHER-ADMIN-REASON     PIC X(25).                           
                                                                                
       01  WK-BASIC-ADMIN.                                                      
           07  W-GGIBASIC-ADMIN-AMT        PIC ZZZZZZ9.99.                      
           07  FILLER                      PIC X    VALUE SPACES.               
           07  W-GGIBASIC-ADMIN-IND        PIC X.                               
           07  FILLER                      PIC X    VALUE SPACES.               
           07  W-GGIBASIC-ADMIN-REASON     PIC XX.                              
                                                                                
       01  WORK-DATES.                                                          
           03  WDAT-CONV-TYPE              PIC XX    VALUE 'AC'.                
           03  WDATE-P                     PIC X(4).                            
           03  WDATE-C                     PIC X(7).                            
                                                                                
       01  WORK-STATS-AREA.                                                     
           03  W-GSTPROJECTED-LOSS-RATIO.                                       
               05  W-GSTPROJ-LR-PREV-POLYR     PIC Z(3)9.9.                     
               05  FILLER                      PIC X  VALUE SPACES.             
               05  W-GSTPROJ-LR-CURR-POLYR     PIC Z(3)9.9.                     
               05  FILLER                      PIC XX VALUE SPACES.             
           03  W-GSTACCEPT-LOSS-PREV           PIC Z(3)9.9.                     
           03  FILLER                          PIC XX VALUE SPACES.             
           03  W-GSTPART                       PIC Z(6)9.                       
           03  FILLER                          PIC X  VALUE SPACES.             
           03  W-GSTNON-PART                   PIC Z(4)9.                       
                                                                                
       01  WORK-STATS-AREA-COV.                                                 
               07  W-GSTSTAT-COV-CODE          PIC 9(3).                        
               07  FILLER                      PIC X.                           
               07  W-GSTSTAT-VOL               PIC Z(8)9.                       
               07  FILLER                      PIC X.                           
               07  W-GSTSTAT-LIVES             PIC Z(6)9.                       
                                                                                
       01  WORK-NAME-ADDRESS.                                                   
           03  WORK-NA-ERRCODE     PIC X(3).                                    
           03  WORK-NA-AREA1.                                                   
               05  WNA-1A          PIC X(62).                                   
               05  WNA-1B          PIC X(62).                                   
               05  WNA-1C          PIC X(62).                                   
           03  WORK-NA-AREA2 REDEFINES WORK-NA-AREA1.                           
               05  P-NA-LINE-1     PIC X(30).                                   
               05  P-NA-DELIM-1    PIC X.                                       
               05  P-NA-LINE-2     PIC X(30).                                   
               05  P-NA-DELIM-2    PIC X.                                       
               05  P-NA-LINE-3     PIC X(30).                                   
               05  P-NA-DELIM-3    PIC X.                                       
               05  P-NA-LINE-4     PIC X(30).                                   
               05  P-NA-DELIM-4    PIC X.                                       
               05  P-NA-LINE-5     PIC X(30).                                   
               05  P-NA-DELIM-5    PIC X.                                       
               05  P-NA-LINE-6     PIC X(30).                                   
               05  P-NA-DELIM-6    PIC X.                                       
                                                                                
       01  W-BILLING-NUMBER.                                                    
           05  W-PHONE-LONG-D         PIC X.                                    
           05  W-PHONE-AREA-C         PIC X(3).                                 
           05  W-PHONE-NUM-1          PIC X(3).                                 
           05  W-PHONE-NUM-2          PIC X(4).                                 
                                                                                
       01  W-PRINT-BILLING-NUMBER.                                              
           05  W-PRINT-PHONE-LONG-D   PIC X.                                    
           05  W-PRINT-DASH-1         PIC X   VALUE '-'.                        
           05  W-PRINT-PHONE-AREA-C   PIC X(3).                                 
           05  W-PRINT-DASH-2         PIC X   VALUE '-'.                        
           05  W-PRINT-PHONE-NUM-1    PIC X(3).                                 
           05  W-PRINT-DASH-3         PIC X   VALUE '-'.                        
           05  W-PRINT-PHONE-NUM-2    PIC X(4).                                 
                                                                                
       01  LINE-HEADINGS.                                                       
           03  LHEAD-00-AA.                                                     
               05  FILLER  PIC X(24) VALUE '            GROUP GROUP '.          
               05  FILLER  PIC X(24) VALUE 'GROUP SHARE CLAIM       '.          
           03  LHEAD-00-AB.                                                     
               05  FILLER  PIC X(28) VALUE '          PROD'.                    
               05  FILLER  PIC X(14) VALUE 'BEN'.                               
           03  LHEAD-00-BA.                                                     
               05  FILLER  PIC X(24) VALUE 'IDENT  BR   REP 1 REP 2 '.          
               05  FILLER  PIC X(22) VALUE ' OFF   OFF   OFF  CTRY'.            
           03  LHEAD-00-BB.                                                     
               05  FILLER  PIC X(25) VALUE 'CUR RES LNG CODE PACT TYP'.         
               05  FILLER  PIC X(17) VALUE ' COV SEL SICC CON'.                 
           03  LHEAD-00-C.                                                      
               05  FILLER  PIC X(33) VALUE SPACES.                              
               05  FILLER  PIC X(25) VALUE 'REDUCTION AGES'.                    
               05  FILLER  PIC X(16) VALUE 'TERMINATION AGES'.                  
           03  LHEAD-00-D.                                                      
               05  FILLER  PIC X(20) VALUE 'BEN TAX WH EMP HAND '.              
               05  FILLER  PIC X(24) VALUE 'ARREARS  LI LTD ADD MED '.          
               05  FILLER  PIC X(25) VALUE 'DEN  WI  LI LTD ADD PLTD '.         
               05  FILLER  PIC X(20) VALUE 'MED DEN  WI STEP CHG'.              
           03  LHEAD-00-E.                                                      
               05  FILLER  PIC X(67) VALUE 'ACT'.                               
               05  FILLER  PIC X(8)  VALUE 'CASHFLOW'.                          
           03  LHEAD-00-F.                                                      
               05  FILLER  PIC X(12) VALUE 'STS N ANNIV'.                       
               05  FILLER  PIC X(24) VALUE 'CLM SUS CON EFF ACC EFF'.           
               05  FILLER  PIC X(24) VALUE 'PAID TO LST CHG LST ACC'.           
               05  FILLER  PIC X(16) VALUE 'PARR LSTYR CURYR'.                  
           03  LHEAD-00-G.                                                      
               05  FILLER  PIC X(13) VALUE SPACES.                              
               05  FILLER  PIC X(24) VALUE 'BILLING STATEMENT FORMAT'.          
           03  LHEAD-00-H.                                                      
               05  FILLER  PIC X(7)  VALUE ' AGENT'.                            
               05  FILLER  PIC X(5)  VALUE 'TYPE'.                              
               05  FILLER  PIC X(8)  VALUE 'CERTLST'.                           
               05  FILLER  PIC X(8)  VALUE 'ORDRLST'.                           
               05  FILLER  PIC X(6)  VALUE 'BILST'.                             
               05  FILLER  PIC X(9)  VALUE 'EECHGLST'.                          
               05  FILLER  PIC X(8)  VALUE 'WKSH SUM'.                          
           03  LHEAD-00-I  PIC X(20) VALUE 'BENEFIT COMBINATIONS'.              
           03  LHEAD-00-J.                                                      
               05  FILLER  PIC X(21) VALUE 'NUM COV CODES'.                     
               05  FILLER  PIC X(21) VALUE 'TITLES'.                            
               05  FILLER  PIC X(14) VALUE 'COVERAGE CODES'.                    
           03  LHEAD-00-K  PIC X(25) VALUE 'BASIC ADMINISTRATION FEES'.         
           03  LHEAD-00-L  PIC X(25) VALUE 'OTHER ADMIN FEES'.                  
           03  LHEAD-00-M  PIC X(13) VALUE 'AMOUNT  ID RS'.                     
           03  LHEAD-00-N  PIC X(18) VALUE 'AMOUNT  ID  REASON'.                
           03  LHEAD-00-O.                                                      
               05  FILLER  PIC X(7)  VALUE SPACES.                              
               05  FILLER  PIC X(31) VALUE 'CLAIMS INFORMATION'.                
               05  FILLER  PIC X(37) VALUE 'FUNDING TYPE'.                      
               05  FILLER  PIC X(16) VALUE 'ADMIN LIVES MAIL'.                  
           03  LHEAD-00-P.                                                      
               05  FILLER  PIC X(21) VALUE 'CO-HC CO-DE EBEN PDN '.             
               05  FILLER  PIC X(24) VALUE 'DPIND LFEES EOB LIF ADD '.          
               05  FILLER  PIC X(20) VALUE 'LTD  WI EHC DEN BILL'.              
               05  FILLER  PIC X(14) VALUE 'ING-NUMBER ARE'.                    
               05  FILLER  PIC X(12) VALUE 'A RANGE INST'.                      
           03  LHEAD-01-A.                                                      
               05  FILLER  PIC X(14) VALUE 'PD'.                                
               05  FILLER  PIC X(38) VALUE 'OUTSTANDING PREMIUMS'.              
               05  FILLER  PIC X(8)  VALUE 'PREM'.                              
               05  FILLER  PIC X(4)  VALUE 'PREM'.                              
           03  LHEAD-01-B.                                                      
               05  FILLER  PIC X(7)  VALUE 'IND'.                               
               05  FILLER  PIC X(13) VALUE 'LIFE'.                              
               05  FILLER  PIC X(12) VALUE 'LTD'.                               
               05  FILLER  PIC X(12) VALUE 'A&S'.                               
               05  FILLER  PIC X(8)  VALUE 'TAX'.                               
               05  FILLER  PIC X(13) VALUE 'IND   ADVANCE'.                     
           03  LHEAD-01-C.                                                      
               05  FILLER  PIC X(23) VALUE 'CALENDAR YEAR TO DATE'.             
           03  LHEAD-01-D.                                                      
               05  FILLER  PIC X(12) VALUE ' LI BILL'.                          
               05  FILLER  PIC X(12) VALUE 'LI PAID'.                           
               05  FILLER  PIC X(11) VALUE 'AS BILL'.                           
               05  FILLER  PIC X(12) VALUE 'AS PAID'.                           
               05  FILLER  PIC X(11) VALUE 'LTD BILL'.                          
               05  FILLER  PIC X(11) VALUE 'LTD PAID'.                          
               05  FILLER  PIC X(11) VALUE 'TAX BILLED'.                        
               05  FILLER  PIC X(8)  VALUE 'TAX PAID'.                          
           03  LHEAD-01-E.                                                      
               05  FILLER  PIC X(15) VALUE 'P R E M I U M S'.                   
           03  LHEAD-01-F.                                                      
               05  FILLER  PIC X(14) VALUE ' LIFE'.                             
               05  FILLER  PIC X(11) VALUE 'LTD'.                               
               05  FILLER  PIC X(11) VALUE 'AD&D'.                              
               05  FILLER  PIC X(8)  VALUE 'WI'.                                
               05  FILLER  PIC X(12) VALUE 'EHC SINGLE'.                        
               05  FILLER  PIC X(11) VALUE 'EHC FAM1'.                          
               05  FILLER  PIC X(8)  VALUE 'EHC FAM2'.                          
           03  LHEAD-01-G  PIC X(31) VALUE                                      
               'DEN SINGLE  DEN FAM1   DEN FAM2'.                               
           03  LHEAD-01-H.                                                      
               05  FILLER  PIC X(36)                                            
               VALUE 'P R E M I U M  A D J U S T M E N T S'.                    
           03  LHEAD-01-I.                                                      
               05  FILLER  PIC X(11) VALUE '  LIFE'.                            
               05  FILLER  PIC X(9)  VALUE 'LTD'.                               
               05  FILLER  PIC X(9)  VALUE 'AD&D'.                              
               05  FILLER  PIC X(7)  VALUE 'WI'.                                
               05  FILLER  PIC X(9)  VALUE 'EHC SIN'.                           
               05  FILLER  PIC X(9)  VALUE 'EHC FAM1'.                          
               05  FILLER  PIC X(10) VALUE 'EHC FAM2'.                          
               05  FILLER  PIC X(8)  VALUE 'DEN SIN'.                           
               05  FILLER  PIC X(9)  VALUE 'DEN FAM1'.                          
               05  FILLER  PIC X(8)  VALUE 'DEN FAM2'.                          
           03  LHEAD-01-J  PIC X(20) VALUE '  LOSS RATIO    LOSS'.              
           03  LHEAD-01-K  PIC X(3)  VALUE 'NON'.                               
           03  LHEAD-01-L  PIC X(14) VALUE 'COVERAGE CODES'.                    
           03  LHEAD-01-M.                                                      
               05  FILLER  PIC X(24) VALUE 'PREVYR CUR YR  PREV YR'.            
               05  FILLER  PIC X(29) VALUE 'PART   PART   CD   VOLUME'.         
               05  FILLER  PIC X(23) VALUE 'LIVES   CD   VOLUME'.               
               05  FILLER  PIC X(5)  VALUE 'LIVES'.                             
                                                                                
       01  GGIBIT6X-FUNCTION         PIC X(1).                                  
                                                                                
       01  GGIBIT6X-CHAR-CNT         PIC S9(4) COMP SYNC.                       
                                                                                
      *01  GGI6BITX.                                                            
           COPY GGI6BITX.                                                       
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
       LINKAGE SECTION.                                                         
       77  LINE-COUNT  COMP SYNC   PIC S9(4).                                   
       01  PRINT-LINES.                                                         
           03  PRLINES-00.                                                      
               05  PRLINE-00-1-1.                                               
                   07  LHEAD-00-AA     PIC X(48).                               
                   07  FILLER          PIC X.                                   
                   07  LHEAD-00-AB     PIC X(42).                               
               05  PRLINE-00-1-2.                                               
                   07  LHEAD-00-BA     PIC X(46).                               
                   07  FILLER          PIC X.                                   
                   07  LHEAD-00-BB     PIC X(42).                               
                   07  FILLER          PIC X(2).                                
               05  PRLINE-00-2.                                                 
                   07  W-GGIIDENTITY                   PIC X(5).                
                   07  FILLER  PIC X.                                           
                   07  W-GGIBRANCH                     PIC X(5).                
                   07  FILLER  PIC X.                                           
                   07  W-GGIGROUP-REP                  PIC X(5).                
                   07  FILLER  PIC X.                                           
                   07  W-GGIGROUP-REP2                 PIC Z(5).                
                   07  FILLER  PIC X.                                           
                   07  W-GGIGROUP-OFFICE               PIC X(5).                
                   07  FILLER  PIC X.                                           
                   07  W-GGISHARING-OFFICE             PIC X(5).                
                   07  FILLER  PIC X.                                           
                   07  W-GGICLAIMS-OFFICE              PIC X(5).                
                   07  FILLER  PIC XX.                                          
                   07  W-GGICOUNTRY                    PIC X.                   
                   07  FILLER  PIC X(4).                                        
                   07  W-GGICURRENCY                   PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGIRESIDENCE                  PIC XX.                  
                   07  FILLER  PIC X(2).                                        
                   07  W-GGILANGUAGE                   PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGIPRODUCT-CODE               PIC X.                   
                   07  FILLER  PIC X(4).                                        
                   07  W-GGIPOLICY-ACCT                PIC X.                   
                   07  FILLER  PIC X(4).                                        
                   07  P-GGITYPE                       PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGICOVERAGE-CODE              PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGIBENEFIT-SEL                PIC X.                   
                   07  FILLER  PIC X(2).                                        
                   07  W-GGISTD-IND-CLASS-CODE         PIC Z(4)9.               
                   07  FILLER  PIC X(2).                                        
                   07  W-GGICONTRIBUTION               PIC X.                   
                   07  FILLER  PIC XX.                                          
               05  PRLINE-00-3.                                                 
                   07  LHEAD-00-C      PIC X(74).                               
                   07  FILLER          PIC X(17).                               
               05  PRLINE-00-4.                                                 
                   07  LHEAD-00-D      PIC X(89).                               
                   07  FILLER          PIC X(2).                                
               05  PRLINE-00-5.                                                 
                   07  FILLER  PIC X.                                           
                   07  W-GGIBENEFIT-LINK               PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGITAX                        PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGIWITHHOLDING                PIC X.                   
                   07  FILLER  PIC XX.                                          
                   07  W-GGIEMPLOYEE-LIST              PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGIHANDLING-CODE              PIC X.                   
                   07  FILLER  PIC X(3).                                        
                   07  W-GGIARREARS-IND                PIC X.                   
                   07  FILLER  PIC X.                                           
                   07  W-GGIARREARS-COUNTER            PIC ZZ9.                 
                   07  FILLER  PIC X.                                           
                   07  W-GGIARREARS-STATUS             PIC X.                   
                   07  FILLER  PIC X.                                           
                   07  W-GGIREDUCTION-AGES.                                     
                       09  W-GGIRED-AGE-LIFE           PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGIRED-AGE-LTD            PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGIRED-AGE-AD-D           PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGIRED-AGE-MEDICAL        PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGIRED-AGE-DENTAL         PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGIRED-AGE-WEEK-INDEM     PIC Z99.                 
                       09  FILLER  PIC X.                                       
                   07  W-GGITERMINATION-AGES.                                   
                       09  W-GGITERM-AGE-LIFE          PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGITERM-AGE-LTD           PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGITERM-AGE-AD-D          PIC Z99.                 
                       09  FILLER  PIC XX.                                      
                       09  W-GGITERM-WAIT-PERIOD-LTD   PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGITERM-AGE-MEDICAL       PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGITERM-AGE-DENTAL        PIC Z99.                 
                       09  FILLER  PIC X.                                       
                       09  W-GGITERM-AGE-WEEK-INDEM    PIC Z99.                 
                   07  FILLER  PIC XXX.                                         
                   07  W-GGISTEP-DOWN                  PIC X.                   
                   07  FILLER  PIC XXX.                                         
                   07  W-GGICHANGE-DATE                PIC X.                   
                   07  FILLER  PIC XXX.                                         
               05  PRLINE-00-6.                                                 
                   07  LHEAD-00-E      PIC X(75).                               
                   07  FILLER          PIC X(16).                               
               05  PRLINE-00-7.                                                 
                   07  LHEAD-00-F      PIC X(76).                               
                   07  FILLER          PIC X(15).                               
               05  PRLINE-00-8.                                                 
                   07  FILLER  PIC X.                                           
                   07  W-GGIACCOUNT-STATUS             PIC XX.                  
                   07  FILLER  PIC X.                                           
                   07  P-GGINEXT-ANNIVERSARY           PIC X(7).                
                   07  FILLER  PIC X.                                           
                   07  P-GGICLAIMS-SUSPENDED           PIC X(7).                
                   07  FILLER  PIC X.                                           
                   07  P-GGICONTRACT-ISSUE             PIC X(7).                
                   07  FILLER  PIC X.                                           
                   07  P-GGI-ACCT-EFFECTIVE            PIC X(7).                
                   07  FILLER PIC X.                                            
                   07  P-GGIPAID-TO-DATE               PIC X(7).                
                   07  FILLER PIC X.                                            
                   07  P-GGILAST-CHANGE-DATE           PIC X(7).                
                   07  FILLER PIC X.                                            
                   07  P-GGILAST-ACCOUNTING-DATE       PIC X(7).                
                   07  FILLER PIC XX.                                           
                   07  W-GGIPOL-ARREARS                PIC Z9.                  
                   07  FILLER PIC XXX.                                          
                   07  W-GGICASHFLOW-LST-POL-YR        PIC ZZ9.                 
                   07  FILLER PIC XXX.                                          
                   07  W-GGICASHFLOW-CURR-POL-YR       PIC ZZ9.                 
                   07  FILLER PIC X(16).                                        
               05  PRLINE-00-9.                                                 
                   07  LHEAD-00-G      PIC X(37).                               
                   07  FILLER          PIC X(54).                               
               05  PRLINE-00-10.                                                
                   07  LHEAD-00-H      PIC X(51).                               
                   07  FILLER          PIC X(40).                               
               05  PRLINE-00-11.                                                
                   07  W-GGIBILL-STAT-FORMAT.                                   
                       09  W-GGIBILLING-AGENT        PIC Z(5)9.                 
                       09  FILLER                    PIC XX.                    
                       09  W-GGIBILLING-TYPE         PIC XX.                    
                       09  FILLER                    PIC X(5).                  
                       09  W-GGILISTING-CERTIFICATE  PIC X.                     
                       09  FILLER                    PIC X(7).                  
                       09  W-GGILISTING-ORDER        PIC X.                     
                       09  FILLER                    PIC X(6).                  
                       09  W-GGISTAT-OPTION.                                    
                           11  W-GGILIST-BILLING         PIC X.                 
                           11  FILLER                    PIC X(7).              
                           11  W-GGIEMP-CHANGE-LIST      PIC X.                 
                           11  FILLER                    PIC X(6).              
                           11  W-GGIWORK-SHEET           PIC X.                 
                           11  FILLER                    PIC X(3).              
                           11  W-GGISUMMARY              PIC X.                 
                   07  FILLER                    PIC X(41).                     
               05  PRLINE-00-11-5.                                              
                   07  LHEAD-00-O      PIC X(91).                               
               05  PRLINE-00-11-6.                                              
                   07  LHEAD-00-P      PIC X(91).                               
               05  PRLINE-00-11-7.                                              
                   10  FILLER PIC X(2).                                         
                   10  P-GGICARRYOVER-IND.                                      
                       15  P-GGICARRYOVER-HC   PIC X.                           
                       15  FILLER PIC X(5).                                     
                       15  P-GGICARRYOVER-DE   PIC X.                           
                   10  FILLER PIC X(5).                                         
                   10  P-GGIELIGIBLE-BENEFITS  PIC X.                           
                   10  FILLER PIC XXX.                                          
                   10  P-GGIPRIVATE-DUTY-NURSING PIC Z9.                        
                   10  FILLER PIC XXX.                                          
                   10  P-GGIDENTAL-PLAN-IND    PIC X.                           
                   10  FILLER PIC X(5).                                         
                   10  P-GGILAB-FEES           PIC XX.                          
                   10  FILLER PIC XXX.                                          
                   10  P-GGIPH-EOB             PIC X.                           
                   10  P-FUND-TYPES OCCURS 6 TIMES.                             
                       15  FILLER PIC XXX.                                      
                       15  P-GGIFUND-TYPE      PIC X.                           
                   10  FILLER PIC X(1).                                         
                   10  P-BILLING-NUMBER        PIC X(14).                       
                   10  FILLER                  PIC X(3).                        
                   10  P-GGIADMIN-AREA         PIC X(1).                        
                   10  FILLER                  PIC X(5).                        
                   10  P-GGILIVES-RANGE        PIC X(1).                        
                   10  FILLER                  PIC X(5).                        
                   10  P-GGIMAIL-INSTRUCTION   PIC X(1).                        
                   10  FILLER                  PIC X(1).                        
               05  PRLINE-00-12.                                                
                   07  FILLER          PIC X(13).                               
                   07  LHEAD-00-I      PIC X(20).                               
                   07  FILLER          PIC X(58).                               
               05  PRLINE-00-13.                                                
                   07  LHEAD-00-J      PIC X(56).                               
                   07  FILLER          PIC X(35).                               
               05  PRLINE-00-14 OCCURS 15 TIMES.                                
                   07  PRLINE-BEN-COMB.                                         
                       09  FILLER             PIC X(4).                         
                       09  BENEFIT-COMB-LINE  PIC X(87).                        
                   07  ADMIN-TITLE-1 REDEFINES PRLINE-BEN-COMB.                 
                       09  FILLER             PIC X(3).                         
                       09  LHEAD-ADMIN-1-A    PIC X(25).                        
                       09  FILLER             PIC X(10).                        
                       09  LHEAD-ADMIN-1-B    PIC X(15).                        
                   07  ADMIN-TITLE-2 REDEFINES PRLINE-BEN-COMB.                 
                       09  FILLER             PIC X(2).                         
                       09  LHEAD-ADMIN-2-A    PIC X(13).                        
                       09  FILLER             PIC X(4).                         
                       09  LHEAD-ADMIN-2-B    PIC X(13).                        
                       09  FILLER             PIC X(5).                         
                       09  LHEAD-ADMIN-2-C    PIC X(18).                        
                   07  ADMIN-DATA-FIELDS REDEFINES PRLINE-BEN-COMB.             
                       09  ADMIN-DATA1        PIC X(15).                        
                       09  FILLER             PIC X(2).                         
                       09  ADMIN-DATA2        PIC X(15).                        
                       09  FILLER             PIC X(2).                         
                       09  ADMIN-DATA3        PIC X(38).                        
               05  FILLER                      PIC X(1527).                     
           03  PRLINES-01  REDEFINES PRLINES-00.                                
               05  PRLINE-01-1.                                                 
                   07  LHEAD-01-A      PIC X(80).                               
                   07  FILLER          PIC X(11).                               
               05  PRLINE-01-2.                                                 
                   07  LHEAD-01-B      PIC X(65).                               
                   07  FILLER          PIC X(26).                               
               05  PRLINE-01-3.                                                 
                   07  FILLER  PIC X.                                           
                   07  W-GSTPAID-IND                   PIC X.                   
                   07  FILLER  PIC X.                                           
                   07  W-GSTOUTSTANDING.                                        
                       09  W-GSTOUT-LIFE               PIC -(7)9.99.            
                       09  FILLER  PIC X.                                       
                       09  W-GSTOUT-LTD                PIC -(7)9.99.            
                       09  FILLER  PIC X.                                       
                       09  W-GSTOUT-A-S                PIC -(7)9.99.            
                       09  FILLER  PIC X.                                       
                       09  W-GSTOUT-ADMIN-FEE          PIC -(7)9.99.            
                   07  FILLER  PIC XXX.                                         
                   07  W-GSTPREMIUM-IND                PIC X.                   
                   07  FILLER  PIC XXX.                                         
                   07  W-GSTADVANCE                    PIC -(7)9.99.            
                   07  FILLER  PIC X(23).                                       
               05  PRLINE-01-4.                                                 
                   07  FILLER          PIC X(30).                               
                   07  LHEAD-01-C      PIC X(23).                               
                   07  FILLER          PIC X(38).                               
               05  PRLINE-01-5.                                                 
                   07  LHEAD-01-D      PIC X(90).                               
                   07  FILLER          PIC X.                                   
               05  PRLINE-01-6.                                                 
                   07  W-GSTCALENDAR-YEAR-TO-DATE.                              
                       09  W-GSTCAL-YTD-LIFE.                                   
                           11  W-GSTCAL-YTD-LI-BILLED  PIC -(7)9.99.            
                           11  W-GSTCAL-YTD-LI-PAID    PIC -(7)9.99.            
                           11  FILLER  PIC X.                                   
                       09  W-GSTCAL-YTD-A-S.                                    
                           11  W-GSTCAL-YTD-AS-BILLED  PIC -(7)9.99.            
                           11  W-GSTCAL-YTD-AS-PAID    PIC -(7)9.99.            
                           11  FILLER  PIC X.                                   
                       09  W-GSTCAL-YTD-LTD.                                    
                           11  W-GSTCAL-YTD-LTD-BILLED PIC -(7)9.99.            
                           11  W-GSTCAL-YTD-LTD-PAID   PIC -(7)9.99.            
                           11  FILLER  PIC X.                                   
                       09  W-GSTCAL-YTD-ADMIN-FEE.                              
                           11  W-GSTCAL-YTD-ADMIN-FEE-BILLED                    
                                                       PIC -(7)9.99.            
                           11  W-GSTCAL-YTD-ADMIN-FEE-PAID                      
                                                       PIC -(7)9.99.            
               05  PRLINE-01-7.                                                 
                   07  FILLER          PIC X(30).                               
                   07  LHEAD-01-E      PIC X(15).                               
                   07  FILLER          PIC X(46).                               
               05  PRLINE-01-8.                                                 
                   07  LHEAD-01-F      PIC X(75).                               
                   07  FILLER          PIC X(16).                               
               05  PRLINE-01-9.                                                 
                 06 W-GSTPREMIUMS.                                              
                   07  W-GSTPREM-LIFE                  PIC Z(6)9.99.            
                   07  FILLER  PIC X.                                           
                   07  W-GSTPREM-LTD                   PIC Z(6)9.99.            
                   07  FILLER  PIC X.                                           
                   07  W-GSTPREM-AD-D                  PIC Z(6)9.99.            
                   07  FILLER  PIC X.                                           
                   07  W-GSTPREM-WI                    PIC Z(6)9.99.            
                   07  FILLER  PIC X.                                           
                   07  W-GSTPREM-EHC.                                           
                       09  W-GSTPREM-EHC-SINGLE        PIC Z(6)9.99.            
                       09  FILLER  PIC X.                                       
                       09  W-GSTPREM-EHC-FAMILY1       PIC Z(6)9.99.            
                       09  FILLER  PIC X.                                       
                       09  W-GSTPREM-EHC-FAMILY2       PIC Z(6)9.99.            
                   07  FILLER  PIC X(15).                                       
               05  PRLINE-01-10.                                                
                   07  FILLER          PIC X(22).                               
                   07  LHEAD-01-G      PIC X(31).                               
                   07  FILLER          PIC X(38).                               
               05  PRLINE-01-11.                                                
                   07  FILLER  PIC X(22).                                       
                   07  W-GSTPREM-DEN.                                           
                       09  W-GSTPREM-DEN-SINGLE        PIC Z(6)9.99.            
                       09  FILLER  PIC X.                                       
                       09  W-GSTPREM-DEN-FAMILY1       PIC Z(6)9.99.            
                       09  FILLER  PIC X.                                       
                       09  W-GSTPREM-DEN-FAMILY2       PIC Z(6)9.99.            
                   07  FILLER  PIC X(37).                                       
               05  PRLINE-01-12.                                                
                   07  FILLER          PIC X(23).                               
                   07  LHEAD-01-H      PIC X(36).                               
                   07  FILLER          PIC X(32).                               
               05  PRLINE-01-13.                                                
                   07  LHEAD-01-I      PIC X(89).                               
                   07  FILLER          PIC X(2).                                
               05  PRLINE-01-14.                                                
                 06  W-GSTCURR-MONTH-PREM-ADJ.                                  
                   07  W-GSTPREM-ADJ-LIFE          PIC -(5)9.99.                
                   07  W-GSTPREM-ADJ-LTD           PIC -(5)9.99.                
                   07  W-GSTPREM-ADJ-AD-D          PIC -(5)9.99.                
                   07  W-GSTPREM-ADJ-WI            PIC -(5)9.99.                
                   07  W-GSTPREM-ADJ-EHC.                                       
                       09  W-GSTPREM-ADJ-EHC-SINGLE  PIC -(5)9.99.              
                       09  W-GSTPREM-ADJ-EHC-FAMILY1 PIC -(5)9.99.              
                       09  W-GSTPREM-ADJ-EHC-FAMILY2 PIC -(5)9.99.              
                   07  W-GSTPREM-ADJ-DEN.                                       
                       09  W-GSTPREM-ADJ-DEN-SINGLE  PIC -(5)9.99.              
                       09  W-GSTPREM-ADJ-DEN-FAMILY1 PIC -(5)9.99.              
                       09  W-GSTPREM-ADJ-DEN-FAMILY2 PIC -(5)9.99.              
                       09  FILLER                    PIC X.                     
               05  PRLINE-01-15.                                                
                   07  LHEAD-01-J      PIC X(20).                               
                   07  FILLER          PIC X(12).                               
                   07  LHEAD-01-K      PIC X(3).                                
                   07  FILLER          PIC X(15).                               
                   07  LHEAD-01-L      PIC X(14).                               
                   07  FILLER          PIC X(27).                               
               05  PRLINE-01-16.                                                
                   07  LHEAD-01-M      PIC X(81).                               
                   07  FILLER          PIC X(10).                               
               05  PRLINE-01-17 OCCURS 8 TIMES.                                 
                   07  PRLINE-01-17-A  PIC X(36).                               
                   07  FILLER          PIC XX.                                  
                   07  PRLINE-01-17-B  PIC X(21).                               
                   07  FILLER          PIC XX.                                  
                   07  PRLINE-01-17-C  PIC X(21).                               
                   07  FILLER          PIC X(9).                                
           03  PRLINES-03-04   REDEFINES PRLINES-00.                            
               05  P-NAME-ADDR.                                                 
                   07  FILLER          PIC X(6).                                
                   07  P-NA-TYPE       PIC XX.                                  
                   07  FILLER          PIC X.                                   
                   07  P-NA-LINE-1     PIC X(30).                               
                   07  FILLER          PIC XX.                                  
                   07  FILLER          PIC X(5).                                
                   07  P-NA-LINE-2     PIC X(30).                               
                   07  FILLER          PIC XX.                                  
                   07  FILLER          PIC X(13).                               
                   07  FILLER          PIC X(9).                                
                   07  P-NA-LINE-3     PIC X(30).                               
                   07  FILLER          PIC XX.                                  
                   07  FILLER          PIC X(5).                                
                   07  P-NA-LINE-4     PIC X(30).                               
                   07  FILLER          PIC XX.                                  
                   07  FILLER          PIC X(13).                               
                   07  FILLER          PIC X(9).                                
                   07  P-NA-LINE-5     PIC X(30).                               
                   07  FILLER          PIC XX.                                  
                   07  FILLER          PIC X(5).                                
                   07  P-NA-LINE-6     PIC X(30).                               
                   07  FILLER          PIC XX.                                  
                   07  FILLER          PIC X(13).                               
               05  FILLER                              PIC X(455).              
                                                                                
      *01  WMGENTR                                                              
GNE        COPY  WMGENTR7.                                                      
                                                                                
      *01  WWMSTSTR.                                                            
           COPY  WMSTSTR.                                                       
                                                                                
      *01  WNA-NAME-ADDRESS.                                                    
           COPY  WMNADTR.                                                       
                                                                                
       PROCEDURE DIVISION.                                                      
      ******************************************************************        
      *    THIS SECTION SETS UP THE PRINT LINES WITH INFORMATION FROM           
      *    TRLR 000.                                                            
      ******************************************************************        
           ENTRY 'GSPTTR00' USING LINE-COUNT, PRINT-LINES,                      
                                  WMGENTR.                                      
           MOVE 17 TO LINE-COUNT.                                               
           MOVE SPACES TO PRLINES-00.                                           
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-1-1.                 
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-1-2.                 
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-3.                   
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-4.                   
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-6.                   
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-7.                   
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-9.                   
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-10.                  
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-12.                  
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-13.                  
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-11-5.                
           MOVE CORR LINE-HEADINGS            TO PRLINE-00-11-6.                
           MOVE CORR WMGENTR                  TO PRLINE-00-2.                   
           MOVE CORR WMGENTR                  TO PRLINE-00-5.                   
           MOVE CORR WMGENTR                  TO PRLINE-00-8.                   
           MOVE CORR WMGENTR                  TO PRLINE-00-11.                  
           MOVE W-GGITYPE                     TO P-GGITYPE.                     
           MOVE W-GGINEXT-ANNIVERSARY         TO WDATE-P.                       
           PERFORM CONV-DATES                                                   
           MOVE WDATE-C                       TO P-GGINEXT-ANNIVERSARY          
           MOVE W-GGICLAIMS-SUSPENDED         TO WDATE-P.                       
           PERFORM CONV-DATES                                                   
           MOVE WDATE-C                       TO P-GGICLAIMS-SUSPENDED.         
           MOVE W-GGICONTRACT-ISSUE           TO WDATE-P.                       
           PERFORM CONV-DATES                                                   
           MOVE WDATE-C                       TO P-GGICONTRACT-ISSUE            
           MOVE W-GGI-ACCT-EFFECTIVE          TO WDATE-P.                       
           PERFORM CONV-DATES                                                   
           MOVE WDATE-C                       TO P-GGI-ACCT-EFFECTIVE           
           MOVE W-GGIPAID-TO-DATE             TO WDATE-P.                       
           PERFORM CONV-DATES                                                   
           MOVE WDATE-C                       TO P-GGIPAID-TO-DATE.             
           MOVE W-GGILAST-CHANGE-DATE         TO WDATE-P.                       
           PERFORM CONV-DATES                                                   
           MOVE WDATE-C                       TO P-GGILAST-CHANGE-DATE          
           MOVE W-GGILAST-ACCOUNTING-DATE     TO WDATE-P.                       
           PERFORM CONV-DATES                                                   
           MOVE WDATE-C                   TO P-GGILAST-ACCOUNTING-DATE.         
           MOVE W-GGICARRYOVER-HC         TO P-GGICARRYOVER-HC.                 
           MOVE W-GGICARRYOVER-DE         TO P-GGICARRYOVER-DE.                 
           MOVE W-GGIELIGIBLE-BENEFITS    TO P-GGIELIGIBLE-BENEFITS.            
           MOVE W-GGIPRIVATE-DUTY-NURSING TO                                    
                                    P-GGIPRIVATE-DUTY-NURSING.                  
           MOVE W-GGIDENTAL-PLAN-IND      TO P-GGIDENTAL-PLAN-IND.              
           MOVE W-GGILAB-FEES             TO P-GGILAB-FEES.                     
           MOVE W-GGIPH-EOB               TO P-GGIPH-EOB.                       
           MOVE W-GGIFUND-TYPE (1)        TO P-GGIFUND-TYPE (1).                
           MOVE W-GGIFUND-TYPE (2)        TO P-GGIFUND-TYPE (2).                
           MOVE W-GGIFUND-TYPE (3)        TO P-GGIFUND-TYPE (3).                
           MOVE W-GGIFUND-TYPE (4)        TO P-GGIFUND-TYPE (4).                
           MOVE W-GGIFUND-TYPE (5)        TO P-GGIFUND-TYPE (5).                
           MOVE W-GGIFUND-TYPE (6)        TO P-GGIFUND-TYPE (6).                
           MOVE W-GGIBILLING-OR-TELE-NUM  TO W-BILLING-NUMBER.                  
           IF   W-BILLING-NUMBER = SPACES                                       
                MOVE SPACES                  TO P-BILLING-NUMBER                
           ELSE                                                                 
                MOVE  W-PHONE-LONG-D         TO W-PRINT-PHONE-LONG-D            
                MOVE  W-PHONE-AREA-C         TO W-PRINT-PHONE-AREA-C            
                MOVE  W-PHONE-NUM-1          TO W-PRINT-PHONE-NUM-1             
                MOVE  W-PHONE-NUM-2          TO W-PRINT-PHONE-NUM-2             
                MOVE  W-PRINT-BILLING-NUMBER TO P-BILLING-NUMBER.               
                                                                                
           MOVE W-GGIADMIN-AREA              TO P-GGIADMIN-AREA.                
           MOVE W-GGILIVES-RANGE             TO P-GGILIVES-RANGE.               
           MOVE W-GGIMAIL-INSTRUCTION        TO P-GGIMAIL-INSTRUCTION.          
      *                                                                         
      *    LOGIC TO HANDLE PRINTING OF BENEFIT CODE COMBINATION FIELDS          
      *    AND ADMIN FEE FIELDS.                                                
      *                                                                         
           MOVE +0 TO NO-PRT-LINES-IN-OCCUR, COV-SUB.                           
           MOVE +1 TO BEN-LOOP-SUB.                                             
           MOVE SPACES TO WK-GENERAL-BEN.                                       
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    WANT TO EXPAND THE COMPRESSED 6-BIT BENEFIT COMBINATIONS             
      *    INTO READABLE FORMAT AND MOVE TO PRINT LINES.                        
      ****************************************************************          
           MOVE 'E'                      TO GGIBIT6X-FUNCTION.                  
           MOVE +171                     TO GGIBIT6X-CHAR-CNT.                  
           MOVE SPACES                   TO GGI6BITX.                           
                                                                                
           CALL 'GUTBITS6' USING GGIBIT6X-FUNCTION                              
                                 GGIBIT6X-CHAR-CNT                              
                                 W-GGITITLES-AREA                               
                                 GGI6BITX.                                      
                                                                                
       BEN-PRINT-LOOP.                                                          
           IF W-GGINUM-COV-CODES (BEN-LOOP-SUB) EQUAL +0 AND                    
             (B6-GGIPREM-OR-VOL (BEN-LOOP-SUB) NOT EQUAL 'B')                   
              ADD +1 TO BEN-LOOP-SUB                                            
              IF BEN-LOOP-SUB NOT GREATER THAN +9                               
                 GO TO BEN-PRINT-LOOP                                           
              ELSE                                                              
                 GO TO PRINT-ADMIN-FEES.                                        
           MOVE W-GGINUM-COV-CODES (BEN-LOOP-SUB) TO WK-NUM-CODES.              
           MOVE B6-GGITITLE-LINE1  (BEN-LOOP-SUB) TO W-GGITITLE-LINE1.          
           MOVE B6-GGITITLE-LINE2  (BEN-LOOP-SUB) TO W-GGITITLE-LINE2.          
      *  MOVE COVERAGE CODES (13 TO A PRINT LINE)                               
       MOVE-COV-CODES.                                                          
           MOVE +0 TO NO-COV-CODES-MOVED-SUB, PRT-COV-CODE-SUB.                 
       MOVE-COV-LOOP.                                                           
           ADD +1 TO NO-COV-CODES-MOVED-SUB, PRT-COV-CODE-SUB.                  
           IF NO-COV-CODES-MOVED-SUB GREATER THAN                               
                           W-GGINUM-COV-CODES (BEN-LOOP-SUB)  OR                
              PRT-COV-CODE-SUB GREATER THAN 13                                  
              GO TO PRINT-BEN-LINE.                                             
           ADD +1 TO COV-SUB.                                                   
           MOVE W-GGICOV-CODES (COV-SUB) TO                                     
                                         WK-COV-CODE (PRT-COV-CODE-SUB).        
           GO TO MOVE-COV-LOOP.                                                 
        PRINT-BEN-LINE.                                                         
           ADD +1 TO NO-PRT-LINES-IN-OCCUR.                                     
           MOVE WK-GENERAL-BEN TO                                               
                               BENEFIT-COMB-LINE (NO-PRT-LINES-IN-OCCUR)        
           MOVE SPACES TO WK-GENERAL-BEN.                                       
           IF NO-COV-CODES-MOVED-SUB GREATER THAN                               
                                     W-GGINUM-COV-CODES (BEN-LOOP-SUB)          
              ADD +1 TO BEN-LOOP-SUB                                            
              IF BEN-LOOP-SUB NOT GREATER THAN +9                               
                 GO TO BEN-PRINT-LOOP                                           
              ELSE                                                              
                 GO TO PRINT-ADMIN-FEES.                                        
           MOVE +0 TO PRT-COV-CODE-SUB.                                         
           SUBTRACT +1 FROM NO-COV-CODES-MOVED-SUB.                             
           GO TO MOVE-COV-LOOP.                                                 
       PRINT-ADMIN-FEES.                                                        
           IF W-GGIBASIC-ADMIN-AMT IN W-GGIBASIC-ADMIN-FEE (1) = +0             
                AND W-GGIOTHER-ADMIN-AMT IN W-GGIOTHER-ADMIN-FEE = +0           
              GO TO COMPUTE-NO-LINES.                                           
      *  PRINT ADMIN HEADINGS                                                   
           ADD +1 TO NO-PRT-LINES-IN-OCCUR.                                     
           MOVE LHEAD-00-K TO LHEAD-ADMIN-1-A (NO-PRT-LINES-IN-OCCUR).          
           MOVE LHEAD-00-L TO LHEAD-ADMIN-1-B (NO-PRT-LINES-IN-OCCUR).          
           ADD +1 TO NO-PRT-LINES-IN-OCCUR.                                     
           MOVE LHEAD-00-M TO LHEAD-ADMIN-2-A (NO-PRT-LINES-IN-OCCUR).          
           MOVE LHEAD-00-M TO LHEAD-ADMIN-2-B (NO-PRT-LINES-IN-OCCUR).          
           MOVE LHEAD-00-N TO LHEAD-ADMIN-2-C (NO-PRT-LINES-IN-OCCUR).          
           MOVE +1 TO ADMIN-SUB.                                                
       ADMIN-LOOP.                                                              
           ADD +1 TO NO-PRT-LINES-IN-OCCUR.                                     
           IF ADMIN-SUB EQUAL +1                                                
              IF W-GGIOTHER-ADMIN-AMT IN W-GGIOTHER-ADMIN-FEE                   
                                         NOT EQUAL +0                           
                 MOVE CORR W-GGIOTHER-ADMIN-FEE TO WK-OTHER-ADMIN               
                 MOVE WK-OTHER-ADMIN TO                                         
                               ADMIN-DATA3 (NO-PRT-LINES-IN-OCCUR).             
           IF W-GGIBASIC-ADMIN-AMT IN W-GGIBASIC-ADMIN-FEE (ADMIN-SUB)          
                               NOT EQUAL +0                                     
              MOVE CORR W-GGIBASIC-ADMIN-FEE (ADMIN-SUB)                        
                                             TO WK-BASIC-ADMIN                  
              MOVE WK-BASIC-ADMIN TO                                            
                               ADMIN-DATA1 (NO-PRT-LINES-IN-OCCUR).             
           ADD +1 TO ADMIN-SUB.                                                 
           IF W-GGIBASIC-ADMIN-AMT IN W-GGIBASIC-ADMIN-FEE (ADMIN-SUB)          
                               NOT EQUAL +0                                     
              MOVE CORR W-GGIBASIC-ADMIN-FEE (ADMIN-SUB)                        
                                             TO WK-BASIC-ADMIN                  
              MOVE WK-BASIC-ADMIN TO                                            
                               ADMIN-DATA2 (NO-PRT-LINES-IN-OCCUR).             
           ADD +1 TO ADMIN-SUB.                                                 
           IF (ADMIN-SUB NOT GREATER THAN +4) AND                               
              (W-GGIBASIC-ADMIN-AMT IN W-GGIBASIC-ADMIN-FEE (ADMIN-SUB)         
                               NOT EQUAL +0)                                    
              GO TO ADMIN-LOOP.                                                 
       COMPUTE-NO-LINES.                                                        
           ADD NO-PRT-LINES-IN-OCCUR TO LINE-COUNT.                             
           GO TO TRAN2-EXIT.                                                    
                                                                                
      ******************************************************************        
      *    THIS SECTION SETS UP THE PRINT LINES WITH INFORMATION FROM           
      *    TRLR 010.                                                            
      ******************************************************************        
           ENTRY 'GSPTTR01' USING LINE-COUNT, PRINT-LINES,                      
                                  WWMSTSTR.                                     
           MOVE 16 TO LINE-COUNT.                                               
           MOVE SPACES TO PRINT-LINES.                                          
           MOVE CORR LINE-HEADINGS TO PRLINE-01-1.                              
           MOVE CORR LINE-HEADINGS TO PRLINE-01-2.                              
           MOVE CORR LINE-HEADINGS TO PRLINE-01-4.                              
           MOVE CORR LINE-HEADINGS TO PRLINE-01-5.                              
           MOVE CORR LINE-HEADINGS TO PRLINE-01-7.                              
           MOVE CORR LINE-HEADINGS TO PRLINE-01-8.                              
           MOVE CORR LINE-HEADINGS TO PRLINE-01-10.                             
           MOVE CORR LINE-HEADINGS TO PRLINE-01-12.                             
           MOVE CORR LINE-HEADINGS TO PRLINE-01-13.                             
           MOVE CORR LINE-HEADINGS TO PRLINE-01-15.                             
           MOVE CORR LINE-HEADINGS TO PRLINE-01-16.                             
           MOVE CORR WWMSTSTR      TO PRLINE-01-3.                              
           MOVE CORR WWMSTSTR      TO PRLINE-01-6.                              
           MOVE CORR WWMSTSTR      TO PRLINE-01-9.                              
           MOVE CORR W-GSTPREMIUMS IN WWMSTSTR                                  
                                   TO PRLINE-01-11.                             
           MOVE CORR WWMSTSTR      TO PRLINE-01-14.                             
           MOVE CORR WWMSTSTR      TO WORK-STATS-AREA.                          
           MOVE WORK-STATS-AREA    TO PRLINE-01-17-A (1).                       
           IF W-GSTNUM-COV-CODES EQUAL +0                                       
              ADD +1 TO LINE-COUNT.                                             
           PERFORM MOVE-COV-STATS THRU MOVE-COV-STATS-EXIT                      
                   VARYING SEGMENT-SUB FROM 1 BY 1                              
                      UNTIL SEGMENT-SUB GREATER THAN W-GSTNUM-COV-CODES.        
           GO TO TRAN2-EXIT.                                                    
       MOVE-COV-STATS.                                                          
           MOVE SPACES TO WORK-STATS-AREA-COV.                                  
           MOVE CORR W-GSTSTATS-BY-COV (SEGMENT-SUB)                            
                                       TO WORK-STATS-AREA-COV.                  
      *                                                                         
           DIVIDE SEGMENT-SUB BY 2 GIVING TEST-SUB REMAINDER SEG-REM.           
           IF SEG-REM EQUAL +0                                                  
              MOVE WORK-STATS-AREA-COV TO PRLINE-01-17-C (TEST-SUB)             
           ELSE                                                                 
              ADD +1 TO LINE-COUNT                                              
              ADD +1 TO TEST-SUB                                                
              MOVE WORK-STATS-AREA-COV TO PRLINE-01-17-B (TEST-SUB).            
       MOVE-COV-STATS-EXIT.                                                     
           EXIT.                                                                
       END-TRL-010.                                                             
                                                                                
      ******************************************************************        
      *    THIS SECTION SETS UP THE PRINT LINES WITH INFORMATION FROM           
      *    A NAME AND ADDRESS TRLR (EITHER 030, 040 OR 045).  EACH PRINT        
      *    LINE HAS ROOM FOR TWO NAME AND/OR ADDRESS LINES.                     
      ******************************************************************        
           ENTRY 'GSPTTRNA' USING LINE-COUNT                                    
                                  PRINT-LINES                                   
                                  WNA-NAME-ADDRESS.                             
GNE        CALL GZNAEXP7  USING WNA-NAME-ADDRESS                                
GNE                               WORK-NA-AREA1,                                
GNE                               WORK-NA-ERRCODE.                              
           MOVE 3 TO LINE-COUNT.                                                
           IF WNA-1C EQUAL TO SPACES,                                           
                                      MOVE 2 TO LINE-COUNT.                     
           IF WNA-1B EQUAL TO SPACES,                                           
                                      MOVE 1 TO LINE-COUNT.                     
           MOVE SPACES TO P-NAME-ADDR.                                          
           MOVE CORR WORK-NA-AREA2 TO P-NAME-ADDR.                              
           IF WNATRIDENT EQUAL '045'                                            
              MOVE WNAIDENT TO P-NA-TYPE.                                       
           GO TO TRAN2-EXIT.                                                    
                                                                                
       CONV-DATES.                                                              
           CALL 'QDATE' USING WDAT-CONV-TYPE, WDATE-P                           
                              WDATE-C.                                          
       TRAN2-EXIT.                                                              
           GOBACK.                                                              
                                                                                
MAN07 *9999-DUMP-ROUTINE.                                                       
MAN07 ******************************************************************        
MAN07 *    SERIOUS ERROR OCCURRED.                                              
MAN07 *    DISPLAY SOME CONSOLE MESSAGES, TAKE A DUMP THEN ABEND.               
MAN07 *    COPYBOOK GWRDUMP IS REQUIRED                                         
MAN07 ******************************************************************        
MAN07 *                                                                         
MAN07 *    MOVE WS-PROGRAM-ID TO GWRDUMP-PROGRAM-NAME.                          
MAN07 *    CALL GWCDUMP    USING ICBM                                           
MAN07 *                          GWRDUMP.                                       
MAN07 *                                                                         
MAN07 *9999-EXIT.                                                               
MAN07 *    EXIT.                                                                
