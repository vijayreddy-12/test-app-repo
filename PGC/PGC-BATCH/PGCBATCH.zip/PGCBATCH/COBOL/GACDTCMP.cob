       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    GACDTCMP.                                                 
      *This program has been examined/renovated for Year 2000 compliance.       
      *AUTHOR.        ANITA NIKELSKI.                                           
      *DATE-WRITTEN.  JUN 1992.                                                 
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *       THIS UTILITY WILL FORMAT A DATE (GARDTCMP-DATE) INTO THE          
      *    COMPLEMENTED-DATE.  THIS WOULD BE USED TO FIND A <= SITUATION        
      *    FOR A VSAM FILE.                                                     
      ******************************************************************        
      *    EG. 19920601 (01JUN92) WOULD BE CONVERTED TO                         
      *        GARDTCMP-FORMATTED-YYYY = 9999 - 1992                            
      *                                  9007                                   
      *        GARDTCMP-FORMATTED-MM   = 12   - 06                              
      *                                  06                                     
      *        GARDTCMP-FORMATTED-DD   = 31   - 01                              
      *                                  30                                     
      ******************************************************************        
      ****************************************************************          
      *                       PROGRAM HISTORY                        *          
      ****************************************************************          
      *                                                              *          
      *  OCT 08  -  IBM  - ENTERPRISE COMPILER UPGRADE               *          
      ****************************************************************          
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(24)      VALUE                       
           'GACDTCMP WS STARTS HERE*'.                                          
                                                                                
       01  WS-HIGH-DATE.                                                        
           05  WS-HIGH-YYYY          PIC 9(4)       VALUE 9999.                 
           05  WS-HIGH-MM            PIC 9(2)       VALUE 12.                   
           05  WS-HIGH-DD            PIC 9(2)       VALUE 31.                   
                                                                                
       01  WS-END                    PIC X(24)      VALUE                       
           'GACDTCMP WS ENDS   HERE*'.                                          
       01  WS-END-BYTE-X             PIC X(1)       VALUE '*'.                  
      /                                                                         
       LINKAGE SECTION.                                                         
                                                                                
           COPY GARDTCMP.                                                       
      /                                                                         
       PROCEDURE DIVISION USING GARDTCMP.                             
                                                                                
       0000-GACDTCMP.                                                           
           COMPUTE GARDTCMP-FORMATTED-YYYY =                                    
                                      WS-HIGH-YYYY  - GARDTCMP-YYYY.            
           COMPUTE GARDTCMP-FORMATTED-MM   =                                    
                                      WS-HIGH-MM    - GARDTCMP-MM.              
           COMPUTE GARDTCMP-FORMATTED-DD   =                                    
                                      WS-HIGH-DD    - GARDTCMP-DD.              
           GOBACK.                                                              
