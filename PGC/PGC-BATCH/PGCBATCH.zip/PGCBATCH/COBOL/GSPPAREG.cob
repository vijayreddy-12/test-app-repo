       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
GNE                                                                             
       PROGRAM-ID. GSPPAREG.                                                    
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *****************************************************************         
      *REMARKS.  THIS MODULE IS USED BY BOTH GSPLIRT + GPRINTAL                 
      *          TO PRODUCE THE P+A TRANSACTION REGISTER.                       
      ******************************************************************        
      *   FEB/90 M. PRANGE                                                      
      *        - FIXED EOJ PROCESSING. TRIED TO PICK UP GROUP IN                
      *          P-A-HEAD-RTN FROM NEXT RECORD  (I.E. NOT A 'J' RECORD).        
      *                                                                         
      *   JUN/93 M. PRANGE                                                      
      *        - CHANGES TO DISPLAY TAX TYPE.                                   
      *                                                                         
      *   JUL/93 D. MAJA                                                        
      *        - FIX TO PREVENT S0C7                                            
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
      *DATE-WRITTEN.  MODIFIED MAY 1984                                         
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  COMMENT                                 PIC  X(49) VALUE             
           '***** START OF WORKING STORAGE FOR GSPPAREG *****'.                 
                                                                                
       01  WS-P-A-KEY.                                                          
           05  WS-P-A-KEY-TYPE                     PIC X(1).                    
GNE        05  WS-P-A-KEY-GROUP                    PIC S9(7) COMP-3.            
           05  WS-P-A-KEY-ACCT                     PIC X(3).                    
           05  WS-P-A-KEY-TRANS-DATE.                                           
               10  WS-P-A-KEY-TRANS-YEAR           PIC S9(3) COMP-3.            
               10  WS-P-A-KEY-TRANS-DAY            PIC S9(3) COMP-3.            
                                                                                
       01  MAX-LINES          COMP SYNC  VALUE +0  PIC S9(4).                   
       01  LINE-COUNT         COMP                 PIC S9(4).                   
       01  GOB-PAGE-COUNT     COMP-3     VALUE +0  PIC S9(5).                   
       01  CZB-PAGE-COUNT     COMP-3     VALUE +0  PIC S9(5).                   
       01  C-Z-B-NO-ENT       COMP SYNC  VALUE +6  PIC S9(4).                   
       01  C-Z-B-SUB          COMP       VALUE +1  PIC S9(4).                   
       01  C-Z-B-TOT-DB       COMP-3     VALUE +0  PIC S9(9)V99.                
       01  C-Z-B-TOT-CR       COMP-3     VALUE +0  PIC S9(9)V99.                
       01  C-Z-B-TOT-DB-LI    COMP-3     VALUE +0  PIC S9(9)V99.                
       01  C-Z-B-TOT-CR-LI    COMP-3     VALUE +0  PIC S9(9)V99.                
       01  C-Z-B-TOT-DB-HE    COMP-3     VALUE +0  PIC S9(9)V99.                
       01  C-Z-B-TOT-CR-HE    COMP-3     VALUE +0  PIC S9(9)V99.                
       01  HEALTH-TOT         COMP-3     VALUE +0  PIC S9(9)V99.                
       01  LIFE-TOT           COMP-3     VALUE +0  PIC S9(9)V99.                
       01  P-A-REC-G-L-POSITIONS.                                               
           05  P-A-REC-G-L-POSITION-1    VALUE SPACES PIC X.                    
           05  P-A-REC-G-L-POSITION-2    VALUE SPACES PIC X(6).                 
                                                                                
      *** COUNTRY AMOUNTS ACCUMULATORS TABLE ****                               
       01  ACCUMULATORS.                                                        
           05  P-A-DB-TOT       COMP-3             PIC S9(9)V99.                
           05  P-A-CR-TOT       COMP-3             PIC S9(9)V99.                
                                                                                
           05  G-O-B-AMT-TOT    COMP-3 VALUE +0    PIC S9(7)V99.                
                                                                                
           05  CTRY-ZERO-BAL-TOTS.                                              
               10  C-Z-B-CAN-CODE         VALUE '0'   PIC X(1).                 
               10  FILLER                 VALUE 'CAN' PIC X(3).                 
               10  C-Z-B-CAN-DB    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-CAN-CR    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-CAN-DB-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-CAN-CR-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-CAN-DB-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-CAN-CR-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-USA-CODE         VALUE '3'   PIC X(1).                 
               10  FILLER                 VALUE 'USA' PIC X(3).                 
               10  C-Z-B-USA-DB    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-USA-CR    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-USA-DB-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-USA-CR-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-USA-DB-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-USA-CR-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-JAM-CODE         VALUE '5'   PIC X(1).                 
               10  FILLER                 VALUE 'JAM' PIC X(3).                 
               10  C-Z-B-JAM-DB    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-JAM-CR    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-JAM-DB-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-JAM-CR-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-JAM-DB-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-JAM-CR-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BAH-CODE         VALUE '7'   PIC X(1).                 
               10  FILLER                 VALUE 'BAH' PIC X(3).                 
               10  C-Z-B-BAH-DB    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BAH-CR    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BAH-DB-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BAH-CR-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BAH-DB-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BAH-CR-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BER-CODE         VALUE '4'   PIC X(1).                 
               10  FILLER                 VALUE 'BER' PIC X(3).                 
               10  C-Z-B-BER-DB    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BER-CR    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BER-DB-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BER-CR-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BER-DB-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-BER-CR-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-OTH-CODE         VALUE '9'   PIC X(1).                 
               10  FILLER                 VALUE 'OTH' PIC X(3).                 
               10  C-Z-B-OTH-DB    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-OTH-CR    COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-OTH-DB-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-OTH-CR-LI COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-OTH-DB-HE COMP-3 VALUE +0    PIC S9(9)V99.             
               10  C-Z-B-OTH-CR-HE COMP-3 VALUE +0    PIC S9(9)V99.             
           05  C-Z-B-TOTS REDEFINES CTRY-ZERO-BAL-TOTS                          
                               OCCURS 6 TIMES.                                  
               10  FILLER                          PIC X(1).                    
               10  C-Z-B-CTRY-NME                  PIC X(3).                    
               10  C-Z-B-CTRY-AMT-DB    COMP-3     PIC S9(9)V99.                
               10  C-Z-B-CTRY-AMT-CR    COMP-3     PIC S9(9)V99.                
               10  C-Z-B-CTRY-AMT-DB-LI COMP-3     PIC S9(9)V99.                
               10  C-Z-B-CTRY-AMT-CR-LI COMP-3     PIC S9(9)V99.                
               10  C-Z-B-CTRY-AMT-DB-HE COMP-3     PIC S9(9)V99.                
               10  C-Z-B-CTRY-AMT-CR-HE COMP-3     PIC S9(9)V99.                
                                                                                
       01  WORK-AREA.                                                           
                                                                                
      *** CONTROL FIELDS ****                                                   
           05  CUR-CTL-FLD.                                                     
               10  C-SEG1.                                                      
                   15  C-SEG2.                                                  
                       20  C-SEG3.                                              
                           25  C-REC-TYPE          PIC X(1)                     
                                                   VALUE   LOW-VALUE.           
GNE                    20  C-GROUP         COMP-3  PIC S9(7).                   
                       20  C-ACCT                  PIC X(3)                     
                                                   VALUE   LOW-VALUE.           
                   15  C-TRANS-DATE                PIC X(4)                     
                                                   VALUE   LOW-VALUE.           
                                                                                
           05  PREV-CTL-FLD.                                                    
               10  P-SEG1.                                                      
                   15  P-SEG2.                                                  
                       20  P-SEG3.                                              
                           25  P-REC-TYPE          PIC X(1).                    
                       20  P-GROUP-ACCT.                                        
GNE                        25  P-GROUP     COMP-3  PIC S9(7).                   
                           25  P-ACCT              PIC X(3).                    
                   15  P-TRANS-DATE                PIC X(4).                    
                                                                                
           05  P-A-HIGH-L-ACCT-DT                  PIC X(4).                    
                                                                                
      *** QDATE CONVERT FIELDS ****                                             
           05  QDATE-FUNCT     VALUE 'AC'          PIC X(2).                    
           05  ALIS-DATE.                                                       
               07 ALIS-YEAR    COMP-3              PIC S999.                    
               07 ALIS-DAY     COMP-3              PIC S999.                    
           05  CONV-DATE.                                                       
               10  FILLER                          PIC X(2).                    
               10  CONV-MMMYY                      PIC X(5).                    
                                                                                
       01  GNUMTBL-PARAMS.                                                      
           05  GNUM-TABLE      VALUE +20   COMP    PIC S9(4).                   
           05  GNUMTBL-RETURN                      PIC X(15).                   
                                                                                
      *** HEADINGS ****                                                         
                                                                                
       01  TITLE-END-HEADINGS.                                                  
           05  TITL-END0.                                                       
               10  FILLER                          PIC X(9) VALUE               
               '1GSPPAREG'.                                                     
               10  FILLER            VALUE SPACES  PIC X(95).                   
           05  TITL-END1.                                                       
               10  FILLER                          PIC X(52) VALUE              
               '0                                                   '.          
               10  FILLER                          PIC X(19) VALUE              
               '         E N D  O F'.                                           
           05  TITL-END2.                                                       
               10  FILLER                          PIC X(52) VALUE              
               '0                                        G I P S Y  '.          
               10  FILLER                          PIC X(41) VALUE              
               'P R E M I U M  A N D  A C C O U N T I N G'.                     
           05  TITL-END3.                                                       
               10  FILLER                          PIC X(52) VALUE              
               '0                                               T R '.          
               10  FILLER                          PIC X(34) VALUE              
               'A N S A C T I O N  R E G I S T E R'.                            
           05  TITL-END4.                                                       
               10  FILLER                          PIC X(52) VALUE              
               '0                                                   '.          
               10  FILLER                          PIC X(18) VALUE              
               '     FOR MONTH OF '.                                            
               10  TITLE-DATE1                     PIC X(5).                    
           05  TITL-END5.                                                       
               10  FILLER                          PIC X(52) VALUE              
               '0                                                   '.          
               10  FILLER                          PIC X(16) VALUE              
               '     RUN  DATE  '.                                              
               10  TITLE-DATE2                     PIC X(7).                    
           05  P-A-HEAD1.                                                       
               10  FILLER                          PIC X(52) VALUE              
               '1GSPPAREG                               GIPSY  DETAI'.          
               10  FILLER                          PIC X(34) VALUE              
               'L  ACCOUNTING  TRANSACTIONS  FOR  '.                            
               10  HD-DATE1                        PIC X(5).                    
               10  FILLER      VALUE SPACE         PIC X(14).                   
               10  HD-DT-PAGE-AREA.                                             
                   15  HD-DT-AREA.                                              
                       20  FILLER                  PIC X(9)                     
                           VALUE 'RUN DATE '.                                   
                       20  HD-DATE2                PIC X(7).                    
                   15  FILLER                      PIC X(7)                     
                           VALUE '  PAGE '.                                     
                   15  HD-PAGE                     PIC ZZZZ9.                   
                                                                                
           05  P-A-HEAD2.                                                       
               10  FILLER                          PIC X(42)                    
               VALUE '0GROUP   ACCT  TRANS LAST ACCT  DUE  TYPE '.              
               10  FILLER                          PIC X(43)                    
               VALUE 'ACT    G.L.         PREMIUM  AMOUNT     CT '.             
               10  FILLER                          PIC X(47)                    
               VALUE 'CU   AGENT   1 YR COMM AGENT  COMM   COMMISSION'.         
                                                                                
           05  P-A-HEAD3.                                                       
               10  FILLER                          PIC X(42)                    
               VALUE '               DATE    DATE     DATE      '.              
               10  FILLER                          PIC X(43)                    
               VALUE 'CODE   CODE       DEBIT        CREDIT      '.             
               10  FILLER                          PIC X(47)                    
               VALUE '    CODE ACC TYPE IND  SHARE  RATE     AMOUNT  '.         
                                                                                
           05  GRP-OUT-BAL-HD1.                                                 
               10  FILLER                          PIC X(52) VALUE              
               '1GSPPAREG                                       G R '.          
               10  FILLER                          PIC X(34) VALUE              
               'O U P S  O U T  O F  B A L A N C E'.                            
           05  GRP-OUT-BAL-HD2.                                                 
               10  FILLER                          PIC X(50) VALUE              
               '-                    GROUP  ACCT            AMOUNT'.            
                                                                                
           05  CTRY-ZERO-BAL-HD1.                                               
               10  FILLER                          PIC X(52) VALUE              
               '1GSPPAREG                                   C O U N '.          
               10  FILLER                          PIC X(38) VALUE              
               'T R Y  Z E R O  B A L A N C E  L I S T'.                        
           05  CTRY-ZERO-BAL-HD2.                                               
               10  FILLER                          PIC X(34) VALUE              
               '0                                 '.                            
               10  FILLER                          PIC X(34) VALUE              
               '                        |---------'.                            
               10  FILLER                          PIC X(34) VALUE              
               '------ LIFE ---------------|   |--'.                            
               10  FILLER                          PIC X(30) VALUE              
               '--------- HEALTH ------------|'.                                
           05  CTRY-ZERO-BAL-HD3.                                               
               10  FILLER                          PIC X(34) VALUE              
               '0                        DEBIT    '.                            
               10  FILLER                          PIC X(34) VALUE              
               '           CREDIT            DEBIT'.                            
               10  FILLER                          PIC X(34) VALUE              
               '               CREDIT             '.                            
               10  FILLER                          PIC X(30) VALUE              
               ' DEBIT             CREDIT     '.                                
                                                                                
      *** GROUP OUT OF BALANCE RECORD - WRITTEN DLSWRITE READ DLSREAD  *        
       01  GROUP-OUT-BAL-RECORD.                                                
           05  FILLER      COMP    VALUE +20       PIC S9(4).                   
           05  FILLER              VALUE '00'      PIC X(2).                    
           05  GOB-GROUP-ACCT.                                                  
GNE            10  GOB-GROUP   COMP-3              PIC S9(7).                   
               10  GOB-ACCT                        PIC X(3).                    
           05  GOB-AMT         COMP-3              PIC S9(7)V99.                
GNE        05  FILLER              VALUE SPACE     PIC X(4).                    
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
      *01  GIPSY-P-A-TRANS-RECORD.                                              
GNE        COPY GJRECOR7.                                                       
                                                                                
       01  REPORT-DATE-PASSED                      PIC X(4).                    
                                                                                
       01  PRINT-LINE.                                                          
           05  CC                                  PIC X(1).                    
           05  PRT-LINE.                                                        
GNE            10  P-PA-GROUP                      PIC ZZZZZZ9.                 
               10  FILLER                          PIC X(2).                    
               10  P-PA-ACCT                       PIC X(3).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-TRAN-DT                    PIC X(7).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-L-ACCT                     PIC X(7).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-DUE-DATE                   PIC X(7).                    
               10  FILLER                          PIC X(2).                    
               10  P-PA-TYPE                       PIC X(1).                    
               10  FILLER                          PIC X(2).                    
               10  P-PA-ACT-COD                    PIC X(3).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-TAX-CODE                   PIC X(2).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-G-L                        PIC X(7).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-DB-PREM                    PIC Z,ZZZ,ZZ9.99.            
               10  FILLER                          PIC X(1).                    
               10  P-PA-CR-PREM                    PIC Z,ZZZ,ZZ9.99.            
               10  FILLER                          PIC X(1).                    
               10  P-PA-TOT-OUT-BAL                PIC X(3).                    
               10  P-PA-CTRY REDEFINES P-PA-TOT-OUT-BAL PIC X(1).               
               10  P-PA-CURR                       PIC X(1).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-AG-CODE                    PIC X(6).                    
               10  FILLER                          PIC X(1).                    
               10  P-PA-AG-ACCT                    PIC X(1).                    
               10  FILLER                          PIC X(2).                    
               10  P-PA-1YR-TYPE                   PIC X(4).                    
               10  FILLER                          PIC X(2).                    
               10  P-PA-COMM-STAT                  PIC X(1).                    
               10  FILLER                          PIC X(2).                    
               10  P-PA-AG-PERCENT                 PIC ZZ9.99.                  
               10  FILLER                          PIC X(1).                    
               10  P-PA-COMM-RATE                  PIC Z9.99.                   
               10  FILLER                          PIC X(1).                    
               10  P-PA-COMM-AMT                   PIC Z,ZZZ,ZZ9.99BCR.         
           05  FILLER  REDEFINES PRT-LINE.                                      
               10  FILLER                          PIC X(20).                   
GNE            10  P-GOB-GROUP                     PIC ZZZZZZ9.                 
               10  P-GOB-TOT-WD REDEFINES P-GOB-GROUP                           
                                                   PIC X(7).                    
               10  FILLER                          PIC X(2).                    
               10  P-GOB-ACCT                      PIC X(3).                    
               10  FILLER                          PIC X(8).                    
               10  P-GOB-AMT                       PIC Z,ZZZ,ZZ9.99.            
               10  FILLER                          PIC X(1).                    
               10  P-GOB-DB                        PIC X(2).                    
           05  FILLER  REDEFINES PRT-LINE.                                      
               10  FILLER                          PIC X(7).                    
               10  P-CZB-TOT-OUT-BAL               PIC X(3).                    
               10  FILLER                          PIC X(2).                    
               10  P-CZB-TOTAL-WD                  PIC X(5).                    
               10  P-CZB-CTRY-NME REDEFINES P-CZB-TOTAL-WD                      
                                                   PIC X(3).                    
               10  FILLER                          PIC X(2).                    
               10  P-CZB-DB-AMT                    PIC ZZZ,ZZZ,ZZZ.99.          
               10  FILLER                          PIC X(7).                    
               10  P-CZB-CR-AMT                    PIC ZZZ,ZZZ,ZZZ.99.          
               10  FILLER                          PIC X(3).                    
               10  P-CZB-DB-AMT-LI                 PIC ZZZ,ZZZ,ZZZ.99.          
               10  FILLER                          PIC X(7).                    
               10  P-CZB-CR-AMT-LI                 PIC ZZZ,ZZZ,ZZZ.99.          
               10  FILLER                          PIC X(6).                    
               10  P-CZB-DB-AMT-HE                 PIC ZZZ,ZZZ,ZZZ.99.          
               10  FILLER                          PIC X(5).                    
               10  P-CZB-CR-AMT-HE                 PIC ZZZ,ZZZ,ZZZ.99.          
           05  FILLER  REDEFINES PRT-LINE.                                      
               10  FILLER                          PIC X(104).                  
               10  P-HD-DT-PAGE                    PIC X(28).                   
       01  PRINT-PARAMETERS.                                                    
                             COPY GSPPRTPM REPLACING                            
                                    ==01  PRINT-PARAMETERS.== BY ====.          
                                                                                
       01  TAPE-PARAMETERS.                                                     
                            COPY GSPFLEPM REPLACING                             
                                     ==01  TAPE-PARAMETERS.== BY ====.          
                                                                                
      ****  D.DOCS         MAINLINE                        SECTION.             
       PROCEDURE DIVISION             USING  GIPSY-P-A-TRANS-RECORD             
                                             REPORT-DATE-PASSED                 
                                             PRINT-LINE                         
                                             PRINT-PARAMETERS                   
                                             TAPE-PARAMETERS.                   
                                                                                
           MOVE CUR-CTL-FLD            TO PREV-CTL-FLD.                         
                                                                                
           IF GJREC-TYPE = 'J'                                                  
               MOVE GJREC-TYPE             TO WS-P-A-KEY-TYPE                   
               MOVE GJREC-GROUP            TO WS-P-A-KEY-GROUP                  
               MOVE GJREC-ACCT             TO WS-P-A-KEY-ACCT                   
               MOVE GJREC-TRANSACTION-DATE TO WS-P-A-KEY-TRANS-DATE             
           ELSE                                                                 
               MOVE SPACES                 TO WS-P-A-KEY.                       
           MOVE WS-P-A-KEY             TO CUR-CTL-FLD.                          
                                                                                
      ****  D.DOCS         CONTROL                         ROUTINE.             
           IF  PREV-CTL-FLD IS        EQUAL  TO LOW-VALUE THEN                  
               PERFORM INITIALIZE-RTN THRU   INIT-EXIT                          
               GO TO MLS-REINIT-GROUP-ACCT.                                     
           IF  C-SEG1 IS              EQUAL  TO P-SEG1 THEN                     
               GO TO MLS-NORMAL-PROCESS.                                        
           IF  C-SEG2 IS              EQUAL  TO P-SEG2 THEN                     
               GO TO MLS-REINIT-TRANS-DATE.                                     
           PERFORM GROUP-ACCT-SUM     THRU   GRP-ACCT-SUM-EXIT.                 
           IF  C-SEG3 IS              EQUAL  P-SEG3 THEN                        
               NEXT SENTENCE                                                    
           ELSE                                                                 
               PERFORM EOJ-RTN        THRU   EOJ-RTN-EXIT                       
               GO TO MLS-GETBACK.                                               
       MLS-REINIT-GROUP-ACCT.                                                   
           MOVE C-GROUP               TO     P-PA-GROUP.                        
           MOVE C-ACCT                TO     P-PA-ACCT.                         
           MOVE +0                    TO     P-A-DB-TOT                         
                                             P-A-CR-TOT.                        
           MOVE GJREC-LAST-ACCOUNTING-DATE                                      
                                      TO     P-A-HIGH-L-ACCT-DT.                
       MLS-REINIT-TRANS-DATE.                                                   
           MOVE C-TRANS-DATE          TO     ALIS-DATE                          
           PERFORM CONVERT-DATE       THRU   CONV-DATE-EXIT.                    
           MOVE CONV-DATE             TO     P-PA-TRAN-DT.                      
           MOVE '0'                   TO     CC.                                
                                                                                
       MLS-NORMAL-PROCESS.                                                      
           MOVE GJREC-PAY-TYPE        TO     P-PA-TYPE.                         
           MOVE GJREC-ACTION-CODE     TO     P-PA-ACT-COD.                      
           MOVE GJREC-TAX-CODE        TO     P-PA-TAX-CODE.                     
           MOVE GJREC-GLCODE          TO     P-A-REC-G-L-POSITIONS.             
           MOVE GJREC-GLCODE          TO     P-PA-G-L.                          
           MOVE GJREC-DUE-DATE        TO     ALIS-DATE.                         
           PERFORM CONVERT-DATE       THRU   CONV-DATE-EXIT.                    
           MOVE CONV-DATE             TO     P-PA-DUE-DATE.                     
           IF  GJREC-PREM-AMT GREATER THAN +0                                   
               MOVE GJREC-PREM-AMT    TO     P-PA-DB-PREM                       
               IF  C-GROUP            EQUAL  +0                                 
               OR GJREC-COMM-STATUS   EQUAL  'S' OR 'T'                         
                  NEXT SENTENCE                                                 
               ELSE                                                             
                  PERFORM ADD-PREM-TO-DEBT-CTRY THRU                            
                                             ADD-PREM-DEBT-EXIT                 
           ELSE                                                                 
               IF  GJREC-PREM-AMT LESS THAN +0                                  
                   MOVE GJREC-PREM-AMT TO P-PA-CR-PREM                          
                   IF  C-GROUP IS EQUAL  TO +0                                  
                   OR  GJREC-COMM-STATUS EQUAL 'S' OR 'T'                       
                       NEXT SENTENCE                                            
                   ELSE                                                         
                       PERFORM ADD-PREM-TO-CRDT-CTRY THRU                       
                               ADD-PREM-CRDT-EXIT.                              
           IF  GJREC-COMM-STATUS IS EQUAL TO   'S' OR 'T'                       
           OR  GJREC-FIRST-YR-COMM IS EQUAL TO '1'                              
           OR  GJREC-PAY-TYPE IS EQUAL    TO   'C'                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  GJREC-PREM-AMT GREATER THAN +0                               
                   ADD GJREC-PREM-AMT     TO    P-A-DB-TOT                      
               ELSE                                                             
                   ADD GJREC-PREM-AMT     TO    P-A-CR-TOT.                     
           IF  GJREC-LAST-ACCOUNTING-DATE > P-A-HIGH-L-ACCT-DT                  
           AND PRINT-SYS029 IS EQUAL      TO    'SYS021'                        
               MOVE GJREC-LAST-ACCOUNTING-DATE                                  
                                          TO    P-A-HIGH-L-ACCT-DT              
           ELSE                                                                 
               IF  GJREC-LAST-ACCOUNTING-DATE < P-A-HIGH-L-ACCT-DT              
               AND PRINT-SYS029 IS EQUAL  TO    'SYS005'                        
                   MOVE GJREC-LAST-ACCOUNTING-DATE                              
                                          TO    P-A-HIGH-L-ACCT-DT              
           MOVE SPACES                    TO    GNUMTBL-RETURN.                 
           CALL  'GNUMTABL'               USING GNUM-TABLE                      
                                                GJREC-FIRST-YR-COMM             
                                                GNUMTBL-RETURN.                 
           IF  GNUMTBL-RETURN NOT         EQUAL SPACES THEN                     
               MOVE GNUMTBL-RETURN        TO    P-PA-1YR-TYPE.                  
           MOVE GJREC-COUNTRY             TO    P-PA-CTRY.                      
           MOVE GJREC-CURRENCY            TO    P-PA-CURR.                      
           MOVE GJREC-AG-CODE             TO    P-PA-AG-CODE.                   
           MOVE GJREC-AG-ACCT             TO    P-PA-AG-ACCT.                   
           MOVE GJREC-COMM-STATUS         TO    P-PA-COMM-STAT.                 
           MOVE GJREC-AGENT-PERCENT       TO    P-PA-AG-PERCENT.                
           MOVE GJREC-COMM-RATE           TO    P-PA-COMM-RATE.                 
           MOVE GJREC-COMM-AMT            TO    P-PA-COMM-AMT.                  
           PERFORM PRINT-IT               THRU PR-EXIT.                         
       MLS-GETBACK.                                                             
           MOVE +0 TO TAPE-RETURN.                                              
           GOBACK.                                                              
                                                                                
       INITIALIZE-RTN.                                                          
           CALL  'ZLINECT' USING MAX-LINES.                                     
           MOVE REPORT-DATE-PASSED TO ALIS-DATE.                                
           PERFORM CONVERT-DATE THRU                                            
                   CONV-DATE-EXIT.                                              
           MOVE CONV-DATE TO TITLE-DATE2                                        
                             HD-DATE2.                                          
           MOVE CONV-MMMYY TO TITLE-DATE1                                       
                              HD-DATE1.                                         
           MOVE SPACE TO PRT-LINE.                                              
           PERFORM TITLE-END-RTN THRU                                           
                   TITL-END-EXIT.                                               
           PERFORM P-A-HEAD-RTN THRU                                            
                   P-A-HD-EXIT.                                                 
       INIT-EXIT.                                                               
           EXIT.                                                                
                                                                                
       GROUP-ACCT-SUM.                                                          
           MOVE '0' TO CC.                                                      
           MOVE P-A-HIGH-L-ACCT-DT TO ALIS-DATE.                                
           PERFORM CONVERT-DATE THRU                                            
                   CONV-DATE-EXIT.                                              
           MOVE CONV-DATE TO P-PA-L-ACCT.                                       
           MOVE 'TOTAL' TO P-PA-G-L.                                            
           MOVE P-A-DB-TOT TO P-PA-DB-PREM.                                     
           MOVE P-A-CR-TOT TO P-PA-CR-PREM.                                     
           COMPUTE GOB-AMT = P-A-DB-TOT + P-A-CR-TOT.                           
           IF  P-GROUP IS NOT EQUAL TO +0                                       
               AND GOB-AMT IS NOT EQUAL TO +0 THEN                              
               MOVE '***' TO P-PA-TOT-OUT-BAL                                   
               PERFORM WRITE-GRP-OUT-BAL-REC THRU                               
                       W-GOB-EXIT.                                              
           IF  LINE-COUNT IS EQUAL TO +5                                        
           AND PREV-CTL-FLD IS NOT EQUAL TO LOW-VALUES THEN                     
               MOVE P-GROUP TO P-PA-GROUP                                       
               MOVE P-ACCT TO P-PA-ACCT.                                        
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT.                                                     
       GRP-ACCT-SUM-EXIT.                                                       
           EXIT.                                                                
                                                                                
       ADD-PREM-TO-DEBT-CTRY.                                                   
           IF  GJREC-FIRST-YR-COMM = '1' OR                                     
               GJREC-PAY-TYPE      = 'C'                                        
               GO TO  ADD-PREM-DEBT-EXIT.                                       
                                                                                
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-CAN-CODE THEN              
               ADD GJREC-PREM-AMT        TO    C-Z-B-CAN-DB                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-CAN-DB-HE                  
               ADD LIFE-TOT              TO    C-Z-B-CAN-DB-LI                  
               GO TO ADD-PREM-DEBT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-USA-CODE THEN              
               ADD GJREC-PREM-AMT        TO    C-Z-B-USA-DB                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-USA-DB-HE                  
               ADD LIFE-TOT              TO    C-Z-B-USA-DB-LI                  
               GO TO ADD-PREM-DEBT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-JAM-CODE THEN              
               ADD GJREC-PREM-AMT        TO    C-Z-B-JAM-DB                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-JAM-DB-HE                  
               ADD LIFE-TOT              TO    C-Z-B-JAM-DB-LI                  
               GO TO ADD-PREM-DEBT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-BAH-CODE THEN              
               ADD GJREC-PREM-AMT        TO    C-Z-B-BAH-DB                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-BAH-DB-HE                  
               ADD LIFE-TOT              TO    C-Z-B-BAH-DB-LI                  
               GO TO ADD-PREM-DEBT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-BER-CODE                   
               ADD GJREC-PREM-AMT        TO    C-Z-B-BER-DB                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-BER-DB-HE                  
               ADD LIFE-TOT              TO    C-Z-B-BER-DB-LI                  
               GO TO ADD-PREM-DEBT-EXIT.                                        
           ADD GJREC-PREM-AMT TO C-Z-B-OTH-DB.                                  
           PERFORM CHK-GL-CODES          THRU  GL-EXIT.                         
           ADD HEALTH-TOT                TO    C-Z-B-OTH-DB-HE.                 
           ADD LIFE-TOT                  TO    C-Z-B-OTH-DB-LI.                 
       ADD-PREM-DEBT-EXIT.                                                      
           EXIT.                                                                
                                                                                
       ADD-PREM-TO-CRDT-CTRY.                                                   
           IF  GJREC-FIRST-YR-COMM IS EQUAL TO '1'                              
           OR  GJREC-PAY-TYPE IS EQUAL   TO   'C'                               
               GO TO ADD-PREM-CRDT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-CAN-CODE                   
               ADD GJREC-PREM-AMT        TO    C-Z-B-CAN-CR                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-CAN-CR-HE                  
               ADD LIFE-TOT              TO    C-Z-B-CAN-CR-LI                  
               GO TO ADD-PREM-CRDT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-USA-CODE                   
               ADD GJREC-PREM-AMT        TO    C-Z-B-USA-CR                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-USA-CR-HE                  
               ADD LIFE-TOT              TO    C-Z-B-USA-CR-LI                  
               GO TO ADD-PREM-CRDT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-JAM-CODE                   
               ADD GJREC-PREM-AMT        TO    C-Z-B-JAM-CR                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-JAM-CR-HE                  
               ADD LIFE-TOT              TO    C-Z-B-JAM-CR-LI                  
               GO TO ADD-PREM-CRDT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-BAH-CODE                   
               ADD GJREC-PREM-AMT        TO    C-Z-B-BAH-CR                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-BAH-CR-HE                  
               ADD LIFE-TOT              TO    C-Z-B-BAH-CR-LI                  
               GO TO ADD-PREM-CRDT-EXIT.                                        
           IF  GJREC-COUNTRY IS EQUAL    TO    C-Z-B-BER-CODE                   
               ADD GJREC-PREM-AMT        TO    C-Z-B-BER-CR                     
               PERFORM CHK-GL-CODES      THRU  GL-EXIT                          
               ADD HEALTH-TOT            TO    C-Z-B-BER-CR-HE                  
               ADD LIFE-TOT              TO    C-Z-B-BER-CR-LI                  
               GO TO ADD-PREM-CRDT-EXIT.                                        
           ADD GJREC-PREM-AMT            TO    C-Z-B-OTH-CR.                    
           PERFORM CHK-GL-CODES          THRU  GL-EXIT                          
           ADD HEALTH-TOT                TO    C-Z-B-OTH-CR-HE.                 
           ADD LIFE-TOT                  TO    C-Z-B-OTH-CR-LI.                 
       ADD-PREM-CRDT-EXIT.                                                      
           EXIT.                                                                
                                                                                
       CHK-GL-CODES.                                                            
           MOVE +0                       TO    HEALTH-TOT                       
           MOVE +0                       TO    LIFE-TOT                         
           IF  P-A-REC-G-L-POSITION-1    =    '1'                               
               ADD  GJREC-PREM-AMT       TO    LIFE-TOT.                        
           IF  P-A-REC-G-L-POSITION-1    =    '9'                               
               ADD  GJREC-PREM-AMT       TO    HEALTH-TOT.                      
       GL-EXIT.                                                                 
           EXIT.                                                                
                                                                                
      *** E N D  O F  J O B  R O U T I N E S ****                               
                                                                                
       EOJ-RTN.                                                                 
           MOVE +4 TO TAPE-RETURN.                                              
           CALL  'DLSWRITE' USING TAPE-SYS015                                   
                                  TAPE-RETURN                                   
                                  GROUP-OUT-BAL-RECORD                          
                                  TAPE-RSIZ15                                   
                                  TAPE-BSIZ15                                   
                                  TAPE-FRMT15                                   
                                  TAPE-CNTR15.                                  
           MOVE +0 TO TAPE-RETURN.                                              
           IF  TAPE-CNTR15 IS NOT EQUAL +0 THEN                                 
               MOVE +0 TO TAPE-CNTR15                                           
               MOVE +0 TO GOB-PAGE-COUNT                                        
               COMPUTE LINE-COUNT = MAX-LINES + +1                              
           ELSE                                                                 
                GO TO COUNTRY-ZERO-BAL-RTN.                                     
                                                                                
      *** GROUP OUT OF BALANCE LIST ROUTINE ****                                
                                                                                
       GROUP-OUT-OF-BAL-RTN.                                                    
           IF  LINE-COUNT IS GREATER THAN MAX-LINES THEN                        
               PERFORM GOB-HEAD-RTN THRU                                        
                       GOB-HD-RTN-EXIT.                                         
           CALL  'DLSREAD' USING TAPE-SYS015                                    
                                 TAPE-RETURN                                    
                                 GROUP-OUT-BAL-RECORD                           
                                 TAPE-RSIZ15                                    
                                 TAPE-BSIZ15                                    
                                 TAPE-FRMT15                                    
                                 TAPE-CNTR15.                                   
           IF  TAPE-RETURN IS NOT EQUAL TO +0 THEN                              
               GO TO GOB-TOTAL-RTN.                                             
           MOVE  GOB-GROUP TO P-GOB-GROUP.                                      
           MOVE  GOB-ACCT TO P-GOB-ACCT.                                        
           MOVE  GOB-AMT TO P-GOB-AMT.                                          
           ADD GOB-AMT TO G-O-B-AMT-TOT.                                        
           IF  GOB-AMT IS GREATER THAN +0 THEN                                  
               MOVE 'DB' TO P-GOB-DB                                            
           ELSE                                                                 
               MOVE 'CR' TO P-GOB-DB.                                           
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE SPACE TO PRT-LINE.                                              
           GO TO GROUP-OUT-OF-BAL-RTN.                                          
       GOB-TOTAL-RTN.                                                           
           MOVE 'TOTAL' TO P-GOB-TOT-WD.                                        
           MOVE G-O-B-AMT-TOT TO P-GOB-AMT.                                     
           IF  G-O-B-AMT-TOT IS GREATER THAN +0 THEN                            
               MOVE 'DB' TO P-GOB-DB.                                           
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
                                                                                
      *** COUNTRY ZERO BALANCE LIST ROUTINE ****                                
                                                                                
       COUNTRY-ZERO-BAL-RTN.                                                    
           PERFORM  CZB-HEAD-RTN THRU                                           
                    CZB-HD-EXIT.                                                
       COUNTRY-ZERO-BAL-PRINT.                                                  
           MOVE C-Z-B-CTRY-NME        (C-Z-B-SUB) TO P-CZB-CTRY-NME.            
           MOVE C-Z-B-CTRY-AMT-DB     (C-Z-B-SUB) TO P-CZB-DB-AMT.              
           MOVE C-Z-B-CTRY-AMT-CR     (C-Z-B-SUB) TO P-CZB-CR-AMT.              
           MOVE C-Z-B-CTRY-AMT-DB-LI  (C-Z-B-SUB) TO P-CZB-DB-AMT-LI.           
           MOVE C-Z-B-CTRY-AMT-CR-LI  (C-Z-B-SUB) TO P-CZB-CR-AMT-LI.           
           MOVE C-Z-B-CTRY-AMT-DB-HE  (C-Z-B-SUB) TO P-CZB-DB-AMT-HE.           
           MOVE C-Z-B-CTRY-AMT-CR-HE  (C-Z-B-SUB) TO P-CZB-CR-AMT-HE.           
           ADD  C-Z-B-CTRY-AMT-DB     (C-Z-B-SUB) TO C-Z-B-TOT-DB.              
           ADD  C-Z-B-CTRY-AMT-CR     (C-Z-B-SUB) TO C-Z-B-TOT-CR.              
           ADD  C-Z-B-CTRY-AMT-DB-LI  (C-Z-B-SUB) TO C-Z-B-TOT-DB-LI.           
           ADD  C-Z-B-CTRY-AMT-CR-LI  (C-Z-B-SUB) TO C-Z-B-TOT-CR-LI.           
           ADD  C-Z-B-CTRY-AMT-DB-HE  (C-Z-B-SUB) TO C-Z-B-TOT-DB-HE.           
           ADD  C-Z-B-CTRY-AMT-CR-HE  (C-Z-B-SUB) TO C-Z-B-TOT-CR-HE.           
           ADD  C-Z-B-CTRY-AMT-DB     (C-Z-B-SUB) TO                            
                C-Z-B-CTRY-AMT-CR     (C-Z-B-SUB).                              
           IF  C-Z-B-CTRY-AMT-CR (C-Z-B-SUB) NOT  EQUAL +0                      
               MOVE '***'                         TO P-CZB-TOT-OUT-BAL.         
           PERFORM PRINT-IT                       THRU PR-EXIT1.                
           MOVE '   '                             TO P-CZB-TOT-OUT-BAL.         
           ADD +1 TO C-Z-B-SUB.                                                 
           IF  C-Z-B-SUB    NOT GREATER           THAN C-Z-B-NO-ENT             
               GO TO COUNTRY-ZERO-BAL-PRINT.                                    
           MOVE 'TOTAL'                           TO P-CZB-TOTAL-WD.            
           MOVE C-Z-B-TOT-DB                      TO P-CZB-DB-AMT.              
           MOVE C-Z-B-TOT-CR                      TO P-CZB-CR-AMT.              
           MOVE C-Z-B-TOT-DB-LI                   TO P-CZB-DB-AMT-LI.           
           MOVE C-Z-B-TOT-CR-LI                   TO P-CZB-CR-AMT-LI.           
           MOVE C-Z-B-TOT-DB-HE                   TO P-CZB-DB-AMT-HE.           
           MOVE C-Z-B-TOT-CR-HE                   TO P-CZB-CR-AMT-HE.           
           ADD  C-Z-B-TOT-DB                      TO C-Z-B-TOT-CR.              
           IF  C-Z-B-TOT-CR    NOT                EQUAL +0                      
               MOVE '***'                         TO P-CZB-TOT-OUT-BAL.         
           PERFORM PRINT-IT                       THRU PR-EXIT1.                
           PERFORM TITLE-END-RTN                  THRU TITL-END-EXIT.           
       EOJ-RTN-EXIT.                                                            
           EXIT.                                                                
                                                                                
      *** TITLE AND HEADING ROUTINES ****                                       
                                                                                
       TITLE-END-RTN.                                                           
           MOVE +1 TO LINE-COUNT.                                               
           ADD  +1 TO PAGE-CTR22.                                               
           MOVE PAGE-CTR22 TO HD-PAGE.                                          
           MOVE TITL-END0 TO PRINT-LINE.                                        
           MOVE HD-DT-PAGE-AREA TO P-HD-DT-PAGE.                                
           MOVE '1' TO CC.                                                      
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE SPACES TO PRINT-LINE.                                           
           MOVE '-' TO CC.                                                      
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1 5 TIMES.                                            
           IF  PREV-CTL-FLD IS NOT EQUAL TO LOW-VALUE THEN                      
               MOVE TITL-END1 TO PRINT-LINE                                     
           ELSE                                                                 
               MOVE '0' TO CC.                                                  
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE TITL-END2 TO PRINT-LINE                                         
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE TITL-END3 TO PRINT-LINE                                         
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE TITL-END4 TO PRINT-LINE                                         
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE TITL-END5 TO PRINT-LINE                                         
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
       TITL-END-EXIT.                                                           
           EXIT.                                                                
                                                                                
       P-A-HEAD-RTN.                                                            
           MOVE +1 TO LINE-COUNT.                                               
           ADD  +1 TO PAGE-CTR22.                                               
           MOVE PAGE-CTR22 TO HD-PAGE.                                          
           MOVE P-A-HEAD1 TO PRINT-LINE.                                        
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1                                                     
           MOVE P-A-HEAD2 TO PRINT-LINE.                                        
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1                                                     
           MOVE P-A-HEAD3 TO PRINT-LINE.                                        
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT2.                                                    
           MOVE '0' TO CC.                                                      
           IF  PREV-CTL-FLD NOT = LOW-VALUES AND                                
               C-REC-TYPE = P-REC-TYPE                                          
               MOVE C-GROUP    TO P-PA-GROUP                                    
               MOVE C-ACCT     TO P-PA-ACCT.                                    
       P-A-HD-EXIT.                                                             
           EXIT.                                                                
                                                                                
       GOB-HEAD-RTN.                                                            
           MOVE +3 TO LINE-COUNT.                                               
           MOVE GRP-OUT-BAL-HD1 TO PRINT-LINE.                                  
           ADD +1 TO GOB-PAGE-COUNT.                                            
           MOVE GOB-PAGE-COUNT TO HD-PAGE.                                      
           MOVE HD-DT-PAGE-AREA TO P-HD-DT-PAGE.                                
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE GRP-OUT-BAL-HD2 TO PRINT-LINE.                                  
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT2.                                                    
           MOVE '0' TO CC.                                                      
       GOB-HD-RTN-EXIT.                                                         
           EXIT.                                                                
                                                                                
       CZB-HEAD-RTN.                                                            
           MOVE +1 TO LINE-COUNT.                                               
           ADD +1 TO CZB-PAGE-COUNT.                                            
           MOVE CZB-PAGE-COUNT TO HD-PAGE.                                      
           MOVE CTRY-ZERO-BAL-HD1 TO PRINT-LINE.                                
           MOVE HD-DT-PAGE-AREA TO P-HD-DT-PAGE.                                
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT1.                                                    
           MOVE CTRY-ZERO-BAL-HD2 TO PRINT-LINE.                                
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT2.                                                    
           MOVE CTRY-ZERO-BAL-HD3 TO PRINT-LINE.                                
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT2.                                                    
           MOVE SPACES            TO PRINT-LINE.                                
           PERFORM PRINT-IT THRU                                                
                   PR-EXIT2.                                                    
           MOVE '0' TO CC.                                                      
       CZB-HD-EXIT.                                                             
           EXIT.                                                                
                                                                                
      *** I/O SUBROUTINES AND QDATE CONVERT SUBROUTINE ****                     
                                                                                
       PRINT-IT.                                                                
           IF  CC IS EQUAL TO '0' THEN                                          
               ADD +2 TO LINE-COUNT                                             
           ELSE                                                                 
               ADD +1 TO LINE-COUNT.                                            
           CALL  'DLSWRITE' USING PRINT-SYS029                                  
                                  PRINT-RETURN22                                
                                  PRINT-LINE                                    
                                  PRINT-RECSIZE                                 
                                  PRINT-BLKSIZE                                 
                                  PRINT-FORMATT                                 
                                  PRINT-COUNTER22.                              
       PR-EXIT1.                                                                
           EXIT.                                                                
                                                                                
       PR-SPACE.                                                                
           MOVE SPACE TO PRINT-LINE.                                            
       PR-EXIT2.                                                                
           EXIT.                                                                
                                                                                
       PR-PA-HEADING.                                                           
           IF  MAX-LINES IS NOT GREATER THAN LINE-COUNT THEN                    
               PERFORM P-A-HEAD-RTN THRU                                        
                       P-A-HD-EXIT.                                             
       PR-EXIT.                                                                 
           EXIT.                                                                
                                                                                
       WRITE-GRP-OUT-BAL-REC.                                                   
           MOVE  P-GROUP-ACCT TO GOB-GROUP-ACCT.                                
           CALL  'DLSWRITE' USING TAPE-SYS015                                   
                                  TAPE-RETURN                                   
                                  GROUP-OUT-BAL-RECORD                          
                                  TAPE-RSIZ15                                   
                                  TAPE-BSIZ15                                   
                                  TAPE-FRMT15                                   
                                  TAPE-CNTR15.                                  
       W-GOB-EXIT.                                                              
           EXIT.                                                                
                                                                                
       CONVERT-DATE.                                                            
           CALL  'QDATE' USING QDATE-FUNCT                                      
                               ALIS-DATE                                        
                               CONV-DATE.                                       
           IF  CONV-DATE IS EQUAL TO '*******' OR ALIS-YEAR = ZERO              
               MOVE SPACES TO CONV-DATE.                                        
       CONV-DATE-EXIT.                                                          
           EXIT.                                                                
