       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
      *========================                                                 
                                                                                
FXXTOK PROGRAM-ID.     GC2RAD.                                                  
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
                                                                                
      **************************************************************            
      *PROGRAM OVERVIEW: TITLE - GWCOCRAD                                       
      *                                                                         
      *                 DESCRIPTION - ADVANCES COMMISSION, SALES                
      *                 CREDITS AND NAPS IN THE RENEWAL YEAR.                   
      *                                                                         
      *                 CALLING PROGRAM(S): NONE                                
      *                                                                         
      *                 CALLED PROGRAM(S): NONE                                 
      *                                                                         
      *                 INPUTS: COMMISSION DATABASE                             
      *                                                                         
      *                 OUTPUTS: COMMISSION DATABASE                            
      **************************************************************            
      *HISTORY:                                                                 
      *  DATE       PROGRAMMER             CHANGES                              
      *  AUG 10/86  HAMPTON    SPECS CONTAINED IN TGW.COMM.SCRIPT               
      *  OCT 31/86  HAMPTON    TO LOOK FOR FY AGENT START DATE AS               
      *                        BEING THE 1ST OF THE MONTH IF THE                
      *                        ACCOUNT EFFECTIVE IS NOT THE FIRST OF            
      *                        THE MONTH.                                       
      *  JAN 26/87  HAMPTON    TO WRITE MESSAGES TO A FILE TO BE SORTED         
      *                        INSTEAD OF PRINTING A REPORT.                    
      *                        TO ADD A MESSAGE IF THE TOTAL NUMBER OF          
      *                        MONTHS ADVANCED IS NOT EQUAL TO 12.              
      *                        DELETE 'NOT RECONCILED' MESSAGE.                 
      *                        PRINT 'NO RENEWAL PREMIUM RECEIVED' MSG          
      *                        ONLY IF 90 DAYS PAST THE RENEWAL DATE.           
      *                        REMOVE INCONSISTENCY MESSAGE IF AGENT HAS        
      *                        A SPLIT BUT THERE IS NO PREMIUM FOR THAT         
      *                        COVERAGE.                                        
      *                        PUT BRACKETS AROUND COMM-IND = 'G' OR 'X'        
      *                        OR 'Z' IN AGENT LOOKUP.                          
      *  FEB 25/87  HAMPTON    TO WRITE OUT A GWCORADVPSM RECORD EVEN           
      *                        THOUGH ALL AGENTS ARE ON A 'NO'                  
      *                        COMMISSION INDICATOR.                            
      *                        CHANGE AGENT TABLES IN WORKING STORAGE           
      *                        TO ACCEPT 2 DECIMAL PLACES FOR THE AGENT         
      *                        SPLIT.                                           
      *                        WRITE AN ERROR MESSAGE IF A RENEWAL              
      *                        PREMIUM IS A NEGATIVE VALUE. THIS SHOULD         
      *                        NEVER OCCUR.                                     
      *  JUL 28/87  HAMPTON    TO PUT IN RUN DATE LOGIC                         
      *             WAGLER                                                      
      *  AUG 10/87  HAMPTON    TO ADD GCRL CODE 121                             
      *  DEC 02/87  HAMPTON    TO FIX UPDATING OF ADVPSM FOR SHORT FY           
      *  DEC 03/87  HAMPTON    TO HANDLE NON-ANNUALIZED AGENTS                  
      *  AUG 16/89  SCHLEICHER MOVE BRANCH TO GFO FIELD IF A BROKER             
      *                        SOLD AN ALPHA CASE                               
      *  DEC/89     BURTON     RECOMPILED TO PICK UP NEW VERSION OF             
      *                        GNUMONIC                                         
      *  DEC/89     PRANGE     GCRL-MAN NOW SET USING 7TH DIGIT OF              
      *                        FOGL CODE.                                       
      **************************************************************            
      *                  COMMISSION RELEASE                                     
      **************************************************************            
      *  JUN 11/90  SCHLEICHER CHANGED COMMISSION RELEASE RECORD TO             
      *                        AGENCY SPECIFICATIONS                            
      *                                                                         
      *  AUG 90     M BURTON   ADDED A PARM DATE CARD TO FACILITATE             
      *                        TESTING OF THE COMMISSION SYSTEM                 
      *                        FORMAT IS PARM='DD/MM/YY'                        
      *                                                                         
      *  SEP 90     A NIKELSKI EXCLUDED WRITTING AN EXTRACT FOR                 
      *                        GWCOCRAR IF                                      
      *                        -AGENT ON GIPSY HAS A COMMISSION                 
      *                         INDICATOR OF 'S' (SERVICE FEE) OR               
      *                         'N' (NO COMMISSION) -                           
      *                        -GROUP NOT ON GIPSY MASTER AND LAST              
      *                         RECON. DATE IS OLDER THAN 1 YEAR                
      *                        -GROUP IS TERMINATED                             
      *                                                                         
      * 11OCT90     A NIKELSKI - CHANGE INCREMENTATION OF GCRL-VLNO             
      *                        - IF 2 AGENTS ARE SERVING THE GROUP              
      *                          MAKE SURE YOU SENT THE ENTIRE PREM AMT         
      *                        - CHANGE GCRL-SCALE AND GCRL-CODE                
      *                                                                         
      *   OCT90     A NIKELSKI - INITIALIZE VALUES IN GCRL-CODE                 
      *                        - CHANGE LTD RATE AND REG RATE                   
      *                          (PRODUCTION PROBLEM INCORRECT                  
      *                           SUBSCRIPT)                                    
      *                        - ADDED VAR-SUB FOR SUBSCRIPTING                 
      *                                                                         
      *  NOV/90     M PRANGE   - VARIOUS LOGIC THAT USES GGINEXT-ANNIV          
      *                          DATE MUST NOW USE PSMNXT-RENEWAL DATE.         
      *                                                                         
      *  APR/92     A LEE      - CHANGES TO READ AND CALC COMMISSIONS           
      *                          USING VSAM COMMISSION SCALE TABLE              
      *                          FILE                                           
      *                                                                         
      *****************************************************************         
      *                  SALE CREDIT RELEASE                          *         
      ******************************************************************        
      *  11MAY92 - NIKELSKI - CHANGES TO READ SALE CREDIT RATES USING  *        
      *                       VSAM SALES CREDIT TABLE FILE             *        
      *                     - REMOVED EDIT NOT TO WRITE AN EXTRACT FOR *        
      *                       GWCOCRAR IF THE AGENT ON GIPSY HAS A     *        
      *                       COMMISSION INDICATOR OF 'S' (SERVICE FEE)*        
      *                       OR 'N' (NO COMMISSION)                   *        
      ******************************************************************        
      *  20DEC94 - NIKELSKI - TRACK REQUEST #99                        *        
      *                       IF A GROUP CAN NOT BE FOUND ON GIPSY AND *        
      *                       THE LAST RECON DATE IS OLDER THAN 1 YEAR *        
      *                       DO NOT PRINT GROUP ON REPORT             *        
      ******************************************************************        
      * 03APR97 - TRACK REQUEST                                        *        
      *                       IF THE GROUP IS A NAL GROUP AND NOT IN   *        
      *                       ITS FIRST YEAR THEN SET THE FY MONTHS TO *        
      *                       ZERO                                     *        
      ******************************************************************        
      * 13JUN98 - ALPHA-CC PROJECT. G. WRIGHT                          *        
      *                       COMMISSION FEED ALWAYS TO HAVE RGO IN    *        
      *                       GCRL-BRANCH FIELD (REMOVE FOGL CODE      *        
      *                       OVERRIDES TO THIS)                       *        
      ******************************************************************        
      * 25AUG98 - FIX SOC07 DUE TO WS-FY-MONTHS NOT BEING INITIALIZED  *        
      ******************************************************************        
      * 25MAY00 - FIX DIVIDE BY ZERO ABENDS WHEN PREMIUM AMOUNTS ARE 0 *        
      ******************************************************************        
      *                                                                *        
      *    JUL/2005  R. KNAUD.                                         *        
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)         *        
      *                  CHANGE THE GMASTER IDMS READ TO:              *        
      *                      USE VOGPWRA7 TO READ THE VCM AND          *        
      *                      GIPSY MASTER FILES.                       *        
      *                                                                *        
      *         - HUB:  COMM PSMASTER ROUTER (VOCOMM VOPSM/PSM)        *        
      *                  CHANGE THE PSMASTER IDMS READ TO:             *        
      *                  READ THE VO PSMASTER FIRST (USING GAEDATSR)   *        
      *                  AND IF THE REQUIRED RECORD IS NOT THERE,      *        
      *                  READ THE PSMASTER (USING GACCDMA7).           *        
      *                                                                *        
      *                                                                         
      *    OCT/08 IBM                                                           
      *         - ENTERPRISE COMPILER UPGRADE                                   
      ******************************************************************        
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCRAD          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
           03  FILLER                   PIC X(30).                              
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  VOGPWRA7                 PIC X(8) VALUE 'VOGPWRA7'.              
           05  GAEDATSR                 PIC X(8) VALUE 'GAEDATSR'.              
           05  GC2DATE                  PIC X(8) VALUE 'GC2DATE'.               
           05  GC2PB2                   PIC X(8) VALUE 'GC2PB2'.                
           05  GC2LCOMM                 PIC X(8) VALUE 'GC2LCOMM'.              
           05  GC2LCALC                 PIC X(8) VALUE 'GC2LCALC'.              
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------                           
      *  VO PS MASTER                                                           
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
             ' **** VO PS MASTER  ****    '.                                    
           COPY VOPSMAST.                                                       
      *----------------------------------------------                           
      *   PSMASTER                                                              
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
FXXTOK       ' **** PSMASTE7  ****    '.                                        
      * PSMASTE7                                                                
CPYNME     COPY PSMASTE7.                                                       
                                                                                
       01  GPSY-GROUP-ACCOUNT.                                                  
REN        05  GPSY-GROUP                          PIC 9(7).                    
           05  GPSY-ACCOUNT                        PIC X(3).                    
       01  VAR-SUB VALUE +0                        PIC S9(3) COMP-3.            
       01  WS-SUB                                  PIC S9(3) COMP-3.            
       01  WS-PERCENT                              PIC S9(6)V9(5).              
       01  WS-PERCENT-01 REDEFINES WS-PERCENT.                                  
           05  FILLER                             PIC S9(6)V.                   
           05  WS-PER-1                           PIC 9.                        
           05  WS-PER-2                           PIC 9.                        
           05  WS-PER-3                           PIC 9.                        
           05  WS-PER-4                           PIC 9.                        
           05  WS-PER-5                           PIC 9.                        
       01  WS-BEGINS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2RAD W-S STARTS HERE **'.                                  
       01  WS-PARAMETERS.                                                       
           05  WS-TOTAL-GROUPS-OUTST      PIC S9(5) COMP-3 VALUE ZERO.          
           05  WS-TOTAL-GROUPS-PROCESSED  PIC S9(5) COMP-3 VALUE ZERO.          
           05  QDATE-FORMATAB    VALUE 'AB'  PIC XX.                            
           05  QDATE-FORMATBA    VALUE 'BA'  PIC XX.                            
           05  QDATE-FORMATCB    VALUE 'CB'  PIC XX.                            
           05  QDATE-FORMATCA    VALUE 'CA'  PIC XX.                            
           05  QDATE-FORMATCD    VALUE 'CD'  PIC XX.                            
REN        05  WS-GROUP-NUMBER               PIC X(7).                          
           05  FILLER  REDEFINES WS-GROUP-NUMBER.                               
REN            10  WS-NUM-GROUP-NUMBER       PIC 9(7).                          
REN        05  WS-GROUP-NUM                  PIC X(7).                          
           05  FILLER  REDEFINES WS-GROUP-NUM.                                  
REN            10  WS-NUM-GROUP-NUM          PIC 9(7).                          
           05  WS-AGT-RATE                   PIC S9(3)V9(5) COMP-3.             
           05  WS-POLICY-YEAR                PIC S9(3)     COMP-3.              
           05  WS-MONTHS-ADVANCED            PIC S9(5)     COMP-3.              
           05  WS-FY-MONTHS                  PIC S9(5)     COMP-3.              
           05  WS-FY-MONTHS-REMAINING        PIC S9(5)     COMP-3.              
           05  WS-RN-MONTHS                  PIC S9(5)     COMP-3.              
           05  WS-SAVE-RN-MONTHS             PIC S9(5)     COMP-3.              
           05  WS-TOTAL-MONTHS-ADVANCED      PIC S9(5)     COMP-3.              
           05  WS-PREM-LIFE                  PIC S9(9)V99  COMP-3.              
           05  WS-PREM-LTD                   PIC S9(9)V99  COMP-3.              
           05  WS-PREM-A-S                   PIC S9(9)V99  COMP-3.              
           05  WS-ANN-PREM-LIFE              PIC S9(9)V99  COMP-3.              
           05  WS-ANN-PREM-LTD               PIC S9(9)V99  COMP-3.              
           05  WS-ANN-PREM-A-S               PIC S9(9)V99  COMP-3.              
           05  WS-ANN-PREM-LIFE-SC           PIC S9(9)V99  COMP-3.              
           05  WS-ANN-PREM-LTD-SC            PIC S9(9)V99  COMP-3.              
           05  WS-ANN-PREM-A-S-SC            PIC S9(9)V99  COMP-3.              
           05  WS-ANN-PREM-NAP               PIC S9(9)V99  COMP-3.              
           05  WS-COMM-LIFE                  PIC S9(9)V99  COMP-3.              
           05  WS-COMM-LTD                   PIC S9(9)V99  COMP-3.              
           05  WS-COMM-A-S                   PIC S9(9)V99  COMP-3.              
           05  WS-SC-LIFE                    PIC S9(9)V99  COMP-3.              
           05  WS-SC-LTD                     PIC S9(9)V99  COMP-3.              
           05  WS-SC-A-S                     PIC S9(9)V99  COMP-3.              
           05  WS-AGT-NAP                    PIC S9(9)     COMP-3.              
           05  WS-AGT-SC                     PIC S9(9)     COMP-3.              
           05  WS-TOTAL-PREM-ALL             PIC S9(9)V99  COMP-3.              
           05  WS-TOTAL-PREM-LIFE-A-S        PIC S9(9)V99  COMP-3.              
           05  WS-TOTAL-PREM-LTD             PIC S9(9)V99  COMP-3.              
           05  WS-TOTAL-PREM-ALL-SC          PIC S9(9)V99  COMP-3.              
           05  WS-PSM-PREM-ADV               PIC S9(9)V99  COMP-3.              
           05  WS-AGT-INDEX                  PIC S9(4)     COMP.                
           05  WS-SEG-INDEX                  PIC S9(4)     COMP.                
           05  WS-FY-AGT-INDEX               PIC S9(4)     COMP.                
           05  WS-RN-AGT-INDEX               PIC S9(4)     COMP.                
           05  WS-FY-AGT-COUNT               PIC S9        COMP-3.              
           05  WS-RN-AGT-COUNT               PIC S9        COMP-3.              
           05  WS-REG-SCALE                  PIC X(3).                          
           05  WS-LTD-SCALE                  PIC X(3).                          
           05  WS-SKIP-GROUP                 PIC X.                             
           05  WS-SAVE-FY-REG-SCALE          PIC X(3).                          
           05  WS-SAVE-FY-LTD-SCALE          PIC X(3).                          
           05  WS-SAVE-RN-REG-SCALE          PIC X(3).                          
           05  WS-SAVE-RN-LTD-SCALE          PIC X(3).                          
           05  WS-LIFE-PERCENT-SWITCH        PIC X.                             
           05  WS-LTD-PERCENT-SWITCH         PIC X.                             
           05  WS-A-S-PERCENT-SWITCH         PIC X.                             
           05  WS-FLAT-CALC-SWITCH           PIC X.                             
               88  FLAT-RATE-CALC       VALUE 'Y'.                              
           05  WS-ERROR-SWITCH               PIC X.                             
               88  ERROR-SWITCH-ON      VALUE 'Y'.                              
               88  ERROR-SWITCH-OFF     VALUE 'N'.                              
           05  WS-ERROR-NUMBER               PIC S9(4)     COMP.                
           05  WS-ALIS-RUN-DATE.                                                
               10  WS-ALIS-RUN-YEAR          PIC S9(3)     COMP-3.              
               10  WS-ALIS-RUN-DAY           PIC S9(3)     COMP-3.              
           05  WS-ALIS-PREM-DATE.                                               
               10  WS-ALIS-PREM-DD           PIC  9(2).                         
               10  WS-ALIS-PREM-MM           PIC  9(2).                         
               10  WS-ALIS-PREM-YY           PIC  9(2).                         
           05  WS-ALIS-PREM2-CCYY.                                              
               10  WS-ALIS-PREM2-CC          PIC 9(2).                          
               10  WS-ALIS-PREM2-YY          PIC 9(2).                          
           05  ALIS-CURR-DATE.                                                  
               10  ALIS-CURR-YEAR            PIC S9(3)     COMP-3.              
               10  ALIS-CURR-DAY             PIC S9(3)     COMP-3.              
           05  ALIS-CURR-DATE-MINUS-1-YEAR.                                     
               10  ALIS-YEAR                 PIC S9(3)     COMP-3.              
               10  ALIS-DAY                  PIC S9(3)     COMP-3.              
           05  WS-CURRENT-DATE.                                                 
               10  WS-CURRENT-DAY            PIC 99.                            
               10  FILLER                    PIC X.                             
               10  WS-CURRENT-MONTH          PIC 99.                            
               10  FILLER                    PIC X.                             
               10  WS-CURRENT-YEAR           PIC 99.                            
           05  WS-CURR-DATE.                                                    
               10  WS-CURR-DAY               PIC 99.                            
               10  WS-CURR-MONTH             PIC 99.                            
               10  WS-CURR-YEAR              PIC 99.                            
           05  WS-RENEW-DATE.                                                   
               10  WS-RENEW-YEAR             PIC S9(3)     COMP-3.              
               10  WS-RENEW-DAY              PIC S9(3)     COMP-3.              
           05  WS-FY-STOP-DATE.                                                 
               10  WS-FY-STOP-YR             PIC S9(3)     COMP-3.              
               10  WS-FY-STOP-DAY            PIC S9(3)     COMP-3.              
      *     EXPAND YEAR TO 4 AND RE-ARRANGE FOR YYYYMMDD FORMAT.        YEAR2000
           05  WS-NEXT-RENEW-DATE-EXT.                                          
               10  WS-NEXT-RENEW-YR-EXT      PIC 9999.                  YEAR2000
               10  WS-NEXT-RENEW-MO-EXT      PIC 99.                    YEAR2000
               10  WS-NEXT-RENEW-DAY-EXT     PIC 99.                    YEAR2000
           05  FILLER REDEFINES WS-NEXT-RENEW-DATE-EXT.                         
               10  WS-NEXT-RENEW-EXT-BYTE1   PIC X.                             
               10  FILLER                    PIC X(5).                          
           05  WS-LAST-RENEW-DATE-INT.                                          
               10  WS-LAST-RENEW-YR-INT      PIC S9(3)     COMP-3.              
               10  WS-LAST-RENEW-DAY-INT     PIC S9(3)     COMP-3.              
      *     EXPAND YEAR TO 4 AND RE-ARRANGE FOR YYYYMMDD FORMAT.        YEAR2000
           05  WS-ACCT-EFF-DATE-EXT.                                            
               10  WS-ACCT-EFF-YR-EXT        PIC 9999.                  YEAR2000
               10  WS-ACCT-EFF-MO-EXT        PIC 99.                    YEAR2000
               10  WS-ACCT-EFF-DAY-EXT       PIC 99.                    YEAR2000
           05  FILLER REDEFINES WS-ACCT-EFF-DATE-EXT.                           
               10  WS-ACCT-EFF-EXT-BYTE1     PIC X.                             
               10  FILLER                    PIC X(5).                          
      *     EXPAND YEAR TO 4 AND RE-ARRANGE FOR YYYYMMDD FORMAT.        YEAR2000
           05  WS-REN-EFF-DATE-EXT.                                             
               10  WS-REN-EFF-YR-EXT         PIC 9999.                  YEAR2000
               10  WS-REN-EFF-MO-EXT         PIC 99.                    YEAR2000
               10  WS-REN-EFF-DAY-EXT        PIC 99.                    YEAR2000
           05  FILLER REDEFINES WS-REN-EFF-DATE-EXT.                            
               10  WS-REN-EFF-EXT-BYTE1      PIC X.                             
               10  FILLER                    PIC X(5).                          
           05  WS-RENEWAL-DATE.                                                 
               10  WS-RENEWAL-YEAR           PIC 9(3).                          
               10  WS-RENEWAL-DAY            PIC 9(3).                          
           05  FILLER  REDEFINES WS-RENEWAL-DATE.                               
               10  FILLER                    PIC 9.                             
               10  WS-5DIG-RENEWAL-DATE      PIC 9(5).                          
           05  WS-AGT-START-DATE-EXT.                                           
               10  WS-AGT-START-DAY-EXT      PIC 99.                            
               10  WS-AGT-START-MO-EXT       PIC 99.                            
               10  WS-AGT-START-YR-EXT       PIC 99.                            
           05  WS-AGT-START-DATE-INT.                                           
               10  FILLER                    PIC S9(3)  COMP-3.                 
               10  FILLER                    PIC S9(3)  COMP-3.                 
           05  FILLER  REDEFINES WS-AGT-START-DATE-INT.                         
               10  WS-AGT-START-INT-BYTE1    PIC X.                             
               10  FILLER                    PIC X(3).                          
           05  WS-REN-TEST-DATE.                                                
               10  WS-REN-TEST-YEAR          PIC S9(3)  COMP-3.                 
               10  WS-REN-TEST-DAY           PIC S9(3)  COMP-3.                 
           05  WS-PSMNXT-RNEW-DATE.                                             
               10  WS-PSMNXT-RNEW-YEAR       PIC S9(3)  COMP-3.                 
               10  WS-PSMNXT-RNEW-DAY        PIC S9(3)  COMP-3.                 
           05  WS-FOGL-CODE.                                                    
               10  WS-FOGL-1-2               PIC XX.                            
               10  WS-FOGL-3-4               PIC XX.                            
               10  WS-FOGL-5-6               PIC XX.                            
               10  WS-FOGL-7                 PIC X.                             
               10  WS-FOGL-8                 PIC X.                             
               10  WS-FOGL-9                 PIC X.                             
               10  WS-FOGL-10                PIC X.                             
           05  TEMP-ACCOUNT.                                                    
               10  FILLER                    PIC X VALUE '-'.                   
               10  TEMP-ACCT                 PIC XXX.                           
           05  TEMP-FIND-CENTURY             PIC 999.                           
           05  TEMP-FIND-01 REDEFINES TEMP-FIND-CENTURY.                        
               10  TEMP-CENTURY              PIC 9.                             
               10  FILLER                    PIC 99.                            
           05  TEMP-DATE.                                                       
               10  TEMP-DD                   PIC 99.                            
               10  TEMP-MM                   PIC 99.                            
               10  TEMP-YY                   PIC 99.                            
           05  NAL-GROUP-IND                 PIC X.                             
               88 NAL-GROUP            VALUE 'Y'.                               
               88 NOT-NAL-GROUP        VALUE 'N'.                               
           05  GR-POL-YEAR                  PIC X.                              
               88 GR-NOT-FIRST-YR      VALUE 'N'.                               
               88 GR-FIRST-YR          VALUE 'Y'.                               
           05  WS-NALGR-NUM                  PIC 9(7).                          
           05  FILLER REDEFINES WS-NALGR-NUM.                                   
               10  WS-NALGR-NUM1             PIC 99.                            
               10  WS-NALGR-NUM2             PIC 9(5).                          
           05  LOW-DATE.                                                        
               10  LOW-YEAR  VALUE +0        PIC S9(3) COMP-3.                  
               10  LOW-DAY   VALUE +0        PIC S9(3) COMP-3.                  
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *-----------------------------                                            
      *          DATASERVER RECORDS                                             
      *-----------------------------                                            
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
       01  LOGICAL-RECORD-NAMES.                                                
           COPY HCSLRNAM.                                                       
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------------                     
      *          GIPSY ACCESS MODULE PARMS                                      
      *----------------------------------------------------                     
       01  GACCDMA7-PS-PARMS.                                                   
           05  GACCDMA7-PS-FUNC      PIC S9(4)    COMP   VALUE +18.             
REN        05  GACCDMA7-PS-GROUP     PIC S9(7)    COMP-3.                       
           05  GACCDMA7-PS-ACCT      PIC X(3).                                  
           05  GACCDMA7-PS-CERT      PIC S9(9)    COMP-3.                       
           05  GACCDMA7-PS-WORK      PIC X(9).                                  
       01  GACCDMA7-PS-RETURN        PIC X(3).                                  
           88  GACCDMA7-PS-RET-OK                 VALUE '   '.                  
           88  GACCDMA7-PS-EOF                    VALUE 'R01'.                  
           88  GACCDMA7-PS-NOT-FOUND              VALUE 'R01'.                  
           88  GACCDMA7-PS-DISK-ERROR             VALUE 'R03'.                  
           88  GACCDMA7-PS-FUNC-INVALID           VALUE 'R09'.                  
                                                                                
       01  GC2DATE-PARS.                                                YEAR2000
                                  COPY GARDATEP.                        YEAR2000
      /                                                                         
       01  TLUCOB-NAL-PARMS.                                                    
           05 WS-ERROR-CODE-N            PIC X(01) VALUE SPACES.                
              88  WS-FOUND-GROUP                   VALUE SPACE.                 
           05 WS-KEY-N.                                                         
              10 WS-KEY-GROUP-N          PIC 9(07) VALUE ZEROS.                 
           05 WS-RETURN-DATES-N.                                                
              10 WS-RET-CII-EFF-DATE-N   PIC X(08) VALUE SPACES.                
              10 WS-RET-CONV-DATE-N      PIC X(08) VALUE SPACES.                
                                                                                
       01  WS-TLU111                     PIC X(9)                               
                                             VALUE 'TABLE 111'.                 
       01  WS-TLU111-TABLE-NUM  COMP-3   PIC S9(3) VALUE +111.                  
       01  WS-TLU111-TABLE.                                                     
           COPY TLU111.                                                         
                                                                                
       01  INIT-CR-RECORD.                                                      
REN        05  FILLER               VALUE +316 COMP   PIC S9(4).        00008000
           05  FILLER               VALUE LOW-VALUES  PIC XX.           00009000
           05  FILLER               VALUE SPACES      PIC X.            00010000
           05  FILLER.                                                  00010100
REN            10  FILLER           VALUE +0 COMP-3   PIC S9(7).        00010200
               10  FILLER           VALUE SPACES      PIC X(3).         00010300
               10  FILLER           VALUE +0 COMP-3   PIC S9(6).        00010400
           05  FILLER               VALUE +0 COMP-3   PIC S9(3).        00011000
           05  FILLER               VALUE +0 COMP-3   PIC S9(15).       00012000
           05  FILLER               VALUE SPACES      PIC X(4).         00012000
           05  FILLER               VALUE +0 COMP-3   PIC S9(3).        00013000
           05  FILLER               VALUE +0          PIC S9(2).        00014000
           05  FILLER               VALUE +0          PIC S9.           00015000
           05  FILLER               VALUE +0 COMP-3   PIC S9(9).        00016000
           05  FILLER               VALUE +0 COMP-3   PIC S9(5).        00017000
           05  FILLER               VALUE +0 COMP-3   PIC S9(2).        00018000
           05  FILLER               VALUE +0 COMP-3   PIC S9(2).        00019000
           05  FILLER               VALUE +0          PIC S9.           00020000
           05  FILLER.                                                  00030000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
           05  FILLER               VALUE SPACES      PIC X(25).        00060000
           05  FILLER               VALUE +0 COMP-3   PIC S9(3).        00070000
           05  FILLER               VALUE +0 COMP-3   PIC S9(2).        00080000
           05  FILLER.                                                  00090000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
           05  FILLER               VALUE +0 COMP-3   PIC S9.           00100000
           05  FILLER               VALUE +0 COMP-3   PIC S9(5).        00110000
           05  FILLER               VALUE +0          PIC S9(2).        00120000
           05  FILLER               VALUE +0          PIC S9(2).        00130000
           05  FILLER               VALUE +0 COMP-3   PIC S9.           00140000
           05  FILLER               VALUE +0 COMP-3   PIC S9.           00150000
           05  FILLER               VALUE SPACES      PIC X(3).         00150000
           05  FILLER.                                                  00160000
               10  FILLER           VALUE  0 COMP-3   PIC 9.            00170000
               10  FILLER           VALUE  0 COMP-3   PIC 9(2).         00180000
           05  FILLER.                                                  00190000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
               10  FILLER           VALUE 0           PIC 99.           00040000
           05  FILLER               VALUE 0           PIC 9(10).        00200000
           05  FILLER               VALUE ZERO        PIC 9(16).        00201000
           05  FILLER               VALUE SPACES      PIC X(5).         00201000
           05  FILLER               VALUE 'G'         PIC X.            00220000
           05  FILLER          COMP-3.                                  00230000
               10  FILLER           VALUE +0          PIC S9(6).        00240000
               10  FILLER               VALUE +0      PIC S9(3).        00241000
               10  FILLER               VALUE  0      PIC 9(3).         00241000
               10  FILLER           VALUE +0          PIC S9(3).        00242000
               10  FILLER           VALUE +0          PIC S9(3)V99.     00243000
               10  FILLER           VALUE +0          PIC S9(5).        00244000
               10  FILLER           VALUE +0          PIC S9(3).        00245000
               10  FILLER           VALUE +0          PIC S9(5).        00244000
           05  FILLER.                                                  00250000
               10  FILLER           VALUE 10          PIC 99.           00250000
               10  FILLER.                                              00030000
                   15  FILLER           VALUE 0       PIC 99.           00040000
                   15  FILLER           VALUE 0       PIC 99.           00040000
                   15  FILLER           VALUE 0       PIC 99.           00040000
                   15  FILLER           VALUE 0       PIC 99.           00040000
               10  FILLER               VALUE 0 COMP-3 PIC 9(5).        00250000
               10  FILLER               VALUE 0        PIC 9.           00250000
           05  FILLER.                                                  00250000
               10  FILLER               VALUE 0        PIC 99.          00250000
               10  FILLER               VALUE 0 COMP-3 PIC 9(5).        00250000
               10  FILLER.                                              00030000
                   15  FILLER           VALUE 0        PIC 99.          00040000
                   15  FILLER           VALUE 0        PIC 99.          00040000
                   15  FILLER           VALUE 0        PIC 99.          00040000
                   15  FILLER           VALUE 0        PIC 99.          00040000
               10  FILLER.                                              00030000
                   15  FILLER           VALUE 0        PIC 99.          00040000
                   15  FILLER           VALUE 0        PIC 99.          00040000
                   15  FILLER           VALUE 0        PIC 99.          00040000
                   15  FILLER           VALUE 0        PIC 99.          00040000
           05  FILLER                   VALUE SPACES   PIC X(31).               
           05  FILLER.                                                  00250000
               10  FILLER             COMP-3 OCCURS 10 TIMES.           00260000
                   15  TEMP-1                          PIC S9(3).       00270000
                   15  TEMP-2                          PIC S9(11).      00280000
       01  FILLER                                      PIC X(100).              
      ***************************************************************           
      *   MESSAGES USED FOR THE ERROR LOGIC USING THE CALL TO WTL   *           
      ***************************************************************           
       01  WTL-AREA.                                                            
           05  WTL-FLAG                PIC X      VALUE 'B'.                    
           05  WTL-REPLY-YES           PIC XXX    VALUE 'YES'.                  
           05  WTL-REPLY-NO            PIC XXX    VALUE 'NO '.                  
           05  WTL-REPLY               PIC XXX    VALUE SPACES.                 
           05  WTL-REPLY-AREA          PIC X(10)  VALUE SPACES.                 
       01  WTL-MESSAGE-AREA.                                                    
           05  FILLER          COMP-3  PIC S9(3)  VALUE +121.                   
           05  FILLER                  PIC X      VALUE SPACES.                 
           05  WTL-MESSAGE             PIC X(120) VALUE SPACES.                 
       01  WTL-ERROR-MESSAGES.                                                  
           05  ERR-MESS1.                                                       
               10  FILLER                 PIC X(40) VALUE                       
                   '***  INVALID RUNDATE FORMAT         '.                      
           05  ERR-MESS2.                                                       
               10  FILLER                 PIC X(50)   VALUE                     
                   '***  INVALID RUNDATE - SEE RUN DOCUMENTATION'.              
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'WS-MSG-TABLE                    '.                                  
                                                                                
       01  WS-MSG-TABLE.                                                        
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'GIPSY POINT-IN-SCALE MASTER NOT FOUND'.                             
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'GIPSY MASTER NOT FOUND'.                                            
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'NO RENEWAL PREMIUMS AVAILABLE'.                                     
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'NEGATIVE PREMIUM AMOUNT. UNABLE TO ADVANCE.'.                       
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'NOT USED                 '.                                         
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'INCONSISTENCY BETWEEN LIFE PREMIUM AND AGENT''S PERCENT'.           
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'INCONSISTENCY BETWEEN LTD PREMIUM AND AGENT''S PERCENT'.            
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'INCONSISTENCY BETWEEN A&S PREMIUM AND AGENT''S PERCENT'.            
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'RENEWAL PREMIUM HAS INVALID COVERAGE TYPE'.                         
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'AGENT SEGMENTS ON GIPSY INCONSISTENT (FIRST YEAR)'.                 
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'FIRST YEAR AGENTS NOT ON SAME COMMISSION SCALE'.                    
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'AGENT SEGMENTS ON GIPSY INCONSISTENT (RENEWAL)'.                    
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'RENEWAL AGENTS NOT ON SAME COMMISSION SCALE'.                       
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'NOT USED                           '.                               
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'GIPSY ACCOUNT EFFECTIVE DATE INVALID'.                              
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'RENEWAL EFFECTIVE DATE INVALID'.                                    
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'GIPSY NEXT RENEWAL DATE INVALID'.                                   
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'NO ADVANCE POINT-IN-SCALE FOUND FOR FIRST YEAR CALCULATION'.        
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'CURRENCY ON COMMISSION RELEASE RECORD SET TO ZERO'.                 
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'FOGL-CODE ON COMMISSION RELEASE RECORD SET TO SPACES'.              
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'GCRL-CODE ON COMMISSION RELEASE RECORD SET TO ZERO'.                
           05  FILLER                        PIC X     VALUE '2'.               
           05  FILLER                        PIC X(100) VALUE                   
           'ACCOUNT NOT ACTIVE. NO COMPENSATION ADVANCED. RENEWAL ADVANC        
      -    'E INDICATOR SET TO "Y"'.                                            
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'NO AGENTS ON GIPSY TO RECEIVE COMPENSATION.'.                       
           05  FILLER                        PIC X     VALUE '2'.               
           05  FILLER                        PIC X(100) VALUE                   
           'UNABLE TO ADVANCE. 90 DAYS INTO RENEWAL YEAR. NO PREMIUM REC        
      -    'EIVED.'.                                                            
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'NOT USED'.                                                          
           05  FILLER                        PIC X     VALUE '1'.               
           05  FILLER                        PIC X(100) VALUE                   
           'ERROR IN CALCULATING FIRST YEAR AGENT START DATE.'.                 
                                                                                
       01  FILLER REDEFINES WS-MSG-TABLE.                                       
           05  FILLER    OCCURS 26 TIMES.                                       
               10  WS-EX-MSG-RPT-NO    PIC X.                                   
               10  WS-EX-MSG           PIC X(100).                              
                                                                                
       01  FILLER.                                                              
           05  WS-EX-MSG2-RPT-NO       PIC X   VALUE '1'.                       
           05  WS-EX-MSG2.                                                      
               10  FILLER              PIC X(48)      VALUE                     
               'UNABLE TO ADVANCE ALL FIRST YEAR COMPENSATION.  '.              
               10  WS-EX-MONTHS-MSG2   PIC ZZZZ9.                               
               10  FILLER              PIC X(24)      VALUE                     
               ' MONTHS STILL REMAINING.'.                                      
                                                                                
       01  FILLER.                                                              
           05  WS-EX-MSG3-RPT-NO       PIC X   VALUE '1'.                       
           05  WS-EX-MSG3.                                                      
               10  WS-EX-MONTHS-MSG3   PIC ZZZZ9.                               
               10  FILLER              PIC X(38)      VALUE                     
               ' MONTHS WERE ADVANCED.  PLEASE VERIFY.'.                        
                                                                                
       01  FILLER.                                                              
           05  WS-EX-MSG4-RPT-NO       PIC X   VALUE '1'.                       
           05  WS-EX-MSG4.                                                      
               10  FILLER              PIC X(6)      VALUE 'AGENT '.            
               10  WS-EX-AGENT-MSG4    PIC X(6).                                
               10  FILLER              PIC X(58)      VALUE                     
           ' - PLEASE SET UP PAYMENT BASIS.  NO COMPENSATION ADVANCED.'.        
                                                                                
       01  WS-EX-DETAIL-LINE-OUT.                                               
           05  WS-EX-RPT-NO-OUT        PIC X.                                   
           05  WS-EX-GFO-NO-OUT        PIC X(5).                                
REN        05  WS-EX-GROUP-NO-OUT      PIC X(10).                               
           05  WS-EX-MSG-OUT           PIC X(100).                              
                                                                                
       01  WS-EX-DATE-RECORD-OUT  REDEFINES WS-EX-DETAIL-LINE-OUT.              
           05  FILLER                  PIC X.                                   
REN        05  FILLER                  PIC X(10).                               
           05  FILLER                  PIC X(5).                                
           05  WS-EX-DATE-OUT          PIC X(100).                              
      /                                                                         
       COPY GWCORRAG.                                                           
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'WS-GFMSCALE-PARMS               '.                                  
                                                                                
      *                                                                         
      *01  GCSLPARM.                                                            
           COPY GCSLPARM.                                                       
      *                                                                         
      *01  GCSLCALP.                                                            
           COPY GCSLCALP.                                                       
      *                                                                         
       01  GTABCOMM-RECORD.                                                     
           COPY GTABCOMM.                                                       
      *                                                                         
      *01  WS-GFMSCALE-PARMS.                                                   
      *    03  WS-GFMSCALE-CODE                   PIC X(3).                     
      *    03  WS-GFMSCALE-POLYR           COMP-3 PIC S9(5).                    
      *    03  WS-GFMSCALE-BASE            COMP-3 PIC S9(7)V99.                 
      *    03  WS-GFMSCALE-PREM            COMP-3 PIC S9(7)V99.                 
      *    03  WS-GFMSCALE-COMM            COMP-3 PIC S9(7)V99.                 
      *    03  WS-GFMSCALE-RATE            COMP-3 PIC S9(3)V99.                 
      *    03  WS-GFMSCALE-REMPREM         COMP-3 PIC S9(7)V99.                 
      /                                                                         
      ******************************************************************        
      * - RETRIEVES A SINGLE SALES CREDIT AND COMMISSION SCALE                  
      *   INFO BASED ON PARMS RECEIVED.                                         
      ******************************************************************        
        COPY    GSCCALP.                                                        
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'WS-GNUMTABL-PARMS               '.                                  
                                                                                
       01  WS-GNUMTABL-PARMS.                                                   
           05  WS-GNUM-TABLE VALUE +34   PIC S9(4) COMP.                        
           05  WS-GNUM-REP               PIC X(5).                              
           05  WS-GNUM-RETURN.                                                  
               10  WS-GNUM-RETURN-1-5    PIC X(5).                              
               10  FILLER                PIC X(15).                             
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'WS-GZNAEXP7-PARMS               '.                                  
                                                                                
       01  WS-GZNAEXP7-PARMS.                                                   
           05  FILLER        OCCURS 6 TIMES.                                    
               10  WS-EXP-NAME           PIC X(30).                             
               10  WS-EXP-DELIMETER      PIC X.                                 
       01  WS-EXP-ERROR-CODE             PIC X(3).                              
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'DLS-WRITE-PARMS                 '.                                  
                                                                                
       01  DLS-WRITE-PARMS.                                                     
                                                                                
      **  FILE DESCRIPTION FOR COMMISSION REPORT                                
                                                                                
           05  DLS-SYS020-SYSNUM    PIC X(6)          VALUE 'SYS020'.           
           05  DLS-SYS020-RETURN    PIC S9    COMP-3  VALUE ZERO.               
SEP90      05  DLS-SYS020-REC-SIZE  PIC 9(5)          VALUE 116.                
SEP90      05  DLS-SYS020-BLK-SIZE  PIC 9(5)          VALUE 27956.              
           05  DLS-SYS020-FORMAT    PIC XX            VALUE 'FB'.               
           05  DLS-SYS020-REC-COUNT PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
       01  DLS-READ-PARMS.                                                      
                                                                                
      **  TO READ RUNDATE                                                       
                                                                                
           05  DLSR-SYSNUM          PIC X(6)          VALUE 'SYS019'.           
           05  DLSR-RETURN          PIC S9    COMP-3  VALUE ZERO.               
           05  DLSR-REC-SIZE        PIC 9(5)          VALUE 80.                 
           05  DLSR-BLK-SIZE        PIC 9(5)          VALUE 23440.              
           05  DLSR-FORMAT          PIC XX            VALUE 'FB'.               
           05  DLSR-REC-COUNT       PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'DATA BASE RECORDS               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
      /                                                                         
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * GWCORACCUM                                                              
CPYNME     COPY GCIACCUM.                                                       
      /                                                                         
      * GWCORADVPSM                                                             
CPYNME     COPY GCIADVPS.                                                       
      /                                                                         
      * GWCORRENEWAL                                                            
CPYNME     COPY GCIRNEWL.                                                       
      /                                                                         
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
      /                                                                         
      * GWCORPAYBASIS                                                           
CPYNME     COPY GCIPAYB.                                                        
      /                                                                         
MAN02 *%   COPY IDMS GWGCRAGT.                                                  
MAN02  COPY EAGNFILE.                                                           
      /                                                                         
      * GWCORGFO                                                                
CPYNME     COPY GCIGFO.                                                         
      /                                                                         
      * GWCORTRANS                                                              
CPYNME     COPY GCITRAN.                                                        
      /                                                                         
      * GWCORCNTL                                                               
CPYNME     COPY GCICNTL.                                                        
      /                                                                         
MAN02 *%   COPY IDMS FIELD-OFFICE.                                              
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'OTHER COPY BOOK RECORDS         '.                                  
                                                                                
       COPY GCOMRLS7.                                                           
      /                                                                         
      * GNAPREC                                                                 
CPYNME     COPY GNAPREC7.                                                       
      /                                                                         
      * GWCORGPB-RECORD                                                         
CPYNME     COPY GCRGPB.                                                         
      /                                                                         
       COPY GWCORNRD.                                                           
      /                                                                         
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           'WORKING STORAGE ENDS HERE'.                                         
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
                                                                                
       01  FDOF-PARMS.                                                          
           05  FDOF-PARM1.                                                      
               10  FDOF-DDNAME       PIC X(7)       VALUE 'VSDSI89'.            
               10  FDOF-ACCTTYPE     PIC X(5)       VALUE 'KEYED'.              
               10  FDOF-RECTYPE      PIC X(1)       VALUE 'V'.                  
               10  FDOF-FUNCTION     PIC X(6)       VALUE 'GETRAN'.             
               10  FDOF-ERRCODE      PIC X(5)       VALUE SPACES.               
               10  FDOF-READCT       PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-WRITECT      PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-UPDATECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-DELETECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-RECLGTH      PIC S9(4)      VALUE +0    COMP.           
           05  FDOF-PARM2.                                                      
               10  FDOF-BRANCH       PIC X(5)       VALUE SPACES.               
                                                                                
MAN02  COPY FDOFFILE.                                                           
                                                                                
       01  FDOFFILE                         PIC X(16) VALUE 'FDOFFILE'.         
                                                                                
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
           05  ZCURRDAT                     PIC X(8)  VALUE 'ZCURRDAT'.         
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  PARM.                                                                
           05  PARMLENGTH                     PIC S9(4) COMP.                   
           05  PARMDATE.                                                        
               10  PARM-DAY                   PIC 99.                           
               10  FILLER                     PIC X.                            
               10  PARM-MONTH                 PIC 99.                           
               10  FILLER                     PIC X.                            
               10  PARM-YEAR                  PIC 99.                           
                                                                                
       PROCEDURE DIVISION USING PARM.                                           
FXXTOK     MOVE 'GC2RAD'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       000-MAINLINE.                                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                PROGRAM MAINLINE                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           PERFORM 100-INITIALIZE THRU 100-EXIT.                                
           PERFORM 200-PROCESS-GROUP-ACCOUNTS THRU 299-EXIT                     
               UNTIL DB-END-OF-SET.                                             
           PERFORM 300-END-OF-JOB THRU 399-EXIT.                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'CLOSE FILES'      TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 160-READ-VCM-GIPSY THRU 160-READ-VCM-GIPSY-EXIT.             
                                                                                
      * VOCOMM VOPSM/PSM                                                        
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  LOGICAL-RECORD-NAME                           
                                  ICBM.                                         
                                                                                
           MOVE +1                   TO GACCDMA7-PS-FUNC.                       
           CALL 'GACCDMA7'        USING GACCDMA7-PS-PARMS                       
                                        GACCDMA7-PS-RETURN                      
                                        PSMASTE7.                               
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
                                                                                
       099-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       100-INITIALIZE.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREA TO BE ACCESSED                              *         
      *     GET RUN DATE AND EDIT                                     *         
      *     WRITE HEADINGS ON REPORT                                  *         
      *     GET FIRST GRACCT RECORD FROM DATA BASE                    *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
CM0510     MOVE LOW-DATE TO WS-RENEW-DATE.                                      
                                                                                
      * VOCOMM VOPSM/PSM                                                        
FXXTOK     MOVE 'GC2RAD'   TO ICBM-PROGRAM-NAME.                                
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
                                                                                
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2RAD' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA3 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-FDOFILE-AREA USAGE-MODE IS RETRIEVAL.                       
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-AGTNAME-AREA USAGE-MODE IS RETRIEVAL.                       
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'OPEN FILES'       TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 160-READ-VCM-GIPSY THRU 160-READ-VCM-GIPSY-EXIT.             
                                                                                
           PERFORM 120-READ-RUNDATE THRU 120-EXIT.                              
MAN02      CALL QDATEQ2 USING QDATE-FORMATCA                                    
MAN02                         PROGRAM-RUN-DATE                                  
MAN02                         WS-ALIS-RUN-DATE.                                 
           IF WS-ALIS-RUN-DATE = '****'                                         
               MOVE SPACES    TO WTL-MESSAGE                                    
               MOVE ERR-MESS1 TO WTL-MESSAGE                                    
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           IF PARMLENGTH = 8                                                    
              MOVE PARM-DAY    TO WS-CURR-DAY                                   
              MOVE PARM-MONTH  TO WS-CURR-MONTH                                 
              MOVE PARM-YEAR   TO WS-CURR-YEAR                                  
           ELSE                                                                 
              CALL  ZCURRDAT        USING WS-CURRENT-DATE                       
              MOVE WS-CURRENT-YEAR  TO    WS-CURR-YEAR                          
              MOVE WS-CURRENT-MONTH TO    WS-CURR-MONTH                         
              MOVE WS-CURRENT-DAY   TO    WS-CURR-DAY.                          
                                                                                
MAN02      CALL QDATEQ2 USING QDATE-FORMATBA                                    
MAN02                         WS-CURR-DATE                                      
MAN02                         ALIS-CURR-DATE.                                   
                                                                                
      *%   OBTAIN FIRST GWCORCNTL WITHIN GW-COMP-AREA1.                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           IF (WS-ALIS-RUN-DATE GREATER THAN ALIS-CURR-DATE) OR                 
            (WS-ALIS-RUN-DATE NOT GREATER THAN LAST-REN-COMM-RUN-DATE)          
               MOVE SPACES    TO WTL-MESSAGE                                    
               MOVE ERR-MESS2 TO WTL-MESSAGE                                    
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           MOVE WS-ALIS-RUN-DATE TO LAST-REN-COMM-RUN-DATE.                     
      *%   MODIFY GWCORCNTL.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           PERFORM INIT-FIELDS THRU INIT-FIELDS-EXIT                            
                               VARYING WS-SUB                                   
                               FROM +1                                          
                               BY +1                                            
                               UNTIL WS-SUB > +10.                              
           MOVE INIT-CR-RECORD TO GCOMRLSE.                                     
                                                                                
           MOVE SPACES TO WS-EX-DATE-RECORD-OUT.                                
           MOVE WS-ALIS-RUN-DATE TO WS-EX-DATE-OUT.                             
           PERFORM 9910-WRITE-EXCEPTION-REPORT THRU 9999-EXIT.                  
                                                                                
      *%   OBTAIN FIRST GWCORGRACCT WITHIN GW-COMP-AREA1                        
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       100-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       120-READ-RUNDATE.                                                        
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   READ RUN DATE FROM PARMLIB                                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           CALL 'DLSREAD' USING DLSR-SYSNUM                                     
                                DLSR-RETURN                                     
                                PROGRAM-RUN-DATE-RECORD                         
                                DLSR-REC-SIZE                                   
                                DLSR-BLK-SIZE                                   
                                DLSR-FORMAT                                     
                                DLSR-REC-COUNT.                                 
           IF DLSR-RETURN = +0                                                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSREAD FAILED - SYS019' UPON CONSOLE                   
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
       120-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------                     
      * VOCOMM VCM/GIPSY                                                        
       160-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       160-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
       200-PROCESS-GROUP-ACCOUNTS.                                              
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    DETERMINE IF GROUP/ACCOUNT IS READY TO ADVANCE.            *         
      *    IF NOT, GET NEXT GROUP/ACCOUNT.                            *         
      *    OTHERWISE,                                                 *         
      *    CHECK ACCUM RECORDS TO SEE IF A PREMIUM HAS BEEN           *         
      *    PAID FOR THE RENEWAL YEAR.                                 *         
      *    IF A PREMIUM HAS BEEN PAID AND THE GROUP/ACCOUNT HAS       *         
      *    RECONCILED, INVOKE LOGIC TO ADVANCE RENEWAL COMPENSATION.  *         
      *    OTHERWISE, GET NEXT GROUP/ACCOUNT.                         *         
      *    PRINT A MESSAGE IF WE HAVEN'T RECEIVED A PREMIUM WITHIN    *         
      *    90 DAYS OF THE RENEWAL DATE.                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    SEP/90 A. NIKELSKI                                         *         
      *         - RESET WS-AGT-INDEX FOR EACH GROUP.                  *         
      *         - RESET GPSY-GROUP & ACCOUNT FOR EACH GROUP           *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE -1     TO WS-AGT-INDEX.                                         
           MOVE 0      TO GPSY-GROUP.                                           
           MOVE SPACES TO GPSY-ACCOUNT.                                         
                                                                                
           MOVE 'N' TO WS-ERROR-SWITCH.                                         
                                                                                
           IF  RENEW-COMP-ADVANCED-IND EQUAL TO 'N'                             
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 290-GET-NEXT-GROUP-ACCOUNT.                                
      *    ENDIF                                                                
                                                                                
      * SET NAL INDICATOR                                                       
           PERFORM 5000-GROUP-NAL   THRU 5000-EXIT.                             
                                                                                
           MOVE RENEWAL-EFFECTIVE-YEAR TO WS-REN-TEST-YEAR.                     
           ADD +90, RENEWAL-EFFECTIVE-DAY GIVING WS-REN-TEST-DAY.               
           IF WS-REN-TEST-DAY GREATER THAN +365                                 
               COMPUTE WS-REN-TEST-DAY = WS-REN-TEST-DAY - 365                  
               ADD +1 TO WS-REN-TEST-YEAR.                                      
                                                                                
      *%   OBTAIN FIRST GWCORACCUM WITHIN GRACCT-ACCUM                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
           PERFORM 400-GET-ACCUM-RECORDS THRU                                   
                   400-GET-ACCUM-RECORDS-EXIT                                   
               UNTIL PREM-DUE-DATE NOT LESS THAN RENEWAL-EFFECTIVE-DATE         
               OR    DB-END-OF-SET.                                             
           IF  DB-END-OF-SET                                                    
               IF WS-ALIS-RUN-DATE GREATER THAN WS-REN-TEST-DATE                
                   MOVE 'N'          TO WS-SKIP-GROUP                           
                   PERFORM 410-GET-VCM-GIPSY-MASTER THRU                        
                           410-GET-VCM-GIPSY-MASTER-EXIT                        
                   IF WS-SKIP-GROUP = 'Y'                                       
                      GO TO 290-GET-NEXT-GROUP-ACCOUNT                          
                   ELSE                                                         
                      MOVE +24 TO WS-ERROR-NUMBER                               
                      PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT              
                      GO TO 290-GET-NEXT-GROUP-ACCOUNT                          
               ELSE                                                             
                   GO TO 290-GET-NEXT-GROUP-ACCOUNT                             
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           IF  DB-STATUS-OK                                                     
           AND RENEWAL-EFFECTIVE-DATE LESS THAN NEXT-RECON-DATE                 
               PERFORM 500-ADVANCE-COMPENSATION THRU 599-EXIT                   
           ELSE                                                                 
               GO TO 290-GET-NEXT-GROUP-ACCOUNT.                                
      /                                                                         
       290-GET-NEXT-GROUP-ACCOUNT.                                              
                                                                                
      *%   FIND CURRENT GWCORGRACCT.                                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   OBTAIN NEXT GWCORGRACCT WITHIN GW-COMP-AREA1                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
      /                                                                         
       299-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       300-END-OF-JOB.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    CLOSE REPORT FILE.                                         *         
      *    CLOSE RUN DATE FILE.                                       *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE +4 TO DLS-SYS020-RETURN.                                        
           CALL 'DLSWRITE' USING DLS-SYS020-SYSNUM                              
                                 DLS-SYS020-RETURN                              
                                 WS-EX-DETAIL-LINE-OUT                          
                                 DLS-SYS020-REC-SIZE                            
                                 DLS-SYS020-BLK-SIZE                            
                                 DLS-SYS020-FORMAT                              
                                 DLS-SYS020-REC-COUNT.                          
           IF DLS-SYS020-RETURN EQUAL TO +4                                     
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'CLOSE FAILED - SYS020' UPON CONSOLE                     
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           MOVE +4 TO DLSR-RETURN.                                              
           CALL 'DLSREAD' USING DLSR-SYSNUM                                     
                                DLSR-RETURN                                     
                                PROGRAM-RUN-DATE-RECORD                         
                                DLSR-REC-SIZE                                   
                                DLSR-BLK-SIZE                                   
                                DLSR-FORMAT                                     
                                DLSR-REC-COUNT.                                 
           IF DLSR-RETURN = +4                                                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'CLOSE FAILED - SYS019' UPON CONSOLE                     
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
       399-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       400-GET-ACCUM-RECORDS.                                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    GET PREMIUM ACCUMULATIONS RECORD FOR THE GROUP/ACCOUNT     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *%   OBTAIN NEXT GWCORACCUM WITHIN GRACCT-ACCUM                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
       400-GET-ACCUM-RECORDS-EXIT.                                              
           EXIT.                                                                
                                                                                
       410-GET-VCM-GIPSY-MASTER.                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    GET THE VCM OR GIPSY MASTER RECORD.                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ KEYED (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES                    TO VGWI-SOURCE-SYSTEM.                
           MOVE 'READ KEYED'              TO VGWI-REQUEST.                      
           MOVE SPACES                    TO VGWI-COVERAGE-TYPE.                
           MOVE GROUP-NUMBER OF GWCORGRACCT TO WS-GROUP-NUMBER.                 
           MOVE WS-NUM-GROUP-NUMBER       TO VGWI-GROUP.                        
           MOVE GR-ACCOUNT OF GWCORGRACCT TO VGWI-ACCOUNT.                      
           MOVE 'GIPSY EXPANDED'          TO VGWI-LR-NAME.                      
           PERFORM 160-READ-VCM-GIPSY THRU 160-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
              MOVE GGIGROUP-NUMBER   TO GPSY-GROUP                              
              MOVE GGIACCOUNT        TO GPSY-ACCOUNT                            
           ELSE                                                                 
              IF VGWO-RET-CODE = '31'                                           
      *       READ-KEYED RECORD NOT FOUND                                       
                 PERFORM CHECK-GROUP-DATES                                      
                    THRU CHECK-GROUP-DATES-EXIT                                 
              ELSE                                                              
                 IF VGWO-RET-SEVERE-ERROR                                       
FXXTOK              GO TO 799-SQL-STATUS.                                       
                                                                                
       410-GET-VCM-GIPSY-MASTER-EXIT.                                           
           EXIT.                                                                
      /                                                                         
       500-ADVANCE-COMPENSATION.                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    INVOKE LOGIC TO GET ALL GROUP RECORDS. END PROCESSING FOR  *         
      *    THE GROUP/ACCOUNT IF THERE IS A PROBLEM.                   *         
      *    INVOKE LOGIC TO GET ALL RENEWAL RECORDS.  WRITE A MESSAGE  *         
      *    END PROCESSING FOR THE GROUP/ACCOUNT IF NONE EXISTS.       *         
      *    CALCULATE LAST RENEWAL DATE BY SUBTRACTING 1 YR FROM       *         
      *    NEXT RENEWAL DATE.                                         *         
      *    INVOKE LOGIC TO CALCULATE NUMBER OF MONTHS LEFT TO ADVANCE *         
      *    FOR FIRST YEAR AND NUMBER OF MONTHS IN THE RENEWAL YEAR.   *         
      *    INVOKE LOGIC TO SET UP AGENTS TO RECEIVE FY AND RENEWAL    *         
      *    COMPENSATION.                                              *         
      *    IF THERE IS FY CALCULATIONS TO BE DONE BUT THERE ARE NO    *         
      *    FY AGENTS, PRINT A MESSAGE.                                *         
      *    IF THERE IS RN CALCULATIONS TO BE DONE BUT THERE ARE NO    *         
      *    RN AGENTS, PRINT A MESSAGE.                                *         
      *    IF THERE IS A LIFE PREMIUM BUT NO AGENTS ARE SET UP TO     *         
      *    RECEIVE COMPENSATION ON LIFE, PRINT A MESSAGE AND          *         
      *    VICE-VERSA.  THIS EDIT IS ALSO DONE FOR LTD AND A&S.       *         
      *    IF ANY OF THE ABOVE ERRORS ARE DETECTED, END PROCESSING    *         
      *    FOR THE GROUP/ACCOUNT.                                     *         
      *    OTHERWISE, INVOKE LOGIC TO CALCULATE FY COMPENSATION IF    *         
      *    APPLICABLE AND INVOKE LOGIC TO CALCULATE RENEWAL           *         
      *    COMPENSATION.                                              *         
      *    IF THE TOTAL NUMBER OF MONTHS ADVANCE IS NOT EQUAL TO 12,  *         
      *       PRINT A MESSAGE.                                        *         
      *    THE GROUP/ACCOUNT RECORD IS MODIFIED TO INDICATE THAT      *         
      *    COMPENSATION HAS BEEN ADVANCED FOR THE RENEWAL YEAR.       *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 600-GET-GROUP-RECORDS THRU 699-EXIT.                         
           IF ERROR-SWITCH-ON                                                   
               GO TO 599-EXIT.                                                  
                                                                                
           IF GGIACCOUNT-STATUS = '00' OR '01' OR '02' OR '03'                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE +22 TO WS-ERROR-NUMBER                                      
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT                     
               GO TO 590-MODIFY-GRACCT.                                         
                                                                                
           MOVE ZERO TO WS-PREM-LIFE                                            
                        WS-PREM-LTD                                             
                        WS-PREM-A-S.                                            
      *%   OBTAIN FIRST GWCORRENEWAL WITHIN GRACCT-RENEWAL                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 FCCSPL-GRACCT-RENEWAL                                     
MAN02                 GWCORRENEWAL                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               MOVE +3 TO WS-ERROR-NUMBER                                       
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           PERFORM 700-GET-RENEWAL-PREM-AMOUNTS UNTIL DB-END-OF-SET.            
                                                                                
           IF WS-PREM-LIFE LESS THAN ZERO                                       
           OR WS-PREM-LTD LESS THAN ZERO                                        
           OR WS-PREM-A-S LESS THAN ZERO                                        
               MOVE +4 TO WS-ERROR-NUMBER                                       
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           IF ERROR-SWITCH-ON                                                   
               GO TO 599-EXIT.                                                  
                                                                                
           PERFORM 800-CALCULATE-FY-RN-MONTHS THRU 849-EXIT.                    
                                                                                
           IF ERROR-SWITCH-ON                                                   
               GO TO 599-EXIT.                                                  
                                                                                
      ******************************************************************        
      *    NOV/90 M PRANGE.                                                     
      *         - USING PSMNXT-RENEW-DATE INSTEAD OF GGINEXT-ANNIV DATE.        
      ******************************************************************        
           COMPUTE WS-LAST-RENEW-YR-INT = WS-PSMNXT-RNEW-YEAR - 1.              
           MOVE WS-PSMNXT-RNEW-DAY         TO WS-LAST-RENEW-DAY-INT.            
           IF  WS-LAST-RENEW-DATE-INT < GGI-ACCT-EFFECTIVE                      
               MOVE RENEWAL-EFFECTIVE-DATE TO WS-LAST-RENEW-DATE-INT.           
                                                                                
           MOVE SPACES TO WS-FY-VALID-AGENT-TABLE                               
                          WS-RN-VALID-AGENT-TABLE                               
                          WS-SAVE-FY-REG-SCALE                                  
                          WS-SAVE-FY-LTD-SCALE                                  
                          WS-SAVE-RN-REG-SCALE                                  
                          WS-SAVE-RN-LTD-SCALE.                                 
           MOVE ZERO TO   WS-FY-AGT-INDEX                                       
                          WS-RN-AGT-INDEX                                       
                          WS-FY-AGT-COUNT                                       
                          WS-RN-AGT-COUNT.                                      
           MOVE 'N' TO    WS-LIFE-PERCENT-SWITCH                                
                          WS-LTD-PERCENT-SWITCH                                 
                          WS-A-S-PERCENT-SWITCH.                                
                                                                                
           IF  WS-FY-MONTHS GREATER THAN ZERO                                   
               PERFORM 850-CALC-FY-AGT-START-DATE                               
               IF ERROR-SWITCH-ON                                               
                   GO TO 599-EXIT.                                              
                                                                                
           PERFORM 900-GET-VALID-AGENTS                                         
               VARYING WS-AGT-INDEX FROM 1 BY 1                                 
                   UNTIL WS-AGT-INDEX GREATER THAN +4                           
                      OR GAGTRIDENT (WS-AGT-INDEX) EQUAL TO SPACES              
                      OR GAGTRIDENT (WS-AGT-INDEX) EQUAL TO LOW-VALUES.         
                                                                                
           IF ERROR-SWITCH-ON                                                   
               GO TO 599-EXIT.                                                  
                                                                                
           MOVE SPACES TO GWCORGPB-RECORD.                                      
           MOVE GROUP-NUMBER OF GWCORGRACCT TO GWCOEGPB-GROUP.                  
           MOVE GR-ACCOUNT OF GWCORGRACCT TO GWCOEGPB-GR-ACCOUNT.               
           MOVE GGI-ACCT-EFFECTIVE TO GWCOEGPB-ACCT-EFF-DATE.                   
           MOVE RENEWAL-EFFECTIVE-DATE TO GWCOEGPB-TRANS-EFF-DATE.              
           MOVE RENEWAL-EFFECTIVE-DATE TO GWCOEGPB-AGENT-START-DATE.            
                                                                                
           PERFORM 1250-GET-PAY-BASIS THRU 1250-EXIT                            
               VARYING WS-AGT-INDEX FROM 1 BY 1                                 
                   UNTIL WS-AGT-INDEX GREATER THAN +4                           
                   OR ( WS-FY-AGENT (WS-AGT-INDEX) = SPACES AND                 
                        WS-RN-AGENT (WS-AGT-INDEX) = SPACES ).                  
                                                                                
           IF ERROR-SWITCH-ON                                                   
               GO TO 599-EXIT.                                                  
                                                                                
           IF  WS-FY-AGT-COUNT EQUAL TO ZERO                                    
           AND WS-RN-AGT-COUNT EQUAL TO ZERO                                    
               MOVE +23 TO WS-ERROR-NUMBER                                      
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT                     
               GO TO 599-EXIT.                                                  
                                                                                
           IF  WS-PREM-LIFE GREATER THAN ZERO                                   
               AND WS-LIFE-PERCENT-SWITCH = 'N'                                 
               MOVE +6 TO WS-ERROR-NUMBER                                       
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           IF  WS-PREM-LTD GREATER THAN ZERO                                    
               AND WS-LTD-PERCENT-SWITCH = 'N'                                  
               MOVE +7 TO WS-ERROR-NUMBER                                       
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           IF  WS-PREM-A-S GREATER THAN ZERO                                    
               AND WS-A-S-PERCENT-SWITCH = 'N'                                  
               MOVE +8 TO WS-ERROR-NUMBER                                       
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           IF ERROR-SWITCH-ON                                                   
               GO TO 599-EXIT.                                                  
                                                                                
      ******************************************************************        
      *  NAL GROUPS ARE BEGING CONVERTED OVER TO GIPSY BY REISSUING             
      *  THEM ON THE SYSTEM. WHEN THE GROUPS ARE REISSUED THE                   
      *  CONVERSION DATE IS USED FOR THE CONTRACT ISSUE DATE AND THE            
      *  ACCOUNT EFFECTIVE DATE.                                                
      *                                                                         
      *  A PROBLEM OCCURS WHEN THESE GROUPS ARE ISSUED AS SECOND YEAR           
      *  THE RENEWAL MONTHS ARE BEING CALCULATED AS IF THE GROUP WAS            
      *  IN IT'S FIRST YEAR. THEREFORE IF THERE IS NO FIRST YEAR AGENT          
      *  RESET THE RN-MONTHS TO THE FULL RENEWAL PERIOD CALCULATED              
      *  IN PARAGRAPH 800-CALCULATE-FY-RN-MONTHS.                               
      *  THIS IS ONLY DONE FOR PRODUCT 2 AND 3 AT THE USERS REQUEST             
      ******************************************************************        
           IF  WS-FY-MONTHS GREATER THAN ZERO                                   
           AND WS-FY-AGT-COUNT EQUAL TO ZERO                                    
               MOVE ZERO TO WS-FY-MONTHS                                        
               IF ( NAL-GROUP       ) AND                                       
                  ( GR-NOT-FIRST-YR ) AND                                       
                  ( GGIPRODUCT-CODE > 1 )                                       
                  MOVE WS-SAVE-RN-MONTHS TO WS-RN-MONTHS                        
                  MOVE ZERO              TO WS-FY-MONTHS-REMAINING.             
                                                                                
           IF  WS-RN-MONTHS GREATER THAN ZERO                                   
           AND WS-RN-AGT-COUNT EQUAL TO ZERO                                    
               MOVE ZERO TO WS-RN-MONTHS.                                       
                                                                                
           IF WS-FY-MONTHS GREATER THAN ZERO                                    
               PERFORM 1300-ADVANCE-FY-COMPENSATION.                            
                                                                                
           COMPUTE WS-TOTAL-MONTHS-ADVANCED = WS-FY-MONTHS                      
                                            + WS-RN-MONTHS.                     
                                                                                
           IF WS-RN-MONTHS GREATER THAN ZERO                                    
               PERFORM 1400-ADVANCE-RN-COMPENSATION.                            
                                                                                
           IF WS-TOTAL-MONTHS-ADVANCED EQUAL TO +12                             
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE +99 TO WS-ERROR-NUMBER                                      
               MOVE WS-EX-MSG3-RPT-NO TO WS-EX-RPT-NO-OUT                       
               MOVE WS-TOTAL-MONTHS-ADVANCED TO WS-EX-MONTHS-MSG3               
               MOVE WS-EX-MSG3 TO WS-EX-MSG-OUT                                 
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           IF WS-FY-MONTHS-REMAINING GREATER THAN ZERO                          
               MOVE +99 TO WS-ERROR-NUMBER                                      
               MOVE WS-EX-MSG2-RPT-NO TO WS-EX-RPT-NO-OUT                       
               MOVE WS-FY-MONTHS-REMAINING TO WS-EX-MONTHS-MSG2                 
               MOVE WS-EX-MSG2 TO WS-EX-MSG-OUT                                 
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT                     
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       590-MODIFY-GRACCT.                                                       
                                                                                
           MOVE 'Y' TO RENEW-COMP-ADVANCED-IND.                                 
      *%   FIND CURRENT GWCORGRACCT.                                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   MODIFY GWCORGRACCT.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           ADD +1 TO WS-TOTAL-GROUPS-PROCESSED.                                 
                                                                                
       599-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       600-GET-GROUP-RECORDS.                                                   
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    GET GROUP RECORD IN COMMISSION DATA BASE.                  *         
      *    GET GIPSY POINT-IN-SCALE MASTER AND SAVE THE POLICY YEAR   *         
      *    GET GIPSY MASTER AND EXPAND.                               *         
      *    IF ANY OF THE ABOVE RECORDS CAN'T BE FOUND, PRINT AN       *         
      *    EXCEPTION MESSAGE.                                         *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT TO                                  
                GROUP-NUMBER OF GWCORGROUP.                                     
      *%   FIND CALC GWCORGROUP.                                                
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      * VOCOMM VOPSM/PSM                                                        
           MOVE LOW-VALUES          TO VOPSMASTER-RECORD.                       
           MOVE GROUP-NUMBER OF GWCORGRACCT                                     
                                    TO WS-GROUP-NUMBER.                         
           MOVE WS-NUM-GROUP-NUMBER TO VOPSM-GROUP-NUMBER.                      
           MOVE LR-VO-PSMASTER-R    TO LOGICAL-RECORD-NAME.                     
           CALL GAEDATSR         USING OBTAIN-KEYED                             
                                       VOPSMASTER-RECORD                        
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              MOVE 'B' TO VDATE-REQ-SERVICE                                     
              MOVE 'B' TO VDATE-REQ-BASIS                                       
              MOVE '1' TO VDATE-REQ-DETAIL                                      
              MOVE 'E' TO VDATE-REQ-LANGUAGE                                    
              MOVE VOPSM-NXT-RNEW-YEAR  TO VDATE1-YYYY                          
              MOVE VOPSM-NXT-RNEW-MONTH TO VDATE1-MM                            
              MOVE VOPSM-NXT-RNEW-DAY   TO VDATE1-DD                            
              CALL GC2DATE USING GC2DATE-PARS                                   
                                                                                
              MOVE VOPSM-GROUP-NUMBER   TO PSMGROUP-NUMBER                      
              MOVE VOPSM-POLICY-YEAR    TO PSMPOLICY-YEAR                       
              MOVE VDATE-ALIS-YEAR1     TO PSMNXT-RNEW-YR                       
              MOVE VDATE-ALIS-DAY1      TO PSMNXT-RNEW-DAY                      
           ELSE                                                                 
FXXTOK        MOVE LOW-VALUES           TO PSMASTE7                             
              MOVE WS-NUM-GROUP-NUMBER  TO GACCDMA7-PS-GROUP                    
              MOVE HIGH-VALUES          TO GACCDMA7-PS-ACCT                     
              CALL 'GACCDMA7'        USING GACCDMA7-PS-PARMS                    
                                           GACCDMA7-PS-RETURN                   
FXXTOK                                     PSMASTE7                             
              IF GACCDMA7-PS-RETURN = 'R01'                                     
                 MOVE -1             TO GGIGROUP-NUMBER                         
                 MOVE LOW-VALUES     TO GGIACCOUNT                              
                 MOVE +1             TO WS-ERROR-NUMBER                         
      *                                                                         
      *        IF GROUP NOT FOUND ON GIPSY MASTER AND LAST RECON.               
      *        DATE IS OLDER THAN 1 YEAR - DO NOT PRINT EXTRACT                 
      *                                                                         
      *        FIND CURR DATE MINUS 1 YEAR                                      
      *                                                                         
                 MOVE ALIS-CURR-DATE TO ALIS-CURR-DATE-MINUS-1-YEAR             
                 SUBTRACT +1         FROM ALIS-YEAR                             
                 IF LAST-RECON-DATE OF GWCORGRACCT                              
                    > ALIS-CURR-DATE-MINUS-1-YEAR                               
                    PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT                
                    GO TO 699-EXIT                                              
                 ELSE                                                           
                    GO TO 699-EXIT                                              
              ELSE                                                              
                 IF GACCDMA7-PS-RETURN NOT = SPACES                             
FXXTOK              GO TO 799-SQL-STATUS.                                       
                                                                                
           MOVE PSMPOLICY-YEAR TO WS-POLICY-YEAR.                               
           MOVE PSMNXT-RNEW-DATE TO WS-PSMNXT-RNEW-DATE.                        
                                                                                
           IF PSMPOLICY-YEAR = 1                                                
              MOVE 'Y'     TO  GR-POL-YEAR                                      
           ELSE                                                                 
              MOVE 'N'     TO  GR-POL-YEAR.                                     
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ KEYED (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES                    TO VGWI-SOURCE-SYSTEM.                
           MOVE 'READ KEYED'              TO VGWI-REQUEST.                      
           MOVE SPACES                    TO VGWI-COVERAGE-TYPE.                
           MOVE WS-NUM-GROUP-NUMBER       TO VGWI-GROUP.                        
           MOVE GR-ACCOUNT OF GWCORGRACCT TO VGWI-ACCOUNT.                      
           MOVE 'GIPSY EXPANDED'          TO VGWI-LR-NAME.                      
           PERFORM 160-READ-VCM-GIPSY THRU 160-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
              MOVE GGIGROUP-NUMBER   TO GPSY-GROUP                              
              MOVE GGIACCOUNT        TO GPSY-ACCOUNT                            
           ELSE                                                                 
              IF VGWO-RET-CODE = '31'                                           
      *       READ-KEYED RECORD NOT FOUND                                       
                 PERFORM CHECK-GROUP-DATES                                      
                    THRU CHECK-GROUP-DATES-EXIT                                 
              ELSE                                                              
                 IF VGWO-RET-SEVERE-ERROR                                       
FXXTOK              GO TO 799-SQL-STATUS.                                       
                                                                                
      ******************************************************************        
      *    NOV/90 M PRANGE.                                                     
      *         - COMMENTED OUT THIS LOGIC THAT FUDGES THE POLICY-YEAR.         
      ******************************************************************        
      *    IF WS-PSMNXT-RNEW-DATE LESS THAN GGINEXT-ANNIVERSARY                 
      *        ADD +1 TO WS-POLICY-YEAR.                                        
      ******************************************************************        
                                                                                
       699-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       700-GET-RENEWAL-PREM-AMOUNTS.                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    SET UP RENEWAL PREMIUM AMOUNTS IN WORKING STORAGE FOR      *         
      *    LIFE, LTD AND A&S.  IF THERE IS A RENEWAL AMOUNT FOR ANY   *         
      *    OTHER COVERAGE, PRINT A MESSAGE.                           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF COV-TYPE OF GWCORRENEWAL EQUAL TO 'T'                             
               MOVE RENEWAL-AMOUNT OF GWCORRENEWAL TO WS-PREM-LIFE              
           ELSE                                                                 
           IF COV-TYPE OF GWCORRENEWAL EQUAL TO 'L'                             
               MOVE RENEWAL-AMOUNT OF GWCORRENEWAL TO WS-PREM-LTD               
           ELSE                                                                 
           IF COV-TYPE OF GWCORRENEWAL EQUAL TO 'O'                             
               MOVE RENEWAL-AMOUNT OF GWCORRENEWAL TO WS-PREM-A-S               
           ELSE                                                                 
               MOVE +9 TO WS-ERROR-NUMBER                                       
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
      *%   OBTAIN NEXT GWCORRENEWAL WITHIN GRACCT-RENEWAL                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 FCCSPL-GRACCT-RENEWAL                                     
MAN02                 GWCORRENEWAL                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       799-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       800-CALCULATE-FY-RN-MONTHS.                                              
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    IF THE ACCOUNT IS NOT AN AMENDMENT TO THE GROUP, THEN      *         
      *    CALCULATE THE DIFFERENCE IN MONTHS BETWEEN THE ACCOUNT     *         
      *    EFFECTIVE DATE AND THE RENEWAL EFFECTIVE DATE TO DETERMINE *         
      *    THE NUMBER OF MONTHS ALREADY ADVANCED.  IF THIS IS LESS    *         
      *    THAN 12, WE NEED TO ADVANCE THE REMAINING FIRST YEAR       *         
      *    COMPENSATION.                                              *         
      *    CALCULATE THE DIFFERENCE IN MONTHS BETWEEN THE RENEWAL     *         
      *    EFFECTIVE DATE AND THE NEXT RENEWAL DATE TO DETERMINE      *         
      *    THE NUMBER OF MONTHS FOR WHICH WE NEED TO ADVANCE RENEWAL  *         
      *    COMPENSATION.                                              *         
      *    PRINT A MESSAGE IF THE NUMBER OF FY MONTHS TO ADVANCE IS   *         
      *    GREATER THAN THE NUMBER OF RENEWAL MONTHS TO ADVANCE AND   *         
      *    ONLY ADVANCE UP TO THE NEXT RENEWAL FOR FIRST YEAR.        *         
      *    THE REST OF THE FY COMPENSATION WILL HAVE TO BE HANDLED    *         
      *    MANUALLY.                                                  *         
      *    IF WE ARE ADVANCING BOTH FY AND RENEWAL, ONLY ADVANCE      *         
      *    THE DIFFENCE BETWEEN FY MONTHS AND RENEWAL MONTHS AS       *         
      *    RENEWAL. I.E. IF WE OWE 3 MONTHS FY AND THERE IS 12 MONTHS *         
      *    IN THE RENEWAL YEAR, ADVANCE 3 MONTHS FY AND 9 MONTHS      *         
      *    RENEWAL.                                                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE '2B1E' TO GC2DATE-PARS.                                 YEAR2000
                                                                        YEAR2000
           MOVE GGI-ACCT-EFFECTIVE TO VDATE-ALIS-DATE1.                 YEAR2000
           CALL  GC2DATE  USING GC2DATE-PARS.                           YEAR2000
           MOVE VDATE1-YYYYMMDD TO WS-ACCT-EFF-DATE-EXT.                YEAR2000
           IF VDATE-RET-FAIL                                            YEAR2000
               MOVE '*' TO WS-ACCT-EFF-EXT-BYTE1                        YEAR2000
               MOVE +15 TO WS-ERROR-NUMBER                                      
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           MOVE RENEWAL-EFFECTIVE-DATE TO VDATE-ALIS-DATE1.             YEAR2000
           CALL  GC2DATE  USING GC2DATE-PARS.                           YEAR2000
           MOVE VDATE1-YYYYMMDD TO WS-REN-EFF-DATE-EXT.                 YEAR2000
           IF VDATE-RET-FAIL                                            YEAR2000
               MOVE '*' TO WS-REN-EFF-EXT-BYTE1                         YEAR2000
               MOVE +16 TO WS-ERROR-NUMBER                                      
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
      ******************************************************************        
      *    NOV/90 M PRANGE.                                                     
      *         - USING PSMNXT-RENEW-DATE INSTEAD OF GGINEXT-ANNIV DATE.        
      ******************************************************************        
           MOVE WS-PSMNXT-RNEW-DATE TO VDATE-ALIS-DATE1.                YEAR2000
           CALL  GC2DATE  USING GC2DATE-PARS.                           YEAR2000
           MOVE VDATE1-YYYYMMDD TO WS-NEXT-RENEW-DATE-EXT.              YEAR2000
           IF VDATE-RET-FAIL                                            YEAR2000
               MOVE '*' TO  WS-NEXT-RENEW-EXT-BYTE1                     YEAR2000
               MOVE +17 TO WS-ERROR-NUMBER                                      
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
           IF ERROR-SWITCH-ON                                                   
               GO TO 849-EXIT.                                                  
                                                                                
            IF GGICONTRACT-ISSUE EQUAL TO GGI-ACCT-EFFECTIVE                    
                COMPUTE WS-MONTHS-ADVANCED =                                    
                   ((WS-REN-EFF-YR-EXT - WS-ACCT-EFF-YR-EXT) * 12)              
                     + (WS-REN-EFF-MO-EXT - WS-ACCT-EFF-MO-EXT)                 
                IF WS-MONTHS-ADVANCED LESS THAN +12                             
                    SUBTRACT WS-MONTHS-ADVANCED FROM +12                        
                       GIVING   WS-FY-MONTHS                                    
                  ELSE                                                          
                    MOVE ZERO TO WS-FY-MONTHS                                   
            ELSE                                                                
                  MOVE ZERO TO WS-FY-MONTHS.                                    
           IF WS-FY-MONTHS LESS THAN ZERO                                       
               MOVE ZERO TO WS-FY-MONTHS.                                       
                                                                                
      ******************************************************************        
      *    NOV/90 M PRANGE.                                                     
      *         - USING PSMNXT-RENEW-DATE INSTEAD OF GGINEXT-ANNIV DATE.        
      ******************************************************************        
            COMPUTE WS-RN-MONTHS =                                              
             ( ( WS-NEXT-RENEW-YR-EXT - WS-REN-EFF-YR-EXT ) * 12 )              
              + ( WS-NEXT-RENEW-MO-EXT - WS-REN-EFF-MO-EXT ).                   
                                                                                
           IF WS-RN-MONTHS LESS THAN ZERO                                       
               MOVE ZERO TO WS-RN-MONTHS.                                       
                                                                                
           MOVE WS-RN-MONTHS       TO   WS-SAVE-RN-MONTHS.                      
                                                                                
           IF WS-FY-MONTHS GREATER THAN WS-RN-MONTHS                            
               COMPUTE WS-FY-MONTHS-REMAINING = WS-FY-MONTHS                    
                                              - WS-RN-MONTHS                    
               MOVE WS-RN-MONTHS TO WS-FY-MONTHS                                
           ELSE                                                                 
               MOVE ZERO TO WS-FY-MONTHS-REMAINING.                             
                                                                                
           COMPUTE WS-RN-MONTHS = WS-RN-MONTHS - WS-FY-MONTHS.                  
                                                                                
       849-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       850-CALC-FY-AGT-START-DATE.                                              
                                                                                
           MOVE WS-ACCT-EFF-DAY-EXT TO WS-AGT-START-DAY-EXT.                    
           MOVE WS-ACCT-EFF-MO-EXT TO WS-AGT-START-MO-EXT.                      
           MOVE WS-ACCT-EFF-YR-EXT TO WS-AGT-START-YR-EXT.                      
                                                                                
           IF WS-AGT-START-DAY-EXT EQUAL TO +1                                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF WS-AGT-START-DAY-EXT GREATER THAN +15                         
                   MOVE +1 TO WS-AGT-START-DAY-EXT                              
                   ADD  +1 TO WS-AGT-START-MO-EXT                               
                   IF WS-AGT-START-MO-EXT = +13                                 
                       MOVE +1 TO WS-AGT-START-MO-EXT                           
                       ADD  +1 TO WS-AGT-START-YR-EXT                           
                   ELSE                                                         
                       NEXT SENTENCE                                            
               ELSE                                                             
                   MOVE +1 TO WS-AGT-START-DAY-EXT.                             
                                                                                
MAN02      CALL QDATEQ2 USING QDATE-FORMATBA                                    
MAN02                         WS-AGT-START-DATE-EXT                             
MAN02                         WS-AGT-START-DATE-INT.                            
           IF WS-AGT-START-INT-BYTE1 EQUAL TO '*'                               
               MOVE +26 TO WS-ERROR-NUMBER                                      
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
       859-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       900-GET-VALID-AGENTS.                                                    
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *  SET UP MINIMUM STOP DATE FOR FY SEGMENTS.                    *         
      *  INVOKE LOGIC TO LOOK AT AGENT SEGMENTS ON GIPSY              *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE WS-LAST-RENEW-DATE-INT TO WS-FY-STOP-DATE.                      
           IF WS-FY-STOP-DAY EQUAL TO +1                                        
               MOVE +365 TO WS-FY-STOP-DAY                                      
               SUBTRACT +1 FROM WS-FY-STOP-YR                                   
           ELSE                                                                 
               SUBTRACT +1 FROM WS-FY-STOP-DAY.                                 
                                                                                
           PERFORM 1000-GET-VALID-AGENT-SEGMENTS                                
               VARYING WS-SEG-INDEX FROM 1 BY 1                                 
                   UNTIL WS-SEG-INDEX GREATER THAN +5                           
                      OR GAGCOMM-IND (WS-AGT-INDEX, WS-SEG-INDEX)               
                             EQUAL TO SPACES                                    
                      OR GAGCOMM-IND (WS-AGT-INDEX, WS-SEG-INDEX)               
                             EQUAL TO LOW-VALUES.                               
                                                                                
       999-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       1000-GET-VALID-AGENT-SEGMENTS.                                           
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  THIS LOGIC SETS UP A TABLE OF AGENTS TO RECEIVE FY           *         
      *  COMPENSATION AND ANOTHER TABLE OF AGENTS TO RECEIVE RENEWAL  *         
      *  COMPENSATION.  TO RECEIVE FY COMPENSATION, THE AGENT MUST    *         
      *  START ON THE ACCOUNT EFFECTIVE DATE AND STOP AFTER THE LAST  *         
      *  RENEWAL DATE AND HAVE A FY SPLIT FOR ONE OF THE THREE        *         
      *  COVERAGES GREATER THAN ZERO.  THE AGENT MUST ALSO BE         *         
      *  ANNUALIZED OR HAVE A NO COMMISSION INDICATOR.  FOR A NO      *         
      *  COMMISSION INDICATOR WE STILL NEED TO ADVANCE SALES CREDITS  *         
      *  AND NAPS.                                                    *         
      *  TO RECEIVE RENEWAL COMPENSATION, THE AGENT MUST START ON OR  *         
      *  BEFORE THE RENEWAL EFFECTIVE DATE AND STOP AFTER THE         *         
      *  RENEWAL EFFECTIVE DATE.  THE AGENT MUST ALSO BE ANNUALIZED   *         
      *  AND HAVE A RENEWAL SPLIT FOR AT LEAST ONE OF THE THREE       *         
      *  COVERAGES GREATER THAN ZERO.                                 *         
      *  IF THESE CONDITIONS ARE TRUE, WE MUST EDIT EACH AGENT TO     *         
      *  MAKE SURE GIPSY IS SET UP PROPERLY.                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  WS-FY-MONTHS GREATER THAN ZERO                                   
           AND GAGSTART-DATE (WS-AGT-INDEX, WS-SEG-INDEX)                       
               EQUAL TO WS-AGT-START-DATE-INT                                   
           AND GAGSTOP-DATE (WS-AGT-INDEX, WS-SEG-INDEX)                        
               NOT LESS THAN WS-FY-STOP-DATE                                    
           AND ( GAGCOMM-IND (WS-AGT-INDEX, WS-SEG-INDEX)                       
                 NOT EQUAL TO 'S' )                                             
           AND (   GAGFRST-LIFE (WS-AGT-INDEX, WS-SEG-INDEX)                    
                   GREATER THAN ZERO                                            
                OR GAGFRST-LTD (WS-AGT-INDEX, WS-SEG-INDEX)                     
                   GREATER THAN ZERO                                            
                OR GAGFRST-A-S (WS-AGT-INDEX, WS-SEG-INDEX)                     
                   GREATER THAN ZERO   )                                        
               PERFORM 1100-EDIT-FY-AGENT THRU 1100-EXIT                        
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           IF  WS-RN-MONTHS GREATER THAN ZERO                                   
           AND GAGSTART-DATE (WS-AGT-INDEX, WS-SEG-INDEX)                       
               NOT GREATER THAN RENEWAL-EFFECTIVE-DATE                          
           AND GAGSTOP-DATE (WS-AGT-INDEX, WS-SEG-INDEX)                        
               GREATER THAN RENEWAL-EFFECTIVE-DATE                              
           AND ( GAGCOMM-IND (WS-AGT-INDEX, WS-SEG-INDEX)                       
                 NOT EQUAL TO 'S' )                                             
           AND (   GAGREN-LIFE (WS-AGT-INDEX, WS-SEG-INDEX)                     
                   GREATER THAN ZERO                                            
                OR GAGREN-LTD (WS-AGT-INDEX, WS-SEG-INDEX)                      
                   GREATER THAN ZERO                                            
                OR GAGREN-A-S (WS-AGT-INDEX, WS-SEG-INDEX)                      
                   GREATER THAN ZERO   )                                        
               PERFORM 1200-EDIT-RN-AGENT THRU 1200-EXIT                        
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1100-EDIT-FY-AGENT.                                                      
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  ALL AGENTS IN THE FY AGENT TABLE MUST HAVE THE SAME          *         
      *  SPLITS, FLAT RATES, AND SCALES.  ALSO, THEY MUST EITHER      *         
      *  ALL BE ANUALIZED OR ALL ON 'NO COMMISSION'.  IF ANY OF THE   *         
      *  ABOVE FIELDS DO NOT COMPARE, PRINT AN EXCEPTION MESSAGE AND  *         
      *  END PROCESSING FOR THIS AGENT'S SEGMENT.  OTHERWISE, SET     *         
      *  A SWITCH FOR EACH OF THE VALID COVERAGES FOR LATER EDITS.    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GAGAGENT-CODE (WS-AGT-INDEX) TO                                 
                WS-TEMP-AGENT-CODE.                                             
           MOVE GAGAGENT-BRANCH (WS-AGT-INDEX) TO                               
                WS-TEMP-AGENT-BRANCH.                                           
           MOVE GAGFRST-LIFE (WS-AGT-INDEX, WS-SEG-INDEX) TO                    
                WS-TEMP-LIFE-PERCENT.                                           
           MOVE GAGFRST-LTD (WS-AGT-INDEX, WS-SEG-INDEX) TO                     
                WS-TEMP-LTD-PERCENT.                                            
           MOVE GAGFRST-A-S (WS-AGT-INDEX, WS-SEG-INDEX) TO                     
                WS-TEMP-A-S-PERCENT.                                            
           MOVE GAGSCALE (WS-AGT-INDEX, WS-SEG-INDEX) TO                        
                WS-TEMP-REG-SCALE.                                              
           MOVE GAGLTD-SCALE (WS-AGT-INDEX, WS-SEG-INDEX) TO                    
                WS-TEMP-LTD-SCALE.                                              
           MOVE GAGFLAT-RATE (WS-AGT-INDEX, WS-SEG-INDEX) TO                    
                WS-TEMP-REG-RATE.                                               
           MOVE GAGLTD-FLAT-RATE (WS-AGT-INDEX, WS-SEG-INDEX) TO                
                WS-TEMP-LTD-RATE.                                               
           IF GAGCOMM-IND (WS-AGT-INDEX, WS-SEG-INDEX) = 'N'                    
                MOVE 'N' TO WS-TEMP-COMM-IND                                    
           ELSE                                                                 
                MOVE 'Y' TO WS-TEMP-COMM-IND.                                   
                                                                                
           IF WS-FY-AGT-INDEX EQUAL TO ZERO                                     
               ADD +1 TO WS-FY-AGT-COUNT                                        
               ADD +1 TO WS-FY-AGT-INDEX                                        
               MOVE WS-TEMP-VALID-AGENT TO                                      
                    WS-FY-VALID-AGENT (WS-FY-AGT-INDEX)                         
               MOVE WS-TEMP-REG-SCALE TO WS-SAVE-FY-REG-SCALE                   
               MOVE WS-TEMP-LTD-SCALE TO WS-SAVE-FY-LTD-SCALE                   
           ELSE                                                                 
               IF  WS-TEMP-AGENT-CODE EQUAL TO                                  
                   WS-FY-AGENT-CODE (WS-FY-AGT-INDEX)                           
                   IF WS-TEMP-CONSTANT-AGENT-INFO NOT =                         
                      WS-FY-CONSTANT-AGENT-INFO (WS-FY-AGT-INDEX)               
                       MOVE +10 TO WS-ERROR-NUMBER                              
                       PERFORM 9900-EXCEPTION-REPORT                            
                           THRU 9999-EXIT                                       
                       GO TO 1100-EXIT                                          
                   ELSE                                                         
                       NEXT SENTENCE                                            
      *            ENDIF                                                        
               ELSE                                                             
                   IF  WS-TEMP-REG-SCALE = WS-SAVE-FY-REG-SCALE                 
                   AND WS-TEMP-LTD-SCALE = WS-SAVE-FY-LTD-SCALE                 
                       ADD +1 TO WS-FY-AGT-COUNT                                
                       ADD +1 TO WS-FY-AGT-INDEX                                
                       MOVE WS-TEMP-VALID-AGENT TO                              
                            WS-FY-VALID-AGENT (WS-FY-AGT-INDEX)                 
                   ELSE                                                         
                       MOVE +11 TO WS-ERROR-NUMBER                              
                       PERFORM 9900-EXCEPTION-REPORT                            
                           THRU 9999-EXIT                                       
                       GO TO 1100-EXIT                                          
      *            ENDIF                                                        
      *        ENDIF                                                            
      *    ENDIF                                                                
           .                                                                    
                                                                                
           IF WS-TEMP-LIFE-PERCENT GREATER THAN ZERO                            
               MOVE 'Y' TO WS-LIFE-PERCENT-SWITCH.                              
                                                                                
           IF WS-TEMP-LTD-PERCENT GREATER THAN ZERO                             
               MOVE 'Y' TO WS-LTD-PERCENT-SWITCH.                               
                                                                                
           IF WS-TEMP-A-S-PERCENT GREATER THAN ZERO                             
               MOVE 'Y' TO WS-A-S-PERCENT-SWITCH.                               
                                                                                
       1100-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1200-EDIT-RN-AGENT.                                                      
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  ALL AGENTS IN THE RN AGENT TABLE MUST HAVE THE SAME          *         
      *  SPLITS, FLAT RATES, AND SCALES.  IF ANY OF THE               *         
      *  ABOVE FIELDS DO NOT COMPARE, PRINT AN EXCEPTION MESSAGE AND  *         
      *  END PROCESSING FOR THIS AGENT'S SEGMENT.  OTHERWISE, SET     *         
      *  A SWITCH FOR EACH OF THE VALID COVERAGES FOR LATER EDITS.    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GAGAGENT-CODE (WS-AGT-INDEX) TO                                 
                WS-TEMP-AGENT-CODE.                                             
           MOVE GAGAGENT-BRANCH (WS-AGT-INDEX) TO                               
                WS-TEMP-AGENT-BRANCH.                                           
           MOVE GAGREN-LIFE (WS-AGT-INDEX, WS-SEG-INDEX) TO                     
                WS-TEMP-LIFE-PERCENT.                                           
           MOVE GAGREN-LTD (WS-AGT-INDEX, WS-SEG-INDEX) TO                      
                WS-TEMP-LTD-PERCENT.                                            
           MOVE GAGREN-A-S (WS-AGT-INDEX, WS-SEG-INDEX) TO                      
                WS-TEMP-A-S-PERCENT.                                            
           MOVE GAGSCALE (WS-AGT-INDEX, WS-SEG-INDEX) TO                        
                WS-TEMP-REG-SCALE.                                              
           MOVE GAGLTD-SCALE (WS-AGT-INDEX, WS-SEG-INDEX) TO                    
                WS-TEMP-LTD-SCALE.                                              
           MOVE GAGFLAT-RATE (WS-AGT-INDEX, WS-SEG-INDEX) TO                    
                WS-TEMP-REG-RATE.                                               
           MOVE GAGLTD-FLAT-RATE (WS-AGT-INDEX, WS-SEG-INDEX) TO                
                WS-TEMP-LTD-RATE.                                               
           IF GAGCOMM-IND (WS-AGT-INDEX, WS-SEG-INDEX) = 'N'                    
                MOVE 'N' TO WS-TEMP-COMM-IND                                    
           ELSE                                                                 
                MOVE 'Y' TO WS-TEMP-COMM-IND.                                   
                                                                                
           IF  WS-RN-AGT-INDEX EQUAL TO ZERO                                    
               ADD +1 TO WS-RN-AGT-COUNT                                        
               ADD +1 TO WS-RN-AGT-INDEX                                        
               MOVE WS-TEMP-VALID-AGENT TO                                      
                    WS-RN-VALID-AGENT (WS-RN-AGT-INDEX)                         
               MOVE WS-TEMP-REG-SCALE TO WS-SAVE-RN-REG-SCALE                   
               MOVE WS-TEMP-LTD-SCALE TO WS-SAVE-RN-LTD-SCALE                   
           ELSE                                                                 
               IF  WS-TEMP-AGENT-CODE EQUAL TO                                  
                   WS-RN-AGENT-CODE (WS-RN-AGT-INDEX)                           
                   IF WS-TEMP-CONSTANT-AGENT-INFO NOT =                         
                      WS-RN-CONSTANT-AGENT-INFO (WS-RN-AGT-INDEX)               
                       MOVE +12 TO WS-ERROR-NUMBER                              
                       PERFORM 9900-EXCEPTION-REPORT                            
                           THRU 9999-EXIT                                       
                       GO TO 1200-EXIT                                          
                   ELSE                                                         
                       NEXT SENTENCE                                            
      *            ENDIF                                                        
               ELSE                                                             
                   IF  WS-TEMP-REG-SCALE = WS-SAVE-RN-REG-SCALE                 
                   AND WS-TEMP-LTD-SCALE = WS-SAVE-RN-LTD-SCALE                 
                       ADD +1 TO WS-RN-AGT-COUNT                                
                       ADD +1 TO WS-RN-AGT-INDEX                                
                       MOVE WS-TEMP-VALID-AGENT TO                              
                            WS-RN-VALID-AGENT (WS-RN-AGT-INDEX)                 
                   ELSE                                                         
                       MOVE +13 TO WS-ERROR-NUMBER                              
                       PERFORM 9900-EXCEPTION-REPORT                            
                           THRU 9999-EXIT                                       
                       GO TO 1200-EXIT                                          
      *            ENDIF                                                        
      *        ENDIF                                                            
      *    ENDIF                                                                
           .                                                                    
                                                                                
           IF WS-TEMP-LIFE-PERCENT GREATER THAN ZERO                            
               MOVE 'Y' TO WS-LIFE-PERCENT-SWITCH.                              
                                                                                
           IF WS-TEMP-LTD-PERCENT GREATER THAN ZERO                             
               MOVE 'Y' TO WS-LTD-PERCENT-SWITCH.                               
                                                                                
           IF WS-TEMP-A-S-PERCENT GREATER THAN ZERO                             
               MOVE 'Y' TO WS-A-S-PERCENT-SWITCH.                               
                                                                                
       1200-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1250-GET-PAY-BASIS.                                                      
                                                                                
           IF WS-FY-AGENT (WS-AGT-INDEX) EQUAL TO SPACES                        
               GO TO 1250-GET-RN-PAY-BASIS.                                     
                                                                                
           MOVE WS-FY-AGENT (WS-AGT-INDEX) TO GWCOEGPB-AGENT-NUMBER.            
FXXTOK     CALL  GC2PB2  USING DBLINK-SUBSCHEMA-CONTROL                         
                                 DBLINK-RECORD-SET-KEYS                         
                                 DBLINK-CURSOR-CODES                            
                                 GWCORGRACCT                                    
                                 GWCORAGENT                                     
                                 GWCORPAYBASIS                                  
FXXTOK                           AGENT-NAME-FILE                                
                                 GWCORGPB-RECORD                                
                                 ICBM.                                          
           IF GWCOEGPB-RETURN-CODE EQUAL TO ZERO                                
               MOVE GWCOEGPB-AGENT-PAY-BASIS-FY TO                              
                    WS-FY-PAY-BASIS (WS-AGT-INDEX)                              
           ELSE                                                                 
               MOVE +99 TO WS-ERROR-NUMBER                                      
               MOVE WS-EX-MSG4-RPT-NO TO WS-EX-RPT-NO-OUT                       
               MOVE GWCOEGPB-AGENT-CODE TO WS-EX-AGENT-MSG4                     
               MOVE WS-EX-MSG4 TO WS-EX-MSG-OUT                                 
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
       1250-GET-RN-PAY-BASIS.                                                   
                                                                                
           IF WS-RN-AGENT (WS-AGT-INDEX) EQUAL TO SPACES                        
               GO TO 1250-EXIT.                                                 
                                                                                
           MOVE WS-RN-AGENT (WS-AGT-INDEX) TO GWCOEGPB-AGENT-NUMBER.            
FXXTOK     CALL  GC2PB2  USING DBLINK-SUBSCHEMA-CONTROL                         
                                 DBLINK-RECORD-SET-KEYS                         
                                 DBLINK-CURSOR-CODES                            
                                 GWCORGRACCT                                    
                                 GWCORAGENT                                     
                                 GWCORPAYBASIS                                  
FXXTOK                           AGENT-NAME-FILE                                
                                 GWCORGPB-RECORD                                
                                 ICBM.                                          
           IF GWCOEGPB-RETURN-CODE EQUAL TO ZERO                                
               MOVE GWCOEGPB-AGENT-PAY-BASIS-RN TO                              
                    WS-RN-PAY-BASIS (WS-AGT-INDEX)                              
           ELSE                                                                 
               MOVE +99 TO WS-ERROR-NUMBER                                      
               MOVE WS-EX-MSG4-RPT-NO TO WS-EX-RPT-NO-OUT                       
               MOVE GWCOEGPB-AGENT-CODE TO WS-EX-AGENT-MSG4                     
               MOVE WS-EX-MSG4 TO WS-EX-MSG-OUT                                 
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT.                    
                                                                                
       1250-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1300-ADVANCE-FY-COMPENSATION.                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  THIS LOGIC DOES THE ADVANCING OF FY COMPENSATION.            *         
      *  INITIALIZE WORK FIELDS. CALCULATE ANUALIZED FY PREMIUM       *         
      *  AMOUNTS BY MULTIPLYING THE RENEWAL PREMIUM AMOUNTS FROM      *         
      *  THE GWCORRENEWAL RECORDS BY THE NUMBER OF FY MONTHS LEFT TO  *         
      *  ADVANCE.  THE ANNUALIZED NAP AMOUNT IS THE TOTAL OF THE      *         
      *  ANNUALIZED PREMIUMS.  IF THIS GROUP/ACCOUNT USES A COMMISSION*         
      *  SCALE, INVOKE COMMISSION SCALE LOGIC. OTHERWISE, COMMISSION  *         
      *  IS CALCULATED ON AN INDIVIDUAL FLAT RATE BASIS.              *         
      *  THE RENEWAL DATE USED IN THE SCALE CALCULATIONS IS THE       *         
      *  LAST RENEWAL.                                                *         
      *  INVOKE LOGIC TO CALCULATE SALES CREDITS.                     *         
      *  INVOKE LOGIC TO INITIALIZE THE NAP RECORD FOR DISTRIBUTION.  *         
      *  INVOKE LOGIC TO INITIALIZE THE COMMISSION RELEASE RECORD.    *         
      *  INVOKE LOGIC TO INITIALIZE THE HISTORY RECORD FOR THE DATA   *         
      *  BASE.                                                        *         
      *  INVOKE LOGIC TO SPLIT THE COMMISSION, SALES CREDITS AND      *         
      *  NAPS BY AGENT SPLIT.                                         *         
      *  INVOKE LOGIC TO UPDATE THE ADVANCE POINT-IN-SCALE FOR        *         
      *  COMMISSIONS AND SALES CREDITS.                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE ZERO TO WS-COMM-LIFE                                            
                        WS-COMM-LTD                                             
                        WS-COMM-A-S                                             
                        WS-SC-LIFE                                              
                        WS-SC-LTD                                               
                        WS-SC-A-S                                               
                        WS-TOTAL-PREM-ALL                                       
                        WS-TOTAL-PREM-LIFE-A-S                                  
                        WS-TOTAL-PREM-LTD                                       
                        WS-TOTAL-PREM-ALL-SC.                                   
CM0510*    MOVE LOW-DATE TO WS-RENEW-DATE.                                      
                                                                                
           MULTIPLY WS-PREM-LIFE BY WS-FY-MONTHS                                
           GIVING   WS-ANN-PREM-LIFE.                                           
           MULTIPLY WS-PREM-LTD BY WS-FY-MONTHS                                 
           GIVING   WS-ANN-PREM-LTD.                                            
           MULTIPLY WS-PREM-A-S BY WS-FY-MONTHS                                 
           GIVING   WS-ANN-PREM-A-S.                                            
                                                                                
           MOVE +0                 TO WS-ANN-PREM-LIFE-SC                       
                                      WS-ANN-PREM-LTD-SC                        
                                      WS-ANN-PREM-A-S-SC.                       
                                                                                
           COMPUTE WS-ANN-PREM-NAP = WS-ANN-PREM-LIFE                           
                                   + WS-ANN-PREM-LTD                            
                                   + WS-ANN-PREM-A-S.                           
                                                                                
           MOVE 'F'  TO COMP-REASON.                                            
           MOVE 'FY' TO GSC-FY-RN-TYPE.                                         
           MOVE 'Y'  TO GSC-FIND-FACTOR.                                        
                                                                                
           IF WS-SAVE-FY-REG-SCALE EQUAL TO SPACES AND                          
              WS-SAVE-FY-LTD-SCALE EQUAL TO SPACES                              
               MOVE 'Y' TO WS-FLAT-CALC-SWITCH                                  
           ELSE                                                                 
               MOVE 'N' TO WS-FLAT-CALC-SWITCH                                  
               MOVE WS-SAVE-FY-REG-SCALE TO WS-REG-SCALE                        
               MOVE WS-SAVE-FY-LTD-SCALE TO WS-LTD-SCALE                        
               MOVE WS-LAST-RENEW-DATE-INT TO WS-RENEW-DATE                     
               PERFORM 1500-SCALE-CALCULATION.                                  
                                                                                
           MOVE WS-LAST-RENEW-DATE-INT TO WS-RENEW-DATE.                        
      *    PERFORM 1900-CALC-SALES-CREDITS.                                     
           PERFORM 2100-INIT-NAP-RECORD.                                        
           PERFORM 2200-INIT-CR-RECORD.                                         
           PERFORM 2300-INIT-COMP-RECORD.                                       
           MOVE WS-FY-VALID-AGENT-TABLE TO WS-VALID-AGENT-TABLE.                
           PERFORM 2400-AGENT-SPLIT                                             
               VARYING WS-AGT-INDEX FROM 1 BY 1                                 
                   UNTIL WS-AGT-INDEX IS GREATER THAN WS-FY-AGT-COUNT.          
           PERFORM 3200-UPDATE-ADVPSM.                                          
                                                                                
       1399-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1400-ADVANCE-RN-COMPENSATION.                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  THIS LOGIC IS THE SAME AS FY PROCESSING EXCEPT WE ONLY       *         
      *  ADVANCE COMMISSION IN A RENEWAL YEAR.                        *         
      *  THE RENEWAL DATE USED IN THE SCALE CALCULATION IS THE        *         
      *  NEXT RENEWAL.                                                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE ZERO TO WS-COMM-LIFE                                            
                        WS-COMM-LTD                                             
                        WS-COMM-A-S                                             
                        WS-SC-LIFE                                              
                        WS-SC-LTD                                               
                        WS-SC-A-S                                               
                        WS-TOTAL-PREM-ALL                                       
                        WS-TOTAL-PREM-LIFE-A-S                                  
                        WS-TOTAL-PREM-LTD                                       
                        WS-TOTAL-PREM-ALL-SC.                                   
CM0510*    MOVE LOW-DATE TO WS-RENEW-DATE.                                      
                                                                                
           MULTIPLY WS-PREM-LIFE BY WS-RN-MONTHS                                
           GIVING   WS-ANN-PREM-LIFE.                                           
           MULTIPLY WS-PREM-LTD BY WS-RN-MONTHS                                 
           GIVING   WS-ANN-PREM-LTD.                                            
           MULTIPLY WS-PREM-A-S BY WS-RN-MONTHS                                 
           GIVING   WS-ANN-PREM-A-S.                                            
                                                                                
      ********************************************************                  
      * MAY93 - PRIOR TO THIS RELEASE, IN A SHORT FIRST YEAR *                  
      *         SALES CREDITS AT RENEWAL TIME THE SALES      *                  
      *         CREDITS WERE CALCULATED FOR 12 MONTHS FOR    *                  
      *         FIRST YEAR.  NOW WE WILL CALCULATE SALES     *                  
      *         CREDITS FOR THE FIRST YEAR AND RENEWAL YEAR  *                  
      *         SEGMENT.                                     *                  
      ********************************************************                  
           COMPUTE WS-ANN-PREM-LIFE-SC =                                        
                   WS-PREM-LIFE * WS-TOTAL-MONTHS-ADVANCED                      
           COMPUTE WS-ANN-PREM-LTD-SC  =                                        
                   WS-PREM-LTD * WS-TOTAL-MONTHS-ADVANCED                       
           COMPUTE WS-ANN-PREM-A-S-SC  =                                        
                   WS-PREM-A-S * WS-TOTAL-MONTHS-ADVANCED.                      
                                                                                
           MOVE 'R' TO COMP-REASON.                                             
           MOVE 'RN' TO GSC-FY-RN-TYPE.                                         
           MOVE 'Y'  TO GSC-FIND-FACTOR.                                        
                                                                                
           IF WS-SAVE-RN-REG-SCALE EQUAL TO SPACES AND                          
              WS-SAVE-RN-LTD-SCALE EQUAL TO SPACES                              
               MOVE 'Y' TO WS-FLAT-CALC-SWITCH                                  
           ELSE                                                                 
               MOVE 'N' TO WS-FLAT-CALC-SWITCH                                  
               MOVE WS-SAVE-RN-REG-SCALE TO WS-REG-SCALE                        
               MOVE WS-SAVE-RN-LTD-SCALE TO WS-LTD-SCALE                        
               MOVE WS-PSMNXT-RNEW-DATE  TO WS-RENEW-DATE                       
               PERFORM 1500-SCALE-CALCULATION.                                  
           PERFORM 1900-CALC-SALES-CREDITS.                                     
                                                                                
           PERFORM 2200-INIT-CR-RECORD.                                         
           PERFORM 2300-INIT-COMP-RECORD.                                       
           MOVE WS-RN-VALID-AGENT-TABLE TO WS-VALID-AGENT-TABLE.                
           PERFORM 2400-AGENT-SPLIT                                             
               VARYING WS-AGT-INDEX FROM 1 BY 1                                 
                   UNTIL WS-AGT-INDEX IS GREATER THAN WS-RN-AGT-COUNT.          
           PERFORM 3200-UPDATE-ADVPSM.                                          
                                                                                
       1499-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1500-SCALE-CALCULATION.                                                  
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  SET UP POLICY YEAR FOR THE SCALE CALCULATION.                *         
      *  IF LIFE, A&S AND LTD ARE ON THE SAME SCALE, TOTAL ALL        *         
      *  ANNUALIZED PREMIUMS AND INVOKE THE APPROPRIATE SCALE LOGIC.  *         
      *  OTHERWISE, TOTAL THE LIFE AND A&S PREMIUM AND INVOKE THE     *         
      *  APPROPRIATE SCALE LOGIC AND THEN INVOKE THE LTD SCALE LOGIC. *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF COMP-REASON EQUAL TO 'F'                                          
      *        MOVE +1 TO WS-GFMSCALE-POLYR                                     
               MOVE +1 TO GCSL-START-YEAR                                       
           ELSE                                                                 
      *        MOVE WS-POLICY-YEAR TO WS-GFMSCALE-POLYR.                        
               MOVE WS-POLICY-YEAR TO GCSL-START-YEAR.                          
                                                                                
           IF WS-REG-SCALE = WS-LTD-SCALE                                       
               COMPUTE WS-TOTAL-PREM-ALL = WS-ANN-PREM-LIFE                     
                                         + WS-ANN-PREM-LTD                      
                                         + WS-ANN-PREM-A-S                      
           ELSE                                                                 
               COMPUTE WS-TOTAL-PREM-LIFE-A-S = WS-ANN-PREM-LIFE                
                                              + WS-ANN-PREM-A-S                 
               MOVE WS-ANN-PREM-LTD TO WS-TOTAL-PREM-LTD.                       
                                                                                
           IF WS-TOTAL-PREM-ALL GREATER THAN ZERO                               
               PERFORM 1600-ALL-SCALE-CALC.                                     
                                                                                
           IF WS-TOTAL-PREM-LIFE-A-S GREATER THAN ZERO                          
               PERFORM 1700-LIFE-A-S-SCALE-CALC.                                
                                                                                
           IF WS-TOTAL-PREM-LTD GREATER THAN ZERO                               
               PERFORM 1800-LTD-SCALE-CALC.                                     
                                                                                
       1599-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1600-ALL-SCALE-CALC.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  USE THE RENEWAL DATE AND THE SCALE TO DETERMINE THE          *         
      *  POINT-IN-SCALE.  CALL GFMSCALE TO DO THE CALCULATION.        *         
      *  PRO-RATE THE TOTAL COMMISSION AMOUNT CALCULATED              *         
      *  TO DETERMINE THE COMMISSION AMOUNT FOR LIFE, LTD AND A&S.    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *    MOVE WS-REG-SCALE TO WS-GFMSCALE-CODE.                               
           MOVE WS-REG-SCALE TO GCSL-SCALE-CODE.                                
           MOVE WS-RENEW-DATE TO NEXT-RENEW-DATE.                               
           MOVE WS-REG-SCALE TO COMM-SCALE.                                     
           PERFORM 2000-GET-ADV-POINT-IN-SCALE.                                 
      *    MOVE PSM-PREM-ADV OF GWCORADVPSM TO WS-GFMSCALE-BASE.                
           MOVE PSM-PREM-ADV OF GWCORADVPSM TO GCSL-BASE-PREMIUM.               
      *    MOVE WS-TOTAL-PREM-ALL TO WS-GFMSCALE-PREM.                          
           MOVE WS-TOTAL-PREM-ALL TO GCSL-CURR-PREMIUM.                         
      *    MOVE ZERO TO WS-GFMSCALE-COMM                                        
      *                 WS-GFMSCALE-RATE                                        
      *                 WS-GFMSCALE-REMPREM.                                    
      *    CALL 'GFMSCALE' USING WS-GFMSCALE-PARMS.                             
      *                                                                         
           MOVE 'R'          TO  GCSL-CALL-TYPE.                                
FXXTOK     CALL  GC2LCOMM    USING  GCSLPARM                                    
                                    GTABCOMM-RECORD.                            
           MOVE +0              TO  GCSL-COMMISSION.                            
           IF  GCSL-RET-SUCCESS                                                 
FXXTOK         CALL  GC2LCALC    USING  GCSL-CALC-PARMS                         
                                        GTABCOMM-RECORD.                        
      *                                                                         
      *    COMPUTE WS-COMM-LIFE ROUNDED = WS-GFMSCALE-COMM                      
           IF WS-TOTAL-PREM-ALL = ZERO                                          
              MOVE ZERO TO WS-COMM-LIFE                                         
                           WS-COMM-LTD                                          
                           WS-COMM-A-S                                          
           ELSE                                                                 
              COMPUTE WS-COMM-LIFE ROUNDED = GCSL-COMMISSION                    
                                           * WS-ANN-PREM-LIFE                   
                                           / WS-TOTAL-PREM-ALL                  
              COMPUTE WS-COMM-LTD ROUNDED  = GCSL-COMMISSION                    
                                           * WS-ANN-PREM-LTD                    
                                           / WS-TOTAL-PREM-ALL                  
              COMPUTE WS-COMM-A-S ROUNDED  = GCSL-COMMISSION                    
                                           * WS-ANN-PREM-A-S                    
                                           / WS-TOTAL-PREM-ALL.                 
       1699-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1700-LIFE-A-S-SCALE-CALC.                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  USE THE RENEWAL DATE AND THE SCALE TO DETERMINE THE          *         
      *  POINT-IN-SCALE.  CALL GFMSCALE TO DO THE CALCULATION.        *         
      *  PRO-RATE THE TOTAL COMMISSION AMOUNT CALCULATED              *         
      *  TO DETERMINE THE COMMISSION AMOUNT FOR LIFE AND A&S.         *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *    MOVE WS-REG-SCALE TO WS-GFMSCALE-CODE.                               
           MOVE WS-REG-SCALE TO GCSL-SCALE-CODE.                                
           MOVE WS-RENEW-DATE TO NEXT-RENEW-DATE.                               
           MOVE WS-REG-SCALE TO COMM-SCALE.                                     
           PERFORM 2000-GET-ADV-POINT-IN-SCALE.                                 
      *    MOVE PSM-PREM-ADV OF GWCORADVPSM TO WS-GFMSCALE-BASE.                
           MOVE PSM-PREM-ADV OF GWCORADVPSM TO GCSL-BASE-PREMIUM.               
      *    MOVE WS-TOTAL-PREM-LIFE-A-S TO WS-GFMSCALE-PREM.                     
           MOVE WS-TOTAL-PREM-LIFE-A-S TO GCSL-CURR-PREMIUM.                    
      *    MOVE ZERO TO WS-GFMSCALE-COMM                                        
      *                 WS-GFMSCALE-RATE                                        
      *                 WS-GFMSCALE-REMPREM.                                    
      *    CALL 'GFMSCALE' USING WS-GFMSCALE-PARMS.                             
      *                                                                         
           MOVE 'R'          TO  GCSL-CALL-TYPE.                                
FXXTOK     CALL  GC2LCOMM    USING  GCSLPARM                                    
                                    GTABCOMM-RECORD.                            
           MOVE +0              TO  GCSL-COMMISSION.                            
           IF  GCSL-RET-SUCCESS                                                 
FXXTOK         CALL  GC2LCALC    USING  GCSL-CALC-PARMS                         
                                        GTABCOMM-RECORD.                        
      *                                                                         
           IF WS-TOTAL-PREM-LIFE-A-S = ZERO                                     
              MOVE ZERO TO WS-COMM-LIFE                                         
                           WS-COMM-A-S                                          
           ELSE                                                                 
              COMPUTE WS-COMM-LIFE ROUNDED = GCSL-COMMISSION                    
                                           * WS-ANN-PREM-LIFE                   
                                           / WS-TOTAL-PREM-LIFE-A-S             
              COMPUTE WS-COMM-A-S ROUNDED  = GCSL-COMMISSION                    
                                           * WS-ANN-PREM-A-S                    
                                           / WS-TOTAL-PREM-LIFE-A-S.            
       1799-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1800-LTD-SCALE-CALC.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  USE THE RENEWAL DATE AND THE SCALE TO DETERMINE THE          *         
      *  POINT-IN-SCALE.  CALL GFMSCALE TO DO THE CALCULATION.        *         
      *  THE COMMISSION AMOUNT CALCULATED IS THE COMMISSION AMOUNT    *         
      *  FOR LTD.                                                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *    MOVE WS-LTD-SCALE TO WS-GFMSCALE-CODE.                               
           MOVE WS-LTD-SCALE TO GCSL-SCALE-CODE.                                
           MOVE WS-RENEW-DATE TO NEXT-RENEW-DATE.                               
           MOVE WS-LTD-SCALE TO COMM-SCALE.                                     
           PERFORM 2000-GET-ADV-POINT-IN-SCALE.                                 
      *    MOVE PSM-PREM-ADV OF GWCORADVPSM TO WS-GFMSCALE-BASE.                
           MOVE PSM-PREM-ADV OF GWCORADVPSM TO GCSL-BASE-PREMIUM.               
      *    MOVE WS-TOTAL-PREM-LTD TO WS-GFMSCALE-PREM.                          
           MOVE WS-TOTAL-PREM-LTD TO GCSL-CURR-PREMIUM.                         
      *    MOVE ZERO TO WS-GFMSCALE-COMM                                        
      *                 WS-GFMSCALE-RATE                                        
      *                 WS-GFMSCALE-REMPREM.                                    
      *    CALL 'GFMSCALE' USING WS-GFMSCALE-PARMS.                             
      *    MOVE WS-GFMSCALE-COMM TO WS-COMM-LTD.                                
                                                                                
      *                                                                         
           MOVE 'R'          TO  GCSL-CALL-TYPE.                                
FXXTOK     CALL  GC2LCOMM    USING  GCSLPARM                                    
                                    GTABCOMM-RECORD.                            
           MOVE +0              TO  GCSL-COMMISSION.                            
           IF  GCSL-RET-SUCCESS                                                 
FXXTOK         CALL  GC2LCALC    USING  GCSL-CALC-PARMS                         
                                        GTABCOMM-RECORD.                        
           MOVE GCSL-COMMISSION  TO WS-COMM-LTD.                                
      *                                                                         
       1899-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       1900-CALC-SALES-CREDITS.                                                 
      * *********************************************************               
      *  USE GTABSC TO FIND COMMISSION SCALE TO BE USED         *               
      * *********************************************************               
           MOVE 'N'                     TO GSC-FIND-FACTOR.                     
                                                                                
           PERFORM 4000-FIND-SALES-CREDITS THRU 4000-EXIT.                      
                                                                                
           MOVE GSC-RET-SCALE    TO GCSL-SCALE-CODE.                            
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  USE THE LAST RENEWAL DATE AND SCALE 'SCR' TO DETERMINE       *         
      *  WHAT POINT-IN-SCALE TO USE FOR SALES CREDITS.  CALL GFMSCALE *         
      *  WITH SCALE '001' TO GET THE COMMISSION AMOUNT AND MULTIPLY   *         
      *  THIS AMOUNT BY 2 TO GET THE SALES CREDIT AMOUNT.             *         
      *  PRO-RATE THE TOTAL SALES CREDIT AMOUNT CALCULATED            *         
      *  TO DETERMINE THE SALES CREDIT AMOUNT FOR LIFE, LTD AND A&S.  *         
      *  THESE AMOUNTS ARE ROUNDED TO THE NEARED DOLLAR.              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *    MOVE '001' TO WS-GFMSCALE-CODE.                                      
      *    MOVE +1 TO WS-GFMSCALE-POLYR.                                        
           MOVE +1 TO GCSL-START-YEAR.                                          
           MOVE WS-RENEW-DATE TO NEXT-RENEW-DATE.                               
           MOVE 'SCR' TO COMM-SCALE.                                            
           PERFORM 2000-GET-ADV-POINT-IN-SCALE.                                 
      *    MOVE PSM-PREM-ADV OF GWCORADVPSM TO WS-GFMSCALE-BASE.                
           MOVE PSM-PREM-ADV OF GWCORADVPSM TO GCSL-BASE-PREMIUM.               
                                                                                
           COMPUTE WS-TOTAL-PREM-ALL-SC = WS-ANN-PREM-LIFE-SC                   
                                        + WS-ANN-PREM-LTD-SC                    
                                        + WS-ANN-PREM-A-S-SC.                   
      *    MOVE WS-TOTAL-PREM-ALL-SC TO WS-GFMSCALE-PREM.                       
           MOVE WS-TOTAL-PREM-ALL-SC TO GCSL-CURR-PREMIUM.                      
      *    MOVE ZERO TO WS-GFMSCALE-COMM                                        
      *                 WS-GFMSCALE-RATE                                        
      *                 WS-GFMSCALE-REMPREM.                                    
      *    CALL 'GFMSCALE' USING WS-GFMSCALE-PARMS.                             
      *                                                                         
           MOVE 'R'          TO  GCSL-CALL-TYPE.                                
FXXTOK     CALL  GC2LCOMM    USING  GCSLPARM                                    
                                    GTABCOMM-RECORD.                            
           MOVE +0              TO  GCSL-COMMISSION.                            
           IF  GCSL-RET-SUCCESS                                                 
FXXTOK         CALL  GC2LCALC    USING  GCSL-CALC-PARMS                         
                                        GTABCOMM-RECORD.                        
      * *********************************************************               
      *  USE GTABSC TO FIND COMMISSION SCALE TO BE USED         *               
      * *********************************************************               
           MOVE 'Y'            TO GSC-FIND-FACTOR.                              
           PERFORM 4000-FIND-SALES-CREDITS THRU 4000-EXIT.                      
                                                                                
      *    COMPUTE WS-GFMSCALE-COMM = WS-GFMSCALE-COMM * 2.                     
           COMPUTE GCSL-COMMISSION  = GCSL-COMMISSION *                         
                                      GSC-RET-RN-CURR-FACTOR.                   
                                                                                
           IF WS-TOTAL-PREM-ALL-SC = ZERO                                       
              MOVE ZERO TO WS-SC-LIFE                                           
                           WS-SC-LTD                                            
                           WS-SC-A-S                                            
           ELSE                                                                 
              COMPUTE WS-SC-LIFE ROUNDED = GCSL-COMMISSION                      
                                         * WS-ANN-PREM-LIFE-SC                  
                                         / WS-TOTAL-PREM-ALL-SC                 
              COMPUTE WS-SC-LTD ROUNDED  = GCSL-COMMISSION                      
                                         * WS-ANN-PREM-LTD-SC                   
                                         / WS-TOTAL-PREM-ALL-SC                 
              COMPUTE WS-SC-A-S ROUNDED  = GCSL-COMMISSION                      
                                         * WS-ANN-PREM-A-S-SC                   
                                         / WS-TOTAL-PREM-ALL-SC.                
       1999-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2000-GET-ADV-POINT-IN-SCALE.                                             
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  GET POINT-IN-SCALE FROM COMMISSION DATA BASE.                *         
      *  IF THIS IS A FIRST YEAR CALCULATION, THERE SHOULD BE A       *         
      *  POINT-IN-SCALE RECORD AVAILABLE. IF NOT, PRINT AN EXCEPTION  *         
      *  MESSAGE.  FOR A RENEWAL CALCULATION, THERE WILL NOT BE A     *         
      *  POINT-IN-SCALE RECORD AVAILABLE IF THIS IS THE FIRST GROUP/  *         
      *  ACCOUNT RENEWING FOR THE GROUP.                              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   FIND CURRENT GWCORGROUP.                                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   OBTAIN GWCORADVPSM WITHIN GROUP-ADVPSM                               
      *%       USING GROUP-ADV-KEY                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 11 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +8  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-ALT-KEY                               
MAN02                 FCCSPLIO-GWCORADVPSM                                      
MAN02                 FCCSPL-GWCORADVPSM                                        
MAN02                 FCCSPL-GROUP-ADVPSM                                       
MAN02                 GWCORADVPSM                                               
MAN02                 GROUP-ADV-KEY                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE ZERO TO PSM-PREM-ADV OF GWCORADVPSM.                     
                                                                                
       2099-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2100-INIT-NAP-RECORD.                                                    
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INITIALIZE NAP RECORD WITH GROUP/ACCOUNT INFORMATION.        *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'P' TO GNAP-RECORD-TYPE.                                        
           MOVE GROUP-NUMBER OF GWCORGRACCT TO GNAP-GROUP.                      
           MOVE GR-ACCOUNT OF GWCORGRACCT TO GNAP-ACCOUNT.                      
           MOVE GGIFOGL-CODE (1) TO GNAP-FOGL-CODE.                             
           CALL 'GZNAEXP7' USING GBNBILLING-NAME-ADDRESS                        
                                 WS-GZNAEXP7-PARMS                              
                                 WS-EXP-ERROR-CODE.                             
           IF WS-EXP-ERROR-CODE NOT EQUAL SPACES                                
               MOVE SPACES TO WS-GZNAEXP7-PARMS.                                
                                                                                
           MOVE WS-EXP-NAME (1) TO GNAP-GROUP-NAME.                             
                                                                                
       2199-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2200-INIT-CR-RECORD.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INITIALIZE THE COMMISSION RELEASE RECORD WITH GROUP/ACCOUNT  *         
      *  INFORMATION.                                                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'W' TO GCRL-RECORD-TYPE.                                        
           MOVE GROUP-NUMBER OF GWCORGRACCT TO GCRL-KEY-GROUP.                  
           MOVE GR-ACCOUNT OF GWCORGRACCT TO GCRL-KEY-ACCOUNT.                  
           MOVE '1' TO GCRL-VLNO.                                               
           MOVE GROUP-NUMBER OF GWCORGRACCT TO GCRL-GROUP.                      
                                                                                
           IF GGICURRENCY EQUAL TO '1'                                          
               MOVE +1 TO GCRL-CURRENCY                                         
           ELSE                                                                 
           IF GGICURRENCY EQUAL TO '2'                                          
               MOVE +2 TO GCRL-CURRENCY                                         
           ELSE                                                                 
           IF GGICURRENCY EQUAL TO '8'                                          
               MOVE +10 TO GCRL-CURRENCY                                        
           ELSE                                                                 
           IF GGICURRENCY EQUAL TO '7'                                          
               MOVE +35 TO GCRL-CURRENCY                                        
           ELSE                                                                 
           IF GGICURRENCY EQUAL TO '5'                                          
               MOVE +48 TO GCRL-CURRENCY                                        
           ELSE                                                                 
               MOVE +19 TO WS-ERROR-NUMBER                                      
               PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT                     
               MOVE ZERO TO GCRL-CURRENCY.                                      
                                                                                
           MOVE '12' TO GCRL-MODE.                                              
                                                                                
CHG        MOVE GGI-ACCT-EFF-YEAR TO TEMP-FIND-CENTURY.                         
CHG        IF TEMP-CENTURY = 0                                                  
CHG           MOVE 18             TO GCRL-EFF-CC                                
CHG        ELSE                                                                 
CHG           IF TEMP-CENTURY = 1                                               
CHG              MOVE 19             TO GCRL-EFF-CC                             
CHG           ELSE                                                              
CHG              MOVE 20             TO GCRL-EFF-CC.                            
CHG                                                                             
MAN02      CALL QDATEQ2 USING QDATE-FORMATAB                                    
MAN02                         GGI-ACCT-EFFECTIVE                                
MAN02                         TEMP-DATE.                                        
CHG                                                                             
CHG        MOVE TEMP-YY          TO GCRL-EFF-YY.                                
CHG        MOVE TEMP-MM          TO GCRL-EFF-MM.                                
CHG        MOVE TEMP-DD          TO GCRL-EFF-DD.                                
CHG                                                                             
           CALL 'GZNAEXP7' USING GBNBILLING-NAME-ADDRESS                        
                                 WS-GZNAEXP7-PARMS                              
                                 WS-EXP-ERROR-CODE.                             
           IF WS-EXP-ERROR-CODE NOT EQUAL SPACES                                
               MOVE SPACES TO WS-GZNAEXP7-PARMS.                                
           MOVE WS-EXP-NAME (1) TO GCRL-BILLING-NAME.                           
CHG        MOVE RENEWAL-EFFECTIVE-YEAR TO TEMP-FIND-CENTURY.                    
CHG        IF TEMP-CENTURY = 0                                                  
CHG           MOVE 18             TO GCRL-PREM-CC                               
CHG        ELSE                                                                 
CHG           IF TEMP-CENTURY = 1                                               
CHG              MOVE 19             TO GCRL-PREM-CC                            
CHG           ELSE                                                              
CHG              MOVE 20             TO GCRL-PREM-CC.                           
CHG                                                                             
MAN02      CALL QDATEQ2 USING QDATE-FORMATAB                                    
MAN02                         RENEWAL-EFFECTIVE-DATE                            
MAN02                         TEMP-DATE.                                        
CHG                                                                             
CHG        MOVE TEMP-YY          TO GCRL-PREM-YY.                               
CHG        MOVE TEMP-MM          TO GCRL-PREM-MM.                               
CHG        MOVE TEMP-DD          TO GCRL-PREM-DD.                               
CHG                                                                             
           MOVE GR-ACCOUNT OF GWCORGRACCT TO TEMP-ACCT.                         
           MOVE TEMP-ACCOUNT              TO GCRL-SUB-ACCOUNT.                  
           MOVE 10                        TO GCRL-SOURCE.                       
                                                                                
       2299-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2300-INIT-COMP-RECORD.                                                   
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INITIALIZE THE DATA BASE HISTORY RECORD WITH GROUP/ACCOUNT   *         
      *  INFORMATION.                                                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GROUP-ACCOUNT OF GWCORGRACCT TO                                 
                GROUP-ACCOUNT OF GWCORCOMP.                                     
           MOVE RENEWAL-EFFECTIVE-DATE TO COMP-EFF-DATE.                        
           MOVE WS-ALIS-RUN-DATE TO COMP-PROCESS-DATE.                          
           MOVE 'Y' TO RECON-IND.                                               
           MOVE 'P' TO COMP-DISP.                                               
                                                                                
       2399-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2400-AGENT-SPLIT.                                                        
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  IF THE GROUP-ACCOUNT USES A FLAT RATE, CALCULATE COMMISSION  *         
      *  USING THE AGENT'S FLAT RATE.                                 *         
      *  IF THIS IS A CSP GROUP, ONLY ADVANCE 90% OF THE COMMISSION   *         
      *  AMOUNT.                                                      *         
      *  IF THIS IS A FY CALCULATION AND THE AGENT HAS A              *         
      *  ANNUALIZED COMMISSION INDICATOR, INVOKE LOGIC TO ADVANCE     *         
      *  COMMISSIONS, SALES CREDITS, AND NAPS.                        *         
      *  IF THIS IS A FY CALCULATION AND THE AGENT HAS A              *         
      *  'NO COMMISSION' INDICATOR, INVOKE LOGIC TO ADVANCE SALES     *         
      *  CREDITS AND NAPS ONLY.                                       *         
      *  IF THIS IS A RENEWAL CALCULATION, INVOKE LOGIC TO ADVANCE    *         
      *  COMMISSIONS ONLY.                                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF FLAT-RATE-CALC                                                    
               COMPUTE WS-COMM-LIFE ROUNDED = WS-ANN-PREM-LIFE                  
                                  * WS-AGT-REG-RATE (WS-AGT-INDEX)              
                                  / 100                                         
               COMPUTE WS-COMM-LTD ROUNDED = WS-ANN-PREM-LTD                    
                                  * WS-AGT-LTD-RATE (WS-AGT-INDEX)              
                                  / 100                                         
               COMPUTE WS-COMM-A-S ROUNDED = WS-ANN-PREM-A-S                    
                                  * WS-AGT-REG-RATE (WS-AGT-INDEX)              
                                  / 100                                         
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
      ***************************************************                       
      * SALES CREDITS ARE ALWAYS ADVANCED WHETHER FY OR *                       
      * RN           MAY92 A.NIKELSKI                   *                       
      ***************************************************                       
           PERFORM 2600-ADVANCE-SALES-CREDITS.                                  
                                                                                
           IF COMP-REASON EQUAL TO 'F'                                          
               PERFORM 2700-ADVANCE-NAPS.                                       
                                                                                
           IF  WS-PAY-BASIS (WS-AGT-INDEX) EQUAL TO 'A'                         
           AND WS-COMM-IND (WS-AGT-INDEX) EQUAL TO 'Y'                          
               PERFORM 2500-ADVANCE-COMMISSIONS                                 
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       2499-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2500-ADVANCE-COMMISSIONS.                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INITIALIZE THE DATA BASE HISTORY RECORD WITH AGENT           *         
      *  INFORMATION.                                                 *         
      *  FOR EACH COMMISSION AMOUNT GREATER THAN ZERO,                *         
      *    SPLIT USING AGENT SPLIT                                    *         
      *    INVOKE LOGIC TO GET AGENT RECORD IN DATA BASE              *         
      *    STORE HISTORY RECORD IN DATA BASE                          *         
      *    INVOKE LOGIC TO WRITE A COMMISSION RELEASE RECORD TO TRANS *         
      *      RECORD IN DATA BASE.                                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE WS-AGENT-CODE (WS-AGT-INDEX) TO                                 
               AGENT-NUMBER OF GWCORCOMP.                                       
           MOVE SPACES TO GFO-NUMBER OF GWCORCOMP.                              
           MOVE ZERO TO GROUP-REP.                                              
           MOVE 'C' TO COMP-TYPE.                                               
                                                                                
           IF WS-COMM-LIFE GREATER THAN ZERO                                    
               COMPUTE COMP-AMT ROUNDED = WS-COMM-LIFE                          
                                  * WS-LIFE-PERCENT (WS-AGT-INDEX)              
                                  / 100                                         
               MOVE WS-LIFE-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT               
               COMPUTE WS-AGT-RATE ROUNDED =                                    
                       WS-AGT-REG-RATE (WS-AGT-INDEX) * +1                      
               MOVE 'T' TO COV-TYPE OF GWCORCOMP                                
               MOVE WS-ANN-PREM-LIFE TO PREM-AMT                                
               MOVE AGENT-NUMBER OF GWCORCOMP TO                                
                    AGENT-NUMBER OF GWCORAGENT                                  
               PERFORM 2800-GET-AGENT                                           
      *%       STORE GWCORCOMP                                                  
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 12 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORCOMP                                    
MAN02                     FCCSPL-GWCORCOMP                                      
MAN02                     GWCORCOMP                                             
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               PERFORM 3000-CREATE-CR-RECORD.                                   
                                                                                
           IF WS-COMM-LTD GREATER THAN ZERO                                     
               COMPUTE COMP-AMT ROUNDED = WS-COMM-LTD                           
                                  * WS-LTD-PERCENT (WS-AGT-INDEX)               
                                  / 100                                         
               MOVE WS-LTD-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT                
               COMPUTE WS-AGT-RATE ROUNDED =                                    
                       WS-AGT-LTD-RATE (WS-AGT-INDEX) * +1                      
               MOVE 'L' TO COV-TYPE OF GWCORCOMP                                
               MOVE WS-ANN-PREM-LTD TO PREM-AMT                                 
               MOVE AGENT-NUMBER OF GWCORCOMP TO                                
                    AGENT-NUMBER OF GWCORAGENT                                  
               PERFORM 2800-GET-AGENT                                           
      *%       STORE GWCORCOMP                                                  
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 13 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORCOMP                                    
MAN02                     FCCSPL-GWCORCOMP                                      
MAN02                     GWCORCOMP                                             
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               PERFORM 3000-CREATE-CR-RECORD.                                   
                                                                                
           IF WS-COMM-A-S GREATER THAN ZERO                                     
               COMPUTE COMP-AMT ROUNDED = WS-COMM-A-S                           
                                  * WS-A-S-PERCENT (WS-AGT-INDEX)               
                                  / 100                                         
               MOVE WS-A-S-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT                
               COMPUTE WS-AGT-RATE ROUNDED =                                    
                       WS-AGT-REG-RATE (WS-AGT-INDEX) * +1                      
               MOVE 'O' TO COV-TYPE OF GWCORCOMP                                
               MOVE WS-ANN-PREM-A-S TO PREM-AMT                                 
               MOVE AGENT-NUMBER OF GWCORCOMP TO                                
                    AGENT-NUMBER OF GWCORAGENT                                  
               PERFORM 2800-GET-AGENT                                           
      *%       STORE GWCORCOMP                                                  
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 14 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORCOMP                                    
MAN02                     FCCSPL-GWCORCOMP                                      
MAN02                     GWCORCOMP                                             
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               PERFORM 3000-CREATE-CR-RECORD.                                   
                                                                                
       2599-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2600-ADVANCE-SALES-CREDITS.                                              
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INITIALIZE THE DATA BASE HISTORY RECORD WITH AGENT           *         
      *  INFORMATION.                                                 *         
      *  FOR EACH SALES CREDIT AMOUNT GREATER THAN ZERO,              *         
      *    SPLIT USING AGENT SPLIT                                    *         
      *    INVOKE LOGIC TO GET AGENT RECORD IN DATA BASE              *         
      *    STORE HISTORY RECORD IN DATA BASE                          *         
      *    INVOKE LOGIC TO WRITE A COMMISSION RELEASE RECORD TO TRANS *         
      *      RECORD IN DATA BASE.                                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE WS-AGENT-CODE (WS-AGT-INDEX) TO                                 
               AGENT-NUMBER OF GWCORCOMP.                                       
           MOVE SPACES TO GFO-NUMBER OF GWCORCOMP.                              
           MOVE ZERO TO GROUP-REP.                                              
           MOVE 'S' TO COMP-TYPE.                                               
                                                                                
           COMPUTE WS-AGT-SC ROUNDED = WS-SC-LIFE                               
                              * WS-LIFE-PERCENT (WS-AGT-INDEX)                  
                              / 100.                                            
           IF WS-AGT-SC GREATER THAN ZERO                                       
               MOVE WS-AGT-SC TO COMP-AMT                                       
               MOVE WS-LIFE-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT               
               COMPUTE WS-AGT-RATE ROUNDED =                                    
                       WS-AGT-REG-RATE (WS-AGT-INDEX) * +1                      
               MOVE 'T' TO COV-TYPE OF GWCORCOMP                                
               MOVE WS-ANN-PREM-LIFE-SC TO PREM-AMT                             
               MOVE AGENT-NUMBER OF GWCORCOMP TO                                
                    AGENT-NUMBER OF GWCORAGENT                                  
               PERFORM 2800-GET-AGENT                                           
      *%       STORE GWCORCOMP                                                  
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 15 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORCOMP                                    
MAN02                     FCCSPL-GWCORCOMP                                      
MAN02                     GWCORCOMP                                             
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               PERFORM 3000-CREATE-CR-RECORD.                                   
                                                                                
           COMPUTE WS-AGT-SC ROUNDED = WS-SC-LTD                                
                              * WS-LTD-PERCENT (WS-AGT-INDEX)                   
                              / 100.                                            
           IF WS-AGT-SC GREATER THAN ZERO                                       
               MOVE WS-AGT-SC TO COMP-AMT                                       
               MOVE WS-LTD-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT                
               COMPUTE WS-AGT-RATE ROUNDED =                                    
                       WS-AGT-LTD-RATE (WS-AGT-INDEX) * +1                      
               MOVE 'L' TO COV-TYPE OF GWCORCOMP                                
               MOVE WS-ANN-PREM-LTD-SC TO PREM-AMT                              
               MOVE AGENT-NUMBER OF GWCORCOMP TO                                
                    AGENT-NUMBER OF GWCORAGENT                                  
               PERFORM 2800-GET-AGENT                                           
      *%       STORE GWCORCOMP                                                  
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 16 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORCOMP                                    
MAN02                     FCCSPL-GWCORCOMP                                      
MAN02                     GWCORCOMP                                             
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               PERFORM 3000-CREATE-CR-RECORD.                                   
                                                                                
           COMPUTE WS-AGT-SC ROUNDED = WS-SC-A-S                                
                              * WS-A-S-PERCENT (WS-AGT-INDEX)                   
                              / 100.                                            
           IF WS-AGT-SC GREATER THAN ZERO                                       
               MOVE WS-AGT-SC TO COMP-AMT                                       
               MOVE WS-A-S-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT                
               COMPUTE WS-AGT-RATE ROUNDED =                                    
                       WS-AGT-REG-RATE (WS-AGT-INDEX) * +1                      
               MOVE 'O' TO COV-TYPE OF GWCORCOMP                                
               MOVE WS-ANN-PREM-A-S-SC TO PREM-AMT                              
               MOVE AGENT-NUMBER OF GWCORCOMP TO                                
                    AGENT-NUMBER OF GWCORAGENT                                  
               PERFORM 2800-GET-AGENT                                           
      *%       STORE GWCORCOMP                                                  
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 17 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORCOMP                                    
MAN02                     FCCSPL-GWCORCOMP                                      
MAN02                     GWCORCOMP                                             
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               PERFORM 3000-CREATE-CR-RECORD.                                   
                                                                                
       2699-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2700-ADVANCE-NAPS.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INITIALIZE THE DATA BASE HISTORY RECORD WITH AGENT           *         
      *  INFORMATION.                                                 *         
      *  SPLIT NAP AMOUNT USING THE FIRST AGENT SPLIT WHICH IS GREATER*         
      *  THAN ZERO.                                                   *         
      *  SET HISTORY RECORD UP AS IF THERE IS ONLY ONE GFO            *         
      *  INVOKE LOGIC TO GET AGENT RECORD IN THE DATA BASE            *         
      *  IF THERE IS ONLY ONE GFO                                     *         
      *    INVOKE LOGIC TO GET THE GFO IN THE DATA BASE               *         
      *    STORE THE HISTORY RECORD IN THE DATA BASE                  *         
      *    CONNECT THE GFO TO THE HISTORY RECORD                      *         
      *    INVOKE LOGIC TO CREATE A NAP RECORD AND STORE IN THE TRANS *         
      *      RECORD IN THE DATA BASE.                                 *         
      *  IF THERE ARE 2 GFO'S, DIVIDE THE AMOUNT BY 2 AND REPEAT THE  *         
      *  THE LOGIC AS ABOVE FOR EACH GFO.                             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE WS-AGENT-CODE (WS-AGT-INDEX) TO                                 
               AGENT-NUMBER OF GWCORCOMP.                                       
           MOVE 'N' TO COMP-TYPE.                                               
           MOVE '#' TO COV-TYPE OF GWCORCOMP.                                   
                                                                                
           MOVE ZERO TO WS-AGT-NAP.                                             
                                                                                
           IF WS-LIFE-PERCENT (WS-AGT-INDEX) GREATER THAN ZERO                  
               COMPUTE WS-AGT-NAP ROUNDED = WS-ANN-PREM-NAP                     
                                 * WS-LIFE-PERCENT (WS-AGT-INDEX)               
                                 / 100                                          
               MOVE WS-LIFE-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT               
           ELSE                                                                 
               IF WS-LTD-PERCENT (WS-AGT-INDEX) GREATER THAN ZERO               
                   COMPUTE WS-AGT-NAP ROUNDED = WS-ANN-PREM-NAP                 
                                     * WS-LTD-PERCENT (WS-AGT-INDEX)            
                                     / 100                                      
                   MOVE WS-LTD-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT            
               ELSE                                                             
                   COMPUTE WS-AGT-NAP ROUNDED = WS-ANN-PREM-NAP                 
                                     * WS-LTD-PERCENT (WS-AGT-INDEX)            
                                     / 100                                      
                   MOVE WS-A-S-PERCENT (WS-AGT-INDEX) TO AGENT-SPLIT.           
                                                                                
           IF WS-AGT-NAP GREATER THAN ZERO                                      
               MOVE GGIGROUP-OFFICE TO GFO-NUMBER OF GWCORCOMP                  
               MOVE GGIGROUP-REP TO  GROUP-REP OF GWCORCOMP                     
               MOVE WS-AGT-NAP TO COMP-AMT                                      
               MOVE WS-ANN-PREM-NAP TO PREM-AMT                                 
               MOVE AGENT-NUMBER OF GWCORCOMP TO                                
                    AGENT-NUMBER OF GWCORAGENT                                  
               PERFORM 2800-GET-AGENT                                           
               IF GGISHARING-OFFICE EQUAL TO '00000' OR SPACES                  
                   MOVE GFO-NUMBER OF GWCORCOMP TO                              
                        GFO-NUMBER OF GWCORGFO                                  
                   PERFORM 2900-GET-GFO                                         
      *%           STORE GWCORCOMP                                              
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 18 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +4  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-INSERT                                     
MAN02                         FCCSPLIO-GWCORCOMP                                
MAN02                         FCCSPL-GWCORCOMP                                  
MAN02                         GWCORCOMP                                         
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
      *%           CONNECT GWCORCOMP TO GFO-COMP                                
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 19 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +5  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-CREATE-RELATIONSHIP                        
MAN02                         FCCSPLIO-GWCORCOMP                                
MAN02                         FCCSPL-GWCORCOMP                                  
MAN02                         FCCSPL-GFO-COMP                                   
MAN02                         GWCORCOMP                                         
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
                   PERFORM 3100-CREATE-NAP-RECORD                               
               ELSE                                                             
                   COMPUTE COMP-AMT ROUNDED = COMP-AMT / 2                      
                   MOVE GFO-NUMBER OF GWCORCOMP TO                              
                        GFO-NUMBER OF GWCORGFO                                  
                   PERFORM 2900-GET-GFO                                         
      *%           STORE GWCORCOMP                                              
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 20 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +4  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-INSERT                                     
MAN02                         FCCSPLIO-GWCORCOMP                                
MAN02                         FCCSPL-GWCORCOMP                                  
MAN02                         GWCORCOMP                                         
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
      *%           CONNECT GWCORCOMP TO GFO-COMP                                
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 21 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +5  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-CREATE-RELATIONSHIP                        
MAN02                         FCCSPLIO-GWCORCOMP                                
MAN02                         FCCSPL-GWCORCOMP                                  
MAN02                         FCCSPL-GFO-COMP                                   
MAN02                         GWCORCOMP                                         
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
                   PERFORM 3100-CREATE-NAP-RECORD                               
                   MOVE GGISHARING-OFFICE TO GFO-NUMBER OF GWCORCOMP            
                   MOVE GGIGROUP-REP2 TO GROUP-REP OF GWCORCOMP                 
                   MOVE GFO-NUMBER OF GWCORCOMP TO                              
                        GFO-NUMBER OF GWCORGFO                                  
                   PERFORM 2900-GET-GFO                                         
      *%           STORE GWCORCOMP                                              
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 22 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +4  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-INSERT                                     
MAN02                         FCCSPLIO-GWCORCOMP                                
MAN02                         FCCSPL-GWCORCOMP                                  
MAN02                         GWCORCOMP                                         
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
      *%           CONNECT GWCORCOMP TO GFO-COMP                                
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 23 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +5  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-CREATE-RELATIONSHIP                        
MAN02                         FCCSPLIO-GWCORCOMP                                
MAN02                         FCCSPL-GWCORCOMP                                  
MAN02                         FCCSPL-GFO-COMP                                   
MAN02                         GWCORCOMP                                         
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
                   PERFORM 3100-CREATE-NAP-RECORD.                              
                                                                                
       2799-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2800-GET-AGENT.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   GET AGENT RECORD IN DATA BASE.                              *         
      *   STORE IF RECORD DOES NOT EXIST.                             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   OBTAIN CALC GWCORAGENT                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 24 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      *%           STORE GWCORAGENT.                                            
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 25 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +4  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-INSERT                                     
MAN02                         FCCSPLIO-GWCORAGENT                               
MAN02                         FCCSPL-GWCORAGENT                                 
MAN02                         GWCORAGENT                                        
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT.                                 
                                                                                
       2899-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       2900-GET-GFO.                                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   GET GTO RECORD IN DATA BASE.                                *         
      *   STORE IF RECORD DOES NOT EXIST.                             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   OBTAIN CALC GWCORGFO                                                 
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 26 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGFO                                         
MAN02                 FCCSPL-GWCORGFO                                           
MAN02                 GWCORGFO                                                  
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      *%           STORE GWCORGFO.                                              
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 27 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +4  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-INSERT                                     
MAN02                         FCCSPLIO-GWCORGFO                                 
MAN02                         FCCSPL-GWCORGFO                                   
MAN02                         GWCORGFO                                          
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT.                                 
                                                                                
       2999-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       3000-CREATE-CR-RECORD.                                                   
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   SET UP THE COMMISSION RELEASE RECORD AND STORE IN THE       *         
      *   TRANS RECORD IN THE DATA BASE.                              *         
      *   JUN/98 REMOVED ALPHA SPECIFIC EDIT                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF COMP-REASON EQUAL TO 'F'                                          
               MOVE '1' TO GCRL-PREMNO                                          
           ELSE                                                                 
               MOVE '13' TO GCRL-PREMNO.                                        
                                                                                
           MOVE AGENT-NUMBER OF GWCORCOMP TO GCRL-KEY-AGENT.                    
                                                                                
      **************************************************                        
      * CHANGE 10OCT90 - ANITA NIKELSKI                                         
      **************************************************                        
           IF COV-TYPE OF GWCORCOMP = 'L'                                       
              MOVE WS-AGT-LTD-SCALE (WS-AGT-INDEX) TO GCRL-SCALE                
           ELSE                                                                 
              IF COV-TYPE OF GWCORCOMP = 'O' OR 'T'                             
                 MOVE WS-AGT-REG-SCALE (WS-AGT-INDEX) TO GCRL-SCALE             
              ELSE                                                              
                 MOVE SPACES                          TO GCRL-SCALE.            
      **************************************************                        
                                                                                
           IF COV-TYPE OF GWCORCOMP = 'T'                                       
               MOVE GGIFOGL-CODE (1) TO WS-FOGL-CODE                            
           ELSE                                                                 
               IF COV-TYPE OF GWCORCOMP = 'L'                                   
                   MOVE GGIFOGL-CODE (3) TO WS-FOGL-CODE                        
               ELSE                                                             
                   IF COV-TYPE OF GWCORCOMP = 'O'                               
                       MOVE GGIFOGL-CODE (5) TO WS-FOGL-CODE                    
                       MOVE '07' TO WS-FOGL-3-4                                 
                   ELSE                                                         
                       MOVE +20 TO WS-ERROR-NUMBER                              
                       PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT             
                       MOVE SPACES TO WS-FOGL-CODE.                             
                                                                                
           MOVE WS-FOGL-CODE TO GCRL-FOGL-CODE.                                 
                                                                                
           IF  WS-FOGL-7 = '1' OR '2'                                           
               MOVE +990 TO GCRL-MAN                                            
           ELSE                                                                 
               MOVE +991 TO GCRL-MAN.                                           
                                                                                
           MOVE GGIGROUP-OFFICE TO GCRL-BRANCH.                                 
                                                                                
           MOVE AGENT-NUMBER OF GWCORCOMP TO GCRL-AGENT-CODE.                   
                                                                                
      *    MOVE GGIGROUP-OFFICE TO FOF-BRANCH-NUMBER.                           
                                                                                
MAN02 *%   OBTAIN CALC FIELD-OFFICE                                             
MAN02      PERFORM 9005-OBTAIN-FIELD-OFFICE                                     
MAN02         THRU 9005-OBTAIN-FIELD-OFFICE-EXIT.                               
MAN02 *        IF  DB-REC-NOT-FOUND                                             
      *            MOVE ZERO TO FOF-MLI-MANAGER-CODE.                           
      *                                                                         
      *    MOVE FOF-MLI-MANAGER-CODE TO GCRL-MGR.                               
                                                                                
           MOVE AGENT-SPLIT OF GWCORCOMP TO GCRL-SHARE.                         
           MOVE +1                       TO VAR-SUB.                            
                                                                                
           IF COMP-TYPE EQUAL TO 'C' AND COMP-REASON EQUAL TO 'R'               
               IF WS-POLICY-YEAR > +2                                           
                   MOVE +131 TO GCRL-CODE (VAR-SUB)                             
               ELSE                                                             
                   MOVE +121 TO GCRL-CODE (VAR-SUB)                             
           ELSE                                                                 
               IF COMP-TYPE EQUAL TO 'C' AND COMP-REASON EQUAL TO 'F'           
                   MOVE +113 TO GCRL-CODE (VAR-SUB)                             
               ELSE                                                             
                   IF COMP-TYPE EQUAL TO 'S' AND                                
                      COMP-REASON EQUAL TO 'F'                                  
                       MOVE +141 TO GCRL-CODE (VAR-SUB)                         
                   ELSE                                                         
                      IF COMP-TYPE EQUAL TO 'S' AND                             
                         COMP-REASON EQUAL TO 'R'                               
                          MOVE +142 TO GCRL-CODE (VAR-SUB)                      
                       ELSE                                                     
                           MOVE +21 TO WS-ERROR-NUMBER                          
                           PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT         
                           MOVE ZERO TO GCRL-CODE (VAR-SUB).                    
                                                                                
           MOVE +0                   TO GCRL-CMAMT (2)                          
                                        GCRL-CODE  (2)                          
                                        GCRL-CMAMT (3)                          
                                        GCRL-CODE  (3).                         
                                                                                
           IF COMP-TYPE = 'S'                                                   
              MOVE COMP-AMT TO GCRL-CRAMT (VAR-SUB)                             
           ELSE                                                                 
              MOVE COMP-AMT TO GCRL-CMAMT (VAR-SUB).                            
           MOVE +341                 TO GCRL-CAUSE.                             
                                                                                
           IF PREM-AMT NOT = +0                                                 
              MOVE +2                      TO VAR-SUB                           
              COMPUTE GCRL-CMAMT (VAR-SUB) = PREM-AMT                           
              IF GWCOEGPB-AGENT-PAY-BASIS-RN = 'A'                              
                 MOVE +107                 TO GCRL-CODE  (VAR-SUB)              
              ELSE                                                              
                 MOVE +108                 TO GCRL-CODE  (VAR-SUB).             
                                                                                
      *************************************************                         
      * OCT CHANGE A. NIKELSKI                                                  
      *************************************************                         
           IF COV-TYPE OF GWCORCOMP = 'L' OR 'O' OR 'T'                         
              IF GCRL-SCALE = SPACES                                            
                 IF VAR-SUB = +1                                                
                    MOVE +2                  TO VAR-SUB                         
                 ELSE                                                           
                    MOVE +3                  TO VAR-SUB.                        
                                                                                
           IF COV-TYPE OF GWCORCOMP = 'L'                                       
              IF GCRL-SCALE = SPACES                                            
                 MOVE +109                 TO GCRL-CODE  (VAR-SUB)              
                 MOVE WS-TEMP-LTD-RATE     TO GCRL-CPAMT (VAR-SUB)              
              ELSE                                                              
                 NEXT SENTENCE                                                  
           ELSE                                                                 
              IF COV-TYPE OF GWCORCOMP = 'O' OR 'T'                             
                 IF GCRL-SCALE = SPACES                                         
                    MOVE +109              TO GCRL-CODE  (VAR-SUB)              
                    MOVE WS-TEMP-REG-RATE  TO GCRL-CPAMT (VAR-SUB).             
                                                                                
           MOVE VAR-SUB         TO GCRL-VLNO.                                   
      **************************************************                        
                                                                                
           MOVE 'CR' TO TRANS-TYPE.                                             
           MOVE GCOMRLSE TO TRANS-DETAILS.                                      
           MOVE -1 TO DIRECT-DBKEY.                                             
      *%   STORE GWCORTRANS.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 28 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORTRANS                                       
MAN02                 FCCSPL-GWCORTRANS                                         
MAN02                 GWCORTRANS                                                
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       3099-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       3100-CREATE-NAP-RECORD.                                                  
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   SET UP THE NAP RECORD AND STORE IN THE TRANS RECORD IN      *         
      *   THE DATA BASE.                                              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE AGENT-NUMBER OF GWCORCOMP TO GNAP-AGENT-CODE.                   
           MOVE GFO-NUMBER OF GWCORCOMP TO GNAP-GFO-OFFICE.                     
           MOVE GROUP-REP TO GNAP-GFO-REP.                                      
           MOVE GNAP-GFO-REP TO WS-GNUM-REP.                                    
           CALL 'GNUMTABL' USING WS-GNUM-TABLE                                  
                                 WS-GNUM-REP                                    
                                 WS-GNUM-RETURN.                                
           IF WS-GNUM-RETURN-1-5 EQUAL WS-GNUM-REP                              
               MOVE SPACES TO WS-GNUM-RETURN.                                   
           MOVE WS-GNUM-RETURN TO GNAP-REP-NAME.                                
           MOVE 'FY' TO GNAP-PREM-TYPE.                                         
           MOVE COMP-AMT TO GNAP-AMOUNT.                                        
           MOVE 'NP' TO TRANS-TYPE.                                             
           MOVE GNAPREC TO TRANS-DETAILS.                                       
           MOVE -1 TO DIRECT-DBKEY.                                             
      *%   STORE GWCORTRANS.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 29 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORTRANS                                       
MAN02                 FCCSPL-GWCORTRANS                                         
MAN02                 GWCORTRANS                                                
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       3199-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       3200-UPDATE-ADVPSM.                                                      
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   DEPENDING ON THE SCALE CALCULATION DONE, UPDATE THE ADVANCE *         
      *   POINT-IN-SCALE USING THE SCALE AND RENEWAL DAY.             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF WS-TOTAL-PREM-ALL GREATER THAN ZERO                               
               MOVE WS-TOTAL-PREM-ALL TO WS-PSM-PREM-ADV                        
               MOVE WS-REG-SCALE TO COMM-SCALE                                  
               MOVE WS-RENEW-DATE TO NEXT-RENEW-DATE                            
               PERFORM 3300-UPDATE-ADVPSM-RECORD.                               
                                                                                
           IF WS-TOTAL-PREM-LIFE-A-S GREATER THAN ZERO                          
               MOVE WS-TOTAL-PREM-LIFE-A-S TO WS-PSM-PREM-ADV                   
               MOVE WS-REG-SCALE TO COMM-SCALE                                  
               MOVE WS-RENEW-DATE TO NEXT-RENEW-DATE                            
               PERFORM 3300-UPDATE-ADVPSM-RECORD.                               
                                                                                
           IF WS-TOTAL-PREM-LTD GREATER THAN ZERO                               
               MOVE WS-TOTAL-PREM-LTD TO WS-PSM-PREM-ADV                        
               MOVE WS-LTD-SCALE TO COMM-SCALE                                  
               MOVE WS-RENEW-DATE TO NEXT-RENEW-DATE                            
               PERFORM 3300-UPDATE-ADVPSM-RECORD.                               
                                                                                
           IF WS-TOTAL-PREM-ALL-SC GREATER THAN ZERO                            
               MOVE WS-TOTAL-PREM-ALL-SC TO WS-PSM-PREM-ADV                     
               MOVE 'SCR' TO COMM-SCALE                                         
               MOVE RENEWAL-EFFECTIVE-DATE TO NEXT-RENEW-DATE                   
               ADD +1                      TO NEXT-RENEW-YEAR                   
               PERFORM 3300-UPDATE-ADVPSM-RECORD.                               
                                                                                
       3299-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       3300-UPDATE-ADVPSM-RECORD.                                               
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   SEARCH THE ADVANCE POINT-IN-SCALE RECORDS FOR THE APPLICABLE*         
      *   SCALE AND DATE.  IF THE RECORD EXISTS, MODIFY IT. OTHERWISE,*         
      *   STORE IT.                                                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   FIND CURRENT GWCORGROUP.                                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 30 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   OBTAIN GWCORADVPSM WITHIN GROUP-ADVPSM                               
      *%       USING GROUP-ADV-KEY                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 31 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +8  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-ALT-KEY                               
MAN02                 FCCSPLIO-GWCORADVPSM                                      
MAN02                 FCCSPL-GWCORADVPSM                                        
MAN02                 FCCSPL-GROUP-ADVPSM                                       
MAN02                 GWCORADVPSM                                               
MAN02                 GROUP-ADV-KEY                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                                       NEXT SENTENCE.                           
           IF DB-REC-NOT-FOUND                                                  
               MOVE WS-PSM-PREM-ADV TO PSM-PREM-ADV                             
      *%       STORE GWCORADVPSM                                                
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 32 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORADVPSM                                  
MAN02                     FCCSPL-GWCORADVPSM                                    
MAN02                     GWCORADVPSM                                           
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               IF COMP-REASON = 'F'                                             
                   MOVE +18 TO WS-ERROR-NUMBER                                  
                   PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT                 
               ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               ADD WS-PSM-PREM-ADV TO PSM-PREM-ADV                              
      *%       MODIFY GWCORADVPSM.                                              
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 33 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-UPDATE                                         
MAN02                     FCCSPLIO-GWCORADVPSM                                  
MAN02                     FCCSPL-GWCORADVPSM                                    
MAN02                     GWCORADVPSM                                           
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
       3399-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       4000-FIND-SALES-CREDITS.                                                 
           MOVE '*'                     TO GSC-PRODUCT-CODE.                    
           MOVE ' '                     TO GSC-WHICH-FACTORS.                   
           MOVE +0                      TO GSC-RET-FY-CURR-FACTOR               
                                           GSC-RET-RN-CURR-FACTOR               
                                           GSC-RET-FY-OLD-FACTOR                
                                           GSC-RET-RN-OLD-FACTOR.               
           MOVE WS-CURR-DAY             TO GSC-PREM-DUE-DD.                     
           MOVE WS-CURR-MONTH           TO GSC-PREM-DUE-MM.                     
           MOVE WS-CURR-YEAR            TO WS-ALIS-PREM2-YY.                    
           IF ALIS-CURR-YEAR > +199                                             
              MOVE 20                   TO WS-ALIS-PREM2-CC                     
           ELSE                                                                 
              MOVE 19                   TO WS-ALIS-PREM2-CC.                    
           MOVE WS-ALIS-PREM2-CCYY      TO GSC-PREM-DUE-YYYY.                   
      *                                                                         
           CALL 'GTABSC' USING   GSC-CALC-PARMS.                                
                                                                                
       4000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       5000-GROUP-NAL.                                                          
                                                                                
            MOVE ZEROS                       TO  WS-NALGR-NUM1.                 
            MOVE GROUP-NUMBER OF GWCORGRACCT TO  WS-GROUP-NUM.                  
            MOVE WS-NUM-GROUP-NUM            TO  WS-NALGR-NUM2.                 
            MOVE WS-NALGR-NUM                TO  WS-KEY-GROUP-N.                
                                                                                
            MOVE SPACES                      TO  WS-ERROR-CODE-N                
                                                 WS-RETURN-DATES-N.             
                                                                                
            CALL 'TLUCOB'  USING  WS-ERROR-CODE-N,                              
                                  WS-KEY-GROUP-N,                               
                                  WS-TLU111-TABLE-NUM,                          
                                  WS-RETURN-DATES-N.                            
                                                                                
           IF WS-FOUND-GROUP                                                    
               MOVE 'Y'      TO  NAL-GROUP-IND                                  
           ELSE                                                                 
               MOVE 'N'      TO  NAL-GROUP-IND.                                 
                                                                                
       5000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      /                                                                         
       9900-EXCEPTION-REPORT.                                                   
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   SET UP MESSAGE USING THE MESSAGE NUMBER AND WRITE TO REPORT *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   SEP/90 A. NIKELSKI                                          *         
      *        - SOME ERRORS ARE SUPPRESSED IF AGENT MATCHES CERTAIN  *         
      *          CONDITIONS.                                          *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE 'Y' TO WS-ERROR-SWITCH.                                         
                                                                                
SEP90 *    DO NOT WRITE OUT ERROR MESSAGE FOR TERMINATED GROUP                  
SEP90      IF  GROUP-ACCOUNT OF GWCORGRACCT = GPSY-GROUP-ACCOUNT AND            
SEP90          GGIACCOUNT-STATUS > '19'                                         
SEP90          GO TO 9999-EXIT.                                                 
                                                                                
SEP90 *    IF  GROUP-ACCOUNT OF GWCORGRACCT = GPSY-GROUP-ACCOUNT AND            
SEP90 *        WS-AGT-INDEX > +0   AND                                          
SEP90 *        WS-AGT-INDEX < +5   AND                                          
SEP90 *        GAGTRIDENT (WS-AGT-INDEX) = '110'                                
SEP90 *        IF  GAGCOMM-IND (WS-AGT-INDEX WS-SEG-INDEX) = 'S' OR 'N'         
SEP90 *            GO TO 9999-EXIT.                                             
                                                                                
           MOVE GROUP-ACCOUNT OF GWCORGRACCT TO WS-EX-GROUP-NO-OUT.             
SEP90      IF  GROUP-ACCOUNT OF GWCORGRACCT = GPSY-GROUP-ACCOUNT                
SEP90          MOVE GGIGROUP-OFFICE          TO WS-EX-GFO-NO-OUT                
SEP90      ELSE                                                                 
SEP90          MOVE SPACES                   TO WS-EX-GFO-NO-OUT.               
           IF  WS-ERROR-NUMBER = +99                                            
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE WS-EX-MSG-RPT-NO (WS-ERROR-NUMBER)                          
                                             TO WS-EX-RPT-NO-OUT                
               MOVE WS-EX-MSG (WS-ERROR-NUMBER)                                 
                                             TO WS-EX-MSG-OUT.                  
                                                                                
       9910-WRITE-EXCEPTION-REPORT.                                             
           MOVE ZERO TO DLS-SYS020-RETURN.                                      
           CALL 'DLSWRITE' USING DLS-SYS020-SYSNUM                              
                                 DLS-SYS020-RETURN                              
                                 WS-EX-DETAIL-LINE-OUT                          
                                 DLS-SYS020-REC-SIZE                            
                                 DLS-SYS020-BLK-SIZE                            
                                 DLS-SYS020-FORMAT                              
                                 DLS-SYS020-REC-COUNT.                          
           IF DLS-SYS020-RETURN EQUAL TO ZERO                                   
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS020' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       9999-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       WTL-TO-OPERATOR.                                                         
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           CALL 'WTL' USING WTL-MESSAGE-AREA                                    
                            WTL-FLAG                                            
                            WTL-REPLY                                           
                            WTL-REPLY-AREA.                                     
       WTL-TO-OPERATOR-EXIT.                                                    
           EXIT.                                                                
                                                                                
       INIT-FIELDS.                                                             
           MOVE +0        TO TEMP-1 (WS-SUB)                                    
                             TEMP-2 (WS-SUB).                                   
                                                                                
       INIT-FIELDS-EXIT.                                                        
           EXIT.                                                                
                                                                                
       CHECK-GROUP-DATES.                                                       
           MOVE -1                      TO GGIGROUP-NUMBER.                     
           MOVE LOW-VALUES              TO GGIACCOUNT.                          
      *                                                                         
      *        IF GROUP NOT FOUND ON GIPSY MASTER AND LAST RECON.               
      *        DATE IS OLDER THAN 1 YEAR - DO NOT PRINT EXTRACT                 
      *                                                                         
      *        FIND CURR DATE MINUS 1 YEAR                                      
      *                                                                         
           MOVE ALIS-CURR-DATE TO ALIS-CURR-DATE-MINUS-1-YEAR.                  
           SUBTRACT +1         FROM ALIS-YEAR.                                  
           IF LAST-RECON-DATE OF GWCORGRACCT >                                  
              ALIS-CURR-DATE-MINUS-1-YEAR                                       
              MOVE +2 TO WS-ERROR-NUMBER                                        
              PERFORM 9900-EXCEPTION-REPORT THRU 9999-EXIT                      
           ELSE                                                                 
              MOVE 'Y'     TO WS-SKIP-GROUP.                                    
                                                                                
       CHECK-GROUP-DATES-EXIT.                                                  
           EXIT.                                                                
                                                                                
MAN02  9005-OBTAIN-FIELD-OFFICE.                                                
           MOVE GGIGROUP-OFFICE TO FDOF-PARM2.                                  
           MOVE 'GETRAN'        TO FDOF-FUNCTION.                               
                                                                                
           CALL 'ZACCVSAM'   USING FDOF-PARM1                                   
                                   FDOF-PARM2                                   
                                   FIELD-OFFICE-FILE.                           
                                                                                
           IF  FDOF-ERRCODE NOT = LOW-VALUES                                    
               MOVE ZERO                 TO GCRL-MGR                            
           ELSE                                                                 
               MOVE FOF-MLI-MANAGER-CODE TO GCRL-MGR                            
           END-IF.                                                              
                                                                                
MAN02 *    MOVE FDOFFILE TO LOGICAL-RECORD-NAME.                                
MAN02 *    CALL GAEDATSR USING OBTAIN-KEYED                                     
MAN02 *                        FIELD-OFFICE-FILE                                
MAN02 *                        ICBM.                                            
MAN02 *    IF KEYED-LR-NOT-FOUND                                                
MAN02 *        MOVE '0326' TO ERROR-STATUS                                      
MAN02 *    ELSE                                                                 
MAN02 *        MOVE ZEROS TO ERROR-STATUS                                       
MAN02 *    END-IF.                                                              
MAN02  9005-OBTAIN-FIELD-OFFICE-EXIT.                                           
MAN02      EXIT.                                                                
      /                                                                         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                      END OF SOURCE                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
