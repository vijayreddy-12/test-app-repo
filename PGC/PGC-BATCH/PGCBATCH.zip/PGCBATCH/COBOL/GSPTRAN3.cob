       ID DIVISION.                                                             
GNE                                                                             
       PROGRAM-ID. GSPTRAN3.                                                    
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *REMARKS.    THIS MODULE IS CALLED BY GSPTRAN1 TO FORMAT GROUP            
      *            MASTER TRAILERS 050 THRU 090 FOR THE TRANS REG.              
      *            REVISED HEADINGS FOR QUEBEC TAX,  C. PETERSON                
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77  SEGMENT-SUB  COMP SYNC   PIC S9(4).                                  
       77  COVERAGE-SUB COMP SYNC   PIC S9(4).                                  
       77  DATE-TYPE    PIC XX  VALUE 'AC'.                                     
       77  WDATE-P      PIC X(4).                                               
       77  WDATE-C      PIC X(7).                                               
                                                                                
       01  TEST-090-SEGMENT.                                                    
           03  TEST-SUB                  PIC S999 COMP-3.                       
           03  SEG-REM                   PIC S9   COMP-3.                       
                                                                                
       01  GNUMONIC-PARAMETERS.                                                 
           03  GNUM-TABLENUM   COMP  VALUE +22     PIC S9(4).                   
           03  GNUM-RETURN.                                                     
               05  GNUM-COV-LIT                    PIC X(8).                    
               05  FILLER                          PIC X(9).                    
                                                                                
GNE    01  GTRLGTH7                      PIC X(8) VALUE 'GTRLGTH7'.             
       01  GTRLGTH-PARAMETERS.                                                  
           03  GTRLGTH-RETURN-AREA.                                             
               05  FILLER                PIC X(10).                             
               05  GTRLGTH-NUM-SEG       PIC S9(4) COMP.                        
               05  FILLER                PIC X(6).                              
           03  GTRLGTH-RETURN-CODE       PIC X SYNC.                            
                                                                                
       01  HEADING-LINES.                                                       
           03  TRLR-050-HEAD1.                                                  
               05  FILLER             PIC X(11) VALUE '  EFF'.                  
               05  FILLER             PIC X(9)  VALUE 'COMP'.                   
               05  FILLER             PIC X(7)  VALUE 'SHARE'.                  
               05  FILLER             PIC X(8)  VALUE 'RETENT'.                 
               05  FILLER             PIC X(9)  VALUE 'CO-INS'.                 
               05  FILLER             PIC X(12) VALUE 'REIN RATE'.              
               05  FILLER             PIC X(7)  VALUE 'SELF'.                   
               05  FILLER             PIC X(9)  VALUE 'MAJOR MED'.              
           03  TRLR-050-HEAD2.                                                  
               05  FILLER             PIC X(7)  VALUE ' DATE'.                  
               05  FILLER             PIC X(8)  VALUE 'TYPE'.                   
               05  FILLER             PIC X(5)  VALUE 'BEN'.                    
               05  FILLER             PIC X(8)  VALUE 'QUOTA'.                  
               05  FILLER             PIC X(8)  VALUE 'MAX'.                    
               05  FILLER             PIC X(6)  VALUE 'PER'.                    
               05  FILLER             PIC X(8)  VALUE 'SINGLE'.                 
               05  FILLER             PIC X(6)  VALUE 'FAM'.                    
               05  FILLER             PIC X(9)  VALUE 'BILL'.                   
               05  FILLER             PIC X(12) VALUE 'MAX.'.                   
               05  FILLER             PIC X(7)  VALUE 'CLASSES'.                
           03  TRLR-080-HEAD1.                                                  
               05  FILLER             PIC X(11) VALUE SPACES.                   
               05  FILLER             PIC X(30) VALUE                           
                   'OUTSTANDING BILLED INFORMATION'.                            
           03  TRLR-080-HEAD2.                                                  
               05  FILLER             PIC X(9)  VALUE 'DUE DATE'.               
               05  FILLER             PIC X(12) VALUE 'BILLED LFE'.             
               05  FILLER             PIC X(12) VALUE 'BILLED LTD'.             
               05  FILLER             PIC X(12) VALUE 'BILLED A&S'.             
               05  FILLER             PIC X(12) VALUE 'BILLED TAX'.             
               05  FILLER             PIC X(8)  VALUE 'POSITION'.               
           03  TRLR-080-HIST-HEAD1.                                             
               05  FILLER             PIC X(9)  VALUE ' DUE'.                   
               05  FILLER             PIC X(8)  VALUE 'PREP'.                   
               05  FILLER             PIC X(12) VALUE 'PREMIUM'.                
               05  FILLER             PIC X(19) VALUE 'CERT'.                   
               05  FILLER             PIC X(6)  VALUE 'NUM'.                    
               05  FILLER             PIC X(13) VALUE 'COVERAGE'.               
               05  FILLER             PIC X(9)  VALUE 'AMOUNT'.                 
               05  FILLER             PIC X(3)  VALUE 'NO.'.                    
           03  TRLR-080-HIST-HEAD2.                                             
               05  FILLER             PIC X(9)  VALUE ' DATE'.                  
               05  FILLER             PIC X(10) VALUE 'DATE'.                   
               05  FILLER             PIC X(9)  VALUE 'DUE'.                    
               05  FILLER             PIC X(12) VALUE 'HOLDERS'.                
               05  FILLER             PIC X(8)  VALUE 'TAX'.                    
               05  FILLER             PIC X(8)  VALUE 'COV'.                    
               05  FILLER             PIC X(11) VALUE 'CODE'.                   
               05  FILLER             PIC X(8)  VALUE 'BILLED'.                 
               05  FILLER             PIC X(8)  VALUE 'LIVES'.                  
               05  FILLER             PIC X(6)  VALUE 'VOLUME'.                 
           03  TRLR-090-HEAD1.                                                  
               05  FILLER             PIC X(12) VALUE '  PAY'.                  
               05  FILLER             PIC X(9)  VALUE 'PAY'.                    
               05  FILLER             PIC X(5)  VALUE 'PAY'.                    
               05  FILLER             PIC X(7)  VALUE 'APPLIED'.                
           03  TRLR-090-HEAD2.                                                  
               05  FILLER             PIC X(11) VALUE ' DATE'.                  
               05  FILLER             PIC X(9)  VALUE 'AMOUNT'.                 
               05  FILLER             PIC X(7)  VALUE 'TYPE'.                   
               05  FILLER             PIC X(4)  VALUE 'DATE'.                   
                                                                                
       01  WORK-PRAREA.                                                         
           03  WPRAREA-080-COV.                                                 
               05  WPRLINE-080-COV.                                             
                   07  W-GBICOV-CODE           PIC 999.                         
                   07  P-080-DASH              PIC X    VALUE '-'.              
                   07  P-GBICOV-CODE-LIT       PIC X(8).                        
                   07  W-GBIAMT-BILLED         PIC -(7)9.99.                    
                   07          FILLER  PIC X            VALUE SPACES.           
                   07  W-GBINO-LIVES           PIC Z(4)9.                       
                   07          FILLER  PIC X            VALUE SPACES.           
                   07  W-GBIVOL                PIC Z(8)9.                       
           03  WPRAREA-080.                                                     
               05  WPRLINE-080-1.                                               
                   07  P-GBIHIST-DUE-DATE      PIC X(7).                        
                   07          FILLER  PIC X.                                   
                   07  P-GBIHIST-PREPARED-DATE PIC X(7).                        
                   07          FILLER  PIC X.                                   
                   07  W-GBI-PREM-DUE          PIC -(8).99.                     
                   07          FILLER  PIC X.                                   
                   07  W-GBICERT-HOLDERS       PIC Z(6)9.                       
                   07          FILLER  PIC X.                                   
                   07  W-GBIHIST-ADMIN-FEE     PIC Z(6)9.99.                    
                   07          FILLER  PIC XX.                                  
                   07  W-GBINO-COV-LINES       PIC Z9.                          
                   07          FILLER  PIC X.                                   
                   07  W-080-COV-DATA          PIC X(40).                       
           03  WPRAREA-090  REDEFINES WPRAREA-080.                              
               05  WPRLINE-090.                                                 
                   07  P-GPAPAYMENT-DATE       PIC X(7).                        
                   07          FILLER  PIC X.                                   
                   07  W-GPAPAY-AMOUNT         PIC -(5),---.99.                 
                   07          FILLER  PIC XX.                                  
                   07  W-GPAPAY-TYPE           PIC X.                           
                   07          FILLER  PIC X(3).                                
                   07  P-GPAPAY-APPLIED-DATE   PIC X(7).                        
                                                                                
       LINKAGE SECTION.                                                         
       77  LINE-COUNT  COMP SYNC   PIC S9(4).                                   
       01  PRINT-LINES.                                                         
           03  PRLINES-050.                                                     
               05  PRLINE-050 OCCURS 3 TIMES.                                   
                   07  P-GRIEFFECTIVE-DATE     PIC X(7).                        
                   07          FILLER PIC X.                                    
                   07  W-GRITYPE               PIC X.                           
                   07          FILLER PIC XXX.                                  
                   07  W-GRICOMPANY            PIC X.                           
                   07          FILLER PIC XXX.                                  
                   07  W-GRIBENEFIT            PIC X.                           
                   07          FILLER PIC XX.                                   
                   07  W-GRISHARE-QUOTA-PER    PIC Z(3).99.                     
                   07          FILLER PIC X.                                    
                   07  W-GRIRETENTION-MAX      PIC Z(4),ZZ9.                    
                   07          FILLER PIC X.                                    
                   07  W-GRICO-INSURANCE-PER   PIC Z(3).99.                     
                   07          FILLER PIC X.                                    
                   07  W-GRIREINSURANCE-RATE.                                   
                       09  W-GRIRATE-SINGLE    PIC Z(3).99.                     
                       09      FILLER PIC X.                                    
                       09  W-GRIRATE-FAMILY    PIC Z(3).99.                     
                       09      FILLER PIC X.                                    
                   07  W-GRISELF-BILL-PER      PIC Z(3).99.                     
                   07          FILLER PIC X.                                    
                   07  W-GRIMAJ-MED-MAX        PIC ZZZ,ZZZ,ZZ9.                 
                   07          FILLER PIC X.                                    
                   07  W-GRIEXEMPT-CLASSES     PIC X(10).                       
                   07          FILLER PIC X(6).                                 
               05  FILLER                      PIC X(22932).                    
           03  PRLINES-080  REDEFINES PRLINES-050.                              
               05  PRLINE-080-HEAD1                    PIC X(91).               
               05  PRLINE-080-HEAD2                    PIC X(91).               
               05  PRLINE-080-1.                                                
                   07  P-GBIDUE-DATE                   PIC X(7).                
                   07              FILLER PIC X.                                
                   07  W-GBIBILL.                                               
                       09  W-GBILIFE                  PIC --------.99.          
                       09          FILLER PIC X.                                
                       09  W-GBILTD                   PIC --------.99.          
                       09          FILLER PIC X.                                
                       09  W-GBIA-S                   PIC --------.99.          
                       09          FILLER PIC X.                                
                       09  W-GBIADMIN-FEE      PIC --------.99.                 
                       09          FILLER PIC X(4).                             
                   07  W-GBIPOSITION                   PIC -(3)9.               
                   07              FILLER PIC X(28).                            
               05  PRLINE-080-HIST-HEAD1               PIC X(91).               
               05  PRLINE-080-HIST-HEAD2               PIC X(91).               
           03  PRLINES-080-OCCURS REDEFINES PRLINES-080.                        
               05  PRLINE-080   OCCURS 255 TIMES       PIC X(91).               
           03  PRLINES-090  REDEFINES PRLINES-050.                              
               05  PRLINE-090-HEAD1.                                            
                   07  PRLINE-090-HEAD1-A              PIC X(40).               
                   07  PRLINE-090-HEAD1-B              PIC X(51).               
               05  PRLINE-090-HEAD2.                                            
                   07  PRLINE-090-HEAD2-A              PIC X(40).               
                   07  PRLINE-090-HEAD2-B              PIC X(51).               
               05  FILLER                              PIC X(2730).             
           03  PRLINES-090-OCCURS REDEFINES PRLINES-090.                        
               05  PRLINE-090   OCCURS 32 TIMES.                                
                   07  PRLINE-090-A                    PIC X(33).               
                   07          FILLER PIC X(7).                                 
                   07  PRLINE-090-B                    PIC X(33).               
                   07          FILLER PIC X(18).                                
       01  W-GRIREIN.                                                           
                                   COPY WMRINTR REPLACING                       
                                             ==01  WMRINTR.== BY ====.          
       01  W-GBIBILLING.                                                        
                                   COPY WMBILTR REPLACING                       
                                             ==01  WMBILTR.== BY ====.          
       01  W-GPAPAYMENT.                                                        
                                   COPY WMPAYTR REPLACING                       
                                             ==01  WMPAYTR.== BY ====.          
       01  REIN-COUNT              PIC S9(4) COMP.                              
                                                                                
       PROCEDURE DIVISION.                                                      
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 050.  HEADINGS           
      *    ARE ONLY PUT OUT IF THE REIN-COUNT IS 1.  THIS COUNT CAN BE          
      *    1 OR 2 SIGNIFYING WHICH OCCURRENCE OF THE REINIT TRAILER IS          
      *    PASSED.                                                              
      ******************************************************************        
           ENTRY 'GSPTTR05' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GRIREIN, REIN-COUNT.                        
           IF REIN-COUNT EQUAL +1                                               
              MOVE TRLR-050-HEAD1 TO PRLINE-050 (1)                             
              MOVE TRLR-050-HEAD2 TO PRLINE-050 (2)                             
              MOVE SPACES         TO PRLINE-050 (3)                             
              MOVE +3             TO LINE-COUNT                                 
           ELSE                                                                 
              MOVE SPACES         TO PRLINE-050 (1)                             
              MOVE +1 TO LINE-COUNT.                                            
           MOVE CORR W-GRIREIN TO PRLINE-050 (LINE-COUNT).                      
           MOVE W-GRIEFFECTIVE-DATE TO WDATE-P.                                 
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GRIEFFECTIVE-DATE (LINE-COUNT).                    
           GO TO TRAN3-EXIT.                                                    
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 080.                     
      *    THE HEADINGS ARE PUT OUT FOR THE OUTSTANDING INFORMATION AND         
      *    THE HEADINGS FOR HISTORY INFORMATION.  THE HISTORY LINES ARE         
      *    THEN SET UP IN THE ORDER THEY APPEAR, WITH THE COVERAGE              
      *    STATISTICS FOR EACH RESPECTIVE HISTORY TRAILER.                      
      ******************************************************************        
           ENTRY 'GSPTTR08' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GBIBILLING.                                 
           MOVE +5 TO LINE-COUNT.                                               
           MOVE SPACES TO PRLINES-080.                                          
           MOVE TRLR-080-HEAD1 TO PRLINE-080-HEAD1.                             
           MOVE TRLR-080-HEAD2 TO PRLINE-080-HEAD2.                             
           MOVE W-GBIDUE-DATE TO WDATE-P.                                       
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GBIDUE-DATE.                                       
           MOVE CORR W-GBIMOST-OUTSTANDING TO PRLINE-080-1.                     
           MOVE TRLR-080-HIST-HEAD1 TO PRLINE-080-HIST-HEAD1.                   
           MOVE TRLR-080-HIST-HEAD2 TO PRLINE-080-HIST-HEAD2.                   
GNE        CALL GTRLGTH7 USING W-GBITRIDENT                                     
                                GTRLGTH-RETURN-AREA                             
                                GTRLGTH-RETURN-CODE.                            
           PERFORM MOVE-TR080-A THRU MOVE-TR080-EXIT                            
               VARYING SEGMENT-SUB FROM 1 BY 1                                  
                   UNTIL SEGMENT-SUB GREATER THAN GTRLGTH-NUM-SEG               
                         OR W-GBIHISTORY-INFO (SEGMENT-SUB)                     
                            EQUAL TO SPACES.                                    
           GO TO TRAN3-EXIT.                                                    
       MOVE-TR080-A.                                                            
           MOVE SPACES TO WPRLINE-080-1.                                        
           MOVE CORR W-GBIHISTORY-INFO (SEGMENT-SUB) TO WPRLINE-080-1.          
           MOVE W-GBIHIST-DUE-DATE (SEGMENT-SUB) TO WDATE-P.                    
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GBIHIST-DUE-DATE.                                  
           MOVE W-GBIHIST-PREPARED-DATE (SEGMENT-SUB) TO WDATE-P.               
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GBIHIST-PREPARED-DATE.                             
           IF W-GBINO-COV-LINES OF W-GBIHISTORY-INFO (SEGMENT-SUB)              
                                   EQUAL +0                                     
              ADD 1 TO LINE-COUNT                                               
              MOVE WPRLINE-080-1 TO PRLINE-080 (LINE-COUNT).                    
           PERFORM MOVE-TR080-COVERAGE THRU MOVE-TR080-COVERAGE-EXIT            
               VARYING COVERAGE-SUB FROM 1 BY 1                                 
                   UNTIL COVERAGE-SUB GREATER THAN                              
                      W-GBINO-COV-LINES                                         
                          OF W-GBIHISTORY-INFO (SEGMENT-SUB).                   
           GO TO MOVE-TR080-EXIT.                                               
       MOVE-TR080-COVERAGE.                                                     
           IF COVERAGE-SUB EQUAL 2                                              
              MOVE SPACES TO WPRLINE-080-1.                                     
           MOVE CORR W-GBISTATS-BY-COVERAGE (SEGMENT-SUB, COVERAGE-SUB)         
                                         TO WPRLINE-080-COV.                    
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 W-GBICOV-CODE IN WPRLINE-080-COV               
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO P-GBICOV-CODE-LIT.                              
           MOVE WPRAREA-080-COV TO W-080-COV-DATA.                              
           ADD +1 TO LINE-COUNT.                                                
           MOVE WPRLINE-080-1 TO PRLINE-080 (LINE-COUNT).                       
       MOVE-TR080-COVERAGE-EXIT.                                                
           EXIT.                                                                
       MOVE-TR080-EXIT.                                                         
           EXIT.                                                                
       END-TR080.                                                               
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 090.                     
      *    EACH DATA LINE HAS ROOM FOR TWO SEGMENTS OF DATA INFORMATION.        
      *    THE HEADING IS PUT OUT FOR MULTIPLE COLUMN OUTPUT ONLY IF            
      *    MORE THAN 1 SEGMENT EXISTS.                                          
      ******************************************************************        
           ENTRY 'GSPTTR09' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GPAPAYMENT.                                 
           MOVE SPACES TO PRLINES-090.                                          
           MOVE 2 TO LINE-COUNT.                                                
           MOVE TRLR-090-HEAD1 TO PRLINE-090-HEAD1-A.                           
           MOVE TRLR-090-HEAD2 TO PRLINE-090-HEAD2-A.                           
GNE        CALL GTRLGTH7 USING W-GPATRIDENT                                     
                                GTRLGTH-RETURN-AREA                             
                                GTRLGTH-RETURN-CODE.                            
           PERFORM MOVE-TR090-A THRU MOVE-TR090-EXIT                            
               VARYING SEGMENT-SUB FROM 1 BY 1                                  
                   UNTIL SEGMENT-SUB GREATER THAN GTRLGTH-NUM-SEG               
                         OR W-GPAPAYMENT-INFO (SEGMENT-SUB)                     
                            EQUAL TO SPACES.                                    
           GO TO TRAN3-EXIT.                                                    
       MOVE-TR090-A.                                                            
           MOVE SPACES TO WPRLINE-090.                                          
           MOVE W-GPAPAYMENT-DATE (SEGMENT-SUB) TO WDATE-P.                     
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GPAPAYMENT-DATE.                                   
           MOVE W-GPAPAY-APPLIED-DATE (SEGMENT-SUB) TO WDATE-P.                 
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GPAPAY-APPLIED-DATE.                               
           MOVE CORR W-GPAPAYMENT-INFO (SEGMENT-SUB) TO WPRLINE-090.            
       MOVE-TR090-B.                                                            
           DIVIDE SEGMENT-SUB BY 2 GIVING TEST-SUB REMAINDER SEG-REM.           
           IF SEG-REM EQUAL +0                                                  
              MOVE WPRLINE-090 TO PRLINE-090-B (LINE-COUNT)                     
           ELSE                                                                 
              ADD 1 TO LINE-COUNT                                               
              MOVE WPRLINE-090 TO PRLINE-090-A (LINE-COUNT).                    
           IF SEGMENT-SUB EQUAL +2                                              
              MOVE TRLR-090-HEAD1 TO PRLINE-090-HEAD1-B                         
              MOVE TRLR-090-HEAD2 TO PRLINE-090-HEAD2-B.                        
       MOVE-TR090-EXIT.                                                         
           EXIT.                                                                
      *                                                                         
       CONV-DATE.                                                               
           CALL 'QDATE' USING DATE-TYPE, WDATE-P, WDATE-C.                      
      *                                                                         
       TRAN3-EXIT.                                                              
           GOBACK.                                                              
                                                                                
MAN07 *9999-DUMP-ROUTINE.                                                       
MAN07 ******************************************************************        
MAN07 *    SERIOUS ERROR OCCURRED.                                              
MAN07 *    DISPLAY SOME CONSOLE MESSAGES, TAKE A DUMP THEN ABEND.               
MAN07 *    COPYBOOK GWRDUMP IS REQUIRED                                         
MAN07 ******************************************************************        
MAN07 *                                                                         
MAN07 *    MOVE WS-PROGRAM-ID TO GWRDUMP-PROGRAM-NAME.                          
MAN07 *    CALL GWCDUMP    USING ICBM                                           
MAN07 *                          GWRDUMP.                                       
MAN07 *                                                                         
MAN07 *9999-EXIT.                                                               
MAN07 *    EXIT.                                                                
