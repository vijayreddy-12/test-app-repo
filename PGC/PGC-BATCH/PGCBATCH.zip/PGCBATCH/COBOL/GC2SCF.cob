       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2SCF.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
      *    THIS PROGRAM CREATES A FILE OF ALL PAID SALES CREDITS                
      *    FOR A SPAN OF DATES SELECTED ON THE PARM CARD.                       
      *    IT DOES ON AREA SWEEP ON GWCORCOMP.                                  
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INPUT:     GWCORCOMP                                         *         
      *             GIPSY MASTER FILE                                 *         
      *                                                               *         
      *  OUTPUT:    SALES CREDIT FILE                                 *         
      *                                                               *         
      *  FREQUENCY: DAILY                                             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                                         
      *  04JUN90 (SUPPORT RELEASE 3A) IAN BUCKNELL                              
      *        - ADD COMMISSION YEAR-END DATE TO PARM CARD & BASE YTD           
      *          TOTALS ON THIS DATE RATHER THAN CALENDAR YEAR-END              
      *        - CHANGE CODES USED FOR RPT-COMP-REASON ON REPORT FILE           
      *          TO ALTER SORT ORDER OF TRANSLATED VALUES ON THE REPORT         
      *                                                                         
      *    JUL/2005  R. KNAUD.                                        *         
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)        *         
      *                  CHANGE THE GMASTER IDMS READ TO:                       
      *                      USE VOGPWRA7 TO READ THE VCM AND         *         
      *                      GIPSY MASTER FILES.                      *         
      *                                                                         
      *                                                                         
      *    OCT/08 IBM                                                           
      *         - ENTERPRISE COMPILER UPGRADE                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCSCF          
186266* JUL2013 - MITRAAD - MODIFICATION TO RESOLVE SOC7 ISSSUE                 
186266*                     TL 186266                                           
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2SCF W-S STARTS HERE **'.                                  
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
           03  FILLER                   PIC X(30).                              
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  VOGPWRA7                 PIC X(8)    VALUE 'VOGPWRA7'.           
           05  GWCDUMP                  PIC X(8)    VALUE 'GWCDUMP'.            
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
                                                                                
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
       01  WS-PARAMETERS.                                                       
           05 SUB                     PIC S9    VALUE +0  COMP.                 
           05 QDATE-CA                PIC XX    VALUE 'CA'.                     
           05 QDATE-CB                PIC XX    VALUE 'CB'.                     
           05 QDATE-AB                PIC XX    VALUE 'AB'.                     
           05 FROM-DATE-A.                                                      
              10  FROM-DATE-YEAR      PIC S9(3)  COMP-3.                        
              10  FROM-DATE-DAY       PIC S9(3)  COMP-3.                        
           05 TO-DATE-A.                                                        
              10  TO-DATE-YEAR        PIC S9(3)  COMP-3.                        
              10  TO-DATE-DAY         PIC S9(3)  COMP-3.                        
           05 LCC-DATE-A.                                                       
              10  LCC-DATE-YEAR        PIC S9(3)  COMP-3.                       
              10  LCC-DATE-DAY         PIC S9(3)  COMP-3.                       
           05 LYC-DATE-A.                                                       
              10  LYC-DATE-YEAR        PIC S9(3)  COMP-3.                       
              10  LYC-DATE-DAY         PIC S9(3)  COMP-3.                       
           05  GIPSY-PRODUCT-CODE      PIC X.                                   
REN        05  NUM-GROUP-NUMBER        PIC S9(7)  VALUE +0.                     
           05  WTL-MESSAGE.                                                     
               10  WTL-MSG-LENGTH PIC S999  COMP-3 VALUE +80.                   
               10  WTL-MSG-CC     PIC X            VALUE '0'.                   
               10  FILLER         PIC X(7)         VALUE 'GROUP='.              
REN            10  WTL-GROUP-NUMBER   PIC X(7)     VALUE SPACES.                
REN            10  FILLER         PIC X            VALUE SPACES.                
               10  FILLER         PIC X(9)         VALUE 'ACCOUNT='.            
               10  WTL-GROUP-ACCOUNT  PIC XXX      VALUE SPACES.                
REN            10  FILLER         PIC XX           VALUE SPACES.                
               10  WTL-ABEND-MSG  PIC X(50)        VALUE SPACES.                
                                                                                
       01  DLSREAD-SYS011.                                                      
           05  SYS011-SYS            PIC X(6)           VALUE 'SYS011'.         
           05  SYS011-RET            PIC S9    COMP-3   VALUE +0.               
           05  SYS011-RECL           PIC 9(5)           VALUE 80.               
           05  SYS011-BLK            PIC 9(5)           VALUE 6160.             
           05  SYS011-FORMAT         PIC X(2)           VALUE 'FB'.             
           05  SYS011-CNT            PIC S9(7) COMP-3   VALUE +0.               
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'PARM CARD                       '.                                  
       01  PARM-CARD-IN.                                                        
           05  FROM-DATE-IN         PIC X(7).                                   
           05  FILLER               PIC X.                                      
           05  TO-DATE-IN           PIC X(7).                                   
           05  FILLER               PIC X.                                      
           05  PROCESS-TYPE         PIC X.                                      
           05  FILLER               PIC X.                                      
           05  LAST-COMM-CLOSE      PIC X(7).                                   
           05  FILLER               PIC X.                                      
           05  LAST-YEAREND-CLOSE   PIC X(7).                                   
           05  FILLER               PIC X(47).                                  
                                                                                
      /                                                                         
       01  DLSWRITE-PARMS.                                                      
           05  SYS020-SYS       PIC X(6)          VALUE 'SYS020'.               
           05  SYS020-RET       PIC S9    COMP-3  VALUE +0.                     
           05  SYS020-RECL      PIC 9(5)          VALUE 105.                    
           05  SYS020-BLK       PIC 9(5)          VALUE 2100.                   
           05  SYS020-FORMAT    PIC XX            VALUE 'FB'.                   
           05  SYS020-CNT       PIC S9(7) COMP-3  VALUE +0.                     
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'REPORT-RECORD-OUT               '.                                  
                                                                                
       01  REPORT-RECORD-OUT.                                                   
           05  RPT-PRODUCT-CODE     PIC X                VALUE SPACES.          
REN        05  RPT-GROUP            PIC X(7)             VALUE SPACES.          
           05  RPT-ACCT             PIC X(3)             VALUE SPACES.          
           05  RPT-AGENT            PIC X(6)             VALUE SPACES.          
           05  RPT-COMP-REASON      PIC X                VALUE SPACES.          
           05  RPT-COMP-AMT         PIC S9(8)V99 COMP-3  VALUE +0.              
           05  RPT-PREM-AMT         PIC S9(8)V99 COMP-3  VALUE +0.              
REN        05  FILLER               PIC X(75)            VALUE SPACES.          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   THE CC-YTD-TOTALS TABLE WILL HOLD THE COMMISSION CLOSE AND  *         
      *   YEAR-TO-DATE TOTALS (ONLY ACCUMULATED ON COMMISSION CLOSE). *         
      *   THE 1ST OCCURANCE                                           *         
      *   IS ALPHA, 2ND IS OMEGA, 3RD IS CSP AND 4TH ARE ANY          *         
      *   GROUP/ACCOUNTS THAT ARE NOT ON GIPSY, THEREFORE WE DON'T    *         
      *   KNOW THE PRODUCT TYPE.                                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       01  TOTAL-RECORD-OUT.                                                    
           05  TOT-PRODUCT-CODE      PIC X.                                     
           05  CC-YTD-TOTALS OCCURS 4 TIMES.                                    
               10  TOT-CC-COMP-AMT   PIC S9(9)V99   COMP-3.                     
               10  TOT-CC-PREM-AMT   PIC S9(9)V99   COMP-3.                     
               10  TOT-YTD-COMP-AMT  PIC S9(11)V99   COMP-3.                    
               10  TOT-YTD-PREM-AMT  PIC S9(11)V99   COMP-3.                    
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - UBSCHEMA DESCRIPTION                      *          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE -  RECORD DESCRIPTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCOMP                       '.                                  
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           'WORKING STORAGE ENDS HERE'.                                         
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2SCF'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       000-MAINLINE.                                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                PROGRAM MAINLINE                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 100-INITIALIZE THRU 100-EXIT.                                
           PERFORM 200-PROCESS-RECORDS THRU 200-EXIT                            
               UNTIL DB-END-OF-SET.                                             
           PERFORM 300-END-OF-JOB THRU 300-EXIT.                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'CLOSE FILES'      TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 160-READ-VCM-GIPSY THRU 160-READ-VCM-GIPSY-EXIT.             
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       100-INITIALIZE.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1.  READ THE PARM CARD AND CONVERT THE TO AND FROM DATES TO   *         
      *     ALIS DATES.                                               *         
      * 2.  INITIALIZE THE TOTAL RECORD.                              *         
      * 3.  READ THE FIRST GWCORCOMP RECORD.                          *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
FXXTOK     MOVE 'GC2SCF' TO PROGRAM-NAME.                                       
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2SCF' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'OPEN FILES'       TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 160-READ-VCM-GIPSY THRU 160-READ-VCM-GIPSY-EXIT.             
                                                                                
           PERFORM 150-READ-PARM THRU 150-EXIT.                                 
MAN02      CALL QDATEQ2 USING QDATE-CA                                          
MAN02                         FROM-DATE-IN                                      
MAN02                         FROM-DATE-A.                                      
MAN02      CALL QDATEQ2 USING QDATE-CA                                          
MAN02                         TO-DATE-IN                                        
MAN02                         TO-DATE-A.                                        
MAN02      CALL QDATEQ2 USING QDATE-CA                                          
MAN02                         LAST-YEAREND-CLOSE                                
MAN02                         LYC-DATE-A.                                       
                                                                                
           MOVE 'T' TO TOT-PRODUCT-CODE.                                        
           PERFORM 175-INIT-TOTALS THRU 175-EXIT                                
              VARYING SUB FROM 1 BY 1 UNTIL SUB > 4.                            
                                                                                
      *%   OBTAIN FIRST GWCORCOMP WITHIN GW-COMP-AREA2                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST-SCF                                    
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GW-COMP-AREA2                                      
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
       100-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       150-READ-PARM.                                                           
           CALL 'DLSREAD' USING SYS011-SYS                                      
                                 SYS011-RET                                     
                                 PARM-CARD-IN                                   
                                 SYS011-RECL                                    
                                 SYS011-BLK                                     
                                 SYS011-FORMAT                                  
                                 SYS011-CNT.                                    
           IF SYS011-RET IS GREATER THAN +4                                     
           THEN                                                                 
               MOVE ZERO TO WTL-GROUP-NUMBER                                    
               MOVE ZERO TO WTL-GROUP-ACCOUNT                                   
               MOVE 'DLSREAD FAILED - FORCED TO ABEND'                          
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
       150-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------                     
      * VOCOMM VCM/GIPSY                                                        
       160-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       160-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
       175-INIT-TOTALS.                                                         
           MOVE ZERO TO TOT-CC-COMP-AMT (SUB).                                  
           MOVE ZERO TO TOT-CC-PREM-AMT (SUB).                                  
           MOVE ZERO TO TOT-YTD-COMP-AMT (SUB).                                 
           MOVE ZERO TO TOT-YTD-PREM-AMT (SUB).                                 
       175-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       200-PROCESS-RECORDS.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * IF GWCORCOMP RECORD IS A PAID SALES CREDIT COMP RECORD,       *         
      * CHECK THE DATES TO SEE IF IT FALLS IN PERIOD SELECTED  FROM   *         
      * PARM CARD.  THEN, OBTAIN NEXT GWCORCOMP RECORD.               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF COMP-TYPE = 'S' AND                                               
              COMP-DISP = 'P'                                                   
                  PERFORM 400-CHECK-DATES THRU 400-EXIT.                        
                                                                                
      *%   OBTAIN NEXT GWCORCOMP WITHIN GW-COMP-AREA2                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT-SCF                                     
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GW-COMP-AREA2                                      
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
       200-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       300-END-OF-JOB.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1.  WRITE TOTAL RECORD TO FILE.                               *         
      * 2.  CLOSE FILE.                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE TOTAL-RECORD-OUT TO REPORT-RECORD-OUT.                          
           PERFORM 700-WRITE-RECORD THRU 700-EXIT.                              
                                                                                
           MOVE +4 TO SYS020-RET.                                               
           CALL 'DLSWRITE' USING SYS020-SYS                                     
                                 SYS020-RET                                     
                                 REPORT-RECORD-OUT                              
                                 SYS020-RECL                                    
                                 SYS020-BLK                                     
                                 SYS020-FORMAT                                  
                                 SYS020-CNT.                                    
           IF SYS020-RET IS GREATER THAN +4                                     
           THEN                                                                 
               MOVE ZERO TO WTL-GROUP-NUMBER                                    
               MOVE ZERO TO WTL-GROUP-ACCOUNT                                   
               MOVE 'DLSWRITE CLOSE FAILED - FORCED TO ABEND'                   
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
       300-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       400-CHECK-DATES.                                                         
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1.  IF THE COMP RECORD FALLS WITHIN THE DATES SELECTED,       *         
      *     PROCESS THE RECORD.                                       *         
      *     OTHERWISE, IF IT IS A COMM CLOSE RUN, CHECK IF THE COMP   *         
      *     RECORD SHOULD BE INCLUDED IN THE YEAR TO DATE AND COMM    *         
      *     CLOSE TOTALS.                                             *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           IF COMP-PROCESS-DATE NOT LESS THAN FROM-DATE-A AND                   
              COMP-PROCESS-DATE NOT GREATER THAN TO-DATE-A                      
                PERFORM 500-PROCESS-DATE-FOUND THRU 500-EXIT                    
           ELSE                                                                 
           IF PROCESS-TYPE = 'C'                                                
              PERFORM 450-COMM-CLOSE-TOTALS THRU 450-EXIT.                      
                                                                                
       400-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       450-COMM-CLOSE-TOTALS.                                                   
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1.  IF THE COMP RECORD EXCEEDS THE PREVIOUS YEAR-END CLOSE    *         
      *     BUT DOES NOT EXCEED THE CURRENT COMM CLOSE, ADD TO THE    *         
      *     YTD TOTALS.                                               *         
      * 2.  ADD  1 TO THE DAY OF THE LAST COMM CLOSE DATE.            *         
      * 3.  IF THE COMP RECORD FALLS WITHIN THE DAY AFTER THE LAST    *         
      *     COMM CLOSE AND THIS COMM CLOSE, ADD TO  THE COMM CLOSE    *         
      *     TOTALS.                                                   *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE 0 TO SUB.                                                       
           IF COMP-PROCESS-DATE     > LYC-DATE-A   AND                          
              COMP-PROCESS-DATE NOT > TO-DATE-A                                 
                 PERFORM 600-GET-VCM-GIPSY THRU 600-EXIT                        
                 MOVE GIPSY-PRODUCT-CODE TO SUB                                 
                 ADD COMP-AMT TO TOT-YTD-COMP-AMT (SUB)                         
                 ADD PREM-AMT TO TOT-YTD-PREM-AMT (SUB).                        
                                                                                
MAN02      CALL QDATEQ2 USING QDATE-CA                                          
MAN02                         LAST-COMM-CLOSE                                   
MAN02                         LCC-DATE-A.                                       
           ADD +1 TO LCC-DATE-DAY.                                              
                                                                                
           IF COMP-PROCESS-DATE NOT LESS THAN LCC-DATE-A AND                    
              COMP-PROCESS-DATE NOT GREATER THAN TO-DATE-A                      
186266        MOVE GIPSY-PRODUCT-CODE TO SUB                                    
              ADD COMP-AMT TO TOT-CC-COMP-AMT (SUB)                             
              ADD PREM-AMT TO TOT-CC-PREM-AMT (SUB).                            
                                                                                
       450-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       500-PROCESS-DATE-FOUND.                                                  
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1.  SETUP SALES CREDIT RECORD.                                *         
      * 2.  GET GIPSY RECORD TO DETERMINE PRODUCT TYPE.               *         
      * 3.  WRITE SALES CREDIT RECORD.                                *         
      * 4.  IF COMM CLOSE RUN, ADD TO YTD AND COMM CLOSE TOTALS       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE GROUP-NUMBER      TO RPT-GROUP.                                 
           MOVE GR-ACCOUNT        TO RPT-ACCT.                                  
           MOVE AGENT-NUMBER      TO RPT-AGENT.                                 
           IF COMP-REASON = 'F'                                                 
              MOVE '1' TO RPT-COMP-REASON                                       
           ELSE                                                                 
              IF COMP-REASON = 'A'                                              
                 MOVE '2' TO RPT-COMP-REASON                                    
              ELSE                                                              
                 IF COMP-REASON = 'R'                                           
                    MOVE '3' TO RPT-COMP-REASON                                 
                 ELSE                                                           
                    IF COMP-REASON = 'B'                                        
                       MOVE '4' TO RPT-COMP-REASON                              
                    ELSE                                                        
                       MOVE '9' TO RPT-COMP-REASON.                             
           MOVE COMP-AMT          TO RPT-COMP-AMT.                              
           MOVE PREM-AMT          TO RPT-PREM-AMT.                              
           PERFORM 600-GET-VCM-GIPSY THRU 600-EXIT.                             
           MOVE GIPSY-PRODUCT-CODE TO RPT-PRODUCT-CODE.                         
                                                                                
           PERFORM 700-WRITE-RECORD THRU 700-EXIT.                              
                                                                                
           IF PROCESS-TYPE = 'C'                                                
              MOVE GIPSY-PRODUCT-CODE TO SUB                                    
              ADD COMP-AMT TO TOT-CC-COMP-AMT (SUB)                             
              ADD PREM-AMT TO TOT-CC-PREM-AMT (SUB)                             
              ADD COMP-AMT TO TOT-YTD-COMP-AMT (SUB)                            
              ADD PREM-AMT TO TOT-YTD-PREM-AMT (SUB).                           
       500-EXIT.                                                                
           EXIT.                                                                
                                                                                
       600-GET-VCM-GIPSY.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1.  GET GISPY RECORD AND SET UP PRODUCT CODE                  *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE GROUP-NUMBER   TO NUM-GROUP-NUMBER.                             
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ KEYED (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES                    TO VGWI-SOURCE-SYSTEM.                
           MOVE 'READ KEYED'              TO VGWI-REQUEST.                      
           MOVE SPACES                    TO VGWI-COVERAGE-TYPE.                
           MOVE NUM-GROUP-NUMBER          TO VGWI-GROUP.                        
           MOVE GR-ACCOUNT                TO VGWI-ACCOUNT.                      
           MOVE 'GIPSY EXPANDED'          TO VGWI-LR-NAME.                      
           PERFORM 160-READ-VCM-GIPSY THRU 160-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           ELSE                                                                 
              IF VGWO-RET-CODE = '31'                                           
      *       READ-KEYED RECORD NOT FOUND                                       
                 MOVE '0' TO GGIPRODUCT-CODE                                    
              ELSE                                                              
                 IF VGWO-RET-SEVERE-ERROR                                       
FXXTOK              GO TO 799-SQL-STATUS.                                       
                                                                                
           IF GGIPRODUCT-CODE = 0                                               
              MOVE '4' TO GIPSY-PRODUCT-CODE                                    
           ELSE                                                                 
           IF GGIPRODUCT-CODE = 1                                               
              MOVE '1' TO GIPSY-PRODUCT-CODE                                    
           ELSE                                                                 
           IF GGIPRODUCT-CODE = 2                                               
              MOVE '2' TO GIPSY-PRODUCT-CODE                                    
           ELSE                                                                 
              MOVE '3' TO GIPSY-PRODUCT-CODE.                                   
       600-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       700-WRITE-RECORD.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * WRITE SALES CREDIT REPORT RECORD                              *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING SYS020-SYS                                     
                                 SYS020-RET                                     
                                 REPORT-RECORD-OUT                              
                                 SYS020-RECL                                    
                                 SYS020-BLK                                     
                                 SYS020-FORMAT                                  
                                 SYS020-CNT.                                    
           IF SYS020-RET IS GREATER THAN +4                                     
           THEN                                                                 
               MOVE RPT-GROUP TO WTL-GROUP-NUMBER                               
               MOVE RPT-ACCT TO WTL-GROUP-ACCOUNT                               
               MOVE 'DLSWRITE FAILED - FORCED TO ABEND'                         
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
       700-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          END OF SOURCE                                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
