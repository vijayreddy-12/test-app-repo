       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRBILEX                                                    
      *This program has been examined/renovated for Year 2000 compliance.       
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
      *AUTHOR. DOUG SCOTT.                                                      
      *DATE-WRITTEN.  AUGUST 1984.                                              
      *DATE-COMPILED.                                                           
      *----------------------------------------------------------------*        
      * CALLED BY GPRINTAL TO PROCESS BILLING EXCEPTION REPORT RECORDS.*        
      *----------------------------------------------------------------*        
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  START-WS         VALUE '*--START WS--*' PIC X(14).                   
       01  MISC-WS.                                                             
           05  QDATE-FORMAT-AC  VALUE 'AC'         PIC X(2).                    
           05  MRF-SUB          VALUE +0           PIC S9(4) COMP.              
           05  COV-SUB          VALUE +0           PIC S9(4) COMP.              
           05  BIL-SUB          VALUE +0           PIC S9(4) COMP.              
           05  PRT-SUB          VALUE +0           PIC S9(4) COMP.              
           05  PRINT-SYS012              PIC X(06) VALUE 'SYS012'.              
           05  PRINT-SYS012-COUNT        PIC S9(7)  COMP-3  VALUE +0.           
           05  HEADING-FLAGS.                                                   
               10 RETROACTIVE-IND   VALUE ' '          PIC X.                   
                  88 RETR-TITL-1    VALUE '1'.                                  
               10 STATISTICS-IND    VALUE ' '          PIC X.                   
                  88 STAT-TITL-1    VALUE '1' '2' '3' '4'.                      
                  88 STAT-TITL-2    VALUE '2'.                                  
                  88 STAT-TITL-3    VALUE '3'.                                  
                  88 STAT-TITL-4    VALUE '4'.                                  
               10 REVISED-IND       VALUE ' '          PIC X.                   
                  88 REVI-TITL-1    VALUE '1' '2'.                              
                  88 REVI-TITL-2    VALUE '2'.                                  
               10 HISTORY-IND       VALUE ' '          PIC X.                   
                  88 HIST-TITL-1    VALUE '1' '2' '3'.                          
                  88 HIST-TITL-2    VALUE '2'.                                  
                  88 HIST-TITL-3    VALUE '3'.                                  
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 LINE AND PAGE COUNTERS                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  MAX-LINES        VALUE +0     COMP SYNC PIC S9(4).                   
       01  LINE-COUNT       VALUE +0     COMP SYNC PIC S9(4).                   
       01  PAGE-COUNT       VALUE +0     COMP-3    PIC S9(5).                   
       01  REPORT-TYPE      VALUE '91'             PIC X(2).                    
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                         PAGE HEADINGS                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  HEADING-1.                                                           
           03  FILLER       VALUE '1GPRBILEX'      PIC X(9).                    
           03  FILLER       VALUE SPACES           PIC X(42).                   
           03  FILLER                              PIC X(30)                    
               VALUE 'GIPSY BILLING EXCEPTION REPORT'.                          
           03  FILLER       VALUE SPACES           PIC X(21).                   
           03  FILLER       VALUE 'RUNDATE '       PIC X(8).                    
           03  HD-RUNDATE   VALUE SPACES           PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(3).                    
           03  FILLER       VALUE 'PAGE '          PIC X(5).                    
           03  HD-COUNT     VALUE ZEROS            PIC ZZZZ9.                   
           03  FILLER       VALUE SPACES           PIC X(3).                    
       01  HEADING-2.                                                           
           03  FILLER       VALUE '0'              PIC X(1).                    
           03  FILLER       VALUE 'GROUP '         PIC X(6).                    
GNE        03  HD-GROUP     VALUE ZEROS            PIC ZZZZZZ9.                 
           03  FILLER       VALUE SPACES           PIC XX.                      
           03  FILLER       VALUE 'ACCOUNT '       PIC X(8).                    
           03  FILLER       VALUE SPACES           PIC X.                       
           03  HD-ACCT      VALUE SPACES           PIC X(3).                    
GNE        03  FILLER       VALUE SPACES           PIC X(105).                  
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *               RETROACTIVE AJUSTMENT REPORT                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  RETROACTIVE-1.                                                       
           03  FILLER       VALUE '0 '             PIC X(2).                    
           03  FILLER       VALUE 'RETROACTIVE '   PIC X(12).                   
           03  FILLER       VALUE 'ADJUSTMENT '    PIC X(11).                   
           03  FILLER       VALUE '(D90) -'        PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(100).                  
       01  RETROACTIVE-2.                                                       
           03  FILLER       VALUE SPACES           PIC X(2).                    
           03  FILLER                              PIC X(29)                    
               VALUE '----------------------------'.                            
           03  FILLER       VALUE SPACES           PIC X(102).                  
       01  RETROACTIVE-3.                                                       
           03  FILLER       VALUE SPACES           PIC X(7).                    
           03  FILLER       VALUE 'CERT#'          PIC X(13).                   
           03  FILLER       VALUE 'REMARKS'        PIC X(17).                   
           03  FILLER       VALUE 'EFFDATE'        PIC X(11).                   
           03  FILLER       VALUE 'COV CODE'       PIC X(13).                   
           03  FILLER       VALUE 'PREM ADJ'       PIC X(13).                   
           03  FILLER       VALUE 'COV CODE'       PIC X(13).                   
           03  FILLER       VALUE 'PREM ADJ'       PIC X(13).                   
           03  FILLER       VALUE 'COV CODE'       PIC X(13).                   
           03  FILLER       VALUE 'PREM ADJ'       PIC X(20).                   
       01  RETROACTIVE-4.                                                       
           03  FILLER       VALUE SPACES           PIC X(3).                    
           03  RET-CERT     VALUE ZEROS            PIC Z(9).                    
           03  FILLER       VALUE SPACES           PIC X(2).                    
           03  RET-REMARKS  VALUE SPACES           PIC X(20).                   
           03  FILLER       VALUE SPACES           PIC X(3).                    
           03  RET-EFFDATE  VALUE SPACES           PIC X(7).                    
           03  RET-AMTS OCCURS 3 TIMES.                                         
               05  FILLER                          PIC X(7).                    
               05  RET-COVCODE                     PIC X(3).                    
               05  FILLER                          PIC X(3).                    
               05  RET-PREMADJ                     PIC Z,ZZZ,ZZ9.99-.           
           03  FILLER       VALUE SPACES           PIC X(11).                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 STATISTICS TRAILER REPORT                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  STATISTIC-1.                                                         
           03  FILLER       VALUE '0 '             PIC X(2).                    
           03  FILLER       VALUE 'STATISTICS '    PIC X(11).                   
           03  FILLER       VALUE 'TRAILER / '     PIC X(10).                   
           03  FILLER       VALUE 'BILLING '       PIC X(8).                    
           03  FILLER       VALUE 'CALCULATED '    PIC X(11).                   
           03  FILLER       VALUE 'AMOUNTS '       PIC X(8).                    
           03  FILLER       VALUE 'IMBALANCE -'    PIC X(11).                   
           03  FILLER       VALUE SPACES           PIC X(72).                   
       01  STATISTIC-2.                                                         
           03  FILLER       VALUE SPACES           PIC X(2).                    
           03  FILLER                              PIC X(30)                    
               VALUE '------------------------------'.                          
           03  FILLER                              PIC X(27)                    
               VALUE '---------------------------'.                             
           03  FILLER       VALUE SPACES           PIC X(74).                   
       01  STATISTIC-3.                                                         
           03  FILLER       VALUE SPACES           PIC X(2).                    
           03  FILLER       VALUE 'STATISTICS '    PIC X(11).                   
           03  FILLER       VALUE 'TRAILER:'       PIC X(8).                    
           03  FILLER       VALUE SPACES           PIC X(112).                  
       01  STATISTIC-4.                                                         
           03  FILLER       VALUE '0'              PIC X(1).                    
           03  FILLER       VALUE SPACES           PIC X(3).                    
           03  FILLER       VALUE 'NUMBER OF '     PIC X(10).                   
           03  FILLER       VALUE 'LIVES '         PIC X(6).                    
           03  FILLER       VALUE 'INSURED -'      PIC X(9).                    
           03  STAT-LIVES   VALUE ZEROS            PIC Z,ZZZ,ZZ9.               
           03  FILLER       VALUE SPACES           PIC X(95).                   
       01  STATISTIC-5.                                                         
           03  FILLER       VALUE SPACES           PIC X(74).                   
           03  FILLER       VALUE 'E H C'          PIC X(36).                   
           03  FILLER       VALUE 'DENTAL'         PIC X(23).                   
       01  STATISTIC-6.                                                         
           03  FILLER       VALUE ' '              PIC X(1).                    
           03  FILLER       VALUE SPACES           PIC X(17).                   
           03  FILLER       VALUE 'LIFE'           PIC X(13).                   
           03  FILLER       VALUE 'LTD'            PIC X(11).                   
           03  FILLER       VALUE 'AD&D'           PIC X(14).                   
           03  FILLER       VALUE 'WI'             PIC X(8).                    
           03  FILLER       VALUE 'SINGLE'         PIC X(14).                   
           03  FILLER       VALUE 'FAM1'           PIC X(12).                   
           03  FILLER       VALUE 'FAM2'           PIC X(10).                   
           03  FILLER       VALUE 'SINGLE'         PIC X(14).                   
           03  FILLER       VALUE 'FAM1'           PIC X(12).                   
           03  FILLER       VALUE 'FAM2'           PIC X(7).                    
       01  STATISTIC-7.                                                         
           03  FILLER       VALUE '0PREMIUMS - '   PIC X(12).                   
           03  STA-LIFE     VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-LTD      VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-AD-D     VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-WI       VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-EHC-S    VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-EHC-F1   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-EHC-F2   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-DEN-S    VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-DEN-F1   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  STA-DEN-F2   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X(3).                    
       01  STATISTIC-8.                                                         
           03  FILLER       VALUE '0PREM ADJ - '   PIC X(12).                   
           03  ST8-LIFE     VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-LTD      VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-AD-D     VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-WI       VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-EHC-S    VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-EHC-F1   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-EHC-F2   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-DEN-S    VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-DEN-F1   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X.                       
           03  ST8-DEN-F2   VALUE ZEROS            PIC ZZZZZZ9.99-.             
           03  FILLER       VALUE SPACES           PIC X(3).                    
       01  STATISTIC-9.                                                         
           03  FILLER       VALUE '0'              PIC X(1).                    
           03  FILLER       VALUE SPACES           PIC X(8).                    
           03  FILLER       VALUE 'COV CODE'       PIC X(16).                   
           03  FILLER       VALUE 'VOL'            PIC X(8).                    
           03  FILLER       VALUE 'LIVES'          PIC X(7).                    
           03  FILLER       VALUE 'COV CODE'       PIC X(16).                   
           03  FILLER       VALUE 'VOL'            PIC X(8).                    
           03  FILLER       VALUE 'LIVES'          PIC X(7).                    
           03  FILLER       VALUE 'COV CODE'       PIC X(16).                   
           03  FILLER       VALUE 'VOL'            PIC X(8).                    
           03  FILLER       VALUE 'LIVES'          PIC X(7).                    
           03  FILLER       VALUE 'COV CODE'       PIC X(16).                   
           03  FILLER       VALUE 'VOL'            PIC X(8).                    
           03  FILLER       VALUE 'LIVES'          PIC X(7).                    
       01  STATISTIC-10.                                                        
           03  STA-10-CC    VALUE '0'              PIC X(1).                    
           03  FILLER       VALUE SPACES           PIC X(6).                    
           03  STA-AMT OCCURS 4 TIMES.                                          
               05  FILLER                          PIC X(5).                    
               05  STA-COV                         PIC X(3).                    
               05  FILLER                          PIC X(2).                    
               05  STA-VOL                         PIC ZZZ,ZZZ,ZZ9.             
               05  FILLER                          PIC X(1).                    
               05  STA-LIVES                       PIC Z,ZZZ,ZZ9.               
           03  FILLER       VALUE SPACES           PIC X(2).                    
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *               BILLING HISTORY TRAILER REPORT                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  BILLING-1.                                                           
           03  FILLER       VALUE '0 '             PIC X(2).                    
           03  FILLER       VALUE 'BILLING '       PIC X(8).                    
           03  FILLER       VALUE 'HISTORY '       PIC X(8).                    
           03  FILLER       VALUE 'TRAILER / '     PIC X(10).                   
           03  FILLER       VALUE 'BILLING '       PIC X(8).                    
           03  FILLER       VALUE 'CALCULATED '    PIC X(11).                   
           03  FILLER       VALUE 'AMOUNTS '       PIC X(8).                    
           03  FILLER       VALUE 'IMBALANCE -'    PIC X(11).                   
           03  FILLER       VALUE SPACES           PIC X(67).                   
       01  BILLING-2.                                                           
           03  FILLER       VALUE SPACES           PIC X(2).                    
           03  FILLER                              PIC X(31)                    
               VALUE '-------------------------------'.                         
           03  FILLER                              PIC X(31)                    
               VALUE '-------------------------------'.                         
           03  FILLER       VALUE SPACES           PIC X(69).                   
       01  BILLING-3.                                                           
           03  FILLER       VALUE SPACES           PIC X(3).                    
           03  FILLER       VALUE 'BILLING '       PIC X(8).                    
           03  FILLER       VALUE 'HISTORY '       PIC X(8).                    
           03  FILLER       VALUE 'TRAILER: '      PIC X(9).                    
           03  FILLER       VALUE '(REPLACES)'     PIC X(13).                   
           03  FILLER       VALUE 'PREMIUM DUE'    PIC X(13).                   
           03  FILLER       VALUE 'STMT PREPARED'  PIC X(15).                   
           03  FILLER       VALUE 'TOTAL PREMIUM'  PIC X(18).                   
           03  FILLER       VALUE '# CERTS'        PIC X(48).                   
       01  BILLING-4.                                                           
           03  FILLER       VALUE '0'              PIC X(1).                    
           03  FILLER       VALUE SPACES           PIC X(42).                   
           03  BIL-PDUEDATE VALUE SPACES           PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(6).                    
           03  BIL-STMTDATE VALUE SPACES           PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(6).                    
           03  BIL-TOTPREM  VALUE ZEROS            PIC Z,ZZZ,ZZ9.99-.           
           03  FILLER       VALUE SPACES           PIC X(4).                    
           03  BIL-NOCERTS  VALUE ZEROS            PIC Z,ZZZ,ZZ9.               
           03  FILLER       VALUE SPACES           PIC X(40).                   
       01  BILLING-5.                                                           
           03  FILLER       VALUE '0   '           PIC X(4).                    
           03  FILLER       VALUE 'COV CODE'       PIC X(10).                   
           03  FILLER       VALUE 'AMOUNT BILLED'  PIC X(17).                   
           03  FILLER       VALUE 'LIVES'          PIC X(12).                   
           03  FILLER       VALUE 'VOLUME'         PIC X(10).                   
           03  FILLER       VALUE 'COV CODE'       PIC X(10).                   
           03  FILLER       VALUE 'AMOUNT BILLED'  PIC X(17).                   
           03  FILLER       VALUE 'LIVES'          PIC X(12).                   
           03  FILLER       VALUE 'VOLUME'         PIC X(41).                   
       01  BILLING-6.                                                           
           03  BIL-6-CC     VALUE '0'              PIC X.                       
           03  FILLER       VALUE SPACES           PIC X(3).                    
           03  BILLING-AMT1 OCCURS 2 TIMES.                                     
               05  FILLER                          PIC X(3).                    
               05  BIL1-COVCODE                    PIC X(3).                    
               05  FILLER                          PIC X(5).                    
               05  BIL1-BILLED                     PIC Z,ZZZ,ZZ9.99-.           
               05  FILLER                          PIC X(2).                    
               05  BIL1-LIVES                      PIC ZZ,ZZ9.                  
               05  FILLER                          PIC X(2).                    
               05  BIL1-VOLUME                     PIC ZZZ,ZZZ,ZZ9.             
               05  FILLER                          PIC X(4).                    
           03  FILLER       VALUE SPACES           PIC X(1).                    
       01  BILLING-7.                                                           
           03  FILLER       VALUE '0  '            PIC X(3).                    
           03  FILLER       VALUE 'BILLING '       PIC X(8).                    
           03  FILLER       VALUE 'CALCULATED '    PIC X(11).                   
           03  FILLER       VALUE 'AMOUNTS:'       PIC X(19).                   
           03  FILLER       VALUE 'PREPARED DATE'  PIC X(16).                   
           03  FILLER       VALUE 'PREMIUM DUE'    PIC X(14).                   
           03  FILLER       VALUE 'NO. LIVES '     PIC X(10).                   
           03  FILLER       VALUE 'INSURED'        PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(48).                   
       01  BILLING-8.                                                           
           03  FILLER       VALUE '0'              PIC X(1).                    
           03  FILLER       VALUE SPACES           PIC X(43).                   
           03  BIL-PREPDATE VALUE SPACES           PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(5).                    
           03  BIL-PREMDUE  VALUE ZEROS            PIC Z,ZZZ,ZZ9.99-.           
           03  FILLER       VALUE SPACES           PIC X(5).                    
           03  BIL-LIVES    VALUE ZEROS            PIC Z,ZZZ,ZZ9.               
           03  FILLER       VALUE SPACES           PIC X(50).                   
       01  BILLING-9.                                                           
           03  FILLER       VALUE '0   '           PIC X(4).                    
           03  FILLER       VALUE 'COV CODE'       PIC X(10).                   
           03  FILLER       VALUE 'AMOUNT BILLED'  PIC X(15).                   
           03  FILLER       VALUE 'D90 RETRO ADJ'  PIC X(17).                   
           03  FILLER       VALUE 'LIVES'          PIC X(12).                   
           03  FILLER       VALUE 'VOLUME'         PIC X(09).                   
           03  FILLER       VALUE 'COV CODE'       PIC X(10).                   
           03  FILLER       VALUE 'AMOUNT BILLED'  PIC X(15).                   
           03  FILLER       VALUE 'D90 RETRO ADJ'  PIC X(17).                   
           03  FILLER       VALUE 'LIVES'          PIC X(12).                   
           03  FILLER       VALUE 'VOLUME'         PIC X(12).                   
       01  BILLING-10.                                                          
           03  BIL-10-CC    VALUE '0'              PIC X.                       
           03  BILLING-AMT2 OCCURS 2 TIMES.                                     
               05  FILLER                          PIC X(6).                    
               05  BIL2-COVCODE                    PIC X(3).                    
               05  FILLER                          PIC X(2).                    
               05  BIL2-BILLED                     PIC Z,ZZZ,ZZ9.99-.           
               05  FILLER                          PIC X(2).                    
               05  BIL2-RETADJ                     PIC Z,ZZZ,ZZ9.99-.           
               05  FILLER                          PIC X(2).                    
               05  BIL2-LIVES                      PIC Z,ZZZ,ZZ9.               
               05  FILLER                          PIC X(2).                    
               05  BIL2-VOLUME                     PIC ZZZ,ZZZ,ZZ9.             
           03  FILLER       VALUE SPACES           PIC X(2).                    
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  REVISED BILLING REPORT                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REVISED-1.                                                           
           03  FILLER       VALUE '0 '             PIC X(2).                    
           03  FILLER       VALUE 'REVISED '       PIC X(8).                    
           03  FILLER       VALUE 'BILLING -'      PIC X(9).                    
           03  FILLER       VALUE SPACES           PIC X(114).                  
       01  REVISED-2.                                                           
           03  FILLER       VALUE SPACES           PIC X(2).                    
           03  FILLER                              PIC X(131)                   
               VALUE '----------------'.                                        
       01  REVISED-3.                                                           
           03  FILLER       VALUE SPACES           PIC X(3).                    
           03  FILLER       VALUE 'BILLING '       PIC X(8).                    
           03  FILLER       VALUE 'HISTORY '       PIC X(8).                    
           03  FILLER       VALUE 'TRAILER: '      PIC X(9).                    
           03  FILLER       VALUE '(REPLACED)'     PIC X(14).                   
           03  FILLER       VALUE 'PREMIUM DUE'    PIC X(13).                   
           03  FILLER       VALUE 'STMT PREPARED'  PIC X(15).                   
           03  FILLER       VALUE 'TOTAL PREMIUM'  PIC X(18).                   
           03  FILLER       VALUE '# CERTS'        PIC X(48).                   
       01  REVISED-4.                                                           
           03  FILLER       VALUE '0'              PIC X(1).                    
           03  FILLER       VALUE SPACES           PIC X(42).                   
           03  REV-PDUEDATE VALUE SPACES           PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(6).                    
           03  REV-STMTDATE VALUE SPACES           PIC X(7).                    
           03  FILLER       VALUE SPACES           PIC X(6).                    
           03  REV-TOTPREM  VALUE ZEROS            PIC Z,ZZZ,ZZ9.99-.           
           03  FILLER       VALUE SPACES           PIC X(4).                    
           03  REV-NOCERTS  VALUE ZEROS            PIC Z,ZZZ,ZZ9.               
           03  FILLER       VALUE SPACES           PIC X(40).                   
       01  REVISED-5.                                                           
           03  FILLER       VALUE '0'              PIC X.                       
           03  FILLER       VALUE SPACES           PIC X(14).                   
           03  FILLER       VALUE 'COV CODE'       PIC X(10).                   
           03  FILLER       VALUE 'AMOUNT BILLED'  PIC X(18).                   
           03  FILLER       VALUE 'LIVES'          PIC X(12).                   
           03  FILLER       VALUE 'VOLUME'         PIC X(07).                   
           03  FILLER       VALUE 'COV CODE'       PIC X(10).                   
           03  FILLER       VALUE 'AMOUNT BILLED'  PIC X(18).                   
           03  FILLER       VALUE 'LIVES'          PIC X(12).                   
           03  FILLER       VALUE 'VOLUME'         PIC X(31).                   
       01  REVISED-6.                                                           
           03  FILLER       VALUE SPACES           PIC X(16).                   
           03  REVISED-AMTS OCCURS 2 TIMES.                                     
               05  FILLER                          PIC X(2).                    
               05  REV-COVCODE                     PIC X(3).                    
               05  FILLER                          PIC X(5).                    
               05  REV-BILLED                      PIC Z,ZZZ,ZZ9.99-.           
               05  FILLER                          PIC X(3).                    
               05  REV-LIVES                       PIC ZZ,ZZ9.                  
               05  FILLER                          PIC X(2).                    
               05  REV-VOLUME                      PIC ZZZ,ZZZ,ZZ9.             
               05  FILLER                          PIC X(2).                    
           03  FILLER       VALUE SPACES           PIC X(35).                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                     PRINT LINE LAYOUT                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-AREA.                                                          
           03  PRT-CC       VALUE SPACES           PIC X(1).                    
           03  PRT-LINE     VALUE SPACES           PIC X(132).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *  AREA USED TO SAVE PRINT LINE WHILE HEADING ARE BEING WRITTEN  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  SAVE-PRINT-AREA  VALUE SPACES           PIC X(133).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *               CURRENT AND PREVIOUS RECORD KEYS                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PREV-CERT        VALUE +0                PIC S9(9) COMP-3.           
       01  CURRENT-KEY.                                                         
           03  C-SEG1.                                                          
               05  CURR-ACCOUNT                    PIC X(3)                     
                                                   VALUE   LOW-VALUES.          
GNE            05  CURR-GROUP-NUMBER     COMP-3    PIC S9(7).                   
           03  C-SEG2.                                                          
               05  CURR-ORDER                      PIC X(1)                     
                                                   VALUE   LOW-VALUES.          
       01  PREVIOUS-KEY.                                                        
           03  P-SEG1.                                                          
               05  PREV-ACCOUNT                    PIC X(3)                     
                                                   VALUE   LOW-VALUES.          
GNE            05  PREV-GROUP-NUMBER     COMP-3    PIC S9(7).                   
           03  P-SEG2.                                                          
               05  PREV-ORDER                      PIC X(1)                     
                                                   VALUE   LOW-VALUES.          
                                                                                
       01  END-WS           VALUE '*---WS END---*' PIC X(14).                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *        PARAMETERS PASSED TO THIS PROGRAM BY THE CALLER         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       LINKAGE SECTION.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *              BILLING EXCEPTION RECORD LAYOUT                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  BILLING-EXCEPTION.                                                   
GNE                           COPY 'GFMBERR7' REPLACING                         
                               ==01  GFMBILLING-EXCEPTIONS.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *                LAYOUT OF RESTART INFORMATION                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  MISCELLANEOUS-AREA.                                                  
           03  LOW-DATE            COMP-3.                                      
               05  LOW-DATE-YEAR                   PIC S9(3).                   
               05  LOW-DATE-DAY                    PIC S9(3).                   
           03  HIGH-DATE           COMP-3.                                      
               05  HIGH-DATE-YEAR                  PIC S9(3).                   
               05  HIGH-DATE-DAY                   PIC S9(3).                   
           03  STAT-DATE           COMP-3.                                      
               05  STAT-DATE-YEAR                  PIC S9(3).                   
               05  STAT-DATE-DAY                   PIC S9(3).                   
           03  PREMIUM-CLOSING-DATE  COMP-3.                                    
               05  PREMIUM-CLOSING-YEAR            PIC S9(3).                   
               05  PREMIUM-CLOSING-DAY             PIC S9(3).                   
           03  RESTART-INFORMATION.                                             
               05  RESTART-RECORD-TYPE             PIC X(1).                    
               05  FILLER                          PIC X(11).                   
           03  CURRENT-LOW-DATE       COMP-3.                                   
               05  CURRENT-LOW-YEAR                PIC S9(3).                   
               05  CURRENT-LOW-DAY                 PIC S9(3).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                      PRINT PARAMETERS                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-PARAMETERS.                                                    
                             COPY 'GPRPRINT' REPLACING                          
                                            ==01  GPRPRINT.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *                       TAPE PARAMETERS                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-PARAMETERS.                                                     
                            COPY 'GPRTPARM' REPLACING                           
                                            ==01  GPRTPARM.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *                     REPORT ACCUMLATORS                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-ACCUMULATORS.                                                 
                                COPY 'GPRACCUM' REPLACING                       
                                            ==01  GPRACCUM.== BY ====.          
                                                                                
       PROCEDURE DIVISION USING BILLING-EXCEPTION                               
                                MISCELLANEOUS-AREA                              
                                PRINT-PARAMETERS                                
                                TAPE-PARAMETERS                                 
                                REPORT-ACCUMULATORS.                            
       MAINLINE.                                                                
                                                                                
           PERFORM INITIALIZATION-ROUTINE-BGN THRU                              
                   INITIALIZATION-ROUTINE-END.                                  
           PERFORM PROCESS-RECORDS THRU                                         
                   PROCESS-RECORDS UNTIL                                        
                   (TAPE-RETURN IS NOT EQUAL TO +0)                             
                   OR  (GFMBE-RECORD-TYPE NOT EQUAL TO 'V').                    
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
                                                                                
       INITIALIZATION-ROUTINE-BGN.                                              
      *----------------------------------------------------------------*        
      *                                                                *        
      *               INITIALIZATION VARIOUS FIELDS                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              HIGH-DATE                                         
                              HD-RUNDATE.                                       
           CALL 'ZLINECT' USING MAX-LINES.                                      
           SUBTRACT +1 FROM MAX-LINES.                                          
                                                                                
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          REPORT-TYPE.                                   
                                                                                
           MOVE ZERO TO PRINT-RETURN.                                           
                                                                                
           MOVE SPACES TO BILLING-AMT1(1)                                       
                          BILLING-AMT1(2)                                       
                          BILLING-AMT2(1)                                       
                          BILLING-AMT2(2)                                       
                          REVISED-AMTS(1)                                       
                          REVISED-AMTS(2).                                      
       INITIALIZATION-ROUTINE-END.                                              
           EXIT.                                                                
                                                                                
       PROCESS-RECORDS.                                                         
      *----------------------------------------------------------------*        
      *  SET UP THE KEYS.                                              *        
      *  PROCESS THE RECORD PREVIOUSLY READ, AND READ THE NEXT RECORD  *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE CURRENT-KEY TO PREVIOUS-KEY.                                    
           MOVE GFMBE-GROUP-NUMBER TO CURR-GROUP-NUMBER.                        
           MOVE GFMBE-ACCOUNT      TO CURR-ACCOUNT.                             
           MOVE GFMBE-ORDER        TO CURR-ORDER.                               
           IF C-SEG1 NOT EQUAL P-SEG1                                           
                MOVE SPACES TO HEADING-FLAGS                                    
                PERFORM HEADING-ROUTINE-BGN THRU                                
                        HEADING-ROUTINE-END.                                    
                                                                                
           PERFORM CREATE-WRITE-RECORD THRU                                     
                   CREATE-WRITE-RECORD-EXIT.                                    
                                                                                
           PERFORM READ-ROUTINE-BGN THRU                                        
                   READ-ROUTINE-END.                                            
       PROCESS-RECORDS-END.                                                     
           EXIT.                                                                
                                                                                
       CREATE-WRITE-RECORD.                                                     
      *----------------------------------------------------------------*        
      * DETERMINE WHAT KIND OF A RECORD WE HAVE, AND PRODUCE THE       *        
      * APPROPRIATE PART OF THE REPORT.                                *        
      * IF WE GET DIFFERENT RECORD, WE NEED AT LEAST 5 LINES TO        *        
      * PUT TITLES, ETC OUT                                            *        
      *----------------------------------------------------------------*        
           IF CURRENT-KEY NOT EQUAL PREVIOUS-KEY                                
           AND (LINE-COUNT + 5) GREATER THAN MAX-LINES THEN                     
                MOVE SPACES TO HEADING-FLAGS                                    
                PERFORM HEADING-ROUTINE-BGN THRU                                
                        HEADING-ROUTINE-END.                                    
                                                                                
           IF  GFMBE-ORDER IS EQUAL TO '1' THEN                                 
               PERFORM PROCESS-RETROACTIVE THRU                                 
                       PROCESS-RETROACTIVE-EXIT                                 
           ELSE                                                                 
           IF  GFMBE-ORDER IS EQUAL TO '2' THEN                                 
               PERFORM PROCESS-STATISTICS THRU                                  
                       PROCESS-STATISTICS-EXIT                                  
           ELSE                                                                 
           IF  GFMBE-ORDER IS EQUAL TO '3' THEN                                 
               PERFORM PROCESS-REVISED THRU                                     
                       PROCESS-REVISED-EXIT                                     
           ELSE                                                                 
           IF  GFMBE-ORDER IS EQUAL TO '4' THEN                                 
               PERFORM PROCESS-BILL-HIST THRU                                   
                       PROCESS-BILL-HIST-EXIT.                                  
       CREATE-WRITE-RECORD-EXIT.                                                
           EXIT.                                                                
                                                                                
       PROCESS-RETROACTIVE.                                                     
      *----------------------------------------------------------------*        
      * SET UP THE PRINT LINE AND TITLES IF NECESSARY, AND PRINT OUT   *        
      * CURRENT INFORMATION.                                           *        
      *----------------------------------------------------------------*        
           IF CURRENT-KEY NOT EQUAL PREVIOUS-KEY THEN                           
                MOVE '1' TO RETROACTIVE-IND                                     
                PERFORM RETROACTIVE-HEADING-BGN THRU                            
                        RETROACTIVE-HEADING-END.                                
                                                                                
           IF GFMBE-D90-CERTIFICATE NOT EQUAL PREV-CERT THEN                    
               MOVE GFMBE-D90-CERTIFICATE TO RET-CERT, PREV-CERT                
           ELSE                                                                 
               MOVE ZEROES TO RET-CERT.                                         
           MOVE GFMBE-D90-REMARKS     TO RET-REMARKS.                           
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              GFMBE-D90-EFFECTIVE-DATE                          
                              RET-EFFDATE.                                      
           MOVE SPACES TO RET-AMTS(1)                                           
                          RET-AMTS(2)                                           
                          RET-AMTS(3).                                          
                                                                                
           PERFORM MOVE-RET-FIELDS THRU                                         
                   MOVE-RET-FIELDS-EXIT                                         
                   VARYING MRF-SUB FROM +1 BY +1                                
                   UNTIL   MRF-SUB GREATER THAN                                 
                           GFMBE-D90-NO-OF-CODES.                               
           MOVE RETROACTIVE-4 TO PRINT-AREA.                                    
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           MOVE SPACE TO RETROACTIVE-IND.                                       
       PROCESS-RETROACTIVE-EXIT.                                                
           EXIT.                                                                
                                                                                
       MOVE-RET-FIELDS.                                                         
           MOVE GFMBE-D90-CODE( MRF-SUB ) TO RET-COVCODE( MRF-SUB ).            
           MOVE GFMBE-D90-PREM-ADJ( MRF-SUB )                                   
                                          TO RET-PREMADJ( MRF-SUB ).            
       MOVE-RET-FIELDS-EXIT.                                                    
           EXIT.                                                                
                                                                                
       PROCESS-STATISTICS.                                                      
      *----------------------------------------------------------------*        
      * SET UP THE TITLES, AND PRINT LINES FOR THE STATISTICS PART     *        
      * OF THE REPORT.                                                 *        
      *----------------------------------------------------------------*        
           MOVE '1' TO STATISTICS-IND.                                          
           IF CURRENT-KEY NOT EQUAL PREVIOUS-KEY THEN                           
               PERFORM STATISTICS-HEADING-BGN THRU                              
                       STATISTICS-HEADING-END                                   
               MOVE GFMBE-STAT-INSURED-LIVES TO STAT-LIVES                      
               MOVE STATISTIC-4 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +2 TO LINE-COUNT.                                            
                                                                                
           MOVE '2' TO STATISTICS-IND.                                          
           IF (LINE-COUNT + 3) GREATER THAN MAX-LINES THEN                      
                MOVE MAX-LINES TO LINE-COUNT                                    
           ELSE                                                                 
               MOVE STATISTIC-5 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               MOVE STATISTIC-6 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +2 TO LINE-COUNT.                                            
                                                                                
           PERFORM PROC-STAT-PREM THRU                                          
                   PROC-STAT-PREM-EXIT.                                         
           PERFORM PROC-STAT-PRADJ THRU                                         
                   PROC-STAT-PRADJ-EXIT.                                        
                                                                                
           MOVE '1' TO STATISTICS-IND.                                          
           IF GFMBE-STAT-NO-OF-CODES GREATER THAN ZERO THEN                     
                PERFORM PROC-STAT-COVERAGE THRU                                 
                        PROC-STAT-COVERAGE-EXIT.                                
                                                                                
           MOVE '1' TO STATISTICS-IND.                                          
           IF (LINE-COUNT + 4) GREATER THAN MAX-LINES THEN                      
                MOVE MAX-LINES TO LINE-COUNT.                                   
           MOVE  BILLING-7 TO PRINT-AREA.                                       
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
                                                                                
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              GFMBE-BILL-PREPARED-DATE                          
                              BIL-PREPDATE.                                     
           MOVE GFMBE-BILL-PREMIUM-DUE   TO BIL-PREMDUE.                        
           MOVE GFMBE-BILL-INSURED-LIVES TO BIL-LIVES.                          
           MOVE  BILLING-8 TO PRINT-AREA.                                       
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
                                                                                
           IF GFMBE-BILL-NO-OF-CODES GREATER THAN ZERO THEN                     
                PERFORM PROC-STAT-BILLING THRU                                  
                        PROC-STAT-BILLING-EXIT.                                 
           MOVE SPACE TO STATISTICS-IND.                                        
       PROCESS-STATISTICS-EXIT.                                                 
           EXIT.                                                                
       PROC-STAT-PREM.                                                          
      *----------------------------------------------------------------*        
      * MOVE IN PREMIUM AMOUNT INFORMATION                             *        
      *----------------------------------------------------------------*        
           MOVE GFMBE-PREM-LIFE   TO STA-LIFE.                                  
           MOVE GFMBE-PREM-LTD    TO STA-LTD.                                   
           MOVE GFMBE-PREM-ADD    TO STA-AD-D.                                  
           MOVE GFMBE-PREM-WI     TO STA-WI.                                    
           MOVE GFMBE-PREM-EHC-SIN   TO STA-EHC-S.                              
           MOVE GFMBE-PREM-EHC-FAM1  TO STA-EHC-F1.                             
           MOVE GFMBE-PREM-EHC-FAM2  TO STA-EHC-F2.                             
           MOVE GFMBE-PREM-DEN-SIN   TO STA-DEN-S.                              
           MOVE GFMBE-PREM-DEN-FAM1  TO STA-DEN-F1.                             
           MOVE GFMBE-PREM-DEN-FAM2  TO STA-DEN-F2.                             
           MOVE STATISTIC-7 TO PRINT-AREA.                                      
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
       PROC-STAT-PREM-EXIT.                                                     
           EXIT.                                                                
                                                                                
       PROC-STAT-PRADJ.                                                         
      *----------------------------------------------------------------*        
      * MOVE IN PREMIUM ADJUSTMENT INFORMATION                         *        
      *----------------------------------------------------------------*        
           MOVE GFMBE-PADJ-LIFE   TO ST8-LIFE.                                  
           MOVE GFMBE-PADJ-LTD    TO ST8-LTD.                                   
           MOVE GFMBE-PADJ-ADD    TO ST8-AD-D.                                  
           MOVE GFMBE-PADJ-WI     TO ST8-WI.                                    
           MOVE GFMBE-PADJ-EHC-SIN   TO ST8-EHC-S.                              
           MOVE GFMBE-PADJ-EHC-FAM1  TO ST8-EHC-F1.                             
           MOVE GFMBE-PADJ-EHC-FAM2  TO ST8-EHC-F2.                             
           MOVE GFMBE-PADJ-DEN-SIN   TO ST8-DEN-S.                              
           MOVE GFMBE-PADJ-DEN-FAM1  TO ST8-DEN-F1.                             
           MOVE GFMBE-PADJ-DEN-FAM2  TO ST8-DEN-F2.                             
           MOVE STATISTIC-8 TO PRINT-AREA.                                      
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
       PROC-STAT-PRADJ-EXIT.                                                    
           EXIT.                                                                
       PROC-STAT-COVERAGE.                                                      
      *----------------------------------------------------------------*        
      * PRODUCE THE COVERAGE PART OF STATISTICS REPORT                 *        
      *----------------------------------------------------------------*        
           MOVE '3' TO STATISTICS-IND.                                          
           IF (LINE-COUNT + 4) IS GREATER THAN MAX-LINES THEN                   
                MOVE MAX-LINES TO LINE-COUNT                                    
           ELSE                                                                 
                MOVE STATISTIC-9 TO PRINT-AREA                                  
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END.                                         
                                                                                
           MOVE +0 TO COV-SUB PRT-SUB.                                          
           PERFORM PROC-STAT-COV-RTN THRU                                       
                   PROC-STAT-COV-RTN-EXIT.                                      
           MOVE STATISTIC-10 TO PRINT-AREA.                                     
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           MOVE '0'    TO STA-10-CC.                                            
       PROC-STAT-COVERAGE-EXIT.                                                 
           EXIT.                                                                
       PROC-STAT-COV-RTN.                                                       
      *----------------------------------------------------------------*        
      * MOVE FROM ONE OF 15 COVERAGE INFO FIELDS TO ONE OF 4 PRT FIELDS*        
      * THIS WILL GENERATE FROM 1 TO 4 PRINT-LINES                     *        
      *----------------------------------------------------------------*        
           ADD +1 TO COV-SUB.                                                   
           ADD +1 TO PRT-SUB.                                                   
           IF COV-SUB GREATER THAN GFMBE-STAT-NO-OF-CODES THEN                  
                GO TO PROC-STAT-COV-RTN-EXIT.                                   
           IF PRT-SUB GREATER THAN +4 THEN                                      
                MOVE +1 TO PRT-SUB                                              
                MOVE STATISTIC-10 TO PRINT-AREA                                 
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END                                          
                MOVE SPACES TO STATISTIC-10.                                    
                                                                                
           MOVE GFMBE-STAT-COVERAGE-CODE(COV-SUB) TO STA-COV(PRT-SUB).          
           MOVE GFMBE-STAT-VOLUME(COV-SUB) TO STA-VOL(PRT-SUB).                 
           MOVE GFMBE-STAT-LIVES(COV-SUB)  TO STA-LIVES(PRT-SUB).               
                                                                                
           GO TO PROC-STAT-COV-RTN.                                             
       PROC-STAT-COV-RTN-EXIT.                                                  
           EXIT.                                                                
                                                                                
       PROC-STAT-BILLING.                                                       
      *----------------------------------------------------------------*        
      * PRODUCE THE BILLING AMOUNTS PORTION OF THE STATISTICS PART OF  *        
      * THE REPORT                                                     *        
      *----------------------------------------------------------------*        
           MOVE '4' TO STATISTICS-IND.                                          
           IF (LINE-COUNT + 4) IS GREATER THAN MAX-LINES THEN                   
                MOVE MAX-LINES TO LINE-COUNT                                    
           ELSE                                                                 
                MOVE BILLING-9 TO PRINT-AREA                                    
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END.                                         
                                                                                
           MOVE +0 TO BIL-SUB PRT-SUB.                                          
           PERFORM PROC-STAT-BILL-RTN THRU                                      
                   PROC-STAT-BILL-RTN-EXIT.                                     
           MOVE BILLING-10 TO PRINT-AREA.                                       
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           MOVE '0'    TO BIL-10-CC.                                            
       PROC-STAT-BILLING-EXIT.                                                  
           EXIT.                                                                
       PROC-STAT-BILL-RTN.                                                      
      *----------------------------------------------------------------*        
      * PRODUCE THE BILLING AMOUNTS PORTION OF THE STATISTICS PART OF  *        
      * THE REPORT                                                     *        
      *----------------------------------------------------------------*        
           ADD +1 TO BIL-SUB.                                                   
           ADD +1 TO PRT-SUB.                                                   
           IF BIL-SUB GREATER THAN GFMBE-BILL-NO-OF-CODES THEN                  
                GO TO PROC-STAT-BILL-RTN-EXIT.                                  
           IF PRT-SUB GREATER THAN +2 THEN                                      
                MOVE +1 TO PRT-SUB                                              
                MOVE BILLING-10 TO PRINT-AREA                                   
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END                                          
                MOVE SPACES TO BILLING-10.                                      
                                                                                
           MOVE GFMBE-BILL-COV-CODE(BIL-SUB) TO BIL2-COVCODE(PRT-SUB).          
           MOVE GFMBE-BILL-AMT-BILLED(BIL-SUB) TO BIL2-BILLED(PRT-SUB).         
           MOVE GFMBE-BILL-D90-ADJ(BIL-SUB) TO BIL2-RETADJ(PRT-SUB).            
           MOVE GFMBE-BILL-LIVES(BIL-SUB)   TO BIL2-LIVES(PRT-SUB).             
           MOVE GFMBE-BILL-VOLUME(BIL-SUB)  TO BIL2-VOLUME(PRT-SUB).            
                                                                                
           GO TO PROC-STAT-BILL-RTN.                                            
       PROC-STAT-BILL-RTN-EXIT.                                                 
           EXIT.                                                                
                                                                                
       PROCESS-REVISED.                                                         
      *----------------------------------------------------------------*        
      * PROCESS THE REVISED RECORD - ORDER 3, -REMEMBER TO STICK IN    *        
      * WHAT TITLES ARE REQUIRED TO PRINT IF WE ARE GOING TO RUN OVER  *        
      * A PAGE                                                         *        
      *----------------------------------------------------------------*        
           IF CURRENT-KEY NOT EQUAL PREVIOUS-KEY THEN                           
                MOVE '1' TO REVISED-IND                                         
                PERFORM REVISED-HEADING-BGN THRU                                
                        REVISED-HEADING-END.                                    
                                                                                
           MOVE REVISED-3 TO PRINT-AREA.                                        
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              GFMBE-REV-BILL-PREM-DUE-DATE                      
                              REV-PDUEDATE.                                     
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              GFMBE-REV-BILL-PREPARED-DATE                      
                              REV-STMTDATE.                                     
           MOVE GFMBE-REV-BILL-PREMIUM-DUE TO REV-TOTPREM.                      
           MOVE GFMBE-REV-BILL-NO-CERTS    TO REV-NOCERTS.                      
           MOVE REVISED-4 TO PRINT-AREA.                                        
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
                                                                                
           IF GFMBE-REV-BILL-NO-OF-CODES GREATER THAN ZERO THEN                 
                PERFORM PROC-REV-BILLING THRU                                   
                        PROC-REV-BILLING-EXIT.                                  
           MOVE SPACES TO REVISED-IND.                                          
       PROCESS-REVISED-EXIT.                                                    
           EXIT.                                                                
       PROC-REV-BILLING.                                                        
      *----------------------------------------------------------------*        
      * PRODUCE THE BILLING AMOUNTS PORTION OF THE REVISED PART OF     *        
      * REPORT                                                         *        
      *----------------------------------------------------------------*        
           MOVE '2' TO REVISED-IND.                                             
           IF (LINE-COUNT + 4) IS GREATER THAN MAX-LINES THEN                   
                MOVE MAX-LINES TO LINE-COUNT                                    
           ELSE                                                                 
                MOVE REVISED-5 TO PRINT-AREA                                    
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END.                                         
           MOVE +0 TO BIL-SUB PRT-SUB.                                          
           PERFORM PROC-REV-BILL-RTN THRU                                       
                   PROC-REV-BILL-RTN-EXIT.                                      
           MOVE REVISED-6 TO PRINT-AREA.                                        
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           MOVE '0'    TO REVISED-6.                                            
       PROC-REV-BILLING-EXIT.                                                   
           EXIT.                                                                
       PROC-REV-BILL-RTN.                                                       
      *----------------------------------------------------------------*        
      * PRODUCE THE BILLING DETAIL LINES FOR THE REVISED PART OF       *        
      * REPORT                                                         *        
      *----------------------------------------------------------------*        
           ADD +1 TO BIL-SUB.                                                   
           ADD +1 TO PRT-SUB.                                                   
           IF BIL-SUB GREATER THAN GFMBE-REV-BILL-NO-OF-CODES THEN              
                GO TO PROC-REV-BILL-RTN-EXIT.                                   
           IF PRT-SUB GREATER THAN +2 THEN                                      
                MOVE +1 TO PRT-SUB                                              
                MOVE REVISED-6 TO PRINT-AREA                                    
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END                                          
                MOVE SPACES TO REVISED-6.                                       
                                                                                
           MOVE GFMBE-REV-BILL-COV-CODE(BIL-SUB)                                
                                         TO REV-COVCODE(PRT-SUB).               
           MOVE GFMBE-REV-BILL-AMT-BILLED(BIL-SUB)                              
                                         TO REV-BILLED(PRT-SUB).                
           MOVE GFMBE-REV-BILL-LIVES(BIL-SUB)                                   
                                         TO REV-LIVES(PRT-SUB).                 
           MOVE GFMBE-REV-BILL-VOLUME(BIL-SUB)                                  
                                         TO REV-VOLUME(PRT-SUB).                
           GO TO PROC-REV-BILL-RTN.                                             
       PROC-REV-BILL-RTN-EXIT.                                                  
           EXIT.                                                                
                                                                                
       PROCESS-BILL-HIST.                                                       
      *----------------------------------------------------------------*        
      * PROCESS THE BILLING HISTORY RECORD.                            *        
      *----------------------------------------------------------------*        
           MOVE '1' TO HISTORY-IND.                                             
           IF CURRENT-KEY NOT EQUAL PREVIOUS-KEY THEN                           
                PERFORM BILL-HIST-HEADING-BGN THRU                              
                        BILL-HIST-HEADING-END.                                  
                                                                                
           IF (LINE-COUNT + 3) IS GREATER THAN MAX-LINES THEN                   
                MOVE MAX-LINES TO LINE-COUNT.                                   
                                                                                
           MOVE BILLING-3 TO PRINT-AREA.                                        
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              GFMBE-BILL-IMB-PREM-DUE-DATE                      
                              BIL-PDUEDATE.                                     
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              GFMBE-BILL-IMB-PREPARED-DATE                      
                              BIL-STMTDATE.                                     
           MOVE GFMBE-BILL-IMB-PREMIUM-DUE TO BIL-TOTPREM.                      
           MOVE GFMBE-BILL-IMB-NO-CERTS    TO BIL-NOCERTS.                      
           MOVE BILLING-4 TO PRINT-AREA.                                        
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
                                                                                
           IF GFMBE-BILL-IMB-NO-OF-CODES GREATER THAN ZERO THEN                 
                PERFORM PROC-HIST-BILLING THRU                                  
                        PROC-HIST-BILLING-EXIT.                                 
                                                                                
           MOVE '1' TO HISTORY-IND.                                             
           IF (LINE-COUNT + 4) GREATER THAN MAX-LINES THEN                      
                PERFORM HEADING-ROUTINE-BGN THRU                                
                        HEADING-ROUTINE-END.                                    
           MOVE  BILLING-7 TO PRINT-AREA.                                       
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
                                                                                
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              GFMBE-BCI-PREPARED-DATE                           
                              BIL-PREPDATE.                                     
           MOVE GFMBE-BCI-PREMIUM-DUE   TO BIL-PREMDUE.                         
           MOVE GFMBE-BCI-INSURED-LIVES TO BIL-LIVES.                           
           MOVE  BILLING-8 TO PRINT-AREA.                                       
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           IF GFMBE-BCI-NO-OF-CODES GREATER THAN ZERO THEN                      
                PERFORM PROC-IMB-BILLING THRU                                   
                        PROC-IMB-BILLING-EXIT.                                  
           MOVE SPACES TO HISTORY-IND.                                          
       PROCESS-BILL-HIST-EXIT.                                                  
           EXIT.                                                                
       PROC-HIST-BILLING.                                                       
      *----------------------------------------------------------------*        
      * PRODUCE THE BILLING AMOUNTS PORTION OF THE REVISED PART OF     *        
      *----------------------------------------------------------------*        
           MOVE '2' TO HISTORY-IND.                                             
           IF (LINE-COUNT + 4) IS GREATER THAN MAX-LINES THEN                   
                MOVE MAX-LINES TO LINE-COUNT                                    
           ELSE                                                                 
                MOVE BILLING-5 TO PRINT-AREA                                    
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END.                                         
           MOVE +0 TO BIL-SUB PRT-SUB.                                          
           PERFORM PROC-HIST-BILL-RTN THRU                                      
                   PROC-HIST-BILL-RTN-EXIT.                                     
           MOVE BILLING-6 TO PRINT-AREA.                                        
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           MOVE '0'    TO BIL-6-CC.                                             
       PROC-HIST-BILLING-EXIT.                                                  
           EXIT.                                                                
       PROC-HIST-BILL-RTN.                                                      
      *----------------------------------------------------------------*        
      * PRODUCE DETAIL LINES FOR BILLINGS PART OF  REVISED SECTION     *        
      *----------------------------------------------------------------*        
           ADD +1 TO BIL-SUB.                                                   
           ADD +1 TO PRT-SUB.                                                   
           IF BIL-SUB GREATER THAN GFMBE-BILL-IMB-NO-OF-CODES THEN              
                GO TO PROC-HIST-BILL-RTN-EXIT.                                  
           IF PRT-SUB GREATER THAN +2 THEN                                      
                MOVE +1 TO PRT-SUB                                              
                MOVE BILLING-6 TO PRINT-AREA                                    
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END                                          
                MOVE SPACES TO BILLING-6.                                       
                                                                                
           MOVE GFMBE-BILL-IMB-COV-CODE(BIL-SUB)                                
                                         TO BIL1-COVCODE(PRT-SUB).              
           MOVE GFMBE-BILL-IMB-AMT-BILLED(BIL-SUB)                              
                                         TO BIL1-BILLED(PRT-SUB).               
           MOVE GFMBE-BILL-IMB-LIVES(BIL-SUB)                                   
                                         TO BIL1-LIVES(PRT-SUB).                
           MOVE GFMBE-BILL-IMB-VOLUME(BIL-SUB)                                  
                                         TO BIL1-VOLUME(PRT-SUB).               
                                                                                
           GO TO PROC-HIST-BILL-RTN.                                            
       PROC-HIST-BILL-RTN-EXIT.                                                 
           EXIT.                                                                
                                                                                
       PROC-IMB-BILLING.                                                        
           MOVE '3' TO HISTORY-IND.                                             
           IF (LINE-COUNT + 4) IS GREATER THAN MAX-LINES THEN                   
                MOVE MAX-LINES TO LINE-COUNT                                    
           ELSE                                                                 
                MOVE BILLING-9 TO PRINT-AREA                                    
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END.                                         
           MOVE +0 TO BIL-SUB PRT-SUB.                                          
           PERFORM PROC-IMB-BILL-RTN THRU                                       
                   PROC-IMB-BILL-RTN-EXIT.                                      
           MOVE BILLING-10 TO PRINT-AREA.                                       
           PERFORM PRINT-LINE-BGN THRU                                          
                   PRINT-LINE-END.                                              
           MOVE '0'    TO BIL-10-CC.                                            
       PROC-IMB-BILLING-EXIT.                                                   
           EXIT.                                                                
       PROC-IMB-BILL-RTN.                                                       
      *----------------------------------------------------------------*        
      * PRODUCE THE BILLING AMOUNTS PORTION OF THE BILLING HISTORY     *        
      * PART OF THE REPORT                                             *        
      *----------------------------------------------------------------*        
           ADD +1 TO BIL-SUB.                                                   
           ADD +1 TO PRT-SUB.                                                   
           IF BIL-SUB GREATER THAN GFMBE-BCI-NO-OF-CODES THEN                   
                GO TO PROC-IMB-BILL-RTN-EXIT.                                   
           IF PRT-SUB GREATER THAN +2 THEN                                      
                MOVE +1 TO PRT-SUB                                              
                MOVE BILLING-10 TO PRINT-AREA                                   
                PERFORM PRINT-LINE-BGN THRU                                     
                        PRINT-LINE-END                                          
                MOVE SPACES TO BILLING-10.                                      
                                                                                
           MOVE GFMBE-BCI-COV-CODE(BIL-SUB) TO BIL2-COVCODE(PRT-SUB).           
           MOVE GFMBE-BCI-AMT-BILLED(BIL-SUB) TO BIL2-BILLED(PRT-SUB).          
           MOVE GFMBE-BCI-D90-ADJ(BIL-SUB) TO BIL2-RETADJ(PRT-SUB).             
           MOVE GFMBE-BCI-LIVES(BIL-SUB)   TO BIL2-LIVES(PRT-SUB).              
           MOVE GFMBE-BCI-VOLUME(BIL-SUB)  TO BIL2-VOLUME(PRT-SUB).             
                                                                                
           GO TO PROC-IMB-BILL-RTN.                                             
       PROC-IMB-BILL-RTN-EXIT.                                                  
           EXIT.                                                                
                                                                                
       HEADING-ROUTINE-BGN.                                                     
      *----------------------------------------------------------------*        
      *               PRINT PAGE AND COLUMN HEADINGS                   *        
      *    INCREMENT PAGE COUNT AND PRINT THE THE CONSTANT HEADINGS    *        
      * THE FIRST TIME THIS IS CALLED FOR AN GROUP/ACCT, NO SECONDARY  *        
      * HEADINGS SHOULD BE WRITTEN OUT. ONLY WHEN THIS IS CALLED FROM  *        
      * THE PRINT ROUTINE SHOULD THE SECONDARY HEADINGS BE PRINTED     *        
      *----------------------------------------------------------------*        
           ADD +1 TO PAGE-COUNT                                                 
           ADD +1 TO ACCUM-EXCEPTION.                                           
           MOVE PAGE-COUNT TO HD-COUNT.                                         
           MOVE HEADING-1  TO PRINT-AREA.                                       
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
                                                                                
           MOVE GFMBE-GROUP-NUMBER TO HD-GROUP.                                 
           MOVE GFMBE-ACCOUNT      TO HD-ACCT.                                  
           MOVE HEADING-2 TO PRINT-AREA.                                        
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE +3   TO LINE-COUNT.                                             
           MOVE ZERO TO PREV-CERT.                                              
                                                                                
           IF  RETR-TITL-1 THEN                                                 
               PERFORM RETROACTIVE-HEADING-BGN THRU                             
                       RETROACTIVE-HEADING-END                                  
           ELSE                                                                 
           IF  STAT-TITL-1 THEN                                                 
               PERFORM STATISTICS-HEADING-BGN THRU                              
                       STATISTICS-HEADING-END                                   
           ELSE                                                                 
           IF  REVI-TITL-1 THEN                                                 
               PERFORM REVISED-HEADING-BGN THRU                                 
                       REVISED-HEADING-END                                      
           ELSE                                                                 
           IF  HIST-TITL-1 THEN                                                 
               PERFORM BILL-HIST-HEADING-BGN THRU                               
                       BILL-HIST-HEADING-END.                                   
       HEADING-ROUTINE-END.                                                     
           EXIT.                                                                
                                                                                
       RETROACTIVE-HEADING-BGN.                                                 
      *----------------------------------------------------------------*        
      *           PRINT RETROACTIVE PAGE AND COLUMN HEADINGS           *        
      *----------------------------------------------------------------*        
           MOVE RETROACTIVE-1 TO PRINT-AREA.                                    
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE RETROACTIVE-2 TO PRINT-AREA.                                    
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE RETROACTIVE-3 TO PRINT-AREA.                                    
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES TO PRINT-AREA.                                           
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           ADD +5 TO LINE-COUNT.                                                
       RETROACTIVE-HEADING-END.                                                 
           EXIT.                                                                
                                                                                
       STATISTICS-HEADING-BGN.                                                  
      *----------------------------------------------------------------*        
      *           PRINT STATISTICS  PAGE AND COLUMN HEADINGS           *        
      *----------------------------------------------------------------*        
           IF  STAT-TITL-1 THEN                                                 
               MOVE STATISTIC-1 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               MOVE STATISTIC-2 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               MOVE STATISTIC-3 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +3 TO LINE-COUNT.                                            
           IF STAT-TITL-2 THEN                                                  
               MOVE STATISTIC-5 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               MOVE STATISTIC-6 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +2 TO LINE-COUNT.                                            
           IF STAT-TITL-3 THEN                                                  
               MOVE STATISTIC-9 TO PRINT-AREA                                   
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +2 TO LINE-COUNT.                                            
           IF STAT-TITL-4 THEN                                                  
               MOVE BILLING-9 TO PRINT-AREA                                     
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +2 TO LINE-COUNT.                                            
       STATISTICS-HEADING-END.                                                  
           EXIT.                                                                
                                                                                
       BILL-HIST-HEADING-BGN.                                                   
      *----------------------------------------------------------------*        
      * WRITE REQUIRED HISTROY HEADING TITLES BASED ON FLAGS SET       *        
      *----------------------------------------------------------------*        
           IF HIST-TITL-1 THEN                                                  
               MOVE BILLING-1 TO PRINT-AREA                                     
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               MOVE BILLING-2 TO PRINT-AREA                                     
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +2 TO LINE-COUNT.                                            
           IF HIST-TITL-2 THEN                                                  
               MOVE BILLING-5 TO PRINT-AREA                                     
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END                                        
               ADD +2 TO LINE-COUNT.                                            
           IF HIST-TITL-3 THEN                                                  
                MOVE BILLING-9 TO PRINT-AREA                                    
                PERFORM PRINT-ROUTINE-BGN THRU                                  
                        PRINT-ROUTINE-END                                       
               ADD +2 TO LINE-COUNT.                                            
       BILL-HIST-HEADING-END.                                                   
           EXIT.                                                                
                                                                                
       REVISED-HEADING-BGN.                                                     
      *----------------------------------------------------------------*        
      * WRITE REQUIRED REVISED HEADING TITLES BASED ON FLAGS SET       *        
      *----------------------------------------------------------------*        
           IF REVI-TITL-1 THEN                                                  
                MOVE REVISED-1 TO PRINT-AREA                                    
                PERFORM PRINT-ROUTINE-BGN THRU                                  
                        PRINT-ROUTINE-END                                       
                MOVE REVISED-2 TO PRINT-AREA                                    
                PERFORM PRINT-ROUTINE-BGN THRU                                  
                        PRINT-ROUTINE-END                                       
                ADD +3 TO LINE-COUNT.                                           
           IF REVI-TITL-2 THEN                                                  
                MOVE REVISED-5 TO PRINT-AREA                                    
                PERFORM PRINT-ROUTINE-BGN THRU                                  
                        PRINT-ROUTINE-END                                       
                ADD +2 TO LINE-COUNT.                                           
       REVISED-HEADING-END.                                                     
           EXIT.                                                                
                                                                                
       PRINT-LINE-BGN.                                                          
      *----------------------------------------------------------------*        
      *                    PRINT A REPORT LINE                         *        
      *----------------------------------------------------------------*        
           IF  PRT-CC IS EQUAL TO '-' THEN                                      
               ADD +3 TO LINE-COUNT                                             
           ELSE                                                                 
               IF  PRT-CC IS EQUAL TO '0' THEN                                  
                   ADD +2 TO LINE-COUNT                                         
               ELSE                                                             
                   IF  PRT-CC IS EQUAL TO SPACES THEN                           
                       ADD +1 TO LINE-COUNT.                                    
           IF  LINE-COUNT IS GREATER THAN MAX-LINES THEN                        
               MOVE PRINT-AREA TO SAVE-PRINT-AREA                               
               PERFORM HEADING-ROUTINE-BGN THRU                                 
                       HEADING-ROUTINE-END                                      
               MOVE SAVE-PRINT-AREA TO PRINT-AREA                               
               GO TO PRINT-LINE-BGN.                                            
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-BGN.                                           
           MOVE SPACES TO PRINT-AREA.                                           
       PRINT-LINE-END.                                                          
           EXIT.                                                                
                                                                                
       PRINT-ROUTINE-BGN.                                                       
      *----------------------------------------------------------------*        
      *    SET UP CALL TO GENERAL I/O ROUTINE TO PRINT OUTPUT LINES    *        
      *----------------------------------------------------------------*        
           CALL 'DLSWRITE' USING PRINT-SYS012                                   
                                 PRINT-RETURN                                   
                                 PRINT-AREA                                     
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS012-COUNT.                            
       PRINT-ROUTINE-END.                                                       
           EXIT.                                                                
                                                                                
       READ-ROUTINE-BGN.                                                        
      *----------------------------------------------------------------*        
      * READ AN EXCEPTION RECORD                                       *        
      * AND SET UP THE LENGTH                                          *        
      *----------------------------------------------------------------*        
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                BILLING-EXCEPTION                               
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
           MOVE GFMBE-RECORD-LENGTH TO GFMBE-RECORD-LENGTH.                     
       READ-ROUTINE-END.                                                        
           EXIT.                                                                
