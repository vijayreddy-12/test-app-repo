       CBL DATA(24)                                                             
       ID DIVISION.                                                             
       PROGRAM-ID.  GPRIDCER.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS.  THIS MODULE PRINTS IDENTIFICATION CERTIFICATES FOR             
      *          CANADA AND U. S. (INCLUDES ALL OTHER COUNTRIES).               
      *          REVISED FOR DIVISIONAL BILLING JUNE 86. TVN.                   
      *          CORRECTED                      NOV  86. GPL.                   
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  START                          *         
      *****************************************************************         
      *                                                               *         
      *  AUG/89  M DRURY  - ADD TWO NEW FIELDS TO ERROR FILE          *         
      *                   - CHANGE ERROR FILE TO BE COPY BOOK.        *         
      *                                                               *         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  END                            *         
      *****************************************************************         
      *  11OCT89 B.G. WILKE                                           *         
      *                   - FOR SA CERT REQUEST,                      *         
      *                        CONTROLLING SINGLE AND FAMILY COVERAGE *         
      *                        OF DEPENDANT LIFE.                     *         
      *                     IF GROUP HAS DEPENDANT LIFE               *         
      *                        BUT CERT REQ. IS SINGLE, THE DEPENDANT *         
      *                        LINE WILL BE BYPASSED, FORMERLY IT     *         
      *                        WOULD PRINT.                           *         
      *                                                               *         
      *  JAN/90  M DRURY  - ALLOW ID-CERT TO PRINT FOR A SELECTION    *         
      *                     INDECATOR OF 'DE'.                        *         
      *                                                               *         
      *  FEB 90  M BURTON - RECOMPILED TO PICK UP NEW VERSION OF      *         
      *                     COPYBOOK                                  *         
      *                                                               *         
      *  SEP/91 M PRANGE                                              *         
      *       - REMOVED BENEFICIARY NAME FROM WALLET-IDS              *         
      *                                                               *         
      *  Jul94, I.Bucknell - Allow detailed walletID for SA groups.   *         
      *                      (Required because the introduction of    *         
      *                      PASS 2000 means GIPSY will now often     *         
      *                      carry certificate details even though    *         
      *                      group is billing type SA.) ChgReq 1296.  *         
      *                                                               *         
      *  Dec97, I.Bucknell, Year 2000 Project.                        *         
      *                      Expand 'Effective Date' as printed on    *         
      *                      wallet ID from DDMMMYY to DDMMMYYYY.     *         
      *  JAN99, WEI LIN    - TASK # 4945                              *         
      *                      REMOVE GROUP ID FORM WALLET-IDS          *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      * JAN2015 - GNE PROJECT WARRANTY - CORRECTED THE LOOKUP FOR GIPSY         
      *           TRAILERS TO READ THE MASTER FIRST THEN JUST MOVE THE          
      *           TRAILER DIRECTLY TO THE DESTINATION                           
      *****************************************************************         
      *AUTHOR.   E. MELTZ                                                       
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77   FILLER                           PIC X(50)   VALUE                  
            '***** START OF WORKING STORAGE FOR GPRIDCER *****'.                
       77  CC-FORM                                 PIC X.                       
       77  QDATE-PARM                              PIC XX.                      
       77  ERR-SW              VALUE  '0'          PIC X.                       
       77  START-SW                                PIC X.                       
       77  FAMILY-IND          VALUE  '0'          PIC X.                       
                                                                                
       01  SW-US.                                                               
           05  SW-US-BENEFIT-65                    PIC X VALUE SPACES.          
           05  SW-US-BENEFIT-EHC                   PIC X VALUE SPACES.          
           05  SW-US-BENEFIT-DEN                   PIC X VALUE SPACES.          
           05  SW-EMP-BEN                          PIC X VALUE SPACES.          
                                                                                
       01  PR-URLE                      PIC X(36) VALUE                         
               'www.manulife.ca/planmember         '.                           
       01  PR-URLF                      PIC X(36) VALUE                         
               'www.manuvie.ca/participant         '.                           
                                                                                
       01  PR-CUSTE                     PIC X(17) VALUE                         
               '1-800-268-6195   '.                                             
       01  PR-CUSTF                     PIC X(17) VALUE                         
               '1 800 268-6195   '.                                             
                                                                                
       01  SUBSCRIPS.                                                           
           03  SUB1            COMP SYNC           PIC S9(4).                   
           03  SUB2            COMP SYNC           PIC S9(4).                   
           03  SUB3            COMP SYNC           PIC S9(4).                   
           03  SUB4            COMP SYNC           PIC S9(4).                   
           03  SUB5            COMP SYNC           PIC S9(4).                   
           03  SUB7            COMP SYNC           PIC S9(4).                   
      *    03  WS-DENT-SUB     COMP SYNC           PIC S9(4).                   
           03  SUB-LINE        COMP SYNC           PIC S9(4).                   
           03  SUB-OCC         COMP SYNC           PIC S9(4).                   
           03  SUB-MOVE        COMP SYNC           PIC S9(4).                   
           03  SUB-FORM        COMP SYNC           PIC S9(4).                   
      *    03  SUB-BLANK       COMP SYNC           PIC S9(4).                   
           03  COV-COD-SUB     COMP SYNC           PIC S9(4).                   
                                                                                
       01  PRINT-SYS018              PIC X(06) VALUE 'SYS018'.                  
       01  PRINT-SYS018-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
                                                                                
       01  COV-COD-INDICATOR    VALUE '00'         PIC XX.                      
       01  FILLER     REDEFINES COV-COD-INDICATOR.                              
           02  COV-COD-IND   OCCURS 2 TIMES        PIC X.                       
                                                                                
       01  COVERAGE-CODES COMP-3.                                               
           05  LIFE                               PIC S9(3) VALUE +150.         
           05  AD-D                               PIC S9(3) VALUE +083.         
           05  DL                                 PIC S9(3) VALUE +160.         
           05  WI                                 PIC S9(3) VALUE +010.         
           05  LTD                                PIC S9(3) VALUE +130.         
           05  OPT-LIFE                           PIC S9(3) VALUE +155.         
           05  OPT-ADD                            PIC S9(3) VALUE +084.         
           05  OPT-SP                             PIC S9(3) VALUE +165.         
           05  OPT-SUR                            PIC S9(3) VALUE +300.         
           05  EHC                                PIC S9(3) VALUE +019.         
           05  DEN                                PIC S9(3) VALUE +099.         
                                                                                
       01  INDICATOR-EHC-DEN.                                                   
           05  SW-DISPLAY-IND                       PIC X.                      
                                                                                
       01  WS-COVERAGE COMP-3.                                                  
           05  FILLER  VALUE +0                    PIC S9(7).                   
           05  WS-COVERAGE-R.                                                   
               10  WS-LIFE-VOLUME                  PIC S9(7).                   
               10  WS-ADD-VOLUME                   PIC S9(7).                   
               10  WS-DL-VOLUME                    PIC S9(7).                   
               10  WS-WI-VOLUME                    PIC S9(7).                   
               10  WS-LTD-VOLUME                   PIC S9(7).                   
               10  WS-OPT-LIFE-VOLUME              PIC S9(7).                   
               10  WS-OPT-ADD-VOLUME               PIC S9(7).                   
               10  WS-OPT-SP-VOLUME                PIC S9(7).                   
               10  WS-OPT-SUR-VOLUME               PIC S9(7).                   
               10  WS-EHC-VOLUME                   PIC S9(7).                   
               10  WS-DEN-VOLUME                   PIC S9(7).                   
               10  TEMP-VOLUME-DESC                PIC S9(7).                   
                                                                                
       01  WS-EHC                                  PIC 9(7).                    
       01  WS-DEN                                  PIC 9(7).                    
                                                                                
       01  CURR-KEY.                                                            
           03  CURR-SEG1.                                                       
               05  C-REC-TYPE                      PIC X.                       
               05  C-REC-FORM                      PIC X.                       
           03  C-REC-GROUP-ACCT.                                                
GNE            05  C-REC-GROUP     COMP-3              PIC S9(7).               
               05  C-REC-ACCT                          PIC XXX.                 
       01  PREV-KEY.                                                            
           03  PREV-SEG1.                                                       
               05  P-REC-TYPE                      PIC X.                       
               05  P-FORM                          PIC X.                       
GNE        03  P-GROUP         COMP-3              PIC S9(7).                   
           03  P-ACCT                              PIC XXX.                     
                                                                                
       01  ROW-COL.                                                             
           03  F-ROW           COMP                PIC S9(4).                   
           03  F-COL           COMP                PIC S9(4).                   
                                                                                
       01  STORE-RESTART.                                                       
           03  SAVE-RESTART.                                                    
               05  SAVE-RESTART-1.                                              
                   07  R-REC-TYPE                      PIC X.                   
                   07  R-FORM                          PIC X.                   
GNE            05  R-GROUP         COMP-3              PIC S9(7).               
               05  R-ACCT                              PIC XXX.                 
           03  FILLER                              PIC XX.                      
                                                                                
GNE        COPY GERRREC7.                                                       
                                                                                
       01  NA-EXP.                                                              
           03  NA-LINES    OCCURS     6.                                        
               05  NA-LN                           PIC X(30).                   
               05  NA-DEL                          PIC X.                       
                                                                                
       COPY   GMIDCTR.                                                          
               05  FILLER                          PIC X(61).                   
                                                                                
      *01  GMBNATR.                                                             
           COPY GMBNATRX.                                                       
                                                                                
GNE    COPY   GMGENTR7.                                                         
                                                                                
       01  BENEFIT-CODE.                                                        
           03  BEN-CODE                            PIC XX.                      
           03  BEN-REC.                                                         
               05  FILLER                          PIC XX.                      
               05  BEN-DESC                        PIC X(32).                   
               05  FILLER                          PIC XXX.                     
           03  LANG-CODE                           PIC X.                       
                                                                                
GNE    01  GACCDMAS-PARMS.                                                      
GNE        03  GACCDMAS-1.                                                      
GNE            05  GACCDMAS-FUNC-CODE     PIC S9(4)  VALUE +2 COMP.             
GNE            05  GACCDMAS-GRP-INFO.                                           
GNE                07  GACCDMAS-GROUP     PIC S9(7)  VALUE +0  COMP-3.          
GNE                07  GACCDMAS-ACCT      PIC XXX    VALUE LOW-VALUES.          
GNE            05  FILLER                 PIC X(9)   VALUE SPACES.              
GNE        03  GACCDMAS-ERR               PIC X(3)   VALUE SPACES.              
GNE                                                                             
GNE        COPY GMASTER7.                                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *             CONSTANTS FOR ID CERT                              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  INFO-LINES.                                                          
           05  INFO-BENEFITS.                                                   
               10  INFO-BENEFITS-EMP-ONLY         PIC X(31)                     
               VALUE 'EMPLOYEE ONLY                  '.                         
               10  INFO-BENEFITS-EMP-DEP1         PIC X(31)                     
               VALUE 'EMPLOYEE AND 1 DEPENDENT       '.                         
               10  INFO-BENEFITS-EMP-DEPS         PIC X(31)                     
               VALUE 'EMPLOYEE & ELIGIBLE DEPENDENTS '.                         
           05  INFO-BENEFITS-FRENCH.                                            
               10  INFO-BENEFITS-EMP-ONLY-F       PIC X(31)                     
               VALUE 'EMPLOYE SEULEMENT              '.                         
               10  INFO-BENEFITS-EMP-DEP1-F       PIC X(31)                     
               VALUE 'EMPLOYE ET 1 PERSONNE A CHARGE '.                         
               10  INFO-BENEFITS-EMP-DEPS-F       PIC X(31)                     
               VALUE 'EMP.ET PERS. A CH. ADMISSIBLES '.                         
                                                                                
      *----------------------------------------------------------------*        
      *             LIFE AND ADD LINES                                 *        
      *----------------------------------------------------------------*        
           05  INFO-LIFE-ADD.                                                   
               10  INFO-LIFE-ENG                  PIC X(32)                     
               VALUE 'LIFE INSURANCE                  '.                        
               10  INFO-LIFE-FRE                  PIC X(32)                     
               VALUE 'ASSURANCE-VIE                   '.                        
                                                                                
               10  INFO-LIFE-AMOUNT-ENG.                                        
                   15  FILLER                     PIC X(15)                     
                   VALUE 'LIFE INSURANCE '.                                     
                   15  INFO-LIFE-AMT-ENG          PIC $$$$,$$$.                 
                   15  FILLER    VALUE SPACES     PIC X(9).                     
               10  INFO-LIFE-AMOUNT-FRE.                                        
                   15  FILLER                     PIC X(17)                     
                   VALUE 'ASSURANCE-VIE DE '.                                   
                   15  INFO-LIFE-AMT-FRE          PIC $$$$,$$$.                 
                   15  FILLER    VALUE SPACES     PIC X(7).                     
                                                                                
               10  INFO-LIFE-ADD-ENG              PIC X(32)                     
               VALUE 'LIFE AND AD&D INSURANCE         '.                        
               10  INFO-LIFE-ADD-FRE              PIC X(32)                     
               VALUE 'ASSURANCE-VIE ET P.A.V.M        '.                        
                                                                                
               10  INFO-LIFE-ADD-AMOUNT-ENG.                                    
                   15  FILLER                     PIC X(5)                      
                   VALUE 'LIFE '.                                               
                   15  INFO-LIFE-A-AMT-ENG        PIC $$$$,$$$.                 
                   15  FILLER                     PIC X(10)                     
                   VALUE ' AND AD&D '.                                          
                   15  INFO-L-ADD-AMT-ENG         PIC $$$$,$$$.                 
                   15  FILLER    VALUE SPACES     PIC X.                        
               10  INFO-LIFE-ADD-AMOUNT-FRE.                                    
                   15  FILLER                     PIC X(4)                      
                   VALUE 'VIE '.                                                
                   15  INFO-LIFE-A-AMT-FRE        PIC $$$$,$$$.                 
                   15  FILLER                     PIC X(12)                     
                   VALUE ' ET P.A.V.M.'.                                        
                   15  INFO-L-ADD-AMT-FRE         PIC $$$$,$$$.                 
                                                                                
               10  INFO-ADD-ENG                   PIC X(32)                     
               VALUE 'AD&D INSURANCE                  '.                        
               10  INFO-ADD-FRE                   PIC X(32)                     
               VALUE 'ASSURANCE P.A.V.M.              '.                        
                                                                                
               10  INFO-ADD-AMOUNT-ENG.                                         
                   15  FILLER                     PIC X(15)                     
                   VALUE 'AD&D INSURANCE '.                                     
                   15  INFO-ADD-AMT-ENG           PIC $$$$,$$$.                 
                   15  FILLER    VALUE SPACES     PIC X(9).                     
                                                                                
               10  INFO-ADD-AMOUNT-FRE.                                         
                   15  FILLER                     PIC X(22)                     
                   VALUE 'ASSURANCE-P.A.V.M. DE '.                              
                   15  INFO-ADD-AMT-FRE           PIC $$$$,$$$.                 
                   15  FILLER    VALUE SPACES     PIC X(2).                     
                                                                                
               10  INFO-DEP-LIFE-ENG              PIC X(32)                     
               VALUE 'DEPENDENT LIFE INSURANCE        '.                        
               10  INFO-DEP-LIFE-FRE              PIC X(32)                     
               VALUE 'ASS.-VIE DES PERSONNES A CHARGE '.                        
                                                                                
      *----------------------------------------------------------------*        
      *            WI AND LTD LINES                                    *        
      *----------------------------------------------------------------*        
               10  INFO-WI-ENG                    PIC X(18)                     
               VALUE 'WI INSURANCE      '.                                      
               10  INFO-WI-FRE                    PIC X(32)                     
               VALUE 'ASSURANCE-INDEMNITE HEBDOMADAIRE'.                        
                                                                                
               10  INFO-WI-AMOUNT-ENG.                                          
                   15  FILLER                     PIC X(03)                     
                   VALUE 'WI '.                                                 
                   15  INFO-WI-AMT-ENG            PIC $$$$.                     
                   15  FILLER VALUE SPACES        PIC X(11).                    
               10  INFO-WI-AMOUNT-FRE.                                          
                   15  FILLER                     PIC X(28)                     
                   VALUE 'ASS.-INDEMNITE HEBDOMADAIRE '.                        
                   15  INFO-WI-AMT-FRE            PIC $$$$.                     
                                                                                
               10  INFO-LTD-ENG                   PIC X(32)                     
               VALUE 'LONG TERM DISABILITY INSURANCE  '.                        
               10  INFO-LTD-FRE                   PIC X(32)                     
               VALUE 'ASS.-INVALIDITE DE LONGUE DUREE '.                        
                                                                                
               10  INFO-LTD-AMOUNT-ENG.                                         
                   15  FILLER                     PIC X(21)                     
                   VALUE 'LONG TERM DISABILITY '.                               
                   15  INFO-LTD-AMT-ENG            PIC $$$$$.                   
                   15  FILLER VALUE SPACES        PIC X(6).                     
               10  INFO-LTD-AMOUNT-FRE.                                         
                   15  FILLER                     PIC X(27)                     
                   VALUE 'INVALIDITE DE LONGUE DUREE '.                         
                   15  INFO-LTD-AMT-FRE           PIC $$$$$.                    
                                                                                
               10  INFO-WI-LTD-ENG                PIC X(32)                     
               VALUE 'WI AND LTD INSURANCE            '.                        
               10  INFO-WI-LTD-FRE.                                             
                   15  FILLER                     PIC X(11)                     
                   VALUE 'ASSURANCE D'.                                         
                   15  FILLER                     PIC X                         
                   VALUE QUOTE.                                                 
                   15  FILLER                     PIC X(9)                      
                   VALUE 'I.H. ET D'.                                           
                   15  FILLER                     PIC X                         
                   VALUE QUOTE.                                                 
                   15  FILLER                     PIC X(10)                     
                   VALUE 'I.L.D.    '.                                          
                                                                                
               10  INFO-WI-LTD-AMOUNT-ENG.                                      
                   15  FILLER                     PIC X(3)                      
                   VALUE 'WI '.                                                 
                   15  INFO-WI-L-AMT-ENG          PIC $$$$.                     
                   15  FILLER                     PIC X(9)                      
                   VALUE ' AND LTD '.                                           
                   15  INFO-W-LTD-AMT-ENG         PIC $$$$$.                    
                   15  FILLER    VALUE SPACES     PIC X(12).                    
                                                                                
               10  INFO-WI-LTD-AMOUNT-FRE.                                      
                   15  FILLER                     PIC X(5)                      
                   VALUE 'I.H. '.                                               
                   15  INFO-WI-L-AMT-FRE          PIC $$$$.                     
                   15  FILLER                     PIC X(11)                     
                   VALUE ' ET I.L.D. '.                                         
                   15  INFO-W-LTD-AMT-FRE         PIC $$$$$.                    
                   15  FILLER    VALUE SPACES     PIC X(7).                     
                                                                                
      *----------------------------------------------------------------*        
      *       OPTION COVERAGES                                         *        
      *----------------------------------------------------------------*        
               10  INFO-OPT-LIFE-ENG              PIC X(32)                     
               VALUE 'OPTIONAL LIFE INSURANCE         '.                        
               10  INFO-OPT-LIFE-FRE              PIC X(32)                     
               VALUE 'ASSURANCE-VIE FACUL.            '.                        
                                                                                
               10  INFO-OPT-LIFE-AMOUNT-ENG.                                    
                   15  FILLER                     PIC X(24)                     
                   VALUE 'OPTIONAL LIFE INSURANCE '.                            
                   15  INFO-OPT-LIFE-AMT-ENG      PIC $$$$,$$$.                 
               10  INFO-OPT-LIFE-AMOUNT-FRE.                                    
                   15  FILLER                     PIC X(21)                     
                   VALUE 'ASSURANCE-VIE FACUL. '.                               
                   15  INFO-OPT-LIFE-AMT-FRE      PIC $$$$,$$$.                 
                   15  FILLER    VALUE SPACES     PIC X(3).                     
                                                                                
               10  INFO-OPT-ADD-ENG               PIC X(32)                     
               VALUE 'OPTIONAL AD&D INSURANCE         '.                        
               10  INFO-OPT-ADD-FRE               PIC X(32)                     
               VALUE 'ASSURANCE-P.A.V.M. FACULTATIVE  '.                        
               10  INFO-OPT-ADD-AMOUNT-ENG.                                     
                   15  FILLER                     PIC X(24)                     
                   VALUE 'OPTIONAL AD&D INSURANCE '.                            
                   15  INFO-OPT-ADD-AMT-ENG      PIC $$$$,$$$.                  
               10  INFO-OPT-ADD-AMOUNT-FRE.                                     
                   15  FILLER                     PIC X(21)                     
                   VALUE 'ASS.-P.A.V.M. FACUL. '.                               
                   15  INFO-OPT-ADD-AMT-FRE       PIC $$$$,$$$.                 
                   15  FILLER    VALUE SPACES     PIC X(3).                     
                                                                                
               10  INFO-OPT-SP-ENG                PIC X(32)                     
               VALUE 'SPOUSAL OPTIONAL LIFE INSURANCE '.                        
               10  INFO-OPT-SP-FRE               PIC X(32)                      
               VALUE 'ASS.-VIE/CONJOINT - FACULTATIVE '.                        
               10  INFO-OPT-SP-AMOUNT-ENG.                                      
                   15  FILLER                     PIC X(17)                     
                   VALUE 'SPOUSAL OPTIONAL '.                                   
                   15  INFO-OPT-SP-AMT-ENG      PIC $$$$,$$$.                   
                   15  FILLER       VALUE SPACES  PIC X(8).                     
               10  INFO-OPT-SP-AMOUNT-FRE.                                      
                   15  FILLER                     PIC X(24)                     
                   VALUE 'ASS.-VIE/CONJ. - FACUL. '.                            
                   15  INFO-OPT-SP-AMT-FRE        PIC $$$$,$$$.                 
                                                                                
               10  INFO-OPT-SUR-ENG                PIC X(32)                    
               VALUE 'SURVIVOR INCOME INSURANCE       '.                        
               10  INFO-OPT-SUR-FRE               PIC X(32)                     
               VALUE 'ASS.-VIE ET ASS-REVENU AUX SURV.'.                        
               10  INFO-OPT-SUR-AMOUNT-ENG.                                     
                   15  FILLER                     PIC X(18)                     
                   VALUE 'SURVIVOR OPTIONAL '.                                  
                   15  INFO-OPT-SUR-AMT-ENG       PIC $$$$,$$$.                 
                   15  FILLER       VALUE SPACES  PIC X(8).                     
               10  INFO-OPT-SUR-AMOUNT-FRE.                                     
                   15  FILLER                     PIC X(24)                     
                   VALUE 'VIE ET REVENU AUX SURV. '.                            
                   15  INFO-OPT-SUR-AMT-FRE       PIC $$$$,$$$.                 
                                                                                
           03  I-LNB                               PIC X(32)                    
               VALUE '   COVER THE EMPLOYEE ONLY.     '.                        
           03  I-LNC                               PIC X(32)                    
               VALUE '   COVER THE EMPLOYEE AND       '.                        
           03  I-LND                               PIC X(32)                    
               VALUE '   ELIGIBLE DEPENDENTS.         '.                        
           03  I-LNE                               PIC X(32)                    
               VALUE '   SUPPLEMENT TO MEDICARE       '.                        
           03  I-LNF                               PIC X(32)                    
               VALUE '   PROVIDED IF AGE 65 OR OVER.  '.                        
           03  I-LNG           PIC X(32)   VALUE                                
              '   ONE DEPENDENT.               '.                               
           03  I-LNH                               PIC X(32)                    
               VALUE ' DENTAL BENEFITS                '.                        
           03  I-LNJ                               PIC X(32)                    
               VALUE ' MEDICAL BENEFITS               '.                        
           03  I-LNK                               PIC X(32)                    
               VALUE ' MEDICAL AND DENTAL BENEFITS    '.                        
           03  I-DUP1                              PIC X(32)                    
               VALUE '     THIS DUPLICATE WALLET      '.                        
           03  I-DUP2                              PIC X(32)                    
               VALUE '     IDENTIFICATION CARD        '.                        
           03  I-DUP3                              PIC X(32)                    
               VALUE '     IS PROVIDED FOR YOUR       '.                        
           03  I-DUP4                              PIC X(32)                    
               VALUE '     CONVENIENCE                '.                        
           03  I-LNAF.                                                          
               05  FILLER      VALUE 'L'           PIC X.                       
               05  FILLER      VALUE  QUOTE        PIC X.                       
               05  FILLER                          PIC X(30)                    
               VALUE   'ASSE-MALADIE ET ACCIDENTS     '.                        
           03  I-LNBF.                                                          
               05  FILLER  VALUE '   PROTEGE L'    PIC X(12).                   
               05  FILLER  VALUE  QUOTE            PIC X.                       
               05  FILLER                          PIC X(19)                    
                   VALUE 'EMPLOYE SEULEMENT. '.                                 
           03  I-LNCF.                                                          
               05  FILLER      PIC X(10)   VALUE ' PROTEGE L'.                  
               05  FILLER      PIC X       VALUE QUOTE.                         
               05  FILLER      PIC X(10)   VALUE 'EMPLOYE ET'.                  
               05  FILLER      PIC X(11)   VALUE SPACES.                        
           03  I-LNDF          PIC X(32)   VALUE                                
              ' LES PERSONNES A CHARGE ADMISES.'.                               
           03  I-LNGF          PIC X(32)   VALUE                                
              ' UNE PERSONNE A CHARGE.         '.                               
           03  I-LNHF.                                                          
               05  FILLER  VALUE 'L'               PIC X.                       
               05  FILLER  VALUE QUOTE             PIC X.                       
               05  FILLER                          PIC X(28)  VALUE             
                   'ASSURANCE DE FRAIS DENTAIRES'.                              
           03  I-LNJF.                                                          
               05  FILLER                          PIC X(31)  VALUE             
                   'ASS. DE FRAIS DE SOINS MEDICAUX'.                           
           03  I-LNKF.                                                          
               05  FILLER                          PIC X(32)  VALUE             
                   'ASS.-FRAIS DE SOINS MED. & DENT.'.                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              SECTION 1  PRINT AREA                             *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-AREA.                                                          
           05  PR-LANG                      PIC X(1).                           
           05  PR-GROUP1                    PIC X(7).                           
           05  PR-ACCT1                     PIC X(3).                           
           05  PR-CERT1N                    PIC X(9).                           
           05  PR-CERT1 REDEFINES PR-CERT1N PIC Z(9).                           
           05  PR-FIRST                     PIC X(25).                          
           05  PR-LAST                      PIC X(25).                          
           05  PR-EFF1                      PIC X(9).                           
           05  PR-NA1                       PIC X(30).                          
           05  PR-NA2                       PIC X(30).                          
           05  PR-NA3                       PIC X(30).                          
           05  PR-CUSTOMER                  PIC X(17).                          
           05  PR-URL                       PIC X(36).                          
           05  COVERAGE1                    PIC X(30).                          
           05  COVERAGE2                    PIC X(30).                          
           05  PR-NOTES2.                                                       
               10  PRINT-AREA5B-LINE OCCURS 10 TIMES.                           
                   15  PRINT-AREA5-SEC3.                                        
                       20  PRINT-AREA5-SEC3-DESC   PIC X(32).                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              SECTION 2  PRINT AREA                             *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-AREA3     REDEFINES   PRINT-AREA.                              
           03  FILLER                              PIC X(904).                  
GNE        03  PR-GROUP2                           PIC Z(7).                    
           03  FILLER                              PIC XX.                      
           03  PR-ACCT2                            PIC XXX.                     
           03  PR-ACCT2N       REDEFINES  PR-ACCT2 PIC Z99.                     
GNE        03  FILLER                              PIC X(102).                  
           03  PR-EMP2                             PIC X(32).                   
           03  FILLER                              PIC X(109).                  
           03  PR-CERT2                            PIC Z(9).                    
           03  PR-CERT2A REDEFINES PR-CERT2        PIC X(9).                    
           03  FILLER                              PIC X(9).                    
      *  Dec97, IB                                                              
           03  PR-EFF2                             PIC X(9).                    
           03  FILLER                              PIC X(101).                  
           03  PR-LN1-U                            PIC X(32).                   
           03  FILLER                              PIC X(103).                  
           03  PR-LN2-U                            PIC X(32).                   
           03  FILLER                              PIC X(103).                  
           03  PR-LN3-U                            PIC X(32).                   
           03  FILLER                              PIC X(103).                  
           03  PR-LN4-U                            PIC X(32).                   
           03  FILLER                              PIC X(103).                  
           03  PR-LN5-U                            PIC X(32).                   
           03  FILLER                                  PIC X(31).               
       01  PRINT-AREA6     REDEFINES   PRINT-AREA.                              
           03  FILLER                              PIC X(1184).                 
           03  PR-AREA6-LN1  OCCURS 5 TIMES.                                    
               05  FILLER                              PIC X(103).              
               05  PR-AREA6-LN1-US                     PIC X(32).               
                                                                                
       01  EXTRA.                                                               
           03  PR-LINE1.                                                        
               05  PR-NOTE1    OCCURS  2.                                       
                   07  PR-LN6                      PIC X(32).                   
           03  PR-LINE2.                                                        
               05  PR-NOTE2    OCCURS  2.                                       
                   07  PR-LN7                      PIC X(32).                   
           03  PR-LINE3.                                                        
               05  PR-NOTE3    OCCURS  2.                                       
                   07  PR-LN8                      PIC X(32).                   
           03  PR-LINE4.                                                        
               05  PR-NOTE4                        PIC X(135).                  
           03  PR-LINE5.                                                        
               05  PR-NOTE5                        PIC X(135).                  
           03  PR-LINE8.                                                        
               05  PR-NOTE8                        PIC X(135).                  
           03  PR-LINE9.                                                        
               05  PR-NOTE9    OCCURS  2.                                       
                   07  PR-LN1                      PIC X(32).                   
           03  PR-LINE10.                                                       
               05  PR-NOTE10   OCCURS  2.                                       
                   07  PR-LN2-IND                  PIC X(1).                    
                   07  PR-LN2                      PIC X(31).                   
               05  PR-NOTE11   OCCURS  2.                                       
                   07  PR-LN3-IND                  PIC X(1).                    
                   07  PR-LN3                      PIC X(32).                   
           03  PR-LINE12.                                                       
               05  PR-NOTE12   OCCURS  2.                                       
                   07  PR-LN4                      PIC X(32).                   
           03  PR-LINE13.                                                       
               05  PR-NOTE13   OCCURS  2.                                       
                   07  PR-LN13                     PIC X(33).                   
           03  PR-LINE14.                                                       
               05  PR-NOTE14                       PIC X(135).                  
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
GNE        05  GACBMAS7                  PIC X(8)  VALUE 'GACBMAS7'.            
       LINKAGE SECTION.                                                         
GNE    COPY GFMIDCR7.                                                           
                                                                                
       01  MISC-AREA.                                                           
           03  FILLER                              PIC X(16).                   
           03  R-RESTART.                                                       
               05  R-RESTART-1.                                                 
                   07  R-REC-TYPE                  PIC X.                       
                   07  R-FORM                      PIC X.                       
GNE            05  R-GROUP                         PIC 9(7).                    
               05  R-ACCT                          PIC XXX.                     
GNE        03  FILLER              PIC X(4).                                    
                                                                                
       COPY GPRPRINT.                                                           
                                                                                
       COPY GPRTPARM.                                                           
                                                                                
       COPY GPRACCUM.                                                           
                                                                                
       01  GO-TO-SW             COMP-3         PIC S9.                          
                                                                                
       PROCEDURE DIVISION      USING   GI-FM-CERT-REQUEST                       
                                       MISC-AREA                                
                                       GPRPRINT                                 
                                       GPRTPARM                                 
                                       GPRACCUM                                 
                                       GO-TO-SW.                                
                                                                                
      *    READY TRACE.                                                         
       GPRIDCER-STARTUP.                                                        
      *----------------------------------------------------------------*        
      *-   ADD NEXT LINE TO SET UP ERROR RECORD   MARCUS SEP/89.      -*        
      *----------------------------------------------------------------*        
           MOVE '3'  TO E-REC-TYPE.                                             
                                                                                
           MOVE ZERO TO PRINT-RETURN.                                           
           MOVE SPACES TO PRINT-AREA.                                           
           MOVE GI-FM-RECORD-TYPE TO C-REC-TYPE                                 
           MOVE GI-FM-FORM     TO C-REC-FORM                                    
           MOVE GI-FM-GROUP    TO C-REC-GROUP                                   
           MOVE GI-FM-ACCOUNT  TO C-REC-ACCT.                                   
           MOVE  LOW-VALUES    TO  PREV-KEY.                                    
           IF  R-REC-TYPE  OF  R-RESTART  NOT EQUAL TO  '3'                     
           OR  R-FORM  OF  R-RESTART  EQUAL TO  HIGH-VALUES                     
               MOVE  R-RESTART  TO  STORE-RESTART                               
               GO  TO  INIT-1.                                                  
           IF  R-GROUP  OF  R-RESTART  NOT  NUMERIC                             
               MOVE  ZEROS  TO  R-GROUP  OF  R-RESTART.                         
           MOVE  R-RESTART-1  TO  SAVE-RESTART-1.                               
           MOVE  R-GROUP OF R-RESTART TO R-GROUP OF SAVE-RESTART.               
           MOVE  R-ACCT  OF R-RESTART TO R-ACCT  OF SAVE-RESTART.               
       INIT-1.                                                                  
           IF  R-FORM OF SAVE-RESTART NOT EQUAL SPACES                          
               IF  GO-TO-SW EQUAL +4                                            
                   IF  C-REC-FORM GREATER THAN R-FORM OF SAVE-RESTART           
                       GO TO GETBACK.                                           
           IF  CURR-SEG1  NOT LESS THAN  SAVE-RESTART-1                         
               MOVE  '1'       TO  START-SW                                     
           ELSE                                                                 
               MOVE  '0'   TO  START-SW.                                        
           GO  TO  REINIT-FORM.                                                 
                                                                                
       SUMMARY.                                                                 
           IF  PREV-KEY  EQUAL TO  CURR-KEY                                     
               GO  TO  NORM-PROC.                                               
           IF  PREV-SEG1   EQUAL TO  CURR-SEG1                                  
               GO  TO  REINIT-GROUP.                                            
                                                                                
      *  IF THERE IS ONE CANADIAN ID CERT TO PRINT, PRINT IT                    
      *  NOW BEFORE A NEW FORM IS USED OR EOJ.                                  
                                                                                
      *    IF (P-FORM  NOT EQUAL '1' AND '4')                                   
      *        PERFORM PRINT-FORMS THRU PRINT-FORMS-BLANK-IT.                   
            IF  R-FORM OF SAVE-RESTART NOT EQUAL SPACES                         
                IF  GO-TO-SW EQUAL +4                                           
                    IF  GI-FM-FORM GREATER THAN R-FORM OF SAVE-RESTART          
                        GO TO GETBACK.                                          
           IF  C-REC-TYPE           EQUAL TO  P-REC-TYPE                        
               GO  TO  REINIT-FORM.                                             
       GETBACK.                                                                 
           GOBACK.                                                              
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *          REINIT FORMS , GROUP                                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       REINIT-FORM.                                                             
           MOVE SPACES TO PRINT-AREA.                                           
           IF  START-SW   EQUAL TO  '0'                                         
               GO  TO  REINIT-FORM3.                                            
      *    CALL 'GPRSGMNT' USING PRINT-SYS022, CURR-SEG1.                       
                                                                                
       REINIT-FORM3.                                                            
           IF  GI-FM-FORM   EQUAL TO  '3' OR '6'                                
               MOVE  'AF'      TO  QDATE-PARM                                   
               MOVE  'F'       TO  LANG-CODE                                    
                                   PR-LANG                                      
             ELSE                                                               
                   MOVE  'AD'  TO  QDATE-PARM                                   
                   MOVE  'E'   TO  LANG-CODE                                    
                                   PR-LANG.                                     
           MOVE  +1 TO  SUB1.                                                   
           MOVE  +0 TO  SUB7.                                                   
           MOVE  +0 TO  SUB-FORM.                                               
                                                                                
       REINIT-GROUP.                                                            
           IF START-SW = '1'                                                    
               OR CURR-SEG1  LESS THAN SAVE-RESTART-1                           
                   GO TO REINIT-GROUP2.                                         
           MOVE '1' TO START-SW.                                                
      *    CALL 'GPRSGMNT' USING PRINT-SYS022, CURR-SEG1.                       
           MOVE  +1       TO  SUB1.                                             
                                                                                
       REINIT-GROUP2.                                                           
GNE        MOVE C-REC-GROUP  TO  GACCDMAS-GROUP.                                
GNE        MOVE C-REC-ACCT   TO  GACCDMAS-ACCT.                                 
GNE        CALL GACBMAS7 USING GACCDMAS-1                                       
GNE                              GACCDMAS-ERR                                   
GNE                              GMASTER7.                                      
GNE                                                                             
GNE        MOVE SPACES TO E-CODE.                                               
                                                                                
           MOVE  '0'           TO  ERR-SW.                                      
                                                                                
      *    MOVE  '000'         TO  GMGENTR.                                     
GNE   *    CALL  GZACCMT7    USING   C-REC-GROUP-ACCT                           
GNE   *                                GMGENTR                                  
GNE   *                                E-CODE.                                  
GNE        MOVE GGIGENERAL-INFORMATION OF GMASTER7 TO GMGENTR.                  
                                                                                
           IF E-CODE NOT EQUAL TO SPACES                                        
              MOVE ' ' TO GGICOUNTRY OF GMGENTR                                 
              PERFORM ERR-RTN                                                   
              MOVE '1' TO ERR-SW                                                
              GO TO NORM-PROC.                                                  
           IF GGICOUNTRY  OF GMGENTR NOT EQUAL '0'                              
              MOVE '1' TO GGICOUNTRY OF GMGENTR.                                
                                                                                
      *    MOVE  '030'         TO  GBNTRIDENT OF GMBNATR.                       
GNE   *    CALL  GZACCMT7    USING   C-REC-GROUP-ACCT                           
GNE   *                                GMBNATR                                  
GNE   *                                E-CODE.                                  
           IF  E-CODE   NOT EQUAL TO   SPACES                                   
               PERFORM   ERR-RTN                                                
               MOVE  '1'       TO  ERR-SW                                       
               GO  TO  NORM-PROC.                                               
GNE   *    CALL  GZNAEXP7    USING   GMBNATR                                    
GNE   *                                NA-EXP                                   
GNE   *                                E-CODE.                                  
GNE        MOVE GBNBILL-NAME-ADDR OF GMASTER7 TO NA-EXP.                        
           IF  E-CODE  NOT = SPACES                                             
               PERFORM   ERR-RTN.                                               
                                                                                
      *    MOVE  '140'         TO      GICTRIDENT OF GMIDCTR.                   
GNE   *    CALL  GZACCMT7    USING   C-REC-GROUP-ACCT                           
GNE   *                                GMIDCTR                                  
GNE   *                                E-CODE.                                  
GNE        MOVE GICIDENTIFICATION-CERTIFICATE OF GMASTER7 TO GMIDCTR.           
                                                                                
           IF  E-CODE  NOT = SPACES                                             
               PERFORM   ERR-RTN                                                
               MOVE  '1'       TO  ERR-SW.                                      
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  NORMAL PROCESSING                             *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NORM-PROC.                                                               
           IF  ERR-SW  EQUAL TO  '1'                                            
               GO  TO  GCR-RTN.                                                 
           MOVE SPACES TO SW-US.                                                
           IF  START-SW EQUAL '0'                                               
               GO TO PROC-NEW.                                                  
           IF  GI-FM-FORM IS EQUAL TO '1'                                       
               ADD +1 TO ACCUM-ID-US-OTH                                        
           ELSE                                                                 
           IF  GI-FM-FORM IS EQUAL TO '2'                                       
               ADD +1 TO ACCUM-ID-ENG-OTH                                       
           ELSE                                                                 
           IF  GI-FM-FORM IS EQUAL TO '3'                                       
               ADD +1 TO ACCUM-ID-FR-OTH                                        
           ELSE                                                                 
           IF  GI-FM-FORM IS EQUAL TO '4'                                       
               ADD +1 TO ACCUM-ID-US-SPGS                                       
           ELSE                                                                 
           IF  GI-FM-FORM IS EQUAL TO '5'                                       
               ADD +1 TO ACCUM-ID-ENG-SPGS                                      
           ELSE                                                                 
           IF  GI-FM-FORM IS EQUAL TO '6'                                       
               ADD +1 TO ACCUM-ID-FR-SPGS.                                      
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *           SECTION 1 OF FORM                                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PROC-NEW.                                                                
           IF GI-FM-S-F NOT = SPACE                                             
               MOVE  SPACES           TO  PR-LAST                               
               MOVE  SPACES           TO  PR-FIRST                              
               MOVE  SPACES           TO  PR-CERT1N                             
           ELSE                                                                 
           IF  GI-FM-ORDER   EQUAL TO  'N'                                      
               UNSTRING GI-FM-NAME2  DELIMITED BY ','                           
                   INTO PR-LAST                                                 
                        PR-FIRST                                                
               MOVE  GI-FM-CERT2      TO  PR-CERT1                              
           ELSE                                                                 
           IF  GI-FM-ORDER  EQUAL TO   'A'                                      
               UNSTRING GI-FM-NAME1  DELIMITED BY ','                           
                   INTO PR-LAST                                                 
                        PR-FIRST                                                
                   MOVE  GI-FM-CERT1  TO  PR-CERT1.                             
           MOVE  C-REC-GROUP       TO  PR-GROUP1.                               
           MOVE  C-REC-ACCT  TO  PR-ACCT1.                                      
                                                                                
           IF GI-FM-S-F NOT = SPACE                                             
               MOVE SPACES TO      PR-EFF1                                      
           ELSE                                                                 
               CALL  'QDATE'   USING   QDATE-PARM                               
                                       GI-FM-EFFECTIVE-DATE                     
                                       PR-EFF1                                  
                                                                                
            MOVE  NA-LN (1)     TO  PR-NA1.                                     
            IF  NA-DEL (1)    EQUAL TO  '$'                                     
                MOVE  NA-LN (2)     TO  PR-NA2                                  
                IF  NA-DEL (2)  EQUAL TO  '$'                                   
                    MOVE  NA-LN (3)     TO  PR-NA3.                             
                                                                                
           IF LANG-CODE = 'E'                                                   
               MOVE PR-CUSTE  TO PR-CUSTOMER                                    
               MOVE PR-URLE TO PR-URL.                                          
                                                                                
           IF LANG-CODE = 'F'                                                   
               MOVE PR-CUSTF  TO PR-CUSTOMER                                    
               MOVE PR-URLF TO PR-URL.                                          
            MOVE LANG-CODE TO PR-LANG.                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *           SECTION 2 OF FORM                                    *        
      *                                                                *        
      *   -  BUILD THE COVERAGE INFORMATION FOR THE ID CERT            *        
      *   -  BUILD THE BENEFIT INFORMATION                             *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-SECTION2.                                                             
           MOVE SPACES TO INDICATOR-EHC-DEN.                                    
           MOVE WS-COVERAGE TO WS-COVERAGE-R.                                   
           MOVE +1 TO SUB-MOVE.                                                 
       NP-COV-LOOP.                                                             
           IF SUB-MOVE GREATER THAN GI-FM-NUM-CODES                             
               GO TO NP-COV-LOOP-X.                                             
      *                                                                         
      *  JAN/90  M DRURY  - ALLOW ID-CERT TO PRINT FOR A SEL-IND OF DE.         
      *                                                                         
           IF GI-FM-SELECTION-IND (SUB-MOVE) = ('WA' OR 'NT' OR                 
                                                'CT' OR 'LA' OR 'DA')           
               GO TO NP-COV-NEXT.                                               
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = EHC                                   
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-EHC-VOLUME.                   
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-EHC-VOLUME.               
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = DEN                                   
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-DEN-VOLUME.                   
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-DEN-VOLUME.               
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = LIFE                                  
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-LIFE-VOLUME                   
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-LIFE-VOLUME.              
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = AD-D                                  
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-ADD-VOLUME                    
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-ADD-VOLUME.               
                                                                                
      *    ADD LINE FOR CHECKING GI-FM-S-F NOT EQUAL TO 0 OR 1                  
      *    THEREFORE THE GROUP MUST BE FAMILY(GREATER THAN 1)                   
      *    THEREFORE LET IT HAVE DEP. LIFE                                      
      *    TWO LINES ADDED BY BRENT G. WILKE 11OCT89 (PROD PROB)                
           IF GI-FM-COV-CODE (SUB-MOVE) = DL                                    
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-DL-VOLUME                     
               IF GI-FM-S-F NOT = SPACE                                         
               AND (GI-FM-S-F EQUAL '0'                                         
               OR   GI-FM-S-F EQUAL '1')                                        
                   MOVE +0                      TO WS-DL-VOLUME                 
               ELSE                                                             
                   MOVE +1                      TO WS-DL-VOLUME                 
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = WI                                    
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-WI-VOLUME                     
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-WI-VOLUME.                
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = LTD                                   
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-LTD-VOLUME                    
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-LTD-VOLUME.               
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = OPT-LIFE                              
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-OPT-LIFE-VOLUME               
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-OPT-LIFE-VOLUME.          
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = OPT-ADD                               
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-OPT-ADD-VOLUME                
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-OPT-ADD-VOLUME.           
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = OPT-SP                                
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-OPT-SP-VOLUME                 
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-OPT-SP-VOLUME.            
                                                                                
           IF GI-FM-COV-CODE (SUB-MOVE) = OPT-SUR                               
               MOVE GI-FM-VOLUME (SUB-MOVE) TO WS-OPT-SUR-VOLUME                
               IF GI-FM-S-F NOT = SPACE                                         
                   MOVE +1                      TO WS-OPT-SUR-VOLUME.           
                                                                                
       NP-COV-NEXT.                                                             
           ADD +1 TO SUB-MOVE.                                                  
           GO TO NP-COV-LOOP.                                                   
                                                                                
       NP-COV-LOOP-X.                                                           
                                                                                
      * BUILD SECTION 1 BENEFITS INFORMATION                                    
      *      AND THE INDICATOR                                                  
                                                                                
           IF GI-FM-S-F = SPACE                                                 
               PERFORM NP-SEC1-BEN THRU NP-SEC1-BEN-X.                          
                                                                                
      * BUILD THE COVERAGE LINE INFORMATION                                     
       NP-BUILD-COV.                                                            
                                                                                
           IF WS-EHC-VOLUME NOT = ZERO AND WS-DEN-VOLUME NOT = ZERO             
                 MOVE +3 TO SUB-FORM.                                           
                                                                                
           IF WS-EHC-VOLUME = ZERO AND WS-DEN-VOLUME NOT = ZERO                 
                 MOVE +2 TO SUB-FORM.                                           
                                                                                
           IF WS-EHC-VOLUME NOT ZERO AND WS-DEN-VOLUME = ZERO                   
                 MOVE +2 TO SUB-FORM.                                           
                                                                                
           IF WS-EHC-VOLUME = ZERO AND WS-DEN-VOLUME = ZERO                     
                 MOVE +1 TO SUB-FORM.                                           
                                                                                
           IF (WS-LIFE-VOLUME  NOT = ZERO AND                                   
               WS-ADD-VOLUME   NOT = ZERO)                                      
               PERFORM NP-LIFE-ADD-COV THRU NP-LIFE-ADD-COV-X                   
           ELSE                                                                 
           IF WS-LIFE-VOLUME  NOT = ZERO                                        
               PERFORM NP-LIFE-COV THRU NP-LIFE-COV-X                           
           ELSE                                                                 
           IF WS-ADD-VOLUME  NOT = ZERO                                         
               PERFORM NP-ADD-COV THRU NP-ADD-COV-X.                            
                                                                                
           IF (WS-LIFE-VOLUME  NOT = ZERO OR                                    
               WS-ADD-VOLUME   NOT = ZERO)                                      
                ADD +1 TO SUB-FORM.                                             
                                                                                
           IF WS-DL-VOLUME  NOT = ZERO                                          
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   MOVE INFO-DEP-LIFE-FRE TO PRINT-AREA5-SEC3 (SUB-FORM)        
                   ADD +1 TO SUB-FORM                                           
               ELSE                                                             
                   MOVE INFO-DEP-LIFE-ENG TO PRINT-AREA5-SEC3 (SUB-FORM)        
                   ADD +1 TO SUB-FORM.                                          
                                                                                
           IF (WS-WI-VOLUME  NOT = ZERO AND                                     
               WS-LTD-VOLUME   NOT = ZERO)                                      
               PERFORM NP-WI-LTD-COV THRU NP-WI-LTD-COV-X                       
           ELSE                                                                 
           IF WS-WI-VOLUME  NOT = ZERO                                          
               PERFORM NP-WI-COV THRU NP-WI-COV-X                               
           ELSE                                                                 
           IF WS-LTD-VOLUME  NOT = ZERO                                         
               PERFORM NP-LTD-COV THRU NP-LTD-COV-X.                            
                                                                                
           IF (WS-WI-VOLUME  NOT = ZERO OR                                      
               WS-LTD-VOLUME   NOT = ZERO)                                      
                ADD +1 TO SUB-FORM.                                             
                                                                                
           IF WS-OPT-LIFE-VOLUME  NOT = ZERO                                    
               PERFORM NP-OPT-LIFE THRU NP-OPT-LIFE-X                           
               ADD +1 TO SUB-FORM.                                              
                                                                                
           IF WS-OPT-ADD-VOLUME  NOT = ZERO                                     
               PERFORM NP-OPT-ADD  THRU NP-OPT-ADD-X                            
               ADD +1 TO SUB-FORM.                                              
                                                                                
           IF WS-OPT-SP-VOLUME  NOT = ZERO                                      
               PERFORM NP-OPT-SP  THRU NP-OPT-SP-X                              
               ADD +1 TO SUB-FORM.                                              
                                                                                
           IF SUB-FORM LESS THAN +7                                             
               IF WS-OPT-SUR-VOLUME  NOT = ZERO                                 
                   PERFORM NP-OPT-SUR THRU NP-OPT-SUR-X                         
                   ADD +1 TO SUB-FORM.                                          
                                                                                
      * LEAVE A BLANK LINE BETWEEN TOP AND BOTTOM IF THERE IS ROOM              
      *    MOVE SUB-FORM TO SUB-BLANK.                                          
      *    ADD +1 TO SUB-FORM.                                                  
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             ID CERT TRAILER INFORMATION                        *        
      *                                                                *        
      *     SEARCH ALL THE TRAILERS FOR THE CLASS                      *        
      *     - CLASS FOUND  FOR THE BENEFITS PRINT THE DESCRIPTION      *        
      *----------------------------------------------------------------*        
           IF  GICTRIDENT OF GMIDCTR  EQUAL TO  SPACES                          
               GO  TO  CHK-US.                                                  
                                                                                
           IF GI-FM-S-F = 0                                                     
               GO  TO  CHK-US.                                                  
                                                                                
           MOVE  +1        TO  SUB3  SUB4.                                      
                                                                                
       CLASS-LOOP.                                                              
           IF  GICCLASS  OF GMIDCTR (1, 1) EQUAL TO  '$$'                       
           OR  GI-FM-CLASS EQUAL TO  GICCLASS OF GMIDCTR (SUB3, SUB4)           
               PERFORM IDCERT-BENEFITS THRU IDCERT-BENEFITS-X                   
           ELSE                                                                 
               ADD   +1        TO  SUB4                                         
               IF  SUB4   LESS THAN  +6                                         
                   GO  TO  CLASS-LOOP.                                          
                                                                                
           MOVE  +1        TO  SUB4.                                            
           ADD   +1        TO  SUB3.                                            
           IF  (SUB3  GREATER THAN  +11                                         
             OR  GICCLASSES  OF GMIDCTR (SUB3) EQUAL TO  SPACES                 
             OR  SUB-FORM GREATER THAN +13)                                     
               GO  TO  CHK-US                                                   
           ELSE                                                                 
               GO  TO  CLASS-LOOP.                                              
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *           PRINT THE U. S. FORM                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       CHK-US.                                                                  
           IF GI-FM-S-F NOT = SPACE                                             
               PERFORM NP-SEC1-BEN-SA THRU NP-SEC1-BEN-SA-X.                    
           IF  GI-FM-FORM    NOT EQUAL TO  '1' AND '4'                          
               GO  TO  END-NEW.                                                 
           MOVE  C-REC-GROUP       TO  PR-GROUP1.                               
           MOVE  C-REC-ACCT  TO  PR-ACCT1.                                      
           IF GI-FM-S-F NOT = SPACE                                             
               MOVE  SPACES           TO  PR-LAST                               
               MOVE  SPACES           TO  PR-FIRST                              
               MOVE  SPACES           TO  PR-CERT1N                             
           ELSE                                                                 
           IF  GI-FM-ORDER   EQUAL TO  'N'                                      
               UNSTRING GI-FM-NAME2  DELIMITED BY ','                           
                   INTO PR-LAST                                                 
                        PR-FIRST                                                
               MOVE  GI-FM-CERT2      TO  PR-CERT1                              
           ELSE                                                                 
           IF  GI-FM-ORDER   EQUAL TO  'A'                                      
               MOVE  GI-FM-NAME1   TO  PR-EMP2                                  
                   MOVE  GI-FM-CERT1  TO  PR-CERT2.                             
           IF GI-FM-S-F NOT = SPACE                                             
               MOVE SPACES TO      PR-EFF2                                      
           ELSE                                                                 
               CALL  'QDATE'   USING   QDATE-PARM                               
                                       GI-FM-EFFECTIVE-DATE                     
                                       PR-EFF2.                                 
                                                                                
           IF GI-FM-S-F NOT = SPACE                                             
               PERFORM US-SECTION3-SA THRU US-SECTION3-SA-X                     
           ELSE                                                                 
               PERFORM US-SECTION3 THRU US-SECTION3-X.                          
           GO TO END-NEW-US.                                                    
                                                                                
       US-SECTION3-SA.                                                          
                                                                                
           MOVE +0 TO SUB-LINE.                                                 
           IF GI-FM-S-F = 0                                                     
               GO TO US-SECTION3-SA-X.                                          
      * LINE 1                                                                  
           IF SW-US-BENEFIT-DEN = '1' AND                                       
              SW-US-BENEFIT-EHC = '1'                                           
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNK  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
                                                                                
           IF SW-US-BENEFIT-DEN = '1'                                           
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNH  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
           IF SW-US-BENEFIT-EHC = '1'                                           
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNJ  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
               GO TO US-SECTION3-SA-X.                                          
      * LINE 2                                                                  
           IF GI-FM-S-F = 1                                                     
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNB  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
           IF GI-FM-S-F = 2                                                     
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNC  TO    PR-AREA6-LN1-US (SUB-LINE)                     
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNG  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
           IF GI-FM-S-F = 3                                                     
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNC   TO    PR-AREA6-LN1-US (SUB-LINE)                    
               ADD +1 TO SUB-LINE                                               
               MOVE I-LND   TO    PR-AREA6-LN1-US (SUB-LINE).                   
                                                                                
      * LINE 3                                                                  
           IF SW-US-BENEFIT-65 = '1'                                            
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNE  TO    PR-AREA6-LN1-US (SUB-LINE)                     
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNF  TO    PR-AREA6-LN1-US (SUB-LINE).                    
                                                                                
       US-SECTION3-SA-X.                                                        
                         EXIT.                                                  
                                                                                
       US-SECTION3.                                                             
                                                                                
           MOVE +0 TO SUB-LINE.                                                 
      * LINE 1                                                                  
           IF WS-DEN-VOLUME NOT = +0 AND                                        
              WS-EHC-VOLUME NOT = +0                                            
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNK  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
                                                                                
           IF WS-DEN-VOLUME NOT = +0                                            
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNH  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
           IF WS-EHC-VOLUME NOT = +0                                            
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNJ  TO    PR-AREA6-LN1-US (SUB-LINE).                    
                                                                                
      * LINE 2                                                                  
           IF SW-EMP-BEN = '1'                                                  
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNB  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
           IF SW-EMP-BEN = 2                                                    
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNC  TO    PR-AREA6-LN1-US (SUB-LINE)                     
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNG  TO    PR-AREA6-LN1-US (SUB-LINE)                     
           ELSE                                                                 
           IF SW-EMP-BEN = 3                                                    
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNC   TO    PR-AREA6-LN1-US (SUB-LINE)                    
               ADD +1 TO SUB-LINE                                               
               MOVE I-LND   TO    PR-AREA6-LN1-US (SUB-LINE).                   
                                                                                
      * LINE 3                                                                  
           IF SW-US-BENEFIT-65 = '1'                                            
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNE  TO    PR-AREA6-LN1-US (SUB-LINE)                     
               ADD +1 TO SUB-LINE                                               
               MOVE I-LNF  TO    PR-AREA6-LN1-US (SUB-LINE).                    
                                                                                
       US-SECTION3-X.                                                           
                      EXIT.                                                     
                                                                                
       END-NEW-US.                                                              
           IF (WS-EHC-VOLUME = +2 OR +3) OR                                     
              (WS-DEN-VOLUME = +2 OR +3)                                        
               PERFORM PRINT-FORMS                                              
                    VARYING SUB2 FROM +1 BY +1                                  
                         UNTIL SUB2 GREATER THAN +14                            
                    MOVE ' ' TO PR-ACCT2                                        
                                PR-EMP2                                         
                                PR-EFF2                                         
                                PR-LN5-U                                        
                    MOVE +0  TO PR-GROUP2                                       
                                PR-CERT2                                        
                    MOVE I-DUP1 TO PR-LN1-U                                     
                    MOVE I-DUP2 TO PR-LN2-U                                     
                    MOVE I-DUP3 TO PR-LN3-U                                     
                    MOVE I-DUP4 TO PR-LN4-U                                     
                    PERFORM PRINT-FORMS THRU PRINT-FORMS-BLANK-IT               
                    VARYING SUB2 FROM +1 BY +1                                  
                    UNTIL SUB2 GREATER THAN +14                                 
                    IF START-SW EQUAL '1'                                       
                       IF GI-FM-FORM EQUAL '1'                                  
                          ADD +1 TO ACCUM-ID-US-OTH                             
                          MOVE +1 TO SUB1                                       
                       ELSE                                                     
                          ADD +1 TO ACCUM-ID-US-SPGS                            
                          MOVE +1 TO SUB1                                       
                    ELSE                                                        
                       NEXT SENTENCE                                            
           ELSE                                                                 
               PERFORM PRINT-FORMS THRU PRINT-FORMS-BLANK-IT.                   
                         MOVE +1 TO SUB1.                                       
                                                                                
       END-NEW.                                                                 
                                                                                
           PERFORM PRINT-FORMS THRU PRINT-FORMS-BLANK-IT.                       
                                                                                
       GCR-RTN.                                                                 
           MOVE  CURR-KEY      TO  PREV-KEY.                                    
           CALL  'DLSREAD' USING TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 GI-FM-CERT-REQUEST                             
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
           IF  TAPE-RETURN NOT EQUAL TO  ZEROS OR                               
               GI-FM-RECORD-TYPE NOT = '3'                                      
               MOVE  HIGH-VALUES   TO  CURR-KEY                                 
           ELSE                                                                 
               MOVE GI-FM-RECORD-TYPE TO C-REC-TYPE                             
               MOVE GI-FM-FORM     TO C-REC-FORM                                
               MOVE GI-FM-GROUP    TO C-REC-GROUP                               
               MOVE GI-FM-ACCOUNT  TO C-REC-ACCT.                               
                                                                                
           GO  TO  SUMMARY.                                                     
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              BUILD SECTION 1 BENEFITS                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-SEC1-BEN-SA.                                                          
           MOVE +9 TO SUB-FORM.                                                 
                                                                                
           IF GI-FM-S-F = 0                                                     
                GO TO NP-SEC1-BEN-SA-X.                                         
                                                                                
           IF SW-US-BENEFIT-DEN = '1' OR SW-US-BENEFIT-EHC = '1'                
                NEXT SENTENCE                                                   
           ELSE                                                                 
                GO TO NP-SEC1-BEN-SA-X.                                         
                                                                                
           ADD +1 TO SUB-FORM.                                                  
           IF GI-FM-S-F = '1'                                                   
                IF  GI-FM-FORM   EQUAL TO  '3' OR '6'                           
                    DISPLAY 'US'                                                
                    MOVE  INFO-BENEFITS-EMP-ONLY-F TO                           
                                 COVERAGE1                                      
                ELSE                                                            
                    DISPLAY 'US'                                                
                    MOVE  INFO-BENEFITS-EMP-ONLY TO                             
                                 COVERAGE1.                                     
                                                                                
           IF GI-FM-S-F = '2'                                                   
                IF  GI-FM-FORM   EQUAL TO  '3' OR '6'                           
                    DISPLAY 'US'                                                
                    MOVE INFO-BENEFITS-EMP-DEP1-F TO                            
                                 COVERAGE1                                      
                ELSE                                                            
                    DISPLAY 'US'                                                
                    MOVE INFO-BENEFITS-EMP-DEP1 TO                              
                                 COVERAGE1.                                     
           IF GI-FM-S-F = '3'                                                   
                IF  GI-FM-FORM   EQUAL TO  '3' OR '6'                           
                        DISPLAY 'US'                                            
                        MOVE INFO-BENEFITS-EMP-DEPS-F TO                        
                                 COVERAGE1                                      
                    ELSE                                                        
                        DISPLAY 'US'                                            
                        MOVE INFO-BENEFITS-EMP-DEPS TO                          
                                 COVERAGE1.                                     
                                                                                
           IF SW-US-BENEFIT-DEN = '1' AND SW-US-BENEFIT-EHC = '1'               
                MOVE INFO-BENEFITS-EMP-DEPS TO COVERAGE2.                       
                                                                                
       NP-SEC1-BEN-SA-X.                                                        
                         EXIT.                                                  
                                                                                
       NP-SEC1-BEN.                                                             
           IF (WS-EHC-VOLUME = +0 AND WS-DEN-VOLUME = +0)                       
              GO TO NP-SEC1-BEN-X.                                              
                                                                                
           MOVE +9 TO SUB-FORM.                                                 
           IF (WS-EHC-VOLUME = +1 AND WS-DEN-VOLUME = +1) OR                    
              (WS-EHC-VOLUME = +2 AND WS-DEN-VOLUME = +2) OR                    
              (WS-EHC-VOLUME = +3 AND WS-DEN-VOLUME = +3) OR                    
              (WS-EHC-VOLUME = +2 AND WS-DEN-VOLUME = +3) OR                    
              (WS-EHC-VOLUME = +3 AND WS-DEN-VOLUME = +2)                       
               NEXT SENTENCE                                                    
           ELSE                                                                 
                GO TO NP-SEC1-BEN-SKIP1.                                        
                                                                                
           IF (WS-EHC-VOLUME = +1 AND WS-DEN-VOLUME = +1)                       
               MOVE '1' TO SW-EMP-BEN                                           
               MOVE WS-DEN-VOLUME TO TEMP-VOLUME-DESC                           
               PERFORM NP-SEC1-BEN-FIND THRU NP-SEC1-BEN-FIND-X                 
           ELSE                                                                 
                                                                                
           IF (WS-EHC-VOLUME = +2 AND WS-DEN-VOLUME = +2)                       
               MOVE '2' TO SW-EMP-BEN                                           
               MOVE WS-DEN-VOLUME TO TEMP-VOLUME-DESC                           
               PERFORM NP-SEC1-BEN-FIND THRU NP-SEC1-BEN-FIND-X                 
                                                                                
           ELSE                                                                 
               MOVE '3' TO SW-EMP-BEN                                           
               MOVE +3            TO TEMP-VOLUME-DESC                           
               PERFORM NP-SEC1-BEN-FIND THRU NP-SEC1-BEN-FIND-X.                
                                                                                
           GO TO NP-SEC1-BEN-X.                                                 
                                                                                
       NP-SEC1-BEN-SKIP1.                                                       
           IF (WS-EHC-VOLUME GREATER THAN +0 AND                                
               WS-DEN-VOLUME = +0)                                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO  NP-SEC1-BEN-SKIP2.                                        
           ADD +1 TO SUB-FORM.                                                  
                                                                                
           MOVE WS-EHC-VOLUME TO TEMP-VOLUME-DESC.                              
           PERFORM NP-SEC1-BEN-FIND THRU NP-SEC1-BEN-FIND-X.                    
           GO TO NP-SEC1-BEN-X.                                                 
                                                                                
       NP-SEC1-BEN-SKIP2.                                                       
           IF (WS-DEN-VOLUME GREATER THAN +0 AND                                
               WS-EHC-VOLUME = +0)                                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO  NP-SEC1-BEN-SKIP3.                                        
           ADD +1 TO SUB-FORM.                                                  
                                                                                
           MOVE WS-DEN-VOLUME TO TEMP-VOLUME-DESC.                              
           PERFORM NP-SEC1-BEN-FIND THRU NP-SEC1-BEN-FIND-X.                    
           GO TO NP-SEC1-BEN-X.                                                 
                                                                                
       NP-SEC1-BEN-SKIP3.                                                       
           MOVE '1' TO SW-DISPLAY-IND.                                          
           MOVE WS-EHC-VOLUME TO TEMP-VOLUME-DESC.                              
           PERFORM NP-SEC1-BEN-FIND THRU NP-SEC1-BEN-FIND-X.                    
                                                                                
           ADD +1 TO SUB-FORM.                                                  
                                                                                
           MOVE WS-DEN-VOLUME TO TEMP-VOLUME-DESC.                              
           PERFORM NP-SEC1-BEN-FIND THRU NP-SEC1-BEN-FIND-X.                    
                                                                                
           IF WS-DEN-VOLUME = +3 OR                                             
              WS-EHC-VOLUME = +3                                                
                MOVE '3' TO SW-EMP-BEN                                          
           ELSE                                                                 
           IF WS-DEN-VOLUME = +2 OR                                             
              WS-EHC-VOLUME = +2                                                
                MOVE '2' TO SW-EMP-BEN                                          
           ELSE                                                                 
                MOVE '1' TO SW-EMP-BEN.                                         
                                                                                
       NP-SEC1-BEN-X.                                                           
                      EXIT.                                                     
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             FIND THE COVERAGE MESSAGE                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-SEC1-BEN-FIND.                                                        
           ADD +1 TO SUB-FORM.                                                  
                                                                                
           IF WS-EHC-VOLUME = +0                                                
                MOVE SPACES TO COVERAGE1.                                       
                                                                                
           IF WS-EHC-VOLUME = +1                                                
                IF  GI-FM-FORM   EQUAL TO  '3'                                  
                    MOVE  INFO-BENEFITS-EMP-ONLY-F TO                           
                               COVERAGE1                                        
                ELSE                                                            
                    IF  GI-FM-FORM   EQUAL TO  '2'                              
                        MOVE  INFO-BENEFITS-EMP-ONLY TO                         
                                   COVERAGE1.                                   
                                                                                
           IF WS-EHC-VOLUME = +2                                                
                IF  GI-FM-FORM   EQUAL TO  '3'                                  
                    MOVE  INFO-BENEFITS-EMP-DEP1-F TO                           
                               COVERAGE1                                        
                ELSE                                                            
                    MOVE  INFO-BENEFITS-EMP-DEP1 TO                             
                                   COVERAGE1.                                   
                                                                                
           IF WS-EHC-VOLUME = +3                                                
                IF  GI-FM-FORM   EQUAL TO  '3'                                  
                    MOVE  INFO-BENEFITS-EMP-DEPS-F TO                           
                               COVERAGE1                                        
                ELSE                                                            
                    MOVE  INFO-BENEFITS-EMP-DEPS TO                             
                                   COVERAGE1.                                   
                                                                                
           IF WS-DEN-VOLUME = +0                                                
                MOVE  SPACES TO COVERAGE2.                                      
                                                                                
           IF WS-DEN-VOLUME = +1                                                
                IF  GI-FM-FORM   EQUAL TO  '3'                                  
                    MOVE  INFO-BENEFITS-EMP-ONLY-F TO                           
                               COVERAGE2                                        
                ELSE                                                            
                    MOVE  INFO-BENEFITS-EMP-ONLY TO                             
                                   COVERAGE2.                                   
                                                                                
           IF WS-DEN-VOLUME = +2                                                
                IF  GI-FM-FORM   EQUAL TO  '3'                                  
                    MOVE  INFO-BENEFITS-EMP-DEP1-F TO                           
                               COVERAGE2                                        
                ELSE                                                            
                    MOVE  INFO-BENEFITS-EMP-DEP1 TO                             
                                   COVERAGE2.                                   
                                                                                
           IF WS-DEN-VOLUME = +3                                                
                IF  GI-FM-FORM   EQUAL TO  '3'                                  
                    MOVE  INFO-BENEFITS-EMP-DEPS-F TO                           
                               COVERAGE2                                        
                ELSE                                                            
                    MOVE  INFO-BENEFITS-EMP-DEPS TO                             
                                   COVERAGE2.                                   
                                                                                
       NP-SEC1-BEN-FIND-X.                                                      
                           EXIT.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *       LIFE AND ADD COVERAGE  PRINT                             *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-LIFE-ADD-COV.                                                         
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF GGIHANDLING-CODE  OF GMGENTR  = '2'                       
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-ADD-VOLUME  TO INFO-L-ADD-AMT-FRE                
                       MOVE WS-LIFE-VOLUME TO INFO-LIFE-A-AMT-FRE               
                       MOVE INFO-LIFE-ADD-AMOUNT-FRE TO                         
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-LIFE-ADD-FRE TO                                
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
               ELSE                                                             
                   IF GGIHANDLING-CODE  OF GMGENTR  = '2'                       
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-LIFE-VOLUME TO INFO-LIFE-A-AMT-ENG               
                       MOVE WS-ADD-VOLUME  TO INFO-L-ADD-AMT-ENG                
                       MOVE INFO-LIFE-ADD-AMOUNT-ENG TO                         
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-LIFE-ADD-ENG TO                                
                            PRINT-AREA5-SEC3 (SUB-FORM).                        
                                                                                
       NP-LIFE-ADD-COV-X.                                                       
                          EXIT.                                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *       LIFE COVERAGE ONLY PRINT                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-LIFE-COV.                                                             
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF GGIHANDLING-CODE OF GMGENTR  = '2'                        
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-LIFE-VOLUME TO INFO-LIFE-AMT-FRE                 
                       MOVE INFO-LIFE-AMOUNT-FRE TO                             
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                      MOVE INFO-LIFE-FRE TO PRINT-AREA5-SEC3 (SUB-FORM)         
               ELSE                                                             
                   IF GGIHANDLING-CODE OF GMGENTR  = '2'                        
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-LIFE-VOLUME  TO INFO-LIFE-AMT-ENG                
                       MOVE INFO-LIFE-AMOUNT-ENG TO                             
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-LIFE-ENG TO                                    
                            PRINT-AREA5-SEC3 (SUB-FORM).                        
                                                                                
       NP-LIFE-COV-X.                                                           
                       EXIT.                                                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *        ADD COVERAGE ONLY PRINT                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-ADD-COV.                                                              
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF GGIHANDLING-CODE OF GMGENTR = '2'                         
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-ADD-VOLUME TO INFO-ADD-AMT-FRE                   
                       MOVE INFO-ADD-AMOUNT-FRE TO                              
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-ADD-FRE TO PRINT-AREA5-SEC3 (SUB-FORM)         
               ELSE                                                             
                   IF GGIHANDLING-CODE OF GMGENTR = '2'                         
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-ADD-VOLUME  TO INFO-ADD-AMT-ENG                  
                       MOVE INFO-ADD-AMOUNT-ENG TO                              
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-ADD-ENG TO PRINT-AREA5-SEC3 (SUB-FORM).        
       NP-ADD-COV-X.                                                            
                     EXIT.                                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *       WI AND LTD COVERAGE  PRINT                               *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-WI-LTD-COV.                                                           
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF GGIHANDLING-CODE OF GMGENTR  = '2'                        
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-LTD-VOLUME  TO INFO-W-LTD-AMT-FRE                
                       MOVE WS-WI-VOLUME TO INFO-WI-L-AMT-FRE                   
                       MOVE INFO-WI-LTD-AMOUNT-FRE TO                           
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-WI-LTD-FRE TO                                  
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
               ELSE                                                             
                   IF GGIHANDLING-CODE OF GMGENTR   = '2'                       
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-WI-VOLUME TO INFO-WI-L-AMT-ENG                   
                       MOVE WS-LTD-VOLUME  TO INFO-W-LTD-AMT-ENG                
                       MOVE INFO-WI-LTD-AMOUNT-ENG TO                           
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-WI-LTD-ENG TO                                  
                            PRINT-AREA5-SEC3 (SUB-FORM).                        
                                                                                
       NP-WI-LTD-COV-X.                                                         
                        EXIT.                                                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *       WI COVERAGE ONLY PRINT                                 *          
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-WI-COV.                                                               
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF GGIHANDLING-CODE OF GMGENTR = '2'                         
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-WI-VOLUME TO INFO-WI-AMT-FRE                     
                       MOVE INFO-WI-AMOUNT-FRE TO                               
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-WI-FRE TO PRINT-AREA5-SEC3 (SUB-FORM)          
               ELSE                                                             
                   IF GGIHANDLING-CODE OF GMGENTR  = '2'                        
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-WI-VOLUME  TO INFO-WI-AMT-ENG                    
                       MOVE INFO-WI-AMOUNT-ENG TO                               
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-WI-ENG TO PRINT-AREA5-SEC3 (SUB-FORM).         
       NP-WI-COV-X.                                                             
                    EXIT.                                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *        LTD COVERAGE ONLY PRINT                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-LTD-COV.                                                              
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF GGIHANDLING-CODE OF GMGENTR   = '2'                       
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-LTD-VOLUME TO INFO-LTD-AMT-FRE                   
                       MOVE INFO-LTD-AMOUNT-FRE TO                              
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-LTD-FRE TO                                     
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
               ELSE                                                             
                   IF GGIHANDLING-CODE OF GMGENTR  = '2'                        
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-LTD-VOLUME  TO INFO-LTD-AMT-ENG                  
                       MOVE INFO-LTD-AMOUNT-ENG TO                              
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-LTD-ENG TO                                     
                            PRINT-AREA5-SEC3 (SUB-FORM).                        
                                                                                
       NP-LTD-COV-X.                                                            
                     EXIT.                                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *            OPTION LIFE PRINT                                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-OPT-LIFE.                                                             
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF (GGIHANDLING-CODE OF GMGENTR  ='2' OR '1')                
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-LIFE-VOLUME TO INFO-OPT-LIFE-AMT-FRE         
                       MOVE INFO-OPT-LIFE-AMOUNT-FRE TO                         
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-OPT-LIFE-FRE TO                                
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
               ELSE                                                             
                   IF (GGIHANDLING-CODE OF GMGENTR  = '2' OR '1')               
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-LIFE-VOLUME  TO INFO-OPT-LIFE-AMT-ENG        
                       MOVE INFO-OPT-LIFE-AMOUNT-ENG TO                         
                            PRINT-AREA5-SEC3 (SUB-FORM)                         
                   ELSE                                                         
                       MOVE INFO-OPT-LIFE-ENG TO                                
                            PRINT-AREA5-SEC3 (SUB-FORM).                        
                                                                                
       NP-OPT-LIFE-X.                                                           
                      EXIT.                                                     
      *----------------------------------------------------------------*        
      *                                                                *        
      *            OPTION ADD PRINT                                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-OPT-ADD.                                                              
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF (GGIHANDLING-CODE OF GMGENTR = '2' OR '1')                
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-ADD-VOLUME TO INFO-OPT-ADD-AMT-FRE           
                       MOVE INFO-OPT-ADD-AMOUNT-FRE TO                          
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
                   ELSE                                                         
                       MOVE INFO-OPT-ADD-FRE TO                                 
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
               ELSE                                                             
                   IF (GGIHANDLING-CODE OF GMGENTR = '2' OR '1')                
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-ADD-VOLUME  TO INFO-OPT-ADD-AMT-ENG          
                       MOVE INFO-OPT-ADD-AMOUNT-ENG TO                          
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
                   ELSE                                                         
                       MOVE INFO-OPT-ADD-ENG TO                                 
                                    PRINT-AREA5-SEC3 (SUB-FORM).                
       NP-OPT-ADD-X.                                                            
                     EXIT.                                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *            OPTION SPOUSAL PRINT                                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-OPT-SP.                                                               
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF (GGIHANDLING-CODE OF GMGENTR = '2' OR '1')                
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-SP-VOLUME TO INFO-OPT-SP-AMT-FRE             
                       MOVE INFO-OPT-SP-AMOUNT-FRE TO                           
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
                   ELSE                                                         
                       MOVE INFO-OPT-SP-FRE TO                                  
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
               ELSE                                                             
                   IF (GGIHANDLING-CODE OF GMGENTR = '2' OR '1')                
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-SP-VOLUME  TO INFO-OPT-SP-AMT-ENG            
                       MOVE INFO-OPT-SP-AMOUNT-ENG TO                           
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
                   ELSE                                                         
                       MOVE INFO-OPT-SP-ENG TO                                  
                                    PRINT-AREA5-SEC3 (SUB-FORM).                
       NP-OPT-SP-X.                                                             
                    EXIT.                                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *            OPTION SURVIVOR INCOME                              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NP-OPT-SUR.                                                              
               IF GI-FM-FORM EQUAL '3' OR '6'                                   
                   IF (GGIHANDLING-CODE OF GMGENTR = '2')                       
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-SUR-VOLUME TO INFO-OPT-SUR-AMT-FRE           
                       MOVE INFO-OPT-SUR-AMOUNT-FRE TO                          
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
                   ELSE                                                         
                       MOVE INFO-OPT-SUR-FRE TO                                 
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
               ELSE                                                             
                   IF (GGIHANDLING-CODE OF GMGENTR = '2')                       
                     AND GI-FM-S-F = SPACE                                      
                       MOVE WS-OPT-SUR-VOLUME  TO INFO-OPT-SUR-AMT-ENG          
                       MOVE INFO-OPT-SUR-AMOUNT-ENG TO                          
                                    PRINT-AREA5-SEC3 (SUB-FORM)                 
                   ELSE                                                         
                       MOVE INFO-OPT-SUR-ENG TO                                 
                                   PRINT-AREA5-SEC3 (SUB-FORM).                 
       NP-OPT-SUR-X.                                                            
                     EXIT.                                                      
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *          ID CERTS  BENEFITS                                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       IDCERT-BENEFITS.                                                         
           MOVE  +1        TO  SUB4 SUB5 COV-COD-SUB.                           
           MOVE  SUB-FORM  TO  SUB7.                                            
       COV-COD-LOOP.                                                            
           IF  COV-COD-SUB GREATER THAN +10                                     
           OR  GICCOVERAGE-CODE OF GMIDCTR (SUB3, COV-COD-SUB)                  
               EQUAL SPACES                                                     
               GO TO IDCERT-BENEFITS-X.                                         
                                                                                
      * GPL - ALL DEN CODES                                                     
           IF (GICCOVERAGE-CODE OF GMIDCTR (SUB3, COV-COD-SUB)                  
             EQUAL '1R' OR '6H' OR '7K' OR '7M' OR '7W' OR '7Z'                 
                        OR '8H' OR '9K' OR '9M' OR '9W' OR '9Z')                
               MOVE '1' TO SW-US-BENEFIT-DEN                                    
               IF  WS-DEN-VOLUME = +0                                           
                   GO TO COV-COD-NEXT                                           
               ELSE                                                             
                   IF WS-EHC-VOLUME > +0 AND                                    
                      GICCOVERAGE-CODE OF GMIDCTR (SUB3, COV-COD-SUB)           
                      EQUAL '7Z'                                                
                      MOVE +2 TO SUB7                                           
                   ELSE                                                         
                      IF WS-EHC-VOLUME = +0 AND                                 
                        GICCOVERAGE-CODE OF GMIDCTR (SUB3, COV-COD-SUB)         
                      EQUAL '7Z'                                                
                      MOVE +1 TO SUB7                                           
                      ELSE                                                      
                         MOVE SUB-FORM TO SUB7.                                 
                                                                                
      * GPL - ALL EHC CODES                                                     
           IF (GICCOVERAGE-CODE OF GMIDCTR (SUB3, COV-COD-SUB)                  
             EQUAL '2G' OR '6A' OR '6B' OR '6C' OR '6D' OR '6G' OR '6J'         
                        OR '8A' OR '8B' OR '8C' OR '8D' OR '8G' OR '8J'         
                OR '7D' OR '7G' OR '7H' OR '7J' OR '7L' OR '7P' OR '7Q'         
                OR '9D' OR '9G' OR '9H' OR '9J' OR '9L' OR '9P' OR '9Q'         
                OR '7R' OR '7S' OR '7T' OR '7U' OR '7V' OR '7X' OR '7Y'         
                OR '9R' OR '9S' OR '9T' OR '9U' OR '9V' OR '9X' OR '9Y')        
               MOVE '1' TO SW-US-BENEFIT-EHC                                    
               IF  WS-EHC-VOLUME = +0                                           
                   GO TO COV-COD-NEXT                                           
               ELSE                                                             
                   IF GICCOVERAGE-CODE OF GMIDCTR (SUB3, COV-COD-SUB)           
                      EQUAL '6C'                                                
                      MOVE +1  TO SUB7                                          
                   ELSE                                                         
                      IF WS-DEN-VOLUME > +0 AND SUB-FORM = +2                   
                         ADD +1 to SUB-FORM                                     
                         MOVE SUB-FORM  TO SUB7                                 
                      ELSE                                                      
                         MOVE SUB-FORM  TO SUB7.                                
                                                                                
            PERFORM IDCERT-BUILD-DESC THRU IDCERT-BUILD-DESC-X.                 
                                                                                
       COV-COD-NEXT.                                                            
           ADD +1 TO COV-COD-SUB.                                               
           IF SUB-FORM GREATER THAN +10                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO COV-COD-LOOP.                                              
       IDCERT-BENEFITS-X.                                                       
                          EXIT.                                                 
                                                                                
       IDCERT-BUILD-DESC.                                                       
           MOVE  GICCOVERAGE-CODE OF GMIDCTR (SUB3, COV-COD-SUB)                
                 TO BEN-CODE.                                                   
           CALL  'GACCDB01'    USING   BEN-CODE                                 
                                       BEN-REC                                  
                                       E-CODE                                   
                                       LANG-CODE.                               
           IF  E-CODE   NOT EQUAL TO   SPACES                                   
               PERFORM   ERR-RTN                                                
               GO TO IDCERT-BUILD-DESC-X.                                       
                                                                                
           IF PRINT-AREA5-SEC3-DESC (SUB7) NOT EQUAL SPACES                     
                 MOVE SUB-FORM to SUB7.                                         
           IF BEN-DESC NOT EQUAL SPACES                                         
              MOVE  BEN-DESC TO PRINT-AREA5-SEC3-DESC (SUB7).                   
           IF PRINT-AREA5-SEC3-DESC (SUB-FORM) NOT EQUAL SPACES                 
           ADD +1 TO SUB-FORM.                                                  
                                                                                
       IDCERT-BUILD-DESC-X.                                                     
                            EXIT.                                               
      *----------------------------------------------------------------*        
      *                                                                *        
                                                                                
       PRINT-FORMS.                                                             
                                                                                
           IF COVERAGE1 EQUAL SPACES AND COVERAGE2 NOT EQUAL SPACES             
              MOVE COVERAGE2 TO COVERAGE1                                       
              MOVE SPACES TO COVERAGE2.                                         
                                                                                
           IF  START-SW  EQUAL TO  '1'                                          
               CALL 'DLSWRITE' USING PRINT-SYS018,     PRINT-RETURN             
                                     PRINT-AREA,       PRINT-RECSIZE            
                                     PRINT-BLKSIZE,    PRINT-FORMAT             
                                     PRINT-SYS018-COUNT.                        
       PRINT-FORMS-BLANK-IT.                                                    
           MOVE  SPACES        TO  PRINT-AREA.                                  
                                                                                
       ERR-RTN.                                                                 
           MOVE C-REC-GROUP    TO  E-GROUP.                                     
           MOVE C-REC-ACCT     TO  E-ACCT.                                      
           MOVE GGICOUNTRY OF GMGENTR TO E-COUNTRY.                             
           IF  GI-FM-ORDER   EQUAL TO  'N'                                      
               MOVE  GI-FM-CERT2     TO  E-CERT.                                
           IF  GI-FM-ORDER  EQUAL TO  'A'                                       
               MOVE  GI-FM-CERT1  TO  E-CERT.                                   
           IF  GI-FM-ORDER  EQUAL TO  'N'                                       
               MOVE  ZEROS   TO  E-CERT.                                        
      *                                                                         
      *  NEW FIELDS TO THE ERROR REPORT           MARCUS                        
      *                                                                         
           MOVE GI-FM-PRODUCT      TO E-PROD-CD.                                
           MOVE GI-FM-GRP-OFF      TO E-OFFICE.                                 
                                                                                
           CALL  'DLSWRITE' USING  TAPE-SYS011                                  
                                   TAPE-RETURN                                  
                                   ERR-REC                                      
                                   TAPE-SYS011-RECSIZE                          
                                   TAPE-SYS011-BLKSIZE                          
                                   TAPE-SYS011-FORMAT                           
                                   TAPE-SYS011-COUNT.                           
           MOVE  SPACES        TO  E-CODE.                                      
       ERR-RTN-END.                                                             
                                                                                
