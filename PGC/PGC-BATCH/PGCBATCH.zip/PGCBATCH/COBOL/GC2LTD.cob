       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2LTD.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *AUTHOR.   B. BEAUBIEN.                                                   
      *-----------------------------------------------------------------        
      * PREPAID COMMISSION AUDIT REPORT                                         
      * IDENTIFY, COMPARE AND PROVIDE A BALANCE BETWEEN COMISSIONS PAID         
      * TO COMMISSIONS EARNED                                                   
      *-----------------------------------------------------------------        
      * HISTORY:                                                                
      * TASK 21693  BEAUBIB   OCT 2002                                          
      *             CHANGE FROM USING EFFECTIVE DATES TO PROCESS DATES          
      *                                                                         
      * TASK 21693  FULFONI   NOV 2004 - REVISITED                              
      *             PROCESS DATES ARE OVER A MONTHLY INTERVAL AS PER            
      *             THE JCL SUPPLIED DATEFILE AS DETERMINED BY THE LAST         
      *             DAY OF THE MONTH.                                           
      *                                                                         
      * TASK 33782  B BEAUBIEN JAN 2005                                         
      *             FINAL CORRECTIONS TO DATE SELECTION                         
      *                                                                         
      *    JUL/2005  R. KNAUD.                                                  
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)                  
      *                  USE VOGPWRA7 TO READ THE VCM AND GIPSY                 
      *                  MASTER FILES.                                          
      *         - HUB:  COMM PSMASTER ROUTER (VOCOMM VOPSM/PSM)                 
      *                  READ THE VO PSMASTER FIRST (USING GAEDATSR)            
      *                  AND IF THE REQUIRED RECORD IS NOT THERE,               
      *                  READ THE PSMASTER (USING GACCDMA7).                    
      *                                                                         
      *    OCT/2008  IBM           - ENTERPRISE COMPILER UPGRADE       *        
      *-----------------------------------------------------------------        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCLTD          
      * JUN2013 - GROUP NUMBER EXPANSION PROJECT - 7-DIGIT COMPLIANT            
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2LTD W-S STARTS HERE **'.                                  
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GAEDATSR                   PIC X(8)    VALUE 'GAEDATSR'.         
           05  GC2DATE                    PIC X(8)    VALUE 'GC2DATE'.          
      * VOCOMM VCM/GIPSY                                                        
           05  VOGPWRA7                   PIC X(8)    VALUE 'VOGPWRA7'.         
                                                                                
       01  WS-WORK-FIELDS.                                                      
           05  WS-VERB                    PIC X(16)  VALUE SPACES.              
           05  WS-ERR-SW                  PIC X      VALUE 'N'.                 
           05  WS-COMP-DONE               PIC X      VALUE 'N'.                 
           05  WS-LAST-DAY-MONTH-ALIS.                                          
               10  WS-LAST-DAY-MONTH-YYY  PIC S9(3) COMP-3.                     
               10  WS-LAST-DAY-MONTH-DDD  PIC S9(3) COMP-3.                     
                                                                                
       01  GACCDMA7-PS-PARMS.                                                   
           05  GACCDMA7-PS-FUNC      PIC S9(4)      COMP   VALUE +18.           
REN        05  GACCDMA7-PS-GROUP     PIC S9(7)      COMP-3.                     
           05  GACCDMA7-PS-ACCT      PIC X(3).                                  
           05  GACCDMA7-PS-CERT      PIC S9(9)      COMP-3.                     
           05  GACCDMA7-PS-WORK      PIC X(9).                                  
                                                                                
       01  GACCDMA7-PS-RETURN        PIC X(3).                                  
           88  GACCDMA7-PS-RET-OK                   VALUE '   '.                
           88  GACCDMA7-PS-EOF                      VALUE 'R01'.                
           88  GACCDMA7-PS-NOT-FOUND                VALUE 'R01'.                
           88  GACCDMA7-PS-DISK-ERROR               VALUE 'R03'.                
           88  GACCDMA7-PS-FUNC-INVALID             VALUE 'R09'.                
                                                                                
      * VOCOMM VOPSM/PSM                                                        
       01  WS-PSMASTER.                                                         
           05  WS-PSMGROUP-NUMBER      PIC S9(7) COMP-3.                        
           05  WS-PSMNXT-RNEW-DATE.                                             
               10  WS-PSMNXT-RNEW-YR   PIC S9(3) COMP-3.                        
               10  WS-PSMNXT-RNEW-DAY  PIC S9(3) COMP-3.                        
      *----------------------------------------------------------------         
      *  VO PS MASTER                                                           
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** VO PS MASTER  ****    '.                                    
           COPY VOPSMAST.                                                       
                                                                                
      *----------------------------------------------------------------         
      *  GIPSY PS MASTER                                                        
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GIPSY PS MASTER  ****    '.                                 
      * PSMASTE7                                                                
CPYNME     COPY PSMASTE7.                                                       
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      *----------------------------------------------------------------         
      *  GIPSY MASTER                                                           
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GIPSY MASTER  ****       '.                                 
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
      * VOCOMM VCM/GIPSY                                                        
           03  FILLER             PIC X(30).                                    
                                                                                
      *----------------------------------------------------------------         
      *  PARMS USED FOR DATE CONVERSION                                         
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GC2DATE PARMS ****       '.                                 
       01  GC2DATE-PARMS.                                                       
           COPY GARDATEP.                                                       
      *                                                                         
      *----------------------------------------------------------------         
      *  DATECARD LAYOUT                                                        
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GARDTCRD ****            '.                                 
       01  GARDTCRD.                                                            
           COPY GARDTCRD.                                                       
           05  FILLER                           PIC X(56).                      
                                                                                
      *----------------------------------------------------------------         
      *  OUTPUT  LAYOUT                                                         
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** OUTPUT RECORD ****       '.                                 
       01  OUTPUT-RECORD.                                                       
           05  O-AGENT                 PIC X(6)      VALUE SPACES.              
           05  FILLER                  PIC X         VALUE SPACES.              
REN        05  O-GROUP                 PIC X(7)      VALUE ZEROS.               
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-ACCOUNT               PIC X(3)      VALUE ZEROS.               
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-GIPSY-RENEWAL-DATE    PIC X(9)      VALUE SPACES.              
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-RECON-DATE            PIC X(9)      VALUE SPACES.              
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-COMM-RENEWAL-DATE     PIC X(9)      VALUE SPACES.              
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-ACCT-STAT-DESC        PIC X(8)      VALUE SPACES.              
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-REASON                PIC X         VALUE SPACES.              
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-PAID-AMT              PIC S9(12)V99  VALUE ZEROES              
                                           COMP-3.                              
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-EARN-AMT              PIC S9(12)V99  VALUE ZEROES              
                                           COMP-3.                              
           05  FILLER                  PIC X         VALUE SPACES.              
           05  O-BALANCE               PIC S9(12)V99  VALUE ZEROES              
                                           COMP-3.                              
                                                                                
      *----------------------------------------------------------------         
      *          GNUMTABL PARAMATERS                                  *         
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GNUMTABL ****            '.                                 
       01  WS-GNUMTABL-DATA.                                                    
              10  GNUMTABL-PARAMETER-1.                                         
                  15  GNUMTABL-TABLE-CODE COMP PIC S9(4)                        
                                VALUE +12.                                      
              10  GNUMTABL-PARAMETER-2.                                         
                  15  GNUMTABL-TABLE-ARGUMENT  PIC XX VALUE SPACES.             
              10  GNUMTABL-PARAMETER-3.                                         
                  15  GNUMTABL-RETURN-DATA     PIC X(8) VALUE SPACES.           
                                                                                
      *----------------------------------------------------------------         
      *  ERROR EXTRACT  LAYOUT                                                  
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** ERROR  RECORD ****       '.                                 
       01  ERR-EXTRACT.                                                         
FXXTOK     05  ERR-PROGRAM           PIC X(10)      VALUE 'GC2LTD: '.           
           05  ERR-STATUS            PIC X(4)       VALUE SPACES.               
           05  FILLER                PIC X(5)       VALUE SPACES.               
           05  ERR-PREFIX            PIC X(71)      VALUE SPACES.               
                                                                                
      *----------------------------------------------------------------         
      *          DATASERVER RECORDS                                   *         
      *----------------------------------------------------------------         
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
      * VOCOMM VOPSM/PSM                                                        
       01  LOGICAL-RECORD-NAMES.                                                
           COPY HCSLRNAM.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE -  RECORD DESCRIPTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGROUP                      '.                                  
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
                                                                                
      *----------------------------------------------------------------         
      *  COMMISSIONS GRACCT RECORD                                              
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GWCORGRACCT   ****       '.                                 
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      *----------------------------------------------------------------         
      *  COMMISSIONS COMP RECORD                                                
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GWCORCOMP     ****       '.                                 
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
                                                                                
      *----------------------------------------------------------------         
       01  WS-ENDS.                                                             
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2LTD W-S ENDS HERE   **'.                                  
                                                                                
      ******************************************************************        
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2LTD'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
      *-----------------------------------------------------------------        
       MAINLINE.                                                                
                                                                                
FXXTOK     DISPLAY 'START OF GC2LTD PROGRAM'.                                   
                                                                                
           PERFORM 100-INIT THRU 100-INIT-EXIT.                                 
                                                                                
           IF WS-ERR-SW = 'Y'                                                   
              GO TO 000-PROGRAM-END.                                            
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ NEXT (VCM/GIPSY FILES)                                            
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-READ-NEXT      TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
           PERFORM 200-PROCESS-VCM-GIPSY                                        
              THRU 200-PROCESS-VCM-GIPSY-EXIT                                   
             UNTIL VGWO-RET-CODE NOT = '00'.                                    
                                                                                
      *--------------------------------------------------------------           
      *   END OF PROGRAM LOGIC                                                  
      *--------------------------------------------------------------           
       000-PROGRAM-END.                                                         
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-CLOSE-FILES    TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
                                                                                
           MOVE +1                TO GACCDMA7-PS-FUNC.                          
           CALL 'GACCDMA7'     USING GACCDMA7-PS-PARMS                          
                                     GACCDMA7-PS-RETURN                         
                                     PSMASTE7.                                  
                                                                                
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  OUTPUT-RECORD                                 
                                  ICBM.                                         
                                                                                
FXXTOK     DISPLAY 'END OF GC2LTD PROGRAM'.                                     
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
                                                                                
      ******************************************************************        
       100-INIT.                                                                
                                                                                
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2LTD' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
FXXTOK     MOVE 'GC2LTD'   TO ICBM-PROGRAM-NAME.                                
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-OPEN-FILES     TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
                                                                                
           MOVE OBTAIN-FIRST TO WS-VERB.                                        
           PERFORM 900-GET-DATECARD THRU 900-GET-DATECARD-EXIT                  
                   UNTIL GARDTCRD-IDENTIFIER = 'CURRENT'                        
                      OR WS-ERR-SW = 'Y'.                                       
                                                                                
           IF NOT LR-STATUS-OK                                                  
              AND NOT LR-NOT-FOUND                                              
              DISPLAY 'STATUS: ' ICBM,                                          
                  '    ERROR READING DATECARD = ', GARDTCRD                     
              MOVE 'ERROR READING DATE CARD' TO ERR-PREFIX                      
              MOVE LINKAGE-STATUS TO ERR-STATUS                                 
              PERFORM 990-WRITE-ERROR THRU 990-WRITE-ERROR-EXIT                 
              GO TO 100-INIT-EXIT                                               
           END-IF.                                                              
                                                                                
           IF LR-NOT-FOUND                                                      
              DISPLAY 'DATECARD NOT FOUND'                                      
              MOVE 'DATECARD NOT FOUND' TO ERR-PREFIX                           
              PERFORM 990-WRITE-ERROR THRU 990-WRITE-ERROR-EXIT                 
              GO TO 100-INIT-EXIT                                               
           END-IF.                                                              
                                                                                
      *--------------------------------------------------------                 
      * GET THE ALIS FORMAT OF THE DATE CARD                                    
      *--------------------------------------------------------                 
                                                                                
      *    MOVE GARDTCRD-YYYDDD    TO WS-LAST-DAY-MONTH-ALIS.                   
           MOVE GARDTCRD-JUL-YYY   TO WS-LAST-DAY-MONTH-YYY.                    
           MOVE GARDTCRD-JUL-DDD   TO WS-LAST-DAY-MONTH-DDD.                    
                                                                                
FXXTOK     DISPLAY ' +++ GC2LTD RUN DATE:  ',                                   
                    GARDTCRD-YYYYMMMDD.                                         
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
                                                                                
       100-INIT-EXIT.                                                           
           EXIT.                                                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       200-PROCESS-VCM-GIPSY.                                                   
      *--------------------------------------------------------                 
      * REPORT ON ALL VCM/GIPSY GROUPS                                          
      *--------------------------------------------------------                 
           MOVE GGIGROUP-NUMBER TO GROUP-NUMBER OF GWCORGRACCT.                 
           MOVE GGIACCOUNT      TO GR-ACCOUNT OF GWCORGRACCT.                   
                                                                                
      *--------------------------------------------------------                 
      * GET THE COMMISSION GRACCT RECORD                                        
      *--------------------------------------------------------                 
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      * VOCOMM VCM/GIPSY                                                        
                     GO TO 200-GET-NEXT-VCM-GIPSY.                              
                                                                                
      *--------------------------------------------------------                 
      * GET THE 1ST COMP RECORD AND START PROCESSING                            
      *--------------------------------------------------------                 
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
CM0303                FCCSPL-FETCH-FIRST-LTD                                    
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
CM0303                LAST-RECON-YEAR                                           
CM0303                LAST-RECON-DAY                                            
CM0303                WS-LAST-DAY-MONTH-YYY                                     
CM0303                WS-LAST-DAY-MONTH-DDD                                     
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      * VOCOMM VCM/GIPSY                                                        
                     GO TO 200-GET-NEXT-VCM-GIPSY.                              
                                                                                
           MOVE 'N' TO WS-COMP-DONE.                                            
           PERFORM 300-PROCESS-COMP THRU 300-PROCESS-COMP-EXIT                  
                   UNTIL WS-COMP-DONE = 'Y'.                                    
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       200-GET-NEXT-VCM-GIPSY.                                                  
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       200-PROCESS-VCM-GIPSY-EXIT.                                              
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
      *  READ COMP RECORDS                                                      
      *      SELECT THOSE RECORDS THAT FALL WITHIN THE CURRENT MONTH            
      *-----------------------------------------------------------------        
       300-PROCESS-COMP.                                                        
                                                                                
           IF COMP-EFF-DATE >  LAST-RECON-DATE                                  
            AND COMP-PROCESS-DATE <= WS-LAST-DAY-MONTH-ALIS                     
      *        DISPLAY GGIGROUP-NUMBER ' '                                      
      *                GGIACCOUNT ' '                                           
      *                COMP-EFF-YEAR                                            
      *                COMP-EFF-DAY ' '                                         
      *                LAST-RECON-YEAR                                          
      *                LAST-RECON-DAY ' '                                       
      *                COMP-PROCESS-YEAR                                        
      *                COMP-PROCESS-DAY ' '                                     
      *                WS-LAST-DAY-MONTH-YYY                                    
      *                WS-LAST-DAY-MONTH-DDD                                    
               PERFORM 600-SETUP-RECORD THRU 600-SETUP-RECORD-EXIT.             
                                                                                
       300-GET-NEXT-COMP.                                                       
      *%   OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT-LTD                                     
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
CM0303                LAST-RECON-YEAR                                           
CM0303                LAST-RECON-DAY                                            
CM0303                WS-LAST-DAY-MONTH-YYY                                     
CM0303                WS-LAST-DAY-MONTH-DDD                                     
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                     MOVE 'Y' TO WS-COMP-DONE.                                  
                                                                                
       300-PROCESS-COMP-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       600-SETUP-RECORD.                                                        
      *-----------------------------------------------------------------        
      *  BYPASS DUMMY AGENT RECORDS (099998)                                    
      *-----------------------------------------------------------------        
           IF AGENT-NUMBER = '099998'                                           
              GO TO 600-SETUP-RECORD-EXIT.                                      
                                                                                
      *-----------------------------------------------------------------        
      *  WE'RE ONLY INTERESTED IN COMMISSION RECORDS                            
      *               (NO SALES CREDITS OR NAPS)                                
      *-----------------------------------------------------------------        
           IF COMP-TYPE = 'C'                                                   
              NEXT SENTENCE                                                     
           ELSE                                                                 
              GO TO 600-SETUP-RECORD-EXIT.                                      
                                                                                
      *-----------------------------------------------------------------        
      *  ONLY PROCESS FY OR RN COMMISSIONS                                      
      *-----------------------------------------------------------------        
           IF COMP-REASON = 'F' OR 'R'                                          
              NEXT SENTENCE                                                     
           ELSE                                                                 
              GO TO 600-SETUP-RECORD-EXIT.                                      
                                                                                
      *-----------------------------------------------------------------        
      *  DETERMINE IF THIS A PAID OR EARNED COMMISSION                          
      *-----------------------------------------------------------------        
                                                                                
           IF COMP-DISP = 'P'                                                   
              COMPUTE O-PAID-AMT =  COMP-AMT                                    
           ELSE                                                                 
              IF COMP-DISP = 'E'                                                
                 COMPUTE O-EARN-AMT = COMP-AMT                                  
              END-IF                                                            
           END-IF.                                                              
                                                                                
      *-----------------------------------------------------------------        
      *  POPULATE THE REST OF THE RECORD                                        
      *-----------------------------------------------------------------        
           MOVE AGENT-NUMBER    TO O-AGENT.                                     
           MOVE COMP-REASON     TO O-REASON.                                    
           MOVE GGIGROUP-NUMBER TO O-GROUP.                                     
           MOVE GGIACCOUNT      TO O-ACCOUNT.                                   
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *--------------------------------------------------------                 
      * READ VOPSM/PS MASTER TO GET GIPSY RENEWAL DATE                          
      *--------------------------------------------------------                 
           IF  WS-PSMGROUP-NUMBER NUMERIC                                       
           AND WS-PSMGROUP-NUMBER = GGIGROUP-NUMBER                             
               NEXT SENTENCE                                                    
           ELSE                                                                 
               PERFORM 700-VOPSM-PSMASTER THRU 700-VOPSM-PSMASTER-EXIT          
           END-IF.                                                              
                                                                                
           MOVE '2' TO VDATE-REQ-SERVICE.                                       
           MOVE 'B' TO VDATE-REQ-BASIS.                                         
           MOVE '1' TO VDATE-REQ-DETAIL.                                        
           MOVE 'E' TO VDATE-REQ-LANGUAGE.                                      
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *-----------------------------------------------------------------        
      *  CONVERT RENEWAL DATE TO DISPLAY FORMAT                                 
      *-----------------------------------------------------------------        
           MOVE WS-PSMNXT-RNEW-DATE         TO VDATE-ALIS-DATE1.                
           CALL GC2DATE USING GC2DATE-PARMS.                                    
                                                                                
           IF VDATE-RET-IND NOT = +0                                            
              DISPLAY 'INVALID RNEW DATE, RETURN CODE: '                        
                          VDATE-RET-CODE                                        
           ELSE                                                                 
              MOVE VDATE-EXT-DATE TO O-GIPSY-RENEWAL-DATE                       
           END-IF.                                                              
                                                                                
      *-----------------------------------------------------------------        
      *  CONVERT NEXT RECONCILIATION DATE TO DISPLAY FORMAT                     
      *-----------------------------------------------------------------        
           MOVE NEXT-RECON-DATE          TO VDATE-ALIS-DATE1.                   
           CALL GC2DATE USING GC2DATE-PARMS.                                    
                                                                                
           IF VDATE-RET-IND NOT = +0                                            
              DISPLAY 'INVALID RECON DATE, RETURN CODE: '                       
                          VDATE-RET-CODE                                        
           ELSE                                                                 
              MOVE VDATE-EXT-DATE TO O-RECON-DATE                               
           END-IF.                                                              
                                                                                
      *-----------------------------------------------------------------        
      *  CONVERT COMMISSION RENEWAL DATE TO DISPLAY FORMAT                      
      *-----------------------------------------------------------------        
           MOVE RENEWAL-EFFECTIVE-DATE   TO VDATE-ALIS-DATE1.                   
           CALL GC2DATE USING GC2DATE-PARMS.                                    
                                                                                
           IF VDATE-RET-IND NOT = +0                                            
              DISPLAY 'INVALID RECON DATE, RETURN CODE: '                       
                          VDATE-RET-CODE                                        
           ELSE                                                                 
              MOVE VDATE-EXT-DATE TO O-COMM-RENEWAL-DATE                        
           END-IF.                                                              
                                                                                
      *-----------------------------------------------------------------        
      *  CONVERT ACCOUNT STATUS TO DISPLAY FORMAT                               
      *-----------------------------------------------------------------        
           MOVE GGIACCOUNT-STATUS                                               
                          TO GNUMTABL-TABLE-ARGUMENT.                           
           CALL 'GNUMTABL' USING GNUMTABL-PARAMETER-1                           
                                 GNUMTABL-PARAMETER-2                           
                                 GNUMTABL-PARAMETER-3.                          
           MOVE GNUMTABL-RETURN-DATA                                            
                          TO O-ACCT-STAT-DESC.                                  
                                                                                
           COMPUTE O-BALANCE = O-PAID-AMT  - O-EARN-AMT.                        
                                                                                
      *-----------------------------------------------------------------        
           PERFORM 900-WRITE-RECORD THRU 900-WRITE-RECORD-EXIT.                 
                                                                                
       600-SETUP-RECORD-EXIT.                                                   
           EXIT.                                                                
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *-----------------------------------------------------------------        
      *  NEXT RENEWAL DATE IS ON VOPSM/PS MASTER.  1 PS MASTER PER GROUP        
      *  SO CHECK TO SEE IF WE HAVE CHANGED GROUP NUMBERS.                      
      *  IF SO, CALL TO READ VOPSM/PSMASTER                                     
      *-----------------------------------------------------------------        
       700-VOPSM-PSMASTER.                                                      
                                                                                
           IF  WS-PSMGROUP-NUMBER NUMERIC                                       
           AND WS-PSMGROUP-NUMBER = GGIGROUP-NUMBER                             
               NEXT SENTENCE                                                    
           ELSE                                                                 
               PERFORM 850-READ-VOPSM-PSMASTER                                  
                       THRU 850-READ-VOPSM-PSMASTER-EXIT                        
           END-IF.                                                              
                                                                                
       700-VOPSM-PSMASTER-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
      * VOCOMM VCM/GIPSY                                                        
       800-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       800-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------------------------         
       850-READ-VOPSM-PSMASTER.                                                 
                                                                                
           MOVE LOW-VALUES       TO WS-PSMASTER.                                
                                                                                
           MOVE LOW-VALUES       TO VOPSMASTER-RECORD.                          
           MOVE GGIGROUP-NUMBER  TO VOPSM-GROUP-NUMBER.                         
           MOVE LR-VO-PSMASTER-R TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING OBTAIN-KEYED                                
                                    VOPSMASTER-RECORD                           
                                    ICBM.                                       
           IF LR-STATUS-OK                                                      
                                                                                
              MOVE VOPSM-GROUP-NUMBER   TO WS-PSMGROUP-NUMBER                   
                                                                                
              MOVE 'B' TO VDATE-REQ-SERVICE                                     
              MOVE 'B' TO VDATE-REQ-BASIS                                       
              MOVE '1' TO VDATE-REQ-DETAIL                                      
              MOVE 'E' TO VDATE-REQ-LANGUAGE                                    
              MOVE VOPSM-NXT-RNEW-YEAR  TO VDATE1-YYYY                          
              MOVE VOPSM-NXT-RNEW-MONTH TO VDATE1-MM                            
              MOVE VOPSM-NXT-RNEW-DAY   TO VDATE1-DD                            
              CALL GC2DATE USING GC2DATE-PARMS                                  
              IF VDATE-RET-IND NOT = +0                                         
                 MOVE 0                 TO WS-PSMNXT-RNEW-YR                    
                                           WS-PSMNXT-RNEW-DAY                   
              ELSE                                                              
                                                                                
                 MOVE VDATE-ALIS-YEAR1     TO WS-PSMNXT-RNEW-YR                 
                 MOVE VDATE-ALIS-DAY1      TO WS-PSMNXT-RNEW-DAY                
              END-IF                                                            
                                                                                
           ELSE                                                                 
                                                                                
FXXTOK        MOVE LOW-VALUES        TO PSMASTE7                                
              MOVE GGIGROUP-NUMBER   TO GACCDMA7-PS-GROUP                       
              MOVE HIGH-VALUES       TO GACCDMA7-PS-ACCT                        
              CALL 'GACCDMA7'     USING GACCDMA7-PS-PARMS                       
                                        GACCDMA7-PS-RETURN                      
FXXTOK                                  PSMASTE7                                
              IF GACCDMA7-PS-RET-OK                                             
                 MOVE PSMGROUP-NUMBER      TO WS-PSMGROUP-NUMBER                
                 MOVE PSMNXT-RNEW-YR       TO WS-PSMNXT-RNEW-YR                 
                 MOVE PSMNXT-RNEW-DAY      TO WS-PSMNXT-RNEW-DAY                
              ELSE                                                              
                 MOVE 0                    TO WS-PSMGROUP-NUMBER                
                                              WS-PSMNXT-RNEW-YR                 
                                              WS-PSMNXT-RNEW-DAY                
              END-IF                                                            
           END-IF.                                                              
                                                                                
       850-READ-VOPSM-PSMASTER-EXIT.                                            
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       900-GET-DATECARD.                                                        
           MOVE 'CARD-DATA-010'      TO LOGICAL-RECORD-NAME.                    
                                                                                
           CALL GAEDATSR  USING WS-VERB                                         
                                GARDTCRD                                        
                                ICBM.                                           
                                                                                
           MOVE OBTAIN-NEXT TO WS-VERB.                                         
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-ERR-SW.                                            
                                                                                
       900-GET-DATECARD-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       900-WRITE-RECORD.                                                        
                                                                                
      *    DISPLAY 'WRITING RECORD: ' OUTPUT-RECORD.                            
                                                                                
           MOVE 'PRINT-DATA-020' TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR          USING  STORE-LR                               
                                         OUTPUT-RECORD                          
                                         ICBM.                                  
                                                                                
            IF NOT LR-STATUS-OK                                                 
               DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                       
            END-IF.                                                             
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
                                                                                
       900-WRITE-RECORD-EXIT.                                                   
           EXIT.                                                                
      *---------------------------------------------------------                
       990-WRITE-ERROR.                                                         
                                                                                
           MOVE 'PRINT-DATA-021' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR USING STORE-LR                                         
                               ERR-EXTRACT                                      
                               ICBM.                                            
                                                                                
       990-WRITE-ERROR-EXIT.                                                    
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          END OF SOURCE                                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
