                                                                                
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VOREX.                                                 
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  OCTOBER 2005.                                             
      *DATE-COMPILED.                                                           
      *****************************************************************         
      *                                                                         
      *   COMMISSIONS SYSTEM                                                    
      *   HUB VO COMMISSIONS PROJECT                                            
      *                                                                         
      *   HUB:  VO COMMISSION EXTRACT OF RENEWAL PREMIUMS                       
      *         (VOCOMM RENEWAL ADVANCE PROCESS)                                
      *                                                                         
      *   THIS PROGRAM CREATES AN EXTRACT FILE OF VO RENEWAL                    
      *   PREMIUMS WHICH WILL BE USED IN UPDATING THE COMMISSION                
      *   DATABASE.                                                             
      *                                                                         
      *   CALLING PROGRAM:  NONE                                                
      *                                                                         
      *   CALLED PROGRAMS:  GAEDATSR                                            
      *                     GC2DATE                                             
      *                                                                         
      *   COPYBOOKS:                                                            
      *       GARDTCRD                                                          
      *       VOPSMAST                                                          
      *       VMASTER                                                           
      *       GCOMGRE7 (FOR VORENEXT FILE)                                      
      *       GARDSVRB                                                          
      *       HCSLRNAM                                                          
      *       ICBM                                                              
      *       GARDATEP                                                          
      *                                                                         
      *   INPUT  - DATEFILE                        (GARDTCRD)                   
      *            VO PSMASTER FILE                (VOPSMAST)                   
      *            VO CONTRACT MASTER FILE         (VMASTER)                    
      *                                                                         
      *   OUTPUT - VO RENEWAL PREMIUM EXTRACT FILE (VORENEXT)                   
      *            (LAYOUT IS GCOMGRE7)                                         
      *                                                                         
      *   DESCRIPTION:                                                          
      *     READ THE DATEFILE FILE - PGW.PROD.DATEFILE(0) TO GET                
      *        THE CURRENT PROCESSING DATE.  CREATE AN EXTRACT                  
      *        HEADER RECORD CONTAINING THIS DATE.                              
      *     READ ALL OF THE VO PSMASTER RECORDS UNTIL END-OF-FILE.              
      *        SELECT ONLY VO PSMASTER RECORDS WHICH HAVE POLICY                
      *        YEAR > 1.                                                        
      *     FOR THE SELECTED VO PSMASTER RECORDS, GET ALL THE                   
      *        ACCOUNTS THAT BELONG TO IT BY READING THE VO                     
      *        CONTRACT MASTER FILE.                                            
      *     FOR EACH OF THE VO CONTRACT MASTER ACCOUNTS READ,                   
      *        SELECT ONLY THE INFORCE ACCOUNTS (VGI-ACCOUNT-                   
      *        STATUS '00', '01', '02', OR '03').                               
      *     FOR EACH OF THE INFORCE ACCOUNTS, COMPARE ITS                       
      *        LATEST VBI-HIST-DUE-DATE(X) WITH THE VO PSMASTER                 
      *        NEXT RENEWAL DATE.  SELECT THE ACCOUNTS WHICH                    
      *        HAVE VBI-HIST-DUE-DATE(X) MONTH THE SAME AS THE                  
      *        VOPSM-NXT-RNEW-MONTH AND VBI-HIST-DUE-DATE(X)                    
      *        YEAR IS 1 LESS THAN THE VOPSM-NXT-RNEW-YEAR                      
      *        AND ITS VGI-ACCT-EFFECTIVE IS LESS THAN THE                      
      *        LATEST VBI-HIST-DUE-DATE(X).                                     
      *     FOR EACH OF THE SELECTED ACCOUNTS, CHECK ITS                        
      *        COMM-PROC-DT.  IF IT IS AT LEAST 3 MONTHS IN THE                 
      *        PAST OR IT IS LOW-VALUES/SPACES, CREATE AN EXTRACT               
      *        RENEWAL PREMIUM RECORD FOR THIS ACCOUNT.                         
      *        THE RENEWAL EFFFECTIVE DATE ON THIS EXTRACT                      
      *        RENEWAL PREMIUM RECORD SHOULD BE 1 YEAR LESS                     
      *        THAN THE VOPSM-NXT-RNEW-DATE.                                    
      *        UPDATE ITS COMM-PROC-DT TO THE CURRENT PROCESS DATE.             
      *     NOTE: CHANGE ALL LEAP DATES FEB 29 TO FEB 28.                       
      *                                                                         
      ******************************************************************        
      *    MMM/CCYY   -    NAME            -   DESCRIPTION                      
      *    OCT 2005        REGINA KNAUD        INITIAL CREATION.                
      *                                                                         
      *    SEP 2006        REGINA KNAUD        SET GCEX-NEXT-ANNIV-YEAR         
      *                                        TO GCEX-REN-EFF-YEAR.            
      *                                        SET GCEX-NEXT-ANNIV-DAY          
      *                                        TO GCEX-REN-EFF-DAY.             
      *                                                                         
      *    OCT 2008        IBM                 COMPILER UPGRADE.                
      *                                                                         
      *    SEP 2011        DARRYL JOBES /      SET GCEX-GROUP-NUMBER TO         
      *                    SHANNON CARLYLE     WS-GROUP-NUMBER PIC 9(7)         
      *                                        AND REMOVED THE                  
      *                                        PIC 99/PIC 9(5) REDEFINES        
      *                                        FROM WS-GROUP-NUMBER             
      *                                                                         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVOREX           
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                            00360000
       CONFIGURATION SECTION.                                           00370000
       SOURCE-COMPUTER. IBM-370-165.                                    00380000
       OBJECT-COMPUTER. IBM-370-165.                                    00390000
                                                                        00400000
       INPUT-OUTPUT SECTION.                                            00410000
                                                                        00420000
       FILE-CONTROL.                                                    00430000
                                                                        00440000
       DATA DIVISION.                                                   00450000
                                                                        00460000
       FILE SECTION.                                                    00470000
                                                                        00480000
       WORKING-STORAGE SECTION.                                         00490000
                                                                        00500000
       01  WS-VARIABLES.                                                00510000
           05  FILLER                      PIC X(32) VALUE              00520000
FXXTOK         '*** GC2VOREX WORKING STORAGE ***'.                              
           05  WS-GARDTCRD-EOF             PIC X.                               
           05  WS-VOPSMAST-EOF             PIC X.                               
           05  WS-VMASTER-EOF              PIC X.                               
           05  WS-GARDTCRD-DATE.                                                
               10  WS-GARDTCRD-YEAR        PIC 9(4).                            
               10  WS-GARDTCRD-MONTH       PIC 99.                              
               10  WS-GARDTCRD-DAY         PIC 99.                              
           05  WS-VOPSM-NXT-RNEW-DATE.                                          
               10  WS-VOPSM-NXT-RNEW-YEAR  PIC 9(4).                            
               10  WS-VOPSM-NXT-RNEW-MONTH PIC 99.                              
               10  WS-VOPSM-NXT-RNEW-DAY   PIC 99.                              
           05  WS-VGI-ACCT-EFFECTIVE.                                           
               10  WS-VGI-ACCT-EFF-YEAR    PIC 9(4).                            
               10  WS-VGI-ACCT-EFF-MONTH   PIC 99.                              
               10  WS-VGI-ACCT-EFF-DAY     PIC 99.                              
           05  WS-VBI-HIST-DUE-DATE.                                            
               10  WS-VBI-HIST-DUE-YEAR    PIC 9(4).                            
               10  WS-VBI-HIST-DUE-MONTH   PIC 99.                              
               10  WS-VBI-HIST-DUE-DAY     PIC 99.                              
           05  WS-PAST-3MONTHS-DATE.                                            
               10  WS-PAST-3MONTHS-YEAR    PIC 9(4).                            
               10  WS-PAST-3MONTHS-MONTH   PIC 99.                              
               10  WS-PAST-3MONTHS-DAY     PIC 99.                              
           05  WS-VOPSM-YEAR-LESS-1        PIC 9(4).                            
           05  WS-GCEX-RENEWAL-DATE.                                            
               10  WS-GCEX-RENEWAL-YEAR    PIC 9(4).                            
               10  WS-GCEX-RENEWAL-MONTH   PIC 99.                              
               10  WS-GCEX-RENEWAL-DAY     PIC 99.                              
           05  WS-VGI-NEXT-ANNIVERSARY.                                         
               10  WS-VGI-NEXT-ANNIV-YEAR  PIC 9(4).                            
               10  WS-VGI-NEXT-ANNIV-MONTH PIC 99.                              
               10  WS-VGI-NEXT-ANNIV-DAY   PIC 99.                              
           05  WS-CCYYMMDD-DATE.                                                
               10  WS-CCYY                 PIC 9(4).                            
               10  WS-MM                   PIC 99.                              
               10  WS-DD                   PIC 99.                              
           05  WS-GCEX-RENEW-EFF-DATE.                                          
               10  WS-GCEX-REN-EFF-YEAR    PIC S9(3) COMP-3.                    
               10  WS-GCEX-REN-EFF-DAY     PIC S9(3) COMP-3.                    
           05  WS-SUB1                     PIC 99.                              
           05  WS-GROUP-NUMBER             PIC 9(7).                            
                                                                                
      *----------------------------------------------------------------*00794602
      *    DATEFILE RECORD - GARDTCRD                                   00794702
      *----------------------------------------------------------------*00795002
       01  GARDTCRD.                                                    00800000
           COPY GARDTCRD.                                                       
                                                                        00810000
      *----------------------------------------------------------------*00794602
      *    VO PSMASTER RECORD - VOPSMAST                                00794702
      *----------------------------------------------------------------*00795002
      *01  VOPSMASTER-RECORD.                                           00800000
           COPY VOPSMAST.                                                       
                                                                        00810000
      *----------------------------------------------------------------*00794602
      *    VO CONTRACT MASTER RECORD - VMASTER                          00794702
      *----------------------------------------------------------------*00795002
      *01  VMASTER.                                                     00800000
           COPY VMASTER.                                                        
                                                                                
       01 VMASTER-RECORD.                                                       
          03  WS-VOM-GAEDATSR-INFO.                                             
            05  WS-VOM-LENGTH            PIC S9(04) COMP SYNC.                  
            05  WS-VOM-FILLER            PIC X(02) VALUE SPACES.                
          03  WS-VOM-RECORD.                                                    
            05  WS-VOM-POLICY-NUM        PIC S9(7) COMP-3.                      
            05  WS-VOM-CLASS-NUM         PIC X(05).                             
            05  WS-VOM-REST              PIC X(11391).                          
                                                                                
      *----------------------------------------------------------------*00794602
      *    VO RENEWAL PREMIUM EXTRACT - VORENEXT (GCOMGRE7 LAYOUT)      00794702
      *----------------------------------------------------------------*00795002
      *01  GCOMGRE7.                                                    00800000
           COPY GCOMGRE7.                                                       
                                                                        00810000
      *----------------------------------------------------------------*00794602
      *    DATA SERVER ACTION VERBS                                     00794702
      *----------------------------------------------------------------*00795002
       01  GAEDATSR-PARMS.                                              00800000
                                      COPY GARDSVRB.                    00800000
                                                                        00810000
       01  WS-GAEDATSR.                                                 00820000
           05  GAEDATSR               PIC X(8) VALUE 'GAEDATSR'.        00830000
           05  WS-GAEDATSR-VERB       PIC X(16).                        00840000
                                                                        00850000
      *----------------------------------------------------------------*00860000
      *    INTERFACE CONTROL BLOCK                                      00870000
      *----------------------------------------------------------------*00880000
       01  ICBM.                                                        00890000
                                      COPY ICBM.                        00890000
                                                                        00900000
      *----------------------------------------------------------------*00910000
      *    LOGICAL RECORD NAMES                                         00920000
      *----------------------------------------------------------------*00930000
       01  LOGICAL-RECORD-NAMES.                                        00940000
                                      COPY HCSLRNAM.                    00940000
              10  LR-GARDTCRD-IN      PIC X(16) VALUE 'CARD-DATA-010'.  00960002
              10  LR-VORENEXT-OUT     PIC X(16) VALUE 'PRINT-DATA-020'. 00960002
                                                                        00970000
      *------------------------------------------------------------     00980000
      *    DATE CONVERSION PARMS                                        00990000
      *-------------------------------------------------------------    01000000
       01  GC2DATE-PARMS.                                               00970000
           COPY GARDATEP.                                               00970000
                                                                        00970000
       01  GC2DATE                    PIC X(8) VALUE 'GC2DATE'.                 
                                                                                
      *------------------------------------------------------------     00980000
      *    ABEND VARIABLES                                              00990000
      *-------------------------------------------------------------    01000000
       01  WS-USER-ABEND-CODE.                                          01010000
           05  WS-COMP-CODE-X            PIC X(04).                     01020000
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.     01030000
       01  WTL-MESSAGE-PARAMETERS.                                      01040000
           05  WTL-MESSAGES.                                            01050000
               10  WTL-MESS-LENGTH       PIC S9(3) VALUE +133 COMP-3.   01060000
               10  WTL-MESS-CC           PIC X(1)  VALUE SPACES.        01070000
               10  WTL-MESS-TEXT         PIC X(132) VALUE SPACES.       01080000
           05  WTL-FLAG                  PIC X(1)  VALUE 'B'.           01090000
           05  WTL-REPLY                 PIC X(3)  VALUE 'NO '.         01100000
           05  WTL-REPLY-AREA            PIC X(80) VALUE SPACES.        01110000
       01  WTL-MESSAGE-LIST.                                            01120000
           05  WTL-1                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - SEVERE ERROR READING VO PSMASTE7 FILE'.            
           05  WTL-2                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - ERROR REFORMATTING DATE - GC2DATE    '.            
           05  WTL-3                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - ERROR UPDATING VMASTER - MODIFY-LR   '.            
           05  WTL-4                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - CANNOT DETERMINE CURRENT PROCESS DATE'.            
           05  WTL-5                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - ERROR READING VO PSMASTE7 FILE '.                  
           05  WTL-6                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - ERROR READING VMASTER          '.                  
           05  WTL-7                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - ERROR WRITING VORENEXT RECORD  '.                  
           05  WTL-8                     PIC X(80)                      01130000
FXXTOK     VALUE 'GC2VOREX - PROBLEM CLOSING FILES'.                            
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                01210000
           05  WTL-MESSAGE-ENTRY         OCCURS 8 TIMES.                01220000
               10  WTL-MESSAGE           PIC X(80).                     01230000
       01  WTL-SUB                       PIC S9(4) COMP.                01240000
                                                                        01250000
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                              01260000
       0000-MAINLINE.                                                   01270000
                                                                        04750000
           PERFORM 1000-INITIALIZATION      THRU 1000-EXIT.             04760001
           PERFORM 2000-PROCESS-VOPSMAST    THRU 2000-EXIT              04770001
                   UNTIL WS-VOPSMAST-EOF = 'Y'.                         04780001
           PERFORM 9000-FINISH              THRU 9000-EXIT.             04800001
                                                                        04810000
           STOP RUN.                                                    04820000
                                                                        04830000
       0000-EXIT.                                                       04840000
           EXIT.                                                        04850000
                                                                        04860000
      ******************************************************************04870000
      * 1000-INITIALIZATION                                             04880000
      *     INITIALIZE VARIABLES.                                       04890000
      *     READ THE DATEFILE - LR-GARDTCRD-IN.                                 
      *     READ THE FIRST VOPSMAST RECORD.                                     
      ******************************************************************04920000
       1000-INITIALIZATION.                                             04930000
FXXTOK     MOVE 'GC2VOREX'      TO ICBM-PROGRAM-NAME.                           
           MOVE  LOW-VALUES    TO LINKAGE-CONTROL.                              
                                                                        04950000
           MOVE 'N'            TO WS-GARDTCRD-EOF                       04960001
                                  WS-VOPSMAST-EOF.                      04960001
                                                                                
           MOVE SPACES         TO GARDTCRD-IDENTIFIER.                          
           MOVE 0              TO GARDTCRD-Y4                                   
                                  GARDTCRD-M2                                   
                                  GARDTCRD-D2.                                  
           MOVE OBTAIN-FIRST   TO WS-GAEDATSR-VERB.                     06000000
           PERFORM 4000-READ-GARDTCRD THRU 4000-EXIT.                           
           IF WS-GARDTCRD-EOF = 'N'                                             
              MOVE OBTAIN-NEXT TO WS-GAEDATSR-VERB                              
              PERFORM 4000-READ-GARDTCRD THRU 4000-EXIT                         
                UNTIL WS-GARDTCRD-EOF = 'Y'                                     
           END-IF.                                                              
                                                                                
           MOVE LOW-VALUES TO GCOMGRE7.                                         
           MOVE WS-GARDTCRD-YEAR        TO WS-CCYY.                             
           MOVE WS-GARDTCRD-MONTH       TO WS-MM.                               
           MOVE WS-GARDTCRD-DAY         TO WS-DD.                               
           PERFORM 2131-CCYYMMDD-TO-YYYDDD THRU 2131-EXIT.                      
           MOVE VDATE-ALIS-YEAR1       TO GCEX-REN-EFF-YEAR.                    
           MOVE VDATE-ALIS-DAY1        TO GCEX-REN-EFF-DAY.                     
           PERFORM 7000-WRITE-VORENEXT THRU 7000-EXIT.                          
                                                                                
           MOVE OBTAIN-FIRST     TO WS-GAEDATSR-VERB.                           
           PERFORM 5000-READ-VOPSMAST THRU 5000-EXIT.                           
           IF LR-STATUS-OK                                                      
              OR                                                                
              PARTIAL-LR-FOUND                                                  
              OR                                                                
              PARTIAL-LR-FOUND-04                                               
              OR                                                                
              PARTIAL-LR-FOUND-05                                               
              OR                                                                
              PARTIAL-LR-FOUND-06                                               
              IF VOPSM-GROUP-NUMBER > 0                                         
                 MOVE VOPSM-NXT-RNEW-YEAR  TO WS-VOPSM-NXT-RNEW-YEAR            
                 MOVE VOPSM-NXT-RNEW-MONTH TO WS-VOPSM-NXT-RNEW-MONTH           
                 MOVE VOPSM-NXT-RNEW-DAY   TO WS-VOPSM-NXT-RNEW-DAY             
              ELSE                                                              
                MOVE OBTAIN-NEXT TO WS-GAEDATSR-VERB                            
                PERFORM 5000-READ-VOPSMAST THRU 5000-EXIT                       
                IF LR-STATUS-OK                                                 
                   OR                                                           
                   PARTIAL-LR-FOUND                                             
                   OR                                                           
                   PARTIAL-LR-FOUND-04                                          
                   OR                                                           
                   PARTIAL-LR-FOUND-05                                          
                   OR                                                           
                   PARTIAL-LR-FOUND-06                                          
                   MOVE VOPSM-NXT-RNEW-YEAR  TO WS-VOPSM-NXT-RNEW-YEAR          
                   MOVE VOPSM-NXT-RNEW-MONTH TO WS-VOPSM-NXT-RNEW-MONTH         
                   MOVE VOPSM-NXT-RNEW-DAY   TO WS-VOPSM-NXT-RNEW-DAY           
                ELSE                                                            
                   MOVE 'Y' TO WS-VOPSMAST-EOF                                  
                END-IF                                                          
           ELSE                                                                 
              MOVE 'Y' TO WS-VOPSMAST-EOF                                       
           END-IF.                                                              
                                                                                
       1000-EXIT.                                                       04930000
           EXIT.                                                                
                                                                                
      ******************************************************************07450000
      * 2000-PROCESS-VOPSMAST                                           07460000
      * SELECT VO PSMASTER RECORDS WITH POLICY YEAR > 1 AND READ                
      *    THE VO CONTRACT MASTER RECORDS FOR THESE GROUPS.                     
      * READ NEXT VO PSMASTER RECORD.                                           
      ******************************************************************07470000
       2000-PROCESS-VOPSMAST.                                           07480000
           IF VOPSM-POLICY-YEAR > 1                                     08730000
              MOVE 'N' TO WS-VMASTER-EOF                                        
              MOVE VOPSM-GROUP-NUMBER TO WS-VOM-POLICY-NUM                      
              MOVE LOW-VALUES         TO WS-VOM-CLASS-NUM                       
              MOVE OBTAIN-GE          TO WS-GAEDATSR-VERB                       
              PERFORM 6000-READ-VMASTER THRU 6000-EXIT                          
              PERFORM 2100-GET-VCM-ACCOUNTS THRU 2100-EXIT                      
                      UNTIL WS-VMASTER-EOF = 'Y'                                
           END-IF.                                                      08730000
                                                                                
           MOVE OBTAIN-NEXT      TO WS-GAEDATSR-VERB.                           
           PERFORM 5000-READ-VOPSMAST THRU 5000-EXIT.                           
           IF LR-STATUS-OK                                                      
              OR                                                                
              PARTIAL-LR-FOUND                                                  
              OR                                                                
              PARTIAL-LR-FOUND-04                                               
              OR                                                                
              PARTIAL-LR-FOUND-05                                               
              OR                                                                
              PARTIAL-LR-FOUND-06                                               
              MOVE VOPSM-NXT-RNEW-YEAR  TO WS-VOPSM-NXT-RNEW-YEAR               
              MOVE VOPSM-NXT-RNEW-MONTH TO WS-VOPSM-NXT-RNEW-MONTH              
              MOVE VOPSM-NXT-RNEW-DAY   TO WS-VOPSM-NXT-RNEW-DAY                
           END-IF.                                                              
                                                                        08760000
       2000-EXIT.                                                       08770000
           EXIT.                                                        08780000
                                                                        08790000
      ******************************************************************07450000
      * 2100-GET-VCM-ACCOUNTS                                           07460000
      ******************************************************************07470000
       2100-GET-VCM-ACCOUNTS.                                           07480000
           IF VGI-ACCOUNT-STATUS = '00' OR '01' OR '02' OR '03'                 
              PERFORM 2110-LATEST-HIST-DUE-DATE THRU 2110-EXIT                  
              IF WS-VBI-HIST-DUE-DATE > '00000000'                              
                 IF WS-VBI-HIST-DUE-MONTH = WS-VOPSM-NXT-RNEW-MONTH             
                    COMPUTE WS-VOPSM-YEAR-LESS-1 =                              
                            WS-VOPSM-NXT-RNEW-YEAR - 1                          
                    IF WS-VBI-HIST-DUE-YEAR = WS-VOPSM-YEAR-LESS-1              
                       MOVE VGI-ACCT-EFFECTIVE TO WS-VGI-ACCT-EFFECTIVE         
                       IF WS-VGI-ACCT-EFFECTIVE < WS-VBI-HIST-DUE-DATE          
                          PERFORM 2120-PAST-3MONTHS-DATE THRU 2120-EXIT         
                          IF VCS-COMM-PROCESSED-DATE = LOW-VALUES               
                             OR                                                 
                             VCS-COMM-PROCESSED-DATE = SPACES                   
                             OR                                                 
                             VCS-COMM-PROCESSED-DATE <                          
                                WS-PAST-3MONTHS-DATE                            
                             PERFORM 2130-CREATE-EXTRACT-RECORD                 
                                THRU 2130-EXIT                                  
                             PERFORM 3000-UPD-COMM-PROC-DATE                    
                                THRU 3000-EXIT                                  
                          END-IF                                                
                       END-IF                                                   
                    END-IF                                                      
                 END-IF                                                         
              END-IF                                                            
                                                                                
           END-IF.                                                              
                                                                                
           MOVE OBTAIN-NEXT      TO WS-GAEDATSR-VERB.                           
           PERFORM 6000-READ-VMASTER THRU 6000-EXIT.                            
                                                                                
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ****************************************************************          
      * 2110-LATEST-HIST-DUE-DATE                                               
      ****************************************************************          
       2110-LATEST-HIST-DUE-DATE.                                               
           MOVE LOW-VALUES TO WS-VBI-HIST-DUE-DATE.                             
           PERFORM VARYING WS-SUB1 FROM 1 BY 1 UNTIL WS-SUB1 > 25               
              IF VBI-HIST-DUE-DATE (WS-SUB1) > WS-VBI-HIST-DUE-DATE             
                 MOVE VBI-HIST-DUE-DATE (WS-SUB1)                               
                   TO WS-VBI-HIST-DUE-DATE                                      
              END-IF                                                            
           END-PERFORM.                                                         
                                                                                
           IF WS-VBI-HIST-DUE-DATE = SPACES OR LOW-VALUES                       
              MOVE '00000000' TO WS-VBI-HIST-DUE-DATE                           
           END-IF.                                                              
                                                                                
       2110-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ****************************************************************          
      * 2120-PAST-3MONTHS-DATE                                                  
      ****************************************************************          
       2120-PAST-3MONTHS-DATE.                                                  
           MOVE WS-GARDTCRD-DAY    TO WS-PAST-3MONTHS-DAY.                      
           IF WS-GARDTCRD-MONTH < 4                                             
              COMPUTE WS-PAST-3MONTHS-YEAR = WS-GARDTCRD-YEAR - 1               
              IF WS-GARDTCRD-MONTH = 3                                          
                 MOVE 12 TO WS-PAST-3MONTHS-MONTH                               
              ELSE                                                              
                 IF WS-GARDTCRD-MONTH = 2                                       
                    MOVE 11 TO WS-PAST-3MONTHS-MONTH                            
                 ELSE                                                           
                    MOVE 10 TO WS-PAST-3MONTHS-MONTH                            
                 END-IF                                                         
              END-IF                                                            
           ELSE                                                                 
              MOVE WS-GARDTCRD-YEAR   TO WS-PAST-3MONTHS-YEAR                   
              COMPUTE WS-PAST-3MONTHS-MONTH = WS-GARDTCRD-MONTH - 3             
           END-IF.                                                              
                                                                                
       2120-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ****************************************************************          
      * 2130-CREATE-EXTRACT-RECORD                                              
      ****************************************************************          
       2130-CREATE-EXTRACT-RECORD.                                              
      *    INITIALIZE VORENEXT RECORD (GCOMGRE7 LAYOUT).                        
           INITIALIZE GCOMGRE7.                                                 
           MOVE VGI-GROUP-OFFICE       TO GCEX-GFO.                             
           MOVE VGI-POLICY-NUM         TO WS-GROUP-NUMBER.                      
           MOVE WS-GROUP-NUMBER        TO GCEX-GROUP-NUMBER.                    
           MOVE VGI-LOCATION-NUM       TO GCEX-GROUP-ACCOUNT.                   
           MOVE VGI-BRANCH             TO GCEX-BRANCH.                          
                                                                                
           COMPUTE WS-GCEX-RENEWAL-YEAR = WS-VOPSM-NXT-RNEW-YEAR - 1.           
           IF WS-VOPSM-NXT-RNEW-MONTH = 02                                      
              AND                                                               
              WS-VOPSM-NXT-RNEW-DAY   = 29                                      
              MOVE 28 TO WS-VOPSM-NXT-RNEW-DAY                                  
           END-IF.                                                              
           MOVE WS-VOPSM-NXT-RNEW-MONTH TO WS-GCEX-RENEWAL-MONTH.               
           MOVE WS-VOPSM-NXT-RNEW-DAY   TO WS-GCEX-RENEWAL-DAY.                 
           MOVE WS-GCEX-RENEWAL-YEAR    TO WS-CCYY.                             
           MOVE WS-GCEX-RENEWAL-MONTH   TO WS-MM.                               
           MOVE WS-GCEX-RENEWAL-DAY     TO WS-DD.                               
           PERFORM 2131-CCYYMMDD-TO-YYYDDD THRU 2131-EXIT.                      
           MOVE VDATE-ALIS-YEAR1       TO GCEX-REN-EFF-YEAR                     
                                          GCEX-NEXT-ANNIV-YEAR.                 
           MOVE VDATE-ALIS-DAY1        TO GCEX-REN-EFF-DAY                      
                                          GCEX-NEXT-ANNIV-DAY.                  
                                                                                
           MOVE VST-PREM-LIFE          TO GCEX-REN-LIFE-AMT.                    
           MOVE VST-PREM-LTD           TO GCEX-REN-LTD-AMT.                     
           COMPUTE GCEX-REN-A-S-AMT     = VST-PREM-AD-D                         
                                        + VST-PREM-WI                           
                                        + VST-PREM-EHC-SINGLE                   
                                        + VST-PREM-EHC-FAMILY1                  
                                        + VST-PREM-EHC-FAMILY2                  
                                        + VST-PREM-DEN-SINGLE                   
                                        + VST-PREM-DEN-FAMILY1                  
                                        + VST-PREM-DEN-FAMILY2.                 
                                                                                
           IF WS-VGI-ACCT-EFF-MONTH   = 02                                      
              AND                                                               
              WS-VGI-ACCT-EFF-DAY     = 29                                      
              MOVE 28 TO WS-VGI-ACCT-EFF-DAY                                    
           END-IF.                                                              
           MOVE WS-VGI-ACCT-EFF-YEAR    TO WS-CCYY.                             
           MOVE WS-VGI-ACCT-EFF-MONTH   TO WS-MM.                               
           MOVE WS-VGI-ACCT-EFF-DAY     TO WS-DD.                               
           PERFORM 2131-CCYYMMDD-TO-YYYDDD THRU 2131-EXIT.                      
           MOVE VDATE-ALIS-YEAR1       TO GCEX-ACCT-EFF-YEAR.                   
           MOVE VDATE-ALIS-DAY1        TO GCEX-ACCT-EFF-DAY.                    
                                                                                
           PERFORM 7000-WRITE-VORENEXT THRU 7000-EXIT.                          
                                                                                
       2130-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ****************************************************************          
      * 2131-CCYYMMDD-TO-YYYDDD                                                 
      ****************************************************************          
       2131-CCYYMMDD-TO-YYYDDD.                                                 
           MOVE 'B' TO VDATE-REQ-SERVICE.                                       
           MOVE 'B' TO VDATE-REQ-BASIS.                                         
           MOVE '1' TO VDATE-REQ-DETAIL.                                        
           MOVE 'E' TO VDATE-REQ-LANGUAGE.                                      
           MOVE WS-CCYY    TO VDATE1-YYYY.                                      
           MOVE WS-MM      TO VDATE1-MM.                                        
           MOVE WS-DD      TO VDATE1-DD.                                        
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = '0'                                           
              MOVE 'Y' TO WS-VMASTER-EOF                                        
              MOVE 'Y' TO WS-VOPSMAST-EOF                                       
              MOVE +2  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       2131-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ****************************************************************          
      * 3000-UPD-COMM-PROC-DATE                                                 
      ****************************************************************          
       3000-UPD-COMM-PROC-DATE.                                                 
           MOVE WS-GARDTCRD-DATE TO VCS-COMM-PROCESSED-DATE.                    
           MOVE VMASTER          TO WS-VOM-RECORD.                              
                                                                                
           MOVE MODIFY-LR        TO WS-GAEDATSR-VERB.                           
           MOVE VO-CNTRCT-MST    TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING WS-GAEDATSR-VERB                            
                                    VMASTER-RECORD                              
                                    ICBM.                                       
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +3  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       3000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ****************************************************************          
      * 4000-READ-GARDTCRD                                                      
      ****************************************************************          
       4000-READ-GARDTCRD.                                                      
           MOVE LR-GARDTCRD-IN TO LOGICAL-RECORD-NAME.                          
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       GARDTCRD                                 
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF GARDTCRD-IDENTIFIER = 'LEAP-1'                                 
                 MOVE GARDTCRD-Y4 TO WS-GARDTCRD-YEAR                           
                 MOVE GARDTCRD-M2 TO WS-GARDTCRD-MONTH                          
                 MOVE GARDTCRD-D2 TO WS-GARDTCRD-DAY                            
                 MOVE 'Y' TO WS-GARDTCRD-EOF                                    
              END-IF                                                            
           ELSE                                                                 
              MOVE 'Y' TO WS-GARDTCRD-EOF                                       
              MOVE +4  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       4000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ***************************************************************           
      * 5000-READ-VOPSMAST                                                      
      ***************************************************************           
       5000-READ-VOPSMAST.                                                      
           MOVE LR-VO-PSMASTER-R TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING WS-GAEDATSR-VERB                            
                                    VOPSMASTER-RECORD                           
                                    ICBM.                                       
           IF LR-NOT-FOUND                                                      
              MOVE 'Y' TO WS-VOPSMAST-EOF                                       
           ELSE                                                                 
              IF LR-STATUS-OK                                                   
                 OR                                                             
                 PARTIAL-LR-FOUND                                               
                 OR                                                             
                 PARTIAL-LR-FOUND-04                                            
                 OR                                                             
                 PARTIAL-LR-FOUND-05                                            
                 OR                                                             
                 PARTIAL-LR-FOUND-06                                            
                 NEXT SENTENCE                                                  
              ELSE                                                              
                 MOVE 'Y' TO WS-VOPSMAST-EOF                                    
                 MOVE +5  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
              END-IF                                                            
           END-IF.                                                              
                                                                                
       5000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ***************************************************************           
      * 6000-READ-VMASTER                                                       
      ***************************************************************           
       6000-READ-VMASTER.                                                       
           MOVE VO-CNTRCT-MST    TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING WS-GAEDATSR-VERB                            
                                    VMASTER-RECORD                              
                                    ICBM.                                       
           IF LR-NOT-FOUND OR KEYED-LR-NOT-FOUND                                
              MOVE 'Y' TO WS-VMASTER-EOF                                        
           ELSE                                                                 
              IF LR-STATUS-OK                                                   
                 OR                                                             
                 PARTIAL-LR-FOUND                                               
                 OR                                                             
                 PARTIAL-LR-FOUND-04                                            
                 OR                                                             
                 PARTIAL-LR-FOUND-05                                            
                 OR                                                             
                 PARTIAL-LR-FOUND-06                                            
                 MOVE WS-VOM-RECORD TO VMASTER                                  
                 IF VOPSM-GROUP-NUMBER = VGI-POLICY-NUM                         
                    NEXT SENTENCE                                               
                 ELSE                                                           
                    MOVE 'Y' TO WS-VMASTER-EOF                                  
                 END-IF                                                         
              ELSE                                                              
                 MOVE 'Y' TO WS-VMASTER-EOF                                     
                 MOVE +6  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
              END-IF                                                            
           END-IF.                                                              
                                                                                
       6000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      **************************************************************            
      * 7000-WRITE-VORENEXT (LAYOUT IS GCOMGRE7)                                
      **************************************************************            
       7000-WRITE-VORENEXT.                                                     
           MOVE LR-VORENEXT-OUT       TO LOGICAL-RECORD-NAME.                   
           MOVE STORE-LR              TO WS-GAEDATSR-VERB.                      
           CALL GAEDATSR           USING WS-GAEDATSR-VERB                       
                                         GCOMGRE7                               
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +7  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      **********************************************************                
      * 9000-FINISH                                                             
      *     CLOSE THE FILES.                                                    
      **********************************************************                
       9000-FINISH.                                                             
           MOVE SPACES      TO LOGICAL-RECORD-NAME.                             
           MOVE FINISH-LR   TO WS-GAEDATSR-VERB.                                
           CALL GAEDATSR USING WS-GAEDATSR-VERB                                 
                               LOGICAL-RECORD-NAME                              
                               ICBM.                                            
                                                                                
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +8  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       9000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      **********************************************************                
      * 9999-WTL-ABEND                                                          
      **********************************************************                
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL'    USING  WTL-MESSAGES                                    
                                WTL-FLAG                                        
                                WTL-REPLY                                       
                                WTL-REPLY-AREA.                                 
                                                                                
           CALL 'ILBOABN0'  USING  WS-COMP-CODE.                                
                                                                                
       9999-EXIT.                                                               
           EXIT.                                                                
                                                                                
      **********************************************************                
