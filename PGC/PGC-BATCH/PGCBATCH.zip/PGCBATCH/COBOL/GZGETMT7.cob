       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.      GZGETMT7.                                               
                                                                                
      *****************************************************************         
      *                                                               *         
      *  CHANGE LOG:         GZGETMT7                                 *         
      *****************************************************************         
      *                                                               *         
      *  THIS PROGRAM IS A REPLACEMENT FOR THE ASSEMBER PROGRAM       *         
      *  GZGETMT7.                                                    *         
      *                                                               *         
      * THIS PROGRAM WILL TAKE IN A TRAILER ID AS INPUT AND RETURN    *         
      * BACK A SPECIFIC GIPSY MASTER TRAILER RECORD TO THE CALLING    *         
      * PROGRAM.                                                      *         
      *****************************************************************         
                                                                   SKIP1        
       ENVIRONMENT DIVISION.                                                    
                                                                   SKIP1        
       CONFIGURATION SECTION.                                                   
                                                                   EJECT        
       DATA DIVISION.                                                           
                                                                   SKIP1        
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------         
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01   LS-TRAILER-ID     PIC X(03).                                        
       COPY GMASTER7.                                                           
       EJECT                                                                    
       01   LS-TRAILER-REC    PIC X(16280).                                     
       01   LS-ERROR-CD       PIC X(03).                                        
                                                                                
                                                                                
       PROCEDURE DIVISION USING LS-TRAILER-ID                                   
                                GMASTER7                                        
                                LS-TRAILER-REC                                  
                                LS-ERROR-CD.                                    
                                                                                
       A-100-MAINLINE.                                                          
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
                                                                                
      ** INIT THE RETURN AREA                                                   
           PERFORM B-100-INIT-RET-AREA THRU B-100-EXIT.                         
                                                                                
      ** PROCESS THE INPUT AREA                                                 
           PERFORM C-100-PROCESS-REQ   THRU C-100-EXIT.                         
                                                                                
       A-100-EXIT.                                                              
                                                                                
           GOBACK.                                                              
                                                                                
       B-100-INIT-RET-AREA.                                                     
      *****************************************************************         
      *                                                               *         
      *  INIT THE OUTPUT STORAGE AREA                                           
      *                                                               *         
      *****************************************************************         
                                                                                
      *    MOVE  LOW-VALUES                                                     
      *      TO  LS-TRAILER-REC.                                                
           MOVE  SPACES                                                         
             TO  LS-ERROR-CD.                                                   
                                                                                
       B-100-EXIT.                                                              
           EXIT.                                                                
                                                                                
       C-100-PROCESS-REQ.                                                       
      *****************************************************************         
      *                                                                         
      *  PROCESS THE INPUT AREA BASED ON TRAILER-ID VALUE                       
      *                                                                         
      *****************************************************************         
                                                                                
           EVALUATE LS-TRAILER-ID                                               
             WHEN ('000') MOVE GGIGENERAL-INFORMATION                           
                TO LS-TRAILER-REC(1:LENGTH OF GGIGENERAL-INFORMATION)           
             WHEN ('005') MOVE GCOGCOVERAGE-RECORD-PTR                          
                TO LS-TRAILER-REC(1:LENGTH OF GCOGCOVERAGE-RECORD-PTR)          
             WHEN ('010') MOVE GSTSTATISTICS                                    
                TO LS-TRAILER-REC(1:LENGTH OF GSTSTATISTICS)                    
             WHEN ('030') MOVE GBNBILLING-NAME-ADDRESS                          
                TO LS-TRAILER-REC(1:LENGTH OF GBNBILLING-NAME-ADDRESS)          
             WHEN ('040') MOVE GCNCLAIMS-NAME-ADDRESS                           
                TO LS-TRAILER-REC(1:LENGTH OF GCNCLAIMS-NAME-ADDRESS)           
             WHEN ('045') MOVE GONOTHER-NAME-ADDRESS                            
                TO LS-TRAILER-REC(1:LENGTH OF GONOTHER-NAME-ADDRESS)            
             WHEN ('050') MOVE GRIREINSURANCE                                   
                TO LS-TRAILER-REC(1:LENGTH OF GRIREINSURANCE)                   
             WHEN ('080') MOVE GBIBILLING                                       
                TO LS-TRAILER-REC(1:LENGTH OF GBIBILLING)                       
             WHEN ('090') MOVE GPAPAYMENT                                       
                TO LS-TRAILER-REC(1:LENGTH OF GPAPAYMENT)                       
             WHEN ('100') MOVE GPSPREMIUM-SPLIT                                 
                TO LS-TRAILER-REC(1:LENGTH OF GPSPREMIUM-SPLIT)                 
             WHEN ('110') MOVE GAGAGENTS-INFORMATION                            
                TO LS-TRAILER-REC(1:LENGTH OF GAGAGENTS-INFORMATION)            
             WHEN ('120') MOVE GSNSPECIAL-NOTES                                 
                TO LS-TRAILER-REC(1:LENGTH OF GSNSPECIAL-NOTES)                 
             WHEN ('125') MOVE GAMAMENDMENT                                     
                TO LS-TRAILER-REC(1:LENGTH OF GAMAMENDMENT)                     
             WHEN ('130') MOVE GTMTERMINATION                                   
                TO LS-TRAILER-REC(1:LENGTH OF GTMTERMINATION)                   
             WHEN ('140') MOVE GICIDENTIFICATION-CERTIFICATE TO                 
             LS-TRAILER-REC(1:LENGTH OF GICIDENTIFICATION-CERTIFICATE)          
             WHEN ('150') MOVE GTX-TAXES                                        
                TO LS-TRAILER-REC(1:LENGTH OF GTX-TAXES)                        
             WHEN ('160') MOVE GF1FILLER1                                       
                TO LS-TRAILER-REC(1:LENGTH OF GF1FILLER1)                       
             WHEN OTHER                                                         
                   MOVE 'X01' TO LS-ERROR-CD                                    
             END-EVALUATE.                                                      
                                                                                
       C-100-EXIT.                                                              
           EXIT.                                                                
