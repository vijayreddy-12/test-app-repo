       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VODCO.                                                 
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  AUGUST 2005.                                              
      *DATE-COMPILED.                                                           
      *****************************************************************         
      *                                                                         
      *   COMMISSIONS SYSTEM                                                    
      *   HUB VO COMMISSIONS PROJECT                                            
      *                                                                         
      *   HUB:  VO AND MAINFRAME COMMISSIONS FEED MERGE                         
      *         (VOCOMM FEEDS MERGE)                                            
      *                                                                         
      *   THIS PROGRAM READS THE VO COMMISSION EXTRACT FEED                     
      *   (VOCOMEXT) WHICH COMES FROM THE NIGHTLY VO COMMISSIONS                
      *   CALCULATION PROCESS.  THE VO COMMISSION EXTRACT FEED                  
      *   WILL BE REFORMATTED INTO THE VO COMMISSION REFORMATTED                
      *   EXTRACT FILE (VODACOM).                                               
      *                                                                         
      *   CALLING PROGRAM:  NONE                                                
      *                                                                         
      *   CALLED PROGRAMS:  GAEDATSR                                            
      *                     GC2DATE                                             
      *                                                                         
      *   COPYBOOKS:                                                            
      *       VOCOMEXT                                                          
      *       GCOMDATE                                                          
      *       GCOMXTR7                                                          
      *       GPRMXTR7                                                          
      *       GARDSVRB                                                          
      *       HCSLRNAM                                                          
      *       ICBM                                                              
      *       GARDATEP                                                          
      *                                                                         
      *   INPUT  - VO COMMISSION EXTRACT FEED (VOCOMEXT)                        
      *            COMMISSION EXTRACT NEXT VERSION FILE (DACOMNUM)              
      *                                                                         
      *   OUTPUT - VO COMMISSION REFORMATTED EXTRACT FILE (VODACOM)             
      *            COMMISSION EXTRACT NEXT VERSION FILE (DACOMNUM)              
      *                                                                         
      *   DESCRIPTION:                                                          
      *     READ THE DACOMNUM(0) FILE TO GET THE EXPECTED FILE NUMBER.          
      *     READ THE FIRST RECORD FROM THE VOCOMEXT FILE.                       
      *        THE FIRST RECORD HAS RECORD TYPE 'A' AND WILL CONTAIN            
      *        THE FILE NUMBER.                                                 
      *     COMPARE THE FILE NUMBER VALUES FROM THE DACOMNUM(0) AND             
      *        VOCOMEXT FILES.  IF THEY ARE THE SAME, INCREMENT                 
      *        THE FILE NUMBER BY 1 AND CONTINUE PROCESSING THE REST            
      *        OF THE VOCOMEXT RECORDS (RECORD TYPE B - DATE RECORD,            
      *        RECORD TYPE C - COMMISSION RECORD, AND RECORD                    
      *        TYPE P - PREMIUM RECORD). SET THE RETURN CODE TO 0.              
      *        IF THEY ARE NOT THE SAME, DO NOT INCREMENT THE FILE              
      *        NUMBER VALUE AND DO NOT PROCESS THE REST OF THE                  
      *        VOCOMEXT FILE; DO NOT ABEND THIS PROGRAM BUT SET THE             
      *        RETURN CODE TO 4.                                                
      *        WRITE OUT MESSAGES IN THE VOCOMMSG FILE TO INDICATE              
      *        THAT THE OUTPUT VODACOM(+1) FILE FROM THIS PROCESSING            
      *        IS AN EMPTY FILE DUE TO A MISMATCH IN FILE VERSION               
      *        NUMBERS AND THAT THE FILE VERSION NUMBERS SHOULD BE              
      *        INVESTIGATED AND CORRECTED BEFORE THE NEXT CYCLE.                
      *        END THE PROCESSING.                                              
      *     PROCESSING THE SECOND RECORD OF THE VOCOMEXT FILE                   
      *     (RECORD TYPE B):                                                    
      *        REFORMAT THIS DATE AND WRITE IT OUT IN GCOMDATE FORMAT.          
      *     PROCESSING THE REST OF THE THE VOCOMEXT FILE                        
      *     (RECORD TYPES C OR P):                                              
      *        REFORMAT THE 'C' RECORDS AND WRITE THEM OUT IN                   
      *        GCOMXTR7 FORMAT.  REFORMAT THE 'P' RECORDS AND WRITE             
      *        THEM OUT IN GPRMXTR7 FORMAT.                                     
      *     WRITE OUT THE FILE NUMBER IN DACOMNUM(+1) FILE.                     
      *                                                                         
180947*        IF THE INPUT FILE IS EMPTY, DO NOT ABEND THIS PROGRAM.DO         
180947*        NOT INCREMENT THE FILE NUMBER IN DACOMNUM(+1) FILE.CREATE        
180947*        AN EMPTY VODACOM(+1) FILE.                                       
180947*                                                                         
180947*        IF THE INPUT FILE HAS MORE THAN ONE DAY'S RECORD,THE             
180947*        PROGRAM SHOULD NOT ABEND. EACH TIME AN A TYPE RECORD IS          
180947*        FOUND, THE FILE NUMBER WILL BE COMPARED WITH THE FILE            
180947*        NUMBER IN DACOMNUM(0) FILE. IF IT IS A MATCH, IT WILL BE         
180947*        INCREMENTED BY 1 IN DACOMNUM. THE FINAL NUMBER WILL BE           
180947*        WRITTEN TO THE DACOMNUM(+1) FILE FOR NEXT CYCLE'S                
180947*        PROCESSING.                                                      
180947*        ONLY THE LAST B TYPE RECORD WILL BE WRITTEN TO THE OUTPUT        
180947*        VODACOM(+1) FILE.                                                
180947*        ALL OTHER RECORDS WILL BE PROCESSED AND REFORMATTED AS           
180947*        PER THE EXISTING LOGIC ABD WILL BE WRITTEN TO THE                
180947*        VODACOM(+1) FILE.                                                
      ******************************************************************        
      *    MMM/CCYY   -    NAME            -   DESCRIPTION                      
      *    AUG 2005        REGINA KNAUD        INITIAL CREATION.                
      *    OCT 2008        IBM                 COMPILER UPGRADE.                
      *                                                                         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVODACO          
180947* OCT2012 - T180947 - CHANGES FOR COMMISSION SYSTEMS TASK                 
180947* APR2013 - T180947 - CURRENT DATE PGC1100 FEED HEADER                    
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       SOURCE-COMPUTER. IBM-370-165.                                            
       OBJECT-COMPUTER. IBM-370-165.                                            
                                                                                
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-VARIABLES.                                                        
           05  FILLER                      PIC X(32) VALUE                      
FXXTOK         '*** GC2VODCO WORKING STORAGE ***'.                              
           05  WS-VOCOMEXT-EOF             PIC X.                               
           05  WS-AMOUNT-NINE              PIC 9(9).99.                         
           05  WS-AMT-NINE REDEFINES WS-AMOUNT-NINE.                            
               10  WS-AMT-NINE-1           PIC 9(9).                            
               10  WS-AMT-NINE-2           PIC X.                               
               10  WS-AMT-NINE-3           PIC 99.                              
           05  WS-AMOUNT-THREE             PIC 9(3).99.                         
           05  WS-AMT-THREE REDEFINES WS-AMOUNT-THREE.                          
               10  WS-AMT-THREE-1          PIC 9(3).                            
               10  WS-AMT-THREE-2          PIC X.                               
               10  WS-AMT-THREE-3          PIC 99.                              
           05  WS-NINE-AMOUNT              PIC S9(9)V99.                        
           05  WS-THREE-AMOUNT             PIC S9(3)V99.                        
180947*----------------------------------------------------------------*        
180947*    VARIABLE TO CHECK EMPTY VOCOMSRT FILE                                
180947*----------------------------------------------------------------*        
180947     05  WS-VOCOMEXT-EMPTY           PIC X.                               
180947*----------------------------------------------------------------*        
180947*    VARIABLE TO CHECK IF THE FILE NUMBER IN DACOMNUM(0) AND              
180947*    VOCOMSRT FILE ARE SAME OR NOT                                        
180947*----------------------------------------------------------------*        
180947     05  WS-VOCOMEXT-BNUM-MATCH      PIC X.                               
180947*----------------------------------------------------------------*        
180947*    VARIABLE TO CHECK IF THE PREVIOUS REC TYPE IS B OR NOT               
180947*    NO A-TYPE RECORD SHOULD BE PROCESSED IMMEDIATELY AFTER               
180947*    A  B-TYPE RECORD                                                     
180947*----------------------------------------------------------------*        
180947     05  WS-VOCOMEXT-REC-TYPE-B      PIC X.                               
                                                                                
      *01  VO-COMM-EXTRACT.                                                     
           COPY VOCOMEXT.                                                       
                                                                                
      *01  GCOMDATE.                                                            
           COPY GCOMDAT7.                                                       
                                                                                
      *01  GCOMXTR7.                                                            
           COPY GCOMXTR7.                                                       
                                                                                
      *01  GPRMXTR7.                                                            
           COPY GPRMXTR7.                                                       
                                                                                
      *    DACOMNUM(0) FILE                                                     
       01  DACOMNUM-IN-BATCH-NUM.                                               
           05  DACOMNUM-IN-BATCH-NUMBER    PIC 9(9).                            
           05  FILLER                      PIC X(71).                           
                                                                                
      *    DACOMNUM(+1) FILE                                                    
       01  DACOMNUM-OUT-BATCH-NUM.                                              
           05  DACOMNUM-OUT-BATCH-NUMBER   PIC 9(9).                            
           05  FILLER                      PIC X(71) VALUE SPACES.              
                                                                                
180947*----------------------------------------------------------------*        
180947*    VARIABLE TO STORE DACOMNUM(0) FILE NUMBER                            
180947*----------------------------------------------------------------*        
       01  WS-DACOMNUM-FIRST-BNUM.                                              
           05  WS-DACOMNUM-FIRST-BNUMBER   PIC 9(9).                            
           05  FILLER                      PIC X(71) VALUE SPACES.              
                                                                                
       01  VOCOMMSG-RECORDS.                                                    
           05  VOCOMMSG-REC1               PIC X(80) VALUE                      
           'VODACOM FILE FOR TONIGHT IS EMPTY DUE TO A MISMATCH IN'.            
           05  VOCOMMSG-REC2               PIC X(80) VALUE                      
           'FILE VERSION NUMBERS.  THIS SHOULD BE INVESTIGATED AND'.            
           05  VOCOMMSG-REC3               PIC X(80) VALUE                      
           'CORRECTED BEFORE THE NEXT CYCLE.                      '.            
                                                                                
      *----------------------------------------------------------------*        
      *    DATA SERVER ACTION VERBS                                             
      *----------------------------------------------------------------*        
       01  GAEDATSR-PARMS.                                                      
                                      COPY GARDSVRB.                            
                                                                                
       01  WS-GAEDATSR.                                                         
           05  GAEDATSR               PIC X(8) VALUE 'GAEDATSR'.                
           05  WS-GAEDATSR-VERB       PIC X(16).                                
                                                                                
      *----------------------------------------------------------------*        
      *    INTERFACE CONTROL BLOCK                                              
      *----------------------------------------------------------------*        
       01  ICBM.                                                                
                                      COPY ICBM.                                
                                                                                
      *----------------------------------------------------------------*        
      *    LOGICAL RECORD NAMES                                                 
      *----------------------------------------------------------------*        
       01  LOGICAL-RECORD-NAMES.                                                
                                      COPY HCSLRNAM.                            
              10  LR-VOCOMEXT-IN      PIC X(16) VALUE 'CARD-DATA-010'.          
              10  LR-IN-BATCH-NUM     PIC X(16) VALUE 'CARD-DATA-011'.          
              10  LR-VODACOM-OUT      PIC X(16) VALUE 'PRINT-DATA-020'.         
              10  LR-OUT-BATCH-NUM    PIC X(16) VALUE 'PRINT-DATA-021'.         
              10  LR-VOCOMMSG-OUT     PIC X(16) VALUE 'PRINT-DATA-022'.         
                                                                                
      *------------------------------------------------------------             
      *    DATE CONVERSION PARMS                                                
      *------------------------------------------------------------             
       01  GC2DATE-PARMS.                                                       
           COPY GARDATEP.                                                       
                                                                                
       01  GC2DATE                    PIC X(8) VALUE 'GC2DATE'.                 
                                                                                
      *------------------------------------------------------------             
      *    ABEND VARIABLES                                                      
      *------------------------------------------------------------             
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X            PIC X(04).                             
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH       PIC S9(3) VALUE +133 COMP-3.           
               10  WTL-MESS-CC           PIC X(1)  VALUE SPACES.                
               10  WTL-MESS-TEXT         PIC X(132) VALUE SPACES.               
           05  WTL-FLAG                  PIC X(1)  VALUE 'B'.                   
           05  WTL-REPLY                 PIC X(3)  VALUE 'NO '.                 
           05  WTL-REPLY-AREA            PIC X(80) VALUE SPACES.                
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - VOCOMEXT MISSING THE FILE# (RECTYPE A)'.           
           05  WTL-2                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM INITIAL READ VOCOMEXT FILE'.               
           05  WTL-3                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM READING DACOMNUM(0) FILE'.                 
           05  WTL-4                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - VOCOMEXT MISSING THE DATE (RECTYPE B)'.            
           05  WTL-5                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM SECOND READ VOCOMEXT FILE'.                
           05  WTL-6                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - VOCOMEXT CONTAINS INVALID RECORD TYPE'.            
           05  WTL-7                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM READING VOCOMEXT FILE'.                    
           05  WTL-8                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM WRITING VODACOM - GCOMDATE'.               
           05  WTL-9                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM WRITING VODACOM - GCOMXTR7'.               
           05  WTL-10                    PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM WRITING VODACOM - GPRMXTR7'.               
           05  WTL-11                    PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM WRITING DACOMNUM(+1) FILE'.                
           05  WTL-12                    PIC X(80)                              
FXXTOK     VALUE 'GC2VODCO - PROBLEM CLOSING FILES'.                            
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY         OCCURS 12 TIMES.                       
               10  WTL-MESSAGE           PIC X(80).                             
       01  WTL-SUB                       PIC S9(4) COMP.                        
                                                                                
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
       0000-MAINLINE.                                                           
                                                                                
           PERFORM 1000-INITIALIZATION      THRU 1000-EXIT.                     
           PERFORM 2000-PROCESS-VOCOMEXT    THRU 2000-EXIT                      
                   UNTIL WS-VOCOMEXT-EOF = 'Y'.                                 
180947     IF WS-VOCOMEXT-EMPTY = 'N' AND WS-VOCOMEXT-BNUM-MATCH = 'Y'          
180947        PERFORM 4000-WRITE-GCOMDATE  THRU 4000-EXIT                       
180947     END-IF.                                                              
           PERFORM 7000-WRITE-OUT-BATCH-NUM THRU 7000-EXIT.                     
           PERFORM 9000-FINISH              THRU 9000-EXIT.                     
                                                                                
           STOP RUN.                                                            
                                                                                
       0000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 1000-INITIALIZATION                                                     
      *     INITIALIZE VARIABLES.                                               
      *     READ THE FIRST INPUT VOCOMEXT RECORD (FIRST RECORD SHOULD           
      *          HAVE RECORD TYPE 'A' - CONTAINS THE FILE NUMBER).              
180947*     IF THE FILE IS EMPTY SET 'Y' TO WS-VOCOMEXT-EMPTY                   
      ******************************************************************        
       1000-INITIALIZATION.                                                     
FXXTOK     MOVE 'GC2VODCO'          TO ICBM-PROGRAM-NAME.                       
           MOVE  LOW-VALUES         TO LINKAGE-CONTROL.                         
                                                                                
           MOVE 'N'                 TO WS-VOCOMEXT-EOF.                         
180947     MOVE 'N'                 TO WS-VOCOMEXT-EMPTY.                       
180947     MOVE 'Y'                 TO WS-VOCOMEXT-BNUM-MATCH.                  
180947     MOVE 'N'                 TO WS-VOCOMEXT-REC-TYPE-B                   
                                                                                
           MOVE LR-VOCOMEXT-IN      TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-FIRST        TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       VO-COMM-EXTRACT                          
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF VOCOMX-REC-TYPE = 'A'                                          
                 PERFORM 1010-CHECK-IN-BATCH-NUM THRU 1010-EXIT                 
              ELSE                                                              
                 MOVE +1  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND THRU 9999-EXIT                          
           ELSE                                                                 
180947        IF LR-NOT-FOUND                                                   
180947           MOVE 'Y'                    TO WS-VOCOMEXT-EMPTY               
180947           PERFORM 1010-CHECK-IN-BATCH-NUM THRU 1010-EXIT                 
180947        ELSE                                                              
                 MOVE +2  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
180947        END-IF                                                            
           END-IF.                                                              
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 1010-CHECK-IN-BATCH-NUM                                                 
      *     READ THE DACOMNUM FILE.                                             
      *     CHECK THE FILE NUMBER FROM THE DACOMNUM AND VOCOMEXT FILES.         
      *     IF THE FILE NUMBERS ARE THE SAME, INCREMENT THE DACOMNUM            
      *        FILE NUMBER BY 1 (FOR THE NEXT CYCLE'S PROCESSING) AND           
      *        PROCESS TILL THE END OF THE VOCOMEXT FILE.                       
      *     IF THE FILE NUMBERS ARE NOT THE SAME, DO NOT INCREMENT              
      *        THE DACOMNUM FILE NUMBER AND DO NOT PROCESS THE REST             
      *        OF THE VOCOMEXT FILE.                                            
      ******************************************************************        
       1010-CHECK-IN-BATCH-NUM.                                                 
           MOVE LR-IN-BATCH-NUM     TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-FIRST        TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       DACOMNUM-IN-BATCH-NUM                    
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF DACOMNUM-IN-BATCH-NUMBER = VOCOMX-FILE-NUMBER                  
                  COMPUTE DACOMNUM-OUT-BATCH-NUMBER =                           
                          DACOMNUM-IN-BATCH-NUMBER  + 1                         
180947            MOVE DACOMNUM-IN-BATCH-NUMBER TO                              
180947                 WS-DACOMNUM-FIRST-BNUMBER                                
                  PERFORM 1020-PROCESS-DATE-RECORD THRU 1020-EXIT               
                  MOVE +00 TO RETURN-CODE                                       
              ELSE                                                              
                  COMPUTE DACOMNUM-OUT-BATCH-NUMBER =                           
                          DACOMNUM-IN-BATCH-NUMBER  + 0                         
                  MOVE LR-VOCOMMSG-OUT    TO LOGICAL-RECORD-NAME                
                  MOVE STORE-LR           TO WS-GAEDATSR-VERB                   
                  CALL GAEDATSR        USING WS-GAEDATSR-VERB                   
                                             VOCOMMSG-REC1                      
                                             ICBM                               
                  CALL GAEDATSR        USING WS-GAEDATSR-VERB                   
                                             VOCOMMSG-REC2                      
                                             ICBM                               
                  CALL GAEDATSR        USING WS-GAEDATSR-VERB                   
                                             VOCOMMSG-REC3                      
                                             ICBM                               
                  MOVE 'Y'                TO WS-VOCOMEXT-EOF                    
180947            MOVE 'N'                TO WS-VOCOMEXT-BNUM-MATCH             
                  MOVE +04 TO RETURN-CODE                                       
              END-IF                                                            
           ELSE                                                                 
              MOVE +3  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND THRU 9999-EXIT                             
           END-IF.                                                              
                                                                                
       1010-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 1020-PROCESS-DATE-RECORD                                                
      ******************************************************************        
       1020-PROCESS-DATE-RECORD.                                                
           MOVE LR-VOCOMEXT-IN      TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-NEXT         TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       VO-COMM-EXTRACT                          
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF VOCOMX-REC-TYPE = 'B'                                          
180947           MOVE 'Y' TO WS-VOCOMEXT-REC-TYPE-B                             
                 MOVE 'B' TO VDATE-REQ-SERVICE                                  
                 MOVE 'B' TO VDATE-REQ-BASIS                                    
                 MOVE '1' TO VDATE-REQ-DETAIL                                   
                 MOVE 'E' TO VDATE-REQ-LANGUAGE                                 
                 MOVE VOCOMX-FILE-YYYY     TO VDATE1-YYYY                       
                 MOVE VOCOMX-FILE-MM       TO VDATE1-MM                         
                 IF VOCOMX-FILE-MM = 02                                         
                    AND                                                         
                    VOCOMX-FILE-DD = 29                                         
                    MOVE 28 TO VOCOMX-FILE-DD                                   
                 END-IF                                                         
                 MOVE VOCOMX-FILE-DD       TO VDATE1-DD                         
                 CALL GC2DATE USING GC2DATE-PARMS                               
                 IF VDATE-RET-IND NOT = +0                                      
                    MOVE 0                 TO GDAT-RUN-YEAR                     
                                              GDAT-RUN-DAY                      
                 ELSE                                                           
                    MOVE VDATE-ALIS-YEAR1     TO GDAT-RUN-YEAR                  
                    MOVE VDATE-ALIS-DAY1      TO GDAT-RUN-DAY                   
                 END-IF                                                         
      *                                                                         
      * CHECK FILE HEADER DATE IS NOT LESS THAN CURRENT DATE                    
      * IF IT IS SET FILE HEADER DATE TO THE CURRENT DATE                       
      *                                                                         
                 MOVE 'E' TO VDATE-REQ-SERVICE                                  
                 MOVE 'B' TO VDATE-REQ-BASIS                                    
                 MOVE '1' TO VDATE-REQ-DETAIL                                   
                 MOVE 'E' TO VDATE-REQ-LANGUAGE                                 
                 CALL GC2DATE USING GC2DATE-PARMS                               
                 IF VDATE-RET-IND = +0                                          
                    IF GDAT-RUN-DATE < VDATE-ALIS-DATE1                         
                       MOVE VDATE-ALIS-YEAR1     TO GDAT-RUN-YEAR               
                       MOVE VDATE-ALIS-DAY1      TO GDAT-RUN-DAY                
                    END-IF                                                      
                 END-IF                                                         
180947*          PERFORM 4000-WRITE-GCOMDATE THRU 4000-EXIT                     
              ELSE                                                              
                 MOVE +4  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND THRU 9999-EXIT                          
           ELSE                                                                 
              MOVE +5  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       1020-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2000-PROCESS-VOCOMEXT                                                   
      ******************************************************************        
       2000-PROCESS-VOCOMEXT.                                                   
                                                                                
           MOVE LR-VOCOMEXT-IN      TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-NEXT         TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       VO-COMM-EXTRACT                          
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF VOCOMX-REC-TYPE = 'C'                                          
                 PERFORM 2100-REFORMAT-REC-TYPE-C THRU 2100-EXIT                
                 PERFORM 5000-WRITE-GCOMXTR7 THRU 5000-EXIT                     
180947           IF WS-VOCOMEXT-REC-TYPE-B = 'Y'                                
180947              MOVE 'N'        TO WS-VOCOMEXT-REC-TYPE-B                   
180947           END-IF                                                         
              ELSE                                                              
                 IF VOCOMX-REC-TYPE = 'P'                                       
                    PERFORM 2200-REFORMAT-REC-TYPE-P THRU 2200-EXIT             
                    PERFORM 6000-WRITE-GPRMXTR7 THRU 6000-EXIT                  
180947              IF WS-VOCOMEXT-REC-TYPE-B = 'Y'                             
180947                 MOVE 'N'        TO WS-VOCOMEXT-REC-TYPE-B                
180947              END-IF                                                      
                 ELSE                                                           
180947              IF VOCOMX-REC-TYPE = 'A'                                    
180947                     AND WS-VOCOMEXT-REC-TYPE-B = 'N'                     
180947                 MOVE DACOMNUM-OUT-BATCH-NUMBER TO                        
180947                      DACOMNUM-IN-BATCH-NUMBER                            
180947                 IF DACOMNUM-IN-BATCH-NUMBER = VOCOMX-FILE-NUMBER         
180947                    COMPUTE DACOMNUM-OUT-BATCH-NUMBER =                   
180947                            DACOMNUM-IN-BATCH-NUMBER  + 1                 
180947                    PERFORM 1020-PROCESS-DATE-RECORD                      
180947                                         THRU 1020-EXIT                   
180947                    MOVE +00 TO RETURN-CODE                               
180947                 ELSE                                                     
180947                    COMPUTE DACOMNUM-OUT-BATCH-NUMBER =                   
180947                            DACOMNUM-IN-BATCH-NUMBER  + 0                 
180947                    MOVE LR-VOCOMMSG-OUT   TO LOGICAL-RECORD-NAME         
180947                    MOVE STORE-LR          TO WS-GAEDATSR-VERB            
180947                    CALL GAEDATSR       USING WS-GAEDATSR-VERB            
180947                                              VOCOMMSG-REC1               
180947                                              ICBM                        
180947                    CALL GAEDATSR       USING WS-GAEDATSR-VERB            
180947                                              VOCOMMSG-REC2               
180947                                              ICBM                        
180947                    CALL GAEDATSR       USING WS-GAEDATSR-VERB            
180947                                              VOCOMMSG-REC3               
180947                                              ICBM                        
180947                    MOVE 'Y'            TO WS-VOCOMEXT-EOF                
180947                    MOVE 'N'            TO WS-VOCOMEXT-BNUM-MATCH         
180947                    MOVE WS-DACOMNUM-FIRST-BNUMBER TO                     
180947                            DACOMNUM-OUT-BATCH-NUMBER                     
180947                    MOVE +04 TO RETURN-CODE                               
180947                 END-IF                                                   
180947              ELSE                                                        
                       MOVE +6  TO WTL-SUB                                      
                       MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE              
                       PERFORM 9999-WTL-ABEND THRU 9999-EXIT                    
180947              END-IF                                                      
                 END-IF                                                         
              END-IF                                                            
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'           TO WS-VOCOMEXT-EOF                          
              ELSE                                                              
                 MOVE +7  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
              END-IF                                                            
           END-IF.                                                              
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2100-REFORMAT-REC-TYPE-C                                                
      ******************************************************************        
       2100-REFORMAT-REC-TYPE-C.                                                
           MOVE VOCOMX-GROUP-NUMBER  TO GCXT-GROUP-NUMBER.                      
           MOVE VOCOMX-GR-ACCOUNT    TO GCXT-GR-ACCOUNT.                        
           MOVE VOCOMX-REC-TYPE      TO GCXT-REC-TYPE.                          
           MOVE 'B' TO VDATE-REQ-SERVICE.                                       
           MOVE 'B' TO VDATE-REQ-BASIS.                                         
           MOVE '1' TO VDATE-REQ-DETAIL.                                        
           MOVE 'E' TO VDATE-REQ-LANGUAGE.                                      
           MOVE VOCOMX-COMM-COMP-EFFYYYY TO VDATE1-YYYY.                        
           MOVE VOCOMX-COMM-COMP-EFFMM   TO VDATE1-MM.                          
           IF VOCOMX-COMM-COMP-EFFMM = 02                                       
              AND                                                               
              VOCOMX-COMM-COMP-EFFDD = 29                                       
              MOVE 28 TO VOCOMX-COMM-COMP-EFFDD                                 
           END-IF                                                               
           MOVE VOCOMX-COMM-COMP-EFFDD   TO VDATE1-DD.                          
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = +0                                            
              MOVE 0                 TO GCXT-COMP-EFF-YEAR                      
                                        GCXT-COMP-EFF-DAY                       
           ELSE                                                                 
              MOVE VDATE-ALIS-YEAR1  TO GCXT-COMP-EFF-YEAR                      
              MOVE VDATE-ALIS-DAY1   TO GCXT-COMP-EFF-DAY                       
           END-IF.                                                              
           MOVE VOCOMX-COMM-AGENT-NUMBER TO GCXT-AGENT-NUMBER.                  
           IF VOCOMX-COMM-GFO-NUMBER = 0                                        
              MOVE SPACES                TO GCXT-GFO-NUMBER                     
           ELSE                                                                 
              MOVE VOCOMX-COMM-GFO-NUMBER                                       
                                         TO GCXT-GFO-NUMBER                     
           END-IF.                                                              
           MOVE VOCOMX-COMM-COMP-TYPE    TO GCXT-COMP-TYPE.                     
           MOVE VOCOMX-COMM-COMP-DISP    TO GCXT-COMP-DISP.                     
           MOVE VOCOMX-COMM-GROUP-REP    TO GCXT-GROUP-REP.                     
           MOVE VOCOMX-COMM-COMP-PROCYYYY TO VDATE1-YYYY.                       
           MOVE VOCOMX-COMM-COMP-PROCMM   TO VDATE1-MM.                         
           IF VOCOMX-COMM-COMP-PROCMM = 02                                      
              AND                                                               
              VOCOMX-COMM-COMP-PROCDD = 29                                      
              MOVE 28 TO VOCOMX-COMM-COMP-PROCDD                                
           END-IF                                                               
           MOVE VOCOMX-COMM-COMP-PROCDD   TO VDATE1-DD.                         
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = +0                                            
              MOVE 0                 TO GCXT-COMP-PROCESS-YEAR                  
                                        GCXT-COMP-PROCESS-DAY                   
           ELSE                                                                 
              MOVE VDATE-ALIS-YEAR1  TO GCXT-COMP-PROCESS-YEAR                  
              MOVE VDATE-ALIS-DAY1   TO GCXT-COMP-PROCESS-DAY                   
           END-IF.                                                              
           MOVE VOCOMX-COMM-COV-TYPE TO GCXT-COV-TYPE.                          
           MOVE VOCOMX-COMM-COMP-AMT TO WS-AMOUNT-NINE.                         
           IF VOCOMX-COMM-COMP-AMT-SGN = '-'                                    
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
                                       * (-1)                                   
           ELSE                                                                 
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
           END-IF.                                                              
           MOVE WS-NINE-AMOUNT           TO GCXT-COMP-AMT                       
           MOVE VOCOMX-COMM-COMP-REASON  TO GCXT-COMP-REASON.                   
           MOVE VOCOMX-COMM-RECON-IND    TO GCXT-RECON-IND.                     
           MOVE VOCOMX-COMM-AGENT-SPLIT  TO WS-AMOUNT-THREE.                    
           IF VOCOMX-COMM-AGENT-SPLIT-SGN = '-'                                 
              COMPUTE WS-THREE-AMOUNT = (WS-AMT-THREE-1 +                       
                                        (WS-AMT-THREE-3 / 100))                 
                                       * (-1)                                   
           ELSE                                                                 
              COMPUTE WS-THREE-AMOUNT = (WS-AMT-THREE-1 +                       
                                        (WS-AMT-THREE-3 / 100))                 
           END-IF.                                                              
           MOVE WS-THREE-AMOUNT       TO GCXT-AGENT-SPLIT.                      
           MOVE VOCOMX-COMM-PREM-AMT TO WS-AMOUNT-NINE.                         
           IF VOCOMX-COMM-PREM-AMT-SGN = '-'                                    
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
                                       * (-1)                                   
           ELSE                                                                 
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
           END-IF.                                                              
           MOVE WS-NINE-AMOUNT       TO GCXT-PREM-AMT.                          
           MOVE VOCOMX-COMM-NEXT-RECONYYYY TO VDATE1-YYYY.                      
           MOVE VOCOMX-COMM-NEXT-RECONMM   TO VDATE1-MM.                        
           IF VOCOMX-COMM-NEXT-RECONMM = 02                                     
              AND                                                               
              VOCOMX-COMM-NEXT-RECONDD = 29                                     
              MOVE 28 TO VOCOMX-COMM-NEXT-RECONDD                               
           END-IF                                                               
           MOVE VOCOMX-COMM-NEXT-RECONDD   TO VDATE1-DD.                        
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = +0                                            
              MOVE 0                 TO GCXT-NEXT-RECON-YEAR                    
                                        GCXT-NEXT-RECON-DAY                     
           ELSE                                                                 
              MOVE VDATE-ALIS-YEAR1  TO GCXT-NEXT-RECON-YEAR                    
              MOVE VDATE-ALIS-DAY1   TO GCXT-NEXT-RECON-DAY                     
           END-IF.                                                              
           MOVE VOCOMX-COMM-ACCT-EFFYYYY TO VDATE1-YYYY.                        
           MOVE VOCOMX-COMM-ACCT-EFFMM   TO VDATE1-MM.                          
           IF VOCOMX-COMM-ACCT-EFFMM = 02                                       
              AND                                                               
              VOCOMX-COMM-ACCT-EFFDD = 29                                       
              MOVE 28 TO VOCOMX-COMM-ACCT-EFFDD                                 
           END-IF                                                               
           MOVE VOCOMX-COMM-ACCT-EFFDD   TO VDATE1-DD.                          
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = +0                                            
              MOVE 0                TO GCXT-ACCT-EFFECTIVE-YEAR                 
                                       GCXT-ACCT-EFFECTIVE-DAY                  
           ELSE                                                                 
              MOVE VDATE-ALIS-YEAR1 TO GCXT-ACCT-EFFECTIVE-YEAR                 
              MOVE VDATE-ALIS-DAY1  TO GCXT-ACCT-EFFECTIVE-DAY                  
           END-IF.                                                              
           MOVE VOCOMX-COMM-NEXT-RECON-IND TO GCXT-NEXT-RECON-IND.              
                                                                                
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2200-REFORMAT-REC-TYPE-P                                                
      ******************************************************************        
       2200-REFORMAT-REC-TYPE-P.                                                
           MOVE VOCOMX-GROUP-NUMBER  TO GPXT-GROUP-NUMBER.                      
           MOVE VOCOMX-GR-ACCOUNT    TO GPXT-GR-ACCOUNT.                        
           MOVE VOCOMX-REC-TYPE      TO GPXT-REC-TYPE.                          
           MOVE 'B' TO VDATE-REQ-SERVICE.                                       
           MOVE 'B' TO VDATE-REQ-BASIS.                                         
           MOVE '1' TO VDATE-REQ-DETAIL.                                        
           MOVE 'E' TO VDATE-REQ-LANGUAGE.                                      
           MOVE VOCOMX-PREM-PREM-DUEYYYY TO VDATE1-YYYY.                        
           MOVE VOCOMX-PREM-PREM-DUEMM   TO VDATE1-MM.                          
           IF VOCOMX-PREM-PREM-DUEMM = 02                                       
              AND                                                               
              VOCOMX-PREM-PREM-DUEDD = 29                                       
              MOVE 28 TO VOCOMX-PREM-PREM-DUEDD                                 
           END-IF                                                               
           MOVE VOCOMX-PREM-PREM-DUEDD   TO VDATE1-DD.                          
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = +0                                            
              MOVE 0                 TO GPXT-PREM-DUE-YEAR                      
                                        GPXT-PREM-DUE-DAY                       
           ELSE                                                                 
              MOVE VDATE-ALIS-YEAR1  TO GPXT-PREM-DUE-YEAR                      
              MOVE VDATE-ALIS-DAY1   TO GPXT-PREM-DUE-DAY                       
           END-IF.                                                              
           MOVE VOCOMX-PREM-PREM-AMT TO WS-AMOUNT-NINE.                         
           IF VOCOMX-PREM-PREM-AMT-SGN = '-'                                    
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
                                       * (-1)                                   
           ELSE                                                                 
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
           END-IF.                                                              
           MOVE WS-NINE-AMOUNT           TO GPXT-PREM-AMT                       
           MOVE VOCOMX-PREM-COV-TYPE     TO GPXT-COV-TYPE.                      
           MOVE VOCOMX-PREM-NEXT-RECONYYYY TO VDATE1-YYYY.                      
           MOVE VOCOMX-PREM-NEXT-RECONMM   TO VDATE1-MM.                        
           IF VOCOMX-PREM-NEXT-RECONMM = 02                                     
              AND                                                               
              VOCOMX-PREM-NEXT-RECONDD = 29                                     
              MOVE 28 TO VOCOMX-PREM-NEXT-RECONDD                               
           END-IF                                                               
           MOVE VOCOMX-PREM-NEXT-RECONDD   TO VDATE1-DD.                        
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = +0                                            
              MOVE 0                 TO GPXT-NEXT-RECON-YEAR                    
                                        GPXT-NEXT-RECON-DAY                     
           ELSE                                                                 
              MOVE VDATE-ALIS-YEAR1  TO GPXT-NEXT-RECON-YEAR                    
              MOVE VDATE-ALIS-DAY1   TO GPXT-NEXT-RECON-DAY                     
           END-IF.                                                              
           MOVE VOCOMX-PREM-ACCT-EFFYYYY TO VDATE1-YYYY.                        
           MOVE VOCOMX-PREM-ACCT-EFFMM   TO VDATE1-MM.                          
           IF VOCOMX-PREM-ACCT-EFFMM = 02                                       
              AND                                                               
              VOCOMX-PREM-ACCT-EFFDD = 29                                       
              MOVE 28 TO VOCOMX-PREM-ACCT-EFFDD                                 
           END-IF                                                               
           MOVE VOCOMX-PREM-ACCT-EFFDD   TO VDATE1-DD.                          
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           IF VDATE-RET-IND NOT = +0                                            
              MOVE 0                 TO GPXT-ACCT-EFFECTIVE-YEAR                
                                        GPXT-ACCT-EFFECTIVE-DAY                 
           ELSE                                                                 
              MOVE VDATE-ALIS-YEAR1  TO GPXT-ACCT-EFFECTIVE-YEAR                
              MOVE VDATE-ALIS-DAY1   TO GPXT-ACCT-EFFECTIVE-DAY                 
           END-IF.                                                              
           MOVE VOCOMX-PREM-NEXT-RECON-IND TO GPXT-NEXT-RECON-IND.              
                                                                                
       2200-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 4000-WRITE-GCOMDATE.                                                    
      ******************************************************************        
       4000-WRITE-GCOMDATE.                                                     
           MOVE LR-VODACOM-OUT        TO LOGICAL-RECORD-NAME.                   
           MOVE STORE-LR              TO WS-GAEDATSR-VERB.                      
           CALL GAEDATSR           USING WS-GAEDATSR-VERB                       
                                         GCOMDATE                               
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +8  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       4000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 5000-WRITE-GCOMXTR7.                                                    
      ******************************************************************        
       5000-WRITE-GCOMXTR7.                                                     
           MOVE LR-VODACOM-OUT        TO LOGICAL-RECORD-NAME.                   
           MOVE STORE-LR              TO WS-GAEDATSR-VERB.                      
           CALL GAEDATSR           USING WS-GAEDATSR-VERB                       
                                         GCOMXTRT                               
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +9  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       5000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 6000-WRITE-GPRMXTR7.                                                    
      ******************************************************************        
       6000-WRITE-GPRMXTR7.                                                     
           MOVE LR-VODACOM-OUT        TO LOGICAL-RECORD-NAME.                   
           MOVE STORE-LR              TO WS-GAEDATSR-VERB.                      
           CALL GAEDATSR           USING WS-GAEDATSR-VERB                       
                                         GPRMXTR7                               
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +10 TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       6000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 7000-WRITE-OUT-BATCH-NUM                                                
      ******************************************************************        
       7000-WRITE-OUT-BATCH-NUM.                                                
           MOVE LR-OUT-BATCH-NUM      TO LOGICAL-RECORD-NAME.                   
           MOVE STORE-LR              TO WS-GAEDATSR-VERB.                      
           CALL GAEDATSR           USING WS-GAEDATSR-VERB                       
                                         DACOMNUM-OUT-BATCH-NUM                 
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +11 TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9000-FINISH                                                             
      *     CLOSE THE FILES.                                                    
      ******************************************************************        
       9000-FINISH.                                                             
           MOVE SPACES      TO LOGICAL-RECORD-NAME.                             
           MOVE FINISH-LR   TO WS-GAEDATSR-VERB.                                
           CALL GAEDATSR USING WS-GAEDATSR-VERB                                 
                               LOGICAL-RECORD-NAME                              
                               ICBM.                                            
                                                                                
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +12 TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       9000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9999-WTL-ABEND                                                          
      ******************************************************************        
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL'    USING  WTL-MESSAGES                                    
                                WTL-FLAG                                        
                                WTL-REPLY                                       
                                WTL-REPLY-AREA.                                 
                                                                                
           CALL 'ILBOABN0'  USING  WS-COMP-CODE.                                
                                                                                
       9999-EXIT.                                                               
           EXIT.                                                                
                                                                                
