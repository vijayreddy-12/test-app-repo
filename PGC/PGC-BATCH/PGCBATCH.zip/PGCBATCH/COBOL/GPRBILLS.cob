       CBL DATA(24)                                                             
       ID DIVISION.                                                             
GNE                                                                             
       PROGRAM-ID.   GPRBILLS.                                                  
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *****************************************************************         
      **                                                                        
      *   Note: If this comment is NOT Mixed Case, DO NOT RELEASE!              
      *         If you are reading these comments in UPPER CASE only,           
      *         there's been an EDITOR ACCIDENT.  Use only CAPS OFF for         
      *         this program or special characters will not be properly         
      *         preserved.                                                      
      *                                                                         
      *   Note: Program now has upper/lower case and French accent              
      *         characters (some of which do not display on terminal).          
      *         Use "HEX ON" to verify fields contain "SPACES" only.            
      *                                                                         
      *            character       hex    capital                               
      *         e (left accent)   = 51    E = 71                                
      *         a (right accent)  = 44    A = 64                                
      *         e (hat)           = 52    E = 72                                
      *         u (hat)           = DB    U = FB                                
      *         c (bottom hook)   = 48    C = 68                                
      *         e (right accent)  = 54    E = 74                                
      *         o (hat)           = CB                                          
      *                                                                         
      *       By 'right' (s)he means a slant from the upper left                
      *       slopping down to the lower right,                                 
      *       'left' goes from the upper right corner to the                    
      *       lower left.                                                       
      *****************************************************************         
      *REMARKS.      REVISED FOR DIVISIONAL BILLING JUNE 86. TVN.               
      *              REVISED FOR QUEBEC TAX DEC 12 GEORGE LENIO.                
      *              REVISED FOR QUEBEC TAX JUN 87,  C. PETERSON.               
      * K. AYSCOUGH  MAR/88 - REACTIVATED CODE THAT PRODUCES                    
      *                     BILLING NUMBERS ON THE FORMS.  G629                 
      *              MAY/88 - ADDED TWO GFO'S TO PHONE NUMBER                   
      *                       TABLE.                       G669                 
      * A. SCHLEICHER NOV/88- ADDED FEATURE FOR ERROR CHECK - NUMBER            
      *                       OF LIVES = 0, HAS TO READ GPSY MASTER             
      *                       TO MAKE SURE ACCOUNT STATUS IS NOT                
      *                       TERMINATED                                        
      * M. DRURY      MAR/89- CHANGE FIRST PAGE OF BILLS TO READ                
      *                       -PREMIUM SUMMARY- AND FOLLOWING PAGES             
      *                       TO READ -EMPLOYEE DATA-.                          
      *                       -REMOVE CALL TO GPRSGMNT AND REPLACED             
      *                        WITH  DLSO53 ENGLISH                             
      *                              DLSO54 FRENCH G736                         
      *                                                                         
      * B. WILKE      APR/89- CHANGE GFM2E-INSURED-LIVES = +0                   
      *                       SO THAT IT WILL LOOK AT THE CURRENT               
      *                      GIPSY MASTER RECORD FOR THE CURRENT                
      *                       BILLING TRAILER CERT-HOLDER = +0.                 
      *                                                                         
      *                                                                         
      * B. WILKE      MAY/89- CHANGE TELEPHONE LIST CLAIM OFFICE                
      *                       TO USE NEW CLAIM OFFICE NUMBERS                   
      *                       00320 TO 00548 CALGARY                            
      *                       00322 TO 00549 MONTREAL                           
      *                       00324 TO 00550 VANCOUVER                          
      *                       FIRST THREE LINES OF TELEPHONE TABLE              
      *                                                                         
      * M. PRANGE     JUN/89- SUBDIVIDE CALGARY CLAIMS OFFICE                   
      *                       INTO GFO'S IN TELEPHONE LIST TABLE.               
      *                                                                         
      *****************************************************************         
      *                   GIPSY-REL-1  START                          *         
      *****************************************************************         
      *                                                               *         
      *  AUG/89  M PRANGE - ENHANCED RETORACTIVE ADJUSTMENTS WITH NO  *         
      *                     CERT CODED TO BE DIVISION SPECIFIC AND    *         
      *                     THEREFORE PRINT WITHIN CORRECT DIVISION.  *         
      *                                                               *         
      *                   - INCREASED COLUMN COUNT FROM 7 TO 9.       *         
      *                                                               *         
      *                   - COSMETIC CHANGES.                         *         
      *                     E.G. UPPER/LOWER CASES, MULTIPLE FONTS,   *         
      *                          AFP PRINT INSTRUCTIONS ETC.          *         
      *                                                               *         
      *                   - CALLED BY GPRINTAL TO CLOSE SYS053        *         
      *                     AND SYS054.                               *         
      *                                                               *         
      *                   - FOR DEFAULT ADJUST RECORDS ON TERMINATIONS*         
      *                     USE NEW DATE ON 'S' RECORD.               *         
      *                                                               *         
      *  SEP/89 I BUCKNELL -BUG FIX: PICK UP PROPER DATE FOR MODE 12  *         
      *                     CERT ADDITION  (NOT THE SAME AS GROUP DT) *         
      *                    -CHANGE REPORT LITERAL 'GROUP OFFICE' TO   *         
      *                     JUST 'OFFICE'.                            *         
      *                                                               *         
      *  SEP/89 M DRURY    -CHANGED THE ERROR FILE (SYS011) TO A      *         
      *                      COPY BOOK.                                         
      *                    -CREATED 'HOLD-' FIELDS TO PUT PROD CODE   *         
      *                      AND GFO ON ERROR FILE.                   *         
      *****************************************************************         
      *                   GIPSY-REL-1  END                            *         
      *****************************************************************         
      *                                                                         
      *  FEB/90 M. PRANGE                                                       
      *         - ADDED MARKETING MESSAGE PRINT LOGIC.                          
      *                                                                         
      *  MAR/90 M. PRANGE                                                       
      *         - PICKING UP DEFAULT ISSUE (ADDITION) DATE FROM                 
      *           THE 'S' RECORD WHEN NO ADJUST RECORDS EXIST.                  
      *                                                                         
      *  JUN/90 M. PRANGE                                                       
      *         - FORCE AFP "UGBIL2" COMMANDS TO AUTOMATICALLY PRINT            
      *           OUT BEFORE EACH SUMMARY PAGE.                                 
      *                                                                         
      *  APR/91 M. PRANGE                                                       
      *         - NEW GTELENOS COPYBOOK. INCREASED SIZE OF "CITY" TEXT.         
      *                                                                         
      *  MAY/91 D. HAMILTON                                                     
      *         - CHANGES FOR CHERYL KAY'S NEW OVERLAYS.                        
      *                                                                         
      *  JUL/91 M. BURTON                                                       
      *         - CHANGES TO PRINT OUT FRENCH SUMMARY LINES CORRECTLY.          
      *                                                                         
      *  JAN/92 M. PRANGE                                                       
      *         - DO NOT PRINT "IMPORTANT" TEXT LINES IF TOT PREMIUM            
      *           DUE IS < OR = ZERO.                                           
      *                                                                         
      *  APR/92 M. PRANGE                                                       
      *         - INCREASED SIZE OF 'EDIT-PREM' AND 'EDIT-PREM-FIN'             
      *           FIELDS TO 10 BYTES.                                           
      *                                                                         
      *                                                                         
      *  JUN/93 M. PRANGE                                                       
      *         - CHANGES TO HANDLE MULTIPLE TAXES.                             
      *                                                                         
      *  AUG/93 M. PRANGE                                                       
      *         - FIX GNUMTABL RETURN AREA TO BE 15 BYTES.                      
      *                                                                         
NAL   *  JUN/96 A. MA                                                           
NAL   *         - CHECK TLU111 FOR CONVERTED NAL CUSTOMERS                      
NAL   *           PRINT NAL/PAL TOLL FREE NUMBER ON NOTICE IF FOUND             
NAL   *           DETERMINE FRENCH OR ENGLISH NUMBER BY PROVINCE AND            
NAL   *           LANGUAGE CODE                                                 
      *  JAN/97 RBS                                                             
      *         - TRACKS 1730 - CHANGE THE FRENCH DATES TO LOWER CASE.          
 GV   *  SEP/99 GVRAO                                                           
      *         - ADD TEXT LINES TO BILL RE: EFT PAYMENT OPTIONS                
      *         - ADDED NEW PAD REPORT                                          
 GV2  *  NOV/99 GVRAO                                                           
 GV2  *         - CHANGES FOR EFT PHASE II                                      
 BM   *         - CHANGES TO OVERDUE NOTICE                                     
      *  NOV/2000 ISAM TASK LOG # 14238  C.ARSENE                               
      *         - ADDED THE STATEMENT CURRENTLY ON ALPH+ (NO-EFT-LIT-1,         
      *         NO-EFT-LIT-2 AND NO-EFT-LIT-3) TO THE HO SIGNITURE              
      *         POLICIES (PROD CODE 2 & 3 )                                     
ZUR1  * JUN/2001 MELANSON FOR ZURICH                                            
      *   - TLU111 NOW IDENTIFIES BOTH NAL AND ZURICH, SO CHANGE LOGIC          
      *     SO THAT THE APPROPRIATE 1-800 NUMBERS ARE USED                      
E42   *  2002SPRING - ECOMMERCE 4.2 RELEASE DLS                                 
E42   *         CREATED NEW EXTRACT TO FACILITATE BILL PRESENTMENT              
E42   *         ON THE WEB. THIS COULD LEAD TO DOING ALL THE BILLS              
E42   *         THRU XML/XSL/PDF TECHNOLOGY .                                   
      *  AUG/02 C. ARSENE - GBSS TASK LOG 23785                                 
      *          - STANDARDIZE ALL 1-800 #'S ON GIPSY HEAD                      
      *            OFFICE BILLS TO 1-800-268-6195 (TLU111)                      
      *  APR/03 M. COOPER - GBSS TASK LOG 24907                                 
      *          - MODIFIED DUE TO CHANGES TO GARBILL* COPYBOOKS                
      *            TO MAKE MAILING-DIVISON A CHARACTER TYPE FIELD.              
      * C ARSENE FEB/05  - GBSS TASK 37699                                      
      *                    CHANGED TO USE ENGLISH OR FRENCH TOLL FREE           
      * SEP/2008 IBMECU    - ENTERPRISE COMPILER UPGRADE                        
      *                                                                         
      * FEB/2009 C. MUNCAN - MODIFIED SUMM-LINE-EDIT1 FIELD SO THE              
      *      PREMIUM DUE LAST MONTH & TOTAL PREMIUM DUE WILL PRINT WITH         
      *      BOTH LEADING -VEs & TRAILING 'CR' ...                              
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       77  BANNER                                  PIC X(41)                    
           VALUE '*** START OF GPRBILLS WORKING STORAGE ***'.                   
      *                                                                         
      *  HOLD- PCODE AND OFFICE SET BY MARCUS TO PASS THE CORRECT               
      *        PCODE AND GFO TO THE ERROR FILE.                                 
      *                                                                         
       77  HOLD-PCODE         VALUE SPACES         PIC X.                       
       77  HOLD-OFFICE        VALUE SPACES         PIC XXXXX.                   
                                                                                
       77  SUB1                COMP SYNC           PIC S9(4).                   
       77  ZPAR-PARM1         VALUE '5'            PIC X.                       
       77  ERR-CODE                  VALUE SPACES  PIC XXX.                     
       77  PAGE-CT             COMP-3              PIC S9(3).                   
       77  LOOP-CNT            COMP                PIC S9(2).                   
       77  QDATE-PARM                              PIC XX.                      
       77  QDATE-AB                  VALUE 'AB'    PIC XX.                      
       77  QDATE-AD                  VALUE 'AD'    PIC XX.              YEAR2000
       77  DIVISION-UNPACK                         PIC 999.                     
       77  DIVISION-BLANK-LINE COMP-3              PIC S9(3).                   
       77  LINE-CT             COMP-3              PIC S9(3).                   
       77  TEST-LINE-CT        COMP-3              PIC S9(3).                   
       77  TEST-LINE-MAX       COMP-3              PIC S9(3).                   
       77  TOTAL-BILL          COMP-3              PIC S9(7)V99.                
       77  TOTAL-TAX           COMP-3              PIC S9(7)V99.                
       77  TOTAL-PREM-DUE      COMP-3              PIC S9(7)V99.                
       77  TOTAL-TAX-DUE       COMP-3              PIC S9(7)V99.                
       77  PROV-TAX-DUE        COMP-3              PIC S9(7)V99.                
       77  OUTSTANDING-PREM    COMP-3              PIC S9(7)V99.                
       77  PRS-WORK            COMP-3              PIC S9(9)V99.                
       77  NUM-SUMMARY-REP-PRODUCED                PIC S9(1) COMP-3.            
       77  ADJ-RECD-FND-SW                         PIC X.                       
       77  ADJ-RECD-GROUP-REQD-SW                  PIC X.                       
       77  ADJ-RECD-CERT-REQD-SW                   PIC X.                       
       77  DIV-TRIPLE-SPACE-FLAG                   PIC X(1).                    
       77  DIV-ADJ-FOUND-FLAG                      PIC X(1).                    
       77  GENERATE-ADJ-SW                         PIC X.                       
       77  DONE-DETAIL-SW                          PIC X.                       
       77  DONE-DIVISION-SW                        PIC X.                       
       77  PREM-PAY1                               PIC X VALUE 'N'.             
       77  TAX-PAY1                                PIC X VALUE 'N'.             
       77  PREM-PAY2                               PIC X VALUE 'N'.             
       77  TAX-PAY2                                PIC X VALUE 'N'.             
       77  GPRSGMNT-SW-ENG-SGPS                    PIC X VALUE '0'.             
       77  GPRSGMNT-SW-FR-SGPS                     PIC X VALUE '0'.             
       77  DIV-BILL-TYPE-SW                        PIC X VALUE '0'.             
       77  END-NAME-FOUND-SW                       PIC X VALUE '0'.             
       77  IMPORT-BOX-REQD-SW                      PIC X VALUE '0'.             
       77  GMASEXPD-ERROR                          PIC X(3).                    
       77  SAVE-CURRENCY                           PIC X(3).                    
       77  SAVE-LINE                               PIC X(165).                  
       77  PHONE-INDEX         PIC S9(8)  COMP  VALUE +0.                       
       77  PHONE-INDEX-SAVE    PIC S9(8)  COMP  VALUE +0.                       
       77  INIT-PHONE          PIC X(14) VALUE ' -   -   -    '.                
                                                                                
       01  WS-DATE1.                                                            
           05  WS-DAY1         PIC X(2)         VALUE SPACES.                   
           05  WS-MONTH1       PIC X(3)         VALUE SPACES.                   
           05  WS-YEAR1        PIC X(4)         VALUE SPACES.           YEAR2000
       01  WS-DATE2.                                                            
           05  WS-DAY2         PIC X(2)         VALUE SPACES.                   
           05  FILLER          PIC X(1)         VALUE SPACES.                   
           05  WS-MONTH2       PIC X(3)         VALUE SPACES.                   
           05  FILLER          PIC X(1)         VALUE SPACES.                   
           05  WS-YEAR2        PIC X(4)         VALUE SPACES.           YEAR2000
                                                                                
      *01  GPPFAPRM.                                                            
           COPY GPPFAPRM.                                                       
                                                                                
       01  SAVE-GPPFA-PAGE-NAME        PIC X(8)  VALUE SPACES.                  
       01  SAVE-GPPFA-OVLY-COPYGRP     PIC X(8)  VALUE SPACES.                  
                                                                                
NAL    01  WS-PHONE-CLAIMS-OFFICE      PIC X(05).                               
NAL    01  WS-PHONE-GROUP-OFFICE       PIC X(05).                               
NAL    01  TLU111-PARMS.                                                        
NAL        05  TLU111-ERRIND           PIC X(1).                                
NAL        05  TLU111-SEARCH-ARGUMENT.                                          
NAL            10  TLU111-GROUP        PIC 9(7).                                
NAL        05  TLU111-TABLE-NUM        PIC S9(3) COMP-3                         
NAL                                              VALUE +111.                    
NAL        05  TLU111-CII-EFF-DATE     PIC 9(8).                                
NAL        05  TLU111-GROUP-EFF-DATE   PIC 9(8).                                
                                                                                
       01  WRITE-ENG-SYS053.                                                    
           05  WRITE-ENG-DDNAME        PIC X(6)  VALUE 'SYS053'.                
           05  WRITE-ENG-RET           PIC S9    COMP-3.                        
           05  WRITE-ENG-REC           PIC 9(5)  VALUE 165.                     
           05  WRITE-ENG-BLK           PIC 9(5)  VALUE 1650.                    
           05  WRITE-ENG-FMT           PIC XX    VALUE 'FB'.                    
           05  WRITE-ENG-CNT           PIC S9(7) COMP-3 VALUE +0.               
                                                                                
       01  WRITE-FRN-SYS054.                                                    
           05  WRITE-FRN-DDNAME        PIC X(6)  VALUE 'SYS054'.                
           05  WRITE-FRN-RET           PIC S9    COMP-3.                        
           05  WRITE-FRN-REC           PIC 9(5)  VALUE 165.                     
           05  WRITE-FRN-BLK           PIC 9(5)  VALUE 1650.                    
           05  WRITE-FRN-FMT           PIC XX    VALUE 'FB'.                    
           05  WRITE-FRN-CNT           PIC S9(7) COMP-3 VALUE +0.               
E42    01  WRITE-XTR-SYS085.                                                    
E42        05  WRITE-XTR-DDNAME        PIC X(6)  VALUE 'SYS085'.                
E42        05  WRITE-XTR-RET           PIC S9    COMP-3.                        
E42        05  WRITE-XTR-REC           PIC 9(5)  VALUE 5000.                    
E42        05  WRITE-XTR-BLK           PIC 9(5)  VALUE 5004.                    
E42        05  WRITE-XTR-FMT           PIC XX    VALUE 'VB'.                    
E42        05  WRITE-XTR-CNT           PIC S9(7) COMP-3 VALUE +0.               
E42                                                                             
E42    01  BILL-EXTRACT-RECORD.                                                 
E42        02  FILLER.                                                          
E42            05  BER-EXTRACT-LENGTH  PIC S9(4) COMP.                          
E42            05  FILLER              PIC X(2)  VALUE LOW-VALUES.              
E42        02  BER-EXTRACT-DATA        PIC X(5000).                             
E42                                                                             
E42    01  LENGTH-FIELDS.                                                       
E42        05  BSR-FIXED-LENGTH    VALUE +640    PIC S9(4) COMP.                
E42        05  BSR-VAR-LENGTH      VALUE +31     PIC S9(4) COMP.                
E42        05  BER-FIXED-LENGTH    VALUE +147    PIC S9(4) COMP.                
E42        05  BER-VAR-LENGTH      VALUE +23     PIC S9(4) COMP.                
E42        05  BMR-FIXED-LENGTH    VALUE +119    PIC S9(4) COMP.                
E42        05  BMR-VAR-LENGTH      VALUE +25     PIC S9(4) COMP.                
E42        05  BPR-FIXED-LENGTH    VALUE +51     PIC S9(4) COMP.                
E42        05  BA1R-FIXED-LENGTH   VALUE +101    PIC S9(4) COMP.                
E42        05  BA1R-VAR-LENGTH     VALUE +25     PIC S9(4) COMP.                
E42        05  BA2R-FIXED-LENGTH   VALUE +122    PIC S9(4) COMP.                
E42        05  BA2R-VAR-LENGTH     VALUE +13     PIC S9(4) COMP.                
E42        05  BCR-FIXED-LENGTH    VALUE +39     PIC S9(4) COMP.                
E42        05  BCR-VAR-LENGTH      VALUE +0      PIC S9(4) COMP.                
E42                                                                             
E42    01  BILL-SUMMARY-EXTRACT.                                                
E42        COPY GARBILLA.                                                       
E42    01  BILL-MEMBER-EXTRACT.                                                 
E42        COPY GARBILLB.                                                       
E42    01  BILL-PAYMENT-EXTRACT.                                                
E42        COPY GARBILLC.                                                       
E42    01  BILL-GRP-END-EXTRACT.                                                
E42        COPY GARBILLD.                                                       
E42    01  BILL-MEMADJ1-EXTRACT.                                                
E42        COPY GARBILLE.                                                       
E42    01  BILL-MEMADJ2-EXTRACT.                                                
E42        COPY GARBILLF.                                                       
E42    01  BILL-CONTROL-EXTRACT.                                                
E42        COPY GARBILLZ.                                                       
E42                                                                             
E42    01  WSA-FLAGS.                                                           
E42        05  WSA-XTR-GROUP-STARTED-FLAG VALUE 'N'  PIC X(1).                  
E42            88  WSA-XTR-GROUP-STARTED             VALUE 'Y'.                 
E42            88  WSA-XTR-GROUP-FINISHED            VALUE 'N'.                 
E42        05  WSA-MEM-DETAIL-STARTED-FLAG VALUE 'N' PIC X(1).                  
E42            88  WSA-MEM-DETAIL-STARTED            VALUE 'Y'.                 
E42            88  WSA-MEM-DETAIL-FINISHED           VALUE 'N'.                 
E42                                                                             
E42    01  WSA-WORK-FIELDS.                                                     
E42        05  WSA-NUMBER3-X.                                                   
E42            10  WSA-NUMBER3                       PIC 9(3).                  
E42        05  WSA-NUMBER9-X.                                                   
E42            10  WSA-NUMBER9                       PIC 9(9).                  
E42                                                                             
E42        05  WSA-GROUP-NUMBER-X.                                              
E42            10  WSA-GROUP-NUMBER                  PIC 9(7).                  
E42   *                            SIGN LEADING SEPARATE.                       
E42        05  WSA-SUB                      COMP-3   PIC S9(3).                 
E42        05  WSA-SUB-A                    COMP-3   PIC S9(3).                 
E42        05  WSA-SUB-B                    COMP-3   PIC S9(3).                 
E42        05  WSA-NAME-ADDR-MAX VALUE +6   COMP-3   PIC S9(3).                 
E42        05  WSA-COLUMN-MAX    VALUE +9   COMP-3   PIC S9(3).                 
E42        05  WSA-ERROR-MAX     VALUE +25  COMP-3   PIC S9(3).                 
E42        05  WSA-ALIS-WORK-DATE.                                              
E42            10  WSA-ALIS-WORK-YEAR       COMP-3   PIC S9(3).                 
E42            10  WSA-ALIS-WORK-DAY        COMP-3   PIC S9(3).                 
E42                                                                             
E42        05  WSA-WORK-DATE.                                                   
E42            10  WSA-WORK-YEAR                     PIC 9(4).                  
E42            10  WSA-WORK-MONTH                    PIC 9(2).                  
E42            10  WSA-WORK-DAY                      PIC 9(2).                  
E42        05  WSA-CURR-COV-CODE                     PIC 9(3).                  
E42            88  WSA-CURR-COV-CODE-LIFE            VALUE 150.                 
E42            88  WSA-CURR-COV-CODE-ADD             VALUE 083.                 
E42        05  WSA-TEST-COV-CODE                     PIC 9(3).                  
E42            88  WSA-TEST-COV-CODE-LIFE            VALUE  140 150.            
E42            88  WSA-TEST-COV-CODE-ADD             VALUE  080 083             
E42                                                         084.                
E42        05  WSA-LOW-DATE        VALUE '00000101'  PIC X(8).                  
                                                                                
      *=======================>                                                 
      *       FR-LINE-1-2 IS USED TO ACCOMADATE THE THREE FRENCH MONTHS         
      *          THAT BEGIN WITH A VOWEL. THESE MONTHS CAN NOT BE               
      *          PREFIXED WITH DE, BUT MUST HAVE D'.                            
      *          THESE LINES ARE USED IN THE PARA  BUILD-SUMM-TEST-NORM.        
      *          IF THE LANG-SUB IS 2 AND THE MONTH IS EITHOR 4,8,10            
      *           THEN FR-LINE-1 IS SET TO - DU MOIS D -  AND                   
      *                FR-LINE-2 IS SET TO - ' -.                               
      *           FR-LINE-1-2 IS THEN MOVE TO PR-HEAD2-SAVE.                    
      *                                                 MARUCS FEB/6/86         
      *=======================>                                                 
                                                                                
       01  MASTER-RECORD-START.                                                 
           05  FILLER                     PIC X(27)       VALUE                 
               'GPRBILLS - GMASEXPD ERROR. '.                                   
           05  FILLER                     PIC X(5)        VALUE                 
               'GRP  '.                                                         
GNE        05  ERROR-GROUP                PIC 9(7)        VALUE ZEROS.          
           05  FILLER                     PIC X(5)        VALUE                 
               'ACCT '.                                                         
           05  ERROR-ACCT                 PIC X(3)        VALUE SPACES.         
           05  FILLER                     PIC X(5)        VALUE                 
               'CODE '.                                                         
           05  ERROR-CODE                 PIC X(3)        VALUE SPACES.         
           05  FILLER                     PIC X(7)        VALUE                 
               ' START '.                                                       
       01  VSDSI20-START.                                                       
           05  FILLER                     PIC X(27)       VALUE                 
               'START OF VSDSI20 PARMS     '.                                   
       01  VSDSI20-PARM-1.                                                      
           05  VSDSI20-DDNAME       PIC X(7)  VALUE 'VSDSI20'.                  
           05  VSDSI20-ACCTYPE      PIC X(5)  VALUE 'KEYED'.                    
           05  VSDSI20-RECTYPE      PIC X     VALUE 'V'.                        
           05  VSDSI20-FUNCTION     PIC X(6)  VALUE SPACES.                     
           05  VSDSI20-ERRCODE      PIC X(5)  VALUE SPACES.                     
           05  VSDSI20-READCT       PIC S9(7) VALUE +0 COMP-3.                  
           05  VSDSI20-WRITECT      PIC S9(7) VALUE +0 COMP-3.                  
           05  VSDSI20-UPDATECT     PIC S9(7) VALUE +0 COMP-3.                  
           05  VSDSI20-DELETECT     PIC S9(7) VALUE +0 COMP-3.                  
           05  VSDSI20-RECLGTH      PIC S9(4) VALUE +0 COMP.                    
       01  VSDSI20-PARM-2.                                                      
GNE        05  VSDSI20-GROUP        PIC S9(7) COMP-3.                           
           05  VSDSI20-ACCOUNT      PIC X(3)  VALUE SPACES.                     
          01 GACCDMAS-PARMS.                                                    
             05 GMP-PARM1.                                                      
                10 GMP-FUNC-CODE    PIC S9(4) COMP   VALUE +2.                  
                10 GMP-SEARCH-ARG.                                              
GNE                15 GMP-SA-GROUP  PIC S9(7) COMP-3 VALUE +0.                  
                   15 GMP-SA-ACCT   PIC XXX          VALUE SPACES.              
                   15 GMP-SA-FILLER PIC S9(9) COMP-3 VALUE +0.                  
                   15 GMP-ACCESS    PIC X(9)         VALUE SPACES.              
             05 GMP-ERROR-CODE      PIC XXX         VALUE SPACES.               
                                                                                
       01  COND-START.                                                          
           05  FILLER                     PIC X(27)       VALUE                 
               'START OF COND MASTER RECORD'.                                   
       01  CONDENSED-MASTER-RECORD.                                             
           05  FILLER                     PIC X(00004).                         
           05  CONDENSED-MASTER           PIC X(13000).                         
                                                                                
       01  GMASTER-START.                                                       
           05  FILLER                     PIC X(27)       VALUE                 
               'START OF MASTER EXPD RECORD'.                                   
                                                                                
      *01  GMASTER.                                                             
GNE        COPY GMASTER7.                                                       
                                                                                
       01  MASTER-RECORD-END.                                                   
           05  FILLER                     PIC X(5)        VALUE                 
               ' END '.                                                         
                                                                                
       01  WTL-PARMS.                                                           
           05  WTL-MESSAGE-PARMS.                                               
               10  WTL-LEN    COMP-3   PIC S9(3)   VALUE +56.                   
               10  WTL-MESS.                                                    
                   15  WTL-MESS-CARR   PIC X       VALUE SPACE.                 
                   15  WTL-MESSAGE     PIC X(55)   VALUE SPACE.                 
           05  WTL-FLAG                PIC X       VALUE 'C'.                   
           05  WTL-REPLY               PIC XX      VALUE 'NO'.                  
       01  FR-LINE-1-2.                                                         
           05  FR-LINE-1                        PIC X(9)  VALUE SPACE.          
           05  FR-LINE-2                        PIC X     VALUE SPACE.          
           05  FR-LINE-3                        PIC X(14) VALUE SPACE.          
                                                                                
       01  W-GFMBRL2D-BIL-NUM.                                                  
           05  W-PHONE-LONG-D  PIC X.                                           
           05  W-PHONE-AREA-C  PIC X(3).                                        
           05  W-PHONE-NUM-1   PIC X(3).                                        
           05  W-PHONE-NUM-2   PIC X(4).                                        
                                                                                
       01  BILLING-FORMS.                                                       
           05  FORM-BILL-ENG-SGPS                  PIC XX  VALUE '22'.          
           05  FORM-BILL-FR-SGPS                   PIC XX  VALUE '23'.          
                                                                                
       01  MISCELLANEOUS-WORK-AREA.                                             
 GV        03  GWEFCPDR   VALUE 'GWEFCPDR'         PIC X(08).                   
           03  LANG-SUB                            PIC S9(3) COMP-3.            
 GV            88  ENGLISH-SUB VALUE +1.                                        
 GV            88  FRENSH-SUB  VALUE +2.                                        
           03  GGICOV-SUB                          PIC S9(3) COMP-3.            
           03  GGICOL-SUB                          PIC S9(3) COMP-3.            
           03  GGICOL-CTR                          PIC S9(3) COMP-3.            
           03  GGI-TITLE-SUB                       PIC S9(3) COMP-3.            
           03  CHECK-SUB                           PIC S9(3) COMP-3.            
           03  COV-SUB                             PIC S9(3) COMP-3.            
           03  ADJ-SUB                             PIC S9(3) COMP-3.            
           03  REC-SUB                             PIC S9(3) COMP-3.            
           03  PREM-SUB                            PIC S9(3) COMP-3.            
           03  TEST-SUB       REDEFINES PREM-SUB   PIC XX.                      
           03  COL-SUB                             PIC S9(3) COMP-3.            
           03  TITLE-SUB                           PIC S9(3) COMP-3.            
           03  STATS-SUB                           PIC S9(3) COMP-3.            
           03  CERT-SUB                            PIC S9(3) COMP-3.            
           03  LINE-SUB                            PIC S9(3) COMP-3.            
           03  TAX-LINE-CNT                        PIC S9(3) COMP-3.            
           03  TAX-SUB                             PIC S9(3) COMP-3.            
           03  WORK-NUM-COV-CODES.                                              
           05  WORK-NUM-COV-CODES9                 PIC S9(3) COMP-3.            
           05  WORK-NUM-COV-CODESX REDEFINES WORK-NUM-COV-CODES9 PIC XX.        
           03  DEPENDENT-IND.                                                   
               05  DEP-LIFE-IND                    PIC X.                       
               05  DEP-EHC-IND                     PIC X.                       
               05  DEP-DEN-IND                     PIC X.                       
           03  EDIT-GRP-OFFICE                     PIC 99999.                   
           03  EDIT-GRP-OFF REDEFINES EDIT-GRP-OFFICE.                          
               05  EDIT-GRP-OFF-1                  PIC 9.                       
               05  EDIT-GRP-OFF-2                  PIC 9.                       
               05  EDIT-GRP-OFF-3                  PIC 9.                       
               05  EDIT-GRP-OFF-4                  PIC 9.                       
               05  EDIT-GRP-OFF-5                  PIC 9.                       
           03  STORE-OFFICE-NM-NUM.                                             
               05  STORE-OFF-NM-NUM OCCURS 35 TIMES                             
                                    INDEXED BY OFFICE-SUB  PIC X.               
           03  SAVE-AGENT-NAME                     PIC X(24).                   
           03  EDIT-VOL                            PIC --,---,---.              
           03  EDIT-PREM                           PIC ---,---.--.              
           03  EDIT-VOL-FIN                        PIC ----------.              
           03  EDIT-PREM-FIN                       PIC -------.--.              
           03  EHC-CODE-MIN               COMP-3   PIC S9(3).                   
           03  EHC-CODE-MAX               COMP-3   PIC S9(3).                   
           03  DEN-CODE-MIN               COMP-3   PIC S9(3).                   
           03  DEN-CODE-MAX               COMP-3   PIC S9(3).                   
           03  OUT-DDMMYY.                                                      
               05  FILLER                          PIC XX.                      
MAN07          05  OUT-MM                          PIC 99.                      
               05  FILLER                          PIC XX.                      
           03  TEST-DATE                           PIC X(4).                    
           03  TEST-MODE                           PIC XX.                      
           03  OUT-DDMMMYYYY.                                                   
               05  FILLER                          PIC X(5).                    
               05  OUT-YYYY.                                                    
                   07  OUT-YEAR1                   PIC X.                       
                   07  OUT-YEAR2                   PIC X.                       
                   07  OUT-YEAR3                   PIC X.                       
                   07  OUT-YEAR4                   PIC X.                       
           03  AMOUNT-OUTSTANDING                  PIC S9(7)V99 COMP-3.         
           03  TOTAL-PREM-DUE-THIS-MONTH           PIC S9(7)V99 COMP-3.         
           03  TEST-AMOUNT                         PIC S9(7)V99 COMP-3.         
           03  TEST-AMOUNT-R REDEFINES TEST-AMOUNT PIC S9(6)V999 COMP-3.        
           03  PAY-STORE-DATA.                                                  
               05  PAY-REVERSE                  PIC S9(7)V99 COMP-3.            
               05  PAY-RECEIVE1-AMT             PIC S9(7)V99 COMP-3.            
               05  PAY-RECEIVE2-AMT             PIC S9(7)V99 COMP-3.            
               05  PAY-RECEIVE3-AMT             PIC S9(7)V99 COMP-3.            
               05  PAY-RECEIVE1-DATE            PIC X(4).                       
               05  PAY-RECEIVE2-DATE            PIC X(4).                       
               05  PAY-RECEIVE3-DATE            PIC X(4).                       
           03  ACCUM-PAGE-KEY.                                                  
               05  FILLER                       PIC X.                          
               05  NEW-PAGE-FORM                PIC X.                          
GNE            05  NEW-PAGE-GROUP               PIC S9(7) COMP-3.               
               05  NEW-PAGE-ACCT                PIC XXX.                        
           03  TAPE-COVERAGE-SEGMENT.                                           
               05  T-COV-CODE                   PIC S9(3) COMP-3.               
               05  T-VOLUME                     PIC S9(7) COMP-3.               
               05  T-PREM                       PIC S9(8)V999 COMP-3.           
           03  EXT-PARMS.                                                       
               05  EXT-SYS075          PIC X(6)  VALUE 'SYS075'.                
               05  EXT-RETURN          PIC S9(1) VALUE +0  COMP-3.              
               05  EXT-RECSIZE         PIC 9(5)  VALUE 19056.                   
               05  EXT-BLKSIZE         PIC 9(5)  VALUE 19060.                   
               05  EXT-FORMAT          PIC XX    VALUE 'VB'.                    
               05  EXT-SYS075-COUNT    PIC S9(7) VALUE +0  COMP-3.              
           03  ZPARDUMP-PARMS.                                                  
               05  ZPARDUMP-FUNC   PIC X         VALUE '1'.                     
                                                                                
       01  GNUMTABL-PARMS.                                                      
           03  GNUM-TABLE-NO           COMP     PIC S9(4) VALUE +22.            
           03  GNUM-EHC-KEY                     PIC X(3)  VALUE '019'.          
           03  GNUM-DEN-KEY                     PIC X(3)  VALUE '099'.          
           03  GNUM-RETURN.                                                     
               05  FILLER                       PIC X(8).                       
               05  COV-CODE-MIN                 PIC 999.                        
               05  FILLER                       PIC X(4).                       
               05  COV-CODE-MAX                 PIC 999.                        
           03  GNUM-CURR-TABLE-NO      COMP     PIC S9(4) VALUE +02.            
           03  GNUM-CURR-RETURN.                                                
               05  GNUM-CURRENCY                PIC X(3).                       
               05  FILLER                       PIC X(12).                      
                                                                                
       01  CHANGE-REPORTS-E.                                                    
           03  ER-TITLE.                                                        
               05  FILLER PIC X(23) VALUE SPACES.                               
               05  FILLER PIC X(44) VALUE                                       
                  'TERMINATION, CLASSIFICATION AND SALARY CHANG'.               
               05  FILLER PIC X(8) VALUE                                        
                  'E REPORT'.                                                   
               05  FILLER PIC X(89) VALUE SPACES.                               
           03  ER-DASH-LINE.                                                    
               05  FILLER PIC X(50) VALUE                                       
                   '     _____________________________________________'.        
               05  FILLER PIC X(50) VALUE                                       
                   '__________________________________________________'.        
               05  FILLER PIC X(50) VALUE                                       
                   '__________________________________________________'.        
               05  FILLER PIC X(14) VALUE                                       
                   '_________     '.                                            
           03  ER-POLICY-AND-NAME.                                              
               05  FILLER PIC X(7)  VALUE SPACES.                               
GNE            05  ER-GROUP PIC X(7).                                           
               05  FILLER PIC X     VALUE SPACES.                               
               05  ER-ACCOUNT PIC X(3).                                         
               05  FILLER PIC X(5)  VALUE SPACES.                               
               05  ER-NAME PIC X(30).                                           
GNE            05  FILLER PIC X(111) VALUE SPACES.                              
           03  ER-EFF-AND-CHANGE.                                               
               05  FILLER PIC X(51) VALUE SPACES.                               
               05  FILLER PIC X(31) VALUE ' EFFECTIVE DATE OF'.                 
               05  FILLER PIC X(82) VALUE                                       
                   ' CHANGE IN SALARY OR OCCUPATION     CLASS'.                 
           03  ER-CERT-AND-REMARKS.                                             
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(12) VALUE ' CERT.     '.                        
               05  FILLER PIC X(33) VALUE                                       
                  ' NAME OF EMPLOYEE '.                                         
               05  FILLER PIC X(8)  VALUE ' CHANGE'.                            
               05  FILLER PIC X(16) VALUE 'OR TERMINATION'.                     
               05  FILLER PIC X(39) VALUE ' CODE '.                             
               05  FILLER PIC X(14) VALUE '   CHANGE'.                          
               05  FILLER PIC X(36) VALUE                                       
                  '          REMARKS           '.                               
           03  ER-NUMBER-AND-DATES.                                             
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(45) VALUE ' NUMBER    '.                        
               05  FILLER PIC X(8)  VALUE '  DAY  '.                            
               05  FILLER PIC X(8)  VALUE '  MO.  '.                            
               05  FILLER PIC X(8)  VALUE ' YEAR  '.                            
               05  FILLER PIC X(7)  VALUE '  *   '.                             
               05  FILLER PIC X(16) VALUE '     FROM      '.                    
               05  FILLER PIC X(16) VALUE '      TO       '.                    
               05  FILLER PIC X(7)  VALUE ' FROM '.                             
               05  FILLER PIC X(43) VALUE '  TO  '.                             
                                                                                
           03  ER-FOOTNOTE1.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(62) VALUE                                       
            '* CLASSIFICATION CHANGE CODE - "C"                '.               
               05  FILLER PIC X(52) VALUE                                       
               '* TERMINATION CODES                                 '.          
               05  FILLER PIC X(44) VALUE                                       
               'DATES TO BE SHOWN                        '.                     
           03  ER-FOOTNOTE2.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(62) VALUE                                       
            'If classification change results in increased coverage, '.         
               05  FILLER PIC X(52) VALUE                                       
               '"T" - Termination of employment                     '.          
               05  FILLER PIC X(44) VALUE                                       
               'Date active work ceased                  '.                     
           03  ER-FOOTNOTE3.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(62) VALUE                                       
            'and employee was not at work on date of change, show    '.         
               05  FILLER PIC X(52) VALUE                                       
               '"L" - Temporary layoff or leave of absence          '.          
               05  FILLER PIC X(44) VALUE                                       
               'Date to which insurance is to be continued'.                    
           03  ER-FOOTNOTE4.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(62) VALUE                                       
            'date of return to work in "REMARKS" column.             '.         
               05  FILLER PIC X(52) VALUE SPACES.                               
               05  FILLER PIC X(44) VALUE                                       
               'up to the limit specified in the policy  '.                     
           03  ER-FOOTNOTE5.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(62) VALUE                                       
            'If decreased coverage will result, always show actual   '.         
               05  FILLER PIC X(52) VALUE                                       
               '"P" - Pensioned or Retired                          '.          
               05  FILLER PIC X(44) VALUE                                       
               'Date active work ceased                  '.                     
           03  ER-FOOTNOTE6.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(62) VALUE                                       
            'date of change.                                         '.         
               05  FILLER PIC X(52) VALUE                                       
               '"A" - Cancellation requested by employee            '.          
               05  FILLER PIC X(44) VALUE                                       
               'Date requested by employee               '.                     
                                                                                
       01  CHANGE-REPORTS-F.                                                    
           03  FR-TITLE.                                                        
               05  FILLER PIC X(23) VALUE SPACES.                               
               05  FILLER PIC X(7) VALUE                                        
                  'AVIS DE'.                                                    
               05  FILLER PIC X(12) VALUE                                       
                  ' CESSATION, '.                                               
               05  FILLER PIC X(40) VALUE                                       
                  'DE CHANGEMENT DE CAT�GORIE ET DE SALAIRE'.                   
               05  FILLER PIC X(82) VALUE SPACES.                               
           03  FR-DASH-LINE.                                                    
               05  FILLER PIC X(50) VALUE                                       
                   '     _____________________________________________'.        
               05  FILLER PIC X(50) VALUE                                       
                   '__________________________________________________'.        
               05  FILLER PIC X(50) VALUE                                       
                   '__________________________________________________'.        
               05  FILLER PIC X(14) VALUE                                       
                   '_________     '.                                            
           03  FR-POLICY-AND-NAME.                                              
               05  FILLER PIC X(7)  VALUE SPACES.                               
GNE            05  FR-GROUP PIC X(7).                                           
               05  FILLER PIC X     VALUE SPACES.                               
               05  FR-ACCOUNT PIC X(3).                                         
               05  FILLER PIC X(5)  VALUE SPACES.                               
               05  FR-NAME PIC X(30).                                           
GNE            05  FILLER PIC X(111) VALUE SPACES.                              
           03  FR-EFF-AND-CHANGE.                                               
               05  FILLER PIC X(51) VALUE SPACES.                               
               05  FILLER PIC X(6)  VALUE 'DATE D'.                             
               05  FILLER PIC X     VALUE QUOTE.                                
               05  FILLER PIC XX    VALUE 'EF'.                                 
               05  FILLER PIC X(8)  VALUE 'FET DU C'.                           
               05  FILLER PIC X     VALUE 'H'.                                  
               05  FILLER PIC X(16) VALUE 'ANGEMENT'.                           
               05  FILLER PIC X(24) VALUE '    CHANGEMENT DE SALAIR'.           
               05  FILLER PIC X(6)  VALUE 'E OU D'.                             
               05  FILLER PIC X     VALUE QUOTE.                                
               05  FILLER PIC X(11) VALUE 'EMPLOI    '.                         
               05  FILLER PIC X(6)  VALUE 'CHANGE'.                             
               05  FILLER PIC X     VALUE 'M'.                                  
               05  FILLER PIC X(30) VALUE 'ENT DE'.                             
           03  FR-CERT-AND-REMARKS.                                             
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(12) VALUE ' CERT. NO  '.                        
               05  FILLER PIC X(37)  VALUE                                      
                  '        NOM DU SALARIE         '.                            
               05  FILLER PIC X(7)  VALUE 'OU DE L'.                            
               05  FILLER PIC X     VALUE QUOTE.                                
               05  FILLER PIC X(15) VALUE 'ANNULATION     '.                    
               05  FILLER PIC X(7)  VALUE ' CODE '.                             
               05  FILLER PIC X(42) VALUE                                       
               ' AYANT CAUSE LE CHANGEMENT DE CATEGORIE  '.                     
               05  FILLER PIC X(14) VALUE '  CATEGORIE  '.                      
               05  FILLER PIC X(23) VALUE                                       
                  '   REMARQUES    '.                                           
           03  FR-NUMBER-AND-DATES.                                             
               05  FILLER PIC X(51) VALUE SPACES.                               
               05  FILLER PIC X(9)  VALUE '  JOUR  '.                           
               05  FILLER PIC X(9)  VALUE '  MOIS  '.                           
               05  FILLER PIC X(9)  VALUE ' ANNEE  '.                           
               05  FILLER PIC X(7)  VALUE '  *   '.                             
               05  FILLER PIC X(21) VALUE '        DE          '.               
               05  FILLER PIC X(21) VALUE '           A        '.               
               05  FILLER PIC X(37) VALUE '  DE     A'.                         
                                                                                
           03  FR-FOOTNOTE1.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(62) VALUE                                       
            '*POUR INDIQUER LE CHANGEMENT DE CAT�GORIE, EMPLOYER "C". '.        
               05  FILLER PIC X(33) VALUE                                       
               '*CODE POUR INDIQUER LA CAUSE DE L'.                             
               05  FILLER PIC X     VALUE QUOTE.                                
               05  FILLER PIC X(18) VALUE                                       
               'ANNULATION  '.                                                  
               05  FILLER PIC X(44) VALUE                                       
               'DATES DEVANT �TRE INDIQU�ES       '.                            
           03  FR-FOOTNOTE2.                                                    
               05  FILLER PIC X(6)  VALUE SPACES.                               
               05  FILLER PIC X(14)  VALUE                                      
               'Si par suite d'.                                                
               05  FILLER PIC X      VALUE QUOTE.                               
               05  FILLER PIC X(29)  VALUE                                      
               'un changement de cat�gorie, l'.                                 
               05  FILLER PIC X      VALUE QUOTE.                               
               05  FILLER PIC X(17)  VALUE                                      
               'assurance doit  '.                                              
               05  FILLER PIC X(17)  VALUE                                      
               '"T" - Cessation d'.                                             
               05  FILLER PIC X      VALUE QUOTE.                               
               05  FILLER PIC X(34)  VALUE                                      
               'emploi                  '.                                      
               05  FILLER PIC X(44)  VALUE                                      
               'Date de cessation du travail r�gulier   '.                      
           03  FR-FOOTNOTE3.                                                    
               05  FILLER PIC X(6)   VALUE SPACES.                              
               05  FILLER PIC X(33)  VALUE                                      
               '�tre augment�e et si le salari� n'.                             
               05  FILLER PIC X      VALUE QUOTE.                               
               05  FILLER PIC X(28)  VALUE                                      
               '�tait pas au travail � la  '.                                   
               05  FILLER PIC X(52)  VALUE                                      
               '"L" - Cong� ou mise � pied temporaire     '.                    
               05  FILLER PIC X(31)  VALUE                                      
               'Date limite contractuelle jusqu'.                               
               05  FILLER PIC X      VALUE QUOTE.                               
               05  FILLER PIC X(12)  VALUE                                      
               '� laquelle'.                                                    
           03  FR-FOOTNOTE4.                                                    
               05  FILLER PIC X(6)   VALUE SPACES.                              
               05  FILLER PIC X(31)  VALUE                                      
               'date du changement, indiquez la'.                               
               05  FILLER PIC X(31)  VALUE                                      
               ' date de la reprise du travail'.                                
               05  FILLER PIC X(52)  VALUE SPACES.                              
               05  FILLER PIC X      VALUE                                      
               'l'.                                                             
               05  FILLER PIC X      VALUE QUOTE.                               
               05  FILLER PIC X(42)  VALUE                                      
               'assurance a �t� maintenue en vigueur'.                          
           03  FR-FOOTNOTE5.                                                    
               05  FILLER PIC X(6)   VALUE SPACES.                              
               05  FILLER PIC X(22)  VALUE                                      
               'sous "REMARQUES". Si l'.                                        
               05  FILLER PIC X      VALUE QUOTE.                               
               05  FILLER PIC X(39)  VALUE                                      
               'assurance doit �tre reduite, indiquez '.                        
               05  FILLER PIC X(52)  VALUE                                      
               '"P" - D�part en Retraite                   '.                   
               05  FILLER PIC X(44)  VALUE                                      
               'Date de cessation du travail r�gulier      '.                   
           03  FR-FOOTNOTE6.                                                    
               05  FILLER PIC X(6)   VALUE SPACES.                              
               05  FILLER PIC X(31)  VALUE                                      
               'la date r�elle du changement so'.                               
               05  FILLER PIC X(31)  VALUE                                      
               'us "REMARQUES".               '.                                
               05  FILLER PIC X(52)  VALUE                                      
               '"A" - Annulation demand�e par le salari�      '.                
               05  FILLER PIC X(44)  VALUE                                      
               'Date indiqu�e par le salari�          '.                        
                                                                                
       01  WORK-REPORTS.                                                        
           03  WR-TITLE                         PIC X(164).                     
           03  WR-DASH-LINE                     PIC X(164).                     
           03  WR-POLICY-AND-NAME               PIC X(164).                     
           03  WR-EFF-AND-CHANGE                PIC X(164).                     
           03  WR-CERT-AND-REMARKS              PIC X(164).                     
           03  WR-NUMBER-AND-DATES              PIC X(164).                     
           03  WR-FOOTNOTE1                     PIC X(164).                     
           03  WR-FOOTNOTE2                     PIC X(164).                     
           03  WR-FOOTNOTE3                     PIC X(164).                     
           03  WR-FOOTNOTE4                     PIC X(164).                     
           03  WR-FOOTNOTE5                     PIC X(164).                     
           03  WR-FOOTNOTE6                     PIC X(164).                     
      *****************************************************************         
      *    TABLE AREA STORE                                                     
      *    STORE ALL THE DETAIL RECORDS (CURRENT BILLING, ADJUSTMENT            
      *    BILLING AND D90 ADJUSTMENT) FOR THE CURRENT GROUP/ACCT/CERT.         
      *    ON CHANGE IN CERT OR TABLE FULL THE RECORDS WILL BE PROCESSED        
      *    AND PRINTED ON THE DETAIL BILLING LIST.                              
      *  - THE RECORDS ARE ACCUMULATED IN A TABLE SINCE ALL LINES FOR A         
      *    GROUP/ACCT/CERT MUST APPEAR ON THE SAME PAGE UNLESS THEY             
      *    THERE ARE MORE THAN 30 LINES FOR THAT GROUP/ACCT/CERT                
      ******************************************************************        
       01  DETAIL-RECORDS-TABLE.                                                
           03  NUM-DETAIL-STORED                PIC S9(4) COMP.                 
           03  DETAIL-RECORDS OCCURS 30 TIMES.                                  
               05  FILLER                       PIC X(4).                       
               05  DETAIL-REC-TYPE              PIC X.                          
               05  DETAIL-GRP-OFFICE            PIC XXXXX.                      
GNE            05  DETAIL-GROUP                 PIC S9(7) COMP-3.               
               05  DETAIL-ACCOUNT               PIC XXX.                        
               05  DETAIL-ORDER                 PIC X.                          
               05  DETAIL-CERT-NAME.                                            
                   07  DETAIL-CN-CERTIFICATE    PIC S9(9) COMP-3.               
                   07  DETAIL-CN-NAME           PIC X(28).                      
               05  DETAIL-NAME-CERT REDEFINES DETAIL-CERT-NAME.                 
                   07  DETAIL-NC-NAME           PIC X(28).                      
                   07  DETAIL-NC-CERTIFICATE    PIC S9(9) COMP-3.               
               05  DETAIL-DETAIL-IDENT          PIC X.                          
               05  DETAIL-ADJ-EFF-DATE          PIC X(4).                       
               05  DETAIL-ADJ-MODE              PIC XX.                         
GNE            05  FILLER                       PIC X(600).                     
                                                                                
      ******************************************************************        
      *    TABLE AREA STORE                                                     
      *    EACH COVERAGE CODE IN FROM THE BILLING CONTROL RECORD HAS THE        
      *    ASSOCIATED COLUMNS IN WHICH IT IS REQUIRED.                          
      *    THIS TABLE IS BUILT EXACTLY THE SAME WAY AS IN GPRCERTL.             
      ******************************************************************        
       01  TITLE-TABLE-BY-COV-CODE.                                             
           03  TITLE-NUM-CODES                     PIC S9(3) COMP-3.            
           03  TITLE-COV-CODES OCCURS 38 TIMES.                                 
               05  TITLE-COV-CODE                  PIC S9(3) COMP-3.            
               05  NUM-COLS                        PIC S9(1) COMP-3.            
               05  COLS-OF-COV-CODE OCCURS 9 TIMES PIC S9(1) COMP-3.            
                                                                                
      ******************************************************************        
      *    ACCUMULATORS FOR 1) DETAIL LINES                                     
      *                     2) GRP/ACCOUNT/FORM TOTAL LINES - USED TO           
      *                        PRINT THE BALANCE OF CONTROL REPORT.             
      ******************************************************************        
       01  ACCUMULATORS.                                                        
           03  COL-ACCUM-ROUNDED      COMP-3       PIC S9(11)V99.               
           03  COLUMN-ACCUM-DETAIL    COMP-3.                                   
               05  COL-ACCUM OCCURS 10 TIMES       PIC S9(10)V999.              
           03  COL-ACCUM-R REDEFINES COLUMN-ACCUM-DETAIL.                       
               05  FILLER             COMP-3       PIC S9(10)V999.              
               05  COL-ACCUM-TO-ZERO               PIC X(63).                   
           03  BAL-GRP-COLUMN-ACCUM-DETAIL    COMP-3.                           
               05  BAL-GRP-COL-ACCUM OCCURS 10 TIMES PIC S9(10)V999.            
           03  BAL-GRP-COL-ACCUM-R REDEFINES                                    
                                   BAL-GRP-COLUMN-ACCUM-DETAIL.                 
               05  FILLER             COMP-3       PIC S9(10)V999.              
               05  BAL-GRP-COL-ACCUM-TO-ZERO       PIC X(63).                   
                                                                                
      ******************************************************************        
      *    THE ERROR REC IS TRANSLATED BY GPRERROR                              
      *    M39 - TRANSLATED AS 'TOTAL DUE THIS MONTH OUT OF BALANCE'            
      *    M40 -               'BILNG CNTRL OR INFRCE REC NOT RECVD'            
      *    M50 -               'NUMBER OF LIVES IS 0               '            
      ******************************************************************        
      *                                                                         
      *  CHANGED TO A COPY BOOK     BY MARCUS                                   
      *                                                                         
GNE        COPY GERRREC7.                                                       
                                                                                
       01  CURR-AREA.                                                           
           05  CURR-KEY.                                                        
               10  CURR-SEG1.                                                   
                   15  CURR-REC-TYPE                   PIC X.                   
                   15  CURR-TYPE                       PIC X.                   
GNE            10  CURR-GROUP      COMP-3              PIC S9(7).               
               10  CURR-ACCT                           PIC XXX.                 
           05  CURR-CERT           COMP-3              PIC S9(9).               
           05  CURR-COUNTRY                            PIC X.                   
           05  CURR-BILL-REC-TYPE                      PIC X.                   
                                                                                
       01  PREV-AREA.                                                           
           05  PREV-KEY.                                                        
               10  PREV-SEG1.                                                   
                   15  PREV-REC-TYPE                   PIC X.                   
                   15  PREV-TYPE                       PIC X.                   
GNE            10  PREV-GROUP      COMP-3              PIC S9(7).               
               10  PREV-ACCT                           PIC XXX.                 
           05  PREV-CERT           COMP-3              PIC S9(9).               
           05  PREV-COUNTRY                            PIC X.                   
           05  PREV-BILL-REC-TYPE                      PIC X.                   
           05  PREV-DIVISION       COMP-3              PIC S9(3).               
                                                                                
       01  STORE-RESTART.                                                       
           03  SAVE-RESTART.                                                    
               05  SR-REC-TYPE                         PIC X.                   
               05  SR-FORM                             PIC X.                   
GNE            05  SR-GROUP        COMP-3              PIC S9(7).               
               05  SR-ACCT                             PIC XXX.                 
           03  FILLER                                  PIC XX.                  
                                                                                
      ******************************************************************        
      *    THESE ARE THE LITERAL AREAS USED FOR ALL THE PRINT LINES ON          
      *    THE REPORT.  THE LITERALS AFTER REPORT-LIT-ENGLISH-FRENCH            
      *    ARE REDEFINES SO THAT A SUBSCRIPT CAN BE USED TO ACCESS THE          
      *    REQUIRED ENGLISH OR FRENCH LIT.  THE ENGLISH LIT MUST COME           
      *    IMMEDIATELY BEFORE THE FRENCH LIT.                                   
      ******************************************************************        
       01  LIT-AREAS.                                                           
           03  DASH-LINE.                                                       
               05  DASH-LINE1               PIC X(5)   VALUE SPACES.            
               05  DASH-LINE2               PIC X(152) VALUE ALL '_'.           
           03  STAR-LINE                    PIC X(65)  VALUE ALL '*'.           
                                                                                
           03  REPORT-LIT-ENGLISH-FRENCH.                                       
               05  LIST-BILL-ENG-1-SUMM-PG.                                     
                   07  FILLER               PIC X(60) VALUE                     
                   'PREMIUM SUMMARY'.                                           
               05  LIST-BILL-FR-1-SUMM-PG.                                      
                   07  FILLER               PIC X(60) VALUE                     
                   'SOMMAIRE DES PRIMES'.                                       
               05  LIST-BILL-ENG-1-EMP-DATA.                                    
                   07  FILLER               PIC X(60) VALUE                     
                   'EMPLOYEE DATA'.                                             
               05  LIST-BILL-FR-1-EMP-DATA.                                     
                   07  FILLER               PIC X(60) VALUE                     
                   'RENSEIGNEMENTS SUR LES SALARI�S'.                           
               05  LIST-BILL-ENG-2.                                             
                   07  FILLER               PIC X(17) VALUE                     
                   'For the Month of'.                                          
                   07  LIST-BILL-MONTH-YEAR-ENG.                                
                       09  LIST-BILL-M-Y-E  OCCURS 14 TIMES                     
                                            INDEXED BY LIST-BILL-ESUB           
                                            PIC X.                              
                   07  FILLER               PIC X(29) VALUE SPACES.             
               05  LIST-BILL-FR-2.                                              
                   07  FILLER               PIC X(11) VALUE                     
                   'Du mois de'.                                                
                   07  LIST-BILL-MONTH-YEAR-FR.                                 
                       09  LIST-BILL-M-Y-F  OCCURS 14 TIMES                     
                                            INDEXED BY LIST-BILL-FSUB           
                                            PIC X.                              
                   07  FILLER               PIC X(35) VALUE SPACES.             
               05  REIN-LIST-ENG-1.                                             
                   07  FILLER               PIC X(60) VALUE                     
                   'REINSTATEMENT PREMIUM STATEMENT'.                           
               05  REIN-LIST-FR-1.                                              
                   07  FILLER               PIC X(17) VALUE                     
                   '�TAT DES PRIMES D'.                                         
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(42) VALUE                     
                   'ASSURANCE COLLECTIVE - REMISE EN VIGUEUR'.                  
               05  REIN-LIST-ENG-2.                                             
                   07  FILLER               PIC X(5)  VALUE 'From'.             
                   07  REIN-LIST-DATE1-ENG  PIC X(9).                           
                   07  FILLER               PIC X(4)  VALUE ' To '.             
                   07  REIN-LIST-DATE2-ENG  PIC X(9).                           
                   07  FILLER               PIC X(33) VALUE SPACES.             
               05  REIN-LIST-FR-2.                                              
                   07  FILLER               PIC X(3)  VALUE 'Du'.               
                   07  REIN-LIST-DATE1-FR   PIC X(9).                           
                   07  FILLER               PIC X(4)  VALUE ' Au '.             
                   07  REIN-LIST-DATE2-FR   PIC X(9).                           
                   07  FILLER               PIC X(35) VALUE SPACES.             
               05  NEW-ISSUE-ENG-1.                                             
                   07  FILLER               PIC X(60) VALUE                     
                   'INITIAL PREMIUM STATEMENT'.                                 
               05  NEW-ISSUE-FR-1.                                              
                   07  FILLER               PIC X(60) VALUE                     
                   '�TAT DES PRIMES INITIAL'.                                   
               05  NEW-ISSUE-ENG-2.                                             
                   07  FILLER               PIC X(5)  VALUE 'From'.             
                   07  NEW-ISSUE-DATE1-ENG  PIC X(9).                           
                   07  FILLER               PIC X(4)  VALUE ' To '.             
                   07  NEW-ISSUE-DATE2-ENG  PIC X(9).                           
                   07  FILLER               PIC X(33) VALUE SPACES.             
               05  NEW-ISSUE-FR-2.                                              
                   07  FILLER               PIC X(3)  VALUE 'Du'.               
                   07  NEW-ISSUE-DATE1-FR   PIC X(9).                           
                   07  FILLER               PIC X(4)  VALUE ' Au '.             
                   07  NEW-ISSUE-DATE2-FR   PIC X(9).                           
                   07  FILLER               PIC X(35) VALUE SPACES.             
               05  TERM-LIST-ENG-1.                                             
                   07  FILLER               PIC X(60) VALUE                     
                   'FINAL PREMIUM STATEMENT'.                                   
               05  TERM-LIST-FR-1.                                              
                   07  FILLER               PIC X(60) VALUE                     
                   '�TAT DES PRIMES FINAL'.                                     
               05  TERM-LIST-ENG-2.                                             
                   07  FILLER               PIC X(17) VALUE                     
                       'Termination date'.                                      
                   07  TERM-LIST-DATE-ENG   PIC X(9).                           
                   07  FILLER               PIC X(34) VALUE SPACES.             
               05  TERM-LIST-FR-2.                                              
                   07  FILLER               PIC X(6)  VALUE 'Date D'.           
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(21) VALUE                     
                       'annulation du R�gime'.                                  
                   07  TERM-LIST-DATE-FR    PIC X(9).                           
                   07  FILLER               PIC X(23) VALUE SPACES.             
               05  FILLER                   PIC X(6)  VALUE 'NUMBER'.           
               05  FILLER                   PIC X(6)  VALUE 'NUM�RO'.           
               05  FILLER                   PIC X(6)  VALUE 'OFFICE'.           
               05  FILLER                   PIC X(6)  VALUE 'BUREAU'.           
               05  FILLER                   PIC X(4)  VALUE 'NAME'.             
               05  FILLER                   PIC X(4)  VALUE 'NOM '.             
               05  FILLER                   PIC X(16) VALUE                     
                   'PREMIUM DUE DATE'.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'PRIME PAYABLE LE'.                                          
               05  FILLER                   PIC X(13) VALUE                     
                   'DATE PREPARED'.                                             
               05  FILLER                   PIC X(13) VALUE                     
                   'PR�PAR� LE'.                                                
               05  FILLER                   PIC X(17) VALUE                     
                   'FILE REFERENCE'.                                            
               05  FILLER                   PIC X(17) VALUE                     
                   'CODE DE R�F�RENCE'.                                         
 GV2           05  FILLER                   PIC X(31) VALUE                     
 GV2               'When paying by cheque,         '.                           
 GV2           05  FILLER                   PIC X(31) VALUE                     
 GV2               'Lorsque vous payez par ch�que, '.                           
 GV2           05  FILLER                   PIC X(31) VALUE                     
 GV2               'please detach and return       '.                           
 GV2           05  FILLER                   PIC X(31) VALUE                     
 GV2               'veuillez d�tacher le talon et  '.                           
 GV2           05  FILLER                   PIC X(31) VALUE                     
 GV2               'this stub with your payment.   '.                           
 GV2           05  FILLER                   PIC X(31) VALUE                     
 GV2               'le joindre � votre paiement.   '.                           
               05  FILLER                   PIC X(8)  VALUE                     
                   'CURRENCY'.                                                  
               05  FILLER                   PIC X(8)  VALUE                     
                   'MONNAIE'.                                                   
               05  FILLER                   PIC X(31) VALUE                     
                   'PREMIUM DUE LAST MONTH         '.                           
               05  FILLER                   PIC X(31) VALUE                     
                   'PRIME PAYABLE LE MOIS PR�C�DENT'.                           
               05  FILLER                   PIC X(39) VALUE                     
                   'TOTAL DUE LAST MONTH                   '.                   
               05  FILLER                   PIC X(39) VALUE                     
                   'MONTANT TOTAL PAYABLE LE MOIS PR�C�DENT'.                   
               05  FILLER                   PIC X(26) VALUE                     
                   'PREMIUM PAYMENT REVERSED  '.                                
               05  FILLER                   PIC X(26) VALUE                     
                   'PAIEMENT DE PRIME RENVERS�'.                                
               05  FILLER                   PIC X(25) VALUE                     
                   'PREMIUM PAYMENTS RECEIVED'.                                 
               05  FILLER                   PIC X(25) VALUE                     
                   'PAIEMENTS DE PRIME RE�US '.                                 
               05  FILLER                   PIC X(17) VALUE                     
                   'PAYMENTS RECEIVED'.                                         
               05  FILLER                   PIC X(17) VALUE                     
                   'PAIEMENTS RE�US  '.                                         
               05  FILLER                   PIC X(30) VALUE                     
                   'OUTSTANDING PREMIUM           '.                            
               05  FILLER                   PIC X(30) VALUE                     
                   'MONTANT DE PRIME EN SOUFFRANCE'.                            
               05  FILLER                   PIC X(21) VALUE                     
                   'OUTSTANDING          '.                                     
               05  FILLER                   PIC X(21) VALUE                     
                   'MONTANT EN SOUFFRANCE'.                                     
               05  FILLER                   PIC X(29) VALUE                     
                   'CURRENT MONTH PREMIUM DUE    '.                             
               05  FILLER                   PIC X(29) VALUE                     
                   'PRIME PAYABLE DU MOIS COURANT'.                             
               05  FILLER                   PIC X(21) VALUE                     
                   'TOTAL PREMIUM DUE    '.                                     
               05  FILLER                   PIC X(21) VALUE                     
                   'PRIME TOTALE PAYABLE '.                                     
               05  FILLER                   PIC X(58) VALUE                     
                   '                      '.                                    
               05  FILLER.                                                      
                   07  FILLER               PIC X(19) VALUE                     
                   '                  '.                                        
                   07  FILLER               PIC X(39) VALUE                     
                   '                          '.                                
               05  FILLER                   PIC X(58) VALUE                     
                   '                      '.                                    
               05  FILLER.                                                      
                   07  FILLER               PIC X(58) VALUE                     
                   '                          '.                                
               05  FILLER                   PIC X(16) VALUE                     
                   'GROUP NUMBER    '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'NUM�RO          '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'ACCOUNT         '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'COMPTE          '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'FILE REFERENCE  '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'R�F�RENCE       '.                                          
      ******************************************************************        
      * GIPSY RELEASE 1, LIT BELOW USED TO BE 'GROUP OFFICE' I.B.               
      ******************************************************************        
               05  FILLER                   PIC X(16) VALUE                     
                   'OFFICE          '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'BUREAU          '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'CURRENCY        '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'MONNAIE         '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'DATE DUE        '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'PAYABLE LE      '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'PREM. DUE       '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'PRIME           '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'TOTAL PREM. DUE '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'PRIME TOTALE    '.                                          
               05  FILLER                   PIC X(13) VALUE                     
                   'TAX DUE      '.                                             
               05  FILLER                   PIC X(13) VALUE                     
                   'TAXE DUE -   '.                                             
               05  FILLER                   PIC X(16) VALUE                     
                   'TOTAL DUE       '.                                          
               05  FILLER                   PIC X(16) VALUE                     
                   'TOTAL           '.                                          
               05  FILLER                   PIC X(27) VALUE                     
                   'CURRENT POLICY STATUS'.                                     
               05  FILLER                   PIC X(27) VALUE                     
                   'STATUT COURANT DE LA POLICE'.                               
               05  FILLER                   PIC X(9)  VALUE '     CERT'.        
               05  FILLER                   PIC X(9)  VALUE '   NO. DU'.        
               05  FILLER                   PIC X(10) VALUE                     
                   '    NUMBER'.                                                
               05  FILLER                   PIC X(10) VALUE                     
                   '     CERT.'.                                                
               05  FILLER                   PIC X(2)  VALUE 'CL'.               
               05  FILLER                   PIC X(2)  VALUE 'CT'.               
               05  FILLER                   PIC X(7)  VALUE '  DEP'.            
               05  FILLER                   PIC X(7)  VALUE 'P.A.CH.'.          
               05  FILLER                   PIC X     VALUE 'L'.                
               05  FILLER                   PIC X     VALUE 'V'.                
               05  FILLER                   PIC X     VALUE 'H'.                
               05  FILLER                   PIC X     VALUE 'M'.                
               05  FILLER                   PIC X     VALUE 'D'.                
               05  FILLER                   PIC X     VALUE 'D'.                
               05  FILLER                   PIC X(9)  VALUE '    TOTAL'.        
               05  FILLER                   PIC X(9)  VALUE '    PRIME'.        
               05  FILLER                   PIC X(9)  VALUE '  PREMIUM'.        
               05  FILLER                   PIC X(9)  VALUE '   TOTALE'.        
               05  FILLER                   PIC X(9)  VALUE 'TOTAL'.            
               05  FILLER                   PIC X(9)  VALUE 'PRIME'.            
               05  FILLER                   PIC X(9)  VALUE 'PREMIUM'.          
               05  FILLER                   PIC X(9)  VALUE 'TOTALE'.           
               05  FILLER                   PIC X(5)  VALUE 'TOTAL'.            
               05  FILLER                   PIC X(5)  VALUE 'TOTAL'.            
               05  FILLER                   PIC X(21) VALUE                     
                   '     LIVES INSURED = '.                                     
               05  FILLER                   PIC X(21) VALUE                     
                   'PERSONNES ASSUR�ES = '.                                     
               05  PLEASE-RETURN-LIT-ENG-1.                                     
                   07  FILLER               PIC X(46) VALUE                     
                       'PLEASE RETURN ONE COPY OF THIS PAGE WITH YOUR'.         
                   07  FILLER               PIC X(15) VALUE                     
                       'PAYMENT OF THE'.                                        
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(20) VALUE                     
                       'TOTAL DUE THIS MONTH'.                                  
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(40) VALUE                     
                       '. INDICATE ANY EMPLOYEE'.                               
               05  PLEASE-RETURN-LIT-FR-1.                                      
                   07  FILLER               PIC X(46) VALUE                     
                       'VEUILLEZ NOUS RENVOYER UN EXEMPLAIRE DE CETTE'.         
                   07  FILLER               PIC X(28) VALUE                     
                       'PAGE AVEC VOTRE PAIEMENT DU '.                          
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(37) VALUE                     
                       'MONTANT TOTAL PAYABLE DU MOIS COURANT'.                 
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(10) VALUE                     
                       '. INDIQUEZ'.                                            
               05  PLEASE-RETURN-LIT-ENG-2.                                     
                   07  FILLER               PIC X(44) VALUE                     
                       'ADDITIONS, TERMINATIONS OR OTHER CHANGES ON'.           
                   07  FILLER               PIC X(73) VALUE                     
                       'THE BACK OF THIS STATEMENT.'.                           
               05  PLEASE-RETURN-LIT-FR-2.                                      
                   07  FILLER               PIC X(16) VALUE                     
                       'TOUTE ADDITION D'.                                      
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(43) VALUE                     
                       'EMPLOY�, TOUTE ANNULATION DE CERTIFICAT OU'.            
                   07  FILLER               PIC X(46) VALUE                     
                       'TOUTE AUTRE MODIFICATION AU VERSO DE CET �TAT '.        
                   07  FILLER               PIC X(11) VALUE                     
                       'DES PRIMES.'.                                           
               05  PLEASE-RETURN-LIT-ENG-1-TERM.                                
                   07  FILLER               PIC X(46) VALUE                     
                       'PLEASE RETURN ONE COPY OF THIS PAGE WITH YOUR'.         
                   07  FILLER               PIC X(15) VALUE                     
                       'PAYMENT OF THE'.                                        
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(20) VALUE                     
                       'TOTAL DUE THIS MONTH'.                                  
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(31) VALUE '.'.                
               05  PLEASE-RETURN-LIT-FR-1-TERM.                                 
                   07  FILLER               PIC X(46) VALUE                     
                       'VEUILLEZ NOUS RENVOYER UN EXEMPLAIRE DE CETTE'.         
                   07  FILLER               PIC X(28) VALUE                     
                       'PAGE AVEC VOTRE PAIEMENT DU '.                          
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(37) VALUE                     
                       'MONTANT TOTAL PAYABLE DU MOIS COURANT'.                 
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X     VALUE '.'.                
 GV   * REWORDING OF STANDARD NO TAX LINES                                      
 GV            05  PAYMENT-ADJ-LIT-ENG-1.                                       
 GV                07  FILLER               PIC X(42) VALUE                     
 GV                    'Payments and adjustments for terminations,'.            
 GV                07  FILLER               PIC X(43) VALUE                     
 GV                    ' additions and changes processed after the '.           
 GV            05  PAYMENT-ADJ-LIT-FR-1.                                        
 GV                07  FILLER               PIC X(45) VALUE                     
 GV                    'Les paiements et rajustements, dans le cas de'.         
 GV                07  FILLER               PIC X(40) VALUE                     
 GV                    ' cessations d''emploi, de l''addition   '.              
 GV            05  PAYMENT-ADJ-LIT-ENG-2.                                       
 GV                07  FILLER               PIC X(40) VALUE                     
 GV                    'date prepared* will appear on your next '.              
 GV                07  FILLER               PIC X(45) VALUE                     
 GV                    'Group Insurance Premium Statement.   '.                 
 GV            05  PAYMENT-ADJ-LIT-FR-2.                                        
 GV                07  FILLER               PIC X(39) VALUE                     
 GV                    'd''employ�s et de modifications, effectu'.              
 GV                07  FILLER               PIC X(46) VALUE                     
 GV                    '�s apr�s la date de pr�paration de cet �tat  '.         
 GV            05  PAYMENT-ADJ-LIT-ENG-3.                                       
 GV                07  FILLER VALUE SPACES PIC X(85).                           
 GV            05  PAYMENT-ADJ-LIT-FR-3.                                        
 GV                07  FILLER               PIC X(44) VALUE                     
 GV                    'des primes* seront indiqu�s sur le prochain '.          
 GV                07  FILLER               PIC X(41) VALUE                     
 GV                    '�tat des primes d''assurance collective.'.              
 GV            05  PAYMENT-ADJ-LIT-ENG-4.                                       
 GV                07  FILLER VALUE SPACES PIC X(85).                           
 GV            05  PAYMENT-ADJ-LIT-FR-4.                                        
 GV                07  FILLER VALUE SPACES PIC X(85).                           
 GV   * REWORDING OF STANDARD TAX LINES                                         
 GV            05  PAYMENT-TAX-LIT-ENG-1.                                       
 GV                07  FILLER               PIC X(42) VALUE                     
 GV                    'Payments and adjustments (Including Sales '.            
 GV                07  FILLER               PIC X(43) VALUE                     
 GV                    'Tax) for additions, terminations and '.                 
 GV            05  PAYMENT-TAX-LIT-FR-1.                                        
 GV                07  FILLER               PIC X(41) VALUE                     
 GV                    'Les paiements et rajustements (y compris '.             
 GV                07  FILLER               PIC X(44) VALUE                     
 GV                    'la taxe de vente), dans le cas de cessations'.          
 GV            05  PAYMENT-TAX-LIT-ENG-2.                                       
 GV                07  FILLER               PIC X(42) VALUE                     
 GV                    'changes processed after the date prepared*'.            
 GV                07  FILLER               PIC X(43) VALUE                     
 GV                    ' will appear on your next Group Insurance'.             
 GV            05  PAYMENT-TAX-LIT-FR-2.                                        
 GV                07  FILLER               PIC X(41) VALUE                     
 GV                    'd''emploi, de l''addition d''employ�s et de '.          
 GV                07  FILLER               PIC X(44) VALUE                     
 GV                    'modifications, effectu�s apr�s la date de  '.           
 GV            05  PAYMENT-TAX-LIT-ENG-3.                                       
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                    'Premium Statement.'.                                    
 GV            05  PAYMENT-TAX-LIT-FR-3.                                        
 GV                07  FILLER               PIC X(43) VALUE                     
 GV                    'pr�paration de cet �tat des primes* seront '.           
 GV                07  FILLER               PIC X(42) VALUE                     
 GV                    'indiqu�s sur le prochain �tat des primes  '.            
 GV            05  PAYMENT-TAX-LIT-ENG-4.                                       
 GV                07  FILLER VALUE SPACES PIC X(85).                           
 GV            05  PAYMENT-TAX-LIT-FR-4.                                        
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                    'd''assurance collective.'.                              
 GV   * NEW ALPHA EFT DIRECTIVE LINES                                           
 GV            05  EFT-LIT-ENG-AL-1.                                            
 GV                07  FILLER               PIC X(40) VALUE                     
 GV                    'The Total Premium due will be withdrawn '.              
 GV                07  FILLER               PIC X(21) VALUE                     
 GV                    'from your account on '.                                 
aGV                07  EFT-DATE-ENG-AL-1    PIC X(24).                          
 GV            05  EFT-LIT-FR-AL-1.                                             
 GV                07  FILLER               PIC X(41) VALUE                     
 GV                    'La prime totale due sera d�bit�e de votre'.             
 GV                07  FILLER               PIC X(11) VALUE                     
 GV                    ' compte le '.                                           
 GV                07  EFT-DATE-FR-AL-1     PIC X(33).                          
 GV            05  EFT-LIT-ENG-AL-2.                                            
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                  'Credit will be applied to next month''s premium'.        
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'statement.                            '.                
 GV            05  EFT-LIT-FR-AL-2.                                             
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'La somme sera port�e au cr�dit du proc'.                
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                   'hain relev� de primes.            '.                    
 GV            05  EFT-LIT-ENG-AL-3.                                            
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                    'Please pay as billed.                   '.              
 GV            05  EFT-LIT-FR-AL-3.                                             
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                'Veuillez nous faire parvenir le montant factur�.'.          
 GV   * NEW SIGNATURE EFT DIRECTIVE LINES                                       
 GV            05  EFT-LIT-ENG-SG-1.                                            
 GV                07  FILLER               PIC X(40) VALUE                     
 GV                    'The Total Premium due will be withdrawn '.              
 GV                07  FILLER               PIC X(21) VALUE                     
 GV                    'from your account on '.                                 
 GV                07  EFT-DATE-ENG-SG-1    PIC X(24).                          
 GV            05  EFT-LIT-FR-SG-1.                                             
 GV                07  FILLER               PIC X(41) VALUE                     
 GV                    'La prime totale due sera d�bit�e de votre'.             
 GV                07  FILLER               PIC X(11) VALUE                     
 GV                    ' compte le '.                                           
 GV                07  EFT-DATE-FR-SG-1     PIC X(33).                          
 GV            05  EFT-LIT-ENG-SG-2.                                            
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                  'Credit will be applied to next month''s premium'.        
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'statement.                            '.                
 GV            05  EFT-LIT-FR-SG-2.                                             
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'La somme sera port�e au cr�dit du proc'.                
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                   'hain relev� de primes.            '.                    
 GV            05  EFT-LIT-ENG-SG-3.                                            
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                    'Please pay as billed.                   '.              
 GV            05  EFT-LIT-FR-SG-3.                                             
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                'Veuillez nous faire parvenir le montant factur�.'.          
 GV   * NEW CORPORATE EFT DIRECTIVE LINES                                       
 GV            05  EFT-LIT-ENG-CO-1.                                            
 GV                07  FILLER               PIC X(40) VALUE                     
 GV                    'The Total Premium due will be withdrawn '.              
 GV                07  FILLER               PIC X(21) VALUE                     
 GV                    'from your account on '.                                 
 GV                07  EFT-DATE-ENG-CO-1    PIC X(24).                          
 GV            05  EFT-LIT-FR-CO-1.                                             
 GV                07  FILLER               PIC X(41) VALUE                     
 GV                    'La prime totale due sera d�bit�e de votre'.             
 GV                07  FILLER               PIC X(11) VALUE                     
 GV                    ' compte le '.                                           
 GV                07  EFT-DATE-FR-CO-1     PIC X(33).                          
 GV            05  EFT-LIT-ENG-CO-2.                                            
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                  'Credit will be applied to next month''s premium'.        
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'statement.                            '.                
 GV            05  EFT-LIT-FR-CO-2.                                             
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'La somme sera port�e au cr�dit du proc'.                
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                   'hain relev� de primes.            '.                    
 GV            05  EFT-LIT-ENG-CO-3.                                            
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                    'Please pay as billed.                   '.              
 GV            05  EFT-LIT-FR-CO-3.                                             
 GV                07  FILLER               PIC X(85) VALUE                     
 GV                'Veuillez nous faire parvenir le montant factur�.'.          
 GV2  * EFT REMINDER LINES                                                      
 GV2           05  NOEFT-LIT-ENG-1.                                             
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'A reminder you can now remit your mont'.                
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                   'hly premium by Pre-Authorized Debit.'.                  
 GV2           05  NOEFT-LIT-FR-1.                                              
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'Veuillez noter que vous pouvez mainten'.                
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                  'ant r�gler votre prime mensuelle par'.                   
 GV2           05  NOEFT-LIT-ENG-2.                                             
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'Please contact Group Benefits Customer'.                
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                   ' Service for further information.   '.                  
 GV2           05  NOEFT-LIT-FR-2.                                              
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'pr�l�vement automatique. Veuillez comm'.                
 GV2               07  FILLER               PIC X(47) VALUE                     
 GV2                   'uniquer avec le Service � la client�le pour'.           
 GV2           05  NOEFT-LIT-ENG-3.                                             
 GV2               07  FILLER VALUE SPACES  PIC X(85).                          
 GV2           05  NOEFT-LIT-FR-3.                                              
 GV2               07  FILLER               PIC X(38) VALUE                     
 GV2                   'obtenir des pr�cisions.'.                               
 GV2               07  FILLER               PIC X(47) VALUE SPACES.             
 BM   * CHQ OVERDUE NOTICE LINES                                                
 BM            05  CHQ-IMPORT-LIT-ENG-1.                                        
 BM                07  FILLER               PIC X(37) VALUE                     
 BM                'AS OF THE DATE THIS STATEMENT WAS PRE'.                     
 BM                07  FILLER               PIC X(38) VALUE                     
 BM                'PARED, THE PREMIUM DUE LAST MONTH HAS '.                    
 BM            05  CHQ-IMPORT-LIT-FR-1.                                         
 BM                07  FILLER               PIC X(36) VALUE                     
 BM                'AU MOMENT DE L''�TABLISSEMENT DE CET '.                     
 BM                07  FILLER               PIC X(39) VALUE                     
 BM                '�TAT DE COMPTE, NOUS N''AVIONS TOUJOURS'.                   
 BM            05  CHQ-IMPORT-LIT-ENG-2.                                        
 BM                07  FILLER               PIC X(37) VALUE                     
 BM                'NOT BEEN RECEIVED.  PAYMENT IS REQUIR'.                     
 BM                07  FILLER               PIC X(38) VALUE                     
 BM                'ED BY THE END OF THE MONTH TO CONTINUE'.                    
 BM            05  CHQ-IMPORT-LIT-FR-2.                                         
 BM                07  FILLER               PIC X(37) VALUE                     
 BM                'PAS RE�U LA  PRIME �CHUE LE MOIS DERN'.                     
 BM                07  FILLER               PIC X(38) VALUE                     
 BM                'IER.  CETTE PRIME DOIT ABSOLUMENT    '.                     
 BM            05  CHQ-IMPORT-LIT-ENG-3.                                        
 BM                07  FILLER               PIC X(75) VALUE                     
 BM                    'COVERAGE.                      '.                       
 BM            05  CHQ-IMPORT-LIT-FR-3.                                         
 BM                07  FILLER               PIC X(37) VALUE                     
 BM                '�TRE R�GL�E AVANT LA FIN DU MOIS POUR'.                     
 BM                07  FILLER               PIC X(38) VALUE                     
 BM                ' QUE L''ASSURANCE CONTINUE D''�TRE EN '.                    
 BM            05  CHQ-IMPORT-LIT-ENG-4.                                        
 BM                07  FILLER               PIC X(75) VALUE SPACES.             
 BM            05  CHQ-IMPORT-LIT-FR-4.                                         
 BM                07  FILLER               PIC X(75) VALUE                     
 BM                'VIGUEUR.                      '.                            
 BM   * EFT OVERDUE NOTICE LINES                                                
 BM            05  EFT-IMPORT-LIT-ENG-1.                                        
 BM                07  FILLER               PIC X(37) VALUE                     
 BM                'AS OF THE DATE THIS STATEMENT WAS PRE'.                     
 BM                07  FILLER               PIC X(38) VALUE                     
 BM                'PARED, THE PREMIUM DUE LAST MONTH HAS '.                    
 BM            05  EFT-IMPORT-LIT-FR-1.                                         
 BM                07  FILLER               PIC X(36) VALUE                     
 BM                'AU MOMENT DE L''�TABLISSEMENT DE CET '.                     
 BM                07  FILLER               PIC X(39) VALUE                     
 BM                '�TAT DE COMPTE, NOUS N''AVIONS TOUJOURS'.                   
 BM            05  EFT-IMPORT-LIT-ENG-2.                                        
 BM                07  FILLER               PIC X(37) VALUE                     
 BM                'NOT BEEN RECEIVED.  TO ENSURE CONTINU'.                     
 BM                07  FILLER               PIC X(38) VALUE                     
 BM                'ATION OF COVERAGE, TOTAL PREMIUM DUE  '.                    
 BM            05  EFT-IMPORT-LIT-FR-2.                                         
 BM                07  FILLER               PIC X(37) VALUE                     
 BM                'PAS RE�U LA  PRIME �CHUE LE MOIS DERN'.                     
 BM                07  FILLER               PIC X(38) VALUE                     
 BM                'IER.  POUR ASSURER LE MAINTIEN DE LA '.                     
 BM            05  EFT-IMPORT-LIT-ENG-3.                                        
 BM                07  FILLER               PIC X(33) VALUE                     
 BM                    'MUST BE AVAILABLE ON THE ABOVE NO'.                     
 BM                07  FILLER               PIC X(42) VALUE                     
 BM                    'TED WITHDRAWAL DATE.              '.                    
 BM            05  EFT-IMPORT-LIT-FR-3.                                         
 BM                07  FILLER               PIC X(33) VALUE                     
 BM                    'COUVERTURE, LE MONTANT DE LA PRIM'.                     
 BM                07  FILLER               PIC X(42) VALUE                     
 BM                    'E TOTALE DOIT �TRE DISPONIBLE � LA'.                    
 BM            05  EFT-IMPORT-LIT-ENG-4.                                        
 BM                07  FILLER               PIC X(75) VALUE SPACES.             
 BM            05  EFT-IMPORT-LIT-FR-4.                                         
 BM                07  FILLER               PIC X(75) VALUE                     
 BM                    'DATE DE RETRAIT SUSMENTIONN�E.   '.                     
               05  EXPLAIN-ABBREV-LIT-ENG-1.                                    
                   07  FILLER               PIC X(48) VALUE                     
                       'Y INDICATES DEPENDENT COVERAGE FOR'.                    
               05  EXPLAIN-ABREV-LIT-FR-1.                                      
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X     VALUE 'O'.                
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(45) VALUE                     
                       ' D�SIGNE LES PERSONNES � CHARGE COUVERTES PAR'.         
               05  EXPLAIN-ABREV-LIT-ENG-2.                                     
                   07  FILLER               PIC X(26) VALUE                     
                       'L - LIFE'.                                              
               05  EXPLAIN-ABREV-LIT-FR-2.                                      
                   07  FILLER               PIC X(5)  VALUE 'V - L'.            
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(20) VALUE                     
                       'ASSURANCE SUR LA VIE'.                                  
               05  EXPLAIN-ABREV-LIT-ENG-3.                                     
                   07  FILLER               PIC X(46) VALUE                     
                       'H - EXTENDED HEALTH CARE'.                              
               05  EXPLAIN-ABREV-LIT-FR-3.                                      
                   07  FILLER               PIC X(5)  VALUE 'M - L'.            
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(40) VALUE                     
                       'ASSURANCE COMPL. DE FRAIS DE SOINS M�D. '.              
               05  EXPLAIN-ABREV-LIT-ENG-4.                                     
                   07  FILLER               PIC X(35) VALUE                     
                       'D - DENTAL'.                                            
               05  EXPLAIN-ABREV-LIT-FR-4.                                      
                   07  FILLER               PIC X(5)  VALUE 'D - L'.            
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(29) VALUE                     
                       'ASSURANCE DE FRAIS DENTAIRES '.                         
               05  REP-CHG-LIT-ENG.                                             
                   07  FILLER               PIC X(32) VALUE                     
                   '     * REPORTED CHANGES *'.                                 
               05  REP-CHG-LIT-FR.                                              
                   07  FILLER               PIC X(32) VALUE                     
                   '     * MODIFICATIONS SIGNALEES *'.                          
               05  NIL-LIT-ENG.                                                 
                   07  FILLER              PIC X(10) VALUE '     NIL'.          
               05  NIL-LIT-FR.                                                  
                   07  FILLER              PIC X(10) VALUE '     NEANT'.        
               05  BALANCE-GROUP-ENG.                                           
                   07  FILLER               PIC X(36) VALUE                     
                   '     BALANCE OF GROUP'.                                     
               05  BALANCE-GROUP-FR.                                            
                   07  FILLER               PIC X(36) VALUE                     
                   '     SOLDE DES PRIMES POUR LE GROUPE'.                      
               05  STAR-LIT-2-ENG.                                              
                   07  FILLER VALUE SPACES      PIC X(49).                      
                   07  FILLER VALUE 'IMPORTANT' PIC X(16).                      
               05  STAR-LIT-2-FR.                                               
                   07  FILLER VALUE SPACES           PIC X(47).                 
                   07  FILLER VALUE 'AVIS IMPORTANT' PIC X(18).                 
               05  FILLER                   PIC X(29)  VALUE                    
                   'CURRENT MONTH TAX DUE        '.                             
               05  FILLER                   PIC X(29)  VALUE                    
                   'TAXE DE VENTE DU MOIS COURANT'.                             
               05  FILLER                   PIC X(13)  VALUE                    
                   'TOTAL DUE    '.                                             
               05  FILLER                   PIC X(13)  VALUE                    
                   'MONTANT TOTAL'.                                             
      *                                                                         
      ****    TAX REMIT STUB 1                                                  
      *                                                                         
               05  FILLER                   PIC X(31)  VALUE                    
                   'If sales tax remitted          '.                           
               05  FILLER                   PIC X(31)  VALUE                    
                   'Si le montant de la            '.                           
      *                                                                         
      ****    TAX REMIT STUB 2                                                  
      *                                                                         
               05  FILLER                   PIC X(31)  VALUE                    
                   'differs from the above,        '.                           
               05  FILLER                   PIC X(31)  VALUE                    
                   'taxe de vente remis            '.                           
      *                                                                         
      ****    TAX REMIT STUB 3                                                  
      *                                                                         
               05  FILLER                   PIC X(31)  VALUE                    
                   'please explain and             '.                           
               05  FILLER                   PIC X(31)  VALUE                    
                   'diff�re du montant             '.                           
      *                                                                         
      ****    TAX REMIT STUB 4                                                  
      *                                                                         
               05  FILLER                   PIC X(31)  VALUE                    
                   'indicate amount below.         '.                           
               05  FILLER                   PIC X(31)  VALUE                    
                   'factur�, veuillez              '.                           
      *                                                                         
      ****    TAX REMIT STUB 5                                                  
      *                                                                         
               05  FILLER                   PIC X(31)  VALUE SPACES.            
               05  FILLER                   PIC X(31)  VALUE                    
                   'fournir des details et         '.                           
      *                                                                         
      ****    TAX REMIT STUB 6                                                  
      *                                                                         
               05  FILLER                   PIC X(31)  VALUE SPACES.            
               05  FILLER                   PIC X(31)  VALUE                    
                   'pr�ciser le montant ci-dessous.'.                           
      *                                                                         
      ****    SUBJECT TO TAX                                                    
      *                                                                         
               05  FILLER                   PIC X(50)  VALUE                    
                   '* SUBJECT TO PROVINCIAL SALES TAX           '.              
               05  FILLER                   PIC X(50)  VALUE                    
                   '* SOUS RESERVE DE LA TAXE DE VENTE PROVINCIALE'.            
      *                                                                         
      ****    HOT LINE NUMBER 1                                                 
      *                                                                         
               05  FILLER                   PIC X(54)  VALUE                    
                  'For any inquiries regarding the administration  '.           
               05  FILLER                   PIC X(54)  VALUE                    
                  'Si vous avez des questions au sujet de          '.           
      *                                                                         
      ****    HOT LINE NUMBER 2                                                 
      *                                                                         
               05  FILLER                   PIC X(54)  VALUE                    
                  'of your Group Benefit Program, please call.     '.           
               05  FILLER                   PIC X(1)   VALUE                    
                  'l'.                                                          
               05  FILLER                   PIC X(1)   VALUE QUOTE.             
               05  FILLER                   PIC X(52)  VALUE                    
                  'administration de votre programme             '.             
      *                                                                         
      ****    HOT LINE NUMBER 3                                                 
      *                                                                         
               05  FILLER                   PIC X(54)  VALUE                    
                  '                                                '.           
               05  FILLER                   PIC X(1)   VALUE                    
                  'd'.                                                          
               05  FILLER                   PIC X(1)   VALUE QUOTE.             
               05  FILLER                   PIC X(52)  VALUE                    
                  'assurance collective.                         '.             
      *                                                                         
      ****    HOT LINE NUMBER 4                                                 
      *                                                                         
               05  FILLER                   PIC X(54)  VALUE                    
                  '1-800-999-9999  LOCAL CALL  - XXXXXXXXXXXXXXXXXX'.           
               05  FILLER                   PIC X(54)  VALUE                    
                  '1-800-999-9999  Appel Local - XXXXXXXXXXXXXXXXXX'.           
      *                                                                         
      ****    HOT LINE NUMBER 5                                                 
      *                                                                         
               05  FILLER                   PIC X(54)  VALUE                    
                  '1-800-999-9999  Toll Free                       '.           
               05  FILLER                   PIC X(54)  VALUE                    
                  '1-800-999-9999  Sans Frais                      '.           
      *                                                                         
      ****    END OF HOT LINE NUMBERS                                           
      *                                                                         
               05  FILLER                   PIC X VALUE 'Y'.                    
               05  FILLER                   PIC X VALUE 'O'.                    
               05  FILLER                   PIC X(5) VALUE 'AGENT'.             
               05  FILLER                   PIC X(5) VALUE 'AGENT'.             
      *                                                                         
      ****    DIVISIONAL BILLING LITERALS                                       
      *                                                                         
               05  FILLER                   PIC X(20)                           
                          VALUE 'TOTAL FOR DIVISION  '.                         
               05  FILLER                   PIC X(20)                           
                          VALUE 'TOTAL DE LA DIVISION'.                         
      *                                                                         
               05  FILLER                   PIC X(18)                           
                          VALUE 'BRANCH            '.                           
               05  FILLER                   PIC X(18)                           
                          VALUE 'BUREAU R�GIONAL   '.                           
      *                                                                         
      ****    MARKETING MESSAGES                                                
      *                                                                         
               05  M-MESS-1-E.                                                  
                   07  FILLER               PIC X(41)   VALUE                   
                       '          Are your employees getting thei'.             
                   07  FILLER               PIC X(123)   VALUE                  
                       'r correct coverage? Each month :         '.             
               05  M-MESS-1-F.                                                  
                   07  FILLER               PIC X(41)   VALUE                   
                       '          Vos employ�s re�oivent-ils leur'.             
                   07  FILLER               PIC X(41)   VALUE                   
                       's prestations mensuelles exactes? Veuille'.             
                   07  FILLER               PIC X(82)   VALUE                   
                       'z chaque mois :                          '.             
               05  M-MESS-2-E.                                                  
                   07  FILLER               PIC X(164)   VALUE                  
                       '          - CHECK your Premium Statement.'.             
               05  M-MESS-2-F.                                                  
                   07  FILLER               PIC X(22)   VALUE                   
                       '          - v�rifier l'.                                
                   07  FILLER               PIC X(1)    VALUE QUOTE.            
                   07  FILLER               PIC X(18)   VALUE                   
                       '�tat de primes et '.                                    
                   07  FILLER               PIC X(123)  VALUE                   
                       '                                         '.             
               05  M-MESS-3-E.                                                  
                   07  FILLER               PIC X(41)   VALUE                   
                       '          - SEND in salary changes for sa'.             
                   07  FILLER               PIC X(123)  VALUE                   
                       'lary based Benefits on the Change Report.'.             
               05  M-MESS-3-F.                                                  
                   07  FILLER               PIC X(41)   VALUE                   
                       '          - nous indiquer tout changement'.             
                   07  FILLER               PIC X(123)  VALUE                   
                       ' de salaire                              '.             
                                                                                
           03  REPORT-LIT-ENG-FR-REDEFINES REDEFINES                            
                                           REPORT-LIT-ENGLISH-FRENCH.           
               05  LIST-BILL-TITLE-1-SUMM-PG OCCURS 2 TIMES PIC X(60).          
               05  LIST-BILL-TITLE-1-EMP-PG  OCCURS 2 TIMES PIC X(60).          
               05  LIST-BILL-TITLE-2 OCCURS 2 TIMES PIC X(60).                  
               05  REIN-LIST-TITLE-1 OCCURS 2 TIMES PIC X(60).                  
               05  REIN-LIST-TITLE-2 OCCURS 2 TIMES PIC X(60).                  
               05  NEW-ISSUE-TITLE-1 OCCURS 2 TIMES PIC X(60).                  
               05  NEW-ISSUE-TITLE-2 OCCURS 2 TIMES PIC X(60).                  
               05  TERM-LIST-TITLE-1 OCCURS 2 TIMES PIC X(60).                  
               05  TERM-LIST-TITLE-2 OCCURS 2 TIMES PIC X(60).                  
               05  GROUP-NO-LIT      OCCURS 2 TIMES PIC X(6).                   
               05  GROUP-OFF-LIT     OCCURS 2 TIMES PIC X(6).                   
               05  NAME-LIT          OCCURS 2 TIMES PIC X(4).                   
               05  PREM-DUE-LIT      OCCURS 2 TIMES PIC X(16).                  
               05  DATE-PREP-LIT     OCCURS 2 TIMES PIC X(13).                  
               05  FILE-REF-LIT      OCCURS 2 TIMES PIC X(17).                  
               05  STUB-PLEASE       OCCURS 2 TIMES PIC X(31).                  
               05  STUB-THIS         OCCURS 2 TIMES PIC X(31).                  
               05  STUB-PAYMENT      OCCURS 2 TIMES PIC X(31).                  
               05  CURRENCY-LIT      OCCURS 2 TIMES PIC X(8).                   
               05  DUE-LAST-MTH-LIT  OCCURS 2 TIMES PIC X(31).                  
               05  TOT-DUE-LAST-MTH-LIT  OCCURS 2 TIMES PIC X(39).              
               05  PAY-REVERSE-LIT   OCCURS 2 TIMES PIC X(26).                  
               05  PAY-RECEIVE-LIT   OCCURS 2 TIMES PIC X(25).                  
               05  PAYMT-REC-LIT     OCCURS 2 TIMES PIC X(17).                  
               05  AMOUNT-OUT-LIT    OCCURS 2 TIMES PIC X(30).                  
               05  OUTSTAND-LIT      OCCURS 2 TIMES PIC X(21).                  
               05  MON-PREM-LIT      OCCURS 2 TIMES PIC X(29).                  
               05  TOT-PREM-DUE-LIT  OCCURS 2 TIMES PIC X(21).                  
               05  POLICY-COMM-LIT1  OCCURS 2 TIMES PIC X(58).                  
               05  POLICY-COMM-LIT2  OCCURS 2 TIMES PIC X(58).                  
               05  STUB-GROUP        OCCURS 2 TIMES PIC X(16).                  
               05  STUB-ACCT         OCCURS 2 TIMES PIC X(16).                  
               05  STUB-FILE-REF     OCCURS 2 TIMES PIC X(16).                  
               05  STUB-GRP-OFF      OCCURS 2 TIMES PIC X(16).                  
               05  STUB-CURRENCY     OCCURS 2 TIMES PIC X(16).                  
               05  STUB-DATE-DUE     OCCURS 2 TIMES PIC X(16).                  
               05  STUB-PREM-DUE     OCCURS 2 TIMES PIC X(16).                  
               05  STUB-TOT-PREM-DUE OCCURS 2 TIMES PIC X(16).                  
               05  STUB-TAX          OCCURS 2 TIMES PIC X(13).                  
               05  STUB-TOTAL        OCCURS 2 TIMES PIC X(16).                  
               05  CURR-POL-STAT-LIT OCCURS 2 TIMES PIC X(27).                  
               05  CERT-LIT-LINE1    OCCURS 2 TIMES PIC X(9).                   
               05  CERT-LIT-LINE2    OCCURS 2 TIMES PIC X(10).                  
               05  CLASS-LIT         OCCURS 2 TIMES PIC X(2).                   
               05  DEPENDENT-LIT     OCCURS 2 TIMES PIC X(7).                   
               05  DEP-LIT-LIFE      OCCURS 2 TIMES PIC X.                      
               05  DEP-LIT-EHC       OCCURS 2 TIMES PIC X.                      
               05  DEP-LIT-DEN       OCCURS 2 TIMES PIC X.                      
               05  TOTAL-COL-LINE1   OCCURS 2 TIMES PIC X(9).                   
               05  TOTAL-COL-LINE2   OCCURS 2 TIMES PIC X(9).                   
               05  TOTAL-SUMM-COL-LINE1   OCCURS 2 TIMES PIC X(9).              
               05  TOTAL-SUMM-COL-LINE2   OCCURS 2 TIMES PIC X(9).              
               05  TOTAL-GROUP-SUM   OCCURS 2 TIMES PIC X(5).                   
               05  LIVES-INSURED-LIT OCCURS 2 TIMES PIC X(21).                  
               05  RETURN-LIT-1      OCCURS 2 TIMES PIC X(123).                 
               05  RETURN-LIT-2      OCCURS 2 TIMES PIC X(117).                 
               05  RETURN-LIT-1-TERM OCCURS 2 TIMES PIC X(114).                 
               05  PAYMENT-ADJ-LIT-1 OCCURS 2 TIMES PIC X(85).                  
               05  PAYMENT-ADJ-LIT-2 OCCURS 2 TIMES PIC X(85).                  
               05  PAYMENT-ADJ-LIT-3 OCCURS 2 TIMES PIC X(85).                  
               05  PAYMENT-ADJ-LIT-4 OCCURS 2 TIMES PIC X(85).                  
               05  PAYMENT-TAX-LIT-1 OCCURS 2 TIMES PIC X(85).                  
               05  PAYMENT-TAX-LIT-2 OCCURS 2 TIMES PIC X(85).                  
               05  PAYMENT-TAX-LIT-3 OCCURS 2 TIMES PIC X(85).                  
               05  PAYMENT-TAX-LIT-4 OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-ALPHA-LIT-1   OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-ALPHA-LIT-2   OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-ALPHA-LIT-3   OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-SIGN-LIT-1    OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-SIGN-LIT-2    OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-SIGN-LIT-3    OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-CORP-LIT-1    OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-CORP-LIT-2    OCCURS 2 TIMES PIC X(85).                  
 GV            05  EFT-CORP-LIT-3    OCCURS 2 TIMES PIC X(85).                  
 GV2           05  NO-EFT-LIT-1      OCCURS 2 TIMES PIC X(85).                  
 GV2           05  NO-EFT-LIT-2      OCCURS 2 TIMES PIC X(85).                  
 GV2           05  NO-EFT-LIT-3      OCCURS 2 TIMES PIC X(85).                  
 BM            05  IMPORTANT-CHQ-1   OCCURS 2 TIMES PIC X(75).                  
 BM            05  IMPORTANT-CHQ-2   OCCURS 2 TIMES PIC X(75).                  
 BM            05  IMPORTANT-CHQ-3   OCCURS 2 TIMES PIC X(75).                  
 BM            05  IMPORTANT-CHQ-4   OCCURS 2 TIMES PIC X(75).                  
 BM            05  IMPORTANT-EFT-1   OCCURS 2 TIMES PIC X(75).                  
 BM            05  IMPORTANT-EFT-2   OCCURS 2 TIMES PIC X(75).                  
 BM            05  IMPORTANT-EFT-3   OCCURS 2 TIMES PIC X(75).                  
 BM            05  IMPORTANT-EFT-4   OCCURS 2 TIMES PIC X(75).                  
               05  EXPL-ABREV-LIT-1  OCCURS 2 TIMES PIC X(48).                  
               05  EXPL-ABREV-LIT-2  OCCURS 2 TIMES PIC X(26).                  
               05  EXPL-ABREV-LIT-3  OCCURS 2 TIMES PIC X(46).                  
               05  EXPL-ABREV-LIT-4  OCCURS 2 TIMES PIC X(35).                  
               05  REPORT-CHG-LIT    OCCURS 2 TIMES PIC X(32).                  
               05  NIL-LIT           OCCURS 2 TIMES PIC X(10).                  
               05  BALANCE-OF-GRP-LIT OCCURS 2 TIMES PIC X(36).                 
               05  STAR-LIT-2        OCCURS 2 TIMES PIC X(65).                  
               05  PROV-TAX-LIT      OCCURS 2 TIMES PIC X(29).                  
               05  TOTAL-DUE-LIT     OCCURS 2 TIMES PIC X(13).                  
               05  STUB-TAX-REMIT-LIT-1  OCCURS 2 TIMES PIC X(31).              
               05  STUB-TAX-REMIT-LIT-2  OCCURS 2 TIMES PIC X(31).              
               05  STUB-TAX-REMIT-LIT-3  OCCURS 2 TIMES PIC X(31).              
               05  STUB-TAX-REMIT-LIT-4  OCCURS 2 TIMES PIC X(31).              
               05  STUB-TAX-REMIT-LIT-5  OCCURS 2 TIMES PIC X(31).              
               05  STUB-TAX-REMIT-LIT-6  OCCURS 2 TIMES PIC X(31).              
               05  SUBJECT-TO-TAX-LIT    OCCURS 2 TIMES PIC X(50).              
               05  HOT-LINE-LIT1         OCCURS 2 TIMES PIC X(54).              
               05  HOT-LINE-LIT2         OCCURS 2 TIMES PIC X(54).              
               05  HOT-LINE-LIT3         OCCURS 2 TIMES PIC X(54).              
               05  HOT-LINE-LIT4         OCCURS 2 TIMES.                        
                   10 HOT-L4-PHONE-NUMBER.                                      
                      15 HOT-L4-LONG-D   PIC X.                                 
                      15 HOT-L4-DASH-1   PIC X.                                 
                      15 HOT-L4-AREA-C   PIC X(3).                              
                      15 HOT-L4-DASH-2   PIC X.                                 
                      15 HOT-L4-NUM-1    PIC X(3).                              
                      15 HOT-L4-DASH-3   PIC X.                                 
                      15 HOT-L4-NUM-2    PIC X(4).                              
                   10 FILLER             PIC X(16).                             
                   10 HOT-L4-CITY        PIC X(24).                             
               05  HOT-LINE-LIT5         OCCURS 2 TIMES.                        
                   10 HOT-L5-PHONE-NUMBER.                                      
                      15 HOT-L5-LONG-D   PIC X.                                 
                      15 HOT-L5-DASH-1   PIC X.                                 
                      15 HOT-L5-AREA-C   PIC X(3).                              
                      15 HOT-L5-DASH-2   PIC X.                                 
                      15 HOT-L5-NUM-1    PIC X(3).                              
                      15 HOT-L5-DASH-3   PIC X.                                 
                      15 HOT-L5-NUM-2    PIC X(4).                              
                   10 FILLER             PIC X(40).                             
               05  YO-CHAR               OCCURS 2 TIMES PIC X.                  
               05  AGENT-LIT             OCCURS 2 TIMES PIC X(5).               
               05  DIVISION-LIT          OCCURS 2 TIMES PIC X(20).              
               05  BRANCH-LIT            OCCURS 2 TIMES PIC X(18).              
               05  MARKET-MESSAGE-1      OCCURS 2 TIMES PIC X(164).             
               05  MARKET-MESSAGE-2      OCCURS 2 TIMES PIC X(164).             
               05  MARKET-MESSAGE-3      OCCURS 2 TIMES PIC X(164).             
                                                                                
      ******************************************************************        
      *    THESE MONTHS ARE SET UP IN THIS MANNER SO THAT ON A NORMAL           
      *    HEADING, THE FULL MONTH AND YEAR CAN BE CONCATENATED TOGETHER        
      *    IN THE REPORT.  THIS IS WHY THE LENGTH IS REQUIRED SO THAT           
      *    EXACTLY ONE SPACE IS LEFT BETWEEN THE MONTH AND YEAR.                
      ******************************************************************        
       01  LIT-MONTHS.                                                          
           03  LIT-LENGTH-MONTH-TABLE.                                          
               05  LIT-LENGTHS-ENG.                                             
                   07  FILLER        COMP-3  PIC S9(3) VALUE +8.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +9.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +6.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +6.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +4.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +5.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +5.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +7.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +10.               
                   07  FILLER        COMP-3  PIC S9(3) VALUE +8.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +9.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +9.                
               05  LIT-LENGTHS-ENG-R REDEFINES LIT-LENGTHS-ENG.                 
                   07  LIT-LENGTHS-ENGLISH OCCURS 12 TIMES PIC S9(3)            
                                                   COMP-3.                      
               05  LIT-MONTHS-ENG.                                              
                   07  FILLER              PIC X(10) VALUE 'January '.          
                   07  FILLER              PIC X(10) VALUE 'February '.         
                   07  FILLER              PIC X(10) VALUE 'March '.            
                   07  FILLER              PIC X(10) VALUE 'April '.            
                   07  FILLER              PIC X(10) VALUE 'May '.              
                   07  FILLER              PIC X(10) VALUE 'June '.             
                   07  FILLER              PIC X(10) VALUE 'July '.             
                   07  FILLER              PIC X(10) VALUE 'August '.           
                   07  FILLER              PIC X(10) VALUE 'September '.        
                   07  FILLER              PIC X(10) VALUE 'October '.          
                   07  FILLER              PIC X(10) VALUE 'November '.         
                   07  FILLER              PIC X(10) VALUE 'December '.         
               05  LIT-MONTHS-ENG-R REDEFINES LIT-MONTHS-ENG.                   
                   07  LIT-MONTHS-ENGLISH OCCURS 12 TIMES PIC X(10).            
               05  LIT-LENGTHS-FR.                                              
                   07  FILLER        COMP-3  PIC S9(3) VALUE +8.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +8.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +5.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +6.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +4.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +5.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +8.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +5.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +10.               
                   07  FILLER        COMP-3  PIC S9(3) VALUE +8.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +9.                
                   07  FILLER        COMP-3  PIC S9(3) VALUE +9.                
               05  LIT-LENGTHS-FR-R REDEFINES LIT-LENGTHS-FR.                   
                   07  LIT-LENGTHS-FRENCH OCCURS 12 TIMES PIC S9(3)             
                                                   COMP-3.                      
               05  LIT-MONTHS-FR.                                               
                   07  FILLER              PIC X(10) VALUE 'janvier '.          
                   07  FILLER              PIC X(10) VALUE 'f�vrier '.          
                   07  FILLER              PIC X(10) VALUE 'mars '.             
                   07  FILLER              PIC X(10) VALUE 'avril '.            
                   07  FILLER              PIC X(10) VALUE 'mai '.              
                   07  FILLER              PIC X(10) VALUE 'juin '.             
                   07  FILLER              PIC X(10) VALUE 'juillet '.          
                   07  FILLER              PIC X(10) VALUE 'ao�t '.             
                   07  FILLER              PIC X(10) VALUE 'septembre '.        
                   07  FILLER              PIC X(10) VALUE 'octobre '.          
                   07  FILLER              PIC X(10) VALUE 'novembre '.         
                   07  FILLER              PIC X(10) VALUE 'd�cembre '.         
               05  LIT-MONTHS-FR-R REDEFINES LIT-MONTHS-FR.                     
                   07  LIT-MONTHS-FRENCH OCCURS 12 TIMES PIC X(10).             
                                                                                
      ******************************************************************        
      *    THIS TABLE ALLOWS EASY TRANSLATION OF THE CODES ON THE               
      *    ADJUSTMENT RECORD TO A FRENCH OR ENGLISH EQUIVALENT.                 
      ******************************************************************        
       01  ADJUSTMENT-VALUES-LITERALS.                                          
           03  NUM-ADJ-VALUES              PIC S9(4) VALUE +8.                  
           03  ADJ-VALUES.                                                      
               05  FILLER                  PIC XX    VALUE 'CC'.                
               05  FILLER                  PIC XX    VALUE 'RC'.                
               05  FILLER                  PIC XX    VALUE 'TE'.                
               05  FILLER                  PIC XX    VALUE 'AD'.                
               05  FILLER                  PIC XX    VALUE 'RI'.                
               05  FILLER                  PIC XX    VALUE 'TR'.                
               05  FILLER                  PIC XX    VALUE 'DI'.                
               05  FILLER                  PIC XX    VALUE 'RE'.                
           03  ADJ-VAL REDEFINES ADJ-VALUES.                                    
               05  ADJ-TYPE    OCCURS 8 TIMES PIC XX.                           
           03  ADJUSTMENT-LITERALS.                                             
               05  FILLER                  PIC X(16) VALUE                      
                   'COVERAGE CHANGE'.                                           
               05  FILLER                  PIC X(7)  VALUE                      
                   'MODIF.D'.                                                   
               05  FILLER                  PIC X     VALUE QUOTE.               
               05  FILLER                  PIC X(8)  VALUE 'ASSURANC'.          
               05  FILLER                  PIC X(16) VALUE                      
                   'RATE CHANGE'.                                               
               05  FILLER                  PIC X(16) VALUE                      
                   'MODIF. DE TAUX'.                                            
               05  FILLER                  PIC X(16) VALUE                      
                   'TERMINATED'.                                                
               05  FILLER                  PIC X(16) VALUE                      
                   'ANNULATION'.                                                
               05  FILLER                  PIC X(16) VALUE                      
                   'ADDITION'.                                                  
               05  FILLER                  PIC X(16) VALUE                      
                   'ADDITION'.                                                  
               05  FILLER                  PIC X(16) VALUE                      
                   'REINSTATED'.                                                
               05  FILLER                  PIC X(16) VALUE                      
                   'REMISE EN VIGUER'.                                          
               05  FILLER                  PIC X(16) VALUE                      
                   'TRANSFER'.                                                  
               05  FILLER                  PIC X(16) VALUE                      
                   'TRANSFERT'.                                                 
               05  FILLER                  PIC X(16) VALUE                      
                   'DISABLED'.                                                  
               05  FILLER                  PIC X(16) VALUE                      
                   'INVALIDE       '.                                           
               05  FILLER                  PIC X(16) VALUE                      
                   'RECOVERED'.                                                 
               05  FILLER                  PIC X(16) VALUE                      
                   'RETABLI(E)      '.                                          
           03  ADJUSTMENT-LITERALS-R REDEFINES ADJUSTMENT-LITERALS.             
               05  ADJ-LIT OCCURS 8 TIMES.                                      
                   07  ADJ-LIT-LANG  OCCURS 2 TIMES PIC X(16).                  
                                                                                
      ******************************************************************        
      *    STORE THE COLUMN HEADINGS LINES, SO THAT THEY DO NOT HAVE TO         
      *    BE REBUILT FOR EACH PAGE.                                            
      *    THE FIRST TWO LINES STORED ARE ON THE DETAIL LIST                    
      *    THE NEXT TWO ARE THE HEADING ON THE TOP OF EACH PAGE                 
      ******************************************************************        
       01  TITLE-LINES.                                                         
           03  TITLE-LINE1.                                                     
               05  FILLER                    PIC X(5)  VALUE SPACES.            
               05  FILLER                    PIC X(33) VALUE SPACES.            
               05  T1-CERT-LIT1              PIC X(9).                          
               05  FILLER                    PIC X(3)  VALUE SPACES.            
               05  T1-DEP-LIT                PIC X(7).                          
               05  FILLER                    PIC X(1)  VALUE SPACES.            
               05  T1-COL-LIT1 OCCURS 10 TIMES PIC X(10).                       
           03  TITLE-LINE2.                                                     
               05  FILLER                    PIC X(5)  VALUE SPACES.            
               05  T2-NAME-LIT               PIC X(32).                         
               05  T2-CERT-LIT2              PIC X(11).                         
               05  T2-CLASS-LIT              PIC X(3).                          
               05  T2-DEP-LIFE-LIT           PIC XX.                            
               05  T2-DEP-EHC-LIT            PIC XX.                            
               05  T2-DEP-DEN-LIT            PIC XX.                            
               05  FILLER                    PIC X(1)  VALUE SPACES.            
               05  T2-COL-LIT2 OCCURS 10 TIMES PIC X(10).                       
           03  PR-HEAD1-SAVE                 PIC X(60).                         
           03  PR-HEAD2-SAVE                 PIC X(60).                         
           03  PR-BILL-CONST.                                                   
               05  FILLER VALUE '(P R A C T I C E  B I L L)' PIC X(26).         
               05  FILLER VALUE ' - REQUESTOR'               PIC X(12).         
               05  FILLER VALUE '  '                         PIC X(2).          
               05  PR-HEAD3-SAVE-REQ-E                       PIC X(15).         
               05  FILLER VALUE '     '                      PIC X(5).          
               05  FILLER VALUE '(  FACTURATION  D'          PIC X(17).         
               05  FILLER VALUE QUOTE                        PIC X.             
               05  FILLER VALUE                   'ESSAI  )' PIC X(8).          
               05  FILLER VALUE ' - REQU�RANT'               PIC X(12).         
               05  FILLER VALUE '  '                         PIC X(2).          
               05  PR-HEAD3-SAVE-REQ-F                       PIC X(15).         
               05  FILLER VALUE '     '                      PIC X(5).          
           03  PRACTICE-BILL REDEFINES PR-BILL-CONST.                           
               05  PR-HEAD3-SAVE OCCURS   2 TIMES        PIC X(60).             
                                                                                
      ******************************************************************        
      *    THE FOLLOWING TABLE IS USED TO STORE THE PRINT LINES ON THE          
      *    SUMMARY REPORT FROM THE 'DUE LAST MONTH LINE' TO EITHER THE          
      *    'TOTAL DUE THIS MONTH LINE' OR THE 'TOTAL PREMIUM DUE LINE'          
      *    (IN THE CASE OF A SUMMARY REPORT ONLY), WHICHEVER ONE IS             
      *    LAST.                                                                
      ******************************************************************        
      *    RELEASE #1.                                                          
      *    CANNOT LOAD DATE INTO SUMM-LINE-OLD-DATE ANYMORE. AFP USES           
      *    A PROPORTIONAL FONT IN THIS AREA AND DATES ON CONSECUTIVE            
      *    LINES WERE NOT LINING UP.                                            
      ******************************************************************        
       01  SUMMARY-PAGE-PRINT-LINES.                                            
           03  SUMMARY-LINES-TABLE.                                             
               05  SUMMARY-LINES OCCURS 17 TIMES.                               
                   07  SUMM-LINE-PART1.                                         
                     09  SUMM-LINE-LIT1-1    PIC X(27).                         
                     09  SUMM-LINE-OLD-DATE  PIC X(9).                          
                     09  FILLER              PIC X(3).                          
                     09  SUMXXXX.                                               
                      10  SUMM-LINE-EDIT1     PIC --,---,---.99.                
                      10  CR-VALUE            PIC X(2).                         
                   07  SUMM-TAX-HIGHLIGHT      PIC X(3).                        
                   07  FILLER                  PIC X(6).                        
                   07  SUMM-LINE-PART2.                                         
                       09  SUMM-LINE-LIT2-1    PIC X(10).                       
                       09  SUMM-LINE-LIT2-2    PIC X(11).                       
                       09  SUMM-LINE-EDIT2     PIC Z,ZZZ,ZZZ.99.                
                       09  FILLER              PIC X(4).                        
                   07  SUMM-LINE-NEW-DATE      PIC X(11).                       
                                                                                
       01  TAX-LINES-TABLE.                                                     
           05  TAX-LINES-TAB-ENTRY OCCURS 13 TIMES.                             
               10  FILLER                      PIC X(5).                        
               10  TAX-SUMM-TEXT               PIC X(85).                       
               10  FILLER                      PIC X(32).                       
               10  TAX-STUB-AREA.                                               
                   15  TAX-STUB-TAX-TEXT-E.                                     
                       20  TAX-STUB-CODE-E     PIC X(2).                        
                       20  FILLER              PIC X(1).                        
                       20  TAX-STUB-TEXT-E     PIC X(13).                       
                   15  TAX-STUB-TAX-TEXT-F REDEFINES                            
                                                TAX-STUB-TAX-TEXT-E.            
                       20  TAX-STUB-TEXT-F     PIC X(11).                       
                       20  FILLER              PIC X(1).                        
                       20  TAX-STUB-CODE-F     PIC X(2).                        
                       20  FILLER              PIC X(2).                        
                   15  TAX-STUB-TOTAL-TEXT REDEFINES                            
                                                TAX-STUB-TAX-TEXT-E             
                                               PIC X(16).                       
                   15  FILLER                  PIC X(1).                        
                   15  TAX-STUB-AMT            PIC Z,ZZZ,ZZ9.99CR.              
                                                                                
       01  PRINT-LINE.                                                          
           03  CC                            PIC X.                             
           03  PR-LINE1                      PIC X(164).                        
           03  PR-LINE2 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(41).                         
               05  P-TITLE                   PIC X(40).                         
           03  PR-LINE3 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(46).                         
               05  P-GROUP-NAME              PIC X(30).                         
           03  PR-LINE4 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(5).                          
               05  P-GRP-NUM-OFF-LIT         PIC X(8).                          
               05  P-GRP-OFFICE              PIC X(33).                         
               05  P-GRP-ACCT REDEFINES P-GRP-OFFICE.                           
                   07  P-GROUP               PIC 9(7).                          
                   07  FILLER                PIC X.                             
                   07  P-ACCT                PIC XXX.                           
GNE            05  FILLER                    PIC X(25).                         
               05  P-SUMM-LIT                PIC X(18).                         
               05  P-SUMM-FIELD.                                                
                   10  FILLER                PIC X(11).                         
                   10  P-SUMM-AST            PIC X(1).                          
                   10  FILLER                PIC X(11).                         
               05  FILLER                    PIC X(10).                         
               05  P-STUB-CONST.                                                
                   10  FILLER                PIC X(17).                         
                   10  P-STUB-FIELD.                                            
                     15  P-STUB-FIELD-AMT  PIC Z,ZZZ,ZZ9.99CR.                  
                     15  P-STUB-GROUP REDEFINES P-STUB-FIELD-AMT                
GNE                                        PIC 9(7).                            
                     15  P-STUB-ACCOUNT REDEFINES P-STUB-FIELD-AMT              
                                           PIC X(3).                            
           03  PR-LINE5 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(5).                          
               05  P-NAME-TAX.                                                  
                   07  P-NAME                PIC X(28).                         
                   07  FILLER                PIC X(1).                          
                   07  P-TAX-IND             PIC X(1).                          
                   07  P-TAX-CODE            PIC X(2).                          
               05  P-ADJUST-FIELD REDEFINES P-NAME-TAX.                         
                   07  FILLER                PIC X(2).                          
                   07  P-ADJ-LIT             PIC X(16).                 YEAR2000
                   07  FILLER                PIC X(1).                          
                   07  P-ADJ-EFF-LIT         PIC X(4).                          
                   07  P-ADJ-EFFDATE         PIC X(9).                  YEAR2000
               05  P-D90-FIELDS REDEFINES P-NAME-TAX.                           
                   07  FILLER                PIC X(2).                          
                   07  P-D90-ADJ-LIT         PIC X(16).                 YEAR2000
                   07  FILLER                PIC X(1).                          
                   07  P-D90-EFFDATE         PIC X(9).                  YEAR2000
                   07  FILLER                PIC X(1).                          
                   07  P-D90-TAX-IND         PIC X(1).                          
                   07  P-D90-TAX-CODE        PIC X(2).                          
               05  P-DIV-FIELDS REDEFINES P-NAME-TAX.                           
                   07  P-DIV-ADJ-LIT         PIC X(18).                 YEAR2000
                   07  FILLER                PIC X(1).                          
                   07  P-DIV-EFFDATE         PIC X(9).                  YEAR2000
                   07  FILLER                PIC X(1).                          
                   07  P-DIV-TAX-IND         PIC X(1).                          
                   07  P-DIV-TAX-CODE        PIC X(2).                          
               05  FILLER                    PIC X(1).                          
               05  P-CERT                    PIC Z(9).                          
               05  FILLER                    PIC X.                             
               05  P-CLASS                   PIC XX.                            
               05  FILLER                    PIC X.                             
               05  P-DEP-LIFE                PIC X.                             
               05  FILLER                    PIC X.                             
               05  P-DEP-EHC                 PIC X.                             
               05  FILLER                    PIC X.                             
               05  P-DEP-DEN                 PIC X.                             
               05  FILLER                    PIC X.                             
               05  P-COL-DATA OCCURS 10 TIMES PIC X(10).                        
           03  PR-LINE6 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(5).                          
               05  P-TOTAL-LIT               PIC X(6).                          
               05  FILLER                    PIC X(8).                          
               05  P-LIVES-INS-LIT           PIC X(21).                         
               05  P-LIVES-INS               PIC ZZZ,ZZ9.                       
           03  PR-LINE7 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(5).                          
               05  PR-SUMMARY-PAGE.                                             
                   10  PR-SUMMARY-TEXT       PIC X(85).                         
                   10  FILLER                PIC X(15).                         
               05  FILLER                    PIC X(48).                 YEAR2000
               05  PR-SUMMARY-DATE           PIC X(11).                 YEAR2000
           03  PR-LINE8 REDEFINES PR-LINE1.                                     
 BM            05  FILLER                    PIC X(48).                         
 BM            05  PR-SUMM-IMPORTANT         PIC X(75).                         
           03  PR-LINE9 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(5).                          
               05  PR-ABBREV-LIT             PIC X(49).                         
           03  PR-LINE10 REDEFINES PR-LINE1.                                    
               05  PR-X-1                    PIC X(41).                         
               05  PR-X-LIT                  PIC X(46).                         
               05  FILLER                    PIC X(29).                         
               05  PR-X-PERF                 PIC X(1).                          
               05  FILLER                    PIC X(45).                         
               05  PR-X-2                    PIC X(1).                          
           03  PR-LINE18 REDEFINES PR-LINE1.                                    
               05  PR-C-1                    PIC X(41).                         
               05  PR-C-LIT                  PIC X(46).                         
               05  FILLER                    PIC X(28).                         
               05  PR-C-PERF                 PIC X(1).                          
               05  FILLER                    PIC X(45).                         
               05  PR-C-2                    PIC X(1).                          
           03  PR-LINE22 REDEFINES PR-LINE1.                                    
               05  FILLER                    PIC X(102).                        
               05  PR-TAX-SUBJECT            PIC X(50).                         
               05  FILLER                    PIC X(2).                          
           03  PR-LINE23 REDEFINES PR-LINE1.                                    
               05  FILLER                    PIC X(11).                         
               05  PR-SUMM-NAME-ADDR         PIC X(30).                         
               05  FILLER                    PIC X(21).                         
               05  PR-SUMM-PHONE-MESSAGE     PIC X(54).                         
               05  FILLER                    PIC X(6).                          
               05  PR-SUMM-TAX-REMIT-STUB    PIC X(31).                         
           03  PR-LINE25 REDEFINES PR-LINE1.                                    
               05  FILLER                    PIC X(23).                         
               05  PR25-HEAD                 PIC X(60).                         
               05  FILLER                    PIC X(6).                          
               05  PAGE-LIT                  PIC X(5).                          
               05  OUT-PAGE                  PIC ZZ9.                           
           03  PR-LINE28 REDEFINES PR-LINE1.                                    
               05  FILLER                    PIC X(5).                          
               05  P-TOTAL-DIV-LIT           PIC X(20).                         
               05  P-DIVISION                PIC ZZ9.                           
           03  PR-LINE29 REDEFINES PR-LINE1.                                    
               05  P-DIVISION-GRP-SPACES     PIC X(57).                         
           03  PR-LINE30 REDEFINES PR-LINE1.                                    
               05  FILLER                    PIC X(5).                          
               05  P-TOTAL-DIV-LIT-E         PIC X(18).                         
               05  P-DIVISION-E              PIC ZZ9.                           
                                                                                
      ****  PAD REPORT TITLE AND MESSAGES ****.                                 
                                                                                
         01 PAD-RPT-TITLE.                                                      
 GV       05 FILLER     PIC X(01) VALUE '1'.                                    
 GV       05 FILLER     PIC X(02)    VALUE    SPACES.                           
 GV       05 FILLER     PIC X(13)    VALUE    'RUN DATE:    '.                  
 GV       05 PAD-DD     PIC 9(02).                                              
 GV       05 FILLER     PIC X(01) VALUE '-'.                                    
 GV       05 PAD-MMM    PIC X(03).                                              
 GV       05 FILLER     PIC X(01) VALUE '-'.                                    
 GV       05 PAD-YY     PIC 9(04).                                              
 GV       05 FILLER     PIC X(08)    VALUE    SPACES .                          
 GV       05 FILLER     PIC X(45)    VALUE                                      
 GV                ' THE MANUFACTURERS LIFE INSURANCE COMPANY    '.             
 GV       05 FILLER     PIC X(26)    VALUE    SPACES.                           
 GV       05 FILLER     PIC X(10)     VALUE 'PAGE     :'.                       
 GV       05 PAD-PG-NO  PIC X(04).                                              
 GV       05 FILLER     PIC X(23)    VALUE    SPACES.                           
 GV      01 PAD-RPT-TITLE2.                                                     
 GV       05 FILLER         PIC  X(01) VALUE ' '.                               
 GV       05 FILLER         PIC  X(02)    VALUE     SPACES.                     
 GV       05 FILLER         PIC  X(13)    VALUE    'RUN TIME:  '.               
 GV       05 PAD-HH         PIC  9(02).                                         
 GV       05 FILLER         PIC  X        VALUE   ':'.                          
 GV       05 PAD-MI         PIC  9(02).                                         
 GV       05 FILLER         PIC  X(15)    VALUE    SPACES .                     
 GV       05 FILLER         PIC  X(45)    VALUE                                 
 GV                      ' Group PAD Requests from GIPSY '.                     
 GV       05 FILLER         PIC X(25)     VALUE SPACES.                         
 GV       05 FILLER         PIC X(10)     VALUE 'Report ID:'.                   
 GV       05 PAD-RPT-ID     PIC X(08).                                          
 GV       05 FILLER         PIC X(22)     VALUE SPACES.                         
 GV2     01 PAD-RPT-TITLE3.                                                     
 GV       05 FILLER         PIC X(01) VALUE ' '.                                
 GV2      05 FILLER         PIC  X(02)    VALUE     SPACES.                     
 GV2      05 FILLER         PIC  X(13)    VALUE    'RUN TYPE:  '.               
 GV2      05 PAD-RUN-TYPE   PIC  X(08).                                         
 GV2      05 FILLER         PIC X(109)   VALUE  SPACES.                         
 GV2     01 PAD-RPT-HDG1.                                                       
 GV       05 FILLER         PIC X(01) VALUE '-'.                                
 GV2      05 FILLER         PIC X(92)     VALUE  SPACES.                        
 GV2      05 FILLER         PIC X(11)     VALUE  'Bank'.                        
 GV2      05 FILLER         PIC X(02)     VALUE  SPACES.                        
 GV2      05 FILLER         PIC X(13)     VALUE  'PAD'.                         
 GV2      05 FILLER         PIC X(14)     VALUE  'Sequence'.                    
 GV      01 PAD-RPT-HDG2.                                                       
 GV       05 FILLER         PIC X(01) VALUE ' '.                                
 GV       05 FILLER         PIC X(02)    VALUE     SPACES.                      
 GV       05 FILLER         PIC X(13)     VALUE  'Group/Account'.               
 GV       05 FILLER         PIC X(08)     VALUE  SPACES.                        
 GV       05 FILLER         PIC X(30)     VALUE  'Group Name'.                  
 GV       05 FILLER         PIC X(04)     VALUE  SPACES .                       
 GV       05 FILLER         PIC X(10)     VALUE  'Eff Date  '.                  
 GV       05 FILLER         PIC X(11)     VALUE  SPACES .                       
 GV       05 FILLER         PIC X(10)     VALUE  'PAD Amount'.                  
 GV       05 FILLER         PIC X(06)     VALUE  SPACES.                        
 GV       05 FILLER         PIC X(06)     VALUE  'Status'.                      
 GV       05 FILLER         PIC X(07)     VALUE  SPACES.                        
 GV2      05 FILLER         PIC X(06)     VALUE  'Status'.                      
 GV2      05 FILLER         PIC X(07)     VALUE  SPACES.                        
 GV       05 FILLER         PIC X(11)     VALUE  'Id'.                          
 GV       05 FILLER         PIC X(01)     VALUE  SPACES.                        
 GV      01 PAD-RPT-DETL1.                                                      
 GV       05 FILLER         PIC X(01) VALUE ' '.                                
 GV       05 FILLER         PIC X(02)    VALUE     SPACES.                      
GNE       05 PAD-RPT-GROUP  PIC 9(07).                                          
 GV       05 FILLER         PIC X(02)    VALUE  SPACES.                         
 GV       05 PAD-ACCOUNT    PIC 9(03).                                          
 GV       05 FILLER         PIC X(09)    VALUE  SPACES.                         
 GV       05 PAD-GRP-NAME   PIC X(32).                                          
 GV       05 FILLER         PIC X(02)    VALUE  SPACES.                         
 GV       05 PAD-EFF-DT.                                                        
 GV          10 PAD-EFF-DD     PIC X(02).                                       
 GV          10 PAD-EFF-FIL1   PIC X(01)  VALUE '-'.                            
 GV          10 PAD-EFF-MMM    PIC X(03).                                       
 GV          10 PAD-EFF-FIL2   PIC X(01)  VALUE '-'.                            
 GV          10 PAD-EFF-YYYY   PIC X(04).                                       
 GV       05 FILLER         PIC X(06)     VALUE  SPACES.                        
 GV       05 PAD-AMT        PIC $$$,$$$,$$9.99-.                                
 GV       05 FILLER         PIC X(05)     VALUE  SPACES.                        
 GV2      05 PAD-BI-STATUS  PIC X(10).                                          
 GV2      05 FILLER         PIC X(03)     VALUE  SPACES.                        
 GV2      05 PAD-STATUS     PIC X(13).                                          
 GV       05 PAD-SEQNO      PIC X(14).                                          
 BP      01 PAD-RPT-SUBTOTL.                                                    
 GV       05 ST-CTL     PIC X(01).                                              
 BP       05 FILLER         PIC X(02)     VALUE  SPACES.                        
 BP       05 PAD-ST-NM      PIC X(25).                                          
 BP       05 FILLER         PIC X(05)     VALUE  SPACES .                       
 BP       05 PAD-ST-REC     PIC Z,ZZZ,ZZ9.                                      
 BP       05 FILLER         PIC X(06)     VALUE  SPACES.                        
 BP       05 PAD-ST-AMT     PIC $$$,$$$,$$9.99-.                                
 BP       05 FILLER         PIC X(72)     VALUE  SPACES.                        
 GV      01 PAD-RPT-SPACES.                                                     
 GV       05 FILLER          PIC X(133)    VALUE  SPACES.                       
 GV                                                                             
 GV      01 WS-RECORD-COUNT    PIC 9(5)      VALUE   ZEROS.                     
 GV      01 WS-LINE-CT         PIC 9(2)      VALUE   ZEROS.                     
 GV      01 WS-PAD-SUMMARY-TOTALS  VALUE ZEROES.                                
 GV       05 WS-PAD-PG-NO           PIC 9(4).                                   
 GV       05 WS-PAD-CMP-REC         PIC 9(4).                                   
 GV       05 WS-PAD-CMP-AMT         PIC S9(9)V99.                               
 GV       05 WS-PAD-SUSP-REC        PIC 9(4).                                   
 GV       05 WS-PAD-SUSP-AMT        PIC S9(9)V99.                               
 GV       05 WS-PAD-INEFF-REC       PIC 9(4).                                   
 GV       05 WS-PAD-INEFF-AMT       PIC S9(9)V99.                               
 GV       05 WS-PAD-TRMD-REC        PIC 9(4).                                   
 GV       05 WS-PAD-TRMD-AMT        PIC S9(9)V99.                               
 GV       05 WS-PAD-INFUT-REC       PIC 9(4).                                   
 GV       05 WS-PAD-INFUT-AMT       PIC S9(9)V99.                               
 GV       05 WS-PAD-NPAD-REC        PIC 9(4).                                   
 GV       05 WS-PAD-NPAD-AMT        PIC S9(9)V99.                               
 GV      01 WS-SYSTEM-DATE.                                                     
 GV         05 WS-SYSTEM-YY       PIC  X(04).                                   
 GV         05 WS-SYSTEM-MM       PIC  X(02).                                   
 GV         05 WS-SYSTEM-DD       PIC  X(02).                                   
 GV      01 WS-SYSTEM-DATE1.                                                    
 GV         05 WS-SYSTEM-YY1      PIC 9(04).                                    
 GV         05 WS-SYSTEM-MM1      PIC 9(02).                                    
 GV         05 WS-SYSTEM-DD1      PIC 9(02).                                    
 GV      01 WS-YEAR-ALLN.                                                       
 GV         05 WS-CC-ALLN         PIC  9(02).                                   
 GV         05 WS-YY-ALLN         PIC  9(02).                                   
 GV      01 WS-SYSTEM-TIME        PIC 9(08).                                    
 GV                                                                             
 GV      01 GAEDATSR          PIC  X(08)  VALUE 'GAEDATSR'.                     
 GV      01 GC2TODAY          PIC  X(08)  VALUE 'GC2TODAY'.                     
 GV      01 GC2DATE           PIC  X(08)  VALUE 'GC2DATE '.                     
 GV      01 WS-NOT-FOUND      PIC  X(10)  VALUE 'NOT FOUND '.                   
 GV      01 WS-TERMINATED     PIC  X(10)  VALUE 'TERMINATED'.                   
 GV      01 WS-IN-EFFECT      PIC  X(10)  VALUE 'ACTIVE    '.                   
 GV      01 WS-IN-FUTURE      PIC  X(10)  VALUE 'IN FUTURE '.                   
 GV      01 WS-COMPLETE       PIC  X(08)  VALUE 'COMPLETE'.                     
 GV      01 WS-NO-UPDATE      PIC  X(13)  VALUE 'N/R       '.                   
 GV      01 WS-SUSPENDED      PIC  X(10)  VALUE 'SUSPENDED '.                   
 GV      01 WS-ABORTED        PIC  X(10)  VALUE 'ABORTED   '.                   
 GV      01 WS-REQUEST        PIC  X(10)  VALUE 'REQUEST   '.                   
 GV2     01 WS-SLASH          PIC  X(01)  VALUE '-'.                            
 GV2     01 WS-COPY      PIC  X(08)  VALUE 'COPY'.                              
 GV2     01 WS-PRACTICE  PIC  X(08)  VALUE 'PRACTICE'.                          
 GV2     01 WS-SUMMARY   PIC  X(08)  VALUE 'SUMMARY'.                           
 GV2     01 WS-REGULAR   PIC  X(08)  VALUE 'REGULAR'.                           
 GV      01 WS-TOTAL-PREM-DUE      COMP-3      PIC S9(7)V99                     
 GV                                       VALUE ZEROES.                         
 GV                                                                             
 GV      01 WS-SYSTEM-DATE-ALL.                                                 
 GV         05 WS-SYSTEM-CC      PIC  9(02).                                    
 GV         05 WS-SYSTEM-DT-REST PIC  9(06).                                    
 GV      01 WS-SYSTEM-DATE-ALLN.                                                
 GV         05 WS-SYSTEM-DD-ALLN PIC  9(02).                                    
 GV         05 FILLER            PIC  X(01)  VALUE '/'.                         
 GV         05 WS-SYSTEM-MM-ALLN PIC  9(02).                                    
 GV         05 FILLER            PIC  X(01)  VALUE '/'.                         
 GV         05 WS-SYSTEM-CC-ALLN PIC  9(02).                                    
 GV         05 WS-SYSTEM-YY-ALLN PIC  9(02).                                    
 GV      01 WS-SYSTEM-TIME-ALLN.                                                
 GV         05 WS-SYSTEM-HH-ALLN    PIC  9(02).                                 
 GV         05 WS-SYSTEM-MI-ALLN    PIC  9(02).                                 
 GV         05 WS-SYSTEM-TI-REST    PIC  9(04).                                 
 GV                                                                             
 GV      01 PAD-REQUEST-PARMS.                                                  
 GV                              COPY GWEFLPDR.                                 
 GV                                                                             
 GV   *  GC2DATE DYNAMICALLY LOAD DATE MANIPULATOR                              
 GV      01 GAC-DATE-PARMS.                                                     
 GV                              COPY GARDATEP.                                 
 GV                                                                             
 GV   *  STANDARD VERBS FOR  DATA SERVICE                                       
 GV      01 DATA-SERVICE-VERBS.                                                 
 GV                              COPY GARDSVRB.                                 
 GV                                                                             
 GV   *  STANDARD SERVICE FOR "GAEDATSR" CALL                                   
         01 ICBM.                                                               
                                 COPY ICBM.                                     
 GV                                                                             
 GV   *  PAD REPORT FILE                                                        
 GV      01 PADRPT-FILE-CONTROLS.                                               
 GV         05 PADRPT-INFO-LR                                                   
 GV              VALUE 'PRINT-DATA-032     PAD REPORT FILE ' PIC X(35).         
 GV                                                                             
 GV      01 EFTPADR-WORK-FIELDS.                                                
 GV       05 WS-PAD-DTLS-FOUND-SW       PIC X(01) VALUE 'N'.                    
 GV         88  PAD-DETAILS-PRINTED     VALUE 'Y'.                              
 GV       05 PAD-GROUP-ACCT.                                                    
 GV         10 PAD-GROUP              PIC 9(06).                                
 GV         10 PAD-ACCT               PIC X(03).                                
                                                                                
      *01  GFMBILLING-RECORD-2D.                                                
GNE             COPY GFMBR2D7.                                                  
                                                                                
      *01  GFMBILLING-RECORD-2E.                                                
GNE        COPY GFMBR2E7.                                                       
                                                                                
      *01  GBC-BILL-CURR-RECORD.                                                
GNE        COPY GBILLCU7.                                                       
                                                                                
      *01  GBA-BILL-ADJ-RECORD.                                                 
GNE        COPY GBILLAD7.                                                       
                                                                                
      *01  GBILLING-PAYMENT-RECORD.                                             
GNE        COPY GBILLPA7.                                                       
                                                                                
      *01  GFMEDD90-ADJUST-RECORD.                                              
GNE        COPY GD90ADJ7.                                                       
                                                                                
GNE    01  SAVE-TAPE-LENGTH                  PIC S9(4)  COMP.                   
GNE    01  SAVE-TAPE-RETURN                  PIC S9(1)  COMP-3.                 
                                                                                
GNE    01  TAPE-REC-FILLER23-REC.                                               
GNE        05  TAPE-REC-FILLER23.                                               
GNE            07  TAPE-REC-F23-TO-TAX-CD    PIC X(84).                         
GNE            07  TAPE-REC-F23-FILLER       PIC X(23).                         
GNE            07  TAPE-REC-F23-CODE-CNT     PIC S9(3) COMP-3.                  
GNE            07  TAPE-REC-F23-AF-CD-CNT    PIC X(21).                         
GNE            07  TAPE-REC-F23-REMAINDER    PIC X(6469).                       
                                                                                
GNE    01  TAPE-REC-FILLER22-REC.                                               
GNE        05  TAPE-REC-FILLER22.                                               
GNE            07  TAPE-REC-F22-TO-TAX-CD    PIC X(84).                         
GNE            07  TAPE-REC-F22-FILLER       PIC X(22).                         
GNE            07  TAPE-REC-F22-CODE-CNT     PIC S9(3) COMP-3.                  
GNE            07  TAPE-REC-F22-AF-CD-CNT    PIC X(21).                         
GNE            07  TAPE-REC-F22-AF-SPACE     PIC X     VALUE SPACE.             
GNE            07  TAPE-REC-F22-REMAINDER    PIC X(6469).                       
                                                                                
       01  EXTRACT-RECORD.                                                      
           05  EXT-LENGTH        COMP        PIC S9(4).                         
           05  FILLER      VALUE LOW-VALUES  PIC XX.                            
           05  FILLER      VALUE SPACES      PIC X(4).                          
           05  EXT-PRODUCT                   PIC X.                             
           05  EXT-BRANCH                    PIC X(5).                          
           05  FILLER      VALUE SPACES      PIC X(5).                          
           05  EXT-AGENT                     PIC X(6).                          
           05  EXT-RECORD                    PIC X(7000).                       
                                                                                
      *01  GTELENOS.                                                            
           COPY GTELENOS.                                                       
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GWCDUMP                      PIC X(8)  VALUE 'GWCDUMP'.          
MAN07      05  TLUCOBD                      PIC X(8)  VALUE 'TLUCOBD'.          
MAN07      05  GACBMAS7                     PIC X(8)  VALUE 'GACBMAS7'.         
MAN07  COPY GWRDUMP.                                                            
       LINKAGE SECTION.                                                         
       01  TAPE-REC.                                                            
           03  TAPE-LENGTH     COMP                PIC S9(4).                   
           03  FILLER                              PIC X(2).                    
           03  T-REC-TYPE                          PIC X.                       
           03  T-PRODUCT                           PIC X.                       
           03  T-GROUP-OFFICE                      PIC XXXXX.                   
GNE        03  T-GROUP         COMP-3              PIC S9(7).                   
           03  T-ACCT                              PIC XXX.                     
           03  T-DIVISION      COMP-3              PIC S9(3).                   
           03  T-ORD                               PIC X.                       
           03  T-DETAIL.                                                        
               05  T-MESS.                                                      
                   07  T-CERT-R    COMP-3          PIC S9(9).                   
                   07  T-NAME-R                    PIC X(25).                   
               05  T-MESSL  REDEFINES  T-MESS.                                  
                   07  T-NAME-Q                    PIC X(25).                   
                   07  T-CERT-Q    COMP-3          PIC S9(9).                   
           03  T-IDENT                             PIC X.                       
           03  FILLER                              PIC X(443).                  
           03  T-BRANCH                            PIC X(5).                    
           03  T-RESIDENCE                         PIC XX.                      
           03  T-AGENT                             PIC X(6).                    
           03  T-REC-REST                          PIC X(6091).                 
                                                                                
       01  MISC-AREA.                                                           
           03  FILLER                              PIC X(4).                    
           03  HI-DATE                             PIC X(4).                    
           03  STAT-DATE                           PIC X(4).                    
           03  PREM-DATE                           PIC X(4).                    
           03  R-RESTART.                                                       
               05  R-REC-TYPE                      PIC X.                       
               05  R-FORM                          PIC X.                       
GNE            05  R-GROUP                         PIC 9(7).                    
               05  R-ACCT                          PIC XXX.                     
GNE        03  FILLER                              PIC X(4).                    
      *01  GPRPRINT.                                                            
           COPY GPRPRINT.                                                       
                                                                                
      *01  GPRTPARM.                                                            
           COPY GPRTPARM.                                                       
                                                                                
      *01  GPRACCUM.                                                            
           COPY GPRACCUM.                                                       
                                                                                
       01  GO-TO-SW                PIC S9      COMP-3.                          
                                                                                
       01  COPY-INDICATOR          PIC X.                                       
                                                                                
       01  CLOSE-FILES-FLAG        PIC X.                                       
                                                                                
       PROCEDURE DIVISION      USING   TAPE-REC                                 
                                       MISC-AREA                                
                                       GPRPRINT                                 
                                       GPRTPARM                                 
                                       GPRACCUM                                 
                                       GO-TO-SW                                 
                                       COPY-INDICATOR                           
                                       CLOSE-FILES-FLAG.                        
      ******************************************************************        
      *    IF CLOSE-FILES-FLAG = 'Y' THEN GPRINTAL CALLED WANTING               
      *    SYS053 AND SYS054 CLOSED. ONLY NECESSARY WHEN GPRBILLS               
      *    NOT CALLED BEFORE BECAUSE NO RECTYPE '2' EXISTED.                    
      ******************************************************************        
           IF  CLOSE-FILES-FLAG = 'Y'                                           
               GO TO PROGRAM-EXIT.                                              
                                                                                
      ******************************************************************        
      *    INITIALIZATION                                                       
      *    - SET UP PRINT-LINE, PREV KEY                                        
      *    - CALL GNUMTABL TO GET THE LOW AND HIGH COV CODES FOR EHC AND        
      *      DENTAL                                                             
      *    - STORE THE RESTART INFO. IF REQUIRED                                
      *    - WRITE THE PAD-REPORT HEADINGS AND OPEN THE PAD-RPT FILE.           
      ******************************************************************        
      *                                                                         
      *  MOVE ERROR REC TYPE '2' TO ERROR FILE   BY MARCUS                      
      *                                                                         
           MOVE  '2'   TO  E-REC-TYPE.                                          
           MOVE +0 TO EXT-RETURN.                                               
           MOVE '0000' TO  PROGRAM-LINKAGE-STATUS.                              
                                                                                
 GV        CALL GC2TODAY  USING WS-SYSTEM-DATE.                                 
 GV        ACCEPT  WS-SYSTEM-TIME   FROM   TIME.                                
                                                                                
 GV        MOVE  'BB1E'               TO     VDATE-REQUEST-AREA                 
 GV        MOVE WS-SYSTEM-DATE        TO     VDATE1-YYYYMMDD.                   
 GV        CALL GC2DATE USING GAC-DATE-PARMS.                                   
                                                                                
 GV        MOVE VDATE-EXT-DAY         TO  PAD-DD.                               
 GV        MOVE VDATE-EXT-MONTH       TO  PAD-MMM.                              
 GV        MOVE VDATE-EXT-YEAR        TO  PAD-YY.                               
                                                                                
 GV        MOVE WS-SYSTEM-TIME       TO  WS-SYSTEM-TIME-ALLN.                   
 GV        MOVE WS-SYSTEM-HH-ALLN    TO   PAD-HH.                               
 GV        MOVE WS-SYSTEM-MI-ALLN    TO   PAD-MI.                               
 GV        MOVE PADRPT-INFO-LR       TO   LOGICAL-RECORD-NAME.                  
 GV        MOVE 'GPRBILLS'           TO   ICBM-PROGRAM-NAME.                    
 GV                                                                             
E42   ******************************************************************        
E42   *  SET-UP LOGIC FOR GENERAL INFO FOR THE PDF EXTRACT FILE                 
E42   ******************************************************************        
E42        PERFORM 2100-START-OUTPUT THRU 2100-START-OUTPUT-EXIT.               
                                                                                
      ******************************************************************        
      *  SET LINE COUNT TO MAXIMUM TO PRINT FIRST HEADING IF ANY                
      *  DETAIL LINES ARE FOUND                                                 
      ******************************************************************        
                                                                                
 GV        MOVE 66                   TO   WS-LINE-CT.                           
                                                                                
       GPRBILLS-STARTUP.                                                        
           MOVE SPACES TO PRINT-LINE.                                           
           MOVE  LOW-VALUES    TO  PREV-KEY.                                    
           CALL 'GNUMTABL' USING  GNUM-TABLE-NO                                 
                                  GNUM-EHC-KEY                                  
                                  GNUM-RETURN.                                  
           MOVE COV-CODE-MIN TO EHC-CODE-MIN.                                   
           MOVE COV-CODE-MAX TO EHC-CODE-MAX.                                   
           CALL 'GNUMTABL' USING  GNUM-TABLE-NO                                 
                                  GNUM-DEN-KEY                                  
                                  GNUM-RETURN.                                  
           MOVE COV-CODE-MIN TO DEN-CODE-MIN.                                   
           MOVE COV-CODE-MAX TO DEN-CODE-MAX.                                   
           IF COPY-INDICATOR EQUAL ' '                                          
           IF T-REC-TYPE EQUAL '2'                                              
           IF T-ORD EQUAL 'D'                                                   
              IF ( T-PRODUCT EQUAL '1' OR '2' ) THEN                            
                   MOVE SPACES              TO EXT-RECORD                       
                   MOVE TAPE-REC            TO EXT-RECORD                       
                   MOVE T-PRODUCT           TO EXT-PRODUCT                      
                   MOVE T-BRANCH            TO EXT-BRANCH                       
                   MOVE T-AGENT             TO EXT-AGENT                        
                   COMPUTE EXT-LENGTH = TAPE-LENGTH + 25                        
           CALL 'DLSWRITE' USING EXT-SYS075     EXT-RETURN                      
                                 EXTRACT-RECORD EXT-RECSIZE                     
                                 EXT-BLKSIZE    EXT-FORMAT                      
                                 EXT-SYS075-COUNT.                              
           IF  R-REC-TYPE  NOT EQUAL TO  '2'                                    
                 OR  R-FORM  EQUAL TO  HIGH-VALUES                              
               MOVE  R-RESTART   TO  STORE-RESTART                              
               GO TO CHECK-SUMMARY-RECORD.                                      
           IF  R-GROUP  NOT  NUMERIC                                            
               MOVE  ZEROS   TO  R-GROUP.                                       
           MOVE  R-REC-TYPE  TO  SR-REC-TYPE.                                   
           MOVE  R-FORM      TO  SR-FORM.                                       
           MOVE  R-GROUP     TO  SR-GROUP.                                      
           MOVE  R-ACCT      TO  SR-ACCT.                                       
      ******************************************************************        
      *    THIS SECTION CHECKS THAT THE RECORD CURRENTLY IN STORAGE IS          
      *    A SUMMARY RECORD.  IF IT IS NOT IT GENERATES AN ERROR AND            
      *    GO TO A ROUTINE WHICH READS RECORDS FROM TAPE UNTIL IT               
      *    FINDS THE NEXT GROUP/ACCT.                                           
      *  - IF THE RECORD SHOULD NOT BE PRINTED BECAUSE IT DOESN'T               
      *    SATISFY THE RESTART CRITERIA, FIND THE NEXT GROUP/ACCT.              
      *  - BYPASS THOSE RECORDS WHICH ARE SELF-BILLED, OR SELF ADMIN            
      *    OR HAVE 'O' IN STATEMENT TYPE (OTHER REPORTS).                       
      ******************************************************************        
       CHECK-SUMMARY-RECORD.                                                    
      *    Write out finishing touches, if necessary.                           
E42        PERFORM 5900-FINISH-DETAIL THRU 5900-FINISH-DETAIL-EXIT.             
E42        PERFORM 3900-FINISH-GROUP  THRU 3900-FINISH-GROUP-EXIT.              
           MOVE  T-GROUP       TO  CURR-GROUP.                                  
           MOVE  T-ACCT        TO  CURR-ACCT.                                   
           MOVE  T-REC-TYPE    TO  CURR-REC-TYPE.                               
      *                                                                         
      *  SET UP HOLD FIELDS AT THE RIGHT TIME       MARCUS                      
      *                                                                         
           MOVE  T-PRODUCT     TO  HOLD-PCODE.                                  
           MOVE  T-GROUP-OFFICE TO  HOLD-OFFICE.                                
           IF T-ORD EQUAL 'D'                                                   
              MOVE SPACES   TO GFMBILLING-RECORD-2D                             
              MOVE TAPE-REC TO GFMBILLING-RECORD-2D                             
           ELSE                                                                 
              MOVE SPACES TO CURR-COUNTRY                                       
              MOVE 'M40' TO E-CODE                                              
              PERFORM ERR-RTN                                                   
              GO TO FIND-NEXT-SUMMARY-RECORD.                                   
           MOVE GFM2D-COUNTRY   TO CURR-COUNTRY.                                
           MOVE GFM2D-REQUESTOR TO PR-HEAD3-SAVE-REQ-E.                         
           MOVE GFM2D-REQUESTOR TO PR-HEAD3-SAVE-REQ-F.                         
           IF GFM2D-COUNTRY NOT EQUAL '0'                                       
              MOVE '1' TO CURR-TYPE                                             
              MOVE 'AD' TO QDATE-PARM                                   YEAR2000
              MOVE 1 TO LANG-SUB                                                
           ELSE                                                                 
              IF GFM2D-LANGUAGE EQUAL 'F'                                       
                 MOVE 2 TO LANG-SUB                                             
                 MOVE '3' TO CURR-TYPE                                          
                 MOVE 'AF' TO QDATE-PARM                                YEAR2000
              ELSE                                                              
                 MOVE 1 TO LANG-SUB                                             
                 MOVE '2' TO CURR-TYPE                                          
                 MOVE 'AD' TO QDATE-PARM.                               YEAR2000
           IF SAVE-RESTART NOT GREATER THAN CURR-KEY                            
              NEXT SENTENCE                                                     
           ELSE                                                                 
              GO TO FIND-NEXT-SUMMARY-RECORD.                                   
           IF GFM2D-BILLING-FORMAT-TYPE EQUAL 'SA' OR 'SB' OR                   
              GFM2D-STATEMENT-TYPE EQUAL 'O'                                    
              GO TO FIND-NEXT-SUMMARY-RECORD.                                   
      *                                                                         
      *    NEXT RECORD READ SHOULD BE BILLING INFORCE RECORD, IF NOT            
      *    PRODUCE AN ERROR.                                                    
      *                                                                         
E422       PERFORM 3100-START-GROUP   THRU 3100-START-GROUP-EXIT.               
           PERFORM READ-RECORD THRU READ-RECORD-EXIT.                           
           IF (TAPE-RETURN NOT EQUAL ZEROES) OR                                 
              (T-REC-TYPE NOT EQUAL '2')                                        
               MOVE 'M40' TO E-CODE                                             
               PERFORM ERR-RTN                                                  
E422           PERFORM 3200-STUB-RCD THRU 3200-STUB-RCD-EXIT                    
               GO TO PROGRAM-EXIT.                                              
           IF (T-GROUP NOT EQUAL CURR-GROUP) OR                                 
              (T-ACCT NOT EQUAL CURR-ACCT)                                      
               MOVE 'M40' TO E-CODE                                             
               PERFORM ERR-RTN                                                  
E422           PERFORM 3200-STUB-RCD THRU 3200-STUB-RCD-EXIT                    
               GO TO CHECK-SUMMARY-RECORD.                                      
           IF T-ORD NOT EQUAL 'E'                                               
               MOVE 'M40' TO E-CODE                                             
               PERFORM ERR-RTN                                                  
E422           PERFORM 3200-STUB-RCD THRU 3200-STUB-RCD-EXIT                    
               GO TO FIND-NEXT-SUMMARY-RECORD.                                  
           MOVE TAPE-REC TO GFMBILLING-RECORD-2E.                               
      *********                                                                 
      * CHECK GIPSY MASTER BILLING TRAILER FOR CURRENT TRAILER                  
      * THEN CHECK GBICERT-HOLDER (CURRENT) IF IT EQUALS +0                     
      *                                                                         
      *********                                                                 
           MOVE +2         TO GMP-FUNC-CODE.                                    
           MOVE LOW-VALUES TO GMP-SEARCH-ARG.                                   
           MOVE SPACES     TO GMP-ERROR-CODE.                                   
           MOVE T-GROUP    TO GMP-SA-GROUP.                                     
           MOVE T-ACCT     TO GMP-SA-ACCT.                                      
           PERFORM CALL-GACCDMAS THRU CALL-GACCDMAS-EXIT                        
           IF GMP-ERROR-CODE = SPACES                                           
              IF GBITRIDENT = '080'                                             
                 IF GBINO-HIST-SEG GREATER THAN +0                              
                    IF GBICERT-HOLDERS (GBINO-HIST-SEG) NUMERIC                 
                       IF GBICERT-HOLDERS (GBINO-HIST-SEG) = +0                 
                          IF GGIACCOUNT-STATUS NOT = '20' AND                   
                             GGIACCOUNT-STATUS NOT = '23' AND                   
                             GGIACCOUNT-STATUS NOT = '24' AND                   
                             GGIACCOUNT-STATUS NOT = '25' AND                   
                             GGIACCOUNT-STATUS NOT = '26'                       
                             MOVE 'M50' TO E-CODE                               
                             PERFORM ERR-RTN                                    
                             IF GGIACCOUNT-STATUS = '00'                        
                             OR GGIACCOUNT-STATUS = '01'                        
                                NEXT SENTENCE                                   
                             ELSE                                               
                                GO TO FIND-NEXT-SUMMARY-RECORD                  
                          ELSE                                                  
      *    NOT TERM POLICY           , NO RESPONSE REQUIRED                     
                             NEXT SENTENCE                                      
                       ELSE                                                     
      *    BILL HIST CERT HOLDERS > 0, NO RESPONSE REQUIRED                     
                          NEXT SENTENCE                                         
                    ELSE                                                        
      *    NO BILL HIST CERT HOLDERS, NO RESPONSE REQUIRED                      
                        NEXT SENTENCE                                           
                 ELSE                                                           
      *    NO BILL HIST SEGMENT,   NO RESPONSE REQUIRED                         
                    NEXT SENTENCE                                               
              ELSE                                                              
      *    NO BILL TRAILER,   NO RESPONSE REQUIRED                              
                 NEXT SENTENCE                                                  
           ELSE                                                                 
      *    GACCDMAS ERRCODE,  RESPONSE REQUIRED                                 
              MOVE GMP-SA-GROUP     TO ERROR-GROUP                              
              MOVE GMP-SA-ACCT      TO ERROR-ACCT                               
              MOVE GMP-ERROR-CODE   TO ERROR-CODE                               
              MOVE MASTER-RECORD-START TO WTL-MESSAGE                           
              CALL 'WTL' USING WTL-MESSAGE-PARMS                                
                               WTL-FLAG                                         
                               WTL-REPLY                                        
GNE   *%      CALL 'ZPARDUMP' USING ZPARDUMP-FUNC                               
      *%                            MASTER-RECORD-START                         
      *%                            MASTER-RECORD-END.                          
MAN07         MOVE 'GPRBILLS' TO GWRDUMP-PROGRAM-NAME                           
MAN07         CALL GWCDUMP USING ICBM                                           
MAN07                            GWRDUMP.                                       
           GO TO BUILD-SUMMARY-PAGE.                                            
      *----------------------------------------------------------------*        
      *  - KEEP READING RECORDS FROM THE INPUT FILE UNTIL THE GROUP/   *        
      *    ACCT READ DOES NOT MATCH THE STORED GROUP/ACCT.             *        
      *  - ONCE THIS HAPPENS GO TO CHECK THE SUMMARY RECORD            *        
      *----------------------------------------------------------------*        
       FIND-NEXT-SUMMARY-RECORD.                                                
           PERFORM READ-RECORD THRU READ-RECORD-EXIT.                           
           IF (TAPE-RETURN NOT EQUAL ZEROES) OR                                 
              (T-REC-TYPE NOT EQUAL '2')                                        
               GO TO PROGRAM-EXIT.                                              
           IF (T-GROUP NOT EQUAL CURR-GROUP) OR                                 
              (T-ACCT NOT EQUAL CURR-ACCT)                                      
               GO TO CHECK-SUMMARY-RECORD.                                      
           GO TO FIND-NEXT-SUMMARY-RECORD.                                      
                                                                                
      *----------------------------------------------------------------*        
      *  - BUILD THE REQUIRED INFORMATION TO BE USED IN PRINTING THE   *        
      *    SUMMARY PAGES                                               *        
      *----------------------------------------------------------------*        
       BUILD-SUMMARY-PAGE.                                                      
      *----------------------------------------------------------------*        
      *  - BUILD THE DATE FIELDS FOR THE SUMMARY PAGE TITLES           *        
      *----------------------------------------------------------------*        
E42        PERFORM 3500-EXTRACT-GROUP THRU 3500-EXTRACT-GROUP-EXIT.             
           IF GFM2D-STATEMENT-TYPE NOT EQUAL 'I'                                
              GO TO BUILD-SUMM-TEST-REIN.                                       
           MOVE '1' TO ADJ-RECD-GROUP-REQD-SW                                   
           IF LANG-SUB EQUAL 2                                                  
              CALL 'QDATE' USING QDATE-PARM GFM2D-FROM-YEAR                     
                                 NEW-ISSUE-DATE1-FR                             
              CALL 'QDATE' USING QDATE-PARM GFM2D-TO-YEAR                       
                                 NEW-ISSUE-DATE2-FR                             
           ELSE                                                                 
              CALL 'QDATE' USING QDATE-PARM GFM2D-FROM-YEAR                     
                                 NEW-ISSUE-DATE1-ENG                            
              CALL 'QDATE' USING QDATE-PARM GFM2D-TO-YEAR                       
                                    NEW-ISSUE-DATE2-ENG.                        
           MOVE NEW-ISSUE-TITLE-1 (LANG-SUB) TO PR-HEAD1-SAVE                   
           MOVE NEW-ISSUE-TITLE-2 (LANG-SUB) TO PR-HEAD2-SAVE.                  
       BUILD-SUMM-TEST-REIN.                                                    
           IF GFM2D-STATEMENT-TYPE NOT EQUAL 'R'                                
              GO TO BUILD-SUMM-TEST-TERM.                                       
           MOVE '1' TO ADJ-RECD-GROUP-REQD-SW                                   
           IF LANG-SUB EQUAL 2                                                  
              CALL 'QDATE' USING QDATE-PARM GFM2D-FROM-YEAR                     
                                 REIN-LIST-DATE1-FR                             
              CALL 'QDATE' USING QDATE-PARM GFM2D-TO-YEAR                       
                                 REIN-LIST-DATE2-FR                             
           ELSE                                                                 
              CALL 'QDATE' USING QDATE-PARM GFM2D-FROM-YEAR                     
                                 REIN-LIST-DATE1-ENG                            
              CALL 'QDATE' USING QDATE-PARM GFM2D-TO-YEAR                       
                                 REIN-LIST-DATE2-ENG.                           
           MOVE REIN-LIST-TITLE-1 (LANG-SUB) TO PR-HEAD1-SAVE.                  
               MOVE REIN-LIST-TITLE-2 (LANG-SUB) TO PR-HEAD2-SAVE.              
       BUILD-SUMM-TEST-TERM.                                                    
           IF GFM2D-STATEMENT-TYPE NOT EQUAL 'T'                                
              GO TO BUILD-SUMM-TEST-NORM.                                       
           MOVE '1' TO ADJ-RECD-GROUP-REQD-SW                                   
           IF LANG-SUB EQUAL 2                                                  
               CALL 'QDATE' USING QDATE-PARM GFM2D-FROM-YEAR                    
                                  TERM-LIST-DATE-FR                             
           ELSE                                                                 
               CALL 'QDATE' USING QDATE-PARM GFM2D-FROM-YEAR                    
                                  TERM-LIST-DATE-ENG.                           
           MOVE TERM-LIST-TITLE-1 (LANG-SUB) TO PR-HEAD1-SAVE                   
           MOVE TERM-LIST-TITLE-2 (LANG-SUB) TO PR-HEAD2-SAVE.                  
       BUILD-SUMM-TEST-NORM.                                                    
           IF GFM2D-STATEMENT-TYPE NOT EQUAL 'N'                                
              GO TO BUILD-OFFICE-LIT.                                           
           MOVE '0' TO ADJ-RECD-GROUP-REQD-SW                                   
           CALL 'QDATE' USING QDATE-AB GFM2D-PREMIUM-DUE-DATE                   
                              OUT-DDMMYY                                        
           CALL 'QDATE' USING QDATE-AD GFM2D-PREMIUM-DUE-DATE           YEAR2000
                              OUT-DDMMMYYYY                                     
           IF LANG-SUB EQUAL 2                                                  
              MOVE LIT-MONTHS-FRENCH (OUT-MM) TO                                
                              LIST-BILL-MONTH-YEAR-FR                           
              SET LIST-BILL-FSUB TO LIT-LENGTHS-FRENCH (OUT-MM)                 
              MOVE OUT-YEAR1 TO LIST-BILL-M-Y-F (LIST-BILL-FSUB + 1)            
              MOVE OUT-YEAR2 TO LIST-BILL-M-Y-F (LIST-BILL-FSUB + 2)            
              MOVE OUT-YEAR3 TO LIST-BILL-M-Y-F (LIST-BILL-FSUB + 3)            
              MOVE OUT-YEAR4 TO LIST-BILL-M-Y-F (LIST-BILL-FSUB + 4)            
              MOVE LIST-BILL-TITLE-1-SUMM-PG (LANG-SUB) TO PR-HEAD1-SAVE        
              IF OUT-MM = 4 OR OUT-MM = 8 OR OUT-MM = 10                        
                    MOVE 'Du mois d'               TO   FR-LINE-1               
                    MOVE QUOTE                     TO   FR-LINE-2               
                    MOVE LIST-BILL-MONTH-YEAR-FR   TO   FR-LINE-3               
                    MOVE FR-LINE-1-2               TO   PR-HEAD2-SAVE           
               ELSE                                                             
                    MOVE LIST-BILL-TITLE-2 (LANG-SUB) TO PR-HEAD2-SAVE.         
           IF LANG-SUB EQUAL 1                                                  
              MOVE LIT-MONTHS-ENGLISH (OUT-MM) TO                               
                              LIST-BILL-MONTH-YEAR-ENG                          
              SET LIST-BILL-ESUB TO LIT-LENGTHS-ENGLISH (OUT-MM)                
              MOVE OUT-YEAR1 TO LIST-BILL-M-Y-E (LIST-BILL-ESUB + 1)            
              MOVE OUT-YEAR2 TO LIST-BILL-M-Y-E (LIST-BILL-ESUB + 2)            
              MOVE OUT-YEAR3 TO LIST-BILL-M-Y-E (LIST-BILL-ESUB + 3)            
              MOVE OUT-YEAR4 TO LIST-BILL-M-Y-E (LIST-BILL-ESUB + 4)            
              MOVE LIST-BILL-TITLE-1-SUMM-PG (LANG-SUB) TO PR-HEAD1-SAVE        
              MOVE LIST-BILL-TITLE-2 (LANG-SUB) TO PR-HEAD2-SAVE.               
                                                                                
      ******************************************************************        
      *    CONCATENATE THE GROUP OFFICE LIT FROM THE SUMMARY RECORD AND         
      *    THE GROUP OFFICE NO.                                                 
      ******************************************************************        
       BUILD-OFFICE-LIT.                                                        
           MOVE GFM2D-GROUP-OFFICE-NAME TO STORE-OFFICE-NM-NUM.                 
           SET OFFICE-SUB TO 25.                                                
       OFFICE-LOOP.                                                             
           IF STORE-OFF-NM-NUM (OFFICE-SUB) EQUAL ' '                           
              SET OFFICE-SUB DOWN BY 1                                          
              GO TO OFFICE-LOOP.                                                
           SET OFFICE-SUB UP BY 2.                                              
       MOVE-OFFICE-NUM.                                                         
           MOVE '(' TO STORE-OFF-NM-NUM (OFFICE-SUB).                           
           MOVE ')' TO STORE-OFF-NM-NUM (OFFICE-SUB + 6).                       
           MOVE GFM2D-GROUP-OFFICE TO EDIT-GRP-OFFICE.                          
           MOVE EDIT-GRP-OFF-1 TO STORE-OFF-NM-NUM (OFFICE-SUB + 1).            
           MOVE EDIT-GRP-OFF-2 TO STORE-OFF-NM-NUM (OFFICE-SUB + 2).            
           MOVE EDIT-GRP-OFF-3 TO STORE-OFF-NM-NUM (OFFICE-SUB + 3).            
           MOVE EDIT-GRP-OFF-4 TO STORE-OFF-NM-NUM (OFFICE-SUB + 4).            
           MOVE EDIT-GRP-OFF-5 TO STORE-OFF-NM-NUM (OFFICE-SUB + 5).            
                                                                                
      ******************************************************************        
      *    TRANSFORM THE 'GFM2D-BENEFIT-COMB' TABLE INTO TABLE BY               
      *    COVERAGE CODE.  IN THIS NEW TABLE, EACH ENTRY (COVERAGE CODE)        
      *    WILL HAVE THE COLUMNS (1 TO 9) WHICH IT IS REQUIRED IN.              
      *                                                                         
      *    EG. COMB TABLE =                                                     
      *     1     3    1     1      1     1      2                              
      *    LIFE  LIFE  WI    WI    LTD   LTD   HEALTH                           
      *    AMT   PREM  AMT   PREM  AMT   PREM  PREM                             
      *     V     P     V     P     V     P     P                               
      *                                                                         
      *    CODES = 150,150,160,083,10,10,130,130,19,99                          
      *                                                                         
      *    USE THE TOP ROW OF NUMBERS TO ASSIGN THE NEXT "N" CODES              
      *    TO THE NEXT AVAILABLE COLUMN.                                        
      *                                                                         
      *    CODE POSITIONS/VALUES        COLUMN ASSIGNED TO                      
      *     1     = 150                     1                                   
      *     2,3,4 = 150,160,083             2                                   
      *     5     = 10                      3                                   
      *     6     = 10                      4                                   
      *     7     = 130                     5                                   
      *     8     = 130                     6                                   
      *     9,10  = 19,99                   7                                   
      *                                                                         
      *    END UP WITH THIS TABLE.                                              
      *    #CODES = 7                                                           
      *    CODE  #COLS  COL LIST                                                
      *    150     2     1,2                                                    
      *    160     1     2                                                      
      *     83     1     2                                                      
      *     10     2     3,4                                                    
      *    130     2     5,6                                                    
      *     19     1     7                                                      
      *     99     1     7                                                      
      ******************************************************************        
       BUILD-TABLE-BY-COV-CODE.                                                 
           MOVE 0 TO GGICOV-SUB.                                                
           MOVE 0 TO GGICOL-SUB                                                 
           MOVE 0 TO TITLE-NUM-CODES.                                           
       CHANGE-GGICOL.                                                           
           ADD  1 TO GGICOL-SUB                                                 
           IF GGICOL-SUB GREATER THAN 9 OR                                      
              GFM2D-BC-PREM-OR-VOL (GGICOL-SUB) EQUAL SPACES                    
              GO TO END-TABLE-BUILD.                                            
           MOVE 0 TO GGICOL-CTR.                                                
       BUILD-TABLE-LOOP.                                                        
           ADD +1 TO GGICOL-CTR.                                                
           IF GGICOL-CTR GREATER THAN GFM2D-BC-NO-OF-CODES (GGICOL-SUB)         
              GO TO CHANGE-GGICOL.                                              
           ADD +1 TO GGICOV-SUB.                                                
      *    CHECK IF THIS COVERAGE CODE IS ALREADY STORED.                       
           MOVE +0 TO CHECK-SUB.                                                
       CHECK-TABLE-LOOP.                                                        
           ADD +1 TO CHECK-SUB.                                                 
           IF CHECK-SUB GREATER THAN TITLE-NUM-CODES                            
              ADD +1 TO TITLE-NUM-CODES                                         
              MOVE GFM2D-BC-CODES (GGICOV-SUB) TO                               
                                TITLE-COV-CODE (TITLE-NUM-CODES)                
              MOVE +1 TO NUM-COLS (TITLE-NUM-CODES)                             
              MOVE GGICOL-SUB TO COLS-OF-COV-CODE (TITLE-NUM-CODES, 1)          
              GO TO BUILD-TABLE-LOOP.                                           
           IF GFM2D-BC-CODES (GGICOV-SUB) EQUAL                                 
                              TITLE-COV-CODE (CHECK-SUB)                        
              ADD +1 TO NUM-COLS (CHECK-SUB)                                    
              MOVE NUM-COLS (CHECK-SUB) TO COL-SUB                              
              MOVE GGICOL-SUB TO                                                
                   COLS-OF-COV-CODE (CHECK-SUB, COL-SUB)                        
              GO TO BUILD-TABLE-LOOP.                                           
           GO TO CHECK-TABLE-LOOP.                                              
       END-TABLE-BUILD.                                                         
      *----------------------------------------------------------------*        
      *    READ THE PAYMENT RECORDS FOR THIS GROUP/ACCT                *        
      *    CALL THE ROUTINE TO PRINT THE SUMMARY PAGE                  *        
      *    IF A CHANGE LIST IS BEING PRINTED BYPASS THE NEXT CHECK     *        
      *    CHECK THE LAST RECORD READ TO DETERMINE IF                  *        
      *       A) FINISHED PROCESSING BILLING RECORDS - IF YES GO TO    *        
      *                   PROGRAM EXIT                                 *        
      *       B) PROCESSING NEW GROUP/ACCT RECORDS - IF YES GO TO      *        
      *                   CHECK NEXT SUMMARY RECORD                    *        
      *       C) PROCESSING OTHER BILLING RECORDS FOR THIS GROUP/ACCT  *        
      *                   CONTINUE BY SETTING UP THE PRINTS FOR THE    *        
      *                   DETAIL REPORT                                *        
      *----------------------------------------------------------------*        
           PERFORM SUM-PAYMENT-REC THRU SUM-PAYMENT-REC-EXIT.                   
           PERFORM OUTPUT-SUMMARY-REPORT THRU                                   
                                         OUTPUT-SUMMARY-REPORT-EXIT.            
E42        PERFORM 5100-START-DETAIL THRU 5100-START-DETAIL-EXIT.               
           IF GFM2D-BFSO-CHANGE-BILLING EQUAL 'Y'                               
              GO TO REINIT-BLD-DET-HEAD.                                        
           IF (TAPE-RETURN NOT EQUAL ZERO) OR                                   
              (T-REC-TYPE NOT EQUAL '2')                                        
               GO TO PROGRAM-EXIT.                                              
           IF (T-GROUP NOT EQUAL GFM2D-GROUP-NUMBER) OR                         
              (T-ACCT NOT EQUAL GFM2D-ACCOUNT) OR                               
              (T-ORD EQUAL 'D')                                                 
               GO TO CHECK-SUMMARY-RECORD.                                      
      ******************************************************************        
      *    THERE ARE DETAIL RECORDS FOR THIS GROUP/ACCT                         
      *    DETERMINE IF DEPENDENT HEADINGS ARE REQUIRED IN DETAIL REPORT        
      ******************************************************************        
       REINIT-BLD-DET-HEAD.                                                     
           MOVE +0 TO STATS-SUB.                                                
           MOVE '000' TO DEPENDENT-IND.                                         
       REINIT-STATS-LOOP.                                                       
           ADD +1 TO STATS-SUB.                                                 
           IF STATS-SUB GREATER THAN GFM2E-NO-OF-CODES                          
              GO TO SET-HEAD-LINES.                                             
           IF GFM2E-COVERAGE-CODE (STATS-SUB) EQUAL 160                         
              MOVE '1' TO DEP-LIFE-IND.                                         
           IF (GFM2E-COVERAGE-CODE (STATS-SUB) NOT GREATER THAN                 
                                              EHC-CODE-MAX)   AND               
              (GFM2E-COVERAGE-CODE (STATS-SUB) NOT LESS THAN                    
                                              EHC-CODE-MIN)   AND               
              (GFM2E-VOLUME (STATS-SUB) EQUAL 2 OR 3)                           
              MOVE '1' TO DEP-EHC-IND.                                          
           IF (GFM2E-COVERAGE-CODE (STATS-SUB) NOT GREATER THAN                 
                                               DEN-CODE-MAX)  AND               
              (GFM2E-COVERAGE-CODE (STATS-SUB) NOT LESS THAN                    
                                               DEN-CODE-MIN)  AND               
              (GFM2E-VOLUME (STATS-SUB) EQUAL 2 OR 3)                           
              MOVE '1' TO DEP-DEN-IND.                                          
           GO TO REINIT-STATS-LOOP.                                             
      ******************************************************************        
      *    SET UP THE TITLE LINES FOR THE REPORT                                
      ******************************************************************        
       SET-HEAD-LINES.                                                          
           MOVE SPACES TO TITLE-LINE1  TITLE-LINE2.                             
           MOVE NAME-LIT (LANG-SUB) TO T2-NAME-LIT.                             
           MOVE CERT-LIT-LINE1 (LANG-SUB) TO T1-CERT-LIT1.                      
           MOVE CERT-LIT-LINE2 (LANG-SUB) TO T2-CERT-LIT2.                      
           MOVE CLASS-LIT (LANG-SUB) TO T2-CLASS-LIT.                           
           IF DEPENDENT-IND NOT EQUAL '000'                                     
              MOVE DEPENDENT-LIT (LANG-SUB) TO T1-DEP-LIT.                      
           IF DEP-LIFE-IND NOT EQUAL '0'                                        
              MOVE DEP-LIT-LIFE (LANG-SUB) TO T2-DEP-LIFE-LIT.                  
           IF DEP-EHC-IND NOT EQUAL '0'                                         
              MOVE DEP-LIT-EHC  (LANG-SUB) TO T2-DEP-EHC-LIT.                   
           IF DEP-DEN-IND NOT EQUAL '0'                                         
              MOVE DEP-LIT-DEN  (LANG-SUB) TO T2-DEP-DEN-LIT.                   
           MOVE +0 TO TITLE-SUB.                                                
       REINIT-COL-TITLES.                                                       
           ADD +1 TO TITLE-SUB.                                                 
           IF TITLE-SUB GREATER THAN 9 OR                                       
                    GFM2D-BC-PREM-OR-VOL (TITLE-SUB) EQUAL SPACES               
              GO TO REINIT-TOTAL-PREM.                                          
           MOVE GFM2D-BC-TITLE-LINE1 (TITLE-SUB) TO                             
                                      T1-COL-LIT1 (TITLE-SUB).                  
           MOVE GFM2D-BC-TITLE-LINE2 (TITLE-SUB) TO                             
                                      T2-COL-LIT2 (TITLE-SUB).                  
           GO TO REINIT-COL-TITLES.                                             
      ******************************************************************        
      *  - STORE THE SUBSCRIPT SINCE USED FOR TOTAL PREM COLUMN                 
      *  - SET UP THE COLUMN TITLES FOR THE 'TOTAL PREM'                        
      ******************************************************************        
       REINIT-TOTAL-PREM.                                                       
           MOVE TOTAL-COL-LINE1 (LANG-SUB) TO T1-COL-LIT1 (TITLE-SUB).          
           MOVE TOTAL-COL-LINE2 (LANG-SUB) TO T2-COL-LIT2 (TITLE-SUB).          
           MOVE TITLE-SUB TO PREM-SUB.                                          
                                                                                
      ******************************************************************        
      *    PROCESS THE DETAIL RECORDS FOR THIS GROUP/ACCT.                      
      ******************************************************************        
       REINIT-GROUP-DETAILS.                                                    
           MOVE +0 TO NUM-DETAIL-STORED.                                        
           MOVE +0 TO PREV-GROUP PREV-CERT PREV-DIVISION.                       
           MOVE LOW-VALUES TO PREV-ACCT.                                        
           MOVE '0' TO DONE-DETAIL-SW, DONE-DIVISION-SW.                        
           PERFORM NEW-DETAIL-PAGE THRU NEW-DETAIL-PAGE-EXIT.                   
           MOVE +0 TO BAL-GRP-COL-ACCUM (1).                                    
           MOVE BAL-GRP-COLUMN-ACCUM-DETAIL TO BAL-GRP-COL-ACCUM-TO-ZERO        
                                                                                
           MOVE 'N' TO DIV-ADJ-FOUND-FLAG.                                      
           MOVE '0' TO ADJ-RECD-FND-SW  ADJ-RECD-CERT-REQD-SW.                  
           MOVE '0' TO DIV-BILL-TYPE-SW.                                        
                                                                                
           IF GFM2D-BFSO-CHANGE-BILLING NOT EQUAL 'Y'                           
              GO TO STORE-GRP-ACCT-CERT.                                        
      *                                                                         
      *    PRINT THE * REPORTED CHANGES *  LINE IN THE BOX - IF CHANGE          
      *    BILLING INDICATED                                                    
      *                                                                         
           MOVE REPORT-CHG-LIT (LANG-SUB) TO PR-LINE1                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE 1 TO LINE-CT.                                                   
           IF (TAPE-RETURN NOT EQUAL ZERO) OR                                   
              (T-REC-TYPE NOT EQUAL '2')                                        
                MOVE NIL-LIT (LANG-SUB) TO PR-LINE1                             
                PERFORM OUTPUT-RTN THRU OP-EXIT                                 
                MOVE '1' TO DONE-DETAIL-SW                                      
                MOVE '1' TO DONE-DIVISION-SW                                    
                PERFORM PRINT-STORED-DETAIL-REC THRU                            
                        PRINT-STORED-DETAIL-REC-EXIT                            
                GO TO PROGRAM-EXIT.                                             
           IF ((T-GROUP NOT EQUAL GFM2D-GROUP-NUMBER) OR                        
               (T-ORD EQUAL 'D') OR                                             
               (T-ACCT NOT EQUAL GFM2D-ACCOUNT))                                
                MOVE NIL-LIT (LANG-SUB) TO PR-LINE1                             
                PERFORM OUTPUT-RTN THRU OP-EXIT                                 
                MOVE '1' TO DONE-DETAIL-SW                                      
                MOVE '1' TO DONE-DIVISION-SW                                    
                PERFORM PRINT-STORED-DETAIL-REC THRU                            
                        PRINT-STORED-DETAIL-REC-EXIT                            
                GO TO CHECK-SUMMARY-RECORD.                                     
      ******************************************************************        
      *    STORE THE CERTIFICATE NUMBER.  IF DONE PROCESSING FOR THIS           
      *    CERT AND/OR GROUP/ACCT PRINT THE LAST SET OF RECORDS STORED          
      *    FOR THE PREVIOUS DETAIL.                                             
      *                                                                         
      *    IF DIVISION HAS CHANGED WITHIN GROUP/ACCOUNT PRINT OUT THE           
      *    DIVISIONAL TOTAL, SET THE DIVISION SWITCH ON AND CONTINUE            
      *    PROCESSING THE GROUP.                                                
      *                                                                         
      *    IF THE DIVISION HAS CHANGED FOR THE FIRST TIME AND THE               
      *    NEW DIVISION IS EQUAL TO '99' DO NOT TURN THE DIVISION               
      *    BILLING SWITCH ON.  THIS IS BECAUSE THE DIVISION HAS BEEN            
      *    AUTOMATICALLY SET TO '99' BECAUSE A RETROACTIVE ADJUSTMENT           
      *    ON THE GROUP WAS MADE EARLIER.                                       
      *                                                                         
      *    IF DONE PROCESSING FOR THE DIVISION TURN ON THE                      
      *    DONE-DIVISION-SW WHICH SIGNALS THAT THE DIVISION TOTAL               
      *    LINE FOR THE GROUP/ACCT/DIVISION MUST BE PRINTED IF THE              
      *    GROUP QUALIFIED AS A DIVISIONAL BILLED GROUP.                        
      *                                                                         
      *    IF DONE PROCESSING FOR GROUP TURN ON THE DONE-DETAIL-SW              
      *    WHICH SIGNALS THAT THE TOTAL LINE FOR THE GROUP/ACCT MUST BE         
      *    PRINTED.                                                             
      ******************************************************************        
       STORE-GRP-ACCT-CERT.                                                     
           IF T-ORD EQUAL 'Q'                                                   
              MOVE T-CERT-Q TO CURR-CERT.                                       
           IF T-ORD EQUAL 'R'                                                   
              MOVE T-CERT-R TO CURR-CERT.                                       
           IF PREV-GROUP EQUAL +0                                               
              GO TO STORE-DETAIL-RECORD.                                        
                                                                                
           IF (T-DIVISION NOT EQUAL TO PREV-DIVISION)                           
             AND (T-GROUP EQUAL TO PREV-GROUP AND                               
                  T-ACCT EQUAL TO PREV-ACCT)                                    
              IF  T-DIVISION = +99 AND                                          
                  DIV-BILL-TYPE-SW = '0'                                        
                  NEXT SENTENCE                                                 
              ELSE                                                              
                  MOVE '1' TO DIV-BILL-TYPE-SW                                  
                  MOVE '1' TO DONE-DIVISION-SW                                  
                  PERFORM PRINT-STORED-DETAIL-REC THRU                          
                          PRINT-STORED-DETAIL-REC-EXIT                          
                  MOVE '0' TO DONE-DIVISION-SW                                  
                  MOVE +0 TO BAL-GRP-COL-ACCUM (1)                              
                  MOVE 'N' TO DIV-ADJ-FOUND-FLAG                                
                  MOVE BAL-GRP-COLUMN-ACCUM-DETAIL TO                           
                       BAL-GRP-COL-ACCUM-TO-ZERO.                               
                                                                                
           IF (T-GROUP NOT EQUAL PREV-GROUP) OR                                 
              (T-ACCT NOT EQUAL PREV-ACCT) OR                                   
              (T-ORD EQUAL 'D')                                                 
              MOVE ADJ-RECD-GROUP-REQD-SW TO ADJ-RECD-CERT-REQD-SW              
              MOVE '1' TO DONE-DETAIL-SW                                        
              MOVE '1' TO DONE-DIVISION-SW                                      
              PERFORM PRINT-STORED-DETAIL-REC THRU                              
                      PRINT-STORED-DETAIL-REC-EXIT                              
              MOVE '0' TO ADJ-RECD-FND-SW  ADJ-RECD-CERT-REQD-SW                
              MOVE 'N' TO DIV-ADJ-FOUND-FLAG                                    
              GO TO CHECK-SUMMARY-RECORD.                                       
                                                                                
           IF CURR-CERT NOT EQUAL PREV-CERT                                     
              MOVE ADJ-RECD-GROUP-REQD-SW TO ADJ-RECD-CERT-REQD-SW              
              PERFORM PRINT-STORED-DETAIL-REC THRU                              
                      PRINT-STORED-DETAIL-REC-EXIT                              
              MOVE '0' TO ADJ-RECD-FND-SW  ADJ-RECD-CERT-REQD-SW.               
      *                                                                         
      *    STORE THE RECORD IN THE TABLE, IF AN ADJUSTMENT RECORD               
      *    PRESENT, TURN ON THE ADJ-REQD-FND-SW.                                
      *                                                                         
      *    IF THIS IS THE FIRST RECORD FOR A GIVEN GROUP/ACCT/CERT AND          
      *    IT IS A 'T' RECORD, GENERATE A CURRENT RECORD 'S' TYPE WITH          
      *    PREMIUM AND COVERAGE CODES EQUAL 0.                                  
      *                                                                         
       STORE-DETAIL-RECORD.                                                     
           IF T-IDENT EQUAL 'T'                                                 
              IF (CURR-GROUP NOT EQUAL PREV-GROUP)  OR                          
                 (CURR-ACCT  NOT EQUAL PREV-ACCT)   OR                          
                 (CURR-CERT  NOT EQUAL PREV-CERT)                               
                  PERFORM GENERATE-S-RECORD THRU GEN-S-REC-EXIT.                
           MOVE T-GROUP TO PREV-GROUP                                           
           MOVE T-ACCT TO PREV-ACCT                                             
           MOVE T-DIVISION TO PREV-DIVISION                                     
           MOVE CURR-CERT TO PREV-CERT                                          
           IF NUM-DETAIL-STORED EQUAL +30                                       
                 PERFORM PRINT-STORED-DETAIL-REC THRU                           
                          PRINT-STORED-DETAIL-REC-EXIT.                         
           ADD +1 TO NUM-DETAIL-STORED.                                         
           MOVE TAPE-REC TO DETAIL-RECORDS (NUM-DETAIL-STORED).                 
E42        PERFORM 5500-EXTRACT-DETAIL THRU 5500-EXTRACT-DETAIL-EXIT.           
           IF T-IDENT EQUAL 'T'                                                 
              MOVE '1' TO ADJ-RECD-FND-SW.                                      
      ******************************************************************        
      *    RELEASE # 1.                                                         
      *    SET FLAG INDICATING A DIV ADJUSTMENT HAS BEEN FOUND.                 
      ******************************************************************        
           IF T-IDENT = 'U' AND CURR-CERT = +999999999                          
              MOVE 'Y' TO DIV-ADJ-FOUND-FLAG.                                   
           PERFORM READ-RECORD THRU READ-RECORD-EXIT.                           
           IF (TAPE-RETURN NOT EQUAL ZERO) OR                                   
              (T-REC-TYPE NOT EQUAL '2')                                        
               MOVE ADJ-RECD-GROUP-REQD-SW TO ADJ-RECD-CERT-REQD-SW             
               MOVE '1' TO DONE-DETAIL-SW                                       
               MOVE '1' TO DONE-DIVISION-SW                                     
               PERFORM PRINT-STORED-DETAIL-REC THRU                             
                       PRINT-STORED-DETAIL-REC-EXIT                             
               GO TO PROGRAM-EXIT.                                              
           GO TO STORE-GRP-ACCT-CERT.                                           
                                                                                
      *----------------------------------------------------------------*        
      *    OUTPUT THE SUMMARY PAGE (1 COPY IF SUMMARY LIST OPTION      *        
      *    OTHERWISE 2 COPIES.                                         *        
      *  - A TABLE IS USED TO HOLD THE INFORMATION FOR THE PRINT LINES *        
      *    STARTING AT DUE LAST MONTH TO TOTAL DUE THIS MONTH OR       *        
      *    THE TOTAL PREMIUM FIELD ON SUMMARY LIST WHICHEVER IS GREATER*        
      *  - THIS TABLE IS USED SINCE A VARIABLE NO. OF LINES CAN BE     *        
      *    PRINTED                                                     *        
      *----------------------------------------------------------------*        
       OUTPUT-SUMMARY-REPORT.                                                   
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    SWITCH TO PAGE FORMAT 'UGBIL2'. BILLING SUMMARY PAGE.                
      ****************************************************************          
      *    M. PRANGE.                                                           
      *    AUTOMATICALLY PRINT THESE "AFP" INSTRUCTIONS PRIOR TO                
      *    PRINTING THE SUMMARY PAGE.                                           
      ****************************************************************          
           MOVE 'UGBIL2'               TO GPPFA-PAGE-NAME.                      
 BP        MOVE ZEROES                 TO WS-TOTAL-PREM-DUE.                    
           MOVE GPPFA-PAGE-RECORD      TO PRINT-LINE.                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE 'UGBIL2'               TO GPPFA-OVLY-COPYGRP.                   
           MOVE GPPFA-OVLY-RECORD      TO PRINT-LINE.                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE +1 TO NUM-SUMMARY-REP-PRODUCED.                                 
           MOVE +1 TO PAGE-CT                                                   
           MOVE SPACES TO SUMMARY-PAGE-PRINT-LINES.                             
       OUTPUT-SUMMARY-REPORT-LOOP.                                              
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 1, PAGEDEF CHANNEL FOR SUMMARY PAGE = LINE 1.                   
      ****************************************************************          
           PERFORM SUM-NUMBER-BILLINGS THRU SNB-EXIT.                           
           MOVE '1' TO CC.                                                      
           MOVE PR-HEAD1-SAVE TO PR25-HEAD.                                     
           PERFORM OUTPUT-RTN THRU OP-EXIT                                      
           MOVE PR-HEAD2-SAVE TO PR25-HEAD                                      
           MOVE 'PAGE'        TO PAGE-LIT.                                      
           MOVE PAGE-CT       TO OUT-PAGE.                                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO CC.                                                      
           IF COPY-INDICATOR EQUAL 'P' THEN                                     
              MOVE PR-HEAD3-SAVE (LANG-SUB) TO PR25-HEAD.                       
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
      * ============================================================            
      *                                                                         
      * NOTE ====>                                                              
      *           PR-HEAD1-SAVE IS CHANGED TO REFLECT THE TITLE                 
      *           REQUIRED FOR THE REMAINING PAGES                              
      *                   'EMPLOYEE DATA'                                       
      * MARCUS CHG # 736 MAR/89                                                 
      * ============================================================            
      *                                                                         
           MOVE LIST-BILL-TITLE-1-EMP-PG  (LANG-SUB) TO PR-HEAD1-SAVE           
                                                                                
           MOVE ' ' TO CC.                                                      
           MOVE GROUP-NO-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                   
           MOVE GFM2D-GROUP-NUMBER TO P-GROUP.                                  
           MOVE GFM2D-GROUP-NUMBER TO ER-GROUP, FR-GROUP.                       
           MOVE GFM2D-ACCOUNT TO P-ACCT.                                        
           MOVE GFM2D-ACCOUNT TO ER-ACCOUNT, FR-ACCOUNT.                        
           MOVE PREM-DUE-LIT (LANG-SUB) TO P-SUMM-LIT.                          
           CALL 'QDATE' USING QDATE-PARM                                        
                              GFM2D-PREMIUM-DUE-DATE                            
                              WS-DATE1.                                         
           MOVE SPACES                 TO WS-DATE2.                             
           MOVE WS-DAY1                TO WS-DAY2.                              
           MOVE WS-MONTH1              TO WS-MONTH2.                            
           MOVE WS-YEAR1               TO WS-YEAR2.                             
           MOVE WS-DATE2               TO P-SUMM-FIELD.                         
                                                                                
           MOVE STUB-PLEASE (LANG-SUB) TO P-STUB-CONST.                         
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE GROUP-OFF-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                  
           MOVE STORE-OFFICE-NM-NUM TO P-GRP-OFFICE                             
           MOVE DATE-PREP-LIT (LANG-SUB) TO P-SUMM-LIT.                         
           CALL 'QDATE' USING QDATE-PARM                                        
                              GFM2D-PREPARED-DATE                               
                              WS-DATE1.                                         
           MOVE SPACES                 TO WS-DATE2.                             
           MOVE WS-DAY1                TO WS-DAY2.                              
           MOVE WS-MONTH1              TO WS-MONTH2.                            
           MOVE WS-YEAR1               TO WS-YEAR2.                             
           MOVE WS-DATE2               TO P-SUMM-FIELD.                         
           IF  GFM2D-STATEMENT-TYPE NOT = 'T'                                   
               MOVE '*'                TO P-SUMM-AST.                           
                                                                                
           MOVE STUB-THIS     (LANG-SUB) TO P-STUB-CONST.                       
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE '0' TO END-NAME-FOUND-SW.                                       
           MOVE NAME-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                       
           MOVE GFM2D-NAME-ADDRESS-LINES (1) TO P-GRP-OFFICE.                   
           MOVE GFM2D-NAME-ADDRESS-LINES (1) TO ER-NAME, FR-NAME.               
           IF GFM2D-NAME-ADDRESS-DELIMITER (1) EQUAL '*'                        
              MOVE '1' TO END-NAME-FOUND-SW.                                    
           MOVE FILE-REF-LIT (LANG-SUB) TO P-SUMM-LIT.                          
           MOVE GFM2D-IDENTITY TO P-SUMM-FIELD.                                 
           MOVE STUB-PAYMENT (LANG-SUB) TO P-STUB-CONST.                        
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           IF END-NAME-FOUND-SW EQUAL '0'                                       
              MOVE GFM2D-NAME-ADDRESS-LINES (2) TO P-GRP-OFFICE                 
              IF GFM2D-NAME-ADDRESS-DELIMITER (2) EQUAL '*'                     
                 MOVE '1' TO END-NAME-FOUND-SW.                                 
           PERFORM GET-AGENT THRU GET-AGENT-EXIT.                               
           IF SAVE-AGENT-NAME NOT EQUAL SPACES                                  
              MOVE AGENT-LIT (LANG-SUB) TO P-SUMM-LIT                           
              MOVE SAVE-AGENT-NAME      TO P-SUMM-FIELD.                        
           CALL 'GNUMTABL' USING GNUM-CURR-TABLE-NO                             
                                 GFM2D-CURRENCY                                 
                                 GNUM-CURRENCY.                                 
           MOVE GNUM-CURRENCY         TO SAVE-CURRENCY.                         
           IF GFM2D-CURRENCY EQUAL '1'                                          
              MOVE SPACES TO GNUM-CURRENCY                                      
           ELSE                                                                 
              CALL 'GNUMTABL' USING GNUM-CURR-TABLE-NO                          
                                    GFM2D-CURRENCY                              
                                    GNUM-CURRENCY                               
              MOVE GNUM-CURRENCY TO P-SUMM-FIELD                                
              MOVE CURRENCY-LIT (LANG-SUB) TO P-SUMM-LIT.                       
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           IF END-NAME-FOUND-SW EQUAL '0'                                       
              MOVE GFM2D-NAME-ADDRESS-LINES (3) TO P-GRP-OFFICE.                
           IF COPY-INDICATOR = 'S'                                              
              MOVE BRANCH-LIT (LANG-SUB)        TO P-SUMM-LIT                   
              MOVE GFM2D-BRANCH                 TO P-SUMM-FIELD.                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *                                                                         
      *    THIS NEXT SECTION BUILDS A TABLE OF 17 PRINT LINES.                  
      *    IF YOU ARE FAMILIAR WITH THE "STUB" PORTION OF A BILL, THESE         
      *    17 LINES INCLUDE THE "GROUP NUMNBER" LINE DOWN TO THE                
      *    "PREM DUE" LINE.                                                     
      *    IT DOES NOT INCLUDE THE "TAX DUE" LINE(S) OR "TOTAL DUE"             
      *    LINE.                                                                
      *                                                                         
           IF NUM-SUMMARY-REP-PRODUCED EQUAL +1                                 
              PERFORM BUILD-OUT-SUMM-LINES THRU                                 
                      BUILD-OUT-SUMM-LINES-EXIT.                                
       OUTPUT-SUMMARY-LINE-TABLE.                                               
           MOVE +0 TO LINE-SUB.                                                 
           MOVE ' ' TO CC.                                                      
       OUTPUT-SUMMARY-LINE-TABLE-LOOP.                                          
           ADD +1 TO LINE-SUB.                                                  
           IF LINE-SUB GREATER THAN +17                                         
              GO TO CHECK-FOR-TAXES.                                            
           MOVE SUMMARY-LINES (LINE-SUB)    TO PR-SUMMARY-PAGE.                 
           MOVE SUMM-LINE-NEW-DATE (LINE-SUB)                                   
                                            TO PR-SUMMARY-DATE.                 
           IF LINE-SUB EQUAL +1 THEN                                            
              MOVE STUB-GROUP (LANG-SUB)    TO P-STUB-CONST                     
              MOVE GFM2D-GROUP-NUMBER       TO P-STUB-GROUP.                    
           IF LINE-SUB EQUAL +3 THEN                                            
              MOVE STUB-ACCT  (LANG-SUB)    TO P-STUB-CONST                     
              MOVE GFM2D-ACCOUNT            TO P-STUB-ACCOUNT.                  
           IF LINE-SUB EQUAL +5 THEN                                            
              MOVE STUB-FILE-REF (LANG-SUB) TO P-STUB-CONST                     
              MOVE GFM2D-IDENTITY           TO P-STUB-FIELD.                    
           IF LINE-SUB EQUAL +7 THEN                                            
              MOVE STUB-GRP-OFF  (LANG-SUB) TO P-STUB-CONST                     
              MOVE GFM2D-GROUP-OFFICE-NAME  TO P-STUB-FIELD.                    
           IF LINE-SUB EQUAL +9                                                 
              MOVE STUB-CURRENCY (LANG-SUB) TO P-STUB-CONST                     
              MOVE SAVE-CURRENCY            TO P-STUB-FIELD.                    
           IF LINE-SUB EQUAL +15                                                
              MOVE STUB-DATE-DUE (LANG-SUB) TO P-STUB-CONST                     
              CALL 'QDATE' USING QDATE-PARM                                     
                                 GFM2D-PREMIUM-DUE-DATE                         
                                 WS-DATE1                                       
              MOVE SPACES                   TO WS-DATE2                         
              MOVE WS-DAY1                  TO WS-DAY2                          
              MOVE WS-MONTH1                TO WS-MONTH2                        
              MOVE WS-YEAR1                 TO WS-YEAR2                         
              MOVE WS-DATE2                 TO P-STUB-FIELD.                    
                                                                                
           IF LINE-SUB EQUAL +17                                                
              IF (GFM2E-GROUP-TAX-IND EQUAL 'Y')                                
                MOVE STUB-TOT-PREM-DUE (LANG-SUB) TO P-STUB-CONST               
                SUBTRACT GFM2E-TAX-PREV-TOTAL     FROM                          
                         AMOUNT-OUTSTANDING GIVING OUTSTANDING-PREM             
                ADD GFM2E-GROSS-PREM-DUE-THIS-MTH                               
                    OUTSTANDING-PREM GIVING TOTAL-PREM-DUE                      
                MOVE TOTAL-PREM-DUE       TO P-STUB-FIELD-AMT                   
 GV             MOVE TOTAL-PREM-DUE       TO WS-TOTAL-PREM-DUE                  
              ELSE                                                              
                MOVE STUB-PREM-DUE (LANG-SUB) TO P-STUB-CONST                   
                MOVE TOTAL-PREM-DUE-THIS-MONTH TO P-STUB-FIELD-AMT              
 GV             MOVE TOTAL-PREM-DUE-THIS-MONTH TO WS-TOTAL-PREM-DUE.            
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           GO TO OUTPUT-SUMMARY-LINE-TABLE-LOOP.                                
                                                                                
       CHECK-FOR-TAXES.                                                         
      ******************************************************************        
      *    CHECK IF THIS GROUP HAS TAXES APPLICABLE.                            
      *    IF NOT - JUST PRINT THE ADJ MESSAGES AND SKIP THE TAX LOGIC.         
      ******************************************************************        
           IF  GFM2E-GROUP-TAX-IND = 'Y'                                        
               GO TO TAX-DETAILS.                                               
      *                                                                         
      *    NO TAXES APPLICABLE.                                                 
      *    PRINT ADJ MESSAGES (UNLESS THIS IS A TERMINATION BILL).              
      *                                                                         
           IF  GFM2D-STATEMENT-TYPE = 'T'                                       
               GO TO EFT-PAYMENT-TEXT.                                          
                                                                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE PAYMENT-ADJ-LIT-1 (LANG-SUB) TO PR-SUMMARY-TEXT.                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE PAYMENT-ADJ-LIT-2 (LANG-SUB) TO PR-SUMMARY-TEXT.                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE PAYMENT-ADJ-LIT-3 (LANG-SUB) TO PR-SUMMARY-TEXT.                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE PAYMENT-ADJ-LIT-4 (LANG-SUB) TO PR-SUMMARY-TEXT.                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
 GV        GO TO EFT-PAYMENT-TEXT.                                              
                                                                                
       TAX-DETAILS.                                                             
      ******************************************************************        
      *    BUILD A TABLE OF TAX DETAIL LINES THEN PRINT THEM.                   
      ******************************************************************        
           MOVE SPACES                      TO TAX-LINES-TABLE.                 
                                                                                
           IF  GFM2D-STATEMENT-TYPE = 'T'                                       
               MOVE +0                           TO TAX-LINE-CNT                
           ELSE                                                                 
               MOVE PAYMENT-TAX-LIT-1 (LANG-SUB) TO TAX-SUMM-TEXT (+4)          
               MOVE PAYMENT-TAX-LIT-2 (LANG-SUB) TO TAX-SUMM-TEXT (+5)          
               MOVE PAYMENT-TAX-LIT-3 (LANG-SUB) TO TAX-SUMM-TEXT (+6)          
               MOVE PAYMENT-TAX-LIT-4 (LANG-SUB) TO TAX-SUMM-TEXT (+7)          
               MOVE +7                           TO TAX-LINE-CNT.               
                                                                                
           MOVE +0                               TO LINE-SUB                    
                                                    TAX-SUB.                    
           MOVE +0.00                            TO TOTAL-TAX-DUE.              
       LOAD-TAXES-LOOP.                                                         
      *                                                                         
      *    LOAD THE NEXT TAX TYPE INTO THE TABLE                                
      *                                                                         
           ADD  +1                               TO TAX-SUB.                    
           IF  TAX-SUB > GFM2E-TAX-TABLE-CNT                                    
               GO TO LOAD-TAX-TOTAL-DUE.                                        
                                                                                
           COMPUTE PROV-TAX-DUE = GFM2E-TAX-PREV-AMT (TAX-SUB) +                
                                  GFM2E-TAX-CURR-AMT (TAX-SUB).                 
           IF  PROV-TAX-DUE = +0                                                
               GO TO LOAD-TAXES-LOOP.                                           
                                                                                
           ADD  +1                               TO LINE-SUB.                   
           IF  LANG-SUB = +1                                                    
               MOVE SPACES                       TO                             
                    TAX-STUB-TAX-TEXT-E (LINE-SUB)                              
               MOVE GFM2E-TAX-CODE (TAX-SUB)     TO                             
                    TAX-STUB-CODE-E (LINE-SUB)                                  
               MOVE STUB-TAX (LANG-SUB)          TO                             
                    TAX-STUB-TEXT-E (LINE-SUB)                                  
           ELSE                                                                 
               MOVE SPACES                       TO                             
                    TAX-STUB-TAX-TEXT-F (LINE-SUB)                              
               MOVE GFM2E-TAX-CODE (TAX-SUB)     TO                             
                    TAX-STUB-CODE-F (LINE-SUB)                                  
               MOVE STUB-TAX (LANG-SUB)          TO                             
                    TAX-STUB-TEXT-F (LINE-SUB).                                 
                                                                                
           MOVE PROV-TAX-DUE                     TO                             
                TAX-STUB-AMT (LINE-SUB).                                        
           ADD  PROV-TAX-DUE                     TO TOTAL-TAX-DUE.              
           GO TO LOAD-TAXES-LOOP.                                               
                                                                                
       LOAD-TAX-TOTAL-DUE.                                                      
           ADD  +1                               TO LINE-SUB.                   
           MOVE STUB-TOTAL (LANG-SUB)            TO                             
                TAX-STUB-TOTAL-TEXT (LINE-SUB).                                 
           ADD  TOTAL-PREM-DUE TOTAL-TAX-DUE                                    
                GIVING TOTAL-BILL.                                              
                                                                                
 BP        MOVE TOTAL-BILL        TO   WS-TOTAL-PREM-DUE.                       
                                                                                
           MOVE TOTAL-BILL                       TO                             
                TAX-STUB-AMT (LINE-SUB).                                        
                                                                                
           IF  LINE-SUB > TAX-LINE-CNT                                          
               MOVE LINE-SUB                     TO TAX-LINE-CNT.               
                                                                                
       PRINT-TAX-TABLE.                                                         
           MOVE +0                               TO LINE-SUB.                   
                                                                                
       PRINT-TAX-TABLE-LOOP.                                                    
           ADD  +1                               TO LINE-SUB.                   
           IF  LINE-SUB > TAX-LINE-CNT                                          
               GO TO EFT-PAYMENT-TEXT.                                          
                                                                                
           MOVE TAX-LINES-TAB-ENTRY (LINE-SUB)   TO PR-LINE1.                   
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           GO TO PRINT-TAX-TABLE-LOOP.                                          
                                                                                
 GV    EFT-PAYMENT-TEXT.                                                        
 GV        PERFORM CHECK-FOR-EFT  THRU CHECK-FOR-EFT-EXIT.                      
 GV        IF HOLD-PCODE      = '1'                                             
 GV           PERFORM TEXT-ALPHA-OUT  THRU TEXT-ALPHA-OUT-EXIT                  
 GV2       ELSE                                                                 
 GV2            IF HOLD-PCODE = '2'                                             
 GV           PERFORM TEXT-SIGNA-OUT  THRU TEXT-SIGNA-OUT-EXIT                  
 GV2       ELSE                                                                 
 GV2            IF HOLD-PCODE = '3'                                             
 GV           PERFORM TEXT-CORP-OUT   THRU TEXT-CORP-OUT-EXIT                   
 GV        .                                                                    
 GV                                                                             
       OUTPUT-SUMM-ADDRESS.                                                     
      ******************************************************************        
      *    IS THE IMPORTANT BOX AT BOTTOM OF THE PAGE REQUIRED                  
      *  - REQUIRED IF THE AMOUNT OUTSTANDING IS GREATER THAN OR EQUAL          
      *    TO 10 PERCENT OF THE AMOUNT DUE LAST MONTH.                          
      *  - DO NOT PRINT IT IF THE GROUP IS BEING TERMINATED, ISSUED             
      *    OR REINSTATED IN THIS RUN.                                           
      ******************************************************************        
      ****************************************************************          
      *    JAN/92 M. PRANGE                                                     
      *         - DO NOT PRINT "IMPORTANT" TEXT LINES IF TOT PREMIUM            
      *           DUE IS < OR = ZERO.                                           
      ****************************************************************          
           MOVE GFM2E-PREM-DUE-LAST-MTH TO TEST-AMOUNT.                         
           IF AMOUNT-OUTSTANDING NOT < TEST-AMOUNT-R AND                        
              AMOUNT-OUTSTANDING > +0                AND                        
              TOTAL-PREM-DUE-THIS-MONTH > +0                                    
              MOVE '1' TO IMPORT-BOX-REQD-SW                                    
           ELSE                                                                 
              MOVE '0' TO IMPORT-BOX-REQD-SW.                                   
           IF GFM2D-STATEMENT-TYPE EQUAL 'T' OR 'R' OR 'I'                      
              MOVE '0' TO IMPORT-BOX-REQD-SW.                                   
                                                                                
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 2, PAGEDEF CHANNEL FOR SUMMARY PAGE = LINE 47                   
      ****************************************************************          
           MOVE '2' TO CC.                                                      
                                                                                
       OSA-LINE-LOOP.                                                           
      ****************************************************************          
      *   NOTE: THE HOT-LINE-PROC WILL RETURN THE DEFAULT TOLL FREE             
      *         NUMBER IF THE TABLE SEARCH FAILS.                               
      ****************************************************************          
           PERFORM HOT-LINE-PROC THRU HOT-LINE-PROC-X.                          
      *                                                                         
      ****    (1) ADDRESS, PHONE, TAX REMIT ON STUB                             
      *                                                                         
           MOVE GFM2D-NAME-ADDRESS-LINES (1) TO PR-SUMM-NAME-ADDR.              
           MOVE HOT-LINE-LIT1 (LANG-SUB)     TO PR-SUMM-PHONE-MESSAGE.          
           IF  GFM2E-GROUP-TAX-IND = 'Y'                                        
               MOVE STUB-TAX-REMIT-LIT-1 (LANG-SUB)                             
                                             TO PR-SUMM-TAX-REMIT-STUB.         
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *                                                                         
      ****    (2) ADDRESS, PHONE, TAX REMIT ON STUB                             
      *                                                                         
           MOVE GFM2D-NAME-ADDRESS-LINES (2) TO PR-SUMM-NAME-ADDR.              
           MOVE HOT-LINE-LIT2 (LANG-SUB)     TO PR-SUMM-PHONE-MESSAGE.          
           IF  GFM2E-GROUP-TAX-IND = 'Y'                                        
               MOVE STUB-TAX-REMIT-LIT-2 (LANG-SUB)                             
                                             TO PR-SUMM-TAX-REMIT-STUB.         
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *                                                                         
      ****    (3) ADDRESS, PHONE, TAX REMIT ON STUB                             
      *                                                                         
           MOVE GFM2D-NAME-ADDRESS-LINES (3) TO PR-SUMM-NAME-ADDR.              
           MOVE HOT-LINE-LIT3 (LANG-SUB)     TO PR-SUMM-PHONE-MESSAGE.          
           IF  GFM2E-GROUP-TAX-IND = 'Y'                                        
               MOVE STUB-TAX-REMIT-LIT-3 (LANG-SUB)                             
                                             TO PR-SUMM-TAX-REMIT-STUB.         
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *                                                                         
      ****    (4) ADDRESS, PHONE, TAX REMIT ON STUB                             
      *                                                                         
           MOVE GFM2D-NAME-ADDRESS-LINES (4) TO PR-SUMM-NAME-ADDR.              
           IF  HOT-L4-PHONE-NUMBER (LANG-SUB) = INIT-PHONE                      
               MOVE SPACES                   TO PR-SUMM-PHONE-MESSAGE           
           ELSE                                                                 
               MOVE HOT-LINE-LIT4 (LANG-SUB) TO PR-SUMM-PHONE-MESSAGE.          
E42        MOVE PR-SUMM-PHONE-MESSAGE        TO LOCAL-PHONE-NUMBER              
E42                                          OF BILL-GRP-END-EXTRACT.           
           IF  GFM2E-GROUP-TAX-IND = 'Y'                                        
               MOVE STUB-TAX-REMIT-LIT-4 (LANG-SUB)                             
                                             TO PR-SUMM-TAX-REMIT-STUB.         
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *                                                                         
      ****    (5) ADDRESS, PHONE, TAX REMIT ON STUB                             
      *                                                                         
           MOVE GFM2D-NAME-ADDRESS-LINES (5) TO PR-SUMM-NAME-ADDR.              
           MOVE HOT-LINE-LIT5 (LANG-SUB)     TO PR-SUMM-PHONE-MESSAGE.          
E42        MOVE PR-SUMM-PHONE-MESSAGE        TO TOLL-FREE-NUMBER                
E42                                          OF BILL-GRP-END-EXTRACT.           
           IF  GFM2E-GROUP-TAX-IND = 'Y'                                        
               MOVE STUB-TAX-REMIT-LIT-5 (LANG-SUB)                             
                                             TO PR-SUMM-TAX-REMIT-STUB.         
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *                                                                         
      ****    (6) ADDRESS, PHONE, TAX REMIT ON STUB                             
      *                                                                         
           MOVE GFM2D-NAME-ADDRESS-LINES (6) TO PR-SUMM-NAME-ADDR.              
           IF  GFM2E-GROUP-TAX-IND = 'Y'                                        
               MOVE STUB-TAX-REMIT-LIT-6 (LANG-SUB)                             
                                             TO PR-SUMM-TAX-REMIT-STUB.         
           IF PRINT-LINE NOT = SPACES                                           
              PERFORM OUTPUT-RTN THRU OP-EXIT.                                  
                                                                                
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 3, PAGEDEF CHANNEL FOR SUMMARY PAGE = LINE 54                   
      ****************************************************************          
           MOVE '3' TO CC.                                                      
                                                                                
           IF IMPORT-BOX-REQD-SW = '1'                                          
              MOVE STAR-LIT-2 (LANG-SUB)      TO PR-SUMM-IMPORTANT              
              PERFORM OUTPUT-RTN THRU OP-EXIT                                   
 BM           IF   REQ-PAD-IN-EFFECT                                            
 BM               MOVE IMPORTANT-EFT-1 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM               MOVE IMPORTANT-EFT-2 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM               MOVE IMPORTANT-EFT-3 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM               MOVE IMPORTANT-EFT-4 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM           ELSE                                                              
 BM               MOVE IMPORTANT-CHQ-1 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM               MOVE IMPORTANT-CHQ-2 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM               MOVE IMPORTANT-CHQ-3 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM               MOVE IMPORTANT-CHQ-4 (LANG-SUB) TO PR-SUMM-IMPORTANT          
 BM               PERFORM OUTPUT-RTN THRU OP-EXIT                               
 BM   *       END-IF                                                            
 BM   *    END-IF                                                               
 BM        .                                                                    
      *---                                                                      
      *    MARKETING MESSAGES (FOR APR & OCT REGULAR BILLS)                     
      *---                                                                      
           IF  GFM2D-STATEMENT-TYPE NOT = 'N'                                   
               GO TO OUTPUT-SUMMARY-REPORT-EXIT.                                
                                                                                
           IF  GFM2D-PREMIUM-DUE-DAY >  +90 AND                                 
               GFM2D-PREMIUM-DUE-DAY < +121                                     
               GO TO MARKET-MESSAGE-ONE                                         
           ELSE                                                                 
                IF  GFM2D-PREMIUM-DUE-DAY > +273 AND                            
               GFM2D-PREMIUM-DUE-DAY < +305                                     
               GO TO MARKET-MESSAGE-ONE                                         
           ELSE                                                                 
               GO TO OUTPUT-SUMMARY-REPORT-EXIT.                                
                                                                                
       MARKET-MESSAGE-ONE.                                                      
           MOVE MARKET-MESSAGE-1 (LANG-SUB)   TO PR-LINE1.                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE MARKET-MESSAGE-2 (LANG-SUB)   TO PR-LINE1.                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE MARKET-MESSAGE-3 (LANG-SUB)   TO PR-LINE1.                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
       OUTPUT-SUMMARY-REPORT-EXIT.                                              
           EXIT.                                                                
                                                                                
       HOT-LINE-PROC.                                                           
      ***************************************************************           
      *    WANT TO RETURN A "LOCAL" AND "TOLL FREE" NUMBER FOR                  
      *    PRINTING ON 2 LINES.                                                 
      *    IF A PHONE NUMBER OVERRIDE EXISTS USE IT AS A "TOLL FREE"            
      *    NUMBER. KEEP THE "LOCAL" AS INIT-PHONE SO THAT IT WILL               
      *    WILL NOT GET PRINTED LATER.                                          
      *    USE CLAIMS OFFICE AS HIGHEST SEARCH KEY, NEXT TRY GFO.               
      *    DEFAULT "TOLL FREE" NUMBER IS LAST TABLE ENTRY.                      
      ***************************************************************           
           MOVE INIT-PHONE         TO HOT-L4-PHONE-NUMBER (1)                   
                                      HOT-L4-PHONE-NUMBER (2)                   
                                      HOT-L5-PHONE-NUMBER (1)                   
                                      HOT-L5-PHONE-NUMBER (2).                  
                                                                                
GBSS  ***  IF  GFM2D-BILLING-NUM-IND EQUAL 'Y'                                  
GBSS  **       MOVE GFM2D-BILLING-NUMBER                                        
GBSS  **                           TO W-GFMBRL2D-BIL-NUM                        
GBSS  **       MOVE W-PHONE-LONG-D TO HOT-L5-LONG-D (LANG-SUB)                  
GBSS  **       MOVE W-PHONE-AREA-C TO HOT-L5-AREA-C (LANG-SUB)                  
GBSS  **       MOVE W-PHONE-NUM-1  TO HOT-L5-NUM-1  (LANG-SUB)                  
GBSS  **       MOVE W-PHONE-NUM-2  TO HOT-L5-NUM-2  (LANG-SUB)                  
GBSS  ***      GO TO HOT-LINE-PROC-X.                                           
                                                                                
           MOVE +0                 TO PHONE-INDEX-SAVE.                         
           MOVE +1                 TO PHONE-INDEX.                              
                                                                                
NAL   *    CHECK TLU111 TO DETERMINE NAL GROUPS                                 
NAL   *    DURING CONVERSION, USE SPECIAL NAL/PAL TOLL FREE NUMBER              
NAL   *    CLAIM OFFICE = 99999 AND GFO = 99999 IF FRENCH /                     
NAL   *    GFO = ***** IF ENGLISH                                               
NAL                                                                             
NAL        MOVE GFM2D-CLAIMS-OFFICE TO WS-PHONE-CLAIMS-OFFICE                   
NAL        MOVE GFM2D-GROUP-OFFICE  TO WS-PHONE-GROUP-OFFICE                    
NAL                                                                             
NAL        MOVE GFM2D-GROUP-NUMBER TO TLU111-GROUP                              
GNE        CALL TLUCOBD USING     TLU111-ERRIND                                 
GNE                                TLU111-SEARCH-ARGUMENT                       
GNE                                TLU111-TABLE-NUM                             
GNE                                TLU111-CII-EFF-DATE                          
GNE                                TLU111-GROUP-EFF-DATE.                       
NAL                                                                             
NAL        IF TLU111-ERRIND = SPACE                                             
ZUR1          IF    GGIGROUP-NUMBER > 0050999                                   
ZUR1            AND GGIGROUP-NUMBER < 0060000                                   
ZUR1          THEN                                                              
ZUR1             NEXT SENTENCE                                                  
ZUR1          ELSE                                                              
ZUR1             MOVE '99999'             TO WS-PHONE-CLAIMS-OFFICE             
ZUR1             IF GGIRESIDENCE = '01' OR GGILANGUAGE  = 'F'                   
ZUR1                MOVE '99999'          TO WS-PHONE-GROUP-OFFICE              
ZUR1             ELSE                                                           
ZUR1                MOVE '*****'          TO WS-PHONE-GROUP-OFFICE              
ZUR1  *          END-IF                                                         
ZUR1  *       END-IF                                                            
ZUR1  *    END-IF                                                               
ZUR1       .                                                                    
                                                                                
GBSS  *                                                                         
GBSS  *    GBSS TASK 37699 - USE ENGLISH OR FRENCH TOLL FREE                    
GBSS  *    CLAIM OFFICE = 99999 AND GFO = 99999 IF FRENCH /                     
GBSS  *    CLAIM OFFICE = 99999 AND GFO = ***** IF ENGLISH                      
GBSS  *                                                                         
GBSS       MOVE '99999'             TO WS-PHONE-CLAIMS-OFFICE.                  
GBSS         IF GGILANGUAGE  = 'F'                                              
GBSS            MOVE '99999'          TO WS-PHONE-GROUP-OFFICE                  
GBSS         ELSE                                                               
GBSS            MOVE '*****'          TO WS-PHONE-GROUP-OFFICE.                 
                                                                                
           PERFORM PHONE-SEARCH    THRU PHONE-SEARCH-EXIT                       
             UNTIL PHONE-INDEX-SAVE NOT EQUAL +0.                               
                                                                                
           IF  TELEPHONE-LOCAL (PHONE-INDEX-SAVE) NOT EQUAL SPACES              
               MOVE TELEPHONE-LOCAL (PHONE-INDEX-SAVE)                          
                                   TO HOT-L4-PHONE-NUMBER (LANG-SUB)            
               MOVE TELEPHONE-CITY  (PHONE-INDEX-SAVE)                          
                                   TO HOT-L4-CITY         (LANG-SUB).           
                                                                                
           MOVE TELEPHONE-TOLL-FREE (PHONE-INDEX-SAVE)                          
                                   TO HOT-L5-PHONE-NUMBER (LANG-SUB).           
       HOT-LINE-PROC-X.                                                         
           EXIT.                                                                
                                                                                
       PHONE-SEARCH.                                                            
      ******************************************************************        
      *    TABLE SEARCH FOR PHONE NUMBERS. CLAIMS OFFICE/GFO ARE KEYS.          
      *    NOTE: LAST TABLE ENTRY HAS CLAIMS OFFICE = '*****' AND               
      *          GFO = '*****' WHICH GUARANTEES A MATCH AND IS USED             
      *          AS THE SEARCH DEFAULT.                                         
      ******************************************************************        
NAL        IF ( TELEPHONE-CLMS-OFF(PHONE-INDEX) = WS-PHONE-CLAIMS-OFFICE        
             OR TELEPHONE-CLMS-OFF(PHONE-INDEX) = '*****' )                     
           AND                                                                  
NAL           ( TELEPHONE-GFO(PHONE-INDEX)      = WS-PHONE-GROUP-OFFICE         
             OR TELEPHONE-GFO(PHONE-INDEX)      = '*****' )                     
           THEN                                                                 
                MOVE PHONE-INDEX     TO PHONE-INDEX-SAVE                        
           ELSE                                                                 
               ADD  +1               TO PHONE-INDEX                             
      *    END-IF                                                               
           .                                                                    
       PHONE-SEARCH-EXIT.                                                       
                           EXIT.                                                
                                                                                
      *----------------------------------------------------------------*        
      *    BUILD THE DATA IN THE SUMMARY LINES TABLE AREA.  ONCE IT IS *        
      *    BUILT, PRINT THE DATA LINES ACCORDINGLY.                    *        
      *----------------------------------------------------------------*        
       BUILD-OUT-SUMM-LINES.                                                    
           COMPUTE AMOUNT-OUTSTANDING = GFM2E-PREM-DUE-LAST-MTH +               
                                        PAY-REVERSE + PAY-RECEIVE1-AMT +        
                                        PAY-RECEIVE2-AMT +                      
                                        PAY-RECEIVE3-AMT.                       
           COMPUTE TOTAL-PREM-DUE-THIS-MONTH = AMOUNT-OUTSTANDING +             
                                          GFM2E-GROSS-PREM-DUE-THIS-MTH.        
           IF TOTAL-PREM-DUE-THIS-MONTH NOT EQUAL                               
              GFM2E-NET-PREM-DUE-THIS-MTH                                       
              MOVE 'M39' TO E-CODE                                              
              PERFORM ERR-RTN.                                                  
           IF (GFM2E-GROUP-TAX-IND EQUAL 'Y')                                   
              MOVE TOT-DUE-LAST-MTH-LIT (LANG-SUB) TO                           
                   SUMM-LINE-PART1 (1)                                          
           ELSE                                                                 
              MOVE DUE-LAST-MTH-LIT (LANG-SUB) TO SUMM-LINE-PART1 (1).          
           IF GFM2E-PREM-DUE-LAST-MTH < +0                                      
               MOVE 'CR'   TO CR-VALUE (1)                                      
               MOVE GFM2E-PREM-DUE-LAST-MTH TO SUMM-LINE-EDIT1 (1)              
           ELSE                                                                 
               MOVE SPACES TO CR-VALUE (1)                                      
               MOVE GFM2E-PREM-DUE-LAST-MTH TO SUMM-LINE-EDIT1 (1)              
           END-IF.                                                              
      *                                                                         
           MOVE +3 TO SUB1.                                                     
           IF PAY-REVERSE NOT EQUAL +0                                          
              MOVE PAY-REVERSE-LIT (LANG-SUB) TO SUMM-LINE-PART1 (SUB1)         
              MOVE PAY-REVERSE TO SUMM-LINE-EDIT1 (SUB1)                        
              ADD +2 TO SUB1.                                                   
           IF (GFM2E-GROUP-TAX-IND EQUAL 'Y')                                   
              MOVE PAYMT-REC-LIT (LANG-SUB) TO SUMM-LINE-PART1 (SUB1)           
           ELSE                                                                 
             MOVE PAY-RECEIVE-LIT (LANG-SUB) TO SUMM-LINE-PART1 (SUB1).         
           MOVE PAY-RECEIVE1-AMT TO SUMM-LINE-EDIT1 (SUB1).                     
           IF PAY-RECEIVE1-AMT NOT EQUAL ZERO                                   
              CALL 'QDATE' USING QDATE-PARM PAY-RECEIVE1-DATE                   
                                            WS-DATE1                            
              MOVE SPACES            TO WS-DATE2                                
              MOVE WS-DAY1           TO WS-DAY2                                 
              MOVE WS-MONTH1         TO WS-MONTH2                               
              MOVE WS-YEAR1          TO WS-YEAR2                                
              MOVE WS-DATE2          TO SUMM-LINE-NEW-DATE (SUB1).              
                                                                                
           IF PAY-RECEIVE2-AMT NOT EQUAL ZERO                                   
              ADD +1 TO SUB1                                                    
              MOVE PAY-RECEIVE2-AMT TO SUMM-LINE-EDIT1 (SUB1)                   
              CALL 'QDATE' USING QDATE-PARM PAY-RECEIVE2-DATE                   
                                            WS-DATE1                            
              MOVE SPACES            TO WS-DATE2                                
              MOVE WS-DAY1           TO WS-DAY2                                 
              MOVE WS-MONTH1         TO WS-MONTH2                               
              MOVE WS-YEAR1          TO WS-YEAR2                                
              MOVE WS-DATE2          TO SUMM-LINE-NEW-DATE (SUB1).              
                                                                                
           IF PAY-RECEIVE3-AMT NOT EQUAL ZERO                                   
              ADD +1 TO SUB1                                                    
              MOVE PAY-RECEIVE3-AMT TO SUMM-LINE-EDIT1 (SUB1)                   
              CALL 'QDATE' USING QDATE-PARM PAY-RECEIVE3-DATE                   
                                            WS-DATE1                            
              MOVE SPACES            TO WS-DATE2                                
              MOVE WS-DAY1           TO WS-DAY2                                 
              MOVE WS-MONTH1         TO WS-MONTH2                               
              MOVE WS-YEAR1          TO WS-YEAR2                                
              MOVE WS-DATE2          TO SUMM-LINE-NEW-DATE (SUB1).              
           ADD +2 TO SUB1.                                                      
           IF (GFM2E-GROUP-TAX-IND EQUAL 'Y')                                   
              MOVE OUTSTAND-LIT (LANG-SUB) TO SUMM-LINE-PART1 (SUB1)            
           ELSE                                                                 
              MOVE AMOUNT-OUT-LIT (LANG-SUB) TO SUMM-LINE-PART1 (SUB1).         
           MOVE AMOUNT-OUTSTANDING TO SUMM-LINE-EDIT1 (SUB1).                   
           ADD +2 TO SUB1.                                                      
           MOVE MON-PREM-LIT (LANG-SUB) TO SUMM-LINE-PART1 (SUB1).              
           MOVE GFM2E-GROSS-PREM-DUE-THIS-MTH TO                                
                                           SUMM-LINE-EDIT1 (SUB1).              
           ADD +2 TO SUB1.                                                      
      *                                                                         
      * IF IT NOT A TAXABLE ACCOUNT, CREATE A TOTAL PREMIUM DUE LINE            
      * AND GO TO SUMM-CONT.                                                    
      * IF IT IS A TAXABLE ACCOUNT, CREATE A CURRENT MONTH TAX DUE LINE         
      * AND A TOTAL DUE LINE.                                                   
      *                                                                         
           IF (GFM2E-GROUP-TAX-IND NOT EQUAL 'Y')                               
               MOVE TOT-PREM-DUE-LIT (LANG-SUB) TO                              
                    SUMM-LINE-PART1 (SUB1)                                      
               IF TOTAL-PREM-DUE-THIS-MONTH < +0                                
                   MOVE TOTAL-PREM-DUE-THIS-MONTH TO                            
                           SUMM-LINE-EDIT1 (SUB1)                               
                   MOVE 'CR'   TO CR-VALUE (SUB1)                               
               ELSE                                                             
                   MOVE TOTAL-PREM-DUE-THIS-MONTH TO                            
                           SUMM-LINE-EDIT1 (SUB1)                               
                   MOVE SPACES TO CR-VALUE (SUB1)                               
               END-IF                                                           
                                                                                
               GO TO SUMM-CONT                                                  
           END-IF.                                                              
                                                                                
           MOVE PROV-TAX-LIT (LANG-SUB)    TO SUMM-LINE-PART1 (SUB1).           
           MOVE GFM2E-TAX-CURR-TOTAL       TO SUMM-LINE-EDIT1 (SUB1).           
                                                                                
           ADD +2 TO SUB1.                                                      
           MOVE TOTAL-DUE-LIT (LANG-SUB) TO SUMM-LINE-PART1 (SUB1).             
           COMPUTE TOTAL-BILL = TOTAL-PREM-DUE-THIS-MONTH +                     
                                GFM2E-TAX-CURR-TOTAL.                           
                                                                                
           IF TOTAL-BILL < +0                                                   
               MOVE 'CR'   TO CR-VALUE (SUB1)                                   
               MOVE TOTAL-BILL TO SUMM-LINE-EDIT1 (SUB1)                        
           ELSE                                                                 
               MOVE SPACES TO CR-VALUE (SUB1)                                   
               MOVE TOTAL-BILL TO SUMM-LINE-EDIT1 (SUB1)                        
           END-IF.                                                              
                                                                                
       SUMM-CONT.                                                               
      ******************************************************************        
      *    BUILD THE APPROPRIATE LITERALS ON THE SECOND PIECE OF THE            
      *    SUMMARY LINES ACCORDING TO THE TYPE OF REPORT BEING PRODUCED.        
      ******************************************************************        
           IF  GFM2D-BFSO-CHANGE-BILLING NOT EQUAL 'S'                          
               MOVE POLICY-COMM-LIT1 (LANG-SUB) TO SUMM-LINE-PART2 (5)          
               MOVE POLICY-COMM-LIT2 (LANG-SUB) TO SUMM-LINE-PART2 (6)          
               GO TO BUILD-OUT-SUMM-LINES-EXIT.                                 
      *----------------------------------------------------------------*        
      *    BUILD THE SECOND PART OF THE LINES WHICH ARE PRINTED ON A   *        
      *    SUMMARY LIST ONLY.                                          *        
      *  - ACCUMULATE THE COLUMN TOTALS INCLUDING THE FINAL TOTAL      *        
      *----------------------------------------------------------------*        
           MOVE CURR-POL-STAT-LIT (LANG-SUB) TO SUMM-LINE-PART2 (1).            
           PERFORM BUILD-GRP-TOTALS THRU BUILD-GRP-TOTALS-EXIT.                 
      *                                                                         
      *    MOVE THE COLUMN TITLES AND AMOUNTS TO THE SUMMARY LINES              
      *                                                                         
       MOVE-SUMM-LINES-PART2.                                                   
           MOVE +1 TO LINE-SUB.                                                 
           MOVE +0 TO TITLE-SUB.                                                
       MOVE-SUMM-LINES-PART2-LOOP.                                              
           ADD +2 TO LINE-SUB.                                                  
           ADD +1 TO TITLE-SUB.                                                 
           IF TITLE-SUB GREATER THAN 9 OR                                       
              GFM2D-BC-PREM-OR-VOL (TITLE-SUB) EQUAL ' '                        
              GO TO MOVE-SUMM-TOTAL-LINE.                                       
           IF GFM2D-BC-PREM-OR-VOL (TITLE-SUB) EQUAL 'B'                        
              GO TO MOVE-SUMM-LINES-PART2-LOOP.                                 
           MOVE GFM2D-BC-TITLE-LINE1 (TITLE-SUB) TO                             
                                      SUMM-LINE-LIT2-1 (LINE-SUB).              
           MOVE GFM2D-BC-TITLE-LINE2 (TITLE-SUB) TO                             
                                      SUMM-LINE-LIT2-2 (LINE-SUB).              
           MOVE COL-ACCUM (TITLE-SUB) TO SUMM-LINE-EDIT2 (LINE-SUB).            
           GO TO MOVE-SUMM-LINES-PART2-LOOP.                                    
       MOVE-SUMM-TOTAL-LINE.                                                    
           MOVE TOTAL-SUMM-COL-LINE1 (LANG-SUB) TO                              
                                      SUMM-LINE-LIT2-1 (LINE-SUB).              
           MOVE TOTAL-SUMM-COL-LINE2 (LANG-SUB) TO                              
                                      SUMM-LINE-LIT2-2 (LINE-SUB).              
           MOVE COL-ACCUM (TITLE-SUB) TO SUMM-LINE-EDIT2 (LINE-SUB).            
           DISPLAY 'TSC-LINE2:' TOTAL-SUMM-COL-LINE1 (LANG-SUB).                
           DISPLAY 'TSC-LINE2:' TOTAL-SUMM-COL-LINE2 (LANG-SUB).                
           DISPLAY 'COL-ACCUM:' COL-ACCUM (TITLE-SUB).                          
       BUILD-OUT-SUMM-LINES-EXIT.                                               
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *    KEEP READING RECORDS UNTIL ONE OF THE FOLLOWING HAPPENS     *        
      *    - REACH END OF FILE                                         *        
      *    - NO MORE BILLING RECORDS LEFT                              *        
      *    - GROUP/ACCT ON RECORD READ DOES NOT MATCH GROUP/ACCT ON THE*        
      *      SUMMARY RECORD                                            *        
      *    - RECORD PROCESSED IS NOT A PAYMENT RECORD                  *        
      *                                                                *        
      *    FOR EACH PAYMENT RECORD PROCESSED, ACCUMULATE THE AMOUNT    *        
      *      RECEIVED, THE AMOUNT REVERSED.  FOR THE AMOUNT RECEIVED,  *        
      *      THE FIRST ENTRY WILL CONTAIN THE FIRST SET OF TAX AND     *        
      *      PREMIUM PAYMENTS IF THEY ARE THE SAME DATE.  THE SECOND   *        
      *      ENTRY WILL CONTAIN THE SECOND SET AND THE THIRD ENTRY     *        
      *      WILL ACCUMULATE THE REST OF THE PAYMENTS.                 *        
      *----------------------------------------------------------------*        
       SUM-PAYMENT-REC.                                                         
           MOVE +0 TO PAY-RECEIVE1-AMT                                          
           MOVE +0 TO PAY-RECEIVE2-AMT                                          
           MOVE +0 TO PAY-RECEIVE3-AMT                                          
           MOVE +0 TO PAY-REVERSE.                                              
           MOVE SPACES TO PAY-RECEIVE1-DATE  PAY-RECEIVE2-DATE                  
                          PAY-RECEIVE3-DATE.                                    
           MOVE 'N' TO PREM-PAY1 TAX-PAY1 PREM-PAY2 TAX-PAY2.                   
E42        PERFORM 4100-START-PAYMENT  THRU 4100-START-PAYMENT-EXIT.            
       SUM-PAYMENT-LOOP.                                                        
           PERFORM READ-RECORD THRU READ-RECORD-EXIT.                           
           IF (TAPE-RETURN NOT EQUAL ZERO) OR                                   
              (T-REC-TYPE NOT EQUAL '2')                                        
E42            PERFORM 4900-FINISH-PAYMENT THRU                                 
E42                    4900-FINISH-PAYMENT-EXIT                                 
               GO TO SUM-PAYMENT-REC-EXIT.                                      
           IF (T-GROUP NOT EQUAL GFM2D-GROUP-NUMBER) OR                         
              (T-ORD EQUAL 'D') OR                                              
              (T-ACCT NOT EQUAL GFM2D-ACCOUNT)                                  
E42            PERFORM 4900-FINISH-PAYMENT THRU                                 
E42                    4900-FINISH-PAYMENT-EXIT                                 
               GO TO SUM-PAYMENT-REC-EXIT.                                      
           IF T-ORD NOT EQUAL 'G' AND 'H'                                       
E42            PERFORM 4900-FINISH-PAYMENT THRU                                 
E42                    4900-FINISH-PAYMENT-EXIT                                 
               GO TO SUM-PAYMENT-REC-EXIT.                                      
           MOVE TAPE-REC TO GBILLING-PAYMENT-RECORD.                            
E42        PERFORM 4500-EXTRACT-PAYMENT THRU 4500-EXTRACT-PAYMENT-EXIT.         
           IF GBILL-PAY-PAYMENT-AMOUNT GREATER THAN +0                          
              ADD GBILL-PAY-PAYMENT-AMOUNT TO PAY-REVERSE                       
              GO TO SUM-PAYMENT-LOOP.                                           
           IF GBILL-PAY-REG-TAX EQUAL 'T'                                       
              GO TO TAX-PAYMENT.                                                
                                                                                
           IF PAY-RECEIVE1-DATE EQUAL SPACES                                    
              MOVE GBILL-PAY-PAYMENT-DATE TO PAY-RECEIVE1-DATE                  
              MOVE GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE1-AMT                 
              MOVE 'Y' TO PREM-PAY1                                             
              GO TO SUM-PAYMENT-LOOP.                                           
           IF GBILL-PAY-PAYMENT-DATE EQUAL PAY-RECEIVE1-DATE                    
              AND PREM-PAY1 NOT EQUAL TO 'Y'                                    
                ADD GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE1-AMT                
                MOVE 'Y' TO PREM-PAY1                                           
                GO TO SUM-PAYMENT-LOOP.                                         
           IF PAY-RECEIVE2-DATE EQUAL SPACES                                    
              MOVE GBILL-PAY-PAYMENT-DATE TO PAY-RECEIVE2-DATE                  
              MOVE GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE2-AMT                 
              MOVE 'Y' TO PREM-PAY2                                             
              GO TO SUM-PAYMENT-LOOP.                                           
           IF GBILL-PAY-PAYMENT-DATE EQUAL PAY-RECEIVE2-DATE                    
              AND PREM-PAY2 NOT EQUAL TO 'Y'                                    
                ADD GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE2-AMT                
                MOVE 'Y' TO PREM-PAY2                                           
                GO TO SUM-PAYMENT-LOOP.                                         
           MOVE GBILL-PAY-PAYMENT-DATE TO PAY-RECEIVE3-DATE                     
           ADD  GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE3-AMT                    
           GO TO SUM-PAYMENT-LOOP.                                              
                                                                                
       TAX-PAYMENT.                                                             
           IF PAY-RECEIVE1-DATE EQUAL SPACES                                    
              MOVE GBILL-PAY-PAYMENT-DATE TO PAY-RECEIVE1-DATE                  
              MOVE GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE1-AMT                 
              MOVE 'Y' TO TAX-PAY1                                              
              GO TO SUM-PAYMENT-LOOP.                                           
           IF GBILL-PAY-PAYMENT-DATE EQUAL PAY-RECEIVE1-DATE                    
              AND TAX-PAY1 NOT EQUAL TO 'Y'                                     
                ADD GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE1-AMT                
                MOVE 'Y' TO TAX-PAY1                                            
                GO TO SUM-PAYMENT-LOOP.                                         
           IF PAY-RECEIVE2-DATE EQUAL SPACES                                    
              MOVE GBILL-PAY-PAYMENT-DATE TO PAY-RECEIVE2-DATE                  
              MOVE GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE2-AMT                 
              MOVE 'Y' TO TAX-PAY2                                              
              GO TO SUM-PAYMENT-LOOP.                                           
           IF GBILL-PAY-PAYMENT-DATE EQUAL PAY-RECEIVE2-DATE                    
              AND TAX-PAY2 NOT EQUAL TO 'Y'                                     
                ADD GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE2-AMT                
                MOVE 'Y' TO TAX-PAY2                                            
                GO TO SUM-PAYMENT-LOOP.                                         
           MOVE GBILL-PAY-PAYMENT-DATE TO PAY-RECEIVE3-DATE                     
           ADD  GBILL-PAY-PAYMENT-AMOUNT TO PAY-RECEIVE3-AMT                    
           GO TO SUM-PAYMENT-LOOP.                                              
       SUM-PAYMENT-REC-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *  - ZERO OUT THE COLUMN TOTALS                                           
      *  - ACCUMULATE THE COLUMN TOTALS INCLUDING THE FINAL TOTAL FOR  *        
      *    THE ENTIRE GROUP/ACCT                                       *        
      *----------------------------------------------------------------*        
       BUILD-GRP-TOTALS.                                                        
           MOVE ZERO TO COL-ACCUM (1).                                          
           MOVE COL-ACCUM-R TO COL-ACCUM-TO-ZERO.                               
           MOVE +1 TO LINE-SUB.                                                 
           MOVE +0 TO COV-SUB.                                                  
       SUMM-COV-LOOP.                                                           
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GFM2E-NO-OF-CODES                            
              GO TO BUILD-GRP-TOTALS-EXIT.                                      
           MOVE +0 TO CHECK-SUB.                                                
       SUMM-CHK-TABLE-LOOP.                                                     
           ADD +1 TO CHECK-SUB.                                                 
           IF CHECK-SUB GREATER THAN TITLE-NUM-CODES                            
              GO TO TOTAL-SUMM-PREM.                                            
           IF (TITLE-COV-CODE (CHECK-SUB) EQUAL 019)        AND                 
              (GFM2E-COVERAGE-CODE (COV-SUB) NOT GREATER                        
                                        THAN EHC-CODE-MAX)  AND                 
              (GFM2E-COVERAGE-CODE (COV-SUB) NOT LESS                           
                                        THAN EHC-CODE-MIN)                      
              GO TO SUMM-FOUND-TABLE-ENTRY.                                     
           IF (TITLE-COV-CODE (CHECK-SUB) EQUAL 099)        AND                 
              (GFM2E-COVERAGE-CODE (COV-SUB) NOT GREATER                        
                                        THAN DEN-CODE-MAX)  AND                 
              (GFM2E-COVERAGE-CODE (COV-SUB) NOT LESS                           
                                        THAN DEN-CODE-MIN)                      
              GO TO SUMM-FOUND-TABLE-ENTRY.                                     
           IF TITLE-COV-CODE (CHECK-SUB) NOT EQUAL                              
                                         GFM2E-COVERAGE-CODE (COV-SUB)          
              GO TO SUMM-CHK-TABLE-LOOP.                                        
      *                                                                         
      *    ENTRY HAS BEEN FOUND.  ACCUMULATE THE REQUIRED VALUES IN COL.        
      *    SPECIFIED                                                            
      *                                                                         
       SUMM-FOUND-TABLE-ENTRY.                                                  
           MOVE +0 TO COL-SUB.                                                  
       SUMM-INCRE-COL-SUB.                                                      
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB GREATER THAN NUM-COLS (CHECK-SUB)                         
              GO TO TOTAL-SUMM-PREM.                                            
           MOVE COLS-OF-COV-CODE (CHECK-SUB, COL-SUB) TO GGI-TITLE-SUB.         
           IF GFM2D-BC-PREM-OR-VOL (GGI-TITLE-SUB) EQUAL 'P'                    
              ADD GFM2E-BILLED-PREMIUM (COV-SUB) TO                             
                                        COL-ACCUM (GGI-TITLE-SUB)               
           ELSE                                                                 
              ADD GFM2E-VOLUME (COV-SUB) TO COL-ACCUM (GGI-TITLE-SUB).          
           GO TO SUMM-INCRE-COL-SUB.                                            
      *                                                                         
      *    ACCUMULATE IN THE TOTAL PREMIUM COLUMN.                              
      *                                                                         
       TOTAL-SUMM-PREM.                                                         
           IF TEST-SUB EQUAL LOW-VALUES                                         
              MOVE +1 TO PREM-SUB.                                              
           ADD GFM2E-BILLED-PREMIUM (COV-SUB) TO COL-ACCUM (PREM-SUB).          
           GO TO SUMM-COV-LOOP.                                                 
       BUILD-GRP-TOTALS-EXIT.                                                   
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *    PRINT THE STORED DETAILS FOR THIS GROUP/ACCT/CERT.  IF ALL           
      *    THE RECORDS WILL NOT FIT ON THE ONE PAGE, GO TO A NEW PAGE           
      *    BEFORE STARTING TO PRINT.  IF IT IS THE LAST PAGE FOR THIS           
      *    GROUP/ACCT, MAKE SURE THERE IS ROOM IN THE BOX FOR THE DASH          
      *    LINE AND THE SUMMARY TOTAL LINE.                                     
      *  - IF AN ADJUSTMENT RECORD MUST BE PRINTED, ALLOW FOR THIS WHEN         
      *    CALCULATING THE NO. OF LINES LEFT ON THE PAGE.                       
      ******************************************************************        
       PRINT-STORED-DETAIL-REC.                                                 
           IF NUM-DETAIL-STORED EQUAL +0                                        
              GO TO PRINT-STORE-DASH-LINE-TEST.                                 
           PERFORM TEST-GENERATE-ADJ THRU TGA-EXIT.                             
           ADD NUM-DETAIL-STORED LINE-CT GIVING TEST-LINE-CT.                   
           IF GENERATE-ADJ-SW EQUAL '1'                                         
              ADD +1 TO TEST-LINE-CT.                                           
      ******************************************************************        
      *    RELEASE # 1.                                                         
      *    IF DIV ADJUSTMENTS EXIST, THE 1ST ONE WILL BE TRIPLE SPACED          
      *    DOWN (INSTEAD OF SINGLE SPACING) SO ADD 2 EXTRA TO LINE-CT.          
      ******************************************************************        
           IF  DIV-ADJ-FOUND-FLAG = 'Y'                                         
               ADD +2 TO TEST-LINE-CT.                                          
           IF  DONE-DETAIL-SW EQUAL '1'                                         
               IF GFM2D-BFSO-CHANGE-BILLING EQUAL 'Y'                           
                  MOVE 27 TO TEST-LINE-MAX                                      
               ELSE                                                             
                  MOVE 28 TO TEST-LINE-MAX                                      
           ELSE                                                                 
               MOVE 30 TO TEST-LINE-MAX.                                        
                                                                                
           IF (TEST-LINE-CT GREATER THAN TEST-LINE-MAX) AND                     
              (LINE-CT NOT EQUAL +0) AND (DONE-DETAIL-SW EQUAL '1')             
               MOVE '0' TO DONE-DIVISION-SW.                                    
                                                                                
           IF (TEST-LINE-CT GREATER THAN TEST-LINE-MAX) AND                     
              (LINE-CT NOT EQUAL +0)                                            
               PERFORM PRINT-RUNNING-SUB THRU PRINT-RUNNING-SUB-EXIT            
               PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT                  
               PERFORM NEW-DETAIL-PAGE THRU NEW-DETAIL-PAGE-EXIT                
               IF DIV-BILL-TYPE-SW EQUAL '1' AND                                
                 DONE-DETAIL-SW EQUAL '1'                                       
                   MOVE '1' TO DONE-DIVISION-SW.                                
                                                                                
           MOVE 'Y'               TO DIV-TRIPLE-SPACE-FLAG.                     
           MOVE +0 TO SUB1.                                                     
       PRINT-STORED-DETAIL-LOOP.                                                
           ADD +1 TO SUB1.                                                      
           IF SUB1 GREATER THAN NUM-DETAIL-STORED                               
              GO TO PRINT-GENERATE-ADJ-REC-TEST.                                
           IF LINE-CT GREATER THAN TEST-LINE-MAX                                
               PERFORM PRINT-RUNNING-SUB THRU PRINT-RUNNING-SUB-EXIT            
               PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT                  
               PERFORM NEW-DETAIL-PAGE THRU NEW-DETAIL-PAGE-EXIT.               
           IF DETAIL-DETAIL-IDENT (SUB1) EQUAL 'S'                              
              MOVE DETAIL-RECORDS (SUB1) TO GBC-BILL-CURR-RECORD                
              PERFORM PRINT-DETAIL-CURR-RECORD THRU                             
                      PRINT-DETAIL-CURR-RECORD-EXIT                             
              ADD +1         TO LINE-CT                                         
           ELSE                                                                 
           IF DETAIL-DETAIL-IDENT (SUB1) EQUAL 'T'                              
              MOVE DETAIL-RECORDS (SUB1) TO GBA-BILL-ADJ-RECORD                 
              PERFORM PRINT-DETAIL-ADJ-RECORD THRU                              
                      PRINT-DETAIL-ADJ-RECORD-EXIT                              
              ADD +1         TO LINE-CT                                         
           ELSE                                                                 
              MOVE DETAIL-RECORDS (SUB1) TO GFMEDD90-ADJUST-RECORD              
              PERFORM PRINT-D90-ADJ-RECORD THRU                                 
                      PRINT-D90-ADJ-RECORD-EXIT                                 
              IF  DIV-TRIPLE-SPACE-FLAG = 'Y'                                   
                  MOVE 'N'   TO DIV-TRIPLE-SPACE-FLAG                           
                  ADD  +3    TO LINE-CT                                         
              ELSE                                                              
                  ADD  +1    TO LINE-CT.                                        
                                                                                
           GO TO PRINT-STORED-DETAIL-LOOP.                                      
      ******************************************************************        
      *    IF AN ADJUSTMENT LINE MUST BE GENERATED, SET UP A SKELETON           
      *    RECORD AND THEN CALL THE APPROPRIATE ROUTINE TO PRINT IT.            
      ******************************************************************        
       PRINT-GENERATE-ADJ-REC-TEST.                                             
           IF GENERATE-ADJ-SW EQUAL '0'                                         
              GO TO PRINT-STORE-DASH-LINE-TEST.                                 
           IF LINE-CT GREATER THAN TEST-LINE-MAX                                
               PERFORM PRINT-RUNNING-SUB THRU PRINT-RUNNING-SUB-EXIT            
               PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT                  
               PERFORM NEW-DETAIL-PAGE THRU NEW-DETAIL-PAGE-EXIT.               
           MOVE +0                      TO GBA-NUM-COV-CODES.                   
           MOVE +0                      TO GBA-TOTAL-PREMIUM.                   
           MOVE GFM2D-FROM-DATE         TO GBA-EFFECTIVE-DATE.                  
      ******************************************************************        
      *    MAR/90 M. PRANGE.                                                    
      *    ON ADDITIONS USE THE CERT ISSUE DATE IF AVAILABLE.                   
      ******************************************************************        
           IF  GFM2D-STATEMENT-TYPE = 'I'                                       
               MOVE 'AD'                      TO GBA-ADJ-MODE                   
               IF  GBC-DETAIL-ISSUE-YEAR NUMERIC   AND                          
                   GBC-DETAIL-ISSUE-DAY  NUMERIC   AND                          
                   GBC-DETAIL-ISSUE-YEAR NOT = +0  AND                          
                   GBC-DETAIL-ISSUE-DAY  NOT = +0                               
                   MOVE GBC-DETAIL-ISSUE-DATE TO GBA-EFFECTIVE-DATE.            
                                                                                
      ******************************************************************        
      *    MAR/90 M. PRANGE.                                                    
      *    ON REINSTATEMENTS USE THE CERT REINSTATE DATE IF AVAILABLE.          
      ******************************************************************        
           IF  GFM2D-STATEMENT-TYPE = 'R'                                       
               MOVE 'RI'                       TO GBA-ADJ-MODE                  
               IF  GBC-DETAIL-REINST-YEAR NUMERIC  AND                          
                   GBC-DETAIL-REINST-DAY  NUMERIC  AND                          
                   GBC-DETAIL-REINST-YEAR NOT = +0 AND                          
                   GBC-DETAIL-REINST-DAY  NOT = +0                              
                   MOVE GBC-DETAIL-REINST-DATE TO GBA-EFFECTIVE-DATE.           
                                                                                
      ******************************************************************        
      *    RELEASE # 1.                                                         
      *    ON TERMINATIONS USE THE CERT TERMED DATE IF AVAILABLE.               
      ******************************************************************        
           IF  GFM2D-STATEMENT-TYPE = 'T'                                       
               MOVE 'TE'                      TO GBA-ADJ-MODE                   
               IF  GBC-DETAIL-TERM-YEAR NUMERIC   AND                           
                   GBC-DETAIL-TERM-DAY  NUMERIC   AND                           
                   GBC-DETAIL-TERM-YEAR NOT = +0  AND                           
                   GBC-DETAIL-TERM-DAY  NOT = +0                                
                   MOVE GBC-DETAIL-TERM-DATE  TO GBA-EFFECTIVE-DATE.            
                                                                                
           PERFORM PRINT-DETAIL-ADJ-RECORD THRU                                 
                   PRINT-DETAIL-ADJ-RECORD-EXIT.                                
           ADD +1 TO LINE-CT.                                                   
                                                                                
       PRINT-STORE-DASH-LINE-TEST.                                              
           IF DIV-BILL-TYPE-SW EQUAL '1' AND                                    
                 DONE-DIVISION-SW EQUAL '1'                                     
               PERFORM PRINT-RUNNING-SUB THRU PRINT-RUNNING-SUB-EXIT            
               PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT                  
               PERFORM NEW-DETAIL-PAGE THRU NEW-DETAIL-PAGE-EXIT.               
           IF (DONE-DETAIL-SW EQUAL '1')                                        
               PERFORM END-GRP THRU END-GRP-EXIT                                
           ELSE                                                                 
               IF (CURR-GROUP EQUAL +10888 AND CURR-ACCT EQUAL '000'            
                   AND GFM2D-BFSO-CHANGE-BILLING EQUAL 'Y')                     
                   MOVE ' ' TO CC                                               
                   PERFORM OUTPUT-RTN THRU OP-EXIT                              
                   MOVE ' ' TO CC                                               
                   ADD +1 TO LINE-CT.                                           
           MOVE +0 TO NUM-DETAIL-STORED.                                        
       PRINT-STORED-DETAIL-REC-EXIT.                                            
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *    DETERMINE IF AN ADJUSTMENT RECORD MUST BE AUTOMATICALLY     *        
      *    GENERATED (IF ISSUE OR REINSTATEMENT AND AN ADJUSTMENT REC. *        
      *    DOES NOT EXIST AND THERE IS SOME COVERAGE TAKEN  O R  IF    *        
      *    TERMINATION AND THERE IS NOT AN ADJUSTMENT RECORD FOR A     *        
      *    PREVIOUS TERMINATION                                        *        
      *                                                                *        
      *    IF CERT NO IS HIGH-VALUES (D90 GROUP ADJUSTMENT) DO NOT GEN-*        
      *    ERATE AN ADJUSTMENT LINE.                                   *        
      *----------------------------------------------------------------*        
       TEST-GENERATE-ADJ.                                                       
           MOVE '0' TO GENERATE-ADJ-SW.                                         
           IF ADJ-RECD-CERT-REQD-SW = '0'                                       
              GO TO TGA-EXIT.                                                   
           IF PREV-CERT EQUAL +999999999                                        
              GO TO TGA-EXIT.                                                   
           IF ADJ-RECD-FND-SW EQUAL '1'                                         
              IF GFM2D-STATEMENT-TYPE EQUAL 'R' OR 'I'                          
                 GO TO TGA-EXIT.                                                
      *                                                                         
      *  FOR ISSUE, REINSTATEMENT CHECK THE SEL IND IN THE CURRENT              
      *  RECORD - SHOULD ALWAYS BE THE FIRST ENTRY IN THE TABLE IF LESS         
      *  THAN 30 RECORDS FOR THIS GROUP/ACCT OR IN THE CURR BILLING             
      *  RECORD LAYOUT IF THERE ARE MORE                                        
      *                                                                         
           IF GFM2D-STATEMENT-TYPE EQUAL 'T'                                    
              GO TO TEST-GEN-TERMINATION.                                       
           IF DETAIL-DETAIL-IDENT (1) EQUAL 'S'                                 
              MOVE DETAIL-RECORDS (1) TO GBC-BILL-CURR-RECORD.                  
           MOVE +0 TO COV-SUB.                                                  
       TEST-GEN-ISSUE-REIN-LOOP.                                                
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GBC-NUM-COV-CODES                            
              GO TO TGA-EXIT.                                                   
           IF GBC-SEL-IND (COV-SUB) EQUAL 'WA' OR 'DE' OR 'NT' OR               
                                          'CT' OR 'LA' OR 'DA'                  
              GO TO TEST-GEN-ISSUE-REIN-LOOP.                                   
           MOVE '1' TO GENERATE-ADJ-SW.                                         
           GO TO TGA-EXIT.                                                      
       TEST-GEN-TERMINATION.                                                    
           IF ADJ-RECD-FND-SW EQUAL '0'                                         
              MOVE '1' TO GENERATE-ADJ-SW                                       
              GO TO TGA-EXIT.                                                   
      *                                                                         
      *    CHECK THE ADJUSTMENT LINES TO SEE IF A PREVIOUS TERMINATION          
      *    WITH NO REINSTATEMENT EXISTS.                                        
      *                                                                         
           MOVE LOW-VALUES TO TEST-DATE                                         
           MOVE SPACES TO TEST-MODE.                                            
           MOVE +0 TO REC-SUB.                                                  
       TEST-GEN-TERM-LOOP.                                                      
           ADD +1 TO REC-SUB.                                                   
           IF REC-SUB GREATER THAN NUM-DETAIL-STORED                            
              GO TO TEST-GEN-TERM-FIELDS.                                       
           IF DETAIL-DETAIL-IDENT (REC-SUB) NOT EQUAL 'T'                       
              GO TO TEST-GEN-TERM-LOOP.                                         
           IF DETAIL-ADJ-EFF-DATE (REC-SUB) GREATER THAN TEST-DATE              
              MOVE DETAIL-ADJ-EFF-DATE (REC-SUB) TO TEST-DATE                   
              MOVE DETAIL-ADJ-MODE     (REC-SUB) TO TEST-MODE.                  
           GO TO TEST-GEN-TERM-LOOP.                                            
       TEST-GEN-TERM-FIELDS.                                                    
           IF TEST-MODE NOT EQUAL 'TE'                                          
              MOVE '1' TO GENERATE-ADJ-SW.                                      
       TGA-EXIT.                                                                
           EXIT.                                                                
                                                                                
       PRINT-DETAIL-CURR-RECORD.                                                
           MOVE GBC-NUM-COV-CODES TO WORK-NUM-COV-CODES.                        
           PERFORM BUILD-DETAIL-COL THRU BUILD-DETAIL-COL-EXIT.                 
           IF GBC-ORDER EQUAL 'Q'                                               
              MOVE GBC-NAME-1 TO P-NAME                                         
              MOVE GBC-CERT-1 TO P-CERT                                         
           ELSE                                                                 
              MOVE GBC-NAME-2 TO P-NAME                                         
              MOVE GBC-CERT-2 TO P-CERT.                                        
           MOVE GBC-TAXABLE-IND TO P-TAX-IND.                                   
           MOVE GBC-TAX-CODE    TO P-TAX-CODE.                                  
           MOVE GBC-CLASS TO P-CLASS.                                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PRINT-DETAIL-CURR-RECORD-EXIT.                                           
           EXIT.                                                                
                                                                                
       PRINT-DETAIL-ADJ-RECORD.                                                 
           MOVE GBA-NUM-COV-CODES TO WORK-NUM-COV-CODES.                        
           IF WORK-NUM-COV-CODESX EQUAL SPACES THEN                             
              MOVE +0 TO WORK-NUM-COV-CODES9                                    
              MOVE +0 TO GBA-NUM-COV-CODES.                                     
           PERFORM BUILD-DETAIL-COL THRU BUILD-DETAIL-COL-EXIT.                 
      ******************************************************************        
      * GIPSY RELEASE 1, USE ALTERNATE SOURCE FOR CERT EFF DATE IF              
      *                  CERT IS A 'MODE 12' ADDITION.  I. BUCKNELL             
      ******************************************************************        
           IF  DETAIL-ADJ-MODE (SUB1) = '12'                                    
               CALL 'QDATE' USING QDATE-PARM DETAIL-ADJ-EFF-DATE (SUB1)         
                                             P-ADJ-EFFDATE                      
           ELSE                                                                 
               CALL 'QDATE' USING QDATE-PARM GBA-EFFECTIVE-DATE                 
                                             P-ADJ-EFFDATE.                     
           MOVE 'EFF' TO P-ADJ-EFF-LIT.                                         
      *                                                                         
      *    FIND THE ADJUSTMENT MODE IN THE TABLE SO A LITERAL CAN BE            
      *    PUT IN THE REQUIRED FIELD.                                           
      *                                                                         
           MOVE +0 TO ADJ-SUB.                                                  
       FIND-ADJ-LIT-LOOP.                                                       
           ADD +1 TO ADJ-SUB.                                                   
           IF ADJ-SUB GREATER THAN NUM-ADJ-VALUES                               
              GO TO PRINT-ADJ-LINE.                                             
           IF GBA-ADJ-MODE EQUAL ADJ-TYPE (ADJ-SUB)                             
              MOVE ADJ-LIT-LANG (ADJ-SUB, LANG-SUB) TO P-ADJ-LIT                
           ELSE                                                                 
              GO TO FIND-ADJ-LIT-LOOP.                                          
       PRINT-ADJ-LINE.                                                          
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PRINT-DETAIL-ADJ-RECORD-EXIT.                                            
           EXIT.                                                                
                                                                                
       PRINT-D90-ADJ-RECORD.                                                    
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    IS THIS A D90 CERT ADJUSTMENT OR IS IT DIVISIONAL?                   
      *    THE DIV ADJUSTMENT PRINT LINE HAS A LITTLE DIFFERENT                 
      *    SPACING THAN NORMAL TYPE ADJUSTMENTS.                                
      ****************************************************************          
           IF  GD90AR-ORDER EQUAL 'Q'                                           
               IF  GD90AR-NC-CERTIFICATE = +999999999                           
                   GO TO PRINT-DIV-ADJ-RECORD                                   
               ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               IF  GD90AR-CN-CERTIFICATE = +999999999                           
                   GO TO PRINT-DIV-ADJ-RECORD.                                  
                                                                                
           MOVE 'N'                TO DIV-TRIPLE-SPACE-FLAG.                    
           MOVE GD90AR-NO-OF-CODES TO WORK-NUM-COV-CODES.                       
           PERFORM BUILD-DETAIL-COL THRU BUILD-DETAIL-COL-EXIT.                 
                                                                                
           IF GD90AR-DETAIL-REMARKS NOT = SPACES                                
              MOVE GD90AR-DETAIL-REMARKS    TO P-D90-ADJ-LIT                    
           ELSE                                                                 
              IF LANG-SUB EQUAL 1                                               
                 MOVE 'RETROACTIVE ADJ.'    TO P-D90-ADJ-LIT                    
              ELSE                                                              
                 MOVE 'RECT. RqTROACT.'  TO P-D90-ADJ-LIT.              YEAR2000
                                                                                
           CALL 'QDATE' USING QDATE-PARM GD90AR-EFFECTIVE-DATE                  
                                      P-D90-EFFDATE.                            
                                                                                
           MOVE GD90AR-TAX-IND              TO P-D90-TAX-IND.                   
           MOVE GD90AR-TAX-CODE             TO P-D90-TAX-CODE.                  
                                                                                
           IF SUB1 = +1                                                         
              IF GD90AR-ORDER EQUAL 'Q'                                         
                 IF GD90AR-NC-CERTIFICATE NOT EQUAL +999999999                  
                    MOVE GD90AR-NC-CERTIFICATE TO P-CERT                        
                 ELSE                                                           
                    NEXT SENTENCE                                               
              ELSE                                                              
                 IF  GD90AR-CN-CERTIFICATE NOT EQUAL +999999999                 
                     MOVE GD90AR-CN-CERTIFICATE TO P-CERT.                      
                                                                                
           MOVE ' '       TO CC.                                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           GO TO PRINT-D90-ADJ-RECORD-EXIT.                                     
                                                                                
       PRINT-DIV-ADJ-RECORD.                                                    
           IF  DIV-TRIPLE-SPACE-FLAG = 'Y'                                      
               MOVE ' '   TO CC                                                 
               PERFORM OUTPUT-RTN THRU OP-EXIT                                  
               MOVE ' '   TO CC                                                 
               PERFORM OUTPUT-RTN THRU OP-EXIT.                                 
           MOVE GD90AR-NO-OF-CODES TO WORK-NUM-COV-CODES.                       
           PERFORM BUILD-DETAIL-COL THRU BUILD-DETAIL-COL-EXIT.                 
                                                                                
           IF GD90AR-DETAIL-REMARKS NOT EQUAL SPACES                            
              MOVE GD90AR-DETAIL-REMARKS    TO P-DIV-ADJ-LIT                    
           ELSE                                                                 
              IF LANG-SUB EQUAL 1                                               
                 MOVE 'RETROACTIVE ADJ.'    TO P-DIV-ADJ-LIT                    
              ELSE                                                              
                 MOVE 'RECT. RqTROACTIVES'  TO P-DIV-ADJ-LIT.                   
                                                                                
           CALL 'QDATE' USING QDATE-PARM GD90AR-EFFECTIVE-DATE                  
                                      P-DIV-EFFDATE.                            
                                                                                
           MOVE GD90AR-TAX-IND              TO P-DIV-TAX-IND.                   
           MOVE GD90AR-TAX-CODE             TO P-DIV-TAX-CODE.                  
                                                                                
           MOVE ' ' TO CC.                                                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PRINT-D90-ADJ-RECORD-EXIT.                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *    PRINT THE HEADINGS AND GROUP INFORMATION ON THE DETAIL               
      *    BILLING PAGE.                                                        
      ******************************************************************        
       NEW-DETAIL-PAGE.                                                         
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    SWITCH TO PAGE FORMAT 'UGBIL3'. BILLING DETAIL PAGE.                 
      ****************************************************************          
           IF  GPPFA-PAGE-NAME NOT = 'UGBIL3'                                   
               MOVE 'UGBIL3'               TO GPPFA-PAGE-NAME                   
               MOVE GPPFA-PAGE-RECORD      TO PRINT-LINE                        
               PERFORM OUTPUT-RTN THRU OP-EXIT                                  
               MOVE 'UGBIL3'               TO GPPFA-OVLY-COPYGRP                
               MOVE GPPFA-OVLY-RECORD      TO PRINT-LINE                        
               PERFORM OUTPUT-RTN THRU OP-EXIT.                                 
                                                                                
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 1, PAGEDEF CHANNEL FOR DETAIL PAGE = LINE 1.                    
      ****************************************************************          
           MOVE '1' TO CC.                                                      
           MOVE PR-HEAD1-SAVE TO PR25-HEAD.                                     
           PERFORM OUTPUT-RTN THRU OP-EXIT                                      
           ADD +1             TO PAGE-CT.                                       
           MOVE ' '           TO CC.                                            
           MOVE PR-HEAD2-SAVE TO PR25-HEAD.                                     
           MOVE 'PAGE'        TO PAGE-LIT.                                      
           MOVE PAGE-CT       TO OUT-PAGE.                                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO CC.                                                      
           MOVE GROUP-NO-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                   
           MOVE GFM2D-GROUP-NUMBER TO P-GROUP.                                  
           MOVE GFM2D-ACCOUNT TO P-ACCT.                                        
           MOVE PREM-DUE-LIT (LANG-SUB) TO P-SUMM-LIT.                          
           CALL 'QDATE' USING QDATE-PARM                                        
                              GFM2D-PREMIUM-DUE-DATE                            
                              WS-DATE1.                                         
           MOVE SPACES                 TO WS-DATE2.                             
           MOVE WS-DAY1                TO WS-DAY2.                              
           MOVE WS-MONTH1              TO WS-MONTH2.                            
           MOVE WS-YEAR1               TO WS-YEAR2.                             
           MOVE WS-DATE2               TO P-SUMM-FIELD.                         
                                                                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE GROUP-OFF-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                  
           MOVE STORE-OFFICE-NM-NUM TO P-GRP-OFFICE                             
           MOVE DATE-PREP-LIT (LANG-SUB) TO P-SUMM-LIT.                         
           CALL 'QDATE' USING QDATE-PARM                                        
                              GFM2D-PREPARED-DATE                               
                              WS-DATE1.                                         
           MOVE SPACES                 TO WS-DATE2.                             
           MOVE WS-DAY1                TO WS-DAY2.                              
           MOVE WS-MONTH1              TO WS-MONTH2.                            
           MOVE WS-YEAR1               TO WS-YEAR2.                             
           MOVE WS-DATE2               TO P-SUMM-FIELD.                         
                                                                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE '0' TO END-NAME-FOUND-SW.                                       
           MOVE NAME-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                       
           MOVE GFM2D-NAME-ADDRESS-LINES (1) TO P-GRP-OFFICE                    
           IF GFM2D-NAME-ADDRESS-DELIMITER (1) EQUAL '*'                        
              MOVE '1' TO END-NAME-FOUND-SW.                                    
           MOVE FILE-REF-LIT (LANG-SUB) TO P-SUMM-LIT.                          
           MOVE GFM2D-IDENTITY TO P-SUMM-FIELD.                                 
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           IF END-NAME-FOUND-SW EQUAL '0'                                       
              MOVE GFM2D-NAME-ADDRESS-LINES (2) TO P-GRP-OFFICE                 
              IF GFM2D-NAME-ADDRESS-DELIMITER (2) EQUAL '*'                     
                 MOVE '1' TO END-NAME-FOUND-SW.                                 
           IF GNUM-CURRENCY NOT EQUAL SPACES                                    
              MOVE GNUM-CURRENCY TO P-SUMM-FIELD                                
              MOVE CURRENCY-LIT (LANG-SUB) TO P-SUMM-LIT.                       
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           IF END-NAME-FOUND-SW EQUAL '0'                                       
              MOVE GFM2D-NAME-ADDRESS-LINES (3) TO P-GRP-OFFICE.                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE ' ' TO CC.                                                      
           MOVE TITLE-LINE1 TO PR-LINE1                                         
           IF DONE-DETAIL-SW EQUAL '1' AND DIV-BILL-TYPE-SW EQUAL '1'           
               MOVE SPACES TO P-DIVISION-GRP-SPACES.                            
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE TITLE-LINE2 TO PR-LINE1                                         
           IF DONE-DETAIL-SW EQUAL '1' AND DIV-BILL-TYPE-SW EQUAL '1'           
               MOVE SPACES TO P-DIVISION-GRP-SPACES.                            
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE ' ' TO CC.                                                      
           MOVE DASH-LINE   TO PR-LINE1.                                        
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
                                                                                
           MOVE +0 TO LINE-CT.                                                  
       NEW-DETAIL-PAGE-EXIT.                                                    
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *    PRINT THE BALANCE OF GROUP LINE IF CHANGE LIST ONLY                  
      *    PRINT THE DASH LINE AND TOTAL LINE ON THE BOTTOM TWO LINES           
      *    OF THE BOXED AREA.  PRINT THE DEPENDENT COVERAGE LITERALS            
      *    AS REQUIRED.                                                         
      *                                                                         
      *    IF THE BILL TYPE IS DIVISIONAL BILLING THEN THE FINAL                
      *    PREMIUM TOTALS WILL PRINT ON A NEW PAGE IN THE MIDDLE OF             
      *    THE PAGE.  THE NEW PAGE WAS GENERATED BY THE                         
      *    PRINT-STORED-DETAIL-REC ROUTINE WHEN THE GROUP/ACCOUNT               
      *    CONTROL BREAK OCCURED AND THE DIV-BILL-TYPE-SW WAS SET ON.           
      ******************************************************************        
       END-GRP.                                                                 
           PERFORM BUILD-GRP-TOTALS THRU BUILD-GRP-TOTALS-EXIT.                 
           IF GFM2D-BFSO-CHANGE-BILLING EQUAL 'Y'                               
              PERFORM PRINT-BALANCE-GRP-LINE THRU PBGL-EXIT.                    
       END-GRP-LOOP.                                                            
           IF DONE-DIVISION-SW EQUAL '1' AND                                    
              DIV-BILL-TYPE-SW EQUAL '1'                                        
              GO TO MOVE-DASH-LINE.                                             
       MOVE-DASH-LINE.                                                          
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 3, PAGEDEF CHANNEL FOR DETAIL PAGE = LINE 50.                   
      ****************************************************************          
           MOVE '3'       TO CC.                                                
           MOVE DASH-LINE TO PR-LINE1.                                          
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE TOTAL-GROUP-SUM (LANG-SUB) TO P-TOTAL-LIT.                      
           MOVE LIVES-INSURED-LIT (LANG-SUB) TO P-LIVES-INS-LIT.                
           MOVE GFM2E-INSURED-LIVES TO P-LIVES-INS.                             
       MOVE-TOT-AMOUNTS.                                                        
           MOVE +0 TO COL-SUB.                                                  
       MOVE-TOT-AMTS-LOOP.                                                      
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB NOT LESS THAN PREM-SUB                                    
              GO TO MOVE-GRP-TOTAL-PREM.                                        
           IF GFM2D-BC-PREM-OR-VOL (COL-SUB) EQUAL 'P'                          
              MOVE COL-ACCUM (COL-SUB) TO  EDIT-PREM-FIN                        
              MOVE EDIT-PREM-FIN TO P-COL-DATA (COL-SUB)                        
           ELSE                                                                 
              MOVE COL-ACCUM (COL-SUB) TO  EDIT-VOL-FIN                         
              MOVE EDIT-VOL-FIN  TO P-COL-DATA (COL-SUB).                       
           GO TO MOVE-TOT-AMTS-LOOP.                                            
       MOVE-GRP-TOTAL-PREM.                                                     
           MOVE COL-ACCUM (COL-SUB) TO  EDIT-PREM-FIN                           
           MOVE EDIT-PREM-FIN TO P-COL-DATA (COL-SUB)                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT.                     
      *    PERFORM PRINT-CHANGE-REPORT THRU PCR-EXIT.                           
       END-GRP-EXIT.                                                            
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *  - POSITION THE PRINT SO THAT THE BALANCE OF GROUP LINE WILL   *        
      *    PRINT ON THE 49TH LINE.                                     *        
      *  - PRINT THE TOTALS, EACH COLUMN TOTAL IS THE DIFFERENCE       *        
      *    BETWEEN THE GROUP TOTALS AND THE TOTALS ACCUMULATED FOR THE *        
      *    RECORDS PRINTED                                             *        
      *----------------------------------------------------------------*        
       PRINT-BALANCE-GRP-LINE.                                                  
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 2, PAGEDEF CHANNEL FOR DETAIL PAGE = LINE 49.                   
      ****************************************************************          
           MOVE '2'   TO CC.                                                    
           ADD 1      TO LINE-CT.                                               
       PRINT-BAL-LINE-START.                                                    
           MOVE BALANCE-OF-GRP-LIT (LANG-SUB) TO PR-LINE1.                      
           MOVE 0 TO COL-SUB.                                                   
       PRINT-BAL-TOT-LOOP.                                                      
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB NOT LESS THAN PREM-SUB                                    
              GO TO PRINT-BAL-LINE.                                             
           IF GFM2D-BC-PREM-OR-VOL (COL-SUB) EQUAL 'B'                          
              GO TO PRINT-BAL-TOT-LOOP.                                         
           SUBTRACT BAL-GRP-COL-ACCUM (COL-SUB) FROM COL-ACCUM (COL-SUB)        
               GIVING   BAL-GRP-COL-ACCUM (COL-SUB).                            
           IF GFM2D-BC-PREM-OR-VOL (COL-SUB) EQUAL 'P'                          
              COMPUTE COL-ACCUM-ROUNDED ROUNDED =                               
                                        BAL-GRP-COL-ACCUM (COL-SUB)             
              MOVE COL-ACCUM-ROUNDED TO  EDIT-PREM-FIN                          
              MOVE EDIT-PREM-FIN TO P-COL-DATA (COL-SUB)                        
           ELSE                                                                 
              MOVE BAL-GRP-COL-ACCUM (COL-SUB) TO  EDIT-VOL-FIN                 
              MOVE EDIT-VOL-FIN  TO P-COL-DATA (COL-SUB).                       
           GO TO PRINT-BAL-TOT-LOOP.                                            
       PRINT-BAL-LINE.                                                          
           SUBTRACT BAL-GRP-COL-ACCUM (COL-SUB) FROM COL-ACCUM (COL-SUB)        
               GIVING   BAL-GRP-COL-ACCUM (COL-SUB).                            
           MOVE BAL-GRP-COL-ACCUM (COL-SUB) TO  EDIT-PREM-FIN.                  
           MOVE EDIT-PREM-FIN TO P-COL-DATA (COL-SUB).                          
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PBGL-EXIT.                                                               
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *  - RUNNING SUB TOTALS                                                   
      *----------------------------------------------------------------*        
       PRINT-RUNNING-SUB.                                                       
           MOVE 0 TO COL-SUB.                                                   
       PRS-LOOP2.                                                               
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB NOT LESS THAN PREM-SUB                                    
              GO TO PRS-LINE.                                                   
           IF GFM2D-BC-PREM-OR-VOL (COL-SUB) EQUAL 'B'                          
              GO TO PRS-LOOP2.                                                  
           IF GFM2D-BC-PREM-OR-VOL (COL-SUB) EQUAL 'P'                          
              COMPUTE COL-ACCUM-ROUNDED ROUNDED =                               
                                     BAL-GRP-COL-ACCUM (COL-SUB)                
              MOVE COL-ACCUM-ROUNDED TO  PRS-WORK                               
              MOVE PRS-WORK TO EDIT-PREM-FIN                                    
              MOVE EDIT-PREM-FIN TO P-COL-DATA (COL-SUB)                        
           ELSE                                                                 
              MOVE +0                          TO  EDIT-VOL-FIN                 
              MOVE EDIT-VOL-FIN  TO P-COL-DATA (COL-SUB).                       
           GO TO PRS-LOOP2.                                                     
       PRS-LINE.                                                                
           MOVE BAL-GRP-COL-ACCUM (COL-SUB) TO  PRS-WORK.                       
           MOVE PRS-WORK TO EDIT-PREM-FIN.                                      
           IF DIV-BILL-TYPE-SW EQUAL '1' AND                                    
              DONE-DIVISION-SW EQUAL '1' AND                                    
              PREV-DIVISION NOT EQUAL TO 99                                     
                MOVE DIVISION-LIT (LANG-SUB) TO P-TOTAL-DIV-LIT                 
                MOVE PREV-DIVISION TO DIVISION-UNPACK                           
                IF LANG-SUB EQUAL 1                                             
                    MOVE DIVISION-UNPACK TO P-DIVISION-E                        
                ELSE                                                            
                    MOVE DIVISION-UNPACK TO P-DIVISION.                         
           MOVE EDIT-PREM-FIN TO P-COL-DATA (COL-SUB).                          
                                                                                
           MOVE ' '     TO CC.                                                  
           MOVE PRINT-LINE TO SAVE-LINE.                                        
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 3, PAGEDEF CHANNEL FOR DETAIL PAGE = LINE 50.                   
      ****************************************************************          
           MOVE '3' TO CC.                                                      
           MOVE DASH-LINE TO PR-LINE1.                                          
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE SAVE-LINE TO PRINT-LINE.                                        
           MOVE ' ' TO CC.                                                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PRINT-RUNNING-SUB-EXIT.                                                  
           EXIT.                                                                
      ******************************************************************        
      *    PRINT THE EXPLANATION OF THE DEPENDENT HEADINGS AT THE BOTTOM        
      *    OF THE PAGE IF REQUIRED.                                             
      ******************************************************************        
       PRINT-END-PAGE.                                                          
           PERFORM SUM-NUMBER-BILLINGS THRU SNB-EXIT.                           
       PRINT-END-PAGE-LOOP.                                                     
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 4, PAGEDEF CHANNEL FOR DETAIL PAGE = LINE 55                    
      ****************************************************************          
           MOVE '4' TO CC.                                                      
           IF (DEPENDENT-IND EQUAL '000')                                       
               IF (GFM2E-GROUP-TAX-IND NOT EQUAL 'Y')                           
                   GO TO PRINT-END-PAGE-EXIT                                    
               ELSE                                                             
                   MOVE SUBJECT-TO-TAX-LIT (LANG-SUB)                           
                     TO PR-TAX-SUBJECT                                          
                   PERFORM OUTPUT-RTN THRU OP-EXIT                              
                   GO TO PRINT-END-PAGE-EXIT.                                   
                                                                                
           MOVE EXPL-ABREV-LIT-1 (LANG-SUB) TO PR-ABBREV-LIT.                   
           IF (GFM2E-GROUP-TAX-IND EQUAL 'Y')                                   
               MOVE SUBJECT-TO-TAX-LIT (LANG-SUB) TO PR-TAX-SUBJECT.            
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO CC.                                                      
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO CC.                                                      
           IF DEP-LIFE-IND EQUAL '1'                                            
              MOVE EXPL-ABREV-LIT-2 (LANG-SUB) TO PR-ABBREV-LIT                 
              PERFORM OUTPUT-RTN THRU OP-EXIT.                                  
           IF DEP-EHC-IND  EQUAL '1'                                            
              MOVE EXPL-ABREV-LIT-3 (LANG-SUB) TO PR-ABBREV-LIT                 
              PERFORM OUTPUT-RTN THRU OP-EXIT.                                  
           IF DEP-DEN-IND  EQUAL '1'                                            
              MOVE EXPL-ABREV-LIT-4 (LANG-SUB) TO PR-ABBREV-LIT                 
              PERFORM OUTPUT-RTN THRU OP-EXIT.                                  
       PRINT-END-PAGE-EXIT.                                                     
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ******************************************************************        
      *    B U I L D   T H E   D E T A I L   P R I N T L I N E                  
      ******************************************************************        
      *    FIND COVERAGE CODE IN COL TABLE                                      
      ******************************************************************        
      *  - LOOP THRU THE COVERAGE INFORMATION AND ACCUMULATE TOTALS.            
      *    TURN ON DEPENDENT INDICATORS AS REQUIRED.                            
      *  - MATCH THE COVERAGE CODE ON THE SEGMENT TO ONE IN THE STORED          
      *    TABLE.  IF NO MATCH, START PROCESSING THE NEXT COV. SEGMENT.         
      *    FOR A MATCH, ADD THE APPROPRIATE FIELDS (PREM OR VOLUME) TO          
      *    TO THE COLUMN TOTALS AS SPECIFIED IN THE TABLE (THE ORIGINAL         
      *    GENERAL INFORMATION TABLE WILL INDICATE IF THE COLUMN IS FOR         
      *    PREMIUM OR VOLUME).                                                  
      *    THE EHC (019) SUBLINES, MUST BE ACCUMULATED BEFORE PRINTING          
      *    IF 019 COVERAGE CODE IS REQUESTED FOR ONE OF THE COLUMNS.            
      *    THE SAME HOLDS TRUE FOR DENTAL (099).  IN ALL OTHER CASES,           
      *    HOWEVER, THE COVERAGE CODE ON THE SEGMENT MUST MATCH EXACTLY         
      *    TO ONE IN THE STORED TABLE.                                          
      *  - IGNORE THOSE SEGMENTS WHICH HAVE 'ES', 'LX' OR 'DX' IN THE           
      *    SELECTION IND. FIELD.                                                
      ******************************************************************        
       BUILD-DETAIL-COL.                                                        
           MOVE ZERO TO COL-ACCUM (1).                                          
           MOVE COL-ACCUM-R TO COL-ACCUM-TO-ZERO.                               
           MOVE +0 TO CERT-SUB.                                                 
       CERT-COV-LOOP.                                                           
           ADD +1 TO CERT-SUB.                                                  
           IF CERT-SUB GREATER THAN WORK-NUM-COV-CODES9                         
              GO TO MOVE-AMOUNTS.                                               
      *                                                                         
      *    ONLY BUILD THE DEPENDENT INDICATORS IF THIS IS A CURRENT             
      *    BILLING RECORD                                                       
      *                                                                         
           IF DETAIL-DETAIL-IDENT (SUB1) NOT EQUAL 'S'                          
              GO TO BYPASS-DEPEND-IND.                                          
           IF GBC-VOLUME (CERT-SUB) EQUAL +0                                    
              GO TO BYPASS-DEPEND-IND.                                          
           IF GBC-COV-CODE (CERT-SUB) EQUAL 160                                 
              MOVE YO-CHAR (LANG-SUB) TO P-DEP-LIFE.                            
           IF   (GBC-COV-CODE (CERT-SUB) NOT GREATER THAN EHC-CODE-MAX)         
           AND  (GBC-COV-CODE (CERT-SUB) NOT LESS THAN EHC-CODE-MIN)            
           AND  (GBC-VOLUME   (CERT-SUB) EQUAL 2 OR 3)                          
              MOVE YO-CHAR (LANG-SUB) TO P-DEP-EHC.                             
           IF   (GBC-COV-CODE (CERT-SUB) NOT GREATER THAN DEN-CODE-MAX)         
           AND  (GBC-COV-CODE (CERT-SUB) NOT LESS THAN DEN-CODE-MIN)            
           AND  (GBC-VOLUME   (CERT-SUB) EQUAL 2 OR 3)                          
              MOVE YO-CHAR (LANG-SUB) TO P-DEP-DEN.                             
       BYPASS-DEPEND-IND.                                                       
      *                                                                         
      *   SET UP THE COVERAGE CODES, VOLUME AND PREMIUM IN A COMMON             
      *   FIELD FOR ACCUMULATION PURPOSES                                       
      *                                                                         
           IF  DETAIL-DETAIL-IDENT (SUB1) EQUAL 'S'                             
               MOVE GBC-COV-CODE (CERT-SUB) TO T-COV-CODE                       
               MOVE GBC-VOLUME   (CERT-SUB) TO T-VOLUME                         
               MOVE GBC-BILLED-PREMIUM (CERT-SUB) TO T-PREM.                    
           IF  DETAIL-DETAIL-IDENT (SUB1) EQUAL 'T'                             
               MOVE GBA-COV-CODE (CERT-SUB) TO T-COV-CODE                       
               MOVE GBA-VOLUME   (CERT-SUB) TO T-VOLUME                         
               MOVE GBA-PREM-ADJ-AMOUNT (CERT-SUB) TO T-PREM.                   
           IF  DETAIL-DETAIL-IDENT (SUB1) EQUAL 'U'                             
               MOVE GD90AR-COVERAGE-CODE (CERT-SUB) TO T-COV-CODE               
               MOVE 0 TO T-VOLUME                                               
               MOVE GD90AR-PREMIUM-ADJUST (CERT-SUB) TO T-PREM.                 
           MOVE +0 TO CHECK-SUB.                                                
       CHK-TABLE-LOOP.                                                          
           ADD +1 TO CHECK-SUB.                                                 
           IF CHECK-SUB GREATER THAN TITLE-NUM-CODES                            
              GO TO CERT-COV-LOOP.                                              
           IF (TITLE-COV-CODE (CHECK-SUB) EQUAL 019)      AND                   
              (T-COV-CODE  NOT GREATER THAN EHC-CODE-MAX) AND                   
              (T-COV-CODE  NOT LESS THAN EHC-CODE-MIN)                          
              GO TO NORM-PROC-FOUND-ENTRY.                                      
           IF (TITLE-COV-CODE (CHECK-SUB) EQUAL 099)      AND                   
              (T-COV-CODE  NOT GREATER THAN DEN-CODE-MAX) AND                   
              (T-COV-CODE  NOT LESS THAN DEN-CODE-MIN)                          
              GO TO NORM-PROC-FOUND-ENTRY.                                      
           IF TITLE-COV-CODE (CHECK-SUB) NOT EQUAL T-COV-CODE                   
              GO TO CHK-TABLE-LOOP.                                             
      *                                                                         
      *    ENTRY HAS BEEN FOUND.  ACCUMULATE THE REQUIRED VALUES IN COL.        
      *    SPECIFIED                                                            
      *                                                                         
       NORM-PROC-FOUND-ENTRY.                                                   
           MOVE +0 TO COL-SUB.                                                  
       INCRE-COL-SUB.                                                           
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB GREATER THAN NUM-COLS (CHECK-SUB)                         
              GO TO CERT-COV-LOOP.                                              
           MOVE COLS-OF-COV-CODE (CHECK-SUB, COL-SUB) TO GGI-TITLE-SUB.         
           IF GFM2D-BC-PREM-OR-VOL (GGI-TITLE-SUB) EQUAL 'P'                    
              ADD T-PREM    TO COL-ACCUM (GGI-TITLE-SUB)                        
           ELSE                                                                 
              ADD T-VOLUME  TO COL-ACCUM (GGI-TITLE-SUB).                       
           GO TO INCRE-COL-SUB.                                                 
      ****                                                                      
      *    MOVE THE COLUMN AMOUNTS TO THE PRINT LINE USING THE                  
      *    APPROPRIATE EDIT MASK                                                
      ****                                                                      
       MOVE-AMOUNTS.                                                            
           MOVE +0 TO COL-SUB.                                                  
       MOVE-AMTS-LOOP.                                                          
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB NOT LESS THAN PREM-SUB                                    
              GO TO MOVE-TOTAL-PREM.                                            
           ADD COL-ACCUM (COL-SUB) TO BAL-GRP-COL-ACCUM (COL-SUB).              
           IF GFM2D-BC-PREM-OR-VOL (COL-SUB) EQUAL 'P'                          
              COMPUTE COL-ACCUM-ROUNDED ROUNDED = COL-ACCUM (COL-SUB)           
              MOVE COL-ACCUM-ROUNDED TO  EDIT-PREM                              
              MOVE EDIT-PREM TO P-COL-DATA (COL-SUB)                            
           ELSE                                                                 
              MOVE COL-ACCUM (COL-SUB) TO  EDIT-VOL                             
              MOVE EDIT-VOL  TO P-COL-DATA (COL-SUB).                           
           GO TO MOVE-AMTS-LOOP.                                                
       MOVE-TOTAL-PREM.                                                         
           IF DETAIL-DETAIL-IDENT (SUB1) EQUAL 'S'                              
              MOVE GBC-TOTAL-PREMIUM TO  EDIT-PREM                              
              ADD GBC-TOTAL-PREMIUM TO BAL-GRP-COL-ACCUM (COL-SUB).             
           IF DETAIL-DETAIL-IDENT (SUB1) EQUAL 'T'                              
              MOVE GBA-TOTAL-PREMIUM TO  EDIT-PREM                              
              ADD GBA-TOTAL-PREMIUM TO BAL-GRP-COL-ACCUM (COL-SUB).             
           IF DETAIL-DETAIL-IDENT (SUB1) EQUAL 'U'                              
              MOVE GD90AR-TOTAL-PREMIUM TO  EDIT-PREM                           
              ADD GD90AR-TOTAL-PREMIUM TO BAL-GRP-COL-ACCUM (COL-SUB).          
           MOVE EDIT-PREM TO P-COL-DATA (COL-SUB).                              
       BUILD-DETAIL-COL-EXIT.                                                   
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ******************************************************************        
      *    M I S C E L L A N E O U S   R O U T I N E S                          
      ******************************************************************        
      ******************************************************************        
      *    PRODUCE A DUMMY RECORD IN THE TABLE.                                 
      ******************************************************************        
       GENERATE-S-RECORD.                                                       
           MOVE TAPE-REC TO GBC-BILL-CURR-RECORD.                               
           MOVE 'S' TO GBC-DETAIL-IDENT.                                        
           MOVE SPACES TO GBC-CLASS.                                            
           MOVE +0 TO GBC-TOTAL-PREMIUM, GBC-NUM-COV-CODES.                     
           ADD +1 TO NUM-DETAIL-STORED.                                         
           MOVE GBC-BILL-CURR-RECORD                                            
                TO DETAIL-RECORDS (NUM-DETAIL-STORED).                          
       GEN-S-REC-EXIT.                                                          
           EXIT.                                                                
      ******************************************************************        
      *    PRODUCE AN ERROR RECORD WHICH WILL BE READ BY GPRERROR.              
      ******************************************************************        
       ERR-RTN.                                                                 
E42        ADD 1             TO  NUM-OF-ERRORS                                  
E42                          OF  BILL-GRP-END-EXTRACT.                          
E42        MOVE E-CODE       TO  GROUP-ERROR-CODE                               
E42                          OF  BILL-GRP-END-EXTRACT (NUM-OF-ERRORS).          
           MOVE CURR-GROUP   TO E-GROUP.                                        
           MOVE CURR-ACCT    TO E-ACCT.                                         
           MOVE CURR-COUNTRY TO E-COUNTRY.                                      
      *                                                                         
      *  SET UP NEW ERROR FIELDS AT RIGHT TIME       MARCUS                     
      *                                                                         
           MOVE HOLD-PCODE   TO E-PROD-CD.                                      
           MOVE HOLD-OFFICE  TO E-OFFICE.                                       
           CALL  'DLSWRITE' USING  TAPE-SYS011                                  
                                   TAPE-RETURN                                  
                                   ERR-REC                                      
                                   TAPE-SYS011-RECSIZE                          
                                   TAPE-SYS011-BLKSIZE                          
                                   TAPE-SYS011-FORMAT                           
                                   TAPE-SYS011-COUNT.                           
           MOVE  SPACES        TO  E-CODE.                                      
                                                                                
      ******************************************************************        
      *    PRINT THE LINE ON THE REQUIRED SYS UNIT.                             
      *                                                                         
      *    SYS022 - U.S. STMTS, GROUP OFFICES 111 AND 115                       
      *    SYS022 - NO LONGER USED FOR STATEMENTS                               
      *    SYS075 - PRODUCES EXTRACTS FOR BRANCH COPIES                         
      *    SYS053 - ENGLISH STMTS, GROUP OFFICES 111 AND 115                    
      *    SYS054 - FRENCH STMTS, GROUP OFFICES 111 AND 115                     
      *    SYS085 - U.S. STMTS, GROUP OFFICES OTHER THAN 111 AND 115            
      *    SYS056 - ENGLISH STMTS, GROUP OFFICES OTHER THAN 111 AND 115         
      *    SYS057 - FRENCH STMTS, GROUP OFFICES OTHER THAN 111 AND 115          
      *    SYS085 - NO LONGER USED FOR STMTS                                    
      *    SYS056 - NO LONGER USED FOR STMTS                                    
      *    DYS057 - NO LONGER USED FOR STMTS                                    
      *                                                                         
      *    THE FORM CODE PASSED TO GPRSGMNT DETERMINES WHICH SYSUNIT            
      *    THE LINE WILL BE PRINTED ON.                                         
      ******************************************************************        
       OUTPUT-RTN.                                                              
           IF GFM2D-LANGUAGE EQUAL 'F' THEN                                     
               GO TO PRINT-FR-SGPS                                              
           ELSE                                                                 
               GO TO PRINT-ENG-SGPS.                                            
       PRINT-ENG-SGPS.                                                          
           IF GPRSGMNT-SW-ENG-SGPS EQUAL '0'                                    
              MOVE '1' TO GPRSGMNT-SW-ENG-SGPS                                  
              PERFORM PRINT-LINEUP-PAGES THRU PRINT-LINEUP-PAGES-EXIT.          
           PERFORM  WRITE-ENG-BILLS           THRU   WRITE-ENG-X.               
           GO TO OP-EXIT.                                                       
                                                                                
       PRINT-FR-SGPS.                                                           
           IF GPRSGMNT-SW-FR-SGPS EQUAL '0'                                     
              MOVE '1' TO GPRSGMNT-SW-FR-SGPS                                   
              PERFORM PRINT-LINEUP-PAGES THRU PRINT-LINEUP-PAGES-EXIT.          
           PERFORM  WRITE-FRN-BILLS           THRU   WRITE-FRN-X.               
                                                                                
       OP-EXIT.                                                                 
           MOVE SPACES TO PRINT-LINE.                                           
                                                                                
       PRINT-LINEUP-PAGES.                                                      
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    SWITCH TO PAGE FORMAT 'UGBIL1'. BILLING LINEUP PAGES.                
      ****************************************************************          
           MOVE PRINT-LINE TO SAVE-LINE.                                        
                                                                                
           MOVE GPPFA-PAGE-NAME            TO SAVE-GPPFA-PAGE-NAME.             
           MOVE GPPFA-OVLY-COPYGRP         TO SAVE-GPPFA-OVLY-COPYGRP.          
           IF  GPPFA-PAGE-NAME NOT = 'UGBIL1'                                   
               MOVE 'UGBIL1'               TO GPPFA-PAGE-NAME                   
               MOVE GPPFA-PAGE-RECORD      TO PRINT-LINE                        
               PERFORM OUTPUT-RTN THRU OP-EXIT                                  
               MOVE 'UGBIL1'               TO GPPFA-OVLY-COPYGRP                
               MOVE GPPFA-OVLY-RECORD      TO PRINT-LINE                        
               PERFORM OUTPUT-RTN THRU OP-EXIT.                                 
           MOVE SAVE-GPPFA-PAGE-NAME       TO GPPFA-PAGE-NAME.                  
           MOVE SAVE-GPPFA-OVLY-COPYGRP    TO GPPFA-OVLY-COPYGRP.               
                                                                                
           IF (COPY-INDICATOR EQUAL 'C')                                        
               PERFORM PRINT-C-PAGE THRU PRINT-C-PAGE-EXIT 3 TIMES.             
           IF (COPY-INDICATOR EQUAL 'P')                                        
               PERFORM PRINT-P-PAGE THRU PRINT-P-PAGE-EXIT 3 TIMES.             
           IF (COPY-INDICATOR NOT EQUAL 'C' AND 'P')                            
               PERFORM PRINT-X-PAGE THRU PRINT-X-PAGE-EXIT 3 TIMES.             
           MOVE SAVE-LINE TO PRINT-LINE.                                        
       PRINT-LINEUP-PAGES-EXIT.                                                 
           EXIT.                                                                
                                                                                
       PRINT-X-PAGE.                                                            
           MOVE '1' TO PRINT-LINE.                                              
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO PRINT-LINE.                                              
           PERFORM OUTPUT-RTN THRU OP-EXIT                                      
                   6 TIMES.                                                     
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'X' TO PR-LINE10.                                           
           MOVE '  PRINT THIS BOX OF XS IN THE BOX     ' TO PR-X-LIT.           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           PERFORM PRINT-X-X-LINE THRU PRINT-X-X-LINE-EXIT 51 TIMES.            
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'X' TO PR-LINE10.                                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           GO TO PRINT-X-PAGE-EXIT.                                             
       PRINT-X-X-LINE.                                                          
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE 'X' TO PR-X-1  PR-X-PERF PR-X-2.                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PRINT-X-X-LINE-EXIT.                                                     
                             EXIT.                                              
       PRINT-X-PAGE-EXIT.                                                       
                           EXIT.                                                
                                                                                
       PRINT-C-PAGE.                                                            
           MOVE '1' TO PRINT-LINE.                                              
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO PRINT-LINE.                                              
           PERFORM OUTPUT-RTN THRU OP-EXIT                                      
                   6 TIMES.                                                     
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'C' TO PR-LINE10.                                           
           MOVE '  THESE ARE SELECTED COPIES  ***  DO NOT MAIL  ***'            
             TO PR-C-LIT.                                                       
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           PERFORM PRINT-C-C-LINE THRU PRINT-C-C-LINE-EXIT 51 TIMES.            
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'C' TO PR-LINE10.                                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           GO TO PRINT-C-PAGE-EXIT.                                             
       PRINT-C-C-LINE.                                                          
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE 'C' TO PR-C-1  PR-C-PERF PR-C-2.                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PRINT-C-C-LINE-EXIT.                                                     
                             EXIT.                                              
       PRINT-C-PAGE-EXIT.                                                       
                           EXIT.                                                
       PRINT-P-PAGE.                                                            
           MOVE '1' TO PRINT-LINE.                                              
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO PRINT-LINE.                                              
           PERFORM OUTPUT-RTN THRU OP-EXIT                                      
                   6 TIMES.                                                     
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'P' TO PR-LINE10.                                           
           MOVE ' P R A C T I C E  B I L L I N G ** DO NOT MAIL ** '            
             TO PR-C-LIT.                                                       
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           PERFORM PRINT-P-P-LINE THRU PRINT-P-P-LINE-EXIT 51 TIMES.            
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'P' TO PR-LINE10.                                           
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           GO TO PRINT-P-PAGE-EXIT.                                             
       PRINT-P-P-LINE.                                                          
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE 'P' TO PR-C-1  PR-C-PERF PR-C-2.                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PRINT-P-P-LINE-EXIT.                                                     
                             EXIT.                                              
       PRINT-P-PAGE-EXIT.                                                       
                           EXIT.                                                
                                                                                
      ******************************************************************        
      *    EACH TIME A PAGE IS PRINTED, ACCUMULATE 1 TO THE NECESSARY           
      *    COUNTER IN THE GPRACCUM COPY BOOK.  THESE TOTALS ARE PRINTED         
      *    BY GPRCOUNT.                                                         
      ******************************************************************        
       SUM-NUMBER-BILLINGS.                                                     
           IF GFM2D-LANGUAGE EQUAL 'F' THEN                                     
               ADD +1 TO ACCUM-BILL-FR-OTH                                      
           ELSE                                                                 
               ADD +1 TO ACCUM-BILL-ENG-OTH.                                    
       SNB-EXIT.                                                                
           EXIT.                                                                
                                                                                
 GV    CHECK-FOR-EFT.                                                           
 GV        MOVE 'GIPSY'        TO       REQ-SOURCE.                             
 GV        MOVE 'PREMIUM'      TO       REQ-FUNCTION.                           
 GV        MOVE '********'     TO       REQ-PROD-LINE.                          
 GV        MOVE '**'           TO       REQ-ADMIN-TYPE.                         
 GV                                                                             
 GV        MOVE 'GRPA'         TO       REQ-KEY-TYPE.                           
 GV        MOVE GFM2D-GROUP-NUMBER TO  PAD-GROUP.                               
 GV        MOVE GFM2D-ACCOUNT  TO       PAD-ACCT.                               
 GV        MOVE PAD-GROUP-ACCT TO       REQ-KEY-DATA                            
 GV                                     REQ-ENTRY-ID.                           
 GV        MOVE  ZERO          TO       REQ-EFF-DATE-IN.                        
 GV        MOVE 'GPRBILLS'     TO       REQ-MAINTAINER-ID.                      
 GV        MOVE WS-TOTAL-PREM-DUE TO       REQ-AMOUNT.                          
 GV                                                                             
 GV2       IF COPY-INDICATOR = 'C'                                              
 GV2            MOVE    'I'      TO  REQ-REASON-CODE                            
 GV2            MOVE WS-COPY     TO  PAD-RUN-TYPE                               
 GV2            MOVE  '2A1E'     TO  VDATE-REQUEST-AREA                         
 GV2            MOVE GFM2D-PREPARED-DATE    TO  VDATE-ALIS-DATE1                
 GV2            CALL GC2DATE USING GAC-DATE-PARMS                               
 GV2            MOVE VDATE1-YYYYMMDD        TO  REQ-EFF-DATE-IN                 
 GV2       ELSE                                                                 
 GV2            IF COPY-INDICATOR = 'P'                                         
 GV2            MOVE    'I'      TO  REQ-REASON-CODE                            
 GV2            MOVE WS-PRACTICE TO  PAD-RUN-TYPE                               
 GV2       ELSE                                                                 
 GV2            IF COPY-INDICATOR = 'S'                                         
 GV2            MOVE    'I'      TO  REQ-REASON-CODE                            
 GV2            MOVE WS-SUMMARY  TO  PAD-RUN-TYPE                               
 GV        ELSE                                                                 
 GV2            MOVE WS-REGULAR  TO  PAD-RUN-TYPE                               
 GV             IF WS-TOTAL-PREM-DUE > ZERO                                     
 GV                MOVE    'U'      TO  REQ-REASON-CODE                         
 GV             ELSE                                                            
 GV                MOVE    'A'      TO  REQ-REASON-CODE.                        
                                                                                
 GV        CALL  GWEFCPDR  USING  PAD-REQUEST-PARMS.                            
 GV        IF REQ-PAD-NOT-FOUND                                                 
 GV           ADD REQ-AMOUNT  TO  WS-PAD-NPAD-AMT                               
 GV           ADD 1           TO  WS-PAD-NPAD-REC                               
 GV        ELSE                                                                 
 GV           PERFORM MOVE-PAD-DATA-DETAIL THRU                                 
 GV                   MOVE-PAD-DATA-DETAIL-EXIT                                 
 GV        .                                                                    
 GV    CHECK-FOR-EFT-EXIT.                                                      
 GV                         EXIT.                                               
 GV                                                                             
 GV   ******************************************************************        
 GV   *    WRITING PAD REPORT HEADINGS.                                         
 GV   ******************************************************************        
 GV    PAD-RPT-HEAD.                                                            
 GV        ADD  1            TO    WS-PAD-PG-NO.                                
 GV        MOVE WS-PAD-PG-NO TO    PAD-PG-NO.                                   
 GV        MOVE  'GPRBILLS'  TO    PAD-RPT-ID.                                  
 GV        MOVE  'GPRBILLS'  TO    ICBM-PROGRAM-NAME.                           
 GV        MOVE  PADRPT-INFO-LR  TO LOGICAL-RECORD-NAME.                        
 GV        CALL  GAEDATSR    USING STORE-LR                                     
 GV                                PAD-RPT-TITLE                                
 GV                                ICBM.                                        
 GV        PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 GV                                                                             
 GV        CALL  GAEDATSR    USING STORE-LR                                     
 GV                                PAD-RPT-TITLE2                               
 GV                                ICBM.                                        
 GV        PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 GV                                                                             
 GV2       CALL  GAEDATSR    USING STORE-LR                                     
 GV2                               PAD-RPT-TITLE3                               
 GV2                               ICBM.                                        
 GV2       PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 GV                                                                             
 GV        CALL  GAEDATSR    USING STORE-LR                                     
 GV                                PAD-RPT-HDG1                                 
 GV                                ICBM.                                        
 GV        PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 GV                                                                             
 GV        CALL  GAEDATSR    USING STORE-LR                                     
 GV                                PAD-RPT-HDG2                                 
 GV                                ICBM.                                        
 GV        PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 GV                                                                             
 BP        CALL  GAEDATSR    USING STORE-LR                                     
 BP                                PAD-RPT-SPACES                               
 BP                                ICBM.                                        
 BP        PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 BP                                                                             
 GV2       MOVE   12         TO    WS-LINE-CT.                                  
 GV    PAD-RPT-HEAD-EXIT.                                                       
 GV                         EXIT.                                               
 GV                                                                             
 GV   ******************************************************************        
 GV   *    MOVING DATA TO PAD DETAIL RECORD                                     
 GV   ******************************************************************        
 GV    MOVE-PAD-DATA-DETAIL.                                                    
 GV        MOVE GFM2D-GROUP-NUMBER  TO     PAD-RPT-GROUP.                       
 GV        MOVE GFM2D-ACCOUNT       TO     PAD-ACCOUNT.                         
 GV        MOVE 'Y'          TO  WS-PAD-DTLS-FOUND-SW.                          
                                                                                
 GV        IF REQ-EFF-DATE-OUT NOT NUMERIC                                      
 GV            MOVE ZEROES   TO REQ-EFF-DATE-OUT.                               
                                                                                
 GV        IF REQ-EFF-DATE-OUT > ZERO AND                                       
 GV           NOT REQ-PAD-TERMINATED  AND                                       
 GV2          NOT REQ-PAD-IN-FUTURE                                             
 GV            MOVE  'BB1E'        TO   VDATE-REQUEST-AREA                      
 GV            MOVE REQ-EFF-DATE-OUT   TO   VDATE1-YYYYMMDD                     
 GV            CALL GC2DATE USING GAC-DATE-PARMS                                
                                                                                
 GV            MOVE VDATE-EXT-DAY      TO   PAD-EFF-DD                          
 GV2           MOVE WS-SLASH           TO   PAD-EFF-FIL1                        
 GV            MOVE VDATE-EXT-MONTH    TO   PAD-EFF-MMM                         
 GV2           MOVE WS-SLASH           TO   PAD-EFF-FIL2                        
 GV            MOVE VDATE-EXT-YEAR     TO   PAD-EFF-YYYY                        
             ELSE                                                               
 GV2           MOVE SPACES             TO   PAD-EFF-DT.                         
           IF ENGLISH-SUB                                                       
 GV           MOVE ER-NAME            TO   PAD-GRP-NAME                         
           ELSE                                                                 
 GV           MOVE FR-NAME            TO   PAD-GRP-NAME.                        
                                                                                
 GV        MOVE REQ-AMOUNT   TO     PAD-AMT.                                    
 GV2                                                                            
 GV        IF REQ-PAD-TERMINATED                                                
 GV           MOVE WS-TERMINATED     TO   PAD-BI-STATUS                         
 GV2          MOVE WS-NO-UPDATE      TO   PAD-STATUS                            
 GV        ELSE                                                                 
 GV             IF REQ-PAD-IN-EFFECT                                            
 GV           MOVE WS-IN-EFFECT      TO   PAD-BI-STATUS                         
 GV2          IF REQ-UPDATE                                                     
 GV2              MOVE WS-REQUEST    TO   PAD-STATUS                            
 GV2          ELSE                                                              
 GV2               IF REQ-INQUIRY                                               
 GV2              MOVE WS-NO-UPDATE  TO   PAD-STATUS                            
 GV2          ELSE                                                              
 GV2               IF REQ-AUDIT-ONLY                                            
 GV2              MOVE WS-COMPLETE   TO   PAD-STATUS                            
 GV2          ELSE                                                              
 GV2              MOVE REQ-STATUS    TO   PAD-STATUS                            
 GV        ELSE                                                                 
 GV             IF REQ-PAD-IN-FUTURE                                            
 GV           MOVE WS-IN-FUTURE      TO   PAD-BI-STATUS                         
 GV2          MOVE WS-NO-UPDATE      TO   PAD-STATUS                            
 GV        ELSE                                                                 
 GV             IF REQ-PAD-SUSPENDED                                            
 GV           MOVE WS-SUSPENDED      TO   PAD-BI-STATUS                         
 GV2          IF REQ-UPDATE                                                     
 GV2              MOVE WS-SUSPENDED  TO   PAD-STATUS                            
 GV2          ELSE                                                              
 GV2               IF REQ-INQUIRY                                               
 GV2              MOVE WS-NO-UPDATE  TO   PAD-STATUS                            
 GV2          ELSE                                                              
 GV2               IF REQ-AUDIT-ONLY                                            
 GV2              MOVE WS-COMPLETE   TO   PAD-STATUS                            
 GV2          ELSE                                                              
 GV2              MOVE REQ-STATUS    TO   PAD-STATUS                            
 GV        ELSE                                                                 
 GV             IF REQ-PAD-LOGIC-ABORTED                                        
 GV2          MOVE WS-ABORTED        TO   PAD-BI-STATUS                         
 GV2          MOVE WS-ABORTED        TO   PAD-STATUS.                           
 GV                                                                             
E42        MOVE PAD-STATUS                 TO  GROUP-PAD-STATUS                 
E42                                        OF  BILL-GRP-END-EXTRACT.            
E42        IF  REQ-EFF-DATE-OUT NOT = ZERO                                      
E42            MOVE REQ-EFF-DATE-OUT       TO  GROUP-PAD-DATE                   
E42                                        OF  BILL-GRP-END-EXTRACT             
E42        ELSE                                                                 
E42            MOVE SPACES                 TO  GROUP-PAD-DATE                   
E42                                        OF  BILL-GRP-END-EXTRACT.            
 GV        MOVE REQ-BATCH-ID TO     PAD-SEQNO.                                  
 GV        IF WS-LINE-CT > 60                                                   
 GV           PERFORM  PAD-RPT-HEAD   THRU PAD-RPT-HEAD-EXIT.                   
 GV                                                                             
 GV        MOVE  PADRPT-INFO-LR  TO LOGICAL-RECORD-NAME.                        
 GV        CALL  GAEDATSR    USING STORE-LR                                     
 GV                                PAD-RPT-DETL1                                
 GV                                ICBM.                                        
 GV        PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 GV                                                                             
 GV        ADD  1 TO  WS-LINE-CT.                                               
 GV                                                                             
 GV        IF REQ-PAD-TERMINATED                                                
 GV           ADD REQ-AMOUNT  TO  WS-PAD-TRMD-AMT                               
 GV           ADD 1           TO  WS-PAD-TRMD-REC                               
 GV        ELSE                                                                 
 GV             IF REQ-PAD-IN-FUTURE                                            
 GV           ADD REQ-AMOUNT  TO  WS-PAD-INFUT-AMT                              
 GV           ADD 1           TO  WS-PAD-INFUT-REC                              
 GV2       ELSE                                                                 
 GV2            IF REQ-AUDIT-ONLY                                               
 GV2          ADD REQ-AMOUNT TO  WS-PAD-CMP-AMT                                 
 GV2          ADD 1          TO  WS-PAD-CMP-REC                                 
 GV        ELSE                                                                 
 GV             IF REQ-PAD-IN-EFFECT                                            
 GV           ADD REQ-AMOUNT TO  WS-PAD-INEFF-AMT                               
 GV           ADD 1          TO  WS-PAD-INEFF-REC                               
 GV        ELSE                                                                 
 GV             IF REQ-PAD-SUSPENDED                                            
 GV           ADD 1           TO  WS-PAD-SUSP-REC                               
 GV           ADD REQ-AMOUNT  TO  WS-PAD-SUSP-AMT                               
 GV        ELSE                                                                 
 GV            MOVE 'M51'  TO E-CODE                                            
 GV            PERFORM ERR-RTN                                                  
 GV   *    END-CASE                                                             
 GV        .                                                                    
 GV    MOVE-PAD-DATA-DETAIL-EXIT.                                               
 GV                                 EXIT.                                       
 GV                                                                             
 GV   ******************************************************************        
 GV   *    MOVE ALL THE SUMMARY HEADINGS OF PAD REPORT                          
 GV   *         AND CLOSE  THE PAD REPORT FILE.                                 
 GV   ******************************************************************        
 GV    PAD-END-OF-REPORT.                                                       
 GV           IF WS-LINE-CT > 45                                                
 GV              PERFORM  PAD-RPT-HEAD   THRU PAD-RPT-HEAD-EXIT.                
 GV                                                                             
 GV            MOVE '-' TO ST-CTL.                                              
 BP            MOVE 'TOTAL PAD REQUESTS       ' TO PAD-ST-NM.                   
 BP            MOVE WS-PAD-INEFF-REC            TO PAD-ST-REC.                  
 BP            MOVE WS-PAD-INEFF-AMT            TO PAD-ST-AMT.                  
 BP            PERFORM PRINT-PADRPT-ST-LINE THRU                                
 BP                    PRINT-PADRPT-ST-LINE-EXIT.                               
 GV            MOVE '0' TO ST-CTL.                                              
 BP            MOVE 'TOTAL PAD SUSPENDED      ' TO PAD-ST-NM.                   
 BP            MOVE WS-PAD-SUSP-REC             TO PAD-ST-REC.                  
 BP            MOVE WS-PAD-SUSP-AMT             TO PAD-ST-AMT.                  
 BP            PERFORM PRINT-PADRPT-ST-LINE THRU                                
 BP                    PRINT-PADRPT-ST-LINE-EXIT.                               
 BP                                                                             
 GV            MOVE ' ' TO ST-CTL.                                              
 BP            MOVE 'TOTAL PAD TERMINATED     ' TO PAD-ST-NM.                   
 BP            MOVE WS-PAD-TRMD-REC             TO PAD-ST-REC.                  
 BP            MOVE WS-PAD-TRMD-AMT             TO PAD-ST-AMT.                  
 BP            PERFORM PRINT-PADRPT-ST-LINE THRU                                
 BP                    PRINT-PADRPT-ST-LINE-EXIT.                               
 BP                                                                             
 BP            MOVE 'TOTAL PAD COMPLETED      ' TO PAD-ST-NM.                   
 BP            MOVE WS-PAD-CMP-REC              TO PAD-ST-REC.                  
 BP            MOVE WS-PAD-CMP-AMT              TO PAD-ST-AMT.                  
 GV            PERFORM PRINT-PADRPT-ST-LINE THRU                                
 BP                    PRINT-PADRPT-ST-LINE-EXIT.                               
 BP                                                                             
 BP            MOVE 'TOTAL PAD IN-FUTURE      ' TO PAD-ST-NM.                   
 BP            MOVE WS-PAD-INFUT-REC            TO PAD-ST-REC.                  
 BP            MOVE WS-PAD-INFUT-AMT            TO PAD-ST-AMT.                  
 BP            PERFORM PRINT-PADRPT-ST-LINE THRU                                
 BP                    PRINT-PADRPT-ST-LINE-EXIT.                               
 BP                                                                             
 GV            MOVE '0' TO ST-CTL.                                              
 BP            MOVE 'TOTAL NO PAD SELECTED    ' TO PAD-ST-NM.                   
 BP            MOVE WS-PAD-NPAD-REC             TO PAD-ST-REC.                  
 BP            MOVE WS-PAD-NPAD-AMT             TO PAD-ST-AMT.                  
 BP            PERFORM PRINT-PADRPT-ST-LINE THRU                                
 BP                    PRINT-PADRPT-ST-LINE-EXIT.                               
 GV    PAD-END-OF-REPORT-EXIT.                                                  
 GV                               EXIT.                                         
 GV                                                                             
 GV   ******************************************************************        
 GV   *    BUILD TEXT FOR ALPHA                                                 
 GV   ******************************************************************        
 GV    TEXT-ALPHA-OUT.                                                          
 GV2       IF WS-TOTAL-PREM-DUE < 0 AND REQ-PAD-NOT-FOUND                       
 GV2          MOVE EFT-ALPHA-LIT-2(LANG-SUB)  TO PR-SUMMARY-TEXT                
 GV2          PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 GV2          MOVE  NO-EFT-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2          PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 GV2          MOVE  NO-EFT-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2          PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 GV2          MOVE  NO-EFT-LIT-3(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2       ELSE                                                                 
 GV2            IF WS-TOTAL-PREM-DUE < 0                                        
 GV2          MOVE EFT-ALPHA-LIT-2(LANG-SUB)  TO PR-SUMMARY-TEXT                
 GV2       ELSE                                                                 
 GV2            IF REQ-PAD-NOT-FOUND                                            
 GV2          MOVE  EFT-ALPHA-LIT-3(LANG-SUB) TO PR-SUMMARY-TEXT                
 GV2          PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 GV2          MOVE  NO-EFT-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2          PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 GV2          MOVE  NO-EFT-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2          PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 GV2          MOVE  NO-EFT-LIT-3(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2       ELSE                                                                 
 GV2            IF REQ-PAD-IN-FUTURE                                            
 GV2            OR REQ-PAD-TERMINATED                                           
 GV2            OR REQ-PAD-SUSPENDED                                            
 GV             OR REQ-PAD-LOGIC-ABORTED                                        
 GV           MOVE  EFT-ALPHA-LIT-3(LANG-SUB) TO PR-SUMMARY-TEXT                
 GV2       ELSE                                                                 
 GV2            IF WS-TOTAL-PREM-DUE = 0  AND NOT REQ-PAD-IN-EFFECT             
 GV2           MOVE SPACES TO PR-SUMMARY-TEXT                                   
 GV        ELSE                                                                 
 GV           IF ENGLISH-SUB                                                    
 GV              PERFORM CONV-ENG-DT-OUT  THRU CONV-ENG-DT-OUT-EXIT             
 GV              MOVE VDATE-EXT-DATE            TO  EFT-DATE-ENG-AL-1           
 GV              MOVE EFT-ALPHA-LIT-1(LANG-SUB) TO  PR-SUMMARY-TEXT             
 GV           ELSE                                                              
 GV              PERFORM  CONV-FR-DT-OUT  THRU CONV-FR-DT-OUT-EXIT              
 GV              MOVE VDATE-EXT-DATE            TO  EFT-DATE-FR-AL-1            
 GV              MOVE EFT-ALPHA-LIT-1(LANG-SUB) TO  PR-SUMMARY-TEXT             
 GV        .                                                                    
 GV        PERFORM OUTPUT-RTN  THRU  OP-EXIT.                                   
 GV    TEXT-ALPHA-OUT-EXIT.                                                     
 GV                            EXIT.                                            
 GV                                                                             
 GV   ******************************************************************        
 GV   *    BUILD TEXT FOR SIGNATURE                                             
 GV   ******************************************************************        
 GV    TEXT-SIGNA-OUT.                                                          
 CA        IF WS-TOTAL-PREM-DUE < 0 AND REQ-PAD-NOT-FOUND                       
 CA           MOVE EFT-SIGN-LIT-2(LANG-SUB)  TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-3(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV        ELSE                                                                 
 GV             IF WS-TOTAL-PREM-DUE < 0                                        
 GV           MOVE EFT-SIGN-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                
 GV2       ELSE                                                                 
 GV2            IF REQ-PAD-NOT-FOUND                                            
 GV2          MOVE  EFT-SIGN-LIT-3(LANG-SUB) TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-3(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2       ELSE                                                                 
 GV2            IF REQ-PAD-IN-FUTURE                                            
 GV2            OR REQ-PAD-TERMINATED                                           
 GV2            OR REQ-PAD-SUSPENDED                                            
 GV             OR REQ-PAD-LOGIC-ABORTED                                        
 GV           MOVE EFT-SIGN-LIT-3(LANG-SUB)   TO PR-SUMMARY-TEXT                
 GV2       ELSE                                                                 
 GV2            IF WS-TOTAL-PREM-DUE = 0  AND NOT REQ-PAD-IN-EFFECT             
 GV2          MOVE SPACES TO PR-SUMMARY-TEXT                                    
 GV        ELSE                                                                 
 GV           IF ENGLISH-SUB                                                    
 GV              PERFORM CONV-ENG-DT-OUT  THRU CONV-ENG-DT-OUT-EXIT             
 GV              MOVE VDATE-EXT-DATE           TO  EFT-DATE-ENG-SG-1            
 GV              MOVE EFT-SIGN-LIT-1(LANG-SUB) TO PR-SUMMARY-TEXT               
 GV           ELSE                                                              
 GV              PERFORM  CONV-FR-DT-OUT  THRU CONV-FR-DT-OUT-EXIT              
 GV              MOVE VDATE-EXT-DATE           TO  EFT-DATE-FR-SG-1             
 GV              MOVE EFT-SIGN-LIT-1(LANG-SUB) TO PR-SUMMARY-TEXT               
 GV        .                                                                    
 GV        PERFORM OUTPUT-RTN  THRU  OP-EXIT.                                   
 GV    TEXT-SIGNA-OUT-EXIT.                                                     
 GV                             EXIT.                                           
 GV                                                                             
 GV   ******************************************************************        
 GV   *    BUILD TEXT FOR CORPORATE                                             
 GV   ******************************************************************        
 GV    TEXT-CORP-OUT.                                                           
 CA        IF WS-TOTAL-PREM-DUE < 0 AND REQ-PAD-NOT-FOUND                       
 CA           MOVE EFT-CORP-LIT-2(LANG-SUB)  TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-3(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV        ELSE                                                                 
 GV             IF WS-TOTAL-PREM-DUE < 0                                        
 GV           MOVE EFT-CORP-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                
 GV2       ELSE                                                                 
 GV2            IF REQ-PAD-NOT-FOUND                                            
 GV2          MOVE  EFT-CORP-LIT-3(LANG-SUB) TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-2(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 CA           PERFORM OUTPUT-RTN  THRU  OP-EXIT                                 
 CA           MOVE  NO-EFT-LIT-3(LANG-SUB)   TO PR-SUMMARY-TEXT                 
 GV2       ELSE                                                                 
 GV2            IF REQ-PAD-IN-FUTURE                                            
 GV2            OR REQ-PAD-TERMINATED                                           
 GV2            OR REQ-PAD-SUSPENDED                                            
 GV             OR REQ-PAD-LOGIC-ABORTED                                        
 GV           MOVE  EFT-CORP-LIT-3(LANG-SUB)  TO PR-SUMMARY-TEXT                
 GV2       ELSE                                                                 
 GV2            IF WS-TOTAL-PREM-DUE = 0  AND NOT REQ-PAD-IN-EFFECT             
 GV2           MOVE SPACES TO PR-SUMMARY-TEXT                                   
 GV        ELSE                                                                 
 GV           IF ENGLISH-SUB                                                    
 GV              PERFORM CONV-ENG-DT-OUT  THRU CONV-ENG-DT-OUT-EXIT             
 GV              MOVE VDATE-EXT-DATE             TO  EFT-DATE-ENG-CO-1          
 GV              MOVE EFT-CORP-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT             
 GV           ELSE                                                              
 GV              PERFORM  CONV-FR-DT-OUT  THRU CONV-FR-DT-OUT-EXIT              
 GV              MOVE VDATE-EXT-DATE             TO  EFT-DATE-FR-CO-1           
 GV              MOVE EFT-CORP-LIT-1(LANG-SUB)   TO PR-SUMMARY-TEXT             
 GV        .                                                                    
 GV        PERFORM OUTPUT-RTN  THRU  OP-EXIT.                                   
 GV    TEXT-CORP-OUT-EXIT.                                                      
 GV                          EXIT.                                              
 GV                                                                             
 BP   ******************************************************************        
 BP   *    PRINT A SUB TOTAL LINE ON THE PAD REPORT                             
 BP   ******************************************************************        
 BP    PRINT-PADRPT-ST-LINE.                                                    
 BP           MOVE  PADRPT-INFO-LR   TO LOGICAL-RECORD-NAME.                    
 BP           CALL  GAEDATSR    USING STORE-LR                                  
 BP                                   PAD-RPT-SUBTOTL                           
 BP                                   ICBM.                                     
 BP           PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                   
 BP           ADD  1 TO  WS-LINE-CT.                                            
 BP    PRINT-PADRPT-ST-LINE-EXIT.                                               
 BP                                 EXIT.                                       
 BP                                                                             
 GV   ******************************************************************        
 GV   *    CONVERTING THE DATE TO ENGLISH FORMAT(EXTERNAL FORMAT)               
 GV   ******************************************************************        
 GV    CONV-ENG-DT-OUT.                                                         
 GV        MOVE  'BB1E'           TO  VDATE-REQUEST-AREA.                       
 GV        MOVE REQ-EFF-DATE-OUT  TO  VDATE1-YYYYMMDD.                          
 GV        CALL GC2DATE          USING GAC-DATE-PARMS.                          
 GV    CONV-ENG-DT-OUT-EXIT.                                                    
 GV                           EXIT.                                             
 GV                                                                             
 GV   ******************************************************************        
 GV   *    CONVERTING THE DATE TO FRENCH FORMAT(EXTERNAL FORMAT)                
 GV   ******************************************************************        
 GV    CONV-FR-DT-OUT.                                                          
 GV        MOVE  'BB1F'           TO  VDATE-REQUEST-AREA.                       
 GV        MOVE REQ-EFF-DATE-OUT  TO  VDATE1-YYYYMMDD.                          
 GV        CALL GC2DATE          USING GAC-DATE-PARMS.                          
 GV    CONV-FR-DT-OUT-EXIT.                                                     
 GV                            EXIT.                                            
 GV                                                                             
 GV   ******************************************************************        
 GV   *    CHECKING LR STATUS.                                                  
 GV   ******************************************************************        
 GV    CHK-LR-STATUS.                                                           
 GV        IF (LR-STATUS-OK AND NOT REQ-PAD-LOGIC-ABORTED)                      
 GV           OR REQ-DONE                                                       
 GV            NEXT SENTENCE                                                    
 GV        ELSE                                                                 
 GV            DISPLAY '-----------------------------'                          
 GV            DISPLAY 'LR         ' LOGICAL-RECORD-NAME                        
 GV            DISPLAY 'STATUS     ' PROGRAM-LINKAGE-STATUS                     
 GV            DISPLAY 'REQ STATUS ' REQ-STATUS                                 
 GV            DISPLAY 'BATCH ID   ' REQ-BATCH-ID                               
 GV            DISPLAY ' GPRBILLS ABORT:             '                          
 GV            DISPLAY ' WRITING OF PAD REPORT FAILED'                          
 GV            DISPLAY '-----------------------------'                          
 GV            MOVE 16 TO RETURN-CODE                                           
 GV            STOP RUN.                                                        
 GV    CHK-LR-STATUS-EXIT.                                                      
 GV                             EXIT.                                           
 GV                                                                             
      ******************************************************************        
      *    RETURN TO CALLING PROGRAM - GPRINTAL.                                
      ******************************************************************        
       PROGRAM-EXIT.                                                            
           MOVE +0 TO PRINT-RETURN.                                             
           MOVE +4 TO  WRITE-ENG-RET                                            
                       WRITE-FRN-RET.                                           
           PERFORM  WRITE-ENG-BILLS           THRU   WRITE-ENG-X.               
           PERFORM  WRITE-FRN-BILLS           THRU   WRITE-FRN-X.               
E42        PERFORM 2900-FINISH-OUTPUT THRU 2900-FINISH-OUTPUT-EXIT.             
 GV        IF PAD-DETAILS-PRINTED                                               
 GV           PERFORM  PAD-END-OF-REPORT  THRU PAD-END-OF-REPORT-EXIT.          
                                                                                
 GV        MOVE 'D'   TO  REQ-REASON-CODE.                                      
 GV        CALL  GWEFCPDR  USING  PAD-REQUEST-PARMS.                            
 GV        PERFORM CHK-LR-STATUS  THRU CHK-LR-STATUS-EXIT.                      
 GV                                                                             
           GOBACK.                                                              
                                                                                
       READ-RECORD.                                                             
           CALL  'DLSREAD' USING  TAPE-SYS014  TAPE-RETURN                      
                                  TAPE-REC                                      
                                  TAPE-SYS014-RECSIZE                           
                                  TAPE-SYS014-BLKSIZE                           
                                  TAPE-SYS014-FORMAT                            
                                  TAPE-SYS014-COUNT.                            
                                                                                
GNE   *  EXCEPTION LOGIC :                                                      
GNE   *  FILLER IN CREDIT-ADJUSTMENTS ARE SOMETIMES WITH FILLER                 
GNE   *  X(22) OR X(23). DURING GNE PROJECT WARRANTY, IT IS                     
GNE   *  NOT KNOW WHERE THIS DISCREPANCY IS CREATED.                            
GNE   *  THIS PROGRAM IS COMPILED WITH COPYBOOK GD90ADJ7 WHERE                  
GNE   *  GD90AR-FILLER IS X(22) SINCE PGM == GFMEDD90 == IS                     
GNE   *  ALREADY COMPILED WITH FILLER X(22).                                    
GNE   *  NOTE:                                                                  
GNE   *  TAPE-LENGTH AND TAPE-RETURN HAVE TO BE SAVED AND REWRITTEN,            
GNE   *  AND THE FILLER X(22) TEMP TAPE-REC NEEDS A 1-BYTE FILLER ELSE          
GNE   *  TAPE-RETURN IS LOST AND THE LINKAGE SECTION IS OFF BY 1 BYTE.          
GNE        IF T-REC-TYPE = '2' AND T-ORD = 'Q' AND T-IDENT = 'U'                
GNE           MOVE TAPE-LENGTH            TO SAVE-TAPE-LENGTH                   
GNE           MOVE TAPE-RETURN            TO SAVE-TAPE-RETURN                   
GNE           MOVE TAPE-REC               TO TAPE-REC-FILLER22-REC              
GNE                                          TAPE-REC-FILLER23-REC              
GNE           IF  TAPE-REC-F22-CODE-CNT  IS NOT NUMERIC                         
GNE           AND TAPE-REC-F23-CODE-CNT  IS NUMERIC                             
GNE              MOVE TAPE-REC-F23-CODE-CNT  TO TAPE-REC-F22-CODE-CNT           
GNE              MOVE TAPE-REC-F23-AF-CD-CNT TO TAPE-REC-F22-AF-CD-CNT          
GNE              MOVE TAPE-REC-F23-REMAINDER TO TAPE-REC-F22-REMAINDER          
GNE              MOVE TAPE-REC-FILLER22-REC  TO TAPE-REC                        
GNE              MOVE SAVE-TAPE-LENGTH       TO TAPE-LENGTH                     
GNE              MOVE SAVE-TAPE-RETURN       TO TAPE-RETURN                     
GNE           END-IF                                                            
GNE        END-IF.                                                              
                                                                                
           IF COPY-INDICATOR EQUAL ' '                                          
             IF (T-REC-TYPE EQUAL '2'                                           
               AND T-ORD NOT EQUAL 'D')                                         
              IF ( GFM2D-PRODUCT EQUAL '1' OR '2' ) THEN                        
                   MOVE SPACES              TO EXT-RECORD                       
                   MOVE TAPE-REC            TO EXT-RECORD                       
                   MOVE GFM2D-PRODUCT       TO EXT-PRODUCT                      
                   MOVE GFM2D-BRANCH        TO EXT-BRANCH                       
                   MOVE GFM2D-BILLING-AGENT TO EXT-AGENT                        
                   COMPUTE EXT-LENGTH = TAPE-LENGTH + 25                        
           CALL 'DLSWRITE' USING EXT-SYS075     EXT-RETURN                      
                                 EXTRACT-RECORD EXT-RECSIZE                     
                                 EXT-BLKSIZE    EXT-FORMAT                      
                                 EXT-SYS075-COUNT                               
                   GO TO READ-RECORD-EXIT.                                      
           IF COPY-INDICATOR EQUAL ' '                                          
             IF T-REC-TYPE EQUAL '2'                                            
               IF T-ORD EQUAL 'D'                                               
                 IF ( T-PRODUCT EQUAL '1' OR '2' ) THEN                         
                   MOVE SPACES              TO EXT-RECORD                       
                   MOVE TAPE-REC            TO EXT-RECORD                       
                   MOVE T-PRODUCT           TO EXT-PRODUCT                      
                   MOVE T-BRANCH            TO EXT-BRANCH                       
                   MOVE T-AGENT             TO EXT-AGENT                        
                   COMPUTE EXT-LENGTH = TAPE-LENGTH + 25                        
           CALL 'DLSWRITE' USING EXT-SYS075     EXT-RETURN                      
                                 EXTRACT-RECORD EXT-RECSIZE                     
                                 EXT-BLKSIZE    EXT-FORMAT                      
                                 EXT-SYS075-COUNT.                              
       READ-RECORD-EXIT.                                                        
                                   EXIT.                                        
                                                                                
       GET-AGENT.                                                               
           MOVE GFM2D-AGENT-NAME    TO SAVE-AGENT-NAME.                         
       GET-AGENT-EXIT.                                                          
                                 EXIT.                                          
                                                                                
       PRINT-CHANGE-REPORT.                                                     
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    SWITCH TO PAGE FORMAT 'UGBIL4'. BILLING CHANGE PAGE.                 
      ****************************************************************          
           IF  GPPFA-PAGE-NAME NOT = 'UGBIL4'                                   
               MOVE 'UGBIL4'               TO GPPFA-PAGE-NAME                   
               MOVE GPPFA-PAGE-RECORD      TO PRINT-LINE                        
               PERFORM OUTPUT-RTN THRU OP-EXIT                                  
               IF  GFM2D-LANGUAGE = 'F'                                         
                   MOVE 'UGBL4F'           TO GPPFA-OVLY-COPYGRP                
                   MOVE GPPFA-OVLY-RECORD  TO PRINT-LINE                        
                   PERFORM OUTPUT-RTN THRU OP-EXIT                              
               ELSE                                                             
                   MOVE 'UGBL4E'           TO GPPFA-OVLY-COPYGRP                
                   MOVE GPPFA-OVLY-RECORD  TO PRINT-LINE                        
                   PERFORM OUTPUT-RTN THRU OP-EXIT.                             
                                                                                
           IF GFM2D-LANGUAGE EQUAL 'E' THEN                                     
              MOVE CHANGE-REPORTS-E TO                                          
                  WORK-REPORTS                                                  
           ELSE                                                                 
              MOVE CHANGE-REPORTS-F TO                                          
                  WORK-REPORTS.                                                 
                                                                                
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    CC = 1, PAGEDEF CHANNEL FOR CHANGE PAGE = LINE 1                     
      ****************************************************************          
           MOVE '1' TO CC.                                                      
           MOVE WR-TITLE           TO PR-LINE1.                                 
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO CC.                                                      
           MOVE PR-HEAD2-SAVE      TO PR25-HEAD.                                
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
           MOVE ' ' TO CC.                                                      
           MOVE WR-POLICY-AND-NAME TO PR-LINE1.                                 
           PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE ' ' TO CC.                                                      
      *    MOVE WR-EFF-AND-CHANGE  TO PR-LINE1.                                 
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE WR-CERT-AND-REMARKS TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE WR-NUMBER-AND-DATES TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE ' ' TO CC.                                                      
      *    MOVE WR-FOOTNOTE1        TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE ' ' TO CC.                                                      
      *    MOVE WR-DASH-LINE       TO PR-LINE1.                                 
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE WR-FOOTNOTE2        TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE WR-FOOTNOTE3        TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE WR-FOOTNOTE4        TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE WR-FOOTNOTE5        TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
      *    MOVE WR-FOOTNOTE6        TO PR-LINE1.                                
      *    PERFORM OUTPUT-RTN THRU OP-EXIT.                                     
       PCR-EXIT.                                                                
                           EXIT.                                                
                                                                                
       READ-ZACCVSAM.                                                           
              CALL 'ZACCVSAM'  USING  VSDSI20-PARM-1                            
                                      VSDSI20-PARM-2                            
                                      CONDENSED-MASTER.                         
       READ-ZACCVSAM-EXIT.                                                      
                                      EXIT.                                     
                                                                                
       CALL-GMASEXPD.                                                           
            MOVE LOW-VALUES TO GMASEXPD-ERROR.                                  
GNE         MOVE LOW-VALUES TO GMASTER7.                                        
GNE   *%    CALL 'GMASEXPD' USING CONDENSED-MASTER-RECORD                       
      *%                          GMASTER                                       
      *%                          GMASEXPD-ERROR.                               
GNE         MOVE CONDENSED-MASTER-RECORD TO GMASTER7.                           
       CALL-GMASEXPD-EXIT.                                                      
                                      EXIT.                                     
                                                                                
       CALL-GACCDMAS.                                                           
GNE         CALL GACBMAS7 USING GMP-PARM1                                       
GNE                               GMP-ERROR-CODE                                
GNE                               GMASTER7.                                     
       CALL-GACCDMAS-EXIT.                                                      
                                      EXIT.                                     
                                                                                
       WRITE-ENG-BILLS.                                                         
           CALL 'DLSWRITE'                    USING  WRITE-ENG-DDNAME           
                                                     WRITE-ENG-RET              
                                                     PRINT-LINE                 
                                                     WRITE-ENG-REC              
                                                     WRITE-ENG-BLK              
                                                     WRITE-ENG-FMT              
                                                     WRITE-ENG-CNT.             
       WRITE-ENG-X.                                                             
                              EXIT.                                             
                                                                                
       WRITE-FRN-BILLS.                                                         
           CALL 'DLSWRITE'                    USING  WRITE-FRN-DDNAME           
                                                     WRITE-FRN-RET              
                                                     PRINT-LINE                 
                                                     WRITE-FRN-REC              
                                                     WRITE-FRN-BLK              
                                                     WRITE-FRN-FMT              
                                                     WRITE-FRN-CNT.             
       WRITE-FRN-X.                                                             
                              EXIT.                                             
                                                                                
E42   ******************************************************************        
E42   *   the following logic (to the end of the program) is                    
E42   *   for creating an extract to go to the pdf creation process.            
E42   ******************************************************************        
E42                                                                             
E42    2100-START-OUTPUT.                                                       
E42   ******************************************************************        
E42   *  Set-up logic for general info for the flat file for the PDF            
E42   *  / web output. Make sure the occurs depending on variables are          
E42   *    set.                                                                 
E42   ******************************************************************        
E42        MOVE SPACES                 TO    BILL-SUMMARY-EXTRACT               
E42                                          BILL-GRP-END-EXTRACT               
E42                                          BILL-PAYMENT-EXTRACT               
E42                                          BILL-MEMBER-EXTRACT                
E42                                          BILL-MEMADJ1-EXTRACT               
E42                                          BILL-MEMADJ2-EXTRACT               
E42                                          BILL-CONTROL-EXTRACT.              
E42        MOVE WS-SYSTEM-DATE         TO    PROCESS-DATE                       
E42                                    OF    BILL-SUMMARY-EXTRACT.              
E42        MOVE WS-SYSTEM-DATE         TO    PROCESS-DATE                       
E42                                    OF    BILL-MEMBER-EXTRACT.               
E42        MOVE WS-SYSTEM-DATE         TO    PROCESS-DATE                       
E42                                    OF    BILL-PAYMENT-EXTRACT.              
E42        MOVE WS-SYSTEM-DATE         TO    PROCESS-DATE                       
E42                                    OF    BILL-GRP-END-EXTRACT.              
E42        MOVE WS-SYSTEM-DATE         TO    PROCESS-DATE                       
E42                                    OF    BILL-MEMADJ1-EXTRACT.              
E42        MOVE WS-SYSTEM-DATE         TO    PROCESS-DATE                       
E42                                    OF    BILL-MEMADJ2-EXTRACT.              
E42        MOVE WS-SYSTEM-DATE         TO    PROCESS-DATE                       
E42                                    OF    BILL-CONTROL-EXTRACT.              
E42        MOVE 'Z'                    TO    RECORD-TYPE                        
E42                                    OF    BILL-CONTROL-EXTRACT.              
E42        MOVE COPY-INDICATOR         TO    COPY-IND                           
E42                                    OF    BILL-CONTROL-EXTRACT.              
E42        MOVE ZERO                   TO    RECORD-COUNT                       
E42                                    OF    BILL-CONTROL-EXTRACT               
E422                                         NUM-OF-ERRORS                      
E422                                   OF    BILL-GRP-END-EXTRACT.              
E42    2100-START-OUTPUT-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    2900-FINISH-OUTPUT.                                                      
E42   ******************************************************************        
E42   *    Finish up all the output for the flat/pdf/web file.                  
E42   ******************************************************************        
E42        PERFORM 5900-FINISH-DETAIL    THRU 5900-FINISH-DETAIL-EXIT.          
E42        PERFORM 3900-FINISH-GROUP     THRU 3900-FINISH-GROUP-EXIT.           
E42   ******************************************************************        
E42   *    WRITE OUT THE CONTROL RECORD (ADD ON ONE FOR THE CONTROL             
E42   *    RECORD ITSELF                                                        
E42   ******************************************************************        
E42        ADD 1                          TO  RECORD-COUNT                      
E42                                       OF  BILL-CONTROL-EXTRACT.             
E42        MOVE BILL-CONTROL-EXTRACT      TO  BER-EXTRACT-DATA.                 
E42        MOVE BCR-FIXED-LENGTH          TO  BER-EXTRACT-LENGTH.               
E42        PERFORM 9100-WRITE-XTRACT     THRU 9100-WRITE-XTRACT-EXIT.           
E42   ******************************************************************        
E42   *    CLOSE THE FILE                                                       
E42   ******************************************************************        
E42        MOVE +4                        TO  WRITE-XTR-RET.                    
E42        PERFORM 9100-WRITE-XTRACT     THRU 9100-WRITE-XTRACT-EXIT.           
E42    2900-FINISH-OUTPUT-EXIT.                                                 
E42        EXIT.                                                                
E42                                                                             
E42    3100-START-GROUP.                                                        
E42   ******************************************************************        
E42   *    Establish the start for the group                                    
E42   ******************************************************************        
E42        MOVE 'Y'                       TO                                    
E42             WSA-XTR-GROUP-STARTED-FLAG.                                     
E42        MOVE ZERO                      TO  NUM-OF-ERRORS                     
E42                                       OF  BILL-GRP-END-EXTRACT              
E422                                          NUM-OF-COLS                       
E422                                      OF  BILL-GRP-END-EXTRACT.             
E42        PERFORM 3110-INIT-ERRORS      THRU 3110-INIT-ERRORS-EXIT             
E42                VARYING WSA-SUB       FROM 1 BY 1                            
E42                  UNTIL WSA-SUB        >   WSA-ERROR-MAX.                    
E42    3100-START-GROUP-EXIT.                                                   
E42        EXIT.                                                                
E42                                                                             
E42    3110-INIT-ERRORS.                                                        
E42        MOVE SPACES                    TO  GROUP-ERROR-CODE                  
E42                                       OF  BILL-GRP-END-EXTRACT              
E42                                           (WSA-SUB).                        
E42    3110-INIT-ERRORS-EXIT.                                                   
E42        EXIT.                                                                
E42                                                                             
E422   3200-STUB-RCD.                                                           
E422  ******************************************************************        
E422  *    FOR M40 ERRORS, ENSURE AN 'A' RECORD IS WRITTEN OUT.                 
E422  ******************************************************************        
E422       MOVE SPACES                     TO  BILL-SUMMARY-EXTRACT.            
E422       MOVE 'A'                        TO  RECORD-TYPE                      
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422       MOVE WS-SYSTEM-DATE             TO  PROCESS-DATE                     
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422       MOVE GFM2D-GROUP-NUMBER         TO  WSA-GROUP-NUMBER.                
E422       MOVE WSA-GROUP-NUMBER-X         TO  POLICY                           
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422  *                                                                         
E422       MOVE GFM2D-ACCOUNT              TO  ACCOUNT                          
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422       MOVE GFM2D-PREPARED-DATE        TO  WSA-ALIS-WORK-DATE.              
E422       PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E422       MOVE WSA-WORK-DATE              TO  PREPARED-DATE                    
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422       MOVE GFM2D-PREMIUM-DUE-DATE     TO  WSA-ALIS-WORK-DATE.              
E422       PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E422       MOVE WSA-WORK-DATE              TO  PREMIUM-DUE-DATE                 
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422       MOVE ZERO                       TO  NUM-OF-NA-LINES                  
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           BILLING-NUMBER                   
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           INSURED-LIVES                    
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           PREV-PREMIUM-DUE                 
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           GROSS-PREMIUM-DUE                
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           NET-PREMIUM-DUE                  
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           PREV-TAX-TOTAL                   
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           CURR-TAX-TOTAL                   
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           NUM-OF-TAX-ENTRIES               
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           NUM-OF-MEMBERS                   
E422                                       OF  BILL-SUMMARY-EXTRACT             
E422                                           NUM-OF-BENEFITS                  
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422  *                                                                         
E42        MOVE BILL-SUMMARY-EXTRACT       TO  BER-EXTRACT-DATA.                
E422       COMPUTE BER-EXTRACT-LENGTH      =   BSR-FIXED-LENGTH +               
E422                                           BSR-VAR-LENGTH   *               
E422                                           NUM-OF-BENEFITS                  
E422                                       OF  BILL-SUMMARY-EXTRACT.            
E422       PERFORM 9100-WRITE-XTRACT      THRU 9100-WRITE-XTRACT-EXIT.          
E422   3200-STUB-RCD-EXIT.                                                      
E422       EXIT.                                                                
E42                                                                             
E42    3500-EXTRACT-GROUP.                                                      
E42   ******************************************************************        
E42   *    Extract the group information directly from the records.             
E42   ******************************************************************        
E42   *    IF  GFM2D-STATEMENT-TYPE NOT EQUAL 'N'                               
E42   *        GO TO 3500-EXTRACT-GROUP-EXIT.                                   
E42        MOVE 'A'                        TO  RECORD-TYPE                      
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-GROUP-NUMBER         TO  WSA-GROUP-NUMBER.                
E42        MOVE WSA-GROUP-NUMBER-X         TO  POLICY                           
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42   *                                                                         
E42        MOVE GFM2D-ACCOUNT              TO  ACCOUNT                          
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42   *                                                                         
E42        MOVE GFM2D-DIVISION             TO  MAILING-DIVISION                 
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42   *                                                                         
E42        MOVE GFM2D-PRODUCT              TO  TC                               
E42                                        OF  PRODUCT.                         
E42   *                                                                         
E42        MOVE GFM2D-GROUP-OFFICE         TO  TC                               
E42                                        OF  GROUP-OFFICE.                    
E42   *                                                                         
E42        MOVE GFM2D-STATEMENT-TYPE       TO  TC                               
E42                                        OF  STATEMENT-TYPE.                  
E42   *                                                                         
E42        MOVE GFM2D-FROM-DATE            TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  FROM-DATE                        
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42   *                                                                         
E42        MOVE GFM2D-TO-DATE              TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  TO-DATE                          
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42   *                                                                         
E42        MOVE GFM2D-PREPARED-DATE        TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  PREPARED-DATE                    
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-PREMIUM-DUE-DATE     TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  PREMIUM-DUE-DATE                 
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42                                                                             
E42        MOVE GFM2D-BILLING-FORMAT-TYPE  TO  TC                               
E42                                        OF  BILL-FORMAT-TYPE.                
E42        MOVE GFM2D-BFSO-LIST-BILLING    TO  TC                               
E42                                        OF  LIST-BILLING.                    
E42        MOVE GFM2D-BFSO-CHANGE-BILLING  TO  TC                               
E42                                        OF  CHANGE-BILLING.                  
E42        MOVE GFM2D-CURRENCY             TO  TC                               
E42                                        OF  CURRENCY-CODE.                   
E42        MOVE GFM2D-GROUP-OFFICE-NAME    TO  GROUP-OFFICE-NAME                
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-IDENTITY             TO  IDENTITY                         
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-COUNTRY              TO  COUNTRY                          
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-LANGUAGE             TO  TC                               
E42                                        OF  LANGUAGE.                        
E42        MOVE SPACES                     TO  REQUESTOR                        
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE SPACES                     TO  LOGO                             
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-BRANCH               TO  TC                               
E42                                        OF  BRANCH.                          
E42        MOVE GFM2D-RESIDENCE            TO  TC                               
E42                                        OF  RESIDENCE.                       
E42        MOVE GFM2D-BILLING-AGENT        TO  AGENT                            
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-AGENT-NAME           TO  AGENT-NAME                       
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-BILLING-NUM-IND      TO  BILLING-NUM-IND                  
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-BILLING-NUMBER       TO  BILLING-NUMBER                   
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2D-CLAIMS-OFFICE        TO  TC                               
E42                                        OF  CLAIMS-OFFICE.                   
E42   ******************************************************************        
E42   *    Get the table data that maps the amounts to columns for              
E42   *    the member listing.                                                  
E42   *    SUB - 'COLUMN NUMBER'                                                
E42   *    SUBA - COV CODE UNDER COLUMN                                         
E42   *    SUBB - CUMULATIVE COV CODE                                           
E42   ******************************************************************        
E42        MOVE ZERO                       TO  WSA-SUB-B.                       
E42        PERFORM 3590-MOVE-COLS         THRU 3590-MOVE-COLS-EXIT              
E42                VARYING WSA-SUB        FROM 1 BY 1                           
E42                  UNTIL WSA-SUB         >   WSA-COLUMN-MAX.                  
E42        MOVE WSA-SUB-B                  TO  NUM-OF-COLS                      
E42                                        OF  BILL-GRP-END-EXTRACT.            
E42   *    handle 2E record                                                     
E42        MOVE GFM2E-INSURED-LIVES        TO  INSURED-LIVES                    
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-PREM-DUE-LAST-MTH    TO  PREV-PREMIUM-DUE                 
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-GROSS-PREM-DUE-THIS-MTH                                   
E42                                        TO  GROSS-PREMIUM-DUE                
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-NET-PREM-DUE-THIS-MTH                                     
E42                                        TO  NET-PREMIUM-DUE                  
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-GROUP-TAX-IND        TO  TC                               
E42                                        OF  TAX-STATUS                       
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-TAX-PREV-TOTAL       TO  PREV-TAX-TOTAL                   
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-TAX-CURR-TOTAL       TO  CURR-TAX-TOTAL                   
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-NO-OF-CODES          TO  NUM-OF-BENEFITS                  
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        MOVE GFM2E-TAX-TABLE-CNT        TO  NUM-OF-TAX-ENTRIES               
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42   *    Handle Occurrences                                                   
E42        PERFORM 3510-DO-TAXES          THRU 3510-DO-TAXES-EXIT               
E42                VARYING WSA-SUB        FROM 1 BY 1                           
E42                  UNTIL WSA-SUB         >   8.                               
E42                                                                             
E42        PERFORM 3520-DO-TOTALS         THRU 3520-DO-TOTALS-EXIT              
E42                VARYING WSA-SUB        FROM 1 BY 1                           
E42                  UNTIL WSA-SUB         >   GFM2E-NO-OF-CODES.               
E42        PERFORM 3530-DO-NAME-ADDR THRU    3530-DO-NAME-ADDR-EXIT             
E42                VARYING WSA-SUB   FROM    1 BY 1                             
E42                  UNTIL WSA-SUB    >      WSA-NAME-ADDR-MAX.                 
E42        MOVE ZERO                       TO  NUM-OF-MEMBERS.                  
E42        MOVE BILL-SUMMARY-EXTRACT       TO  BER-EXTRACT-DATA.                
E42        COMPUTE BER-EXTRACT-LENGTH      =   BSR-FIXED-LENGTH +               
E42                                            BSR-VAR-LENGTH   *               
E42                                            NUM-OF-BENEFITS                  
E42                                        OF  BILL-SUMMARY-EXTRACT.            
E42        PERFORM 9100-WRITE-XTRACT      THRU 9100-WRITE-XTRACT-EXIT.          
E42   ******************************************************************        
E42   *    MOVE IN THE DATES FROM THE FIRST GROUP TO THE CONTROL                
E42   *    RECORD.                                                              
E42   ******************************************************************        
E42        IF  PREPARED-DATE OF BILL-CONTROL-EXTRACT = SPACES                   
E42            MOVE PREPARED-DATE          OF  BILL-SUMMARY-EXTRACT             
E42                                        TO  PREPARED-DATE                    
E42                                        OF  BILL-CONTROL-EXTRACT.            
E42        IF  PREMIUM-DUE-DATE OF BILL-CONTROL-EXTRACT = SPACES                
E42            MOVE PREMIUM-DUE-DATE       OF  BILL-SUMMARY-EXTRACT             
E42                                        TO  PREMIUM-DUE-DATE                 
E42                                        OF  BILL-CONTROL-EXTRACT.            
E42    3500-EXTRACT-GROUP-EXIT.                                                 
E42        EXIT.                                                                
                                                                                
E42    3510-DO-TAXES.                                                           
E42   ******************************************************************        
E42   *    Write out the tax table                                              
E42   ******************************************************************        
E42        IF  WSA-SUB > GFM2E-TAX-TABLE-CNT                                    
E42            MOVE SPACES                 TO  TAX-CODE                         
E42                                        OF  TAXES                            
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB)                        
E42            MOVE ZERO                   TO  PREV-TAX-AMOUNT                  
E42                                        OF  TAXES                            
E42                                            (WSA-SUB)                        
E42            MOVE ZERO                   TO  CURR-TAX-AMOUNT                  
E42                                        OF  TAXES                            
E42                                            (WSA-SUB)                        
E42            GO TO 3510-DO-TAXES-EXIT.                                        
E42                                                                             
E42        MOVE GFM2E-TAX-CODE (WSA-SUB)                                        
E42                                        TO  TAX-CODE                         
E42                                        OF  TAXES                            
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB).                       
E42        MOVE GFM2E-TAX-PREV-AMT (WSA-SUB)                                    
E42                                        TO  PREV-TAX-AMOUNT                  
E42                                        OF  TAXES                            
E42                                            (WSA-SUB).                       
E42        MOVE GFM2E-TAX-CURR-AMT (WSA-SUB)                                    
E42                                        TO  CURR-TAX-AMOUNT                  
E42                                        OF  TAXES                            
E42                                            (WSA-SUB).                       
E42    3510-DO-TAXES-EXIT.                                                      
E42        EXIT.                                                                
E42                                                                             
E42    3520-DO-TOTALS.                                                          
E42   ******************************************************************        
E42   *    Write out the totals                                                 
E42   ******************************************************************        
E42        MOVE GFM2E-COVERAGE-CODE (WSA-SUB)                                   
E42                                        TO  WSA-NUMBER3.                     
E42        MOVE WSA-NUMBER3-X              TO  I-D                              
E42                                        OF  BENEFIT                          
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB).                       
E42        MOVE ZERO                       TO  LIVES                            
E42                                        OF  BENEFIT                          
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB).                       
E42        MOVE GFM2E-VOLUME (WSA-SUB)     TO  VOLUME                           
E42                                        OF  BENEFIT                          
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB).                       
E42        MOVE GFM2E-BILLED-PREMIUM (WSA-SUB)                                  
E42                                        TO  BILLED-PREMIUM                   
E42                                        OF  BENEFIT                          
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB).                       
E42        MOVE GBINO-HIST-SEG             TO  WSA-SUB-A.                       
E42        MOVE GFM2E-COVERAGE-CODE (WSA-SUB)                                   
E42                                        TO  WSA-CURR-COV-CODE.               
           IF GBINO-COV-LINES (WSA-SUB-A) NUMERIC                               
E42            PERFORM 3525-FIND-LIVES        THRU 3525-FIND-LIVES-EXIT         
E42                VARYING WSA-SUB-B FROM 1 BY 1                                
E42                  UNTIL WSA-SUB-B > GBINO-COV-LINES (WSA-SUB-A)              
E42                     OR WSA-SUB-B > 10.                                      
E42    3520-DO-TOTALS-EXIT.                                                     
E42        EXIT.                                                                
E42                                                                             
E42    3525-FIND-LIVES.                                                         
E42   *****************************************************************`        
E42   *    Match up on coverage code and get the number of lives                
E42   *    from the master.                                                     
E42   *    For some reason, life and AD&D entries have different                
E42   *      codes on the master. override and then test.                       
E42   *    For EHC and Dental, get the number of lives as per volume            
E42   ******************************************************************        
E42        MOVE GBICOV-CODE (WSA-SUB-A WSA-SUB-B)                               
E42                                        TO  WSA-TEST-COV-CODE.               
E42        IF  WSA-TEST-COV-CODE-LIFE                                           
E42            MOVE 150                    TO  WSA-TEST-COV-CODE.               
E42        IF  WSA-TEST-COV-CODE-ADD                                            
E42            MOVE 083                    TO  WSA-TEST-COV-CODE.               
E42        IF  WSA-CURR-COV-CODE NOT = WSA-TEST-COV-CODE                        
E42            GO TO 3525-FIND-LIVES-EXIT.                                      
E42        IF  WSA-TEST-COV-CODE NOT = 019 AND                                  
E42            WSA-TEST-COV-CODE NOT = 099                                      
E42            MOVE GBINO-LIVES (WSA-SUB-A WSA-SUB-B)                           
E42                                        TO  LIVES                            
E42                                        OF  BENEFIT                          
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB)                        
E42            GO TO 3525-FIND-LIVES-EXIT.                                      
E42        IF  GFM2E-VOLUME (WSA-SUB) =                                         
E42            GBIVOL  (WSA-SUB-A WSA-SUB-B)                                    
E42            MOVE GBINO-LIVES (WSA-SUB-A WSA-SUB-B)                           
E42                                        TO  LIVES                            
E42                                        OF  BENEFIT                          
E42                                        OF  BILL-SUMMARY-EXTRACT             
E42                                            (WSA-SUB).                       
E42    3525-FIND-LIVES-EXIT.                                                    
E42        EXIT.                                                                
E42                                                                             
E42    3530-DO-NAME-ADDR.                                                       
E42   ******************************************************************        
E42   *    Write out the name and address lines                                 
E42   ******************************************************************        
E42        MOVE WSA-SUB                    TO  NUM-OF-NA-LINES.                 
E42        MOVE GFM2D-NAME-ADDRESS-LINES (WSA-SUB)                              
E42             TO  NAME-ADDRESS                                                
E42             OF  BILL-SUMMARY-EXTRACT (WSA-SUB).                             
E42        MOVE GFM2D-NAME-ADDRESS-DELIMITER (WSA-SUB)                          
E42             TO  NAME-ADDRESS-DELIMITER                                      
E42             OF  BILL-SUMMARY-EXTRACT (WSA-SUB).                             
E42    3530-DO-NAME-ADDR-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    3590-MOVE-COLS.                                                          
E42   ******************************************************************        
E42   *    Move the column data to the extract.                                 
E42   ******************************************************************        
E42        IF  GFM2D-BC-PREM-OR-VOL (WSA-SUB) = SPACES                          
E42            MOVE WSA-COLUMN-MAX         TO  WSA-SUB                          
E42            GO TO 3590-MOVE-COLS-EXIT.                                       
E42        PERFORM 3591-MOVE-BEN          THRU 3591-MOVE-BEN-EXIT               
E42            VARYING WSA-SUB-A          FROM 1 BY 1                           
E42              UNTIL WSA-SUB-A           >   GFM2D-BC-NO-OF-CODES             
E42                                            (WSA-SUB).                       
E42    3590-MOVE-COLS-EXIT.                                                     
E42        EXIT.                                                                
E42                                                                             
E42    3591-MOVE-BEN.                                                           
E42   ******************************************************************        
E42   *    Move all the cov codes.                                              
E42   ******************************************************************        
E42        ADD 1                           TO  WSA-SUB-B.                       
E42        MOVE WSA-SUB                    TO  COL                              
E42                                        OF  BILL-GRP-END-EXTRACT             
E42                                            (WSA-SUB-B).                     
E42        MOVE GFM2D-BC-TITLE-LINE1 (WSA-SUB)                                  
E42                                        TO  TITLE-1                          
E42                                        OF  BILL-GRP-END-EXTRACT             
E42                                            (WSA-SUB-B).                     
E42        MOVE GFM2D-BC-TITLE-LINE2 (WSA-SUB)                                  
E42                                        TO  TITLE-2                          
E42                                        OF  BILL-GRP-END-EXTRACT             
E42                                            (WSA-SUB-B).                     
E42        MOVE GFM2D-BC-PREM-OR-VOL (WSA-SUB)                                  
E42                                        TO  FIELD-TYPE                       
E42                                        OF  BILL-GRP-END-EXTRACT             
E42                                            (WSA-SUB-B).                     
E42        MOVE GFM2D-BC-CODES (WSA-SUB-B) TO  WSA-NUMBER3.                     
E42        MOVE WSA-NUMBER3-X              TO  COV-CODE                         
E42                                        OF  BILL-GRP-END-EXTRACT             
E42                                            (WSA-SUB-B).                     
E42    3591-MOVE-BEN-EXIT.                                                      
E42        EXIT.                                                                
E42                                                                             
E42    3900-FINISH-GROUP.                                                       
E42   ******************************************************************        
E42   *    Finish up processing for the group                                   
E42   ******************************************************************        
E42        IF  WSA-XTR-GROUP-FINISHED                                           
E42            GO TO 3900-FINISH-GROUP-EXIT.                                    
E42        MOVE 'D'                        TO  RECORD-TYPE                      
E42                                        OF  BILL-GRP-END-EXTRACT.            
E42        MOVE POLICY                     OF  BILL-SUMMARY-EXTRACT             
E42          TO POLICY                     OF  BILL-GRP-END-EXTRACT.            
E42   *                                                                         
E42        MOVE ACCOUNT                    OF  BILL-SUMMARY-EXTRACT             
E42          TO ACCOUNT                    OF  BILL-GRP-END-EXTRACT.            
E42   *                                                                         
E42        MOVE MAILING-DIVISION           OF  BILL-SUMMARY-EXTRACT             
E42          TO MAILING-DIVISION           OF  BILL-GRP-END-EXTRACT.            
E42   *                                                                         
E42        MOVE REQ-STATUS                 TO  GROUP-PAD-STATUS                 
E42                                        OF  BILL-GRP-END-EXTRACT.            
E422       IF  GROUP-PAD-STATUS OF BILL-GRP-END-EXTRACT = LOW-VALUES            
E42            MOVE SPACES                 TO  GROUP-PAD-STATUS                 
E42                                        OF  BILL-GRP-END-EXTRACT.            
E42        MOVE BILL-GRP-END-EXTRACT       TO  BER-EXTRACT-DATA.                
E42        COMPUTE BER-EXTRACT-LENGTH      =   BER-FIXED-LENGTH +               
E42                                            BER-VAR-LENGTH   *               
E42                                            NUM-OF-COLS                      
E42                                        OF  BILL-GRP-END-EXTRACT.            
E42        PERFORM 9100-WRITE-XTRACT      THRU 9100-WRITE-XTRACT-EXIT.          
E42                                                                             
E42        MOVE 'N'                        TO                                   
E42             WSA-XTR-GROUP-STARTED-FLAG.                                     
E42   *    ZERO OUT JUST IN CASE (SHOULD BE HANDLED BY START)                   
E42        MOVE ZERO                      TO  NUM-OF-ERRORS                     
E42                                       OF  BILL-GRP-END-EXTRACT.             
E42        PERFORM 3110-INIT-ERRORS      THRU 3110-INIT-ERRORS-EXIT             
E42                VARYING WSA-SUB       FROM 1 BY 1                            
E42                  UNTIL WSA-SUB        >   WSA-ERROR-MAX.                    
E42    3900-FINISH-GROUP-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    4100-START-PAYMENT.                                                      
E42   ******************************************************************        
E42   *    Perform whatever is necessary to start the payment stuff             
E42   *    Nothing is required right now.                                       
E42   ******************************************************************        
E42    4100-START-PAYMENT-EXIT.                                                 
E42        EXIT.                                                                
E42                                                                             
E42    4500-EXTRACT-PAYMENT.                                                    
E42   ******************************************************************        
E42   *  Extract the actual payment data                                        
E42   ******************************************************************        
E42   *                                                                         
E42        MOVE 'C'                        TO  RECORD-TYPE                      
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42        MOVE GBILL-PAY-GROUP-NUMBER     TO  WSA-GROUP-NUMBER.                
E42        MOVE WSA-GROUP-NUMBER-X         TO  POLICY                           
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42   *                                                                         
E42        MOVE GBILL-PAY-ACCOUNT          TO  ACCOUNT                          
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42   *                                                                         
E42        MOVE GBILL-PAY-DIVISION         TO  MAILING-DIVISION                 
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42        MOVE GBILL-PAY-PAYMENT-DATE     TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  PAYMENT-DATE                     
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42   *                                                                         
E42        MOVE GBILL-PAY-PAYMENT-AMOUNT   TO  PAYMENT-AMOUNT                   
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42        IF  GBILL-PAY-REG-TAX = LOW-VALUES                                   
E42            MOVE SPACES                 TO  PAYMENT-REG-TAX                  
E42                                        OF  BILL-PAYMENT-EXTRACT             
E42        ELSE                                                                 
E42            MOVE GBILL-PAY-REG-TAX      TO  PAYMENT-REG-TAX                  
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42        IF  GBILL-PAY-TAX-CODE = LOW-VALUES                                  
E42            MOVE SPACES                 TO  PAYMENT-TAX-CODE                 
E42                                        OF  BILL-PAYMENT-EXTRACT             
E42        ELSE                                                                 
E42            MOVE GBILL-PAY-TAX-CODE     TO  PAYMENT-TAX-CODE                 
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42        MOVE GBILL-PAY-ORDER            TO  PAYMENT-ORDER                    
E42                                        OF  BILL-PAYMENT-EXTRACT.            
E42        MOVE BILL-PAYMENT-EXTRACT       TO  BER-EXTRACT-DATA.                
E42        MOVE BPR-FIXED-LENGTH           TO  BER-EXTRACT-LENGTH.              
E42        PERFORM 9100-WRITE-XTRACT      THRU 9100-WRITE-XTRACT-EXIT.          
E42    4500-EXTRACT-PAYMENT-EXIT.                                               
E42        EXIT.                                                                
                                                                                
E42    4900-FINISH-PAYMENT.                                                     
E42   ******************************************************************        
E42   *    Finish the payment elements - nothing to do right now                
E42   ******************************************************************        
E42    4900-FINISH-PAYMENT-EXIT.                                                
E42        EXIT.                                                                
E42                                                                             
E42    5100-START-DETAIL.                                                       
E42   ******************************************************************        
E42   *    Start up the detail section                                          
E42   ******************************************************************        
E42        MOVE 'Y'                   TO  WSA-MEM-DETAIL-STARTED-FLAG.          
E42    5100-START-DETAIL-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    5500-EXTRACT-DETAIL.                                                     
E42   ******************************************************************        
E42   *    Write the detail lines                                               
E42   ******************************************************************        
E42        MOVE TAPE-REC                  TO  GBC-BILL-CURR-RECORD.             
E42        IF  GBC-DETAIL-IDENT = 'S'                                           
E42            PERFORM 6200-EXTRACT-CURR THRU 6200-EXTRACT-CURR-EXIT            
E42        ELSE                                                                 
E42             IF  GBC-DETAIL-IDENT = 'T'                                      
E42            MOVE TAPE-REC              TO  GBA-BILL-ADJ-RECORD               
E42            PERFORM 6400-EXTRACT-ADJ1 THRU 6400-EXTRACT-ADJ1-EXIT            
E42        ELSE                                                                 
E42            MOVE TAPE-REC              TO  GFMEDD90-ADJUST-RECORD            
E42            PERFORM 6600-EXTRACT-ADJ2 THRU 6600-EXTRACT-ADJ2-EXIT.           
E42    5500-EXTRACT-DETAIL-EXIT.                                                
E42        EXIT.                                                                
E42                                                                             
E42    5900-FINISH-DETAIL.                                                      
E42   ******************************************************************        
E42   *    finish up the detail section                                         
E42   ******************************************************************        
E42        IF  WSA-MEM-DETAIL-FINISHED                                          
E42            GO TO 5900-FINISH-DETAIL-EXIT.                                   
E42        MOVE 'N'                   TO                                        
E42             WSA-MEM-DETAIL-STARTED-FLAG.                                    
E42    5900-FINISH-DETAIL-EXIT.                                                 
E42        EXIT.                                                                
E42                                                                             
E42    6200-EXTRACT-CURR.                                                       
E42   ******************************************************************        
E42   *    Write out the current detail extract.                                
E42   ******************************************************************        
E42        MOVE 'B'                        TO  RECORD-TYPE                      
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42        MOVE GBC-GROUP                  TO  WSA-GROUP-NUMBER.                
E42        MOVE WSA-GROUP-NUMBER-X         TO  POLICY                           
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-ACCOUNT                TO  ACCOUNT                          
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42        MOVE GBC-DIVISION               TO  MAILING-DIVISION                 
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42        IF  GBC-ORDER EQUAL 'Q'                                              
E42            MOVE GBC-CERT-1             TO  WSA-NUMBER9                      
E42            MOVE GBC-NAME-1             TO  MEMBER-NAME                      
E42                                        OF  BILL-MEMBER-EXTRACT              
E42        ELSE                                                                 
E42            MOVE GBC-CERT-2             TO  WSA-NUMBER9                      
E42            MOVE GBC-NAME-2             TO  MEMBER-NAME                      
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE WSA-NUMBER9-X              TO  I-D                              
E42                                        OF  MEMBER                           
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42        MOVE WSA-NUMBER9-X              TO  CERTIFICATE                      
E42                                        OF  MEMBER                           
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-CLASS                  TO  CLASS-CODE                       
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-TOTAL-PREMIUM          TO  TOTAL-PREMIUM                    
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-TAXABLE-IND            TO  TC                               
E42                                        OF  TAX-STATUS                       
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-TAX-CODE               TO  TC                               
E42                                        OF  TAX-CODE                         
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-DETAIL-TERM-DATE       TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  TERM-DATE                        
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-DETAIL-ISSUE-DATE      TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  ISSUE-DATE                       
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-DETAIL-REINST-DATE     TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  REINST-DATE                      
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42   *                                                                         
E42        MOVE GBC-NUM-COV-CODES          TO  NUM-OF-MEMBER-BENEFITS           
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42        PERFORM 6220-DO-BENEFITS       THRU 6220-DO-BENEFITS-EXIT            
E42                VARYING WSA-SUB        FROM 1 BY 1                           
E42                  UNTIL WSA-SUB         >   GBC-NUM-COV-CODES.               
E42   *                                                                         
E42        COMPUTE BER-EXTRACT-LENGTH      =   BMR-FIXED-LENGTH +               
E42                                            BMR-VAR-LENGTH   *               
E42                                            NUM-OF-MEMBER-BENEFITS           
E42                                        OF  BILL-MEMBER-EXTRACT.             
E42        MOVE BILL-MEMBER-EXTRACT        TO  BER-EXTRACT-DATA.                
E42        PERFORM 9100-WRITE-XTRACT      THRU 9100-WRITE-XTRACT-EXIT.          
E42    6200-EXTRACT-CURR-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    6220-DO-BENEFITS.                                                        
E42   ******************************************************************        
E42   *    Write out the totals                                                 
E42   ******************************************************************        
E42        MOVE GBC-COV-CODE (WSA-SUB)     TO  WSA-NUMBER3.                     
E42        MOVE WSA-NUMBER3-X              TO  COV-CODE                         
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMBER-EXTRACT              
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42        MOVE GBC-VOLUME (WSA-SUB)       TO  VOLUME                           
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMBER-EXTRACT              
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42        MOVE GBC-BILLED-PREMIUM (WSA-SUB)                                    
E42                                        TO  BILLED-PREMIUM                   
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMBER-EXTRACT              
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42        MOVE GBC-SEL-IND (WSA-SUB)      TO  TC                               
E42                                        OF  SELECT-IND                       
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMBER-EXTRACT              
E42                                            (WSA-SUB).                       
E42        IF  GBC-SEL-IND (WSA-SUB)       =   LOW-VALUES                       
E42            MOVE SPACES                 TO  TC                               
E42                                        OF  SELECT-IND                       
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMBER-EXTRACT              
E42                                            (WSA-SUB).                       
E42    6220-DO-BENEFITS-EXIT.                                                   
E42        EXIT.                                                                
E42                                                                             
E42    6400-EXTRACT-ADJ1.                                                       
E42   ******************************************************************        
E42   *    Write out the current details for the indicated adjustment           
E42   *    (the adjustment '1' record)                                          
E42   ******************************************************************        
E42        MOVE 'E'                        TO  RECORD-TYPE                      
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42        MOVE GBA-GROUP                  TO  WSA-GROUP-NUMBER.                
E42        MOVE WSA-GROUP-NUMBER-X         TO  POLICY                           
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42   *                                                                         
E42        MOVE GBA-ACCOUNT                TO  ACCOUNT                          
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42        MOVE GBA-DIVISION               TO  MAILING-DIVISION                 
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42        IF  GBA-ORDER EQUAL 'Q'                                              
E42            MOVE GBA-CERT-1             TO  WSA-NUMBER9                      
E42            MOVE GBA-NAME-1             TO  MEMBER-NAME                      
E42                                        OF  BILL-MEMADJ1-EXTRACT             
E42        ELSE                                                                 
E42            MOVE GBA-CERT-2             TO  WSA-NUMBER9                      
E42            MOVE GBA-NAME-2             TO  MEMBER-NAME                      
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42   *                                                                         
E42        MOVE WSA-NUMBER9-X              TO  I-D                              
E42                                        OF  MEMBER-ADJUSTMENT1               
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42        MOVE WSA-NUMBER9-X              TO  CERTIFICATE                      
E42                                        OF  MEMBER-ADJUSTMENT1               
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42   *                                                                         
E42        MOVE GBA-ADJ-MODE               TO  ADJUST-MODE                      
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42   *                                                                         
E42        MOVE GBA-EFFECTIVE-DATE         TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  EFFECTIVE-DATE                   
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42   *                                                                         
E42        MOVE GBA-TOTAL-PREMIUM          TO  TOTAL-PREMIUM                    
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42   *                                                                         
E42        MOVE GBA-NUM-COV-CODES          TO  NUM-OF-MEMBER-BENEFITS           
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42        PERFORM 6440-DO-BENEFITS       THRU 6440-DO-BENEFITS-EXIT            
E42                VARYING WSA-SUB        FROM 1 BY 1                           
E42                  UNTIL WSA-SUB         >   GBA-NUM-COV-CODES.               
E42   *                                                                         
E42        COMPUTE BER-EXTRACT-LENGTH      =   BA1R-FIXED-LENGTH +              
E42                                            BA1R-VAR-LENGTH   *              
E42                                            NUM-OF-MEMBER-BENEFITS           
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42        MOVE BILL-MEMADJ1-EXTRACT       TO  BER-EXTRACT-DATA.                
E42        PERFORM 9100-WRITE-XTRACT      THRU 9100-WRITE-XTRACT-EXIT.          
E42    6400-EXTRACT-ADJ1-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    6440-DO-BENEFITS.                                                        
E42   ******************************************************************        
E42   *    Write out the totals for the adjustment record                       
E42   ******************************************************************        
E42        MOVE GBA-COV-CODE (WSA-SUB)     TO  WSA-NUMBER3.                     
E42        MOVE WSA-NUMBER3-X              TO  COV-CODE                         
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMADJ1-EXTRACT             
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42        MOVE GBA-VOLUME (WSA-SUB)       TO  VOLUME                           
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMADJ1-EXTRACT             
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42        MOVE GBA-PREM-ADJ-AMOUNT(WSA-SUB)                                    
E42                                        TO  PREM-ADJUST-AMOUNT               
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMADJ1-EXTRACT             
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42        MOVE GBA-SEL-IND (WSA-SUB)      TO  TC                               
E42                                        OF  SELECT-IND                       
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMADJ1-EXTRACT             
E42                                            (WSA-SUB).                       
E42        IF  GBA-SEL-IND (WSA-SUB)       =   LOW-VALUES                       
E42            MOVE SPACES                 TO  TC                               
E42                                        OF  SELECT-IND                       
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMADJ1-EXTRACT             
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42    6440-DO-BENEFITS-EXIT.                                                   
E42        EXIT.                                                                
E42                                                                             
E42    6600-EXTRACT-ADJ2.                                                       
E42   ******************************************************************        
E42   *    Write out the current details for the indicated adjustment           
E42   *    (the adjustment '2' record)                                          
E42   ******************************************************************        
E42        MOVE 'F'                        TO  RECORD-TYPE                      
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42        MOVE GD90AR-GROUP-NUMBER        TO  WSA-GROUP-NUMBER.                
E42        MOVE WSA-GROUP-NUMBER-X         TO  POLICY                           
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42   *                                                                         
E42        MOVE GD90AR-ACCOUNT             TO  ACCOUNT                          
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42        MOVE GD90AR-DIVISION            TO  MAILING-DIVISION                 
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42        IF  GD90AR-ORDER EQUAL 'Q'                                           
E42            MOVE GD90AR-NC-CERTIFICATE  TO  WSA-NUMBER9                      
E42            MOVE GD90AR-NC-NAME         TO  MEMBER-NAME                      
E42                                        OF  BILL-MEMADJ2-EXTRACT             
E42        ELSE                                                                 
E42            MOVE GD90AR-CN-CERTIFICATE  TO  WSA-NUMBER9                      
E42            MOVE GD90AR-CN-NAME         TO  MEMBER-NAME                      
E42                                        OF  BILL-MEMADJ1-EXTRACT.            
E42   *                                                                         
E42        MOVE WSA-NUMBER9-X              TO  I-D                              
E42                                        OF  MEMBER-ADJUSTMENT2               
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42        MOVE WSA-NUMBER9-X              TO  CERTIFICATE                      
E42                                        OF  MEMBER-ADJUSTMENT2               
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42   *                                                                         
E42        MOVE GD90AR-EFFECTIVE-DATE      TO  WSA-ALIS-WORK-DATE.              
E42        PERFORM 9200-CONVERT-DATE      THRU 9200-CONVERT-DATE-EXIT.          
E42        MOVE WSA-WORK-DATE              TO  EFFECTIVE-DATE                   
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42   *                                                                         
E42        MOVE GD90AR-DETAIL-REMARKS      TO  DETAIL-REMARKS                   
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42   *                                                                         
E42        MOVE GD90AR-TOTAL-PREMIUM       TO  TOTAL-PREMIUM                    
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42   *                                                                         
E42        MOVE GD90AR-TAX-IND             TO  TC                               
E42                                        OF  TAX-STATUS                       
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42   *                                                                         
E42        MOVE GD90AR-TAX-CODE            TO  TC                               
E42                                        OF  TAX-CODE                         
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42   *                                                                         
E42        MOVE GD90AR-NO-OF-CODES         TO  NUM-OF-MEMBER-BENEFITS           
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42        PERFORM 6660-DO-BENEFITS       THRU 6660-DO-BENEFITS-EXIT            
E42                VARYING WSA-SUB        FROM 1 BY 1                           
E42                  UNTIL WSA-SUB         >   GD90AR-NO-OF-CODES.              
E42   *                                                                         
E42        COMPUTE BER-EXTRACT-LENGTH      =   BA2R-FIXED-LENGTH +              
E42                                            BA2R-VAR-LENGTH   *              
E42                                            NUM-OF-MEMBER-BENEFITS           
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42        MOVE BILL-MEMADJ2-EXTRACT       TO  BER-EXTRACT-DATA.                
E42                                                                             
E42        PERFORM 6660-DO-BENEFITS       THRU 6660-DO-BENEFITS-EXIT            
E42                VARYING WSA-SUB        FROM 1 BY 1                           
E42                  UNTIL WSA-SUB         >   GD90AR-NO-OF-CODES.              
E42   *                                                                         
E42        COMPUTE BER-EXTRACT-LENGTH      =   BA2R-FIXED-LENGTH +              
E42                                            BA2R-VAR-LENGTH   *              
E42                                            NUM-OF-MEMBER-BENEFITS           
E42                                        OF  BILL-MEMADJ2-EXTRACT.            
E42        MOVE BILL-MEMADJ2-EXTRACT       TO  BER-EXTRACT-DATA.                
E42        PERFORM 9100-WRITE-XTRACT      THRU 9100-WRITE-XTRACT-EXIT.          
E42    6600-EXTRACT-ADJ2-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    6660-DO-BENEFITS.                                                        
E42   ******************************************************************        
E42   *    Write out the adjustment amounts for the adjustment record           
E42   ******************************************************************        
E42        MOVE GD90AR-COVERAGE-CODE (WSA-SUB)                                  
E42                                        TO  WSA-NUMBER3.                     
E42        MOVE WSA-NUMBER3-X              TO  COV-CODE                         
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMADJ2-EXTRACT             
E42                                            (WSA-SUB).                       
E42   *                                                                         
E42        MOVE GD90AR-PREMIUM-ADJUST (WSA-SUB)                                 
E42                                        TO  PREMIUM-ADJUST                   
E42                                        OF  MEMBER-BENEFIT                   
E42                                        OF  BILL-MEMADJ2-EXTRACT             
E42                                            (WSA-SUB).                       
E42    6660-DO-BENEFITS-EXIT.                                                   
E42        EXIT.                                                                
E42                                                                             
E42    9100-WRITE-XTRACT.                                                       
E42   ******************************************************************        
E42   *    WRITE OUT THE XTRACT                                                 
E42   ******************************************************************        
E42        CALL 'DLSWRITE'              USING  WRITE-XTR-DDNAME                 
E42                                            WRITE-XTR-RET                    
E42                                            BILL-EXTRACT-RECORD              
E42                                            WRITE-XTR-REC                    
E42                                            WRITE-XTR-BLK                    
E42                                            WRITE-XTR-FMT                    
E42                                            WRITE-XTR-CNT.                   
E42        ADD 1                           TO  RECORD-COUNT                     
E42                                        OF  BILL-CONTROL-EXTRACT.            
E42    9100-WRITE-XTRACT-EXIT.                                                  
E42        EXIT.                                                                
E42                                                                             
E42    9200-CONVERT-DATE.                                                       
E42   ******************************************************************        
E42   *    Convert the date from ALIS to YYYYMMDD format                        
E42   ******************************************************************        
E42        MOVE  '2B2E'                 TO  VDATE-REQUEST-AREA.                 
E42        MOVE WSA-ALIS-WORK-DATE      TO  VDATE-ALIS-DATE1.                   
E42        CALL GC2DATE               USING GAC-DATE-PARMS.                     
E42   ******************************************************************        
E42   *    If not really a valid date, set to spaces                            
E42   ******************************************************************        
E42        IF  VDATE-RET-FAIL OR VDATE1-YYYYMMDD = WSA-LOW-DATE                 
E42            MOVE SPACES              TO  WSA-WORK-DATE                       
E42        ELSE                                                                 
E42            MOVE VDATE1-YYYYMMDD     TO  WSA-WORK-DATE.                      
E42    9200-CONVERT-DATE-EXIT.                                                  
E42        EXIT.                                                                
