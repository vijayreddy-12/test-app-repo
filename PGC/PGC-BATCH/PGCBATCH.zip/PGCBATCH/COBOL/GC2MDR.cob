       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2MDR.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *AUTHOR.   J. SASSO.                                                      
      *****************************************************************         
      *                                                                         
      *=================================================================        
      * SOURCE CODE FOR THIS PROGRAM LIVES IN LIBRARY TYPE CIII24               
      *=================================================================        
      *                                                                         
      * DESCRIPTION:                                                            
      *     THIS MODULE IS TO GENERATE AN EXTRACT WITH ALL                      
      *     GROUPS THAT HAVE AN EFFECTIVE DATE EQUAL                            
      *     OR GREATER THAN DECEMBER 1, 2000                                    
      *                                                                         
      *     AND GROUP/ACCOUNTS WITH ACCOUNT STATUS OF                           
      *     INFORCE (00), CLAIMS SUSPEND(01), OR TERMINATED ACCOUNT             
      *     STATUS AND SALES CREDITS OR COMMISSION REVERSAL ENTRIES             
      *     PROCESSED ON THE COMMISSION DATABASE WITHIN REPORTING               
      *     PERIOD.  IT EXCLUDES GROUP/ACCOUNTS WITH DUMMY PRODUCER             
      *     CODES AND GROUP/ACCOUNTS CONTRACTED THROUGH A GFO.                  
      *                                                                         
      * HISTORY:                                                                
      *     SEPT.09.2002 - JACQUELINE SASSO                                     
      *                                                                         
      *    JUL/2005  R. KNAUD.                                                  
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)                  
      *                      USE VOGPWRA7 TO READ THE VCM AND                   
      *                      GIPSY MASTER FILES.                                
      *                                                                         
      *    OCT/2008   IBM         - ENTERPRISE COMPILER UPGRADE       *         
      *                                                                         
      *    DEC/2012   LIVINGSTONE - TL 184869                         *         
      *****************************************************************         
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCMDR          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-START.                                                            
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2MDR W-S STARTS HERE **'.                                  
                                                                                
      *-----------------------------------------------------------------        
      *    BILLING NAME                                                         
      *-----------------------------------------------------------------        
       01  NAME-EXPAND-AREA.                                                    
           05  NAME-AND-DEL OCCURS 6 TIMES.                                     
               10  NAMEX               PIC X(30).                               
               10  DEL                 PIC X.                                   
           05  NEX-ERROR               PIC X(3).                                
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GAEDATSR                   PIC X(8)    VALUE 'GAEDATSR'.         
           05  GC2DATE                    PIC X(8)    VALUE 'GC2DATE'.          
           05  STAFF-PROGRAM              PIC X(8)    VALUE 'GAESTAFP'.         
      * VOCOMM VCM/GIPSY                                                        
           05  VOGPWRA7                   PIC X(8)    VALUE 'VOGPWRA7'.         
           05  GWCDUMP                    PIC X(8)    VALUE 'GWCDUMP'.          
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
                                                                                
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
       01  LASTCOMM-PARAMETERS.                                                 
           05  LASTCOMM-YEAR              PIC X(3)    VALUE SPACES.             
           05  FILLER                     PIC X       VALUE SPACES.             
           05  LASTCOMM-DAY               PIC X(3)    VALUE SPACES.             
           05  FILLER                     PIC X(3)    VALUE SPACES.             
                                                                                
       01  WS-WORK-FIELDS.                                                      
           05  WS-GROUP                   PIC 9(7) VALUE ZERO.                  
           05  SUB1                       PIC S9(4) COMP.                       
                                                                                
       01  WS-PARAMETERS.                                                       
           05  WS-CORGRACCT            PIC X.                                   
               88  CORGRACCT-FOUND                    VALUE 'Y'.                
               88  CORGRACCT-NOT-FOUND                VALUE 'N'.                
           05  WS-CORCOMP              PIC X.                                   
               88  CORCOMP-FOUND                      VALUE 'Y'.                
               88  CORCOMP-NOT-FOUND                  VALUE 'N'.                
           05  WS-VERB                 PIC X(16)      VALUE SPACES.             
           05  WS-AGENT                PIC 9(6)       VALUE ZEROES.             
           05  WS-SWITCHES.                                                     
               10  DATE-FOUND          PIC X          VALUE 'N'.                
           05  WS-TOT-COMP-PD-FY       PIC S9(7)V99   VALUE ZEROES.             
           05  WS-TOT-PREM-PD-FY       PIC S9(9)V99   VALUE ZEROES.             
           05  WS-ACCT-NO              PIC X          VALUE SPACES.             
           05  WS-GROUP-NO             PIC X          VALUE SPACES.             
           05  WS-REC-COUNT            PIC S9(9)      VALUE ZEROES.             
                                                                                
       01  WS-FOGL.                                                             
           05  WS-FOGL-SIGN            PIC X          VALUE '+'.                
           05  WS-FOGL-CODE.                                                    
               10  WS-FOGL-BENEFIT     PIC 9(4)       VALUE ZEROES.             
               10  WS-FOGL-REINS       PIC 9(2)       VALUE ZEROES.             
               10  WS-FOGL-FOUR.                                                
                   15  WS-FOGL-GRP-TYPE PIC 9         VALUE ZEROES.             
                   15  WS-FOGL-AGT-TYPE PIC 9         VALUE ZEROES.             
                   15  WS-FOGL-ADMIN    PIC 9         VALUE ZEROES.             
                   15  WS-FOGL-LIVES    PIC 9         VALUE ZEROES.             
                                                                                
       01  WS-SCALE-RATE-TABLE.                                                 
           05  WS-SCALE-RATE-TBL OCCURS 5 TIMES.                                
               10  WS-AGENT-CODE        PIC 9(6)      VALUE ZEROES.             
               10  WS-SCALE             PIC X(6)      VALUE SPACES.             
               10  WS-FLAT-RATE  REDEFINES  WS-SCALE                            
                                        PIC 9(3).99.                            
               10  WS-LTDSCALE          PIC X(6)      VALUE SPACES.             
               10  WS-LTD-FLAT-RATE  REDEFINES WS-LTDSCALE                      
                                        PIC 9(3).99.                            
                                                                                
       01  DATE-FIELDS.                                                         
           05  CURRDATE.                                                        
               10  CURR-YYYY         PIC 9999.                                  
               10  CURR-MMM          PIC XXX.                                   
               10  CURR-DD           PIC 99.                                    
           05  WS-LOW-DATE-ALIS.                                                
               10 LOW-YEAR           PIC S9(3) COMP-3.                          
               10 LOW-DAY            PIC S9(3) COMP-3.                          
           05  WS-HIGH-DATE-ALIS.                                               
               10 HIGH-YEAR          PIC S9(3) COMP-3.                          
               10 HIGH-DAY           PIC S9(3) COMP-3.                          
           05  WS-SEQUENCE.                                                     
               10 SEQ-YEAR1          PIC 9.                                     
               10 SEQ-YEAR23         PIC 99.                                    
               10 SEQ-DAY            PIC S9(3).                                 
                                                                                
       01  WTL-SUB                   PIC S9(4)      VALUE +0   COMP.            
                                                                                
       01  WS-END-BYTE-X             PIC X(1)       VALUE SPACES.               
                                                                                
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH   PIC S9(3)      VALUE +133  COMP-3.         
               10  WTL-MESS-CC       PIC X(1)       VALUE SPACES.               
               10  WTL-MESS-TEXT     PIC X(132)     VALUE SPACES.               
           05  WTL-FLAG              PIC X(1)       VALUE 'B'.                  
           05  WTL-REPLY             PIC X(3)       VALUE 'NO '.                
           05  WTL-REPLY-AREA        PIC X(80)      VALUE SPACES.               
                                                                                
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                 PIC X(80)      VALUE                       
FXXTOK         'GC2MDR - PROGRAM BEING ABNORMALLY TERMINATED        '.          
           05  WTL-2                 PIC X(80)      VALUE                       
FXXTOK         'GC2MDR - PROBLEM WITH PGW.PROD.DATEFILE(0)          '.          
           05  WTL-3                 PIC X(80)      VALUE                       
FXXTOK         'GC2MDR - PROB IN PGW.COMM.PROD.COMMCLOS.DATEFILE(0) '.          
                                                                                
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY OCCURS 3 TIMES.                                
               10  WTL-MESSAGE       PIC X(80).                                 
                                                                                
MAN02 *COPY GDETEXP.                                                            
                                                                                
       01  FDOF-PARMS.                                                          
           05  FDOF-PARM1.                                                      
               10  FDOF-DDNAME       PIC X(7)       VALUE 'VSDSI97'.            
               10  FDOF-ACCTTYPE     PIC X(5)       VALUE 'KEYED'.              
               10  FDOF-RECTYPE      PIC X(1)       VALUE 'V'.                  
               10  FDOF-FUNCTION     PIC X(6)       VALUE 'GETRAN'.             
               10  FDOF-ERRCODE      PIC X(5)       VALUE SPACES.               
               10  FDOF-READCT       PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-WRITECT      PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-UPDATECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-DELETECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-RECLGTH      PIC S9(4)      VALUE +0    COMP.           
           05  FDOF-PARM2.                                                      
               10  FDOF-BRANCH       PIC X(5)       VALUE SPACES.               
                                                                                
       01  FILLER                    PIC X(16)      VALUE                       
           'FDOFFILE STARTS '.                                                  
                                                                                
      *01  FIELD-OFFICE-FILE.                                                   
           COPY FDOFFILE.                                                       
                                                                                
       01  GAESECUR-PROT.                                                       
           COPY GARSECUR.                                                       
      **************************************************************            
      *   COPY BOOK TO BE USED TO PASS PARAMETERS                               
      *   TO SECURITY PROGRAM GAESECUR                                          
      **************************************************************            
           COPY GARSECSP.                                                       
           COPY GARSECPR.                                                       
                                                                                
       01  GARDTCRD.                                                            
           COPY GARDTCRD.                                                       
                                                                                
      *  GFO NAME ACCESS DATA SECTION                                           
      *     *****  END   ******                                                 
      *  MUST INCLUDE GFMACCVS IN LINKCTL                                       
                                                                                
      *  GFMAGENT WORKING STORAGE SECTION                                       
      *                                                                         
       01  GFMAGENT-PARAMETERS.                                                 
           05  GFMAGENT-FUNCTION-CODE       PIC X(6)   VALUE SPACES.            
           05  GFMAGENT-ERROR-CODE          PIC X(6)   VALUE SPACES.            
           05  GFMAGENT-AGENT-KEY.                                              
               10  GFMAGENT-CODE   COMP-3   PIC S9(7)  VALUE +0.                
               10  GFMAGENT-ACCT            PIC X      VALUE SPACES.            
                                                                                
      *  AGENT NAME FILE                                                        
         COPY EAGNFILE.                                                         
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
      * VOCOMM VCM/GIPSY                                                        
           03  FILLER             PIC X(30).                                    
                                                                                
      *                                                                         
       01  HEADER-RECORD.                                                       
           05  O-RECORD             PIC X          VALUE 'H'.                   
           05  O-SOURCE             PIC 99         VALUE 10.                    
           05  O-SEQUENCE.                                                      
               10 O-SEQ-YEAR        PIC 99         VALUE ZEROES.                
               10 O-SEQ-DAY         PIC 9(3)       VALUE ZEROES.                
           05  O-RECORD-LENGTH      PIC 9(3)       VALUE 135.                   
           05  O-RUN-DATE           PIC 9(7)       VALUE ZEROES.                
           05  O-RUN-TIME           PIC 9(7)       VALUE 230000.                
           05  FILLER               PIC X(110)     VALUE SPACES.                
                                                                                
       01  DETAIL-RECORD.                                                       
           05  O-SYS-CODE           PIC 99         VALUE 10.                    
           05  O-GROUP              PIC S9(15)     VALUE ZEROES.                
           05  O-AGENT-CODE         PIC S9(6)      VALUE ZEROES.                
           05  O-BRANCH-CODE        PIC S9(5)      VALUE ZEROES.                
           05  O-LINE-OF-BUSINESS   PIC S9(2)      VALUE ZEROES.                
           05  O-PROD-CODE          PIC 9(10)      VALUE ZEROES.                
           05  O-AGENT-SHARE        PIC S9(3)V99   VALUE ZEROES.                
           05  O-CASE-COUNT         PIC S9(11)     VALUE ZEROES.                
           05  O-PREM-AMT           PIC S9(9)V99   VALUE ZEROES.                
           05  O-PREM-PD-XS         PIC S9(7)V99   VALUE ZEROES.                
           05  O-COMP-AMT           PIC S9(7)V99   VALUE ZEROES.                
           05  O-LTD                PIC X          VALUE 'U'.                   
           05  O-POLICYHOLDER       PIC X(25)      VALUE SPACES.                
           05  FILLER               PIC X(24)      VALUE SPACES.                
                                                                                
      *----------------------------------------------------------------         
      *          DATASERVER RECORDS                                   *         
      *----------------------------------------------------------------         
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE -  RECORD DESCRIPTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGROUP                      '.                                  
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGRACCT                     '.                                  
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCOMP                       '.                                  
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCASECNT                    '.                                  
      * GWCORCASECNT                                                            
CPYNME     COPY GCICASEC.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORAGENT                      '.                                  
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
                                                                                
       01  WS-ENDS.                                                             
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2MDR W-S ENDS HERE   **'.                                  
                                                                                
      ******************************************************************        
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GFMAGENT                     PIC X(8)  VALUE 'GFMAGENT'.         
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2MDR'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
      ******************************************************************        
       000-MAINLINE.                                                            
                                                                                
FXXTOK     DISPLAY 'START OF GC2MDR PROGRAM'.                                   
                                                                                
           INITIALIZE DETAIL-RECORD.                                            
           MOVE ZEROES TO WS-REC-COUNT.                                         
           MOVE ZEROES TO WS-TOT-COMP-PD-FY.                                    
           MOVE ZEROES TO WS-TOT-PREM-PD-FY.                                    
                                                                                
           PERFORM 100-INIT THRU 100-INIT-EXIT.                                 
                                                                                
           MOVE OBTAIN-FIRST TO WS-VERB.                                        
                                                                                
           PERFORM 150-READ-DATE-CARD THRU 150-READ-DATE-CARD-X                 
                   UNTIL DATE-FOUND = 'Y'.                                      
                                                                                
           PERFORM 350-GET-LOW-DATE THRU 350-GET-LOW-DATE-EXIT.                 
                                                                                
           DISPLAY 'HIGH-DATE: ' HIGH-YEAR, '-', HIGH-DAY.                      
           DISPLAY 'LOW-DATE: ' LOW-YEAR, '-', LOW-DAY.                         
           DISPLAY 'CURRDATE: ' CURR-YYYY, '-', CURR-MMM.                       
           DISPLAY 'RUN DATE: ' O-RUN-DATE.                                     
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ NEXT (VCM/GIPSY FILES)                                            
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-READ-NEXT      TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
           PERFORM 200-PROCESS-VCM-GIPSY                                        
              THRU 200-PROCESS-VCM-GIPSY-EXIT                                   
             UNTIL VGWO-RET-CODE NOT = '00'.                                    
                                                                                
           PERFORM 1200-LOAD-HEADER  THRU 1200-LOAD-HEADER-EXIT.                
           PERFORM 1100-WRITE-HEADER THRU 1100-WRITE-HEADER-EXIT.               
                                                                                
           PERFORM 925-WRITE-LRD THRU 925-WRITE-LRD-EXIT.                       
                                                                                
      *--------------------------------------------------------------           
      *   END OF PROGRAM LOGIC                                                  
      *--------------------------------------------------------------           
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-CLOSE-FILES    TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
                                                                                
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  DETAIL-RECORD                                 
                                  ICBM.                                         
                                                                                
FXXTOK     DISPLAY 'END OF GC2MDR PROGRAM'.                                     
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       000-MAINLINE-X.                                                          
           STOP RUN.                                                            
                                                                                
      *--------------------------------------------------------------           
       100-INIT.                                                                
                                                                                
FXXTOK     MOVE 'GC2MDR' TO ICBM-PROGRAM-NAME.                                  
           MOVE LOW-VALUES TO LINKAGE-CONTROL.                                  
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2MDR' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-OPEN-FILES     TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
                                                                                
       100-INIT-EXIT.                                                           
           EXIT.                                                                
                                                                                
      *--------------------------------------------------------------           
       150-READ-DATE-CARD.                                                      
                                                                                
           MOVE 'CARD-DATA-010' TO LOGICAL-RECORD-NAME.                         
                                                                                
           CALL GAEDATSR USING WS-VERB                                          
                               GARDTCRD                                         
                               ICBM.                                            
                                                                                
      ** MOVE VALUE IN DATE CARD TO RUN DATE FOR CALCS                          
           IF NOT LR-STATUS-OK OR LR-NOT-FOUND                                  
              DISPLAY 'STATUS: ' ICBM,                                          
                  '    DATA = ', GARDTCRD                                       
              MOVE +1 TO WTL-SUB                                                
              GO TO 9999-ABANDON-SHIP.                                          
                                                                                
           IF GARDTCRD-IDENTIFIER = 'CURRENT'                                   
              MOVE 'Y' TO DATE-FOUND                                            
              DISPLAY 'MOVING DATES FROM CARD TO VDATES'                        
              MOVE GARDTCRD-JUL-YYY TO HIGH-YEAR                                
              MOVE GARDTCRD-YY      TO O-SEQ-YEAR                               
              MOVE GARDTCRD-JUL-DDD TO HIGH-DAY                                 
                                       O-SEQ-DAY                                
              MOVE GARDTCRD-YYYYMMMDD TO CURRDATE                               
              MOVE GARDTCRD-YEAR4DDD TO O-RUN-DATE                              
           END-IF.                                                              
                                                                                
           MOVE OBTAIN-NEXT TO WS-VERB.                                         
                                                                                
       150-READ-DATE-CARD-X.                                                    
           EXIT.                                                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *--------------------------------------------------------------           
       200-PROCESS-VCM-GIPSY.                                                   
                                                                                
      *--- ALL GROUPS, ALL ACCOUNT STATUSES AND ALL EFFECTIVE DATES             
      *--- COMMISSION REVERSAL ENTRIES PROCESSED ON THE COMMISSION              
      *--- DATABASE WITHIN THE REPORTING PERIOD.                                
                                                                                
      * EXCLUDE THE DUMMY GROUP                                                 
           IF  GGIGROUP-NUMBER = 99999                                          
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
      * EXCLUDE THE 5000 SERIES OF ZURICH ACCOUNTS                              
      *    MOVE GGIGROUP-NUMBER TO WS-GROUP-NO                                  
           MOVE GGIGROUP-NUMBER TO WS-GROUP                                     
           IF WS-GROUP NOT LESS THAN 50000                                      
              AND WS-GROUP LESS THAN 60000                                      
      *    IF WS-GROUP-NO = '5'                                                 
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
           MOVE GGIACCOUNT TO WS-ACCT-NO                                        
           IF  WS-ACCT-NO = '7'                                                 
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
           IF GGIACCOUNT = 'CP'                                                 
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
      * EXCLUDE THE STAFF PLAN ACCOUNTS                                         
REN        IF WS-GROUP  = GGIGROUP-NUMBER                                       
              IF GAESECSP-RESPONSE = 'Y'                                        
                 GO TO 250-PROCESS-NEXT                                         
              ELSE                                                              
                 NEXT SENTENCE                                                  
              END-IF                                                            
           END-IF.                                                              
                                                                                
REN        MOVE GGIGROUP-NUMBER TO WS-GROUP.                                    
           MOVE WS-GROUP        TO GAESECSP-GROUP.                              
                                                                                
           CALL STAFF-PROGRAM USING GAESECUR-PROT.                              
                                                                                
           IF GAESECSP-RESPONSE = 'Y'                                           
      *       DISPLAY 'SKIPPING, GROUP IS A STAFF PLAN GROUP: '                 
      *               GGIGROUP-NUMBER                                           
              GO TO 250-PROCESS-NEXT.                                           
                                                                                
           MOVE GGIGROUP-NUMBER TO GROUP-NUMBER OF GWCORGRACCT.                 
           MOVE GGIACCOUNT      TO GR-ACCOUNT   OF GWCORGRACCT.                 
                                                                                
      *--- LOOKING AT COMMISSION DATABASE                                       
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      *          DISPLAY GGIGROUP-NUMBER '/' GGIACCOUNT                         
      *                    'NOT FOUND ON COMMISSION DB'                         
              GO TO 250-PROCESS-NEXT.                                           
                                                                                
           PERFORM 400-CORCOMP THRU 400-CORCOMP-EXIT.                           
                                                                                
       250-PROCESS-NEXT.                                                        
      * VOCOMM VCM/GIPSY                                                        
           MOVE 'N' TO GAESECSP-RESPONSE.                                       
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       200-PROCESS-VCM-GIPSY-EXIT.                                              
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       350-GET-LOW-DATE.                                                        
                                                                                
           MOVE 'CARD-DATA-011' TO LOGICAL-RECORD-NAME.                         
                                                                                
           CALL GAEDATSR USING OBTAIN-FIRST                                     
                               LASTCOMM-PARAMETERS                              
                               ICBM.                                            
                                                                                
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF NOT LR-STATUS-OK                                               
                 DISPLAY 'DATE FILE STATUS: ' ICBM,                             
                    '    DATA = ', LASTCOMM-PARAMETERS                          
                 MOVE +2 TO WTL-SUB                                             
                 GO TO 9999-ABANDON-SHIP.                                       
                                                                                
      *  MOVE VALUE IN DATE CARD TO LOW DATE FOR CALCS                          
           IF LASTCOMM-YEAR NUMERIC AND                                         
              LASTCOMM-DAY NUMERIC                                              
              MOVE 'Y' TO DATE-FOUND                                            
              DISPLAY 'MOVING LOW DATES FROM CARD TO VDATES'                    
              MOVE LASTCOMM-YEAR TO LOW-YEAR                                    
              MOVE LASTCOMM-DAY  TO LOW-DAY                                     
           END-IF.                                                              
                                                                                
       350-GET-LOW-DATE-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       400-CORCOMP.                                                             
                                                                                
           MOVE 'Y' TO WS-CORCOMP.                                              
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST-MDR                                    
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
              GO TO 400-CORCOMP-EXIT.                                           
                                                                                
           PERFORM 500-CORCOMP THRU 500-CORCOMP-EXIT.                           
                                                                                
       400-CORCOMP-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       500-CORCOMP.                                                             
                                                                                
      *-- CHECK IF THE PROCESS-DATE IS BETWEEN LOW AND HIGH DATES               
                                                                                
           IF  (COMP-PROCESS-DATE >  WS-LOW-DATE-ALIS) AND                      
               (COMP-PROCESS-DATE <= WS-HIGH-DATE-ALIS)                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 500-NEXT-CORCOMP-RECORD.                                   
                                                                                
           IF (AGENT-NUMBER OF GWCORCOMP = '099998')                            
               GO TO 500-NEXT-CORCOMP-RECORD.                                   
                                                                                
      *-- WE WANT COMMISSION                                                    
      *-- PAID                                                                  
      *-- FIRST YEAR                                                            
      *-- COVERAGE LIFE, LTD OR A&S                                             
                                                                                
           IF (COMP-TYPE = 'C')                                                 
           AND (COMP-DISP = 'P')                                                
           AND (COMP-REASON = 'F' OR COMP-REASON = 'A')                         
           AND (COV-TYPE = 'T' OR COV-TYPE = 'L' OR COV-TYPE = 'O')             
              PERFORM 600-COMP-PREM-INFO THRU 600-EXIT                          
           END-IF.                                                              
                                                                                
      *-- GET NEXT CORCOMP RECORD                                               
       500-NEXT-CORCOMP-RECORD.                                                 
                                                                                
      *%   OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT-MDR                                     
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
              GO TO 500-CORCOMP-EXIT.                                           
                                                                                
           GO TO 500-CORCOMP.                                                   
                                                                                
       500-CORCOMP-EXIT.                                                        
           EXIT.                                                                
      *-----------------------------------------------------------------        
       600-COMP-PREM-INFO.                                                      
                                                                                
           IF O-AGENT-CODE NOT EQUAL AGENT-NUMBER OF GWCORCOMP                  
              MOVE AGENT-NUMBER OF GWCORCOMP TO WS-AGENT                        
              PERFORM 630-COMP-AGENT-INFO THRU 630-EXIT                         
           END-IF.                                                              
                                                                                
           ADD +1 TO WS-REC-COUNT.                                              
           MOVE AGENT-NUMBER OF GWCORCOMP TO O-AGENT-CODE.                      
           MOVE AGENT-SPLIT  OF GWCORCOMP TO O-AGENT-SHARE.                     
                                                                                
           PERFORM 625-GET-PROD-CODE THRU 625-GET-PROD-CODE-EXIT.               
                                                                                
           ADD COMP-AMT TO WS-TOT-COMP-PD-FY.                                   
           ADD PREM-AMT TO WS-TOT-PREM-PD-FY.                                   
                                                                                
           PERFORM 675-SETUP-RECORDS THRU 675-EXIT.                             
                                                                                
       600-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       625-GET-PROD-CODE.                                                       
                                                                                
           IF COV-TYPE = 'T'                                                    
              MOVE GGIFOGL-CODE(1) TO WS-FOGL-CODE                              
           END-IF.                                                              
                                                                                
           IF COV-TYPE = 'L'                                                    
              MOVE GGIFOGL-CODE(3) TO WS-FOGL-CODE                              
           END-IF.                                                              
                                                                                
           IF COV-TYPE = 'O'                                                    
              MOVE GGIFOGL-CODE(5) TO WS-FOGL-CODE                              
           END-IF.                                                              
                                                                                
           IF WS-FOGL-GRP-TYPE = 1                                              
              MOVE 1111 TO WS-FOGL-FOUR                                         
           END-IF.                                                              
           IF WS-FOGL-GRP-TYPE = 2                                              
              MOVE 2222 TO WS-FOGL-FOUR                                         
           END-IF.                                                              
           IF WS-FOGL-GRP-TYPE = 3                                              
              MOVE 3222 TO WS-FOGL-FOUR                                         
           END-IF.                                                              
           IF WS-FOGL-GRP-TYPE = 4                                              
              MOVE 4132 TO WS-FOGL-FOUR                                         
           END-IF.                                                              
           IF WS-FOGL-GRP-TYPE = 6 AND WS-FOGL-ADMIN = 2                        
              MOVE 3222 TO WS-FOGL-FOUR                                         
           END-IF.                                                              
                                                                                
       625-GET-PROD-CODE-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       630-COMP-AGENT-INFO.                                                     
                                                                                
           PERFORM 800-GFMAGENT-SETUP-CALL THRU 800-GFMAGENT-EXIT.              
                                                                                
           MOVE ZEROES TO O-CASE-COUNT.                                         
      *%   OBTAIN OWNER WITHIN AGENT-COMP.                                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-PARENT                                      
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-AGENT-COMP                                         
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   OBTAIN NEXT GWCORCASECNT WITHIN AGENT-CASECNT                        
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCASECNT                                     
MAN02                 FCCSPL-GWCORCASECNT                                       
MAN02                 FCCSPL-AGENT-CASECNT                                      
MAN02                 GWCORCASECNT                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
              GO TO 630-EXIT.                                                   
           MOVE AGT-CASE-CNT-AMT TO O-CASE-COUNT.                               
                                                                                
       630-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       675-SETUP-RECORDS.                                                       
                                                                                
           MOVE GROUP-NUMBER OF GWCORCOMP TO  O-GROUP.                          
           MOVE 10                        TO  O-SYS-CODE.                       
           MOVE 00                        TO  O-LINE-OF-BUSINESS.               
           MOVE 'U'                       TO  O-LTD.                            
           MOVE ZEROES                    TO  O-PREM-PD-XS.                     
           ADD  WS-TOT-COMP-PD-FY TO  O-COMP-AMT.                               
           ADD  WS-TOT-PREM-PD-FY TO  O-PREM-AMT.                               
           MOVE WS-FOGL-CODE      TO  O-PROD-CODE.                              
                                                                                
           CALL 'GZNAEXP7' USING GBNBILLING-NAME-ADDRESS                        
                                 NAME-EXPAND-AREA                               
                                 NEX-ERROR.                                     
                                                                                
           MOVE NAMEX(1)                  TO O-POLICYHOLDER.                    
                                                                                
           PERFORM 900-WRITE-DETAIL THRU 900-WRITE-DETAIL-EXIT.                 
                                                                                
       675-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       800-GFMAGENT-SETUP-CALL.                                                 
                                                                                
           MOVE SPACES      TO GFMAGENT-ERROR-CODE.                             
           MOVE 'SETLIM'    TO GFMAGENT-FUNCTION-CODE.                          
           MOVE '0'         TO GFMAGENT-ACCT.                                   
           MOVE WS-AGENT TO GFMAGENT-CODE.                                      
MAN02      CALL 'GFMAGENT'  USING GFMAGENT-FUNCTION-CODE                        
MAN02                             GFMAGENT-ERROR-CODE                           
MAN02                             AGENT-NAME-FILE                               
MAN02                             GFMAGENT-AGENT-KEY.                           
           MOVE 'GETSEQ'    TO GFMAGENT-FUNCTION-CODE.                          
MAN02      CALL 'GFMAGENT'  USING GFMAGENT-FUNCTION-CODE                        
MAN02                             GFMAGENT-ERROR-CODE                           
MAN02                             AGENT-NAME-FILE                               
MAN02                             GFMAGENT-AGENT-KEY.                           
                                                                                
           IF WS-AGENT EQUAL TO AGT-CODE                                        
              MOVE AGT-BRANCH-CODE TO O-BRANCH-CODE                             
           ELSE                                                                 
              DISPLAY ' AGENT ACCESS ERROR FOR: ' O-AGENT-CODE                  
                      ' ERROR CODE IS: ' GFMAGENT-ERROR-CODE.                   
                                                                                
       800-GFMAGENT-EXIT.                                                       
           EXIT.                                                                
      *-----------------------------------------------------------------        
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       850-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       850-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
      *-----------------------------------------------------------------        
       900-WRITE-DETAIL.                                                        
                                                                                
           MOVE 'PRINT-DATA-020' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR     USING  STORE-LR                                    
                                    DETAIL-RECORD                               
                                    ICBM.                                       
      *    DISPLAY DETAIL-RECORD                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                        
           END-IF.                                                              
                                                                                
           INITIALIZE DETAIL-RECORD.                                            
           MOVE ZEROES TO WS-TOT-COMP-PD-FY.                                    
           MOVE ZEROES TO WS-TOT-PREM-PD-FY.                                    
                                                                                
       900-WRITE-DETAIL-EXIT.                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
       925-WRITE-LRD.                                                           
                                                                                
           MOVE HIGH-YEAR TO LASTCOMM-YEAR.                                     
           MOVE HIGH-DAY TO LASTCOMM-DAY.                                       
                                                                                
           MOVE 'PRINT-DATA-022' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR USING STORE-LR                                         
                               LASTCOMM-PARAMETERS                              
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY 'ERROR WRITING LASTCOMM:    ' ICBM                        
           END-IF.                                                              
                                                                                
       925-WRITE-LRD-EXIT.                                                      
           EXIT.                                                                
      *-----------------------------------------------------------------        
       1100-WRITE-HEADER.                                                       
                                                                                
           MOVE 'PRINT-DATA-023' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR     USING  STORE-LR                                    
                                    HEADER-RECORD                               
                                    ICBM.                                       
      *    DISPLAY HEADER-RECORD.                                               
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING HEADER: ' ICBM                         
           END-IF.                                                              
                                                                                
       1100-WRITE-HEADER-EXIT.                                                  
           EXIT.                                                                
      *-----------------------------------------------------------------        
       1200-LOAD-HEADER.                                                        
                                                                                
           MOVE 'H' TO O-RECORD.                                                
           MOVE 10  TO O-SOURCE.                                                
           MOVE 135 TO O-RECORD-LENGTH                                          
           MOVE 230000 TO O-RUN-TIME.                                           
                                                                                
       1200-LOAD-HEADER-EXIT.                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
                                                                                
       9999-ABANDON-SHIP.                                                       
                                                                                
           MOVE WTL-MESSAGE (WTL-SUB)     TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
           MOVE WTL-MESSAGE (+1)          TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
           CALL GWCDUMP USING ICBM                                              
                              GWRDUMP.                                          
                                                                                
      *-----------------------------------------------------------------        
                                                                                
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
      *-----------------------------------------------------------------        
