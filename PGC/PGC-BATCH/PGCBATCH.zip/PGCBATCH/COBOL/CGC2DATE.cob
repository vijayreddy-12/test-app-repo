       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. CGC2DATE.                                                    
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
       FILE-CONTROL.                                                            
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
           EJECT                                                                
       WORKING-STORAGE SECTION.                                                 
       01  CONTROL-TABLE.                                                       
           03 CT-VERSION1-5                 PIC XXX  VALUE '1.5'.               
           03 CT-PROGRAM1-5                 PIC X(8) VALUE 'GC2DATEA'.          
           03 CT-VERSION2-0                 PIC XXX  VALUE '2.0'.               
           03 CT-PROGRAM2-0                 PIC X(8) VALUE 'GC2DAT20'.          
       01  FILLER REDEFINES CONTROL-TABLE.                                      
           03  FILLER OCCURS 2.                                                 
               05 CT-VERSION                PIC XXX.                            
               05 CT-PROGRAM                PIC X(8).                           
       01  MISC.                                                                
           03 MAX-ENTRIES COMP              PIC 99   VALUE 2.                   
           03 I           COMP              PIC 99   VALUE ZERO.                
           03 DYNAMIC-PROGRAM               PIC X(8) VALUE SPACES.              
       01  TO-DAY.                                                              
           03 CICS-TODAY                    PIC S9(7).                          
           03 CICS-BLANK                    PIC X.                              
       LINKAGE SECTION.                                                         
       01  EIBDATE                          PIC S9(7) COMP-3.                   
       01  VAPS-VDATE-PARAMETERS.                                               
           COPY GARDATEP.                                                       
           EJECT                                                                
       PROCEDURE DIVISION USING VAPS-VDATE-PARAMETERS EIBDATE.                  
       0000-MAINLINE.                                                           
           MOVE EIBDATE TO CICS-TODAY.                                          
           MOVE SPACE   TO CICS-BLANK.                                          
           CALL 'GC2DATEA' USING VAPS-VDATE-PARAMETERS TO-DAY.                  
           GOBACK.                                                              
