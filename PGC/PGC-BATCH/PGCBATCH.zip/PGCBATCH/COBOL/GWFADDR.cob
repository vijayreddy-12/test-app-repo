       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.  GWFADDR.                                                    
       AUTHOR.      FORECROSS CORPORATION.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *           SAVE ADDRESS LIST FOR I/O SPLITTER                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------*        
      *               RECORD XXXX1 BEGIN-WORKING-STORAGE               *        
      *----------------------------------------------------------------*        
       01  XXXX1-BEGIN-WORKING-STORAGE.                                         
               10  XXXX1-CONST-1            PIC X(32)                           
FXXTOK                 VALUE '** GWFADDR WORKING STRG BEGINS'.                  
                                                                                
      *----------------------------------------------------------------*        
      *                RECORD XXCPYRGT COPYRIGHT-NOTICE                *        
      *----------------------------------------------------------------*        
       01  XXCPYRGT-COPYRIGHT-NOTICE.                                           
               10  FILLER                  PIC X(32)                            
                       VALUE 'COPYRIGHT 2000-2010   FORECROSS '.                
               10  FILLER                  PIC X(32)                            
                       VALUE 'CORPORATION. ALL RIGHTS RESERVED'.                
                                                                                
       01  W-PARM-CNT  PIC S9(4) COMP VALUE +75.                                
                                                                                
      *----------------------------------------------------------------*        
      *                RECORD XXXX2 END-WORKING-STORAGE                *        
      *----------------------------------------------------------------*        
       01  XXXX2-END-WORKING-STORAGE.                                           
               10  XXXX2-CONST-2            PIC X(32)                           
                       VALUE '** FCCADDR WORKING STRG ENDS'.                    
                                                                                
       LINKAGE SECTION.                                                         
       01  PARM-1            PIC X.                                             
       01  PARM-2            PIC X.                                             
       01  PARM-3            PIC X.                                             
       01  PARM-4            PIC X.                                             
       01  PARM-5            PIC X.                                             
       01  PARM-6            PIC X.                                             
       01  PARM-7            PIC X.                                             
       01  PARM-8            PIC X.                                             
       01  PARM-9            PIC X.                                             
       01  PARM-10           PIC X.                                             
       01  PARM-11           PIC X.                                             
       01  PARM-12           PIC X.                                             
       01  PARM-13           PIC X.                                             
       01  PARM-14           PIC X.                                             
       01  PARM-15           PIC X.                                             
       01  PARM-16           PIC X.                                             
       01  PARM-17           PIC X.                                             
       01  PARM-18           PIC X.                                             
       01  PARM-19           PIC X.                                             
       01  PARM-20           PIC X.                                             
       01  PARM-21           PIC X.                                             
       01  PARM-22           PIC X.                                             
       01  PARM-23           PIC X.                                             
       01  PARM-24           PIC X.                                             
       01  PARM-25           PIC X.                                             
       01  PARM-26           PIC X.                                             
       01  PARM-27           PIC X.                                             
       01  PARM-28           PIC X.                                             
       01  PARM-29           PIC X.                                             
       01  PARM-30           PIC X.                                             
       01  PARM-31           PIC X.                                             
       01  PARM-32           PIC X.                                             
       01  PARM-33           PIC X.                                             
       01  PARM-34           PIC X.                                             
       01  PARM-35           PIC X.                                             
       01  PARM-36           PIC X.                                             
       01  PARM-37           PIC X.                                             
       01  PARM-38           PIC X.                                             
       01  PARM-39           PIC X.                                             
       01  PARM-40           PIC X.                                             
       01  PARM-41           PIC X.                                             
       01  PARM-42           PIC X.                                             
       01  PARM-43           PIC X.                                             
       01  PARM-44           PIC X.                                             
       01  PARM-45           PIC X.                                             
       01  PARM-46           PIC X.                                             
       01  PARM-47           PIC X.                                             
       01  PARM-48           PIC X.                                             
       01  PARM-49           PIC X.                                             
       01  PARM-50           PIC X.                                             
       01  PARM-51           PIC X.                                             
       01  PARM-52           PIC X.                                             
       01  PARM-53           PIC X.                                             
       01  PARM-54           PIC X.                                             
       01  PARM-55           PIC X.                                             
       01  PARM-56           PIC X.                                             
       01  PARM-57           PIC X.                                             
       01  PARM-58           PIC X.                                             
       01  PARM-59           PIC X.                                             
       01  PARM-60           PIC X.                                             
       01  PARM-61           PIC X.                                             
       01  PARM-62           PIC X.                                             
       01  PARM-63           PIC X.                                             
       01  PARM-64           PIC X.                                             
       01  PARM-65           PIC X.                                             
       01  PARM-66           PIC X.                                             
       01  PARM-67           PIC X.                                             
       01  PARM-68           PIC X.                                             
       01  PARM-69           PIC X.                                             
       01  PARM-70           PIC X.                                             
       01  PARM-71           PIC X.                                             
       01  PARM-72           PIC X.                                             
       01  PARM-73           PIC X.                                             
       01  PARM-74           PIC X.                                             
       01  PARM-75           PIC X.                                             
                                                                                
      **********************************                                        
      * THIS NEXT STRUCTURE IS A PART OF FCCSPLCA AND AC99W ALSO.               
      **********************************                                        
       01  PASSED-ADDRESS-AREA.                                                 
             10  PASSED-ADDRESS-COUNT       PIC S9(4) COMP SYNC.                
             10  PASSED-ADDRESS-MATRIX.                                         
               15  PASSED-ADDRESS    OCCURS 0 TO 75 TIMES                       
                                     DEPENDING ON W-PARM-CNT                    
                                            POINTER.                            
                                                                                
       PROCEDURE DIVISION USING PASSED-ADDRESS-AREA                             
                        PARM-1 PARM-2 PARM-3 PARM-4 PARM-5                      
                        PARM-6 PARM-7 PARM-8 PARM-9 PARM-10                     
                        PARM-11 PARM-12 PARM-13 PARM-14 PARM-15                 
                        PARM-16 PARM-17 PARM-18 PARM-19 PARM-20                 
                        PARM-21 PARM-22 PARM-23 PARM-24 PARM-25                 
                        PARM-26 PARM-27 PARM-28 PARM-29 PARM-30                 
                        PARM-31 PARM-32 PARM-33 PARM-34 PARM-35                 
                        PARM-36 PARM-37 PARM-38 PARM-39 PARM-40                 
                        PARM-41 PARM-42 PARM-43 PARM-44 PARM-45                 
                        PARM-46 PARM-47 PARM-48 PARM-49 PARM-50                 
                        PARM-51 PARM-52 PARM-53 PARM-54 PARM-55                 
                        PARM-56 PARM-57 PARM-58 PARM-59 PARM-60                 
                        PARM-61 PARM-62 PARM-63 PARM-64 PARM-65                 
                        PARM-66 PARM-67 PARM-68 PARM-69 PARM-70                 
                        PARM-71 PARM-72 PARM-73 PARM-74 PARM-75.                
                                                                                
           IF PASSED-ADDRESS-COUNT < 11                                         
               MOVE +10 TO W-PARM-CNT                                           
           ELSE                                                                 
               MOVE +75 TO W-PARM-CNT                                           
           END-IF                                                               
           MOVE LOW-VALUES TO PASSED-ADDRESS-MATRIX.                            
                SET PASSED-ADDRESS(1)   TO ADDRESS OF PARM-1                    
           IF PASSED-ADDRESS-COUNT = +01                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(2)   TO ADDRESS OF PARM-2                    
           IF PASSED-ADDRESS-COUNT = +02                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(3)   TO ADDRESS OF PARM-3                    
           IF PASSED-ADDRESS-COUNT = +03                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(4)   TO ADDRESS OF PARM-4                    
           IF PASSED-ADDRESS-COUNT = +04                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(5)   TO ADDRESS OF PARM-5                    
           IF PASSED-ADDRESS-COUNT = +05                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(6)   TO ADDRESS OF PARM-6                    
           IF PASSED-ADDRESS-COUNT = +06                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(7)   TO ADDRESS OF PARM-7                    
           IF PASSED-ADDRESS-COUNT = +07                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(8)   TO ADDRESS OF PARM-8                    
           IF PASSED-ADDRESS-COUNT = +08                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(9)   TO ADDRESS OF PARM-9                    
           IF PASSED-ADDRESS-COUNT = +09                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(10)  TO ADDRESS OF PARM-10                   
           IF PASSED-ADDRESS-COUNT = +10                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(11)  TO ADDRESS OF PARM-11                   
           IF PASSED-ADDRESS-COUNT = +11                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(12)  TO ADDRESS OF PARM-12                   
           IF PASSED-ADDRESS-COUNT = +12                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(13)  TO ADDRESS OF PARM-13                   
           IF PASSED-ADDRESS-COUNT = +13                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(14)  TO ADDRESS OF PARM-14                   
           IF PASSED-ADDRESS-COUNT = +14                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(15)  TO ADDRESS OF PARM-15                   
           IF PASSED-ADDRESS-COUNT = +15                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(16)  TO ADDRESS OF PARM-16                   
           IF PASSED-ADDRESS-COUNT = +16                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(17)  TO ADDRESS OF PARM-17                   
           IF PASSED-ADDRESS-COUNT = +17                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(18)  TO ADDRESS OF PARM-18                   
           IF PASSED-ADDRESS-COUNT = +18                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(19)  TO ADDRESS OF PARM-19                   
           IF PASSED-ADDRESS-COUNT = +19                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(20)  TO ADDRESS OF PARM-20                   
           IF PASSED-ADDRESS-COUNT = +20                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(21)  TO ADDRESS OF PARM-21                   
           IF PASSED-ADDRESS-COUNT = +21                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(22)  TO ADDRESS OF PARM-22                   
           IF PASSED-ADDRESS-COUNT = +22                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(23)  TO ADDRESS OF PARM-23                   
           IF PASSED-ADDRESS-COUNT = +23                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(24)  TO ADDRESS OF PARM-24                   
           IF PASSED-ADDRESS-COUNT = +24                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(25)  TO ADDRESS OF PARM-25                   
           IF PASSED-ADDRESS-COUNT = +25                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(26)  TO ADDRESS OF PARM-26                   
           IF PASSED-ADDRESS-COUNT = +26                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(27)  TO ADDRESS OF PARM-27                   
           IF PASSED-ADDRESS-COUNT = +27                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(28)  TO ADDRESS OF PARM-28                   
           IF PASSED-ADDRESS-COUNT = +28                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(29)  TO ADDRESS OF PARM-29                   
           IF PASSED-ADDRESS-COUNT = +29                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(30)  TO ADDRESS OF PARM-30                   
           IF PASSED-ADDRESS-COUNT = +30                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(31)  TO ADDRESS OF PARM-31                   
           IF PASSED-ADDRESS-COUNT = +31                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(32)  TO ADDRESS OF PARM-32                   
           IF PASSED-ADDRESS-COUNT = +32                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(33)  TO ADDRESS OF PARM-33                   
           IF PASSED-ADDRESS-COUNT = +33                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(34)  TO ADDRESS OF PARM-34                   
           IF PASSED-ADDRESS-COUNT = +34                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(35)  TO ADDRESS OF PARM-35                   
           IF PASSED-ADDRESS-COUNT = +35                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(36)  TO ADDRESS OF PARM-36                   
           IF PASSED-ADDRESS-COUNT = +36                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(37)  TO ADDRESS OF PARM-37                   
           IF PASSED-ADDRESS-COUNT = +37                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(38)  TO ADDRESS OF PARM-38                   
           IF PASSED-ADDRESS-COUNT = +38                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(39)  TO ADDRESS OF PARM-39                   
           IF PASSED-ADDRESS-COUNT = +39                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(40)  TO ADDRESS OF PARM-40                   
           IF PASSED-ADDRESS-COUNT = +40                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(41)  TO ADDRESS OF PARM-41                   
           IF PASSED-ADDRESS-COUNT = +41                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(42)  TO ADDRESS OF PARM-42                   
           IF PASSED-ADDRESS-COUNT = +42                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(43)  TO ADDRESS OF PARM-43                   
           IF PASSED-ADDRESS-COUNT = +43                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(44)  TO ADDRESS OF PARM-44                   
           IF PASSED-ADDRESS-COUNT = +44                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(45)  TO ADDRESS OF PARM-45                   
           IF PASSED-ADDRESS-COUNT = +45                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(46)  TO ADDRESS OF PARM-46                   
           IF PASSED-ADDRESS-COUNT = +46                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(47)  TO ADDRESS OF PARM-47                   
           IF PASSED-ADDRESS-COUNT = +47                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(48)  TO ADDRESS OF PARM-48                   
           IF PASSED-ADDRESS-COUNT = +48                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(49)  TO ADDRESS OF PARM-49                   
           IF PASSED-ADDRESS-COUNT = +49                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(50)  TO ADDRESS OF PARM-50                   
           IF PASSED-ADDRESS-COUNT = +50                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(51)  TO ADDRESS OF PARM-51                   
           IF PASSED-ADDRESS-COUNT = +51                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(52)  TO ADDRESS OF PARM-52                   
           IF PASSED-ADDRESS-COUNT = +52                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(53)  TO ADDRESS OF PARM-53                   
           IF PASSED-ADDRESS-COUNT = +53                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(54)  TO ADDRESS OF PARM-54                   
           IF PASSED-ADDRESS-COUNT = +54                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(55)  TO ADDRESS OF PARM-55                   
           IF PASSED-ADDRESS-COUNT = +55                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(56)  TO ADDRESS OF PARM-56                   
           IF PASSED-ADDRESS-COUNT = +56                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(57)  TO ADDRESS OF PARM-57                   
           IF PASSED-ADDRESS-COUNT = +57                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(58)  TO ADDRESS OF PARM-58                   
           IF PASSED-ADDRESS-COUNT = +58                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(59)  TO ADDRESS OF PARM-59                   
           IF PASSED-ADDRESS-COUNT = +59                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(60)  TO ADDRESS OF PARM-60                   
           IF PASSED-ADDRESS-COUNT = +60                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(61)  TO ADDRESS OF PARM-61                   
           IF PASSED-ADDRESS-COUNT = +61                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(62)  TO ADDRESS OF PARM-62                   
           IF PASSED-ADDRESS-COUNT = +62                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(63)  TO ADDRESS OF PARM-63                   
           IF PASSED-ADDRESS-COUNT = +63                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(64)  TO ADDRESS OF PARM-64                   
           IF PASSED-ADDRESS-COUNT = +64                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(65)  TO ADDRESS OF PARM-65                   
           IF PASSED-ADDRESS-COUNT = +65                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(66)  TO ADDRESS OF PARM-66                   
           IF PASSED-ADDRESS-COUNT = +66                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(67)  TO ADDRESS OF PARM-67                   
           IF PASSED-ADDRESS-COUNT = +67                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(68)  TO ADDRESS OF PARM-68                   
           IF PASSED-ADDRESS-COUNT = +68                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(69)  TO ADDRESS OF PARM-69                   
           IF PASSED-ADDRESS-COUNT = +69                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(70)  TO ADDRESS OF PARM-70                   
           IF PASSED-ADDRESS-COUNT = +70                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(71)  TO ADDRESS OF PARM-71                   
           IF PASSED-ADDRESS-COUNT = +71                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(72)  TO ADDRESS OF PARM-72                   
           IF PASSED-ADDRESS-COUNT = +72                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(73)  TO ADDRESS OF PARM-73                   
           IF PASSED-ADDRESS-COUNT = +73                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(74)  TO ADDRESS OF PARM-74                   
           IF PASSED-ADDRESS-COUNT = +74                                        
                                         GO TO 900-GOBACK.                      
                SET PASSED-ADDRESS(75)  TO ADDRESS OF PARM-75.                  
                                                                                
       900-GOBACK.                                                              
                                                                                
           GOBACK.                                                              
                                                                                
