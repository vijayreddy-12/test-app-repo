       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
                                                                                
       PROGRAM-ID.  GPRTRAN1.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
                                                                                
      *REMARKS.  THE FUNCTION OF THIS MODULE IS TO PROVIDE AN                   
      *          INTERFACE BETWEEN GPRINTAL + GSPTRAN1, IT'S                    
      *          ONLY PURPOSE IS TO CONTROL THE READING OF                      
      *          THE GIPSY TRANSACTION RECORDS AND PASS THEM TO                 
      *          GSPTRAN1 WHICH DOES NOT HAVE ANY READING ABILITY               
      *          AS IT IS ALSO CALLED BY GSPLIRT WHERE ALL RECORDS              
      *          ARE PASSED TO IT FROM THE MAINLINE.                            
      * DATE CHANGED                                                            
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
                                                                                
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       77  FIRST-REC-TYPE                          PIC X.                       
       77  FLAG-B                  VALUE 'B'       PIC X.                       
       77  BILLING-IND             VALUE '1'       PIC X.                       
                                                                                
      * THIS ROUTINE USES GSPPRTPM                                              
       01  PRINT-PARAMETERS.                                                    
                  COPY GSPPRTPM REPLACING                                       
                                    ==01  PRINT-PARAMETERS.== BY ====.          
                                                                                
       01  PRT.                                                                 
           05  FILLER                              PIC X(34)                    
               VALUE '1END OF GIPSY TRANSACTION REGISTER'.                      
           05  FILLER  VALUE SPACE                 PIC X(99).                   
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  TRANSREG-RECORD.                                                     
           05  FILLER                              PIC X(4).                    
           05  TR-RECTYP1                          PIC X.                       
           05  FILLER                              PIC X(4477).                 
       01  MISC-AREA.                                                           
           05  LOW-HI-DATES.                                                    
               10  LO-DATE                         PIC X(4).                    
               10  HI-DATE                         PIC X(4).                    
       01  TAPE-PARAMETERS.                                                     
           03  TAPE-SYS011                         PIC X(6).                    
           03  TAPE-SYS014                         PIC X(6).                    
           03  TAPE-RETURN                  COMP-3 PIC S9.                      
           03  TAPE-RSIZ11                         PIC 9(5).                    
           03  TAPE-RSIZ14                         PIC 9(5).                    
           03  TAPE-BSIZ11                         PIC 9(5).                    
           03  TAPE-BSIZ14                         PIC 9(5).                    
           03  TAPE-FRMT11                         PIC XX.                      
           03  TAPE-FRMT14                         PIC XX.                      
           03  TAPE-CNTR11                  COMP-3 PIC S9(7).                   
           03  TAPE-CNTR14                  COMP-3 PIC S9(7).                   
       01  REPORT-ACCUMULATORS.                                                 
         COPY  GPRACCUM           REPLACING                                     
                                            ==01  GPRACCUM.== BY ====.          
                                                                                
       PROCEDURE DIVISION USING TRANSREG-RECORD                                 
                                MISC-AREA                                       
                                TAPE-PARAMETERS                                 
                                REPORT-ACCUMULATORS.                            
      ******************************************************************        
      *    READ THE TRANSACTION REGISTERS, CALLING GSPTRAN1 FOR EACH ONE        
      *    AT END OF FILE, ACCUMULATE THE NO. OF PAGES WRITTEN TO REPORT        
      *    PRINT 'END OF GIPSY TRANSACTION REGISTER' ON THE REPORT AND          
      *    CLOSE THE PRINT FILE.                                                
      ******************************************************************        
                                                                                
      ******************************************************************        
      * SYS010 UNIT USED FOR MFICHE COPY OF MONTHLY TRANS REGISTER              
      ******************************************************************        
           MOVE 'SYS010' TO PRINT-SYS022.                                       
           MOVE TR-RECTYP1 TO FIRST-REC-TYPE.                                   
       PASSING-LOOP.                                                            
           CALL 'GSPTRAN1' USING LOW-HI-DATES                                   
                                 TRANSREG-RECORD                                
                                 PRINT-PARAMETERS                               
                                 BILLING-IND.                                   
           MOVE SPACES TO TRANSREG-RECORD                                       
           CALL 'DLSREAD' USING  TAPE-SYS014      TAPE-RETURN                   
                                 TRANSREG-RECORD  TAPE-RSIZ14                   
                                 TAPE-BSIZ14      TAPE-FRMT14                   
                                 TAPE-CNTR14.                                   
           IF  TAPE-RETURN NOT = +0                                             
           OR  TR-RECTYP1 NOT = FIRST-REC-TYPE                                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO PASSING-LOOP.                                              
           ADD PAGE-CTR22 +2 TO ACCUM-TRANREG.                                  
           PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT.                       
           MOVE +4 TO PRINT-RETURN22.                                           
           PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT.                       
           MOVE 'SYS022' TO PRINT-SYS022.                                       
           GOBACK.                                                              
                                                                                
      ******************************************************************        
      *    THIS ROUTINE IS CALLED FIRST TO WRITE THE 'END OF GIPSY REG.         
      *    LINE ON THE  REPORT, THEN A SECOND TIME TO CLOSE THE FILE.           
      ******************************************************************        
       CALL-DLSWRITE.                                                           
           CALL 'DLSWRITE' USING PRINT-SYS022   PRINT-RETURN22                  
                                 PRT            PRINT-RECSIZE                   
                                 PRINT-BLKSIZE  PRINT-FORMATT                   
                                 PRINT-COUNTER22.                               
       CALL-DLSWRITE-EXIT.                                                      
           EXIT.                                                                
