                                                                                
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2LCOMM.                                                 
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *DATE-WRITTEN.  APR 1992.                                                 
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *                                                                         
      *  - BATCH INTERFACE FOR ACCESSING COMMISSION SCALE VSAM TABLES.          
      *  - RETRIEVES A SINGLE SCALE RECORD BASED ON PARMS RECEIVED.             
      *  - UPDATES VSAM TABLE WITH NEW ENTRY OF COMMISSION SCALE.               
      *  - THERE IS A SIMILAR IDMS ONLINE PROGRAM GCSLDATS.                     
      *                                                                         
      ******************************************************************        
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GCSLCOMM          
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(24)      VALUE                       
FXXTOK     'GC2LCOMM WS STARTS HERE*'.                                          
                                                                                
       01  WS-CURR-KEY.                                                         
           05  WS-CURR-NAME          PIC X(8)       VALUE SPACES.               
           05  WS-CURR-SCALE-CODE    PIC X(3)       VALUE SPACES.               
           05  WS-CURR-START-YEAR    PIC 9(3)       VALUE ZEROES.               
           05  FILLER                PIC X(11)      VALUE LOW-VALUES.           
                                                                                
       01  WS-ZPARDUMP-FUNCTION      PIC X(1)       VALUE '1'.                  
       01  WS-GTABCOMM-NAME          PIC X(8)       VALUE 'COMMSCAL'.           
       01  WS-CURR-TIME              PIC 9(6)       VALUE ZEROES.               
       01  WS-SYSTEM-DATE            PIC X(8)       VALUE SPACES.               
       01  WS-SYSTEM-TIME.                                                      
           05 WS-SYSTEM-HHMMSS       PIC 9(6)       VALUE ZEROES.               
           05 FILLER                 PIC 9(2)       VALUE ZEROES.               
       01  QDATE-BA                  PIC X(2)       VALUE 'BA'.                 
                                                                                
       01  WS-HIGH-DATE.                                                        
           05  WS-HIGH-YEAR          PIC 9(3)       VALUE 999.                  
                                                                                
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH   PIC S9(3)      VALUE +133  COMP-3.         
               10  WTL-MESS-CC       PIC X(1)       VALUE SPACES.               
               10  WTL-MESS-TEXT     PIC X(132)     VALUE SPACES.               
           05  WTL-FLAG              PIC X(1)       VALUE 'B'.                  
           05  WTL-REPLY             PIC X(3)       VALUE 'NO '.                
           05  WTL-REPLY-AREA        PIC X(80)      VALUE SPACES.               
                                                                                
       01  ERROR-MESSAGE-LIST.                                                  
           05  ERR-1                 PIC X(80)      VALUE                       
FXXTOK         ' *** GC2LCOMM ABENDED'.                                         
           05  ERR-2.                                                           
               10  FILLER            PIC X(5)       VALUE ' *** '.              
               10  ERR-2-DDNAME      PIC X(7)       VALUE SPACES.               
               10  FILLER            PIC X(8)       VALUE ' ERROR. '.           
               10  ERR-2-FUNCTION    PIC X(6)       VALUE SPACES.               
               10  FILLER            PIC X(10)      VALUE ' RETURN = '.         
               10  ERR-2-RET-CODE    PIC X(5)       VALUE SPACES.               
               10  FILLER            PIC X(7)       VALUE ' KEY = '.            
               10  ERR-2-KEY         PIC X(25)      VALUE SPACES.               
               10  FILLER            PIC X(7)       VALUE SPACES.               
                                                                                
       01  ERROR-MESSAGE-TABLE REDEFINES ERROR-MESSAGE-LIST.                    
           05  ERROR-MESSAGE-ENTRY OCCURS 2 TIMES.                              
               10  ERROR-MESSAGE     PIC X(80).                                 
                                                                                
      ******************************************************************        
      *    VSAM DDNAME IS 'VSDSI50' FOR RETRIEVAL                               
      *               AND 'VSDSO50' FOR ADD CALLS.                              
      *    VSAM ACCTYPE IS 'KEYED' FOR SETLIM AND GETRAN                        
      *               AND 'ENTRY' FOR ADDSEQ                                    
      ******************************************************************        
       01  VSAM-RATE-PARAMETERS.                                                
           05  VSAM-RATE-PARM1.                                                 
               10  VSAM-RATE-DDNAME  PIC X(7)       VALUE 'VSDSI50'.            
               10  VSAM-RATE-ACCTYPE PIC X(5)       VALUE 'KEYED'.              
               10  VSAM-RATE-RECTYPE PIC X(1)       VALUE 'V'.                  
               10  VSAM-RATE-FUNC    PIC X(6)       VALUE SPACES.               
               10  VSAM-RATE-ERROR   PIC X(5)       VALUE SPACES.               
                   88  VSAM-RATE-NOT-FOUND          VALUE 'R0804'.              
               10  VSAM-RATE-READ-CT PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-WRT-CT  PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-UPD-CT  PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-DEL-CT  PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-RECLEN  PIC S9(4)      VALUE +0   COMP.            
           05  VSAM-RATE-PARM2.                                                 
               10  VSAM-RATE-KEY     PIC X(25)      VALUE LOW-VALUES.           
                                                                                
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
       01  WS-END                    PIC X(24)      VALUE                       
FXXTOK     'GC2LCOMM WS ENDS   HERE*'.                                          
       01  WS-END-BYTE-X             PIC X(1)       VALUE '*'.                  
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE '        '   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
                                                                                
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  QDATEQ2                 PIC X(8)       VALUE 'QDATEQ2'.          
           05  GWCDUMP                 PIC X(8)       VALUE 'GWCDUMP'.          
           05  GC2DATE                 PIC X(8)       VALUE 'GC2DATE'.          
           05  ZCURRDAT                PIC X(8)       VALUE 'ZCURRDAT'.         
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
      *01  GCSLPARM.                                                            
           COPY GCSLPARM.                                                       
       01  GTABCOMM-RECORD.                                                     
           COPY GTABCOMM.                                                       
                                                                                
       PROCEDURE DIVISION USING GCSLPARM                                        
                                GTABCOMM-RECORD.                                
                                                                                
       0000-GCSLCOMM.                                                           
      ******************************************************************        
      *    INIT RETURN AREA.                                                    
      *    IF LAST CALL - CLOSE FILE AND EXIT.                                  
      *    BUILD KEY USING CALLING PROGRAM PARMS.                               
      *    READ SCALE VSAM FILE FOR RETRIEVAL.                                  
      *    ADD SCALE RECORD FOR ADD CALL.                                       
      ******************************************************************        
           MOVE '0'                 TO GCSL-RET-CODE.                           
      *                                                                         
           IF  GCSL-LAST-CALL                                                   
               MOVE 'CLOFIL'        TO VSAM-RATE-FUNC                           
               PERFORM 9000-READ-VSAM-RECORD THRU                               
                       9000-READ-VSAM-RECORD-EXIT                               
               GO TO 0000-GCSLCOMM-EXIT.                                        
      *                                                                         
           PERFORM 1000-BUILD-CURR-KEY THRU                                     
                   1000-BUILD-CURR-KEY-EXIT.                                    
      *                                                                         
           IF  GCSL-RETRIEVE-CALL                                               
               PERFORM 2000-FIND-TABLE THRU                                     
                       2000-FIND-TABLE-EXIT                                     
               IF  NOT GCSL-RET-SUCCESS                                         
                   GO TO 0000-GCSLCOMM-EXIT.                                    
      *                                                                         
           IF  GCSL-ADD-CALL                                                    
               PERFORM 3000-ADD-RECORD THRU                                     
                       3000-ADD-RECORD-EXIT                                     
               IF  NOT GCSL-RET-SUCCESS                                         
                   GO TO 0000-GCSLCOMM-EXIT.                                    
      *                                                                         
                                                                                
       0000-GCSLCOMM-EXIT.                                                      
           GOBACK.                                                              
                                                                                
       1000-BUILD-CURR-KEY.                                                     
      ******************************************************************        
      *    BUILD VSAM KEY USING PARMS PASSED.                                   
      *    THE START YEAR IN THE KEY IS STORED AS A COMPLIMENT OF 999           
      *      EG.  IF START YEAR IS 3, THE START YEAR IN THE KEY IS              
      *             STORED AS 999 - 3 = 996                                     
      ******************************************************************        
           MOVE LOW-VALUES           TO WS-CURR-KEY.                            
           MOVE WS-GTABCOMM-NAME     TO WS-CURR-NAME.                           
           MOVE GCSL-SCALE-CODE      TO WS-CURR-SCALE-CODE.                     
           MOVE GCSL-START-YEAR      TO WS-CURR-START-YEAR.                     
                                                                                
      *                                                                         
      *    COMPUTE CURRENT KEY                                                  
      *                                                                         
           COMPUTE  WS-CURR-START-YEAR =                                        
                              WS-HIGH-YEAR - WS-CURR-START-YEAR.                
                                                                                
       1000-BUILD-CURR-KEY-EXIT.                                                
           EXIT.                                                                
                                                                                
       2000-FIND-TABLE.                                                         
      ******************************************************************        
      *    SET VSAM POINTER AT CURRENT KEY RECORD.                              
      *    RETRIEVE CURRENT VSAM POSITION RECORD.                               
      ******************************************************************        
      *                                                                         
           MOVE 'VSDSI50'    TO  VSAM-RATE-DDNAME.                              
           MOVE WS-CURR-KEY             TO VSAM-RATE-PARM2.                     
      *                                                                         
           MOVE 'KEYED'      TO  VSAM-RATE-ACCTYPE.                             
           MOVE 'SETLIM'                TO VSAM-RATE-FUNC.                      
           PERFORM 9000-READ-VSAM-RECORD THRU                                   
                   9000-READ-VSAM-RECORD-EXIT.                                  
           IF  VSAM-RATE-NOT-FOUND                                              
               MOVE '1'                 TO GCSL-RET-CODE                        
               GO TO 2000-FIND-TABLE-EXIT.                                      
           IF  VSAM-RATE-ERROR NOT = LOW-VALUES                                 
               MOVE '1'                 TO GCSL-RET-CODE                        
               GO TO 9999-ABANDON-SHIP.                                         
      *                                                                         
           MOVE 'GETSEQ'                TO VSAM-RATE-FUNC.                      
           PERFORM 9000-READ-VSAM-RECORD THRU                                   
                   9000-READ-VSAM-RECORD-EXIT.                                  
           IF  VSAM-RATE-ERROR NOT = LOW-VALUES                                 
               MOVE '1'                 TO GCSL-RET-CODE                        
               GO TO 9999-ABANDON-SHIP.                                         
           IF  GTABCOMM-NAME  NOT = WS-GTABCOMM-NAME OR                         
               GTABCOMM-SCALE  NOT = WS-CURR-SCALE-CODE                         
               MOVE '1'                 TO GCSL-RET-CODE                        
               GO TO 2000-FIND-TABLE-EXIT.                                      
                                                                                
           IF  GTABCOMM-POLICY-YEAR LESS THAN WS-CURR-START-YEAR                
               MOVE '1'                 TO GCSL-RET-CODE                        
               GO TO 2000-FIND-TABLE-EXIT.                                      
      *                                                                         
       2000-FIND-TABLE-EXIT.                                                    
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *    SET VSAM POINTER TO NEAREST POSITION WHERE THE NEW RECORD IS         
      *        ADDED                                                            
      *    ADD RECORD                                                           
      ******************************************************************        
       3000-ADD-RECORD.                                                         
                                                                                
           MOVE 'VSDSO50'    TO  VSAM-RATE-DDNAME.                              
           MOVE WS-CURR-KEY      TO  GTABCOMM-KEY                               
                                    VSAM-RATE-PARM2.                            
      *                                                                         
           MOVE 'SETLIM'  TO  VSAM-RATE-FUNC.                                   
           MOVE 'KEYED'      TO  VSAM-RATE-ACCTYPE.                             
           PERFORM 9000-READ-VSAM-RECORD THRU                                   
                   9000-READ-VSAM-RECORD-EXIT.                                  
      *                                                                         
           IF  VSAM-RATE-NOT-FOUND                                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  VSAM-RATE-ERROR NOT = LOW-VALUES                             
                   MOVE '1'                 TO GCSL-RET-CODE                    
                   GO TO 9999-ABANDON-SHIP.                                     
                                                                                
           COMPUTE VSAM-RATE-RECLEN =  150 +                                    
                                       (GTABCOMM-BAND-CNT * 16).                
           MOVE WS-CURR-KEY      TO  GTABCOMM-KEY                               
                                    VSAM-RATE-PARM2.                            
           MOVE SPACES       TO  GTABCOMM-AUDIT-DATA.                           
           PERFORM 3100-SET-DATE-TIME  THRU                                     
                   3100-SET-DATE-TIME-EXIT.                                     
      *                                                                         
           MOVE 'ENTRY'      TO  VSAM-RATE-ACCTYPE.                             
           MOVE 'ADDSEQ'  TO  VSAM-RATE-FUNC.                                   
FXXTOK     MOVE 'GC2LCOMM'   TO  GTABCOMM-USERID.                               
                                                                                
           PERFORM 9000-READ-VSAM-RECORD THRU                                   
                   9000-READ-VSAM-RECORD-EXIT.                                  
      *                                                                         
           IF  VSAM-RATE-ERROR NOT = LOW-VALUES                                 
               MOVE '1'                 TO GCSL-RET-CODE                        
               GO TO 3000-ADD-RECORD-EXIT.                                      
                                                                                
       3000-ADD-RECORD-EXIT.                                                    
           EXIT.                                                                
       3100-SET-DATE-TIME.                                                      
      ****************************************************************          
      * BECAUSE OF LIMITATIONS OF ZCURRDAT AND GC2DATE,                         
      *    CALL ZCURRDAT TO GET THE SYSTEM DATE IN DD/MM/YY FORMAT,             
      *    CALL QDATE TO CONVERT TO YYY/DDD FORMAT                              
      *    CALL GC2DATE TO CONVERT YYY/DDD TO DDMMMYY AND YYYYMMDD              
      ****************************************************************          
           CALL ZCURRDAT                 USING WS-SYSTEM-DATE.                  
MAN02      CALL QDATEQ2                  USING QDATE-BA                         
MAN02                                          WS-SYSTEM-DATE                   
MAN02                                          VDATE-ALIS-DATE1.                
           MOVE '2'                         TO VDATE-REQ-SERVICE.               
           MOVE 'B'                         TO VDATE-REQ-BASIS.                 
           MOVE '2'                         TO VDATE-REQ-DETAIL.                
           MOVE 'E'                         TO VDATE-REQ-LANGUAGE               
           CALL  GC2DATE                 USING GAC-DATE-PARAMETERS.             
           MOVE VDATE1-YYYY     TO       GTABCOMM-DATE-STAMP-Y.                 
           MOVE VDATE1-MM       TO       GTABCOMM-DATE-STAMP-M.                 
           MOVE VDATE1-DD       TO       GTABCOMM-DATE-STAMP-D.                 
                                                                                
           ACCEPT WS-SYSTEM-TIME  FROM   TIME.                                  
           MOVE WS-SYSTEM-HHMMSS  TO     GTABCOMM-TIME-STAMP.                   
                                                                                
       3100-SET-DATE-TIME-EXIT.                                                 
           EXIT.                                                                
                                                                                
       9000-READ-VSAM-RECORD.                                                   
           CALL 'ZACCVSAM' USING VSAM-RATE-PARM1                                
                                 VSAM-RATE-PARM2                                
                                 GTABCOMM-RECORD.                               
       9000-READ-VSAM-RECORD-EXIT.                                              
           EXIT.                                                                
                                                                                
       9999-ABANDON-SHIP.                                                       
           MOVE VSAM-RATE-DDNAME          TO ERR-2-DDNAME.                      
           MOVE VSAM-RATE-FUNC            TO ERR-2-FUNCTION.                    
           MOVE VSAM-RATE-ERROR           TO ERR-2-RET-CODE.                    
           MOVE VSAM-RATE-KEY             TO ERR-2-KEY.                         
                                                                                
           MOVE ERROR-MESSAGE (+1)        TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
           MOVE ERROR-MESSAGE (+2)        TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
                                                                                
           CALL GWCDUMP USING ICBM                                              
                              GWRDUMP.                                          
