       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2AGT.                                                   
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION                              
      *%****************************************************************        
      *%  DATE 11/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *AUTHOR.        J. SASSO.                                                 
      *-----------------------------------------------------------------        
      *                                                                         
      * CLONED FROM  T25666                                                     
      *                                                                         
      *-----------------------------------------------------------------        
      *                                                                         
      *    JUL/2005  R. KNAUD.                                                  
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)                  
      *                      USE VOGPWRA7 TO READ THE VCM AND                   
      *                      GIPSY MASTER FILES.                                
      *                                                                         
      *    OCT/2008  IBM GR                                                     
      *         - UPGRADED IN ENTERPRISE COMPILER UPGARDE                       
      *                                                                         
      *-----------------------------------------------------------------        
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2AGT W-S STARTS HERE **'.                                  
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GAEDATSR                   PIC X(8)    VALUE 'GAEDATSR'.         
           05  GC2DATE                    PIC X(8)    VALUE 'GC2DATE'.          
      * VOCOMM VCM/GIPSY                                                        
           05  VOGPWRA7                   PIC X(8)    VALUE 'VOGPWRA7'.         
                                                                                
       01  WS-WORK-FIELDS.                                                      
           05  WS-VERB                    PIC X(16)  VALUE SPACES.              
           05  WS-ERR-SW                  PIC X      VALUE 'N'.                 
           05  WS-FIRST-TIME              PIC X      VALUE 'Y'.                 
           05  WS-COMP-DONE               PIC X      VALUE 'N'.                 
           05  WS-GROUP                   PIC S9(5)  COMP-3 VALUE ZERO.         
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
      * VOCOMM VCM/GIPSY                                                        
           03  FILLER                     PIC X(30).                            
                                                                                
      *----------------------------------------------------------------         
      *  PARMS USED FOR DATE CONVERSION                                         
      *----------------------------------------------------------------         
       01  FILLLER                PIC X(32) VALUE                               
             ' **** GC2DATE PARMS ****       '.                                 
       01  GC2DATE-PARMS.                                                       
           COPY GARDATEP.                                                       
      *                                                                         
      *                                                                         
       01  OUTPUT-RECORD.                                                       
REN        05  O-GROUP                PIC X(7)      VALUE ZEROS.                
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-ACCOUNT              PIC X(3)      VALUE ZEROS.                
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-COMP-EFF-DATE        PIC X(9)      VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-COMP-PROCESS-DATE    PIC X(9)      VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-AGENT                PIC X(6)      VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-AGENT-SPLIT          PIC ZZ9.99    VALUE ZEROS.                
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-COMP-REASON          PIC X(2)      VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-COMP-TYPE            PIC X(3)      VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-COMP-DISP            PIC X(4)      VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-RECON-IND            PIC X         VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-COMP-AMOUNT          PIC -ZZZZZZZZ9.99 VALUE ZEROS.            
           05  FILLER                 PIC X          VALUE SPACES.              
           05  O-PREM-AMOUNT          PIC -ZZZZZZZZ9.99 VALUE ZEROS.            
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-GFO                  PIC X(5)      VALUE SPACES.               
           05  FILLER                 PIC X         VALUE SPACES.               
           05  O-GROUP-REP            PIC X(5)      VALUE SPACES.               
           05  FILLER                 PIC X(15)     VALUE SPACES.               
                                                                                
      *----------------------------------------------------------------         
      *          DATASERVER RECORDS                                   *         
      *----------------------------------------------------------------         
       01  PRINT-DATA-020       PIC X(100).                                     
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE -  RECORD DESCRIPTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGROUP                      '.                                  
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGRACCT                     '.                                  
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCOMP                       '.                                  
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
       01  WS-ENDS.                                                             
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2AGT W-S ENDS HERE   **'.                                  
                                                                                
      ******************************************************************        
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2AGT'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
      *-----------------------------------------------------------------        
       INIT.                                                                    
                                                                                
FXXTOK     DISPLAY 'START OF GC2AGT PROGRAM'.                                   
                                                                                
           PERFORM 100-INIT THRU 100-INIT-EXIT.                                 
                                                                                
      * VOCOMM VCM/GIPSY                                                        
           PERFORM 200-PROCESS-VCM-GIPSY                                        
              THRU 200-PROCESS-VCM-GIPSY-EXIT                                   
             UNTIL VGWO-RET-CODE NOT = '00'.                                    
                                                                                
      *--------------------------------------------------------------           
      *   END OF PROGRAM LOGIC                                                  
      *--------------------------------------------------------------           
       000-PROGRAM-END.                                                         
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-CLOSE-FILES    TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
                                                                                
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  OUTPUT-RECORD                                 
                                  ICBM.                                         
                                                                                
FXXTOK     DISPLAY 'END OF GC2AGT PROGRAM'.                                     
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
                                                                                
      ******************************************************************        
       100-INIT.                                                                
                                                                                
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2AGT' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
FXXTOK     MOVE 'GC2AGT'   TO ICBM-PROGRAM-NAME.                                
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-OPEN-FILES     TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ NEXT (VCM/GIPSY FILES)                                            
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-READ-NEXT      TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
                                                                                
       100-INIT-EXIT.                                                           
           EXIT.                                                                
                                                                                
      ******************************************************************        
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       200-PROCESS-VCM-GIPSY.                                                   
                                                                                
      *--------------------------------------------------------                 
      * REPORT ON ALL GROUPS                                                    
      *--------------------------------------------------------                 
                                                                                
           MOVE GGIGROUP-NUMBER TO GROUP-NUMBER OF GWCORGRACCT.                 
           MOVE GGIACCOUNT      TO GR-ACCOUNT OF GWCORGRACCT.                   
                                                                                
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      *              DISPLAY 'NO COMM GRAACT FOUND FOR: '                       
      *                       GGIGROUP-NUMBER '/' GGIACCOUNT                    
      * VOCOMM VCM/GIPSY                                                        
                     GO TO 200-PROCESS-VCM-GIPSY-EXIT.                          
                                                                                
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
CM0303                FCCSPL-FETCH-FIRST-AGT                                    
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      *              DISPLAY 'NO COMP RECORDS FOUND FOR: '                      
      *                       GGIGROUP-NUMBER '/' GGIACCOUNT                    
      * VOCOMM VCM/GIPSY                                                        
                     GO TO 200-PROCESS-VCM-GIPSY-EXIT.                          
                                                                                
      *    DISPLAY 'PROCESSING:  ',                                             
      *         GGIGROUP-NUMBER, ' - ',                                         
      *         GGIACCOUNT.                                                     
                                                                                
           MOVE 'N' TO WS-COMP-DONE.                                            
           PERFORM 300-PROCESS-COMP THRU 300-PROCESS-COMP-EXIT                  
                   UNTIL WS-COMP-DONE = 'Y'.                                    
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       200-PROCESS-VCM-GIPSY-EXIT.                                              
           PERFORM 800-READ-VCM-GIPSY THRU 800-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
      *  READ COMP RECORDS                                                      
      *      SELECT THOSE RECORDS THAT ARE EQUAL OR GREATER THAT 2003           
      *-----------------------------------------------------------------        
       300-PROCESS-COMP.                                                        
           IF COMP-EFF-YEAR  > 202                                              
           PERFORM 600-SETUP-RECORD THRU 600-SETUP-RECORD-EXIT.                 
                                                                                
       300-GET-NEXT-COMP.                                                       
      *%   OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
CM0303                FCCSPL-FETCH-NEXT-AGT                                     
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                     MOVE 'Y' TO WS-COMP-DONE.                                  
                                                                                
       300-PROCESS-COMP-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       600-SETUP-RECORD.                                                        
      *-----------------------------------------------------------------        
      *  WE'RE ONLY INTERESTED IN 'FY NAP PAID' RECORDS                         
      *-----------------------------------------------------------------        
           IF  COMP-REASON = 'F'                                                
           AND COMP-TYPE   = 'N'                                                
           AND COMP-DISP   = 'P'                                                
              NEXT SENTENCE                                                     
           ELSE                                                                 
              GO TO 600-SETUP-RECORD-EXIT.                                      
                                                                                
           MOVE GGIGROUP-NUMBER TO O-GROUP.                                     
           MOVE GGIACCOUNT      TO O-ACCOUNT.                                   
           MOVE AGENT-SPLIT     TO O-AGENT-SPLIT.                               
           MOVE AGENT-NUMBER    TO O-AGENT.                                     
           MOVE RECON-IND       TO O-RECON-IND.                                 
           MOVE 'PAID'          TO O-COMP-DISP.                                 
           MOVE 'NAP'           TO O-COMP-TYPE.                                 
           MOVE 'FY'            TO O-COMP-REASON.                               
           MOVE COMP-AMT        TO O-COMP-AMOUNT.                               
           MOVE PREM-AMT        TO O-PREM-AMOUNT.                               
           MOVE GGIGROUP-OFFICE TO O-GFO.                                       
           MOVE GGIGROUP-REP    TO O-GROUP-REP.                                 
                                                                                
           MOVE '2' TO VDATE-REQ-SERVICE.                                       
           MOVE 'B' TO VDATE-REQ-BASIS.                                         
           MOVE '1' TO VDATE-REQ-DETAIL.                                        
           MOVE 'E' TO VDATE-REQ-LANGUAGE.                                      
                                                                                
      *-----------------------------------------------------------------        
      *  CONVERT EFF DATE TO DISPLAY FORMAT                                     
      *-----------------------------------------------------------------        
           MOVE COMP-EFF-DATE  TO VDATE-ALIS-DATE1.                             
           CALL GC2DATE USING GC2DATE-PARMS.                                    
                                                                                
           IF VDATE-RET-IND NOT = +0                                            
              DISPLAY 'INVALID EFF DATE, RETURN CODE: '                         
                          VDATE-RET-CODE                                        
           ELSE                                                                 
              MOVE VDATE-EXT-DATE TO O-COMP-EFF-DATE                            
           END-IF.                                                              
                                                                                
      *-----------------------------------------------------------------        
      *  CONVERT PROCESS DATE TO DISPLAY FORMAT                                 
      *-----------------------------------------------------------------        
           MOVE COMP-PROCESS-DATE TO VDATE-ALIS-DATE1.                          
           CALL GC2DATE USING GC2DATE-PARMS.                                    
                                                                                
           IF VDATE-RET-IND NOT = +0                                            
              DISPLAY 'INVALID PROCESS DATE, RETURN CODE: '                     
                          VDATE-RET-CODE                                        
           ELSE                                                                 
              MOVE VDATE-EXT-DATE TO O-COMP-PROCESS-DATE                        
           END-IF.                                                              
                                                                                
      *-----------------------------------------------------------------        
      *  WRITE THIS RECORD                                                      
      *-----------------------------------------------------------------        
           PERFORM 900-WRITE-RECORD THRU 900-WRITE-RECORD-EXIT.                 
                                                                                
       600-SETUP-RECORD-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       800-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       800-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
      *-----------------------------------------------------------------        
                                                                                
      *-----------------------------------------------------------------        
       900-WRITE-RECORD.                                                        
                                                                                
      *    DISPLAY 'WRITING RECORD: ' OUTPUT-RECORD.                            
           MOVE OUTPUT-RECORD         TO PRINT-DATA-020.                        
           MOVE 'PRINT-DATA-020' TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR          USING  STORE-LR                               
                                         OUTPUT-RECORD                          
                                         ICBM.                                  
                                                                                
      *     IF NOT LR-STATUS-OK                                                 
      *        DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                       
      *     END-IF.                                                             
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
                                                                                
       900-WRITE-RECORD-EXIT.                                                   
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          END OF SOURCE                                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
