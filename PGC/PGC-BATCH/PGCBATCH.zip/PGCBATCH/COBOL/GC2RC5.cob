       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2RC5.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      * GL&H COMMISSIONS -- 'INCONSISTENT PAYBASIS REPORT' (MONTHLY)            
      * THIS PROGRAM CREATES AN EXTRACT FILE FOR REPORT PURPOSES;               
      * NO DATABASE UPDATES TAKE PLACE.  OUTPUT FILE IS PROCESSED BY            
      * GWCOCPBP WHICH FORMATS AND PRINTS THE ACTUAL REPORT.  EXTRACT           
      * RECORDS ARE CREATED BY THIS PROGRAM WHENEVER RECENT COMMISSION          
      * PAYMENTS TO AN AGENT DO NOT SEEM TO MATCH THE AGENT'S 'PAY BASIS        
      * INDICATOR'.                                                             
      * IF AGENT-PAYBASIS = 'Y' (ANNUALIZED)                                    
      *     PAYMENT IS SUPPOSED TO BE ADVANCED AT GROUP RENEWAL (OR             
      *     ISSUE) TIME, AND RECONCILED JUST BEFORE NEXT RENEWAL.               
      *     CREATE EXTRACT RECORD IF THERE ARE PAYMENT RECORDS ON THE DB        
      *     THAT AREN'T RECON RECORDS AND AREN'T IN THE RENEWAL MONTH.          
      * IF AGENT-PAYBASIS = 'N' (NON-ANNUALIZED)                                
      *     PAYMENTS ARE SUPPOSED TO BE MADE AS PREMIUMS ARE COLLECTED          
      *     AND COMMISSIONS ARE CONSIDERED TO BE 'EARNED'.  CREATE AN           
      *     EXTRACT RECORD IF THERE ARE PAYMENT RECORDS THAT DO NOT HAVE        
      *     A CORRESPONDING NUMBER OF EARNED RECORDS.                           
      * IF AGENT-PAYBASIS = 'F'                                                 
      *     GROUP'S FIRST YEAR, TREAT AS AN ANNUALIZED AGENT.                   
      *     GROUP'S SUBSEQUENT YEARS, TREAT AS A NON-ANNUALIZED AGENT.          
      ******************************************************************        
      *      REVISION HISTORY                                                   
      *      ----------------                                                   
      * 09OCT90 ANITA NIKELSKI - CREATED                                        
      * 17DEC90 ANITA NIKELSKI - CHANGE LOGIC FOR PAYMENT BASIS IND.            
      *      - IF THE PBI HAS CHANGED FROM 1 YEAR OF THE RENEWAL DATE           
      *        YOU HAVE TO PICK USE EITHER THE CURRENT OR OLD PBI               
      *        DEPENDING WHEN THE RENEWAL DATE IS - BECAUSE THE NEW             
      *        PBI DOES NOT TAKE EFFECT ON AN EXISTING GROUP TIL THE            
      *        NEXT ANNIVERSARY                                                 
      * 30APR91 IAN BUCKNELL                                                    
      *      - VARIOUS PROBLEMS APPARENT -- EXISTING LOGIC ABANDONED.           
      *        SCRAP ORIGINAL VERSION, RE-EXAMINE REQUIREMENTS, AND             
      *        RE-WRITE EXTRACT PROGRAM & ACCESSORIES. (GWCOCPBP WAS OK.)       
      *      - MOVE BOTH PROGRAMS FROM PGC1200 JOB STREAM TO PGC3200.           
      *                                                                         
      * 03OCT08 IBM                                                             
      *      - ENTERPRISE COMPILER UPGRADE                                      
      *                                                                         
      ******************************************************************        
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCRC5          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
      /                                                                         
       WORKING-STORAGE SECTION.                                                 
FXXTOK 01  FILLER  PIC X(32)  VALUE '**** GC2RC5 WS STARTS HERE ***'.           
      *=================================================================        
      * LOCAL YUK.                                                              
      *=================================================================        
       01  WORKING-STORAGE-FIELDS.                                              
           05  SWITCHES.                                                        
               10  FILLER            PIC X(16) VALUE 'SWITCHES********'.        
               10  END-GRACCT        PIC X     VALUE 'N'.                       
               10  END-CORCOMP       PIC X     VALUE 'N'.                       
               10  END-PBI           PIC X     VALUE 'N'.                       
               10  NO-PBI-RECS       PIC X     VALUE 'N'.                       
               10  EFF-PBI           PIC X     VALUE SPACE.                     
           05  DATES.                                                           
               10  FILLER            PIC X(16) VALUE 'DATES-N-STUFF***'.        
               10  QDATE-AB          PIC XX    VALUE 'AB'.                      
               10  QDATE-AC          PIC XX    VALUE 'AC'.                      
               10  QDATE-BA          PIC XX    VALUE 'BA'.                      
               10  QDATE-BC          PIC XX    VALUE 'BC'.                      
               10  QDATE-CA          PIC XX    VALUE 'CA'.                      
               10  QDATE-CB          PIC XX    VALUE 'CB'.                      
               10  RUN-DATE-B                  VALUE LOW-VALUES.                
                   15 RUN-DD          PIC 9(2).                                 
                   15 FILLER          PIC X(1).                                 
                   15 RUN-MM          PIC 9(2).                                 
                   15 FILLER          PIC X(1).                                 
                   15 RUN-YYY         PIC 9(2).                                 
               10  TODAY-DATE-A.                                                
                   15  TODAY-A-YEAR    PIC S9(3) COMP-3.                        
                   15  TODAY-A-DAY     PIC S9(3) COMP-3.                        
               10  LASTRUN-DATE-A.                                              
                   15  LASTRUN-YEAR    PIC S9(3) COMP-3.                        
                   15  LASTRUN-DAY     PIC S9(3) COMP-3.                        
               10  LASTRENEW-DATE-A.                                            
                   15  LASTRENEW-YEAR  PIC S9(3) COMP-3.                        
                   15  LASTRENEW-DAY   PIC S9(3) COMP-3.                        
               10  LASTRENEW-DATE-C.                                            
                   15  LASTRENEW-DD       PIC 99.                               
                   15  LASTRENEW-MMMYY.                                         
                       20  LASTRENEW-MMM  PIC XXX.                              
                       20  LASTRENEW-YY   PIC 99.                               
               10  SEARCH-DATE-A.                                               
                   15  SEARCH-YEAR        PIC S9(3) COMP-3.                     
                   15  SEARCH-DAY         PIC S9(3) COMP-3.                     
               10  COMP-EFF-DATE-C.                                             
                   15  COMP-EFF-DD        PIC 99.                               
                   15  COMP-EFF-MMMYY.                                          
                       20  COMP-EFF-MMM   PIC XXX.                              
                       20  COMP-EFF-YY    PIC 99.                               
                                                                                
      *    *------------------------------------------------------------        
      *    * TABLE TO TRACK INFO FOR MULIPLE AGENTS ON A GIVEN GRP/ACCT         
      *    *------------------------------------------------------------        
       01  AGENT-TABLE-AREA.                                                    
           05  FILLER                PIC X(16) VALUE 'AGENT-TABLE*****'.        
           05  AGTBL-LIMITS.                                                    
               10  AGTBL-SUB         PIC S9(4) COMP SYNC.                       
               10  AGTBL-HIWATER     PIC S9(4) COMP SYNC.                       
               10  AGTBL-LIMIT       PIC S9(4) COMP SYNC  VALUE +20.            
           05  AGTBL-AGENT-TABLE                         OCCURS  20.            
               10  AGTBL-AGT-NUMBER  PIC X(6).                                  
               10  AGTBL-PBI         PIC X.                                     
               10  AGTBL-YPBI-BAD    PIC X.                                     
               10  AGTBL-PREC-COUNT  PIC S9(4)  COMP SYNC.                      
               10  AGTBL-EREC-COUNT  PIC S9(4)  COMP SYNC.                      
      /                                                                         
      *=================================================================        
      * INPUT.                                                                  
      *=================================================================        
      *    *------------------------------------------------------------        
      *    * PARMCARD                                                           
      *    *------------------------------------------------------------        
       01  PARMCARD-PARMS.                                                      
           05  SYS010-SYS010                 PIC X(6)   VALUE 'SYS010'.         
           05  SYS010-RET-CODE       COMP-3  PIC S9     VALUE +0.               
           05  SYS010-REC-SIZE               PIC X(5)   VALUE '00081'.          
           05  SYS010-BLOCK-SIZE             PIC X(5)   VALUE '23409'.          
           05  SYS010-REC-FORMAT             PIC X(2)   VALUE 'FB'.             
           05  SYS010-REC-COUNT      COMP-3  PIC S9(7)  VALUE +0.               
                                                                                
       01  PARMCARD-RECORD.                                                     
      *    * FIRST DATE POSN ON CARD IS LAST YEAR END CLOSE - USED BY           
      *    * OTHER REPORT PROGRAMS IN SAME JOB STREAM                           
           05  FILLER                        PIC X(8).                          
           05  LASTRUN-DATE-C.                                                  
               10  LASTRUN-DD                PIC 9(2).                          
               10  LASTRUN-MMM               PIC X(3).                          
               10  LASTRUN-YY                PIC 9(2).                          
      /                                                                         
      *    *-----------------------------------------------------------         
      *    * IDMS COMMISSIONS DATABASE RECORDS                                  
      *    *-----------------------------------------------------------         
       01  FILLER  PIC X(16)  VALUE 'IDMS START *****'.                         
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
       01  FILLER  PIC X(16)  VALUE 'GWCORGRACCT ****'.                         
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
       01  FILLER  PIC X(16)  VALUE 'GWCORCOMP ******'.                         
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
       01  FILLER  PIC X(16)  VALUE 'GWCORAGENT *****'.                         
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
      /                                                                         
       01  FILLER  PIC X(16)  VALUE 'GWCORPAYBASIS **'.                         
      * GWCORPAYBASIS                                                           
CPYNME     COPY GCIPAYB.                                                        
       01  FILLER  PIC X(16)  VALUE 'IDMS END *******'.                         
                                                                                
      /                                                                         
      *=================================================================        
      * OUTPUT.                                                                 
      *=================================================================        
      *    *------------------------------------------------------------        
      *    * EXTRACT                                                            
      *    *------------------------------------------------------------        
       01  DLSWRITE-PARAMETERS.                                                 
           05  DLSW-SYS020      PIC X(6)          VALUE 'SYS020'.               
           05  DLSW-RET-CODE    PIC S9    COMP-3.                               
           05  DLSW-REC-SIZE    PIC 9(5)          VALUE 50.                     
           05  DLSW-BLK-SIZE    PIC 9(5)          VALUE 23450.                  
           05  DLSW-REC-FMT     PIC XX            VALUE 'FB'.                   
           05  DLSW-REC-CNT     PIC S9(7) COMP-3  VALUE +0.                     
                                                                                
       01  DETAIL-01.                                                           
REN        05  D1-GROUP         PIC 9(07).                                      
           05  D1-ACCOUNT       PIC X(03).                                      
           05  D1-AGENT         PIC 9(06).                                      
           05  D1-PAYBASIS-IND  PIC X(25).                                      
           05  D1-PAYMENT       PIC X(11).                                      
                                                                                
FXXTOK 01  FILLER  PIC X(32)  VALUE '**** GC2RC5 WS ENDS HERE *****'.           
      /                                                                         
      *=================================================================        
      * OPTIONAL PARM ON EXEC CARD TO OVERRIDE CURRENT SYSTEM DATE.             
      *=================================================================        
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
           05  ZCURRDAT                     PIC X(8)  VALUE 'ZCURRDAT'.         
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  PARM.                                                                
           05  PARMLENGTH                     PIC S9(4) COMP.                   
           05  PARMDATE-B.                                                      
               10  PARM-DD                    PIC 99.                           
               10  FILLER                     PIC X.                            
               10  PARM-MM                    PIC 99.                           
               10  FILLER                     PIC X.                            
               10  PARM-YY                    PIC 99.                           
                                                                                
      /                                                                         
      ******************************************************************        
      ******************************************************************        
       PROCEDURE DIVISION USING PARM.                                           
FXXTOK     MOVE 'GC2RC5'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
      ******************************************************************        
      ******************************************************************        
                                                                                
           PERFORM 1000-INIT           THRU 1000-END.                           
           PERFORM 2000-PROCESS-GRACCT THRU 2000-END                            
                   UNTIL END-GRACCT = 'Y'.                                      
           PERFORM 3000-CLEANUP        THRU 3000-END.                           
           STOP RUN.                                                            
                                                                                
      /                                                                         
       1000-INIT.                                                               
      *=================================================================        
      * INITIALIZE HOUSEKEEPING                                                 
      *=================================================================        
      *    *------------------------------------------------------------        
      *    * JANGLE IDMS OUT OF BED                                             
      *    *------------------------------------------------------------        
FXXTOK     MOVE 'GC2RC5' TO PROGRAM-NAME.                                       
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2RC5' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *    *------------------------------------------------------------        
      *    * GET CURRENT DATE OR USE EXEC CARD OVERRIDE                         
      *    *------------------------------------------------------------        
           IF PARMLENGTH = 8                                                    
               MOVE  PARMDATE-B    TO RUN-DATE-B                                
           ELSE                                                                 
               CALL  ZCURRDAT   USING RUN-DATE-B.                               
                                                                                
MAN02      CALL QDATEQ2         USING QDATE-BA                                  
MAN02                                 RUN-DATE-B                                
MAN02                                 TODAY-DATE-A.                             
                                                                                
      *    *-----------------------------------------------------------         
      *    * READ PARMLIB MEMBER -- DATE IS DAY AFTER LAST RUN OF JOB           
      *    *-----------------------------------------------------------         
           CALL  'DLSREAD'   USING  SYS010-SYS010                               
                                    SYS010-RET-CODE                             
                                    PARMCARD-RECORD                             
                                    SYS010-REC-SIZE                             
                                    SYS010-BLOCK-SIZE                           
                                    SYS010-REC-FORMAT                           
                                    SYS010-REC-COUNT.                           
           IF SYS010-RET-CODE  >  ZERO                                          
               DISPLAY 'ERROR READING PARMLIB MEMBER'                           
               PERFORM 3000-CLEANUP THRU 3000-END                               
               MOVE +12 TO RETURN-CODE                                          
               STOP RUN.                                                        
                                                                                
MAN02      CALL QDATEQ2 USING QDATE-CA                                          
MAN02                         LASTRUN-DATE-C                                    
MAN02                         LASTRUN-DATE-A.                                   
           IF LASTRUN-DATE-A = '****'                                           
               DISPLAY 'ERROR ON PARM CARD -- INVALID DATE'                     
               MOVE +12 TO RETURN-CODE                                          
               PERFORM 3000-CLEANUP THRU 3000-END                               
               STOP RUN.                                                        
                                                                                
      *    *------------------------------------------------------------        
      *    * READ FIRST GWCORGRACCT RECORD IN DATABASE                          
      *    *------------------------------------------------------------        
      *%   OBTAIN FIRST GWCORGRACCT WITHIN GW-COMP-AREA1                        
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02 *               FCCSPL-FETCH-FIRST-U                                      
CM0314                FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 DISPLAY 'ERROR - EOS READING FIRST GRACCT RECORD'              
                 PERFORM 3000-CLEANUP THRU 3000-END                             
                 MOVE +12 TO RETURN-CODE                                        
                 STOP RUN.                                                      
                                                                                
       1000-END.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       2000-PROCESS-GRACCT.                                                     
      *=================================================================        
      * PROCESS DRIVER FOR A GIVEN GROUP/ACCT                                   
      *=================================================================        
      *    *------------------------------------------------------------        
      *    * ESTABLISH DATE OF GROUP'S LAST RENEWAL. 'LAST RECON' ALWAYS        
      *    * 1 DAY SHY OF LAST RENEWAL -- EVEN ON A NEW GROUP WHERE             
      *    * IT'S SET UP TO BE 1 DAY SHY OF ORIGINAL ISSUE.                     
      *    *------------------------------------------------------------        
           MOVE LAST-RECON-DATE OF GWCORGRACCT TO LASTRENEW-DATE-A.             
           IF LASTRENEW-DAY = +365                                              
               MOVE  +1       TO  LASTRENEW-DAY                                 
               ADD   +1       TO  LASTRENEW-YEAR                                
           ELSE                                                                 
               ADD   +1       TO  LASTRENEW-DAY.                                
MAN02      CALL  QDATEQ2   USING  QDATE-AC                                      
MAN02                             LASTRENEW-DATE-A                              
MAN02                             LASTRENEW-DATE-C.                             
                                                                                
      *    *------------------------------------------------------------        
      *    * READ FIRST GWCORCOMP RECORD                                        
      *    *------------------------------------------------------------        
           MOVE 'N' TO END-CORCOMP.                                             
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 MOVE  'Y'  TO END-CORCOMP.                                     
                                                                                
      *    *------------------------------------------------------------        
      *    * DRIVE PROCESSING OF ALL CORCOMPS FOR GRP/ACCT                      
      *    *------------------------------------------------------------        
CM0314     INITIALIZE AGTBL-AGENT-TABLE (01).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (02).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (03).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (04).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (05).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (06).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (07).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (08).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (09).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (10).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (11).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (12).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (13).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (14).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (15).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (16).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (17).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (18).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (19).                                   
CM0314     INITIALIZE AGTBL-AGENT-TABLE (20).                                   
                                                                                
           MOVE  ZERO  TO  AGTBL-HIWATER.                                       
           PERFORM 2100-PROCESS-CORCOMPS  THRU  2100-END                        
                   UNTIL END-CORCOMP = 'Y'.                                     
                                                                                
      *    *------------------------------------------------------------        
      *    * DECIDE WHAT GOT FISHED UP.  LOOP THRU TABLE AND FIRE UP AN         
      *    * EXTRACT RECORD FOR ANY AGENT THAT LOOKS INCONSISTENT.              
      *    *------------------------------------------------------------        
           PERFORM 2200-PROCESS-RESULTS   THRU  2200-END                        
                   VARYING  AGTBL-SUB  FROM  +1  BY  +1                         
                     UNTIL  AGTBL-SUB  >  AGTBL-HIWATER.                        
                                                                                
       2000-READ.                                                               
      *    *------------------------------------------------------------        
      *    * NEXT GROUP.                                                        
      *    *------------------------------------------------------------        
      *%   FIND CURRENT GWCORGRACCT.                                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   OBTAIN NEXT  GWCORGRACCT WITHIN GW-COMP-AREA1                        
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02 *               FCCSPL-FETCH-NEXT-U                                       
CM0314                FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 MOVE 'Y' TO END-GRACCT.                                        
                                                                                
       2000-END.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       2100-PROCESS-CORCOMPS.                                                   
      *=================================================================        
      * PROCESS DRIVER FOR A GIVEN CORCOMP RECORD.                              
      *=================================================================        
      *    *------------------------------------------------------------        
      *    * ONLY WANT 'COMM' RECORDS WITHIN OUR PROCESS DATE WINDOW            
      *    *------------------------------------------------------------        
           IF COMP-TYPE  NOT =  'C'                                             
              GO TO 2100-READ.                                                  
                                                                                
           IF COMP-EFF-DATE NOT < LASTRUN-DATE-A  AND                           
              COMP-EFF-DATE NOT > TODAY-DATE-A                                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF COMP-EFF-DATE < LASTRUN-DATE-A                                
                   MOVE 'Y' TO END-CORCOMP                                      
                   GO TO 2100-END                                               
               ELSE                                                             
                   GO TO 2100-READ.                                             
                                                                                
      *    *------------------------------------------------------------        
      *    * GOOD RECORD. LOOK UP OR GENERATE TABLE ENTRY OF AGENT INFO.        
      *    *------------------------------------------------------------        
           PERFORM  2110-EST-AGT-INFO   THRU  2110-END.                         
                                                                                
           IF AGTBL-PBI (AGTBL-SUB) = '*'                                       
               GO TO 2100-READ.                                                 
                                                                                
      *    *------------------------------------------------------------        
      *    * DECIDE WHAT OUR 'EFFECTIVE' PAY BASIS INDICATOR IS                 
      *    *------------------------------------------------------------        
           IF AGTBL-PBI (AGTBL-SUB) = 'Y' OR 'N'                                
               MOVE AGTBL-PBI (AGTBL-SUB) TO EFF-PBI                            
           ELSE                                                                 
      *        *--------------------------------------------------------        
      *        * RESOLVE 'FIRST YEAR ANNUALIZED' PBI BY DECIDING WHETHER        
      *        * CORCOMP IS FOR 1ST YEAR OR SUBSEQUENT YEAR, AND THEN           
      *        * JUST TREAT PBI AS 'Y' OR 'N' ACCORDINGLY.                      
      *        *--------------------------------------------------------        
               IF COMP-REASON = 'F' OR 'A'                                      
                   MOVE 'Y' TO EFF-PBI                                          
               ELSE                                                             
      *            * COMP-REASON = 'R' OR 'B'                                   
                   MOVE 'N' TO EFF-PBI.                                         
                                                                                
      *    *------------------------------------------------------------        
      *    * AND SEE IF THIS CORCOMP HAS ANY STRAY ODORIFEROUS QUALITIES        
      *    *------------------------------------------------------------        
MAN02      CALL QDATEQ2 USING QDATE-AC                                          
MAN02                         COMP-EFF-DATE                                     
MAN02                         COMP-EFF-DATE-C.                                  
                                                                                
           IF EFF-PBI = 'Y'                                                     
      *        * PAYMENT RECORDS OK IF RENEWAL MONTH OR OTHER THAN              
      *        * 1ST DAY OF MONTH (RECONCILIATIONS)                             
               IF COMP-DISP      NOT =  'P'               OR                    
                  COMP-EFF-MMMYY     =  LASTRENEW-MMMYY   OR                    
                  COMP-EFF-DD    NOT =  '01'                                    
                   GO TO 2100-READ                                              
               ELSE                                                             
                   MOVE 'Y' TO AGTBL-YPBI-BAD (AGTBL-SUB)                       
                   GO TO 2100-READ.                                             
                                                                                
           IF EFF-PBI = 'N'                                                     
               IF COMP-EFF-DD  NOT =  '01'                                      
                   GO TO 2100-READ                                              
               ELSE                                                             
                   IF COMP-DISP = 'P'                                           
                       ADD +1 TO AGTBL-PREC-COUNT (AGTBL-SUB)                   
                   ELSE                                                         
                       ADD +1 TO AGTBL-EREC-COUNT (AGTBL-SUB).                  
                                                                                
       2100-READ.                                                               
      *    *------------------------------------------------------------        
      *    * READ ANOTHER CORCOMP                                               
      *    *------------------------------------------------------------        
      *%   FIND CURRENT GWCORCOMP.                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   OBTAIN NEXT  GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE 'Y' TO END-CORCOMP.                                      
                                                                                
       2100-END.                                                                
           EXIT.                                                                
                                                                                
       2110-EST-AGT-INFO.                                                       
      *=================================================================        
      * LOOK UP OR GENERATE TABLE ENTRY OF AGENT INFO                           
      *=================================================================        
      *    *------------------------------------------------------------        
      *    * GOT IT IN TABLE ALREADY?                                           
      *    *------------------------------------------------------------        
           PERFORM  9999-DUMMY  THRU  9999-END                                  
                    VARYING AGTBL-SUB FROM +1 BY +1                             
                            UNTIL AGTBL-SUB > AGTBL-HIWATER                     
                               OR AGTBL-AGT-NUMBER (AGTBL-SUB)                  
                                  = AGENT-NUMBER OF GWCORCOMP.                  
           IF AGTBL-AGT-NUMBER (AGTBL-SUB) = AGENT-NUMBER OF GWCORCOMP          
               GO TO 2110-END.                                                  
                                                                                
      *    *------------------------------------------------------------        
      *    * NOPE.  FETCHEZ DA VACHE.                                           
      *    *------------------------------------------------------------        
           MOVE  AGENT-NUMBER OF GWCORCOMP                                      
             TO  AGENT-NUMBER OF GWCORAGENT.                                    
      *%   OBTAIN CALC GWCORAGENT                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 DISPLAY 'ERROR READING GWCORAGENT '                            
                         GROUP-NUMBER OF GWCORCOMP '-'                          
                         GR-ACCOUNT   OF GWCORCOMP SPACE                        
                         AGENT-NUMBER OF GWCORCOMP                              
                 PERFORM 3000-CLEANUP THRU 3000-END                             
                 MOVE +12 TO RETURN-CODE                                        
                 STOP RUN.                                                      
                                                                                
      *    *------------------------------------------------------------        
      *    * READ FIRST PAYBASIS INDICATOR RECORD                               
      *    *------------------------------------------------------------        
           MOVE  TODAY-DATE-A  TO  SEARCH-DATE-A.                               
           MOVE  'N'           TO  NO-PBI-RECS.                                 
           MOVE  'N'           TO  END-PBI.                                     
      *%   OBTAIN FIRST WITHIN AGENT-PAYBASIS                                   
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 11 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 MOVE 'Y' TO NO-PBI-RECS                                        
                 MOVE 'Y' TO END-PBI.                                           
                                                                                
      *    *------------------------------------------------------------        
      *    * LOOK THRU PAYBASIS INDICATOR RECORDS TO FIND CURRENT VALUE         
      *    *------------------------------------------------------------        
           PERFORM  2111-SEARCH-PBIS  THRU  2111-END                            
                    UNTIL  END-PBI  =  'Y'.                                     
                                                                                
      *    *------------------------------------------------------------        
      *    * IF THERE WERE NO RECORDS PRIOR TO ISSUE OR EARLIEST RENEWAL        
      *    * WE WILL BE USING THE EARLIEST PBI AVAILABLE.                       
      *    *------------------------------------------------------------        
      *    * IF THERE WERE NONE AT ALL, THE ONLY CORCOMP PAYMENTS               
      *    * PRESENT HAVE BEEN SYSTEM DEFAULTED TO 'NON-ANNUALIZED' AND         
      *    * *CANNOT* BE INCONSISTENT -- WE WILL SET A FLAG VALUE IN            
      *    * OUR TABLE AND JUST IGNORE THIS BLOKE.                              
      *    *------------------------------------------------------------        
      *    * ...SET HIM UP IN THE TABLE                                         
      *    *------------------------------------------------------------        
           COMPUTE  AGTBL-SUB  =  AGTBL-HIWATER + 1.                            
           IF AGTBL-SUB  >  AGTBL-LIMIT                                         
               DISPLAY 'ERROR - INTERNAL TABLE OVERFLOW'                        
               PERFORM 3000-CLEANUP THRU 3000-END                               
               MOVE +12 TO RETURN-CODE                                          
               STOP RUN.                                                        
                                                                                
           MOVE AGENT-NUMBER OF GWCORAGENT                                      
                                   TO  AGTBL-AGT-NUMBER (AGTBL-SUB).            
                                                                                
           IF NO-PBI-RECS = 'Y'                                                 
               MOVE '*'            TO  AGTBL-PBI        (AGTBL-SUB)             
           ELSE                                                                 
               MOVE PAY-BASIS-IND  TO  AGTBL-PBI        (AGTBL-SUB).            
                                                                                
           MOVE 'N'                TO  AGTBL-YPBI-BAD   (AGTBL-SUB).            
           MOVE ZERO               TO  AGTBL-PREC-COUNT (AGTBL-SUB).            
           MOVE ZERO               TO  AGTBL-EREC-COUNT (AGTBL-SUB).            
                                                                                
           MOVE AGTBL-SUB          TO  AGTBL-HIWATER.                           
                                                                                
       2110-END.                                                                
           EXIT.                                                                
                                                                                
       2111-SEARCH-PBIS.                                                        
      *=================================================================        
      * PROCESS PAYBASIS RECORD                                                 
      *=================================================================        
      *    *------------------------------------------------------------        
      *    * REJECT IF EFFECTIVE IN THE FUTURE                                  
      *    *------------------------------------------------------------        
           IF PAY-BASIS-EFF-DATE > SEARCH-DATE-A                                
               GO TO 2111-READ.                                                 
                                                                                
      *    *------------------------------------------------------------        
      *    * IF A RENEWAL HAS NOT TAKEN PLACE SINCE THIS PBI 'EFFECTIVE'        
      *    * THEN THE INDICATOR IS NOT REALLY IN EFFECT.  MUST FIND THE         
      *    * LAST ONE THAT WAS 'EFFECTIVE' JUST BEFORE LATEST RENEWAL.          
      *    *------------------------------------------------------------        
           IF PAY-BASIS-EFF-DATE > LASTRENEW-DATE-A                             
               MOVE  LASTRENEW-DATE-A  TO  SEARCH-DATE-A                        
               GO TO 2111-READ.                                                 
                                                                                
      *    *------------------------------------------------------------        
      *    * GOOD RECORD.                                                       
      *    *------------------------------------------------------------        
           MOVE  'Y'  TO  END-PBI.                                              
           GO TO 2111-END.                                                      
                                                                                
       2111-READ.                                                               
      *    *------------------------------------------------------------        
      *    * READ NEXT ONE AND TRY AGAIN                                        
      *    *------------------------------------------------------------        
      *%   OBTAIN NEXT WITHIN AGENT-PAYBASIS                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 12 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 MOVE 'Y' TO END-PBI.                                           
                                                                                
       2111-END.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       2200-PROCESS-RESULTS.                                                    
      *=================================================================        
      * LOOK AT STORED AGENT INFO AND DECIDE WHETHER TO PRINT A RECORD          
      *=================================================================        
                                                                                
           IF AGTBL-PBI      (AGTBL-SUB) = '*'                                  
               GO TO 2200-END.                                                  
                                                                                
           IF AGTBL-PBI      (AGTBL-SUB) = 'Y'  AND                             
              AGTBL-YPBI-BAD (AGTBL-SUB) = 'Y'                                  
               MOVE 'ALL YEARS ANNUALIZED'      TO D1-PAYBASIS-IND              
               MOVE 'MONTHLY'                   TO D1-PAYMENT                   
               PERFORM 2210-WRITE-RECORD      THRU 2210-END                     
               GO TO 2200-END.                                                  
                                                                                
           IF AGTBL-PBI      (AGTBL-SUB) = 'N'  AND                             
              AGTBL-PREC-COUNT (AGTBL-SUB)  NOT =                               
                                            AGTBL-EREC-COUNT (AGTBL-SUB)        
               MOVE 'ALL YEARS NON-ANNUALIZED'  TO D1-PAYBASIS-IND              
               MOVE 'ANNUALIZED'                TO D1-PAYMENT                   
               PERFORM 2210-WRITE-RECORD      THRU 2210-END                     
               GO TO 2200-END.                                                  
                                                                                
           IF AGTBL-PBI      (AGTBL-SUB) = 'F'  AND                             
              AGTBL-YPBI-BAD (AGTBL-SUB) = 'Y'                                  
               MOVE 'FIRST YEAR ANNUALIZED'     TO D1-PAYBASIS-IND              
               MOVE 'MONTHLY'                   TO D1-PAYMENT                   
               PERFORM 2210-WRITE-RECORD      THRU 2210-END.                    
                                                                                
           IF AGTBL-PBI      (AGTBL-SUB) = 'F'  AND                             
              AGTBL-PREC-COUNT (AGTBL-SUB)  NOT =                               
                                            AGTBL-EREC-COUNT (AGTBL-SUB)        
               MOVE 'FIRST YEAR ANNUALIZED'     TO D1-PAYBASIS-IND              
               MOVE 'ANNUALIZED'                TO D1-PAYMENT                   
               PERFORM 2210-WRITE-RECORD      THRU 2210-END.                    
                                                                                
       2200-END.                                                                
           EXIT.                                                                
                                                                                
       2210-WRITE-RECORD.                                                       
      *=================================================================        
      * SET UP AND PRINT THE EXTRACT RECORD                                     
      *=================================================================        
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT  TO D1-GROUP.                       
           MOVE GR-ACCOUNT   OF GWCORGRACCT  TO D1-ACCOUNT.                     
           MOVE AGTBL-AGT-NUMBER (AGTBL-SUB) TO D1-AGENT.                       
                                                                                
           CALL 'DLSWRITE'                USING DLSW-SYS020                     
                                                DLSW-RET-CODE                   
                                                DETAIL-01                       
                                                DLSW-REC-SIZE                   
                                                DLSW-BLK-SIZE                   
                                                DLSW-REC-FMT                    
                                                DLSW-REC-CNT.                   
       2210-END.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       3000-CLEANUP.                                                            
      *=================================================================        
      * LEZ BLOW DIS POP STAND                                                  
      *=================================================================        
           MOVE +4                     TO DLSW-RET-CODE.                        
           PERFORM 2210-WRITE-RECORD THRU 2210-END.                             
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 13 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       3000-END.                                                                
           EXIT.                                                                
                                                                                
       9999-DUMMY.                                                              
      *=================================================================        
      * (EMPTY LOOP)                                                            
      *=================================================================        
       9999-END.                                                                
           EXIT.                                                                
                                                                                
      *%   COPY IDMS IDMS-STATUS.                                               
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
