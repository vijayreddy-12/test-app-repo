       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VOAGM.                                                 
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  JUNE 2005.                                                
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *                                                                         
      *   COMMISSIONS SYSTEM                                                    
      *   HUB VO COMMISSIONS PROJECT                                            
      *                                                                         
      *   HUB:  AGENT FILE AND PAY BASIS DATA EXTRACT/MERGE                     
      *         (VOCOMM AGT PAYBASIS)                                           
      *                                                                         
      *   THIS PROGRAM READS THE AGENT NAME FILE AND THE PAYBASIS               
      *   EXTRACT FILE AND PRODUCES THE MERGED AGENT PAYBASIS FILE.             
      *                                                                         
      *   CALLING PROGRAM:  NONE                                                
      *                                                                         
      *   CALLED PROGRAMS:  ZACCVSAM                                            
      *                     GAEDATSR                                            
      *                     GC2DATE                                             
      *                                                                         
      *   COPYBOOKS:                                                            
      *       PAYBXTR                                                           
      *       EAGNFILE                                                          
      *       AGTMRGE                                                           
      *       GARDATEP                                                          
      *       GARDSVRB                                                          
      *       ICBM                                                              
      *       HCSLRNAM                                                          
      *                                                                         
      *   INPUT  - AGENT NAME FILE (VSAM FILE FROM AGENCY SYSTEM)               
      *            PAY BASIS EXTRACT FILE (SORTED)                              
      *                                                                         
      *   OUTPUT - MERGED AGENT PAY BASIS FILE                                  
      *                                                                         
      *   DESCRIPTION:                                                          
      *     PROCESS ALL RECORDS FROM AGTNAME AND SPAYBXTR.                      
      *     READ AND MATCH AGTNAME AND SPAYBXTR; IGNORE AGTNAME                 
      *     RECORDS WHOSE AGT-CODE IS LESS THAN 5 DIGITS AND WHOSE              
      *     AGT-ACCOUNT IS NOT 0.                                               
      *     FOR AGTNAME RECORDS WITH A MATCHING SPAYBXTR RECORD,                
      *     CREATE AN AGTMRGE RECORD USING AGT-CODE, AGT-BRANCH-CODE,           
      *     AGT-NAME, PBXT-EFF-DATE (CONVERTED TO CCYYMMDD FORMAT),             
      *     PBXT-PAY-BASIS-IND.                                                 
      *     FOR AGTNAME RECORDS WITH NO MATCHING SPAYBXTR RECORD,               
      *     CREATE AN AGTMRGE RECORD USING AGT-CODE, AGT-BRANCH-CODE,           
      *     AGT-NAME, AGT-CONTRACT-DATE (CONVERTED TO CCYYMMDD FORMAT),         
      *     AND PAY BASIS INDICATOR ASSIGNED AS WITH THE VALUE 'Y'.             
      *     FOR SPAYBXTR RECORDS WITH NO MATCHING AGTNAME RECORD,               
      *     CREATE AN AGTMRGE RECORD USING PBXT-AGENT-CODE,                     
      *     SPACES FOR AGENT BRANCH, SPACES FOR AGENT NAME,                     
      *     PBXT-EFF-DATE (CONVERTED TO CCYYMMDD FORMAT),                       
      *     PBXT-PAY-BASIS-IND.                                                 
      *                                                                         
      ******************************************************************        
      *    MMM/CCYY   -    NAME            -   DESCRIPTION                      
      *    JUN 2005        REGINA KNAUD        INITIAL CREATION.                
      *                                                                         
      *    OCT 2008        IBM               ENTERPRISE COMPILER UPGRADE        
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVOAGTM          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       SOURCE-COMPUTER. IBM-370-165.                                            
       OBJECT-COMPUTER. IBM-370-165.                                            
                                                                                
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-VARIABLES.                                                        
           05  FILLER                      PIC X(32) VALUE                      
FXXTOK         '*** GC2VOAGM WORKING STORAGE ***'.                              
           05  WS-AGTNAME-EOF              PIC X.                               
           05  WS-SPAYBXTR-EOF             PIC X.                               
           05  WS-AGT-AGENT-CODE           PIC 9(7).                            
           05  WS-AGT-AGENT-CODEX REDEFINES WS-AGT-AGENT-CODE.                  
               10  WS-AGT-AGENT-CODE-1N3   PIC XXX.                             
               10  WS-AGT-AGENT-CODE-327   PIC X(4).                            
           05  WS-PBXT-AGENT-CODE          PIC 9(7).                            
           05  WS-PBXT-AGENT-CODEX REDEFINES WS-PBXT-AGENT-CODE                 
                                           PIC X(7).                            
           05  WS-AGT-CONTRACT-YEAR        PIC 9(4).                            
           05  WS-AGT-CONTRACT-CCYY REDEFINES WS-AGT-CONTRACT-YEAR.             
               10  WS-AGT-CONTRACT-CC      PIC 99.                              
               10  WS-AGT-CONTRACT-YY      PIC 99.                              
           05  WS-PREV-AGENT-CODEX         PIC X(7).                            
           05  WS-PREV-AGT-BRANCH          PIC X(5).                            
           05  WS-PREV-AGT-NAME            PIC X(25).                           
           05  WS-PREV-AGT-CLASS           PIC 9(3).                            
           05  WS-TODAY-DATE.                                                   
               10  FILLER                  PIC X(6).                            
               10  WS-TODAY-YY             PIC 99.                              
           05  WS-CURRENT-YEAR             PIC 9(4).                            
           05  WS-CURRENT-CCYY REDEFINES WS-CURRENT-YEAR.                       
               10  WS-CURRENT-CC           PIC 99.                              
               10  WS-CURRENT-YY           PIC 99.                              
           05  WS-YYYYMMDD-DATE.                                                
               10  WS-YYYY                 PIC 9(4).                            
               10  WS-MM                   PIC 99.                              
               10  WS-DD                   PIC 99.                              
           05  WS-EXT-DATE.                                                     
               10  WS-EXT-DAY              PIC 99.                              
               10  WS-EXT-MONTH            PIC XXX.                             
               10  WS-EXT-YEAR             PIC 9(4).                            
           05  WS-EXT-DATE-TABL            PIC X(60)                            
               VALUE 'JAN01FEB02MAR03APR04MAY05JUN06JUL07AUG08SEP09OCT10        
      -              'NOV11DEC12'.                                              
           05  WS-EXT-DATE-TABLE REDEFINES WS-EXT-DATE-TABL.                    
               10  WS-EXT-DATE-TAB         OCCURS 12.                           
                   15  WS-EXT-DATE-MONTH   PIC X(3).                            
                   15  WS-EXT-DATE-MM      PIC 99.                              
           05  WS-MONTH-SBS                PIC 99.                              
                                                                                
      *----------------------------------------------------------------*        
      *    ZACCVSAM PARAMETERS - AGENT NAME FILE                                
      *----------------------------------------------------------------*        
       01  VSAM-AGT-PARAMETERS.                                                 
           05  VSAM-AGT-PARM1.                                                  
               10  VSAM-AGT-DDNAME   PIC X(7)      VALUE 'VSDSI37'.             
               10  VSAM-AGT-ACCTYPE  PIC X(5)      VALUE 'KEYED'.               
               10  VSAM-AGT-RECTYPE  PIC X(1)      VALUE 'V'.                   
               10  VSAM-AGT-FUNC     PIC X(6)      VALUE SPACES.                
               10  VSAM-AGT-ERROR    PIC X(5)      VALUE SPACES.                
                   88  VSAM-AGT-NOT-FOUND          VALUE 'R0804'.               
               10  VSAM-AGT-READ-CT  PIC S9(7)     VALUE +0   COMP-3.           
               10  VSAM-AGT-WRT-CT   PIC S9(7)     VALUE +0   COMP-3.           
               10  VSAM-AGT-UPD-CT   PIC S9(7)     VALUE +0   COMP-3.           
               10  VSAM-AGT-DEL-CT   PIC S9(7)     VALUE +0   COMP-3.           
               10  VSAM-AGT-RECLEN   PIC S9(4)     VALUE +0   COMP.             
           05  VSAM-AGT-PARM2.                                                  
               10  VSAM-AGT-AGENT    PIC S9(7) COMP-3.                          
               10  VSAM-AGT-ACCT     PIC X.                                     
                                                                                
      *01  AGENT-NAME-FILE.                                                     
           COPY EAGNFILE.                                                       
                                                                                
      *01  PAYBASIS-EXTRACT.                                                    
           COPY PAYBXTR.                                                        
                                                                                
      *01  AGENT-MERGE-RECORD.                                                  
           COPY AGTMRGE.                                                        
                                                                                
      *----------------------------------------------------------------*        
      *    GACDATE                                                              
      *----------------------------------------------------------------*        
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *    DATA SERVER ACTION VERBS                                             
      *----------------------------------------------------------------*        
       01  GAEDATSR-PARMS.                                                      
                                      COPY GARDSVRB.                            
                                                                                
       01  WS-GAEDATSR-VERB       PIC X(16).                                    
                                                                                
      *----------------------------------------------------------------*        
      *    INTERFACE CONTROL BLOCK                                              
      *----------------------------------------------------------------*        
       01  ICBM.                                                                
                                      COPY ICBM.                                
                                                                                
      *----------------------------------------------------------------*        
      *    LOGICAL RECORD NAMES                                                 
      *----------------------------------------------------------------*        
       01  LOGICAL-RECORD-NAMES.                                                
                                      COPY HCSLRNAM.                            
              10  LR-SPAYBXTR-IN      PIC X(16) VALUE 'CARD-DATA-010'.          
              10  LR-AGTMRGE-OUT      PIC X(16) VALUE 'PRINT-DATA-020'.         
                                                                                
      *------------------------------------------------------------             
      *    ABEND VARIABLES                                                      
      *-------------------------------------------------------------            
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X            PIC X(04).                             
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH       PIC S9(3) VALUE +133 COMP-3.           
               10  WTL-MESS-CC           PIC X(1)  VALUE SPACES.                
               10  WTL-MESS-TEXT         PIC X(132) VALUE SPACES.               
           05  WTL-FLAG                  PIC X(1)  VALUE 'B'.                   
           05  WTL-REPLY                 PIC X(3)  VALUE 'NO '.                 
           05  WTL-REPLY-AREA            PIC X(80) VALUE SPACES.                
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                     PIC X(80)                              
FXXTOK         VALUE 'GC2VOAGM - ** PROBLEM WRITING AGTMRGE REC**'.             
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY         OCCURS 1 TIMES.                        
               10  WTL-MESSAGE           PIC X(80).                             
       01  WTL-SUB                       PIC S9(4) COMP.                        
                                                                                
MAN02  COPY GWFERRWS.                                                           
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GC2DATE                PIC X(8) VALUE 'GC2DATE '.                
           05  GAEDATSR               PIC X(8) VALUE 'GAEDATSR'.                
           05  ZCURRDAT               PIC X(8) VALUE 'ZCURRDAT'.                
                                                                                
       PROCEDURE DIVISION.                                                      
       0000-MAINLINE.                                                           
                                                                                
           PERFORM 1000-INIT THRU 1000-EXIT.                                    
                                                                                
           PERFORM 2000-PROCESS-AGTNAME THRU 2000-EXIT                          
                   UNTIL WS-AGTNAME-EOF = 'Y'.                                  
                                                                                
           PERFORM 3000-PROCESS-SPAYBXTR THRU 3000-EXIT                         
                   UNTIL WS-SPAYBXTR-EOF = 'Y'.                                 
                                                                                
           PERFORM 9900-FINISH THRU 9900-EXIT.                                  
                                                                                
           STOP RUN.                                                            
                                                                                
       0000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       1000-INIT.                                                               
FXXTOK     MOVE 'GC2VOAGM'   TO ICBM-PROGRAM-NAME.                              
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
                                                                                
           INITIALIZE  WS-USER-ABEND-CODE.                                      
           MOVE 'N'    TO WS-AGTNAME-EOF                                        
                          WS-SPAYBXTR-EOF.                                      
           MOVE '0000000' TO WS-PREV-AGENT-CODEX.                               
           MOVE SPACES    TO WS-PREV-AGT-BRANCH                                 
                             WS-PREV-AGT-NAME.                                  
           MOVE 0         TO WS-PREV-AGT-CLASS.                                 
                                                                                
           MOVE 'SETLIM'  TO VSAM-AGT-FUNC.                                     
           PERFORM 2110-READ-AGTNAME THRU 2110-EXIT.                            
           IF  VSAM-AGT-ERROR NOT = LOW-VALUES                                  
               MOVE 'Y'   TO WS-AGTNAME-EOF                                     
           ELSE                                                                 
              MOVE 'GETSEQ' TO VSAM-AGT-FUNC                                    
              PERFORM 2110-READ-AGTNAME THRU 2110-EXIT                          
              IF VSAM-AGT-ERROR NOT = LOW-VALUES                                
                 MOVE 'Y'    TO WS-AGTNAME-EOF                                  
              ELSE                                                              
                 MOVE AGT-CODE    TO WS-AGT-AGENT-CODE                          
              END-IF                                                            
           END-IF.                                                              
                                                                                
           MOVE OBTAIN-FIRST     TO WS-GAEDATSR-VERB.                           
           PERFORM 2210-READ-SPAYBXTR THRU 2210-EXIT.                           
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-SPAYBXTR-EOF                                       
              MOVE HIGH-VALUES TO WS-PBXT-AGENT-CODEX                           
           ELSE                                                                 
              MOVE PBXT-AGENT-CODE TO WS-PBXT-AGENT-CODE                        
           END-IF.                                                              
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2000-PROCESS-AGTNAME.                                                    
           IF WS-AGT-AGENT-CODE-1N3 NOT = '000'                                 
              AND                                                               
              AGT-ACCOUNT = '0'                                                 
                 IF WS-AGT-AGENT-CODEX = WS-PBXT-AGENT-CODEX                    
                    MOVE WS-PBXT-AGENT-CODEX TO WS-PREV-AGENT-CODEX             
                    MOVE AGT-BRANCH-CODE     TO WS-PREV-AGT-BRANCH              
                    MOVE AGT-NAME            TO WS-PREV-AGT-NAME                
                    MOVE AGT-MLI-CONTRACT-CLASS                                 
                                             TO WS-PREV-AGT-CLASS               
                                                                                
                    MOVE SPACES TO AGENT-MERGE-RECORD                           
                    MOVE WS-AGT-AGENT-CODE  TO AGTMRG-AGENT-CODE                
                    MOVE PBXT-EFF-DATE      TO VDATE-ALIS-DATE1                 
                    PERFORM 2400-REFORMAT-YEAR-DAY THRU 2400-EXIT               
                    MOVE WS-YYYYMMDD-DATE                                       
                                          TO AGTMRG-PAY-BASIS-EFF-DATE          
                    MOVE PBXT-PAY-BASIS-IND TO AGTMRG-PAY-BASIS-IND             
                    MOVE AGT-BRANCH-CODE    TO AGTMRG-BRANCH-CODE               
                    MOVE AGT-NAME           TO AGTMRG-AGENT-NAME                
                    MOVE AGT-MLI-CONTRACT-CLASS                                 
                                            TO AGTMRG-CONTRACT-CLASS            
                    PERFORM 2300-PUT-AGTMRGE THRU 2300-EXIT                     
                                                                                
                    PERFORM 2100-GET-AGTNAME  THRU 2100-EXIT                    
                                                                                
                    PERFORM 2200-GET-SPAYBXTR THRU 2200-EXIT                    
                                                                                
                 ELSE                                                           
                    IF WS-AGT-AGENT-CODEX > WS-PBXT-AGENT-CODEX                 
                       MOVE SPACES TO AGENT-MERGE-RECORD                        
                       MOVE WS-PBXT-AGENT-CODE TO AGTMRG-AGENT-CODE             
                       MOVE PBXT-EFF-DATE      TO VDATE-ALIS-DATE1              
                       PERFORM 2400-REFORMAT-YEAR-DAY THRU 2400-EXIT            
                       MOVE WS-YYYYMMDD-DATE                                    
                                          TO AGTMRG-PAY-BASIS-EFF-DATE          
                       MOVE PBXT-PAY-BASIS-IND                                  
                                            TO AGTMRG-PAY-BASIS-IND             
                       IF WS-PBXT-AGENT-CODEX = WS-PREV-AGENT-CODEX             
                          MOVE WS-PREV-AGT-BRANCH TO AGTMRG-BRANCH-CODE         
                          MOVE WS-PREV-AGT-NAME   TO AGTMRG-AGENT-NAME          
                          MOVE WS-PREV-AGT-CLASS                                
                                               TO AGTMRG-CONTRACT-CLASS         
                       ELSE                                                     
                          MOVE SPACES          TO AGTMRG-BRANCH-CODE            
                          MOVE SPACES          TO AGTMRG-AGENT-NAME             
                          MOVE 1               TO AGTMRG-CONTRACT-CLASS         
                       END-IF                                                   
                       PERFORM 2300-PUT-AGTMRGE THRU 2300-EXIT                  
                                                                                
                       PERFORM 2200-GET-SPAYBXTR THRU 2200-EXIT                 
                                                                                
                    ELSE                                                        
                       MOVE SPACES TO AGENT-MERGE-RECORD                        
                       MOVE WS-AGT-AGENT-CODE TO AGTMRG-AGENT-CODE              
                       PERFORM 2500-REFORMAT-MONTH-YEAR THRU 2500-EXIT          
                       MOVE WS-YYYYMMDD-DATE                                    
                                          TO AGTMRG-PAY-BASIS-EFF-DATE          
                       MOVE 'Y'           TO AGTMRG-PAY-BASIS-IND               
                       MOVE AGT-BRANCH-CODE TO AGTMRG-BRANCH-CODE               
                       MOVE AGT-NAME        TO AGTMRG-AGENT-NAME                
                       MOVE AGT-MLI-CONTRACT-CLASS                              
                                            TO AGTMRG-CONTRACT-CLASS            
                       PERFORM 2300-PUT-AGTMRGE THRU 2300-EXIT                  
                                                                                
                       PERFORM 2100-GET-AGTNAME  THRU 2100-EXIT                 
                                                                                
                    END-IF                                                      
                 END-IF                                                         
           ELSE                                                                 
                                                                                
              PERFORM 2100-GET-AGTNAME  THRU 2100-EXIT                          
                                                                                
           END-IF.                                                              
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2100-GET-AGTNAME.                                                        
           MOVE 'GETSEQ' TO VSAM-AGT-FUNC.                                      
                                                                                
           PERFORM 2110-READ-AGTNAME THRU 2110-EXIT.                            
                                                                                
           IF VSAM-AGT-ERROR NOT = LOW-VALUES                                   
              MOVE 'Y'    TO WS-AGTNAME-EOF                                     
           ELSE                                                                 
              MOVE AGT-CODE    TO WS-AGT-AGENT-CODE                             
           END-IF.                                                              
                                                                                
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2110-READ-AGTNAME.                                                       
           CALL 'ZACCVSAM' USING VSAM-AGT-PARM1                                 
                                 VSAM-AGT-PARM2                                 
                                 AGENT-NAME-FILE.                               
                                                                                
       2110-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2200-GET-SPAYBXTR.                                                       
           MOVE OBTAIN-NEXT      TO WS-GAEDATSR-VERB.                           
                                                                                
           PERFORM 2210-READ-SPAYBXTR THRU 2210-EXIT.                           
                                                                                
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-SPAYBXTR-EOF                                       
              MOVE HIGH-VALUES TO WS-PBXT-AGENT-CODEX                           
           ELSE                                                                 
              MOVE PBXT-AGENT-CODE TO WS-PBXT-AGENT-CODE                        
           END-IF.                                                              
                                                                                
       2200-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2210-READ-SPAYBXTR.                                                      
           MOVE LR-SPAYBXTR-IN   TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING WS-GAEDATSR-VERB                            
                                    PAYBASIS-EXTRACT                            
                                    ICBM.                                       
                                                                                
       2210-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2300-PUT-AGTMRGE.                                                        
           MOVE STORE-LR           TO WS-GAEDATSR-VERB.                         
                                                                                
           PERFORM 2310-WRITE-AGTMRGE THRU 2310-EXIT.                           
                                                                                
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-AGTNAME-EOF                                        
              MOVE 'Y' TO WS-SPAYBXTR-EOF                                       
              MOVE +1  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND THRU                                       
                      9999-WTL-ABEND-EXIT                                       
           END-IF.                                                              
                                                                                
       2300-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2310-WRITE-AGTMRGE.                                                      
           MOVE LR-AGTMRGE-OUT   TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING WS-GAEDATSR-VERB                            
                                    AGENT-MERGE-RECORD                          
                                    ICBM.                                       
                                                                                
       2310-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2400-REFORMAT-YEAR-DAY.                                                  
           MOVE '2B1E'             TO VDATE-REQUEST-AREA.                       
           CALL  GC2DATE  USING GAC-DATE-PARAMETERS.                            
           MOVE VDATE-EXT-DATE     TO WS-EXT-DATE.                              
           MOVE WS-EXT-DAY         TO WS-DD.                                    
           MOVE WS-EXT-YEAR        TO WS-YYYY.                                  
           MOVE 1                  TO WS-MM.                                    
           PERFORM VARYING WS-MONTH-SBS FROM 1 BY 1                             
             UNTIL WS-MONTH-SBS > 12                                            
                   IF WS-EXT-DATE-MONTH (WS-MONTH-SBS) = WS-EXT-MONTH           
                      MOVE WS-EXT-DATE-MM (WS-MONTH-SBS) TO WS-MM               
                   END-IF                                                       
           END-PERFORM.                                                         
                                                                                
       2400-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2500-REFORMAT-MONTH-YEAR.                                                
           CALL  ZCURRDAT    USING WS-TODAY-DATE.                               
           MOVE 20                    TO WS-CURRENT-CC.                         
           MOVE WS-TODAY-YY           TO WS-CURRENT-YY.                         
                                                                                
      *** NOTE:  AGT-CONTRACT-DAY ACTUALLY CONTAINS THE YEAR VALUE              
      ***        AND AGT-CONTRACT-YR ACTUALLY CONTAINS THE MONTH VALUE.         
           MOVE 20                    TO WS-AGT-CONTRACT-CC.                    
           MOVE AGT-CONTRACT-DAY      TO WS-AGT-CONTRACT-YY.                    
                                                                                
           IF WS-AGT-CONTRACT-YEAR > WS-CURRENT-YEAR                            
              MOVE 19                 TO WS-AGT-CONTRACT-CC                     
           END-IF.                                                              
                                                                                
           MOVE WS-AGT-CONTRACT-YEAR  TO WS-YYYY.                               
           MOVE AGT-CONTRACT-YR       TO WS-MM.                                 
           IF WS-MM > 0 AND WS-MM < 13                                          
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE 01                 TO WS-MM                                  
           END-IF.                                                              
           MOVE 01                    TO WS-DD.                                 
                                                                                
       2500-EXIT.                                                               
           EXIT.                                                                
                                                                                
       3000-PROCESS-SPAYBXTR.                                                   
           MOVE SPACES TO AGENT-MERGE-RECORD.                                   
           MOVE WS-PBXT-AGENT-CODE TO AGTMRG-AGENT-CODE.                        
           MOVE PBXT-EFF-DATE      TO VDATE-ALIS-DATE1.                         
           PERFORM 2400-REFORMAT-YEAR-DAY THRU 2400-EXIT.                       
           MOVE WS-YYYYMMDD-DATE   TO AGTMRG-PAY-BASIS-EFF-DATE.                
           MOVE PBXT-PAY-BASIS-IND TO AGTMRG-PAY-BASIS-IND.                     
           IF WS-PBXT-AGENT-CODEX = WS-PREV-AGENT-CODEX                         
              MOVE WS-PREV-AGT-BRANCH TO AGTMRG-BRANCH-CODE                     
              MOVE WS-PREV-AGT-NAME   TO AGTMRG-AGENT-NAME                      
              MOVE WS-PREV-AGT-CLASS  TO AGTMRG-CONTRACT-CLASS                  
           ELSE                                                                 
              MOVE SPACES             TO AGTMRG-BRANCH-CODE                     
              MOVE SPACES             TO AGTMRG-AGENT-NAME                      
              MOVE 1                  TO AGTMRG-CONTRACT-CLASS                  
           END-IF.                                                              
           PERFORM 2300-PUT-AGTMRGE THRU 2300-EXIT.                             
                                                                                
           PERFORM 2200-GET-SPAYBXTR THRU 2200-EXIT.                            
                                                                                
       3000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *--------------------------------------------------------                 
      * CLOSE FILES THAT ARE OPEN...                                            
      *--------------------------------------------------------                 
       9900-FINISH.                                                             
           MOVE SPACES      TO LOGICAL-RECORD-NAME.                             
           MOVE FINISH-LR   TO WS-GAEDATSR-VERB.                                
           CALL GAEDATSR USING WS-GAEDATSR-VERB                                 
                               LOGICAL-RECORD-NAME                              
                               ICBM.                                            
                                                                                
           MOVE 'CLOFIL'  TO VSAM-AGT-FUNC.                                     
           PERFORM 2110-READ-AGTNAME THRU 2110-EXIT.                            
                                                                                
       9900-EXIT.                                                               
           EXIT.                                                                
                                                                                
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL'    USING  WTL-MESSAGES                                    
                                WTL-FLAG                                        
                                WTL-REPLY                                       
                                WTL-REPLY-AREA.                                 
                                                                                
           CALL 'ILBOABN0'  USING  WS-COMP-CODE.                                
                                                                                
       9999-WTL-ABEND-EXIT.                                                     
           EXIT.                                                                
