       IDENTIFICATION DIVISION.                                         00010000
       PROGRAM-ID.    TLUCOBD.                                          00020000
      *AUTHOR.        Neil Jeffrey.                                     00030000
      *DATE-WRITTEN.  Sep 17,2009.                                      00040000
      ******************************************************************00050000
      *    PROGRAM CHANGES                                             *00051000
      ******************************************************************00052000
      *  This is one of a pair of programs to convert TLUCOB calls     *00052102
      *  from static to dynamic. The other half is TLUDYN.             *00052202
      *                                                                *00052302
      * This is designed to be a dynamically callable wrapper for      *00053000
      * the utility subroutine TLUCOB                                  *00053100
      *                                                                *00053200
      * The specific problem to solve is that in the INTERFACES job    *00053300
      * PGK1120 (or 1130), there are 6  dynamically called subroutines,*00053400
      * each one of which includes calls to TLUCOB. At the moment that *00053500
      * causes the six instances of TLU COB (each one statically linked)00053600
      * each to load its own copy of all of the tables.                *00053700
      *                                                                *00053800
      * I plan to change the six link cards to  include a tiny replace-*00053900
      * ment TLUCOB routine, which will in turn call this module.      *00054000
      * If they all call the same version of this module (as expected) *00054100
      * then we will only need the storage for one copy of the tables, *00054200
      * instead of six copies. At teh moment the tables being loaded   *00054300
      * amount to around 800K each for a total of 4.8M. I hope to save *00054400
      * about 4 meg by this change.                                    *00054500
      *                                                                *00054600
      * There is an additional two calls, so performance will degrade  *00054700
      * but, we are very close to not being able to run at all         *00054800
      *                                                                *00054900
      * Other possible uses for a wrapper routine could include:       *00055000
      * - counting the lookups (successful and not) per table (TLUPL2) *00055100
      * - obviously reporting those results at the end                 *00056000
      *        DD tluprint will already be in all the jobs using TLUCOB*00056100
      * - potentially diverting some of those calls away from TLU      *00056200
      *        and over to some other acces method (eg VSAM read)      *00056300
      ******************************************************************00056700
       ENVIRONMENT DIVISION.                                            00056800
       CONFIGURATION SECTION.                                           00056900
       SOURCE-COMPUTER.  IBM-370-165.                                   00057000
       OBJECT-COMPUTER.  IBM-370-165.                                   00057100
       INPUT-OUTPUT SECTION.                                            00057200
       FILE-CONTROL.                                                    00057300
                                                                        01270000
      ******************************************************************01280000
      *    REPORT FILES FOR SUCCESSFUL AND UNSUCCESSFUL MOVES           01290000
      ******************************************************************01300000
           SELECT TLUPRINT ASSIGN TO  TLUPRINT.                         01310000
                                                                        01330000
       DATA DIVISION.                                                   01440000
                                                                        03770000
       FILE   SECTION.                                                  03771001
      ******************************************************************03780000
      *    SUCCESSFUL AND UNSUCCESSFUL MOVES REPORT                     03790000
      ******************************************************************03800000
       FD  TLUPRINT                                                     03810000
           RECORD CONTAINS 133 CHARACTERS                               03830000
           BLOCK CONTAINS  0 RECORDS.                                   03840000
       01  TLUPRINT-LINE                         PIC X(133).            03850000
                                                                        04080000
       WORKING-STORAGE SECTION.                                         04090000
                                                                        04091000
       01  FILLER                                PIC X(48)              04092000
            VALUE ' *** TLUCOBD  - WORKING STORAGE STARTS HERE *** '.   04093001
                                                                        04094000
       01 COUNTERS.                                                     13532105
           05 LINES-PER-PAGE         PIC S9(4) COMP VALUE 55.           13532205
           05 LINE-COUNT             PIC S9(4) COMP VALUE 999.          13532305
           05 SUB                    PIC S9(4) COMP VALUE zero.         13532405
                                                                        13532505
       01 SAVE-COUNTERS.                                                13533000
           05 SAVE-CAT-ARRAY             OCCURS 1000 TIMES.             13535000
               10 LOOKUPS-TRIED      PIC S9(8) COMP VALUE 0.            13537000
               10 LOOKUPS-FOUND      PIC S9(8) COMP VALUE 0.            13537100
                                                                        13538100
       01 PRINT-LINE.                                                   13539000
           05  PRINT-CC              PIC X(1)     VALUE '-'.            13540005
           05  FILLER                PIC X(10)    VALUE 'TABLE'.        13550000
           05  PRINT-TABLE           PIC 999      VALUE ZERO.           13560000
           05  FILLER                PIC X(09)    VALUE '  FOUND  '.    13570000
           05  PRINT-FOUND           PIC Z(8)9    VALUE ZERO.           13580000
           05  FILLER                PIC X(09)    VALUE '  OUT OF '.    13590000
           05  PRINT-TRIED           PIC Z(8)9    VALUE ZERO.           13600000
           05  FILLER                PIC X(09)    VALUE ' ATTEMPTS'.    13610000
           05  FILLER                PIC X(64)    VALUE SPACES.         13620000
                                                                        13630000
                                                                        13640005
       01 WELCOME-LINE.                                                 13650005
           05  PRINT-CC1             PIC X(1)     VALUE '-'.            13660006
           05  FILLER                PIC X(42)                          13670005
               VALUE 'New Copy of TLUCOBD has been invoked.'.           13671005
           05  FILLER                PIC X(90)    VALUE spaces.         13690005
                                                                        13705005
       01  FILLER                                PIC X(48)              13710000
              VALUE ' *** TLUCOBD  - WORKING STORAGE -ENDS- HERE *** '. 13711001
                                                                        13712000
       LINKAGE SECTION.                                                 13713000
                                                                  SKIP1 13714000
       01 PARM-ERROR-CODE            PIC X(01)    VALUE SPACE.          13714200
       01 PARM-ARGUMENT              PIC X(281)   VALUE SPACE.          13714300
       01 PARM-TABLE-NUMBER          PIC S9(03)   COMP-3.               13714400
       01 PARM-RESULT                PIC X(281)   VALUE SPACE.          13714600
                                                                        13714700
           EJECT                                                        13720500
       PROCEDURE DIVISION USING      PARM-ERROR-CODE                    13720600
                                     PARM-ARGUMENT                      13720700
                                     PARM-TABLE-NUMBER                  13720800
                                     PARM-RESULT.                       13720900
                                                                  SKIP1 13721400
      ******************************************************************13740000
       A-100-MAIN-LINE.                                                 13741003
           SKIP1                                                        13742000
      ******************************************************************13743000
      *                                                                *13744000
      *    MAIN LINE.                                                  *13745000
      *                                                                *13746000
      ******************************************************************13747000
                                                                        13747100
           if LINE-COUNT = 999                                          13747205
              PERFORM D-100-REPORT-OPEN                                 13747305
              move LINES-PER-PAGE       to LINE-COUNT                   13747405
           END-IF.                                                      13747605
                                                                        13747705
           IF PARM-TABLE-NUMBER  >    0                                 13748003
              PERFORM C-100-LOOKUP                                      13749000
           ELSE                                                         13749305
              PERFORM D-200-REPORT-COUNTS                               13749406
           END-IF.                                                      13749500
                                                                        13749600
       A-100-EXIT.                                                      13749700
           GOBACK.                                                      13749800
                                                                        13749900
           EJECT                                                        13750000
       C-100-LOOKUP.                                                    13750103
                                                                        13750200
      ******************************************************************13750300
      *                                                                *13750400
      *    ASSUMING THE TABLE NUMBER IS IN RANGE,  COUNT THE ATTEMPT,  *13750500
      *      DO THE LOOKUP, AND IF SUCCESSFUL, COUNT THE SUCCESS       *13750600
      *                                                                *13750700
      ******************************************************************13750800
                                                                        13750900
           ADD 1 TO  LOOKUPS-TRIED (PARM-TABLE-NUMBER).                 13751000
                                                                        13751100
           CALL 'TLUCOB' USING   PARM-ERROR-CODE                        13751200
                                 PARM-ARGUMENT                          13751300
                                 PARM-TABLE-NUMBER                      13751400
                                 PARM-RESULT.                           13751500
                                                                        13751600
           IF PARM-ERROR-CODE = SPACE                                   13751700
               ADD 1 TO  LOOKUPS-FOUND (PARM-TABLE-NUMBER)              13751800
           END-IF.                                                      13751900
                                                                        13752000
       C-100-END.  EXIT.                                                13752103
                                                                        13752700
       D-100-REPORT-OPEN.                                               13753005
                                                                        13754000
      ******************************************************************13755000
      *    The first time we call lookup with this program print the    13756005
      *    welcome message.  Within this paragraph do...                13757005
      *      OPEN THE TLUPRINT FILE                                    *13758000
      *      PRINT THE COUNTS                                          *13759000
      *      CLOS THE TLUPRINT FILE                                    *13759100
      *      set a switch so we do not do this on each lookup           13759205
      ******************************************************************13759300
                                                                        13759400
           move LINES-PER-PAGE  to LINE-COUNT.                          13759605
                                                                        13759705
           OPEN OUTPUT TLUPRINT.                                        13759805
                                                                        13759905
           WRITE TLUPRINT-LINE    FROM WELCOME-LINE.                    13760805
                                                                        13761404
           CLOSE TLUPRINT.                                              13761504
                                                                        13761604
       D-100-END.  EXIT.                                                13761704
                                                                        13761804
       D-200-REPORT-COUNTS.                                             13761905
                                                                        13762005
      ******************************************************************13763005
      *    EVERY TIME YOU CALL A LOOKUP WITH TABLE 0, YOU GET THE COUNTS13764005
      *    WITHIN THIS SINGLE SECTION,                                  13765005
      *      OPEN THE TLUPRINT FILE                                    *13766005
      *      PRINT THE COUNTS                                          *13767005
      *      CLOS THE TLUPRINT FILE                                    *13768005
      ******************************************************************13769005
                                                                        13770005
           OPEN OUTPUT TLUPRINT                                         13780005
                                                                        13810005
           PERFORM VARYING SUB FROM 1                                   13820005
                               BY   1                                   13830005
                               UNTIL SUB > 999                          13840005
                                                                        13850105
                IF LOOKUPS-TRIED (SUB) > 0                              13850205
                                                                        13850305
                   MOVE                SUB  TO PRINT-TABLE              13851005
                   MOVE LOOKUPS-FOUND (SUB) TO PRINT-FOUND              13870005
                   MOVE LOOKUPS-TRIED (SUB) TO PRINT-TRIED              13880005
                                                                        13881005
                   if LINE-COUNT >= LINES-PER-PAGE                      13891005
                     MOVE '1' to PRINT-CC                               13892005
                     MOVE  0  to LINE-COUNT                             13892105
                   end-if                                               13893005
                                                                        13894005
                   WRITE TLUPRINT-LINE    FROM PRINT-LINE               13900005
                   MOVE SPACES to PRINT-CC                              13910005
                   ADD 1 TO LINE-COUNT                                  13911005
                                                                        13920005
                END-IF                                                  13930005
                                                                        13940005
           END-PERFORM.                                                 13950005
                                                                        13960005
           CLOSE TLUPRINT.                                              13970005
                                                                        13980005
       D-200-END.  EXIT.                                                13990005
                                                                        14000005
