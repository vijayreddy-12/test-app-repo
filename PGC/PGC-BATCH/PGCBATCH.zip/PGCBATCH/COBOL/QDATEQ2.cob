       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. 'QDATEQ2'.                                                   
      *-------------------------------------------------------------*           
      * THIS PROGRAM IS EQUIVALENT TO SEVERAL OTHER PROGRAMS                    
      * ANY CHANGES MADE TO THIS PROGRAM SHOULD ALSO BE MADE TO:                
      *                                                                         
      *     IQDATEQ  - IDMS DC VERSION                                          
      *     IQDATEQ2 - IDMS DC VERSION FOR COBOL II                             
      *     CQDATEQ  - CICS VERSION                                             
      *     CQDATEQ2 - CICS VERSION FOR COBOL II                                
      *                                                                         
      *-------------------------------------------------------------*           
      * HISTORY LOG                                                             
      * 02JUL08    IBM GR    UPGRADED IN ENTERPRISE COMPILER PROJECT            
      *-------------------------------------------------------------*           
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
       FILE-CONTROL.                                                            
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------         
      *    DYNAMIC CALLED ROUTINES                                              
      *----------------------------------------------------------------         
       01  WS-CALLED-MODULES.                                                   
           05  GC2DATE           PIC X(08)    VALUE 'GC2DATE'.                  
                                                                                
       01  GACDATE-PARS.     COPY GARDATEP.                                     
       01  ZDATE-FORMAT-CODES.                                                  
           03 ZDATE-FORMAT-LIST.                                                
      *                                                                         
      *      SLASHES ARE OPTIONAL FOR FORMATS B, G, & S.                        
      *      NOTE THAT ET'S VERSION OF "ZDATE" HAS FORMAT B DEFINED AS          
      *           MM/DD/YY AND FORMAT S AS DD/MM/YY. QDATEQ2 IS THE             
      *           REPLACEMENT FOR GLH'S VERSION OF ZDATE WHICH HAD              
      *           FORMAT B DEFINED AS DD/MM/YY. FORMAT S WAS ADDED              
      *           TO MAKE THE TRANSITION EASIER.                                
      *                                                                         
               05  FILLER              PIC X(13) VALUE '(A) ALIS     '.         
               05  FILLER              PIC X(13) VALUE '(B) DD/MM/YY '.         
               05  FILLER              PIC X(13) VALUE '(C) DDMMMYY  '.         
               05  FILLER              PIC X(13) VALUE '(D) DDMMMYYYY'.         
               05  FILLER              PIC X(13) VALUE '(E) DDFRAYY  '.         
               05  FILLER              PIC X(13) VALUE '(F) DDFRAYYYY'.         
               05  FILLER              PIC X(13) VALUE '(G) YY/MM/DD '.         
               05  FILLER              PIC X(13) VALUE '(S) MM/DD/YY '.         
       01  FILLER REDEFINES ZDATE-FORMAT-CODES.                                 
           03  FILLER OCCURS 8.                                                 
               05  FILLER              PIC X.                                   
               05 ZDATE-CODE           PIC X.                                   
               05  FILLER              PIC X(11).                               
       01  MISC.                                                                
           03 I                        PIC S99 COMP.                            
           03 ZTAG                     PIC X.                                   
           03 RJ-DATE                  PIC X(6) JUST RIGHT.                     
           03 ZERO-DATE.                                                        
              05 ZERO-DATE-YR          PIC S9(3) COMP-3 VALUE 0.                
              05 ZERO-DATE-DAY         PIC S9(3) COMP-3 VALUE 0.                
       LINKAGE SECTION.                                                         
      *                                                                         
      *     ZDATE PARAMETERS                                                    
      *                                                                         
       01  ZDATE-PAR1.                                                          
           03 ZDATE-FROM                     PIC X.                             
           03 ZDATE-TO                       PIC X.                             
       01  ZDATE-SOURCE.                                                        
           03 ZDATE-ALPHA                    PIC X(9).                          
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05 ZDATE-ALIS-YR              PIC S999 COMP-3.                   
               05 ZDATE-ALIS-DAY             PIC S999 COMP-3.                   
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05 ZDATE-DD                   PIC 99.                            
               05 ZDATE-MM                   PIC 99.                            
               05 ZDATE-YY                   PIC 99.                            
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05  FILLER                    PIC XX.                            
               05 ZDATE-MMM                  PIC XXX.                           
               05 ZDATE-YY2                  PIC 99.                            
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05 ZDATE-YY3                  PIC 99.                            
               05 ZDATE-SL1                  PIC X.                             
               05 ZDATE-MM3                  PIC 99.                            
               05 ZDATE-SL2                  PIC X.                             
               05 ZDATE-DD3                  PIC 99.                            
       01  ZDATE-TARGET.                                                        
           03 ZDATE-TARGET-ALPHA             PIC X(9).                          
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05 ZDATE-TARGET-ALIS-YEAR     PIC S999 COMP-3.                   
               05 ZDATE-TARGET-ALIS-DAY      PIC S999 COMP-3.                   
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05 ZDATE-TARGET-DD            PIC XX.                            
               05 ZDATE-TARGET-MM            PIC XX.                            
               05 ZDATE-TARGET-YY            PIC 99.                            
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05 ZDATE-TARGET-SYSTEM        PIC XX/XX/XX.                      
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05  ZDATE-DDMMM               PIC X(5).                          
               05 ZDATE-TARGET-YYYY.                                            
                   07 ZDATE-TARGET-SHORTYY   PIC 99.                            
                   07 ZDATE-TARGET-BLANK     PIC XX.                            
           03 ZDATE-TARGET-ERROR4 REDEFINES ZDATE-TARGET-ALPHA                  
                                             PIC X(4).                          
           03 ZDATE-TARGET-ERROR6 REDEFINES ZDATE-TARGET-ALPHA                  
                                             PIC X(6).                          
           03 ZDATE-TARGET-ERROR7 REDEFINES ZDATE-TARGET-ALPHA                  
                                             PIC X(7).                          
           03 ZDATE-TARGET-ERROR8 REDEFINES ZDATE-TARGET-ALPHA                  
                                             PIC X(8).                          
           03 ZDATE-TARGET-ERROR9 REDEFINES ZDATE-TARGET-ALPHA                  
                                             PIC X(9).                          
       EJECT                                                                    
       PROCEDURE DIVISION USING ZDATE-PAR1 ZDATE-SOURCE ZDATE-TARGET.           
      *                                                                         
       0000-TRANSLATE-PARAMETERS.                                               
      *                                                                         
      *    DISPLAY 'QDATEQ2 RECEIVING:' ZDATE-PAR1 ',' ZDATE-SOURCE             
           MOVE SPACES TO GACDATE-PARS.                                         
           MOVE '1'            TO VDATE-REQ-DETAIL.                             
           MOVE 'E'            TO VDATE-REQ-BASIS.                              
           MOVE 'E'            TO VDATE-REQ-LANGUAGE.                           
           IF ZDATE-TO = 'E' OR 'F'                                             
               MOVE 'F' TO VDATE-REQ-LANGUAGE.                                  
           MOVE ZDATE-FROM TO ZTAG.                                             
           PERFORM 0600-SEARCH THRU 0690-EXIT.                                  
           IF I > 8                                                             
               GO TO 0300-ERROR.                                                
           GO TO 0010-ALIS                                                      
                 0020-DDMMYY                                                    
                 0030-DDMMMYY                                                   
                 0040-DDMMMYYYY                                                 
                 0050-DDFRAYY                                                   
                 0060-DDFRAYYYY                                                 
                 0070-YY-MM-DD                                                  
                 0080-MMDDYY                                                    
                 DEPENDING ON I.                                                
           GO TO 0300-ERROR.                                                    
      *                                                                         
       0010-ALIS.                                                               
      *                                                                         
           IF ZDATE-ALIS-YR NOT NUMERIC                                         
              GO TO 0300-ERROR.                                                 
           IF ZDATE-ALIS-DAY NOT NUMERIC                                        
              GO TO 0300-ERROR.                                                 
           MOVE ZDATE-ALIS-YR  TO VDATE-ALIS-YEAR1.                             
           MOVE ZDATE-ALIS-DAY TO VDATE-ALIS-DAY1.                              
           MOVE '2'            TO VDATE-REQ-SERVICE.                            
           MOVE 'B'            TO VDATE-REQ-BASIS.                              
           IF ZDATE-ALIS-YR EQUAL ZERO-DATE-YR AND                              
              ZDATE-ALIS-DAY EQUAL ZERO-DATE-DAY                                
              PERFORM 0500-BLANK-RETURN THRU                                    
                      0500-BLANK-RETURN-EXIT                                    
              GO TO 0400-EOJ.                                                   
           GO TO 0100-CALL-GACDATE.                                             
      *                                                                         
       0020-DDMMYY.                                                             
      *                                                                         
           MOVE ZERO TO VDATE1-YYYY.                                            
           IF ZDATE-SL1 = '/'                                                   
              IF ZDATE-DD3 NOT NUMERIC                                          
                 GO TO 0300-ERROR                                               
              ELSE                                                              
                 NEXT SENTENCE                                                  
           ELSE                                                                 
              IF ZDATE-YY  NOT NUMERIC                                          
                 GO TO 0300-ERROR.                                              
           IF ZDATE-SL1 = '/'                                                   
               ADD  ZDATE-DD3 TO VDATE1-YYYY                                    
               MOVE ZDATE-MM3 TO VDATE1-MM                                      
             ELSE                                                               
               ADD  ZDATE-YY    TO VDATE1-YYYY                                  
               MOVE ZDATE-MM    TO VDATE1-MM.                                   
           MOVE ZDATE-DD    TO VDATE1-DD.                                       
           MOVE 'B'         TO VDATE-REQ-SERVICE.                               
           MOVE '2'         TO VDATE-REQ-DETAIL.                                
           GO TO 0100-CALL-GACDATE.                                             
      *                                                                         
       0030-DDMMMYY.                                                            
      *                                                                         
           MOVE ZDATE-ALPHA TO VDATE-EXT-DATE.                                  
           MOVE '1'         TO VDATE-REQ-SERVICE.                               
           MOVE '2'         TO VDATE-REQ-DETAIL.                                
           GO TO 0100-CALL-GACDATE.                                             
      *                                                                         
       0040-DDMMMYYYY.                                                          
      *                                                                         
           MOVE ZDATE-ALPHA TO VDATE-EXT-DATE.                                  
           MOVE '1'         TO VDATE-REQ-SERVICE.                               
           GO TO 0100-CALL-GACDATE.                                             
       0050-DDFRAYY.                                                            
      *                                                                         
           MOVE ZDATE-ALPHA TO VDATE-EXT-DATE.                                  
           MOVE '1'         TO VDATE-REQ-SERVICE.                               
           MOVE '2'         TO VDATE-REQ-DETAIL.                                
           GO TO 0100-CALL-GACDATE.                                             
      *                                                                         
       0060-DDFRAYYYY.                                                          
      *                                                                         
           MOVE ZDATE-ALPHA TO VDATE-EXT-DATE.                                  
           MOVE '1'         TO VDATE-REQ-SERVICE.                               
           GO TO 0100-CALL-GACDATE.                                             
      *                                                                         
       0070-YY-MM-DD.                                                           
      *                                                                         
           MOVE ZERO TO VDATE1-YYYY.                                            
           ADD  ZDATE-YY3   TO VDATE1-YYYY.                                     
           MOVE ZDATE-MM3   TO VDATE1-MM.                                       
           MOVE ZDATE-DD3   TO VDATE1-DD.                                       
           MOVE 'B'         TO VDATE-REQ-SERVICE.                               
           MOVE '2'         TO VDATE-REQ-DETAIL.                                
           GO TO 0100-CALL-GACDATE.                                             
      *                                                                         
       0080-MMDDYY.                                                             
      *                                                                         
           MOVE ZERO TO VDATE1-YYYY.                                            
           IF ZDATE-SL1 = '/'                                                   
              IF ZDATE-DD3 NOT NUMERIC                                          
                 GO TO 0300-ERROR                                               
              ELSE                                                              
                 NEXT SENTENCE                                                  
           ELSE                                                                 
              IF ZDATE-YY  NOT NUMERIC                                          
                 GO TO 0300-ERROR.                                              
           IF ZDATE-SL1 = '/'                                                   
               ADD  ZDATE-DD3 TO VDATE1-YYYY                                    
               MOVE ZDATE-MM3 TO VDATE1-DD                                      
             ELSE                                                               
               ADD  ZDATE-YY    TO VDATE1-YYYY                                  
               MOVE ZDATE-MM    TO VDATE1-DD.                                   
           MOVE ZDATE-DD    TO VDATE1-MM.                                       
           MOVE 'B'         TO VDATE-REQ-SERVICE.                               
           MOVE '2'         TO VDATE-REQ-DETAIL.                                
           GO TO 0100-CALL-GACDATE.                                             
      *                                                                         
       0100-CALL-GACDATE.                                                       
      *                                                                         
                                                                                
           CALL  GC2DATE   USING GACDATE-PARS.                                  
           MOVE ZDATE-TO   TO ZTAG.                                             
           PERFORM 0600-SEARCH THRU 0690-EXIT.                                  
           IF VDATE-RET-IND NOT = '0'                                           
               GO TO 0300-ERROR.                                                
           IF ZDATE-FROM > 'B' AND ZDATE-FROM < 'G' AND                         
              ZDATE-TO   > 'B' AND ZDATE-TO   < 'G'                             
               MOVE 'B' TO VDATE-REQ-SERVICE                                    
               CALL  GC2DATE  USING GACDATE-PARS.                               
           IF I > 8                                                             
               GO TO 0300-ERROR.                                                
           GO TO 0110-ALIS                                                      
                 0120-DDMMYY                                                    
                 0130-DDMMMYY                                                   
                 0140-DDMMMYYYY                                                 
                 0130-DDMMMYY                                                   
                 0140-DDMMMYYYY                                                 
                 0170-YY-MM-DD                                                  
                 0180-MMDDYY                                                    
                 DEPENDING ON I.                                                
           GO TO 0300-ERROR.                                                    
      *                                                                         
       0110-ALIS.                                                               
      *                                                                         
           IF VDATE-ALIS-YEAR1 = ZERO                                           
               GO TO 0300-ERROR.                                                
           MOVE VDATE-ALIS-YEAR1 TO ZDATE-TARGET-ALIS-YEAR.                     
           MOVE VDATE-ALIS-DAY1  TO ZDATE-TARGET-ALIS-DAY.                      
           GO TO 0400-EOJ.                                                      
      *                                                                         
       0120-DDMMYY.                                                             
      *                                                                         
           IF VDATE1-YYYY = ZERO                                                
               GO TO 0300-ERROR.                                                
           MOVE VDATE1-DD   TO ZDATE-TARGET-DD.                                 
           MOVE VDATE1-MM   TO ZDATE-TARGET-MM.                                 
           MOVE ZERO        TO ZDATE-TARGET-YY.                                 
           ADD  VDATE1-YYYY TO ZDATE-TARGET-YY.                                 
           GO TO 0400-EOJ.                                                      
      *                                                                         
       0130-DDMMMYY.                                                            
      *                                                                         
           IF VDATE1-YYYY = ZERO                                                
               GO TO 0300-ERROR.                                                
           MOVE VDATE-EXT-DATE TO ZDATE-DDMMM.                                  
           MOVE ZERO        TO ZDATE-TARGET-SHORTYY.                            
           ADD  VDATE1-YYYY TO ZDATE-TARGET-SHORTYY.                            
           GO TO 0400-EOJ.                                                      
      *                                                                         
       0140-DDMMMYYYY.                                                          
      *                                                                         
           IF VDATE1-YYYY = ZERO                                                
               GO TO 0300-ERROR.                                                
           MOVE VDATE-EXT-DATE TO ZDATE-TARGET-ALPHA.                           
           MOVE VDATE1-YYYY    TO ZDATE-TARGET-YYYY.                            
           GO TO 0400-EOJ.                                                      
      *                                                                         
       0170-YY-MM-DD.                                                           
      *                                                                         
           IF VDATE1-YYYY = ZERO                                                
               GO TO 0300-ERROR.                                                
           MOVE VDATE1-YYYYMMDD TO RJ-DATE.                                     
           MOVE RJ-DATE         TO ZDATE-TARGET-SYSTEM.                         
           GO TO 0400-EOJ.                                                      
      *                                                                         
       0180-MMDDYY.                                                             
      *                                                                         
           IF VDATE1-YYYY = ZERO                                                
               GO TO 0300-ERROR.                                                
           MOVE VDATE1-DD   TO ZDATE-TARGET-MM.                                 
           MOVE VDATE1-MM   TO ZDATE-TARGET-DD.                                 
           MOVE ZERO        TO ZDATE-TARGET-YY.                                 
           ADD  VDATE1-YYYY TO ZDATE-TARGET-YY.                                 
           GO TO 0400-EOJ.                                                      
      *                                                                         
       0300-ERROR.                                                              
      *                                                                         
           IF ZDATE-TO = 'A'                                                    
               MOVE '****' TO ZDATE-TARGET-ERROR4                               
           ELSE                                                                 
               IF ZDATE-TO = 'C' AND VDATE-REQ-DETAIL = 1                       
                   MOVE '*******' TO ZDATE-TARGET-ERROR7                        
               ELSE                                                             
                   IF ZDATE-TO = 'B' OR 'E'                                     
                       MOVE '******' TO ZDATE-TARGET-ERROR6                     
                   ELSE                                                         
                       IF (ZDATE-TO = 'C' AND VDATE-REQ-DETAIL = 2)             
                          OR ZDATE-TO = 'D'                                     
                           MOVE '*********' TO ZDATE-TARGET-ERROR9              
                       ELSE                                                     
                           MOVE '********' TO ZDATE-TARGET-ERROR8.              
      *                                                                         
       0400-EOJ.                                                                
      *                                                                         
      *    DISPLAY 'QDATEQ2 RETURNING:' ZDATE-TARGET                            
           GOBACK.                                                              
      *                                                                         
       0500-BLANK-RETURN.                                                       
      *                                                                         
           IF ZDATE-TO = 'A'                                                    
               MOVE '    ' TO ZDATE-TARGET-ERROR4                               
           ELSE                                                                 
               IF ZDATE-TO = 'C' AND VDATE-REQ-DETAIL = 1                       
                   MOVE '       ' TO ZDATE-TARGET-ERROR7                        
               ELSE                                                             
                   IF ZDATE-TO = 'B' OR 'E'                                     
                       MOVE '      ' TO ZDATE-TARGET-ERROR6                     
                   ELSE                                                         
                       IF (ZDATE-TO = 'C' AND VDATE-REQ-DETAIL = 2)             
                          OR ZDATE-TO = 'D'                                     
                           MOVE '         ' TO ZDATE-TARGET-ERROR9              
                       ELSE                                                     
                           MOVE '        ' TO ZDATE-TARGET-ERROR8.              
      *                                                                         
       0500-BLANK-RETURN-EXIT.                                                  
      *                                                                         
           EXIT.                                                                
      *                                                                         
       0600-SEARCH.                                                             
      *                                                                         
           MOVE ZERO TO I.                                                      
      *                                                                         
       0610-ITERATE.                                                            
      *                                                                         
           ADD 1 TO I.                                                          
           IF I > 8 OR ZTAG = ZDATE-CODE (I)                                    
               GO TO 0690-EXIT.                                                 
           GO TO 0610-ITERATE.                                                  
      *                                                                         
       0690-EXIT.                                                               
      *                                                                         
           EXIT.                                                                
