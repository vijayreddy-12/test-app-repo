       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VOCMP.                                                 
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  AUGUST 2005.                                              
      *DATE-COMPILED.                                                           
      *****************************************************************         
      *                                                                         
      *   COMMISSIONS SYSTEM                                                    
      *   HUB VO COMMISSIONS PROJECT                                            
      *                                                                         
      *   HUB:  VO AND MAINFRAME COMMISSIONS FEED MERGE                         
      *         (VOCOMM FEEDS MERGE)                                            
      *                                                                         
      *   THIS PROGRAM READS THE &&VODACM AND &&VODACR TEMP FILES               
      *   AND DETERMINES WHETHER THE AMOUNTS ARE EQUAL.                         
      *                                                                         
      *   CALLING PROGRAM:  NONE                                                
      *                                                                         
      *   CALLED PROGRAMS:  GAEDATSR                                            
      *                                                                         
      *   COPYBOOKS:                                                            
      *       GCOMXTR7                                                          
      *       GCOMDACR                                                          
      *       GARDSVRB                                                          
      *       HCSLRNAM                                                          
      *       ICBM                                                              
      *                                                                         
      *   INPUT  - TEMP FILE CONTAINING THE TOTAL COMMISSION                    
      *               AMOUNT AND THE TOTAL PREMIUM AMOUNT OF THE                
      *               VODACOM FILE (&&VODACM)                                   
      *            TEMP FILE CONTAINING THE TOTAL COMMISSION                    
      *               AMOUNT AND THE TOTAL PREMIUM AMOUNT OF THE                
      *               VODACRF FILE (&&VODACR)                                   
      *                                                                         
      *   OUTPUT - TEMP FILE INDICATING WHETHER OR NOT THE VO INPUT             
      *               AMOUNTS ARE EQUAL (&&VOCMPR)                              
      *                                                                         
      *   DESCRIPTION:                                                          
      *     READ THE &&VODACM FILE UNTIL END OF FILE.                           
      *       ADD UP THE GCXT-COMP-AMT'S OF ALL THE &&VODACM RECORDS.           
      *       ADD UP THE GCXT-PREM-AMT'S OF ALL THE &&VODACM RECORDS.           
      *     READ THE &&VODACR FILE UNTIL END OF FILE.                           
      *       ADD UP THE GDACR-CMAMT(1)'S OF ALL THE &&VODACR RECORDS.          
      *       ADD UP THE GDACR-CMAMT(2)'S OF ALL THE &&VODACR RECORDS.          
      *     COMPARE THE TOTAL GCXT-COMP-AMT WITH THE TOTAL                      
      *       GDACR-CMAMT(1).  IF THEY ARE NOT EQUAL, FLAG THIS BY              
      *       PUTTING THE VALUE 'N' IN THE INDICATOR COMM-AMT-EQ.               
      *     COMPARE THE TOTAL GCXT-PREM-AMT WITH THE TOTAL                      
      *       GDACR-CMAMT(2).  IF THEY ARE NOT EQUAL, FLAG THIS BY              
      *       PUTTING THE VALUE 'N' IN THE INDICATOR PREM-AMT-EQ.               
      *     IF COMM-AMT-EQ = 'N', WRITE OUT A RECORD IN &&VOCMPR                
      *       STATING THAT "THE COMMISSION AMOUNTS IN VODACOM AND               
      *       VODACRF FILES ARE NOT EQUAL".                                     
      *     IF PREM-AMT-EQ = 'N', WRITE OUT A RECORD IN &&VOCMPR                
      *       STATING THAT "THE PREMIUM AMOUNTS IN VODACOM AND                  
      *       VODACRF FILES ARE NOT EQUAL".                                     
      *                                                                         
      ******************************************************************        
      *    MMM/CCYY   -    NAME            -   DESCRIPTION                      
      *    AUG 2005        REGINA KNAUD        INITIAL CREATION.                
      *    OCT 2008        IBM                 COMPILER UPGRADE.                
      *                                                                         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVOCMPR          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       SOURCE-COMPUTER. IBM-370-165.                                            
       OBJECT-COMPUTER. IBM-370-165.                                            
                                                                                
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-VARIABLES.                                                        
           05  FILLER                      PIC X(32) VALUE                      
FXXTOK         '*** GC2VOCMP WORKING STORAGE ***'.                              
           05  WS-VODACM-EOF               PIC X.                               
           05  WS-VODACR-EOF               PIC X.                               
           05  WS-COMM-AMT-EQ              PIC X.                               
           05  WS-PREM-AMT-EQ              PIC X.                               
           05  WS-VODACM-COMP-AMT          PIC S9(12)V99.                       
           05  WS-VODACR-CMAMT1            PIC S9(12)V99.                       
           05  WS-VODACM-PREM-AMT          PIC S9(12)V99.                       
           05  WS-VODACR-CMAMT2            PIC S9(12)V99.                       
                                                                                
      *01  GCOMXTR7.                                                            
           COPY GCOMXTR7.                                                       
                                                                                
      *01  GCOMDACR.                                                            
           COPY GCOMDACR.                                                       
                                                                                
       01  VOCMPR.                                                              
           05  VOCMPR-REC                  PIC X(80).                           
                                                                                
      *----------------------------------------------------------------*        
      *    DATA SERVER ACTION VERBS                                             
      *----------------------------------------------------------------*        
       01  GAEDATSR-PARMS.                                                      
                                      COPY GARDSVRB.                            
                                                                                
       01  WS-GAEDATSR.                                                         
           05  GAEDATSR               PIC X(8) VALUE 'GAEDATSR'.                
           05  WS-GAEDATSR-VERB       PIC X(16).                                
                                                                                
      *----------------------------------------------------------------*        
      *    INTERFACE CONTROL BLOCK                                              
      *----------------------------------------------------------------*        
       01  ICBM.                                                                
                                      COPY ICBM.                                
                                                                                
      *----------------------------------------------------------------*        
      *    LOGICAL RECORD NAMES                                                 
      *----------------------------------------------------------------*        
       01  LOGICAL-RECORD-NAMES.                                                
                                      COPY HCSLRNAM.                            
              10  LR-VODACM-IN        PIC X(16) VALUE 'CARD-DATA-010'.          
              10  LR-VODACR-IN        PIC X(16) VALUE 'CARD-DATA-071'.          
              10  LR-VOCMPR-OUT       PIC X(16) VALUE 'PRINT-DATA-020'.         
                                                                                
      *------------------------------------------------------------             
      *    ABEND VARIABLES                                                      
      *-------------------------------------------------------------            
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X            PIC X(04).                             
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH       PIC S9(3) VALUE +133 COMP-3.           
               10  WTL-MESS-CC           PIC X(1)  VALUE SPACES.                
               10  WTL-MESS-TEXT         PIC X(132) VALUE SPACES.               
           05  WTL-FLAG                  PIC X(1)  VALUE 'B'.                   
           05  WTL-REPLY                 PIC X(3)  VALUE 'NO '.                 
           05  WTL-REPLY-AREA            PIC X(80) VALUE SPACES.                
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                     PIC X(80)                              
FXXTOK     VALUE 'GC2VOCMP - PROBLEM WRITING VOCMPR (COMMISSION)'.              
           05  WTL-2                     PIC X(80)                              
FXXTOK     VALUE 'GC2VOCMP - PROBLEM WRITING VOCMPR (PREMIUM)'.                 
           05  WTL-3                     PIC X(80)                              
FXXTOK     VALUE 'GC2VOCMP - PROBLEM CLOSING FILES'.                            
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY         OCCURS  3 TIMES.                       
               10  WTL-MESSAGE           PIC X(80).                             
       01  WTL-SUB                       PIC S9(4) COMP.                        
                                                                                
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
       0000-MAINLINE.                                                           
                                                                                
           PERFORM 1000-INITIALIZATION        THRU 1000-EXIT.                   
           PERFORM 2000-PROCESS-VODACM-VODACR THRU 2000-EXIT.                   
           PERFORM 7000-WRITE-VOCMPR          THRU 7000-EXIT.                   
           PERFORM 9000-FINISH                THRU 9000-EXIT.                   
                                                                                
           STOP RUN.                                                            
                                                                                
       0000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 1000-INITIALIZATION                                                     
      *     INITIALIZE VARIABLES.                                               
      ******************************************************************        
       1000-INITIALIZATION.                                                     
           MOVE 0                   TO WS-VODACM-COMP-AMT                       
                                       WS-VODACR-CMAMT1                         
                                       WS-VODACM-PREM-AMT                       
                                       WS-VODACR-CMAMT2.                        
                                                                                
FXXTOK     MOVE 'GC2VOCMP'          TO ICBM-PROGRAM-NAME.                       
           MOVE  LOW-VALUES         TO LINKAGE-CONTROL.                         
                                                                                
           MOVE 'N'                 TO WS-VODACM-EOF                            
                                       WS-VODACR-EOF.                           
                                                                                
           MOVE SPACE               TO WS-COMM-AMT-EQ                           
                                       WS-PREM-AMT-EQ.                          
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2000-PROCESS-VODACM-VODACR                                              
      *     READ AND PROCESS VODACM UNTIL THE END OF FILE.                      
      *     READ AND PROCESS VODACR UNTIL THE END OF FILE.                      
      ******************************************************************        
       2000-PROCESS-VODACM-VODACR.                                              
           MOVE LR-VODACM-IN        TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-FIRST        TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       GCOMXTRT                                 
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              COMPUTE WS-VODACM-COMP-AMT = WS-VODACM-COMP-AMT                   
                                         + GCXT-COMP-AMT                        
              COMPUTE WS-VODACM-PREM-AMT = WS-VODACM-PREM-AMT                   
                                         + GCXT-PREM-AMT                        
              PERFORM 2000A-PROCESS-VODACM     THRU 2000A-EXIT                  
                      UNTIL WS-VODACM-EOF   = 'Y'                               
           END-IF.                                                              
                                                                                
           MOVE LR-VODACR-IN        TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-FIRST        TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       GCOMDACR                                 
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              COMPUTE WS-VODACR-CMAMT1   = WS-VODACR-CMAMT1                     
                                         + GDACR-CMAMT(1)                       
              COMPUTE WS-VODACR-CMAMT2   = WS-VODACR-CMAMT2                     
                                         + GDACR-CMAMT(2)                       
              PERFORM 2000B-PROCESS-VODACR     THRU 2000B-EXIT                  
                      UNTIL WS-VODACR-EOF   = 'Y'                               
           END-IF.                                                              
                                                                                
           IF WS-VODACM-COMP-AMT  NOT = WS-VODACR-CMAMT1                        
              MOVE 'N'               TO WS-COMM-AMT-EQ                          
           END-IF.                                                              
                                                                                
           IF WS-VODACM-PREM-AMT  NOT = WS-VODACR-CMAMT2                        
              MOVE 'N'               TO WS-PREM-AMT-EQ                          
           END-IF.                                                              
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2000A-PROCESS-VODACM.                                                   
      ******************************************************************        
       2000A-PROCESS-VODACM.                                                    
                                                                                
           MOVE LR-VODACM-IN        TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-NEXT         TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       GCOMXTRT                                 
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              COMPUTE WS-VODACM-COMP-AMT = WS-VODACM-COMP-AMT                   
                                         + GCXT-COMP-AMT                        
              COMPUTE WS-VODACM-PREM-AMT = WS-VODACM-PREM-AMT                   
                                         + GCXT-PREM-AMT                        
           ELSE                                                                 
              MOVE 'Y' TO WS-VODACM-EOF                                         
           END-IF.                                                              
                                                                                
       2000A-EXIT.                                                              
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2000B-PROCESS-VODACR.                                                   
      ******************************************************************        
       2000B-PROCESS-VODACR.                                                    
                                                                                
           MOVE LR-VODACR-IN        TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-NEXT         TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       GCOMDACR                                 
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              COMPUTE WS-VODACR-CMAMT1   = WS-VODACR-CMAMT1                     
                                         + GDACR-CMAMT(1)                       
              COMPUTE WS-VODACR-CMAMT2   = WS-VODACR-CMAMT2                     
                                         + GDACR-CMAMT(2)                       
           ELSE                                                                 
              MOVE 'Y' TO WS-VODACR-EOF                                         
           END-IF.                                                              
                                                                                
       2000B-EXIT.                                                              
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 7000-WRITE-VOCMPR                                                       
      ******************************************************************        
       7000-WRITE-VOCMPR.                                                       
           IF WS-COMM-AMT-EQ = 'N'                                              
              MOVE 'THE COMMISSION AMOUNTS IN THE VODACOM AND VODACRF FI        
      -            'LES ARE NOT EQUAL' TO VOCMPR-REC                            
                                                                                
              MOVE LR-VOCMPR-OUT         TO LOGICAL-RECORD-NAME                 
              MOVE STORE-LR              TO WS-GAEDATSR-VERB                    
              CALL GAEDATSR           USING WS-GAEDATSR-VERB                    
                                            VOCMPR                              
                                            ICBM                                
              IF LR-STATUS-OK                                                   
                 NEXT SENTENCE                                                  
              ELSE                                                              
                 MOVE +1  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
              END-IF                                                            
           END-IF.                                                              
                                                                                
           IF WS-PREM-AMT-EQ = 'N'                                              
              MOVE 'THE PREMIUM AMOUNTS IN THE VODACOM AND VODACRF FILES        
      -            ' ARE NOT EQUAL' TO VOCMPR-REC                               
                                                                                
              MOVE LR-VOCMPR-OUT         TO LOGICAL-RECORD-NAME                 
              MOVE STORE-LR              TO WS-GAEDATSR-VERB                    
              CALL GAEDATSR           USING WS-GAEDATSR-VERB                    
                                            VOCMPR                              
                                            ICBM                                
              IF LR-STATUS-OK                                                   
                 NEXT SENTENCE                                                  
              ELSE                                                              
                 MOVE +2  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
              END-IF                                                            
           END-IF.                                                              
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9000-FINISH                                                             
      *     CLOSE THE FILES.                                                    
      ******************************************************************        
       9000-FINISH.                                                             
           MOVE SPACES      TO LOGICAL-RECORD-NAME.                             
           MOVE FINISH-LR   TO WS-GAEDATSR-VERB.                                
           CALL GAEDATSR USING WS-GAEDATSR-VERB                                 
                               LOGICAL-RECORD-NAME                              
                               ICBM.                                            
                                                                                
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +3  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       9000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9999-WTL-ABEND                                                          
      ******************************************************************        
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL'    USING  WTL-MESSAGES                                    
                                WTL-FLAG                                        
                                WTL-REPLY                                       
                                WTL-REPLY-AREA.                                 
                                                                                
           CALL 'ILBOABN0'  USING  WS-COMP-CODE.                                
                                                                                
       9999-EXIT.                                                               
           EXIT.                                                                
                                                                                
