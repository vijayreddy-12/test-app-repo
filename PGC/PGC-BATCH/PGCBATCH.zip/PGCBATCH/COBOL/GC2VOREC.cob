       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VOREC.                                                 
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  FEB 2006.                                                 
      ****************************************************************          
      *                                                                         
      *    COMMISSIONS VO GRECONDT CREATE                                       
      *                                                                         
      *    PRODUCE VO GRECONDT RECORDS  -  THE COMPLETE PROCESS IS              
      *    ACCOMPLISHED IN 2 STEPS.  THE FIRST STEP IS THIS                     
      *    PROGRAM INCCCCOM AND THE SECOND STEP IS THE PROGRAM                  
      *    GWVORECO.                                                            
      *    NOTE:  THE FIRST PROGRAM INCCCCOM CAN BE FOUND IN THE                
      *           PGK JOBSTREAM (JOB PGK1193).                                  
      *           THE SECOND PROGRAM GWVORECO CAN BE FOUND IN THE               
      *           PGC JOBSTREAM  (JOB PGC1100).                                 
      *                                                                         
      *    THE WHOLE PROCESS (INCCCCOM & GWVORECO) CAN BE                       
      *    DESCRIBED AS FOLLOWS:                                                
      *    THIS PROCESS COMPARES TWO VERSIONS OF A VO MASTER RECORD             
      *    LOOKING FOR CHANGES THAT ARE RELEVANT TO THE COMMISSIONS             
      *    ACCOUNT TERMINATION RECORDS.  THE CHANGES THAT ARE                   
      *    RELEVANT TO THE COMMISSIONS ACCOUNT TERMINATION CAN BE               
      *    ANY OF THE FOLLOWING CONDITIONS:                                     
      *      A.  IF THE VGI-ACCOUNT-STATUS HAS CHANGED FROM A                   
      *          NON-TERMINATED STATE (I.E., THE ACCOUNT STATUS                 
      *          IS NOT ANY OF THE VALUES 23, 24, 25, 26)                       
      *          TO A TERMINATED STATE (I.E., THE ACCOUNT STATUS                
      *          IS ANY OF THE VALUES 23, 24, 25, 26).                          
      *      B.  THE VGI-ACCOUNT-STATUS INDICATES A TERMINATED                  
      *          ACCOUNT AND THE TERMINATION LAST BILLING DATE                  
      *          (VCS-COMM-TERM-LASTBILL-DATE) HAS A DIFFERENT                  
      *          VALUE FROM ITS PREVIOUS VALUE.                                 
      *    IF ANY OF THE ABOVE CONDITIONS IS TRUE, DETERMINE WHETHER            
      *    OR NOT TO PRODUCE A TERMINATION RECORD BASED ON THE                  
      *    FOLLOWING CRITERIA:                                                  
      *      1.  IF THE VCS-COMM-TERM-LASTBILL-DATE IS NOT                      
      *          ZEROES, SPACES, LOW-VALUES, NOR HIGH-VALUES,                   
      *          PRODUCE A TERMINATION RECORD WITH ITS GRECONDT-                
      *          PRO-DATE AS THE YEAR AND MONTH OF THE                          
      *          VCS-COMM-TERM-LASTBILL-DATE AND THE                            
      *          DAY AS THE LAST DAY OF THAT MONTH.                             
      *      2.  IF THE VCS-COMM-TERM-LASTBILL-DATE IS                          
      *          ZEROES, SPACES, LOW-VALUES, OR HIGH-VALUES,                    
      *          AND IF THE VCS-ORPHAN-TERM-PROCESS-DT IS NOT                   
      *          ZEROES, SPACES, LOW-VALUE, NOR HIGH-VALUES,                    
      *          AND EITHER ONE OF THE VTM-EFFECTIVE-DATE(N)                    
      *          OR THE VTM-PROCESSED-DATE(N) FALLS BETWEEN                     
      *          THE (GWCORGRACCT.NEXT-RECON-DATE AND                           
      *          (GWCORGRACCT.NEXT-RECON-DATE - 65 DAYS)),                      
      *          INCLUSIVE, PRODUCE A TERMINATION RECORD                        
      *          WITH ITS GRECONDT-PRO-DATE EQUAL TO                            
      *          (GWCORGRACCT.NEXT-RECON-DATE + 60 DAYS),                       
      *          MAKING SURE THAT THE DAY IS THE LAST DAY OF                    
      *          THAT MONTH (IF NEEDED, ADJUST THE DAY TO THE                   
      *          LAST DAY OF THAT MONTH).                                       
      *          (NOTE:  THIS TERMINATION RECORD WILL BE FED                    
      *          TO THE JOB THAT RUNS THE PROGRAM GWCOCUP2.                     
      *          GWCOCUP2 IS THE PROGRAM THAT UPDATES THE                       
      *          COMMISSIONS DATABASE WITH THE TERMINATION                      
      *          RECORDS.  IT USES THE LATER OF THE TERMINATION                 
      *          PROCESS DATE OR THE TERMINATION EFFECTIVE DATE                 
      *          TO UPDATE THE COMMISSIONS DATABASE                             
      *          GWCORGRACCT.NEXT-RECON-DATE.)                                  
      *      3.  IF THE VCS-COMM-TERM-LASTBILL-DATE IS                          
      *          ZEROES, SPACES, LOW-VALUES, OR HIGH-VALUES,                    
      *          AND IF VCS-ORPHAN-TERM-PROCESS-DT IS ZEROES,                   
      *          SPACES, LOW-VALUES, OR HIGH-VALUES,                            
      *          PRODUCE A TERMINATION RECORD WITH ITS                          
      *          GRECONDT-PRO-DATE AS HIGH DATE 999365.                         
      *                                                                         
      *                                                                         
      ****************************************************************          
      * MAINTENANCE LOG:                                                        
      *                                                                         
      * DATE        DEVELOPER    DESCRIPTION                                    
      * ----------------------------------------------------------------        
      * 2006-02-06  RLKNAUD      INITIAL CREATION.                              
      *                                                                         
      * 2008-10-03  IBM          COMPILER UPGRADE.                              
      ****************************************************************  00226009
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVORECO          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(32)     VALUE                        
FXXTOK     'GC2VOREC WS STARTS HERE*********'.                                  
                                                                                
       01  WS-FIELDS.                                                           
FXXTOK     05  WS-PROGRAM-ID             PIC X(8)  VALUE 'GC2VOREC'.            
           05  WS-PREGRECONDT-EOF        PIC X.                                 
           05  WS-CREATE-GRECONDT-IND    PIC X.                                 
           05  WS-NUM-DAYS               PIC S999.                              
           05  WS-RECON-PLUS60DAYS-DATE.                                        
               10  WS-RECON-PLUS60DAYS-YEAR  PIC S9(3) COMP-3.                  
               10  WS-RECON-PLUS60DAYS-DAY   PIC S9(3) COMP-3.                  
           05  WS-RECON-LESSNDAYS-DATE.                                         
               10  WS-RECON-LESSNDAYS-YEAR  PIC S9(3) COMP-3.                   
               10  WS-RECON-LESSNDAYS-DAY   PIC S9(3) COMP-3.                   
           05  WS-MONTHDAY-TABLE.                                               
               10  FILLER                   PIC X(30)                           
                   VALUE 'JAN31FEB28MAR31APR30MAY31JUN30'.                      
               10  FILLER                   PIC X(30)                           
                   VALUE 'JUL31AUG31SEP30OCT31NOV30DEC31'.                      
           05  WS-MONTHDAY-TABL REDEFINES WS-MONTHDAY-TABLE.                    
               10  WS-MONTHDAY           OCCURS 12.                             
                   15  WS-MONTHDAY-MONTH PIC X(3).                              
                   15  WS-MONTHDAY-DAY   PIC 99.                                
           05  WS-DDMMMYY.                                                      
               10  WS-DD                 PIC 99.                                
               10  WS-MMM                PIC X(3).                              
               10  WS-YY                 PIC 99.                                
                                                                                
      *----------------------------------------------------------------         
      *    DATA SERVER (GAEDATSR) PARMS                                         
      *----------------------------------------------------------------         
       01  ICBM.                                                                
           COPY ICBM.                                                           
                                                                                
       01  GAEDATSR-PARMS.                                                      
           COPY GARDSVRB.                                                       
                                                                                
       01  WS-GAEDATSR.                                                         
           05  GAEDATSR                 PIC X(8)  VALUE 'GAEDATSR'.             
           05  WS-GAEDATSR-VERB         PIC X(16)     VALUE SPACES.             
                                                                                
       01  LOGICAL-RECORD-NAMES.                                                
           05  LR-NODAY-IN         VALUE 'CARD-DATA-011   ' PIC X(16).          
           05  LR-PRE-GRECONDT-IN  VALUE 'CARD-DATA-012   ' PIC X(16).          
           05  LR-VO-GRECONDT-OUT  VALUE 'PRINT-DATA-021  ' PIC X(16).          
                                                                                
      *----------------------------------------------------------------         
      *    NUMBER OF DAYS PARM RECORD                                           
      *----------------------------------------------------------------         
       01  WS-NODAY-RECORD.                                                     
           05  WS-NUMBER-OF-DAYS        PIC 999.                                
           05  FILLER                   PIC X(77).                              
                                                                                
      *------------------------------------------------------------             
      *    DATE CONVERSION PARMS                                                
      *------------------------------------------------------------             
       01  GC2DATE-PARMS.                                                       
           COPY GARDATEP.                                                       
                                                                                
       01  GC2DATE                    PIC X(8) VALUE 'GC2DATE'.                 
                                                                                
      *----------------------------------------------------------------         
      *    COMMISSIONS VO ACCOUNT TERMINATION PRE-EXTRACT RECORD                
      *----------------------------------------------------------------         
       01  PRE-GRECONDT.                                                        
           05  PRE-GRECONDT-REC-TYPE        PIC X(1).                           
REN        05  PRE-GRECONDT-GROUP           PIC S9(7)  COMP-3.                  
           05  PRE-GRECONDT-ACCT            PIC X(3).                           
           05  PRE-GRECONDT-STATUS          PIC X(2).                           
           05  PRE-GRECONDT-EFF-DATE.                                           
               10  PRE-GRECONDT-EFF-YEAR    PIC S9(3)  COMP-3.                  
               10  PRE-GRECONDT-EFF-DAY     PIC S9(3)  COMP-3.                  
           05  PRE-GRECONDT-PRO-DATE.                                           
               10  PRE-GRECONDT-PRO-YEAR    PIC S9(3)  COMP-3.                  
               10  PRE-GRECONDT-PRO-DAY     PIC S9(3)  COMP-3.                  
           05  PRE-CLAIMS-LSTBIL-IND        PIC X.                              
           05  PRE-HIGH-DATE-IND            PIC X.                              
           05  PRE-NEXT-RECON-60-IND        PIC X.                              
           05  PRE-CLAIMS-LSTBIL-DATE.                                          
               10  PRE-CLAIMS-LSTBIL-YEAR   PIC S9(3)  COMP-3.                  
               10  PRE-CLAIMS-LSTBIL-DAY    PIC S9(3)  COMP-3.                  
           05  PRE-VTM-EFFECTIVE-DATE.                                          
               10  PRE-VTM-EFFECTIVE-YEAR   PIC S9(3)  COMP-3.                  
               10  PRE-VTM-EFFECTIVE-DAY    PIC S9(3)  COMP-3.                  
           05  PRE-VTM-PROCESSED-DATE.                                          
               10  PRE-VTM-PROCESSED-YEAR   PIC S9(3)  COMP-3.                  
               10  PRE-VTM-PROCESSED-DAY    PIC S9(3)  COMP-3.                  
           05  FILLER                       PIC X(48).                          
                                                                                
      *----------------------------------------------------------------         
      *    COMMISSIONS VO ACCOUNT TERMINATION EXTRACT RECORD                    
      *----------------------------------------------------------------         
      *01  GRECONDT.                                                            
           COPY GRECOND7.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE -  RECORD DESCRIPTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGRACCT                     '.                                  
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
                                                                                
       01  WS-END                    PIC X(32)      VALUE                       
FXXTOK     'GC2VOREC WS ENDS   HERE*********'.                                  
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2VOREC'         TO FCCSPL-CURR-PGM.                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       0000-GWVORECO.                                                           
                                                                                
FXXTOK     MOVE 'GC2VOREC' TO PROGRAM-NAME.                                     
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2VOREC' TO PROGRAM-NAME.                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   READY GW-COMP-AREA1    USAGE-MODE IS RETRIEVAL.                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           PERFORM 1000-INITIALIZATION       THRU 1000-EXIT.                    
                                                                                
           PERFORM 2000-PROCESS-PRE-GRECONDT THRU 2000-EXIT                     
                   UNTIL WS-PREGRECONDT-EOF = 'Y'.                              
                                                                                
           PERFORM 9000-FINALIZATION         THRU 9000-EXIT.                    
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
                                                                                
       1000-INITIALIZATION.                                                     
      ****************************************************************          
      *    INITIALIZATION.                                                      
      ****************************************************************          
                                                                                
           MOVE WS-PROGRAM-ID      TO ICBM-PROGRAM-NAME.                        
                                                                                
           MOVE 'N'                      TO WS-PREGRECONDT-EOF.                 
           MOVE OBTAIN-FIRST             TO WS-GAEDATSR-VERB.                   
           PERFORM 6000-READ-PREGRECONDT THRU 6000-EXIT.                        
           IF WS-PREGRECONDT-EOF = 'Y'                                          
              DISPLAY 'NO TERMINATION RECORDS, GRECONDT IS EMPTY.'              
           END-IF.                                                              
                                                                                
           MOVE OBTAIN-FIRST       TO WS-GAEDATSR-VERB.                         
           MOVE LR-NODAY-IN        TO LOGICAL-RECORD-NAME.                      
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       WS-NODAY-RECORD                          
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              DISPLAY 'NO PARM RECORD FOUND.'                                   
              MOVE 'Y' TO WS-PREGRECONDT-EOF                                    
           END-IF.                                                              
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2000-PROCESS-PRE-GRECONDT.                                               
      ******************************************************************        
      *                                                                         
      ******************************************************************        
           IF PRE-GRECONDT-REC-TYPE = 'D'                                       
              PERFORM 3000-CREATE-GRECONDT-D-RECORD THRU 3000-EXIT              
           ELSE                                                                 
              PERFORM 4000-CREATE-GRECONDT-T-RECORD THRU 4000-EXIT              
           END-IF.                                                              
                                                                                
           MOVE OBTAIN-NEXT              TO WS-GAEDATSR-VERB.                   
           PERFORM 6000-READ-PREGRECONDT THRU 6000-EXIT.                        
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       3000-CREATE-GRECONDT-D-RECORD.                                           
      ******************************************************************        
      *                                                                         
      ******************************************************************        
           MOVE SPACES TO GRECONDT.                                             
           MOVE PRE-GRECONDT-REC-TYPE  TO GRECONDT-REC-TYPE.                    
           MOVE PRE-GRECONDT-EFF-YEAR  TO GRECONDT-EFF-YEAR.                    
           MOVE PRE-GRECONDT-EFF-DAY   TO GRECONDT-EFF-DAY.                     
                                                                                
           PERFORM 7000-WRITE-GRECONDT-RECORD THRU 7000-EXIT.                   
                                                                                
       3000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       4000-CREATE-GRECONDT-T-RECORD.                                           
      ******************************************************************        
      *                                                                         
      ******************************************************************        
           MOVE 'N' TO WS-CREATE-GRECONDT-IND.                                  
                                                                                
           MOVE SPACES TO GRECONDT.                                             
           MOVE PRE-GRECONDT-REC-TYPE  TO GRECONDT-REC-TYPE.                    
           MOVE PRE-GRECONDT-GROUP     TO GRECONDT-GROUP.                       
           MOVE PRE-GRECONDT-ACCT      TO GRECONDT-ACCT.                        
           MOVE PRE-GRECONDT-STATUS    TO GRECONDT-STATUS.                      
           MOVE PRE-GRECONDT-EFF-YEAR  TO GRECONDT-EFF-YEAR.                    
           MOVE PRE-GRECONDT-EFF-DAY   TO GRECONDT-EFF-DAY.                     
                                                                                
           IF PRE-NEXT-RECON-60-IND = 'Y'                                       
              PERFORM 4100-PROCESS-GWCORGRACCT THRU 4100-EXIT                   
              IF (WS-RECON-LESSNDAYS-DATE NOT > PRE-VTM-EFFECTIVE-DATE          
                  AND                                                           
                  PRE-VTM-EFFECTIVE-DATE NOT > NEXT-RECON-DATE                  
                                               OF GWCORGRACCT)                  
                 OR                                                             
                 (WS-RECON-LESSNDAYS-DATE NOT > PRE-VTM-PROCESSED-DATE          
                  AND                                                           
                  PRE-VTM-PROCESSED-DATE NOT > NEXT-RECON-DATE                  
                                               OF GWCORGRACCT)                  
                 MOVE WS-RECON-PLUS60DAYS-YEAR TO GRECONDT-PRO-YEAR             
                 MOVE WS-RECON-PLUS60DAYS-DAY  TO GRECONDT-PRO-DAY              
                 MOVE 'Y'                      TO WS-CREATE-GRECONDT-IND        
              END-IF                                                            
           ELSE                                                                 
              IF PRE-CLAIMS-LSTBIL-IND = 'Y'                                    
                 MOVE '9'               TO VDATE-REQ-SERVICE                    
                 MOVE 'B'               TO VDATE-REQ-BASIS                      
                 MOVE '2'               TO VDATE-REQ-DETAIL                     
                 MOVE 'E'               TO VDATE-REQ-LANGUAGE                   
                 MOVE PRE-CLAIMS-LSTBIL-YEAR                                    
                                        TO VDATE-ALIS-YEAR1                     
                 MOVE PRE-CLAIMS-LSTBIL-DAY                                     
                                        TO VDATE-ALIS-DAY1                      
                 CALL GC2DATE USING GC2DATE-PARMS                               
                 MOVE WS-MONTHDAY-DAY (VDATE-MM)   TO WS-DD                     
                 MOVE WS-MONTHDAY-MONTH (VDATE-MM) TO WS-MMM                    
                 MOVE VDATE-YY                     TO WS-YY                     
                                                                                
                 MOVE '1'               TO VDATE-REQ-SERVICE                    
                 MOVE 'B'               TO VDATE-REQ-BASIS                      
                 MOVE '2'               TO VDATE-REQ-DETAIL                     
                 MOVE 'E'               TO VDATE-REQ-LANGUAGE                   
                 MOVE WS-DD             TO VDATE-EXT-DAY                        
                 MOVE WS-MMM            TO VDATE-EXT-MONTH                      
                 MOVE WS-YY             TO VDATE-EXT-YEAR-SHORT                 
                 CALL GC2DATE USING GC2DATE-PARMS                               
                 MOVE VDATE-ALIS-YEAR1  TO GRECONDT-PRO-YEAR                    
                 MOVE VDATE-ALIS-DAY1   TO GRECONDT-PRO-DAY                     
                 MOVE 'Y'               TO WS-CREATE-GRECONDT-IND               
              ELSE                                                              
                 IF PRE-HIGH-DATE-IND = 'Y'                                     
                    MOVE +999                TO GRECONDT-PRO-YEAR               
                    MOVE +365                TO GRECONDT-PRO-DAY                
                    MOVE 'Y'                 TO WS-CREATE-GRECONDT-IND          
                 END-IF                                                         
              END-IF                                                            
           END-IF.                                                              
                                                                                
           IF WS-CREATE-GRECONDT-IND = 'Y'                                      
              PERFORM 7000-WRITE-GRECONDT-RECORD THRU 7000-EXIT                 
           END-IF.                                                              
                                                                                
       4000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       4100-PROCESS-GWCORGRACCT.                                                
      ****************************************************************          
      * GET THE GWCORGRACCT NEXT-RECON-DATE FOR THIS GROUP/ACCOUNT.             
      * CALCULATE THE DATE WHICH IS N DAYS EARLIER THAN THE                     
      *     GWCORGRACCT NEXT-RECON-DATE.                                        
      * CALCULATE THE DATE WHICH IS 60 DAYS LATER THAN THE                      
      *     GWCORGRACCT NEXT-RECON-DATE; ADJUST THE RESULTING                   
      *     DATE TO THE LAST DAY OF THE MONTH.                                  
      ****************************************************************          
           MOVE +0                  TO WS-RECON-LESSNDAYS-YEAR                  
                                       WS-RECON-LESSNDAYS-DAY                   
                                       WS-RECON-PLUS60DAYS-YEAR                 
                                       WS-RECON-PLUS60DAYS-DAY                  
                                                                                
           COMPUTE WS-NUM-DAYS = WS-NUMBER-OF-DAYS * (-1).                      
                                                                                
           MOVE PRE-GRECONDT-GROUP  TO GROUP-NUMBER OF GWCORGRACCT.             
           MOVE PRE-GRECONDT-ACCT   TO GR-ACCOUNT   OF GWCORGRACCT.             
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 MOVE +0 TO NEXT-RECON-YEAR OF GWCORGRACCT                      
                 MOVE +0 TO NEXT-RECON-DAY  OF GWCORGRACCT                      
                 DISPLAY PRE-GRECONDT-GROUP '/' PRE-GRECONDT-ACCT               
                           'NOT FOUND ON COMMISSION DB'                         
                 GO TO 4100-EXIT.                                               
                                                                                
           MOVE '4'               TO VDATE-REQ-SERVICE.                         
           MOVE 'B'               TO VDATE-REQ-BASIS.                           
           MOVE '2'               TO VDATE-REQ-DETAIL.                          
           MOVE 'E'               TO VDATE-REQ-LANGUAGE.                        
           MOVE WS-NUM-DAYS       TO VDATE-ADJUST-DAYS.                         
           MOVE +0                TO VDATE-ADJUST-MONTHS                        
                                     VDATE-ADJUST-YEARS.                        
           MOVE NEXT-RECON-YEAR OF GWCORGRACCT                                  
                                  TO VDATE-ALIS-YEAR1.                          
           MOVE NEXT-RECON-DAY  OF GWCORGRACCT                                  
                                  TO VDATE-ALIS-DAY1.                           
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           MOVE VDATE-ALIS-YEAR2  TO WS-RECON-LESSNDAYS-YEAR.                   
           MOVE VDATE-ALIS-DAY2   TO WS-RECON-LESSNDAYS-DAY.                    
                                                                                
           MOVE '4'               TO VDATE-REQ-SERVICE.                         
           MOVE 'B'               TO VDATE-REQ-BASIS.                           
           MOVE '2'               TO VDATE-REQ-DETAIL.                          
           MOVE 'E'               TO VDATE-REQ-LANGUAGE.                        
           MOVE +60               TO VDATE-ADJUST-DAYS.                         
           MOVE +0                TO VDATE-ADJUST-MONTHS                        
                                     VDATE-ADJUST-YEARS.                        
           MOVE NEXT-RECON-YEAR OF GWCORGRACCT                                  
                                  TO VDATE-ALIS-YEAR1.                          
           MOVE NEXT-RECON-DAY  OF GWCORGRACCT                                  
                                  TO VDATE-ALIS-DAY1.                           
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           MOVE VDATE-ALIS-YEAR2  TO WS-RECON-PLUS60DAYS-YEAR.                  
           MOVE VDATE-ALIS-DAY2   TO WS-RECON-PLUS60DAYS-DAY.                   
                                                                                
           MOVE '9'               TO VDATE-REQ-SERVICE.                         
           MOVE 'B'               TO VDATE-REQ-BASIS.                           
           MOVE '2'               TO VDATE-REQ-DETAIL.                          
           MOVE 'E'               TO VDATE-REQ-LANGUAGE.                        
           MOVE WS-RECON-PLUS60DAYS-YEAR                                        
                                  TO VDATE-ALIS-YEAR1.                          
           MOVE WS-RECON-PLUS60DAYS-DAY                                         
                                  TO VDATE-ALIS-DAY1.                           
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           MOVE WS-MONTHDAY-DAY (VDATE-MM)   TO WS-DD.                          
           MOVE WS-MONTHDAY-MONTH (VDATE-MM) TO WS-MMM.                         
           MOVE VDATE-YY                     TO WS-YY.                          
                                                                                
           MOVE '1'               TO VDATE-REQ-SERVICE.                         
           MOVE 'B'               TO VDATE-REQ-BASIS.                           
           MOVE '2'               TO VDATE-REQ-DETAIL.                          
           MOVE 'E'               TO VDATE-REQ-LANGUAGE.                        
           MOVE WS-DD             TO VDATE-EXT-DAY.                             
           MOVE WS-MMM            TO VDATE-EXT-MONTH.                           
           MOVE WS-YY             TO VDATE-EXT-YEAR-SHORT.                      
           CALL GC2DATE USING GC2DATE-PARMS.                                    
           MOVE VDATE-ALIS-YEAR1  TO WS-RECON-PLUS60DAYS-YEAR.                  
           MOVE VDATE-ALIS-DAY1   TO WS-RECON-PLUS60DAYS-DAY.                   
                                                                                
       4100-EXIT.                                                               
           EXIT.                                                                
                                                                                
       6000-READ-PREGRECONDT.                                                   
      ****************************************************************          
      *  READ THE INPUT FILE PRE-GRECONDT.                                      
      ****************************************************************          
           MOVE LR-PRE-GRECONDT-IN TO LOGICAL-RECORD-NAME.                      
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       PRE-GRECONDT                             
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE 'Y' TO WS-PREGRECONDT-EOF                                    
           END-IF.                                                              
                                                                                
       6000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       7000-WRITE-GRECONDT-RECORD.                                              
      ******************************************************************        
      *    WRITE THE VO GRECONDT RECORD                                         
      ******************************************************************        
                                                                                
           MOVE STORE-LR            TO WS-GAEDATSR-VERB.                        
           MOVE LR-VO-GRECONDT-OUT  TO LOGICAL-RECORD-NAME.                     
                                                                                
           CALL GAEDATSR            USING WS-GAEDATSR-VERB                      
                                    GRECONDT                                    
                                    ICBM.                                       
                                                                                
           IF  LR-STATUS-OK                                                     
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'ERROR WRITING VO GRECONDT RECORD.'                      
               MOVE 'Y' TO WS-PREGRECONDT-EOF                                   
           END-IF.                                                              
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       9000-FINALIZATION.                                                       
      **************************************************************            
      *    CLOSE FILES                                                          
      **************************************************************            
                                                                                
           MOVE FINISH-LR           TO WS-GAEDATSR-VERB.                        
           MOVE SPACES              TO LOGICAL-RECORD-NAME.             02161056
                                                                                
           CALL GAEDATSR            USING WS-GAEDATSR-VERB                      
                                    LOGICAL-RECORD-NAME                         
                                    ICBM.                                       
                                                                                
       9000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *=================================================================        
      *                                                                         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      ******************** END OF PROGRAM ********************                  
                                                                                
