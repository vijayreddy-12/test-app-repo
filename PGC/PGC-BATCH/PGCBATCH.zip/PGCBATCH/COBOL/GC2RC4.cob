       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2RC4.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
      *    THIS PROGRAM READS THE DATE RECORDS FILE EXTRACTED BY                
      *        GWCOCRC1 TO COMPLETE THE RECONCILIATION UPDATE BY                
      *        SETTING UP THE NEW RECONCILIATION DATES FOR THE                  
      *        ACCOUNTS WHICH HAVE BEEN RECONCILED IN THE CURRENT RUN.          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * HISTORY:  20JULY87  S WAGLER  -PUT CONTROL LOGIC IN TO CONTROL*         
      *                     L HAMPTON -THE RECONCILIATION PROCESS AND *         
      *                                MAKE SURE WE HAVE PICKED UP THE*         
      *                                CORRECT FILE.                  *         
      *                                                               *         
      *  NOV/90   M DRURY       RECOMPILE TO PICK UP NEW VERSION      *         
      *                         OF GWCORGRACCT RECORD CHANGED IN REL3 *         
      *                                                                         
      *    OCT/08 IBM                                                           
      *         - ENTERPRISE COMPILER UPGRADE                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCRC4          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO02 WITHIN SCGWCO01.                                            
      /                                                                         
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2RC4 W-S STARTS HERE **'.                                  
                                                                                
       01  WS-PARAMETERS.                                                       
                                                                                
           05  EOF-SWITCH                 VALUE 'N'       PIC X.                
               88  EOF-ON-EXTRACT         VALUE 'Y'.                            
           05  WS-CONT-PROC-FLAG          VALUE 'Y'       PIC X.                
           05  QDATE-FORMATC              VALUE 'CA'      PIC XX.               
           05  WS-ALIS-RUN-DATE.                                                
               10  FILLER    VALUE ZERO   COMP-3          PIC S9(3).            
               10  FILLER    VALUE ZERO   COMP-3          PIC S9(3).            
      /                                                                         
       01  FILLER                         PIC X(32)       VALUE                 
                                             'EXTRACT RECORD'.                  
       01  EXTRACT-DATE-REC.                                                    
                             COPY GWCORC73 REPLACING                            
                               ==01  EXT-RECON-DATE-RECORD.== BY ====.          
                                                                                
           05  READ-PARMS.                                                      
               10  DLSD-SYSNNN      PIC X(6)          VALUE 'SYS010'.           
               10  DLSD-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSD-REC-SIZE    PIC 9(5)          VALUE 36.                 
               10  DLSD-BLK-SIZE    PIC 9(5)          VALUE 3600.               
               10  DLSD-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSD-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
           05  RUNDATE-READ-PARMS.                                              
               10  DLSR-SYSNNN      PIC X(6)          VALUE 'SYS019'.           
               10  DLSR-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSR-REC-SIZE    PIC 9(5)          VALUE 80.                 
               10  DLSR-BLK-SIZE    PIC 9(5)          VALUE 80.                 
               10  DLSR-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSR-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   MESSAGES USED FOR THE ERROR LOGIC USING THE CALL TO WTL     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       01  WTL-AREA.                                                            
           05  WTL-FLAG             PIC X             VALUE 'B'.                
           05  WTL-REPLY-YES        PIC XXX           VALUE 'YES'.              
           05  WTL-REPLY-NO         PIC XXX           VALUE 'NO '.              
           05  WTL-REPLY            PIC XXX           VALUE SPACES.             
           05  WTL-REPLY-AREA       PIC X(10)         VALUE SPACES.             
       01  WTL-MESSAGE-AREA.                                                    
           05  FILLER        COMP-3 PIC S9(3)         VALUE +121.               
           05  FILLER               PIC X             VALUE SPACES.             
           05  WTL-MESSAGE          PIC X(120)        VALUE SPACES.             
       01  WTL-ERROR-MESSAGES.                                                  
           05  ERR-MESS1.                                                       
               10  FILLER           PIC X(40)         VALUE                     
                   '*** INVALID RUNDATE FORMAT            '.                    
           05  ERR-MESS2.                                                       
               10  FILLER           PIC X(50)         VALUE                     
                   '*** FILE CONTROL DATE DOES NOT MATCH RUNDATE'.              
           05  ERR-MESS3.                                                       
               10  FILLER           PIC X(50)         VALUE                     
                   '*** SEVERE ERROR - CHECK RESTART JCL  '.                    
      /                                                                         
       COPY GWCORRCD.                                                           
                                                                                
       COPY GWCORRRD.                                                           
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
                                       'SUBSCHEMA STARTS HERE'.                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
                                       'GWCORCNTL STARTS HERE'.                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - CONTROL RECORD DESCRIPTION                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCNTL                                                               
CPYNME     COPY GCICNTL.                                                        
      /                                                                         
       01  FILLER                 PIC X(32)       VALUE                         
                                     'GRACCT RECORD STARTS HERE'.               
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
FXXTOK                                '** GC2RC4 W-S ENDS HERE **'.             
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO02'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2RC4'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       MAINLINE.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                PROGRAM MAINLINE                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 000-INITIALIZE.                                              
           IF WS-CONT-PROC-FLAG = 'Y'                                           
               PERFORM 200-PROCESS-RECORD THRU 299-EXIT                         
                   UNTIL EOF-ON-EXTRACT.                                        
           MOVE +4 TO DLSR-RET-CODE.                                            
           PERFORM 300-READ-RUNDATE THRU 399-EXIT.                              
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       000-INITIALIZE.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREAS TO BE ACCESSED                             *         
      *     READ RUN DATE AND FILE CONTROL DATE                       *         
      *     EDIT TO MAKE SURE YOU HAVE PICKED UP THE CORRECT FILE     *         
      *     GET CONTROL RECORD AND MAKE SURE THAT ALL PREVIOUS STEPS  *         
      *        HAVE RUN SUCCESSFULLY                                  *         
      *     UPDATE CONTROL RECORD TO INDICATE THAT THE RECONCILIATION *         
      *        PROCESS IS COMPLETE.                                   *         
      *     READ NEXT EXTRACT RECORD                                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
FXXTOK     MOVE 'GC2RC4' TO PROGRAM-NAME.                                       
      *%   BIND RUN-UNIT.                                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND GWCORCNTL.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGRACCT.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           PERFORM 300-READ-RUNDATE THRU 399-EXIT.                              
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         PROGRAM-RUN-DATE                                  
MAN02                         WS-ALIS-RUN-DATE.                                 
           IF WS-ALIS-RUN-DATE = '****'                                         
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS1    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           PERFORM 290-READ-EXTRACT THRU 299-EXIT.                              
           MOVE EXTRACT-DATE-REC TO FILE-CONTROL-DATE-RECORD.                   
                                                                                
           IF FILE-CONTROL-DATE EQUAL WS-ALIS-RUN-DATE                          
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS2    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
      *%   OBTAIN FIRST GWCORCNTL WITHIN GW-COMP-AREA1.                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           IF COMM-SCR-RECON-IND = 'Y' AND                                      
              NAP-RECON-IND = 'Y' AND                                           
              RECON-DATE-UPDATE-IND = 'N'                                       
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'N' TO WS-CONT-PROC-FLAG                                    
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS3    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           MOVE 'Y' TO RECON-DATE-UPDATE-IND.                                   
           MOVE FILE-CONTROL-DATE TO LAST-RECON-RUN-DATE.                       
      *%   MODIFY GWCORCNTL.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           MOVE 'Y' TO WS-CONT-PROC-FLAG.                                       
           PERFORM 290-READ-EXTRACT THRU 299-EXIT.                              
      /                                                                         
       200-PROCESS-RECORD.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  GET OWNER RECORD                                                 
      *        CHANGE RECONCILIATION DATES                            *         
      *        MODIFY GRACCT                                          *         
      *     -  READ NEXT EXTRACT                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE EXT-DATE-GROUP-NUMBER TO GROUP-NUMBER.                          
           MOVE EXT-DATE-GROUP-ACCOUNT TO GR-ACCOUNT.                           
      *%   OBTAIN CALC GWCORGRACCT.                                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           MOVE EXT-LAST-RECON-DATE TO LAST-RECON-DATE.                         
           MOVE EXT-NEXT-RECON-DATE TO NEXT-RECON-DATE.                         
      *%   MODIFY GWCORGRACCT.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       290-READ-EXTRACT.                                                        
                                                                                
           CALL 'DLSREAD' USING DLSD-SYSNNN                                     
                                DLSD-RET-CODE                                   
                                EXTRACT-DATE-REC                                
                                DLSD-REC-SIZE                                   
                                DLSD-BLK-SIZE                                   
                                DLSD-FORMAT                                     
                                DLSD-REC-COUNT.                                 
                                                                                
           IF  DLSD-RET-CODE = 0                                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  DLSD-RET-CODE = 4                                            
                   MOVE 'Y' TO EOF-SWITCH                                       
               ELSE                                                             
                   DISPLAY 'ERROR READING EXTRACT - ABEND' UPON CONSOLE         
FXXTOK             GO TO 799-SQL-STATUS.                                        
                                                                                
       299-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       300-READ-RUNDATE.                                                        
                                                                                
           CALL 'DLSREAD' USING DLSR-SYSNNN                                     
                                DLSR-RET-CODE                                   
                                PROGRAM-RUN-DATE-RECORD                         
                                DLSR-REC-SIZE                                   
                                DLSR-BLK-SIZE                                   
                                DLSR-FORMAT                                     
                                DLSR-REC-COUNT.                                 
                                                                                
           IF  DLSR-RET-CODE = 0                                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  DLSR-RET-CODE = 4                                            
                   MOVE 'Y' TO EOF-SWITCH                                       
               ELSE                                                             
                   DISPLAY 'ERROR READING EXTRACT - ABEND' UPON CONSOLE         
FXXTOK             GO TO 799-SQL-STATUS.                                        
                                                                                
       399-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       WTL-TO-OPERATOR.                                                         
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           CALL 'WTL' USING WTL-MESSAGE-AREA                                    
                            WTL-FLAG                                            
                            WTL-REPLY                                           
                            WTL-REPLY-AREA.                                     
       WTL-TO-OPERATOR-EXIT.                                                    
           EXIT.                                                                
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
