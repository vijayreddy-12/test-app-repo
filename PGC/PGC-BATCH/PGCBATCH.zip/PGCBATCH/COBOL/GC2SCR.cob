       IDENTIFICATION DIVISION.                                                 
      *========================                                                 
                                                                                
FXXTOK PROGRAM-ID.     GC2SCR.                                                  
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
                                                                                
      **************************************************************            
      *PROGRAM OVERVIEW: TITLE - GWCOCSCR                                       
      *                                                                         
      *        DESCRIPTION - PRINTS A SALES CREDIT REPORT                       
      **************************************************************            
      *                                                                         
      *  04JUN90 (SUPPORT RELEASE 3A) IAN BUCKNELL                              
      *        - ADD COMMISSION YEAR-END DATE TO PARM CARD                      
      *          (FOR CONSISTENCY ONLY--CHANGE IS RELEVANT TO GWCOCSCF).        
      *        - TRANSLATE CODES USED IN IN-COMP-REASON OF REPORT FILE          
      *          TO VALUES PRINTED ON THE REPORT.  (CODE VALUES WERE            
      *          ASSIGNED IN GWCOCSCF TO ACHIVE CORRECT GROUPING AND            
      *          SEQUENCE VIA THE SORT STEP.)                                   
      *        - CHG LINE LIMIT TO FIX PAGE EJECT TIMING PROBLEM.               
      *                                                                         
      **************************************************************            
      *                                                                         
      * 20DEC94 (BLITZ RELEASE 100) BRENT WILKE                                 
      *                                                                         
      *     CHANGE PRODUCT HEADINGS                                             
      *     TO ALPHA PLUS, SIGNATURE, CORPORATE ACCOUNTS                        
      *     ADD COMBINED PRODUCTS TOTAL TO MONTHLY REPORT                       
      *                                                                         
      * 07OCT08  IBMECU        - ENTERPRISE COMPILER UPGRADE          *         
      *                                                                         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCSCR          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2SCR W-S STARTS HERE **'.                                  
       01  WS-FIELDS.                                                           
           05  END-OF-FILE-SW        PIC X            VALUE 'N'.                
           05  WS-PAGE-NO            PIC S9(4) COMP-3 VALUE ZERO.               
           05  LINE-COUNT           PIC S9(4) COMP-3 VALUE ZERO.                
           05  WS-PREV-PRODUCT       PIC X            VALUE SPACES.             
           05  WS-AMT          PIC S9(11)V99 COMP-3 VALUE +0.                   
           05  WS-PREV-GRP-ACCT.                                                
REN            10  WS-PREV-GRP       PIC X(7)         VALUE SPACES.             
               10  WS-PREV-ACCT      PIC X(3)         VALUE SPACES.             
           05  WS-PREV-AGENT         PIC X(6)         VALUE SPACES.             
           05  WS-PREV-REASON        PIC X            VALUE SPACES.             
           05  WS-AGENT-TOTALS.                                                 
               10 AGT-COMP-AMT   PIC S9(9)V99 COMP-3  VALUE +0.                 
               10 AGT-PREM-AMT   PIC S9(9)V99 COMP-3  VALUE +0.                 
           05  WS-PRODUCT-TOTALS.                                               
               10 PROD-COMP-AMT   PIC S9(9)V99 COMP-3  VALUE +0.                
               10 PROD-PREM-AMT   PIC S9(9)V99 COMP-3  VALUE +0.                
           05  WS-FINAL-TOTALS.                                                 
               10 FINAL-COMP-AMT       PIC S9(9)V99 COMP-3  VALUE +0.           
               10 FINAL-PREM-AMT       PIC S9(9)V99 COMP-3  VALUE +0.           
           05  COMB-YTD-TOTALS COMP-3.                                          
               10  COMB-CC-COMP-AMT     PIC S9(9)V99  VALUE +0.                 
               10  COMB-CC-PREM-AMT     PIC S9(9)V99  VALUE +0.                 
               10  COMB-YTD-COMP-AMT    PIC S9(11)V99 VALUE +0.                 
               10  COMB-YTD-PREM-AMT    PIC S9(11)V99 VALUE +0.                 
           05  WTL-MESSAGE.                                                     
               10  WTL-MSG-LENGTH PIC S999  COMP-3 VALUE +80.                   
               10  WTL-MSG-CC     PIC X            VALUE '0'.                   
               10  FILLER         PIC X(7)         VALUE 'GROUP='.              
REN            10  WTL-GROUP-NUMBER   PIC X(7)     VALUE SPACES.                
REN            10  FILLER         PIC X            VALUE SPACES.                
               10  FILLER         PIC X(9)         VALUE 'ACCOUNT='.            
               10  WTL-GROUP-ACCOUNT  PIC XXX      VALUE SPACES.                
REN            10  FILLER         PIC XX           VALUE SPACES.                
               10  WTL-ABEND-MSG  PIC X(50)        VALUE SPACES.                
           05  SUB                PIC S9   COMP    VALUE +0.                    
           05  WS-RPT-TO-DATE.                                                  
               10  FILLER         PIC X(4)         VALUE ' TO '.                
               10  WS-TO-DATE     PIC X(7)         VALUE SPACES.                
      /                                                                         
       01  DLSREAD-SYS010.                                                      
           05  SYS010-SYS       PIC X(6)          VALUE 'SYS010'.               
           05  SYS010-RET       PIC S9    COMP-3  VALUE +0.                     
           05  SYS010-REC       PIC 9(5)          VALUE 105.                    
           05  SYS010-BLK       PIC 9(5)          VALUE 2100.                   
           05  SYS010-FORMAT    PIC XX            VALUE 'FB'.                   
           05  SYS010-CNT       PIC S9(7) COMP-3  VALUE +0.                     
                                                                                
       01  REPORT-RECORD-IN.                                                    
           05  IN-PRODUCT-CODE      PIC X.                                      
           05  IN-GROUP-ACCT.                                                   
REN            10  IN-GROUP             PIC X(7).                               
               10  IN-ACCT              PIC X(3).                               
           05  IN-AGENT             PIC X(6).                                   
           05  IN-COMP-REASON       PIC X.                                      
           05  IN-COMP-AMT          PIC S9(8)V99  COMP-3.                       
           05  IN-PREM-AMT          PIC S9(8)V99  COMP-3.                       
REN        05  FILLER               PIC X(75).                                  
                                                                                
       01  TOTAL-RECORD-IN.                                                     
           05  TOT-PRODUCT-CODE      PIC X.                                     
           05  CC-YTD-TOTALS OCCURS 4 TIMES.                                    
               10  TOT-CC-COMP-AMT     PIC 9(9)V99  COMP-3.                     
               10  TOT-CC-PREM-AMT     PIC 9(9)V99  COMP-3.                     
               10  TOT-YTD-COMP-AMT     PIC 9(11)V99  COMP-3.                   
               10  TOT-YTD-PREM-AMT     PIC 9(11)V99  COMP-3.                   
                                                                                
       01  DLSREAD-SYS011.                                                      
           05  SYS011-SYS       PIC X(6)          VALUE 'SYS011'.               
           05  SYS011-RET       PIC S9    COMP-3  VALUE +0.                     
           05  SYS011-REC       PIC 9(5)          VALUE 80.                     
           05  SYS011-BLK       PIC 9(5)          VALUE 1600.                   
           05  SYS011-FORMAT    PIC XX            VALUE 'FB'.                   
           05  SYS011-CNT       PIC S9(7) COMP-3  VALUE +0.                     
                                                                                
       01  PARM-CARD-IN.                                                        
           05  FROM-DATE-IN              PIC X(7).                              
           05  FILLER                    PIC X.                                 
           05  TO-DATE-IN                PIC X(7).                              
           05  FILLER                    PIC X.                                 
           05  PROCESS-TYPE              PIC X.                                 
           05  FILLER                    PIC X.                                 
           05  LAST-COMM-CLOSE           PIC X(7).                              
           05  FILLER                    PIC X.                                 
           05  LAST-YEAREND-CLOSE        PIC X(7).                              
           05  FILLER                    PIC X(47).                             
      /                                                                         
       01  DLSWRITE-PARMS.                                                      
           05  SYS020-SYS       PIC X(6)          VALUE 'SYS020'.               
           05  SYS020-RET       PIC S9    COMP-3  VALUE +0.                     
           05  SYS020-REC       PIC 9(5)          VALUE 133.                    
           05  SYS020-BLK       PIC 9(5)          VALUE 3990.                   
           05  SYS020-FORMAT    PIC XX            VALUE 'FB'.                   
           05  SYS020-CNT       PIC S9(7) COMP-3  VALUE +0.                     
                                                                                
       01  WS-LINE-OUT             PIC X(133).                                  
      /                                                                         
       01  REPORT-LINES.                                                        
           05  WS-REPORT-HEADING.                                               
               10  FILLER              PIC X          VALUE '1'.                
FXXTOK         10  FILLER              PIC X(12)      VALUE 'GC2SCR'.           
               10  FILLER              PIC X(44)      VALUE SPACES.             
               10  FILLER              PIC X(18)      VALUE                     
               'SALES CREDITS FOR '.                                            
               10  WS-RPT-DATE         PIC X(7)       VALUE SPACES.             
               10  WS-RPT-DATE2        PIC X(11)      VALUE SPACES.             
               10  FILLER              PIC X(31)      VALUE SPACES.             
               10  FILLER              PIC X(5)       VALUE 'PAGE '.            
               10  WS-RPT-PAGE-NO      PIC ZZZ9.                                
                                                                                
           05  WS-REPORT-PRODUCT-HEADING.                                       
               10  FILLER              PIC X          VALUE '0'.                
               10  FILLER              PIC X(20)      VALUE SPACES.             
               10  OUT-PRODUCT-TYPE    PIC X(33).                               
               10  FILLER              PIC X(79)      VALUE SPACES.             
                                                                                
           05  WS-REPORT-UNDERLINE.                                             
               10  FILLER              PIC X          VALUE '0'.                
               10  FILLER              PIC X(20)      VALUE SPACES.             
               10  OUT-UNDERLINE       PIC X(33).                               
               10  FILLER              PIC X(79)      VALUE SPACES.             
                                                                                
           05  WS-REPORT-COL-HEADING.                                           
               10  FILLER              PIC X          VALUE '0'.                
               10  FILLER              PIC X(30)      VALUE SPACES.             
               10  FILLER              PIC X(35)                                
                   VALUE 'GROUP     ACCT     AGENT       TYPE'.                 
               10  FILLER              PIC X(9)       VALUE SPACES.             
               10  FILLER              PIC X(27)                                
                   VALUE 'SALES CREDITS      PREM AMT'.                         
               10  FILLER              PIC X(31)      VALUE SPACES.             
                                                                                
           05  WS-RPT-DETAIL-LINE.                                              
REN            10  FILLER              PIC X(29)     VALUE SPACES.              
REN            10  OUT-GROUP           PIC 9(7).                                
               10  FILLER              PIC X(5)      VALUE SPACES.              
               10  OUT-ACCT            PIC X(3).                                
               10  FILLER              PIC X(5)      VALUE SPACES.              
               10  OUT-AGENT           PIC X(6).                                
               10  FILLER              PIC X(5)      VALUE SPACES.              
               10  OUT-REASON          PIC X(2).                                
               10  FILLER              PIC X(10)                                
                   VALUE ' PAID     '.                                          
               10  OUT-COMP-AMT        PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(4)      VALUE SPACES.              
               10  OUT-PREM-AMT        PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(27)     VALUE SPACES.              
                                                                                
           05  WS-RPT-TOTAL-LINE.                                               
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(53)     VALUE SPACES.              
               10  FILLER              PIC X(18)                                
                   VALUE 'PRODUCT TOTAL     '.                                  
               10  OUT-TOTAL-COMP-AMT  PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(4)      VALUE SPACES.              
               10  OUT-TOTAL-PREM-AMT  PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(27)     VALUE SPACES.              
           05  WS-NO-SCR.                                                       
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(55)     VALUE SPACES.              
               10  FILLER              PIC X(22)                                
                    VALUE 'NO SALES CREDITS TODAY'.                             
               10  FILLER              PIC X(55)     VALUE SPACES.              
                                                                                
           05  WS-FINAL-TOTAL-HEADING.                                          
               10  FILLER              PIC X          VALUE '1'.                
FXXTOK         10  FILLER              PIC X(12)      VALUE 'GC2SCR'.           
               10  FILLER              PIC X(38)      VALUE SPACES.             
               10  FILLER              PIC X(24)      VALUE                     
               'TOTAL SALES CREDITS FOR '.                                      
               10  WS-TOT-RPT-DATE     PIC X(7)       VALUE SPACES.             
               10  WS-TOT-RPT-DATE2    PIC X(11)      VALUE SPACES.             
               10  FILLER              PIC X(31)      VALUE SPACES.             
               10  FILLER              PIC X(5)       VALUE 'PAGE '.            
               10  WS-TOT-RPT-PAGE-NO  PIC ZZZ9.                                
                                                                                
           05  WS-FINAL-TOTAL-LINE.                                             
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(53)     VALUE SPACES.              
               10  FILLER              PIC X(20)                                
                   VALUE '    FINAL TOTALS    '.                                
               10  OUT-FIN-COMP-AMT    PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(3)      VALUE SPACES.              
               10  OUT-FIN-PREM-AMT    PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(26)     VALUE SPACES.              
                                                                                
           05  WS-CC-REPORT-HEADING.                                            
               10  FILLER              PIC X          VALUE '1'.                
FXXTOK         10  FILLER              PIC X(12)      VALUE 'GC2SCR'.           
               10  FILLER              PIC X(40)      VALUE SPACES.             
               10  FILLER              PIC X(27)                                
                   VALUE 'MONTHLY SALES CREDIT REPORT'.                         
               10  FILLER              PIC X(53)      VALUE SPACES.             
                                                                                
           05  WS-CC-REPORT-DATE.                                               
               10  FILLER              PIC X(63)      VALUE SPACES.             
               10  WS-CC-RPT-DATE      PIC X(7).                                
               10  FILLER              PIC X(63)      VALUE SPACES.             
                                                                                
           05  WS-CC-REPORT-COL-HEADING.                                        
               10  FILLER              PIC X          VALUE '0'.                
               10  FILLER              PIC X(74)      VALUE SPACES.             
               10  FILLER              PIC X(28)                                
                   VALUE 'SALES CREDITS       PREM AMT'.                        
               10  FILLER              PIC X(30)      VALUE SPACES.             
                                                                                
           05  WS-CC-RPT-TOTAL-LINE.                                            
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(15)     VALUE SPACES.              
               10  PROD-DESC           PIC X(33).                               
               10  FILLER              PIC X         VALUE SPACES.              
               10  FILLER              PIC X(24)                                
                   VALUE 'COMMISSION CLOSE TOTALS '.                            
               10  OUT-CC-COMP-AMT     PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(3)      VALUE SPACES.              
               10  OUT-CC-PREM-AMT     PIC ZZZ,ZZZ,ZZ9.99-.                     
               10  FILLER              PIC X(26)     VALUE SPACES.              
                                                                                
           05  WS-YTD-RPT-TOTAL-LINE.                                           
               10  FILLER              PIC X         VALUE ' '.                 
               10  FILLER              PIC X(50)     VALUE SPACES.              
               10  FILLER              PIC X(20)                                
                   VALUE 'YEAR TO DATE TOTALS '.                                
               10  OUT-YTD-COMP-AMT    PIC ZZ,ZZZ,ZZZ,ZZ9.99-.                  
               10  OUT-YTD-PREM-AMT    PIC ZZ,ZZZ,ZZZ,ZZ9.99-.                  
               10  FILLER              PIC X(26)     VALUE SPACES.              
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           'WORKING STORAGE ENDS HERE'.                                         
      /                                                                         
MAN02  COPY GWFERRWS.                                                           
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GWCDUMP                 PIC X(8)       VALUE 'GWCDUMP'.          
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
                                                                                
       PROCEDURE DIVISION.                                                      
                                                                                
       000-MAINLINE.                                                            
                                                                                
           PERFORM 100-INITIALIZE THRU 100-EXIT.                                
           PERFORM 200-PROCESS-REPORT THRU 200-EXIT                             
              UNTIL END-OF-FILE-SW = 'Y'.                                       
           PERFORM 700-FINISH-REPORT THRU 700-EXIT.                             
           PERFORM 800-END-PROCESSING THRU 800-EXIT.                            
           STOP RUN.                                                            
                                                                                
       100-INITIALIZE.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. READ PARM CARD AND SET UP REPORT DATES.                    *         
      * 2. READ TOTAL REPORT RECORD (1ST ONE), AND MOVE TO WORK RECORD*         
      * 3. READ FIRST REPORT RECORD, IF THERE ARE NONE WRITE REPORT   *         
      *    WITH 'NO SALES CREDIT' MESSAGE.                            *         
      * 4. SETUP PREVIOUS WORK  FIELDS.                               *         
      * 5. PRINT HEADINGS.                                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           PERFORM 150-READ-PARM THRU 150-EXIT.                                 
           IF FROM-DATE-IN = TO-DATE-IN                                         
              MOVE FROM-DATE-IN TO WS-RPT-DATE                                  
              MOVE SPACES TO WS-RPT-DATE2                                       
              MOVE FROM-DATE-IN TO WS-TOT-RPT-DATE                              
              MOVE SPACES TO WS-TOT-RPT-DATE2                                   
           ELSE                                                                 
              MOVE FROM-DATE-IN TO WS-RPT-DATE                                  
              MOVE FROM-DATE-IN TO WS-TOT-RPT-DATE                              
              MOVE TO-DATE-IN TO WS-TO-DATE                                     
              MOVE WS-RPT-TO-DATE TO WS-RPT-DATE2                               
              MOVE WS-RPT-TO-DATE TO WS-TOT-RPT-DATE2.                          
                                                                                
           PERFORM 225-READ-INPUT THRU 225-EXIT.                                
           MOVE REPORT-RECORD-IN TO TOTAL-RECORD-IN.                            
           PERFORM 225-READ-INPUT THRU 225-EXIT.                                
           IF END-OF-FILE-SW = 'Y'                                              
           THEN                                                                 
               MOVE +1 TO WS-PAGE-NO                                            
               MOVE WS-PAGE-NO TO WS-RPT-PAGE-NO                                
               MOVE WS-REPORT-HEADING TO WS-LINE-OUT                            
               PERFORM 250-WRITE-REPORT THRU 250-EXIT                           
               MOVE WS-NO-SCR TO WS-LINE-OUT                                    
               PERFORM 250-WRITE-REPORT THRU 250-EXIT                           
               PERFORM 800-END-PROCESSING THRU 800-EXIT                         
               STOP RUN.                                                        
           MOVE IN-PRODUCT-CODE TO WS-PREV-PRODUCT.                             
           MOVE IN-GROUP-ACCT TO WS-PREV-GRP-ACCT.                              
           MOVE IN-AGENT TO WS-PREV-AGENT.                                      
           MOVE IN-COMP-REASON TO WS-PREV-REASON.                               
           PERFORM 300-PRINT-HEADINGS THRU 300-EXIT.                            
                                                                                
       100-EXIT.                                                                
           EXIT.                                                                
                                                                                
       150-READ-PARM.                                                           
                                                                                
           CALL 'DLSREAD' USING SYS011-SYS                                      
                                SYS011-RET                                      
                                PARM-CARD-IN                                    
                                SYS011-REC                                      
                                SYS011-BLK                                      
                                SYS011-FORMAT                                   
                                SYS011-CNT.                                     
           IF  SYS011-RET IS GREATER THAN +4                                    
           THEN                                                                 
               MOVE ZERO TO WTL-GROUP-NUMBER                                    
               MOVE ZERO TO WTL-GROUP-ACCOUNT                                   
               MOVE 'DLSREAD FAILED (SYS011) - FORCED TO ABEND'                 
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
                                                                                
       150-EXIT.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       200-PROCESS-REPORT.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. IF PRODUCT CODE CHANGES, PERFORM PRODUCT CODE BREAK        *         
      *    ELSE,                                                      *         
      *    IF GROUP/ACCOUNT CHANGES,PERFORM PRODUCT CODE BREAK        *         
      *    ELSE,                                                      *         
      *    IF AGENT CHANGES,PERFORM PRODUCT CODE BREAK.               *         
      * 2. ADD CURRENT RECORD TO AGENT TOTALS.                        *         
      * 3. READ ANOTHER REPORT RECORD.                                *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF IN-PRODUCT-CODE NOT = WS-PREV-PRODUCT                             
              PERFORM 500-PRODUCT-BREAK THRU 500-EXIT                           
           ELSE                                                                 
           IF IN-GROUP-ACCT NOT = WS-PREV-GRP-ACCT                              
              PERFORM 550-GROUP-ACCT-BREAK THRU 550-EXIT                        
           ELSE                                                                 
           IF IN-AGENT NOT = WS-PREV-AGENT                                      
              PERFORM 600-AGENT-BREAK THRU 600-EXIT.                            
           ADD IN-COMP-AMT TO AGT-COMP-AMT.                                     
           ADD IN-PREM-AMT TO AGT-PREM-AMT.                                     
           PERFORM 225-READ-INPUT THRU 225-EXIT.                                
                                                                                
       200-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       225-READ-INPUT.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. READ REPORT RECORD, IF END OF FILE, SET SWITCH TO 'Y'.     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           CALL 'DLSREAD' USING SYS010-SYS                                      
                                SYS010-RET                                      
                                REPORT-RECORD-IN                                
                                SYS010-REC                                      
                                SYS010-BLK                                      
                                SYS010-FORMAT                                   
                                SYS010-CNT.                                     
           IF  SYS010-RET IS GREATER THAN +4                                    
           THEN                                                                 
               MOVE IN-GROUP TO WTL-GROUP-NUMBER                                
               MOVE IN-ACCT TO WTL-GROUP-ACCOUNT                                
               MOVE 'DLSREAD FAILED (SYS010) - FORCED TO ABEND'                 
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
           IF  SYS010-RET IS EQUAL TO +4                                        
           THEN                                                                 
               MOVE 'Y' TO END-OF-FILE-SW.                                      
                                                                                
       225-EXIT.                                                                
           EXIT.                                                                
                                                                                
       250-WRITE-REPORT.                                                        
                                                                                
           CALL 'DLSWRITE' USING SYS020-SYS                                     
                                 SYS020-RET                                     
                                 WS-LINE-OUT                                    
                                 SYS020-REC                                     
                                 SYS020-BLK                                     
                                 SYS020-FORMAT                                  
                                 SYS020-CNT.                                    
                                                                                
           IF SYS020-RET IS GREATER THAN +4                                     
           THEN                                                                 
               MOVE IN-GROUP TO WTL-GROUP-NUMBER                                
               MOVE IN-ACCT TO WTL-GROUP-ACCOUNT                                
               MOVE 'DLSWRITE FAILED (SYS020) - FORCED TO ABEND'                
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
       250-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       300-PRINT-HEADINGS.                                                      
                                                                                
           ADD +1 TO WS-PAGE-NO.                                                
           MOVE WS-PAGE-NO TO WS-RPT-PAGE-NO.                                   
           MOVE WS-REPORT-HEADING TO WS-LINE-OUT.                               
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           IF WS-PREV-PRODUCT = 4                                               
              MOVE 'MISCELLANEOUS                    '                          
                TO OUT-PRODUCT-TYPE                                             
              MOVE '-------------                    '                          
                TO OUT-UNDERLINE                                                
           ELSE                                                                 
           IF WS-PREV-PRODUCT = 1                                               
              MOVE 'ALPHA PLUS (3 - 19 LIVES)        '                          
                TO OUT-PRODUCT-TYPE                                             
              MOVE '-------------------------        '                          
                TO OUT-UNDERLINE                                                
           ELSE                                                                 
           IF WS-PREV-PRODUCT = 2                                               
              MOVE 'SIGNATURE (20 - 399 LIVES)       '                          
                TO OUT-PRODUCT-TYPE                                             
              MOVE '--------------------------       '                          
                TO OUT-UNDERLINE                                                
           ELSE                                                                 
              MOVE 'CORPORATE ACCOUNTS (400+ LIVES)  '                          
                TO OUT-PRODUCT-TYPE                                             
              MOVE '-------------------------------  '                          
                TO OUT-UNDERLINE.                                               
           MOVE WS-REPORT-PRODUCT-HEADING TO WS-LINE-OUT.                       
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE WS-REPORT-UNDERLINE TO WS-LINE-OUT.                             
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE WS-REPORT-COL-HEADING TO WS-LINE-OUT.                           
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE +6 TO LINE-COUNT.                                               
       300-EXIT.                                                                
           EXIT.                                                                
                                                                                
       500-PRODUCT-BREAK.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. PERFORM GROUP/ACT BREAK.                                   *         
      * 2. WRITE PRODUCT TOTALS.                                      *         
      * 3. ZERO OUT PRODUCT TOTALS.                                   *         
      * 4. SETUP PREVIOUS PRODUCT CODE.                               *         
      * 5. PRINT HEADINGS FOR NEW PRODUCT.                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           PERFORM 550-GROUP-ACCT-BREAK THRU 550-EXIT.                          
           PERFORM 650-WRITE-PRODUCT-TOTALS THRU 650-EXIT.                      
           MOVE ZERO TO PROD-COMP-AMT.                                          
           MOVE ZERO TO PROD-PREM-AMT.                                          
           MOVE IN-PRODUCT-CODE TO WS-PREV-PRODUCT.                             
           PERFORM 300-PRINT-HEADINGS THRU 300-EXIT.                            
       500-EXIT.                                                                
           EXIT.                                                                
                                                                                
       550-GROUP-ACCT-BREAK.                                                    
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. PERFORM AGENT BREAK.                                       *         
      * 2. SETUP PREVIOUS GROUP/ACCT.                                 *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           PERFORM 600-AGENT-BREAK THRU 600-EXIT.                               
           MOVE IN-GROUP-ACCT TO WS-PREV-GRP-ACCT.                              
       550-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       600-AGENT-BREAK.                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. IF PAGE BREAK NEEDED, PRINT HEADINGS.                      *         
      * 2. SETUP AND WRITE REPORT LINE.                               *         
      * 3. ADD AGENT TOTAL TO PRODUCT TOTAL.                          *         
      * 4. ZERO OUT AGENT TOTAL.                                      *         
      * 5. SETUP PREVIOUS AGENT.                                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF LINE-COUNT > 58                                                   
              PERFORM 300-PRINT-HEADINGS THRU 300-EXIT.                         
           MOVE WS-PREV-GRP TO OUT-GROUP.                                       
           MOVE WS-PREV-ACCT TO OUT-ACCT.                                       
           MOVE WS-PREV-AGENT TO OUT-AGENT.                                     
           IF WS-PREV-REASON = '1'                                              
              MOVE 'FY' TO OUT-REASON                                           
           ELSE                                                                 
              IF WS-PREV-REASON = '2'                                           
                 MOVE 'FA' TO OUT-REASON                                        
              ELSE                                                              
                 IF WS-PREV-REASON = '3'                                        
                    MOVE 'RN' TO OUT-REASON                                     
                 ELSE                                                           
                    IF WS-PREV-REASON = '4'                                     
                       MOVE 'RA' TO OUT-REASON                                  
                    ELSE                                                        
                       MOVE SPACES TO OUT-REASON.                               
           MOVE AGT-COMP-AMT TO OUT-COMP-AMT.                                   
           MOVE AGT-PREM-AMT TO OUT-PREM-AMT.                                   
           MOVE WS-RPT-DETAIL-LINE TO WS-LINE-OUT.                              
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           ADD +1 TO LINE-COUNT.                                                
                                                                                
           ADD AGT-COMP-AMT TO PROD-COMP-AMT.                                   
           ADD AGT-PREM-AMT TO PROD-PREM-AMT.                                   
           MOVE ZERO TO AGT-COMP-AMT.                                           
           MOVE ZERO TO AGT-PREM-AMT.                                           
           MOVE IN-AGENT TO WS-PREV-AGENT.                                      
           MOVE IN-COMP-REASON TO WS-PREV-REASON.                               
                                                                                
       600-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       650-WRITE-PRODUCT-TOTALS.                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. ADD PRRODUT TOTALS TO FINAL TOTAL FOR ALL PRODUCTS.        *         
      * 1. WRITE PRODUCT TOTAL LINE.                                  *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           ADD PROD-COMP-AMT TO FINAL-COMP-AMT.                                 
           ADD PROD-PREM-AMT TO FINAL-PREM-AMT.                                 
           MOVE PROD-COMP-AMT TO OUT-TOTAL-COMP-AMT.                            
           MOVE PROD-PREM-AMT TO OUT-TOTAL-PREM-AMT.                            
           MOVE WS-RPT-TOTAL-LINE TO WS-LINE-OUT.                               
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
                                                                                
       650-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       700-FINISH-REPORT.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. PERFORM AGENT BREAK.                                       *         
      * 2. PERFORM WRITE PRODUCT TOTALS.                              *         
      * 3. PERFORM WRITE FINAL TOTALS.                                *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 600-AGENT-BREAK THRU 600-EXIT.                               
           PERFORM 650-WRITE-PRODUCT-TOTALS THRU 650-EXIT.                      
           PERFORM 750-WRITE-FINAL-TOTALS THRU 750-EXIT.                        
                                                                                
       700-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       750-WRITE-FINAL-TOTALS.                                                  
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. WRITE THE FINAL TOTALS (TOTAL OF ALL PRODUCTS).            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           ADD +1 TO WS-PAGE-NO.                                                
           MOVE WS-PAGE-NO TO WS-TOT-RPT-PAGE-NO.                               
           MOVE WS-FINAL-TOTAL-HEADING TO WS-LINE-OUT.                          
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE WS-CC-REPORT-COL-HEADING TO WS-LINE-OUT.                        
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE FINAL-COMP-AMT TO OUT-FIN-COMP-AMT.                             
           MOVE FINAL-PREM-AMT TO OUT-FIN-PREM-AMT.                             
           MOVE WS-FINAL-TOTAL-LINE TO WS-LINE-OUT.                             
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
                                                                                
       750-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       800-END-PROCESSING.                                                      
           IF PROCESS-TYPE = 'C'                                                
              PERFORM 900-COMM-CLOSE-REPORT THRU 900-EXIT.                      
                                                                                
           MOVE +4 TO SYS020-RET.                                               
           CALL 'DLSWRITE' USING SYS020-SYS                                     
                                 SYS020-RET                                     
                                 WS-LINE-OUT                                    
                                 SYS020-REC                                     
                                 SYS020-BLK                                     
                                 SYS020-FORMAT                                  
                                 SYS020-CNT.                                    
           IF SYS020-RET IS GREATER THAN +4                                     
           THEN                                                                 
               MOVE ZERO TO WTL-GROUP-NUMBER                                    
               MOVE ZERO TO WTL-GROUP-ACCOUNT                                   
               MOVE 'DLSWRITE CLOSE FAILED (SYS020) - FORCED TO ABEND'          
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
                                                                                
       800-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       900-COMM-CLOSE-REPORT.                                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 1. WRITE COMM CLOSE REPORT HEADINGS.                          *         
      * 2. PRINT THE PRODUCT'S COMM CLOSE AND YEAR TO DATE TOTALS     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE TO-DATE-IN TO WS-CC-RPT-DATE.                                   
           MOVE WS-CC-REPORT-HEADING TO WS-LINE-OUT.                            
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE WS-CC-REPORT-DATE TO WS-LINE-OUT.                               
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE WS-CC-REPORT-COL-HEADING TO WS-LINE-OUT.                        
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           PERFORM 950-PRINT-TOTALS THRU 950-EXIT                               
              VARYING SUB FROM 1 BY 1 UNTIL SUB > 4.                            
                                                                                
           PERFORM 960-PRINT-COMBINE-TOTALS                                     
              THRU 960-EXIT.                                                    
       900-EXIT.                                                                
           EXIT.                                                                
                                                                                
       950-PRINT-TOTALS.                                                        
           IF SUB = 4 AND                                                       
              TOT-CC-COMP-AMT (SUB) = ZERO AND                                  
              TOT-CC-PREM-AMT (SUB) = ZERO AND                                  
              TOT-YTD-COMP-AMT (SUB) = ZERO AND                                 
              TOT-YTD-PREM-AMT (SUB) = ZERO                                     
                  GO TO 950-EXIT.                                               
           IF SUB = 4                                                           
              MOVE '                    MISCELLANEOUS' TO PROD-DESC             
           ELSE                                                                 
           IF SUB = 1                                                           
              MOVE '                       ALPHA PLUS' TO PROD-DESC             
           ELSE                                                                 
           IF SUB = 2                                                           
              MOVE '                        SIGNATURE' TO PROD-DESC             
           ELSE                                                                 
              MOVE '               CORPORATE ACCOUNTS' TO PROD-DESC.            
           MOVE TOT-CC-COMP-AMT (SUB) TO OUT-CC-COMP-AMT.                       
           MOVE TOT-CC-PREM-AMT (SUB) TO OUT-CC-PREM-AMT.                       
           MOVE WS-CC-RPT-TOTAL-LINE TO WS-LINE-OUT.                            
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE TOT-YTD-COMP-AMT (SUB) TO OUT-YTD-COMP-AMT.                     
           MOVE TOT-YTD-PREM-AMT (SUB) TO OUT-YTD-PREM-AMT.                     
           MOVE WS-YTD-RPT-TOTAL-LINE TO WS-LINE-OUT.                           
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE +0 TO WS-AMT.                                                   
           ADD  TOT-CC-COMP-AMT (SUB) TO  COMB-CC-COMP-AMT.                     
           ADD  TOT-CC-PREM-AMT (SUB) TO  COMB-CC-PREM-AMT.                     
           ADD  TOT-YTD-COMP-AMT (SUB) TO COMB-YTD-COMP-AMT.                    
           ADD  TOT-YTD-PREM-AMT (SUB) TO COMB-YTD-PREM-AMT.                    
       950-EXIT.                                                                
           EXIT.                                                                
       960-PRINT-COMBINE-TOTALS.                                                
           MOVE '                COMBINED PRODUCTS' TO PROD-DESC.               
           MOVE COMB-CC-COMP-AMT     TO OUT-CC-COMP-AMT.                        
           MOVE COMB-CC-PREM-AMT     TO OUT-CC-PREM-AMT.                        
           MOVE WS-CC-RPT-TOTAL-LINE TO WS-LINE-OUT.                            
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE COMB-YTD-COMP-AMT     TO OUT-YTD-COMP-AMT.                      
           MOVE COMB-YTD-PREM-AMT     TO OUT-YTD-PREM-AMT.                      
           MOVE WS-YTD-RPT-TOTAL-LINE TO WS-LINE-OUT.                           
           PERFORM 250-WRITE-REPORT THRU 250-EXIT.                              
           MOVE +0 TO WS-AMT.                                                   
       960-EXIT.                                                                
           EXIT.                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                      END OF SOURCE                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
