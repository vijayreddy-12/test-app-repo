       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2ALPH.                                                     
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *AUTHOR.   C. ARSENE.                                                     
      *****************************************************************         
      *                                                                         
      *=================================================================        
      * SOURCE CODE FOR THIS PROGRAM LIVES IN LIBRARY TYPE CIII24               
      *=================================================================        
      *                                                                         
      * DESCRIPTION:                                                            
      *     THIS MODULE IS TO GENERATE AN EXTRACT WITH ALL ALPHPLUS             
      *     GROUPS ( PROD-CODE = 1) THAT HAVE AN EFFECTIVE DATE EQUAL           
      *     OR GREATER THAN DECEMBER 1, 2000                                    
      *                                                                         
      *     (05.JUL.2002) AND GROUP/ACCOUNTS WITH ACCOUNT STATUS OF             
      *     INFORCE (00), CLAIMS SUSPEND(01), OR TERMINATED ACCOUNT             
      *     STATUS AND SALES CREDITS OR COMMISSION REVERSAL ENTRIES             
      *     PROCESSED ON THE COMMISSION DATABASE WITHIN REPORTING               
      *     PERIOD.  IT EXCLUDES GROUP/ACCOUNTS WITH DUMMY PRODUCER             
      *     CODES AND GROUP/ACCOUNTS CONTRACTED THROUGH A GFO.                  
      *                                                                         
      * HISTORY:                                                                
      *     JUL.05.2001 - CORNELIA ARSENE (CREATION)                            
      *                                                                         
      *     FEB.05.2002 - BUG FIX - IF CURRENT MONTH IS JANUARY                 
      *                                                                         
      *     JUL.05.2002 - JACQUELINE SASSO (REQUIREMENT CHANGE)                 
      *                                                                         
      *    JUL/2005  R. KNAUD.                                                  
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)                  
      *                  USE VOGPWRA7 TO READ THE VCM AND GIPSY                 
      *                  MASTER FILES.                                          
      *                                                                         
      *    OCT/2008   IBM      - ENTERPRISE COMPILER UPGRADE       *            
      *****************************************************************         
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES ALPHCOMM          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2ALPH W-S STARTS HERE **'.                                 
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GAEDATSR                   PIC X(8)    VALUE 'GAEDATSR'.         
           05  GC2DATE                    PIC X(8)    VALUE 'GC2DATE'.          
      * VOCOMM VCM/GIPSY                                                        
           05  VOGPWRA7                   PIC X(8)    VALUE 'VOGPWRA7'.         
                                                                                
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
       01  LASTALPH-PARAMETERS.                                                 
           05  LASTALPH-YEAR              PIC X(3)    VALUE SPACES.             
           05  FILLER                     PIC X       VALUE SPACES.             
           05  LASTALPH-DAY               PIC X(3)    VALUE SPACES.             
           05  FILLER                     PIC X(3)    VALUE SPACES.             
                                                                                
       01  WS-PARAMETERS.                                                       
           05  WS-CORGRACCT            PIC X.                                   
               88  CORGRACCT-FOUND                    VALUE 'Y'.                
               88  CORGRACCT-NOT-FOUND                VALUE 'N'.                
           05  WS-CORCOMP              PIC X.                                   
               88  CORCOMP-FOUND                      VALUE 'Y'.                
               88  CORCOMP-NOT-FOUND                  VALUE 'N'.                
           05  WS-VERB                 PIC X(16)      VALUE SPACES.             
           05  WS-BR-EXCL              PIC XX         VALUE SPACES.             
           05  WS-AGENT                PIC X(5)       VALUE SPACES.             
           05  WS-SWITCHES.                                                     
               10  DATE-FOUND          PIC X          VALUE 'N'.                
               10  DATE-ERROR          PIC X          VALUE 'N'.                
           05  WS-TOT-COMM-PD-FY       PIC S9(7)V99   VALUE ZEROES.             
           05  WS-TOT-COMM-PD-RN       PIC S9(7)V99   VALUE ZEROES.             
           05  WS-TOT-SALS-CDT-FY      PIC S9(7)V99   VALUE ZEROES.             
           05  WS-TOT-SALS-CDT-RN      PIC S9(7)V99   VALUE ZEROES.             
      *    05  WS-GRAND-TOTAL-FY       PIC S9(9)V99   VALUE ZEROES.             
      *    05  WS-GRAND-TOTAL-RN       PIC S9(9)V99   VALUE ZEROES.             
                                                                                
       01  ERROR-MESSAGE.                                                       
           05  ERROR-MSG               PIC X(23)      VALUE SPACES.             
           05  ERR-STATUS              PIC X(4)       VALUE SPACES.             
                                                                                
       01  WS-SCALE-RATE-TABLE.                                                 
           05  WS-SCALE-RATE-TBL OCCURS 5 TIMES.                                
               10  WS-AGENT-CODE        PIC 9(6)      VALUE ZEROES.             
               10  WS-SCALE             PIC X(6)      VALUE SPACES.             
               10  WS-FLAT-RATE  REDEFINES  WS-SCALE                            
                                        PIC 9(3).99.                            
               10  WS-LTDSCALE          PIC X(6)      VALUE SPACES.             
               10  WS-LTD-FLAT-RATE  REDEFINES WS-LTDSCALE                      
                                        PIC 9(3).99.                            
                                                                                
       01  DATE-FIELDS.                                                         
           05  CURRDATE.                                                        
               10  CURR-YYYY         PIC 9999.                                  
               10  CURR-MMM          PIC XXX.                                   
               10  CURR-DD           PIC 99.                                    
           05  WS-LOW-DATE-ALIS.                                                
               10 LOW-YEAR           PIC S9(3) COMP-3.                          
               10 LOW-DAY            PIC S9(3) COMP-3.                          
           05  WS-HIGH-DATE-ALIS.                                               
               10 HIGH-YEAR          PIC S9(3) COMP-3.                          
               10 HIGH-DAY           PIC S9(3) COMP-3.                          
                                                                                
      *                                                                         
MAN02 *COPY GDETEXP.                                                            
                                                                                
       01  NAME-EXPAND-AREA.                                                    
           05  NAME-AND-DEL OCCURS 6 TIMES.                                     
               10  NAMEX           PIC X(30).                                   
               10  DEL             PIC X.                                       
           05  NEX-ERROR           PIC X(3).                                    
                                                                                
       01  FDOF-PARMS.                                                          
           05  FDOF-PARM1.                                                      
               10  FDOF-DDNAME       PIC X(7)       VALUE 'VSDSI97'.            
               10  FDOF-ACCTTYPE     PIC X(5)       VALUE 'KEYED'.              
               10  FDOF-RECTYPE      PIC X(1)       VALUE 'V'.                  
               10  FDOF-FUNCTION     PIC X(6)       VALUE 'GETRAN'.             
               10  FDOF-ERRCODE      PIC X(5)       VALUE SPACES.               
               10  FDOF-READCT       PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-WRITECT      PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-UPDATECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-DELETECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-RECLGTH      PIC S9(4)      VALUE +0    COMP.           
           05  FDOF-PARM2.                                                      
               10  FDOF-BRANCH       PIC X(5)       VALUE SPACES.               
                                                                                
       01  FILLER                    PIC X(16)      VALUE                       
           'FDOFFILE STARTS '.                                                  
                                                                                
      *01  FIELD-OFFICE-FILE.                                                   
           COPY FDOFFILE.                                                       
                                                                                
       01  GARDTCRD.                                                            
           COPY GARDTCRD.                                                       
                                                                                
      *  GFO NAME ACCESS DATA SECTION                                           
      *     *****  END   ******                                                 
      *  MUST INCLUDE GFMACCVS IN LINKCTL                                       
                                                                                
      *  GFMAGENT WORKING STORAGE SECTION                                       
      *                                                                         
       01  GFMAGENT-PARAMETERS.                                                 
           05  GFMAGENT-FUNCTION-CODE       PIC X(6)   VALUE SPACES.            
           05  GFMAGENT-ERROR-CODE          PIC X(6)   VALUE SPACES.            
           05  GFMAGENT-AGENT-KEY.                                              
               10  GFMAGENT-CODE   COMP-3   PIC S9(7)  VALUE +0.                
               10  GFMAGENT-ACCT            PIC X      VALUE SPACES.            
                                                                                
      *  AGENT NAME FILE                                                        
         COPY EAGNFILE.                                                         
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
      * VOCOMM VCM/GIPSY                                                        
           03  FILLER             PIC X(30).                                    
                                                                                
      *                                                                         
       01  OUTPUT-RECORD.                                                       
REN        05  O-GROUP              PIC X(7)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-ACCT               PIC XXX        VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-GROUP-NAME         PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-ACCT-EFF-DATE      PIC X(9)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-AGENT-CODE         PIC 9(6)       VALUE ZEROES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-AGENT-NAME         PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-BRANCH-CODE        PIC X(5)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-BRANCH-NAME        PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-TOT-COMM-PD-FY     PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-TOT-COMM-PD-RN     PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-TOT-SALS-CDT-FY    PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-TOT-SALS-CDT-RN    PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-PROCESS-MMM        PIC XXX         VALUE SPACES.               
           05  FILLER               PIC X           VALUE '/'.                  
           05  O-PROCESS-YYYY       PIC X(4)        VALUE SPACES.               
                                                                                
      *----------------------------------------------------------------         
      *          DATASERVER RECORDS                                   *         
      *----------------------------------------------------------------         
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE -  RECORD DESCRIPTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGROUP                      '.                                  
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGRACCT                     '.                                  
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCOMP                       '.                                  
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORACCUM                      '.                                  
      * GWCORACCUM                                                              
CPYNME     COPY GCIACCUM.                                                       
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORAGENT                      '.                                  
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORPAYBASIS                   '.                                  
      * GWCORPAYBASIS                                                           
CPYNME     COPY GCIPAYB.                                                        
      /                                                                         
       01  WS-ENDS.                                                             
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2ALPH W-S ENDS HERE   **'.                                 
      /                                                                         
      ******************************************************************        
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2ALPH'         TO FCCSPL-CURR-PGM.                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
         SKIP3.                                                                 
      ******************************************************************        
       000-MAINLINE.                                                            
                                                                                
FXXTOK     DISPLAY 'START OF GC2ALPH PROGRAM'.                                  
                                                                                
           PERFORM 100-INIT THRU 100-INIT-EXIT.                                 
                                                                                
           MOVE OBTAIN-FIRST TO WS-VERB.                                        
           PERFORM 150-READ-DATE-CARD THRU 150-READ-DATE-CARD-X                 
                   UNTIL DATE-FOUND = 'Y' OR                                    
                         DATE-ERROR = 'Y'.                                      
                                                                                
           IF DATE-ERROR = 'Y'                                                  
              GO TO 000-MAINLINE-X.                                             
                                                                                
           PERFORM 350-GET-LOW-DATE THRU 350-GET-LOW-DATE-EXIT.                 
                                                                                
           IF DATE-ERROR = 'Y'                                                  
              GO TO 000-MAINLINE-X.                                             
                                                                                
           DISPLAY 'HIGH-DATE: ' HIGH-YEAR, '-', HIGH-DAY.                      
           DISPLAY 'LOW-DATE: ' LOW-YEAR, '-', LOW-DAY.                         
           DISPLAY 'CURRDATE: ' CURR-YYYY, '-', CURR-MMM.                       
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ NEXT (VCM/GIPSY FILES)                                            
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-READ-NEXT      TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
           PERFORM 200-PROCESS-VCM-GIPSY                                        
              THRU 200-PROCESS-VCM-GIPSY-EXIT                                   
             UNTIL VGWO-RET-CODE NOT = '00'.                                    
                                                                                
           PERFORM 925-WRITE-LRD THRU 925-WRITE-LRD-EXIT.                       
                                                                                
      *--------------------------------------------------------------           
      *   END OF PROGRAM LOGIC                                                  
      *--------------------------------------------------------------           
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-CLOSE-FILES    TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
                                                                                
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  OUTPUT-RECORD                                 
                                  ICBM.                                         
                                                                                
FXXTOK     DISPLAY 'END OF GC2ALPH PROGRAM'.                                    
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       000-MAINLINE-X.                                                          
           STOP RUN.                                                            
                                                                                
      *--------------------------------------------------------------           
       100-INIT.                                                                
                                                                                
FXXTOK     MOVE 'GC2ALPH' TO ICBM-PROGRAM-NAME.                                 
           MOVE LOW-VALUES TO LINKAGE-CONTROL.                                  
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2ALPH' TO PROGRAM-NAME.                                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
           INITIALIZE OUTPUT-RECORD.                                            
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-OPEN-FILES     TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
                                                                                
       100-INIT-EXIT.                                                           
           EXIT.                                                                
                                                                                
      *--------------------------------------------------------------           
       150-READ-DATE-CARD.                                                      
                                                                                
           MOVE 'CARD-DATA-010' TO LOGICAL-RECORD-NAME.                         
                                                                                
           CALL GAEDATSR USING WS-VERB                                          
                               GARDTCRD                                         
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK                                                  
              AND NOT LR-NOT-FOUND                                              
              DISPLAY 'STATUS: ' ICBM,                                          
                  '    DATA = ', GARDTCRD                                       
              MOVE 'ERROR READING DATA FROM GARDTCRD: ' TO ERROR-MSG            
              MOVE LINKAGE-STATUS TO ERR-STATUS                                 
              PERFORM 950-WRITE-ERROR THRU 950-WRITE-ERROR-X                    
              MOVE 'Y' TO DATE-ERROR                                            
              GO TO 150-READ-DATE-CARD-X.                                       
                                                                                
           IF LR-NOT-FOUND                                                      
              DISPLAY 'RECORD NOT FOUND'                                        
              MOVE 'DATE RECORD NOT FOUND:' TO ERROR-MSG                        
              MOVE LINKAGE-STATUS TO ERR-STATUS                                 
              PERFORM 950-WRITE-ERROR THRU 950-WRITE-ERROR-X                    
              MOVE 'Y' TO DATE-ERROR                                            
              GO TO 150-READ-DATE-CARD-X.                                       
                                                                                
      *  MOVE VALUE IN DATE CARD TO RUN DATE FOR CALCS                          
           IF GARDTCRD-IDENTIFIER = 'LEAP-1'                                    
              MOVE 'Y' TO DATE-FOUND                                            
              DISPLAY 'MOVING DATES FROM CARD TO VDATES'                        
              MOVE GARDTCRD-JUL-YYY TO HIGH-YEAR                                
              MOVE GARDTCRD-JUL-DDD TO HIGH-DAY                                 
              MOVE GARDTCRD-YYYYMMMDD TO CURRDATE                               
           ELSE                                                                 
              MOVE OBTAIN-NEXT TO WS-VERB                                       
           END-IF.                                                              
                                                                                
       150-READ-DATE-CARD-X.                                                    
           EXIT.                                                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *--------------------------------------------------------------           
       200-PROCESS-VCM-GIPSY.                                                   
                                                                                
      *--- ALPHA PLUS GROUPS WITH EFFECTIVE DATE AFTER DEC 1 2000,              
      *--- ACCOUNT STATUS OF INFORCE OR CLAIMS SUSPEND OR                       
      *--- WITH TERMINATED ACCOUNT STATUS AND SALES CREDITS OR                  
      *--- COMMISSION REVERSAL ENTRIES PROCESSED ON THE COMMISSION              
      *--- DATABASE WITHIN THE REPORTING PERIOD.                                
                                                                                
      * EXCLUDE ALL NON-ALPHA GROUPS AND THE DUMMY GROUP                        
      * EXCLUDE ALL GROUPS WITH A POLICY EFFECTIVE DATE BEFORE                  
      *  DECEMBER 1, 2000                                                       
      * EXCLUDE ALL GROUPS WITH AN ACCOUNT STATUS OTHER THAN                    
      *  '00', '01' OR 23-26                                                    
                                                                                
           IF  GGIPRODUCT-CODE NOT = '1'                                        
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
           IF  GGIGROUP-NUMBER = 99999                                          
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
           IF (GGIISSUE-YEAR > 200 OR (GGIISSUE-YEAR = 200                      
                                  AND  GGIISSUE-DAY > 334))                     
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
           IF (GGIACCOUNT-STATUS = '00' OR                                      
               GGIACCOUNT-STATUS = '01' OR                                      
              (GGIACCOUNT-STATUS > 22 AND                                       
               GGIACCOUNT-STATUS < 27))                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 250-PROCESS-NEXT.                                          
                                                                                
           MOVE GGIGROUP-NUMBER TO GROUP-NUMBER OF GWCORGRACCT.                 
           MOVE GGIACCOUNT      TO GR-ACCOUNT   OF GWCORGRACCT.                 
                                                                                
      *--- LOOKING AT COMMISSION DATABASE                                       
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 DISPLAY GGIGROUP-NUMBER '/' GGIACCOUNT                         
                           'NOT FOUND ON COMMISSION DB'                         
              GO TO 250-PROCESS-NEXT.                                           
                                                                                
           PERFORM 400-CORCOMP THRU 400-CORCOMP-EXIT.                           
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       250-PROCESS-NEXT.                                                        
           PERFORM 850-READ-VCM-GIPSY THRU 850-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           END-IF.                                                              
                                                                                
       200-PROCESS-VCM-GIPSY-EXIT.                                              
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       350-GET-LOW-DATE.                                                        
                                                                                
           MOVE 'CARD-DATA-011' TO LOGICAL-RECORD-NAME.                         
                                                                                
           CALL GAEDATSR USING OBTAIN-FIRST                                     
                               LASTALPH-PARAMETERS                              
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK                                                  
              AND NOT LR-NOT-FOUND                                              
              DISPLAY 'DATE FILE STATUS: ' ICBM,                                
                  '    DATA = ', LASTALPH-PARAMETERS                            
              MOVE 'ERROR READING DATA FROM LASTALPH: ' TO ERROR-MSG            
              MOVE LINKAGE-STATUS TO ERR-STATUS                                 
              PERFORM 950-WRITE-ERROR THRU 950-WRITE-ERROR-X                    
              MOVE 'Y' TO DATE-ERROR                                            
              GO TO 350-GET-LOW-DATE-EXIT.                                      
                                                                                
           IF LR-NOT-FOUND                                                      
              DISPLAY 'RECORD NOT FOUND'                                        
              MOVE 'DATE RECORD NOT FOUND:' TO ERROR-MSG                        
              MOVE LINKAGE-STATUS TO ERR-STATUS                                 
              PERFORM 950-WRITE-ERROR THRU 950-WRITE-ERROR-X                    
              MOVE 'Y' TO DATE-ERROR                                            
              GO TO 350-GET-LOW-DATE-EXIT.                                      
                                                                                
      *  MOVE VALUE IN DATE CARD TO LOW DATE FOR CALCS                          
           IF LASTALPH-YEAR NUMERIC AND                                         
              LASTALPH-DAY NUMERIC                                              
              MOVE 'Y' TO DATE-FOUND                                            
              DISPLAY 'MOVING LOW DATES FROM CARD TO VDATES'                    
              MOVE LASTALPH-YEAR TO LOW-YEAR                                    
              MOVE LASTALPH-DAY  TO LOW-DAY                                     
           ELSE                                                                 
              MOVE 'Y' TO DATE-ERROR                                            
              MOVE 'ERROR READING LASTALPH:' TO ERROR-MSG                       
              MOVE LINKAGE-STATUS TO ERR-STATUS                                 
              PERFORM 950-WRITE-ERROR THRU 950-WRITE-ERROR-X                    
           END-IF.                                                              
                                                                                
       350-GET-LOW-DATE-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       400-CORCOMP.                                                             
                                                                                
           MOVE 'Y' TO WS-CORCOMP.                                              
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST-ALPH                                   
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
              GO TO 400-CORCOMP-EXIT.                                           
                                                                                
           PERFORM 500-CORCOMP THRU 500-CORCOMP-EXIT.                           
                                                                                
       400-CORCOMP-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       500-CORCOMP.                                                             
                                                                                
      *-- CHECK IF THE PROCESS-DATE IS BETWEEN LOW AND HIGH DATES               
                                                                                
           IF  (COMP-PROCESS-DATE >  WS-LOW-DATE-ALIS) AND                      
               (COMP-PROCESS-DATE <= WS-HIGH-DATE-ALIS)                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 500-NEXT-CORCOMP-RECORD.                                   
                                                                                
           IF (AGENT-NUMBER OF GWCORCOMP = '099998')                            
               GO TO 500-NEXT-CORCOMP-RECORD.                                   
                                                                                
      *-- WE WANT COMMISSION OR SALES CREDITS                                   
      *-- PAID                                                                  
      *-- FIRST YEAR OR RENEWAL                                                 
      *-- COVERAGE LIFE, LTD OR A&S                                             
                                                                                
           IF (COMP-TYPE = 'C' OR COMP-TYPE = 'S')                              
           AND (COMP-DISP = 'P')                                                
           AND (COMP-REASON = 'F' OR COMP-REASON = 'R' OR                       
                COMP-REASON = 'A' OR COMP-REASON = 'B')                         
           AND (COV-TYPE = 'T' OR COV-TYPE = 'L' OR COV-TYPE = 'O')             
              PERFORM 600-COMP-PREM-INFO THRU 600-EXIT                          
           END-IF.                                                              
                                                                                
      *-- GET NEXT CORCOMP RECORD                                               
       500-NEXT-CORCOMP-RECORD.                                                 
                                                                                
      *%   OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT-ALPH                                    
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
              GO TO 500-CORCOMP-EXIT.                                           
                                                                                
           GO TO 500-CORCOMP.                                                   
                                                                                
       500-CORCOMP-EXIT.                                                        
           EXIT.                                                                
      *-----------------------------------------------------------------        
       600-COMP-PREM-INFO.                                                      
                                                                                
           MOVE AGENT-NUMBER OF GWCORCOMP TO O-AGENT-CODE.                      
                                                                                
      * GET THE AGENT NAME ->                                                   
      * EXCLUDE AGENTS CONTRACTED THROUGH A GFO (BRANCH CODE = 15***)           
           MOVE SPACES TO WS-BR-EXCL.                                           
           PERFORM 800-GFMAGENT-SETUP-CALL THRU 800-GFMAGENT-EXIT.              
           MOVE O-BRANCH-CODE TO WS-BR-EXCL.                                    
                                                                                
           IF (WS-BR-EXCL = '15')                                               
           GO TO 600-EXIT.                                                      
                                                                                
           IF (COMP-REASON = 'F' OR COMP-REASON = 'A')                          
              IF COMP-TYPE = 'C'                                                
                 ADD COMP-AMT TO WS-TOT-COMM-PD-FY                              
              ELSE                                                              
                 ADD COMP-AMT TO WS-TOT-SALS-CDT-FY                             
              END-IF                                                            
           ELSE                                                                 
              IF COMP-TYPE = 'C'                                                
                 ADD COMP-AMT TO WS-TOT-COMM-PD-RN                              
              ELSE                                                              
                 ADD COMP-AMT TO WS-TOT-SALS-CDT-RN                             
              END-IF                                                            
           END-IF.                                                              
                                                                                
           PERFORM 675-SETUP-RECORDS THRU 675-EXIT.                             
                                                                                
       600-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       675-SETUP-RECORDS.                                                       
                                                                                
           MOVE GROUP-NUMBER OF GWCORCOMP TO  O-GROUP.                          
           MOVE GR-ACCOUNT   OF GWCORCOMP TO  O-ACCT.                           
                                                                                
      *--- GET THE GROUP NAME -> MNAD - BILLING NAME.                           
           CALL 'GZNAEXP7' USING GBNBILLING-NAME-ADDRESS                        
                                 NAME-EXPAND-AREA                               
                                 NEX-ERROR.                                     
           MOVE NAMEX (1)                 TO O-GROUP-NAME.                      
                                                                                
      *--- CONVERT THE ACCOUNT EFFECTIVE DATE.                                  
           MOVE GGIISSUE-YEAR TO VDATE-ALIS-YEAR1.                              
           MOVE GGIISSUE-DAY  TO VDATE-ALIS-DAY1.                               
           MOVE '2' TO VDATE-REQ-SERVICE.                                       
           MOVE '1' TO VDATE-REQ-DETAIL.                                        
           MOVE 'B' TO VDATE-REQ-BASIS.                                         
           MOVE 'E' TO VDATE-REQ-LANGUAGE.                                      
                                                                                
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
                                                                                
           IF VDATE-RET-CODE = ZERO THEN                                        
              MOVE VDATE-EXT-DATE TO O-ACCT-EFF-DATE                            
           ELSE                                                                 
              DISPLAY 'ERROR : DATE CONVERSION ',                               
              VDATE-RETURN-AREA   , '        ',                                 
              VDATE-ALIS-DATE1    , '        ',                                 
              VDATE-EXT-DATE                                                    
           END-IF.                                                              
                                                                                
           MOVE CURR-YYYY TO O-PROCESS-YYYY.                                    
           MOVE CURR-MMM  TO O-PROCESS-MMM.                                     
                                                                                
           MOVE WS-TOT-COMM-PD-FY  TO O-TOT-COMM-PD-FY.                         
           MOVE WS-TOT-SALS-CDT-FY TO O-TOT-SALS-CDT-FY.                        
           MOVE WS-TOT-COMM-PD-RN  TO O-TOT-COMM-PD-RN.                         
           MOVE WS-TOT-SALS-CDT-RN TO O-TOT-SALS-CDT-RN.                        
                                                                                
      *--- GET THE BRANCH NAME ->                                               
           PERFORM 700-BRANCH-NAME THRU 700-EXIT.                               
                                                                                
           PERFORM 900-WRITE-RECORD THRU 900-WRITE-RECORD-EXIT.                 
                                                                                
       675-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       700-BRANCH-NAME.                                                         
                                                                                
           MOVE O-BRANCH-CODE TO FDOF-PARM2.                                    
           MOVE 'GETRAN'      TO FDOF-FUNCTION.                                 
                                                                                
           CALL 'ZACCVSAM' USING FDOF-PARM1                                     
                                 FDOF-PARM2                                     
                                 FIELD-OFFICE-FILE.                             
                                                                                
           IF  FDOF-ERRCODE NOT = LOW-VALUES                                    
               MOVE SPACE     TO O-BRANCH-NAME                                  
           GO TO 700-EXIT.                                                      
                                                                                
           MOVE FOF-BRANCH-NAME TO O-BRANCH-NAME.                               
                                                                                
       700-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       800-GFMAGENT-SETUP-CALL.                                                 
                                                                                
           MOVE SPACES      TO GFMAGENT-ERROR-CODE.                             
           MOVE 'SETLIM'    TO GFMAGENT-FUNCTION-CODE.                          
           MOVE '0'         TO GFMAGENT-ACCT.                                   
           MOVE O-AGENT-CODE  TO GFMAGENT-CODE.                                 
MAN02      CALL 'GFMAGENT'  USING GFMAGENT-FUNCTION-CODE                        
MAN02                             GFMAGENT-ERROR-CODE                           
MAN02                             AGENT-NAME-FILE                               
MAN02                             GFMAGENT-AGENT-KEY.                           
           MOVE 'GETSEQ'    TO GFMAGENT-FUNCTION-CODE.                          
MAN02      CALL 'GFMAGENT'  USING GFMAGENT-FUNCTION-CODE                        
MAN02                             GFMAGENT-ERROR-CODE                           
MAN02                             AGENT-NAME-FILE                               
MAN02                             GFMAGENT-AGENT-KEY.                           
                                                                                
           IF O-AGENT-CODE EQUAL TO AGT-CODE                                    
              MOVE AGT-NAME TO O-AGENT-NAME                                     
              MOVE AGT-BRANCH-CODE TO O-BRANCH-CODE                             
           ELSE                                                                 
              MOVE ' AGENT NOT FOUND        ' TO O-AGENT-NAME                   
              DISPLAY ' AGENT ACCESS ERROR FOR: ' O-AGENT-CODE                  
                      ' ERROR CODE IS: ' GFMAGENT-ERROR-CODE.                   
                                                                                
       800-GFMAGENT-EXIT.                                                       
           EXIT.                                                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *-----------------------------------------------------------------        
       850-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       850-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       900-WRITE-RECORD.                                                        
                                                                                
           MOVE 'PRINT-DATA-020' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR     USING  STORE-LR                                    
                                    OUTPUT-RECORD                               
                                    ICBM.                                       
           DISPLAY OUTPUT-RECORD                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                        
           END-IF.                                                              
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
           MOVE SPACES TO WS-BR-EXCL.                                           
           MOVE ZEROES TO WS-TOT-COMM-PD-FY                                     
                          WS-TOT-COMM-PD-RN                                     
                          WS-TOT-SALS-CDT-FY                                    
                          WS-TOT-SALS-CDT-RN.                                   
                                                                                
       900-WRITE-RECORD-EXIT.                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
       925-WRITE-LRD.                                                           
                                                                                
           MOVE HIGH-YEAR TO LASTALPH-YEAR.                                     
           MOVE HIGH-DAY TO LASTALPH-DAY.                                       
                                                                                
           MOVE 'PRINT-DATA-022' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR USING STORE-LR                                         
                               LASTALPH-PARAMETERS                              
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY 'ERROR WRITING LASTALPH:    ' ICBM                        
           END-IF.                                                              
                                                                                
       925-WRITE-LRD-EXIT.                                                      
           EXIT.                                                                
      *-----------------------------------------------------------------        
       950-WRITE-ERROR.                                                         
                                                                                
           MOVE 'PRINT-DATA-021' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR USING STORE-LR                                         
                               ERROR-MESSAGE                                    
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                        
           END-IF.                                                              
                                                                                
       950-WRITE-ERROR-X.                                                       
           EXIT.                                                                
      *-----------------------------------------------------------------        
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          END OF SOURCE                                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
