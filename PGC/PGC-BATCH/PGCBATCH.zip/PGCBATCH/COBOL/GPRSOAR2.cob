       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. GPRSOAR2.                                                    
      *This program has been examined/renovated for Year 2000 compliance.       
      *DATE-WRITTEN.  SEP-89                                                    
      *DATE-COMPILED.                                                           
      *****************************************************************         
      *                  REPORT FOR HEAD-OFFICE.                                
      *                     REPORT-NUMBER 2.                                    
      *                     SORT ORDER   GFO/BRANCH GFO/AGENT GROUP ACCT        
      *                                                                         
      *                                                                         
      *          SHOWS ALL GROUPS FOR WHICH A LAPSE NOTICE HAS BEEN             
      *          PRODUCED AND CLAIMS HAVE BEEN SUSPENDED.                       
      *          THIS MODULE INTERIGATES REPORT TYPE "H" AND IF TYPE            
      *          "B" CALLS GROUP OFFICE OVERDUE PREMIUM REPORT                  
      *          MODULE.                                                        
      *                                                                         
      *          PAGE BREAK BETWEEN PRODUCERS                                   
      *                                                                         
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *  SEP-89   ANITA SCHLEICHER -- CREATION.                       *         
      *                                                               *         
      *                                                               *         
      *  FEB/90  M DRURY  - CHANGE THE NUMBER OF COPIES TO 1          *         
      *                     OLD    FORM-STANDARD-TWICE  VALUE '92'    *         
      *                     NEW    FORM-STANDARD-ONCE   VALUE '91'    *         
      *                                                               *         
      *  FEB/90  M BURTON - ADJUSTED THE PRINT OF THE LABELS          *         
      *                     TO FIT THE FORMS                          *         
      *                                                               *         
      *  AUG/90  M PRANGE - FIX TOTALLING OF CURRENT PREM DUE.        *         
      *                                                               *         
      *  SEP/97  LARRY GLEASON - CHANGES TO REFORT AND DATE FORMATS   * Y2K97260
      *          TO MEET WITH Y2K COMPLIANCE.  (4 DIGIT REPORT YEAR)  * Y2K97260
      *                                                               *         
      *  JUN/98  J ELKINS - CHANGE FOOTINGS AT BOTTOM OF REPORT FOR   *         
      *                     ALPHA/RGO CHANGES                         *         
      *  AUG/98  KAZINCZY - ADD WS-HEAD0 TO ACOMODATE OUTPUT FORM GPLL*         
      *          ENDRE      (CUT SHEET WITH BILINGUAL HEADER)         *         
      *          T4009                                                *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *                                                               *         
      *                                                               *         
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  PRINT-LINE-AREA.                                                     
           05  FILLER                               PIC X.                      
           05  PRINT-LINE                           PIC X(124).                 
                                                                                
       01  LABEL-01.                                                            
           05  FILLER                               PIC X.                      
           05  FILLER                               PIC X(05).                  
           05  L1-OFFICE-DESC-1                     PIC X(09).                  
           05  L1-OFFICE-1                          PIC X(05).                  
           05  FILLER                               PIC X(16).                  
           05  L1-OFFICE-DESC-2                     PIC X(09).                  
           05  L1-OFFICE-2                          PIC X(05).                  
           05  FILLER                               PIC X(16).                  
           05  L1-OFFICE-DESC-3                     PIC X(09).                  
           05  L1-OFFICE-3                          PIC X(05).                  
           05  FILLER                               PIC X(16).                  
           05  L1-OFFICE-DESC-4                     PIC X(09).                  
           05  L1-OFFICE-4                          PIC X(05).                  
           05  FILLER                               PIC X(11).                  
                                                                                
       01  LABEL-02.                                                            
           05  FILLER                               PIC X.                      
           05  FILLER                               PIC X(05).                  
           05  L2-PRODUCER-1                        PIC X(20).                  
           05  FILLER                               PIC X(05).                  
           05  FILLER                               PIC X(05).                  
           05  L2-PRODUCER-2                        PIC X(20).                  
           05  FILLER                               PIC X(10).                  
           05  L2-PRODUCER-3                        PIC X(20).                  
           05  FILLER                               PIC X(10).                  
           05  L2-PRODUCER-4                        PIC X(20).                  
           05  FILLER                               PIC X(04).                  
                                                                                
       01  LABEL-TABLE.                                                         
           05  LABEL-TABLE-1 OCCURS 4 TIMES.                                    
              10  LABEL-OFFICE                      PIC X(5).                   
              10  LABEL-PRODUCER                    PIC X(20).                  
      *                                                                         
MAN07  01  LABEL-SUB             VALUE 0            PIC 9 COMP.                 
       01  LABEL-MAX             VALUE 4            PIC 9.                      
       01  LABEL-TO-PRINT        VALUE 'N'          PIC X.                      
                                                                                
      *                                                                         
      *           GFMAGENT PARAMETERS (USES ZACCVSAM FROM GFMAACVS)             
       01  GFMAGENT-PARMS.                                                      
           05  GFMAGENT-FUNCTION     PIC X(6)   VALUE SPACES.                   
           05  GFMAGENT-ERROR        PIC X(5)   VALUE SPACES.                   
           05  GFMAGENT-KEY.                                                    
               10  GFMAGENT-CODE     PIC S9(7)  VALUE ZERO    COMP-3.           
               10  GFMAGENT-ACCOUNT  PIC X(1)   VALUE SPACE.                    
                                                                                
          COPY EAGNFILE.                                                        
                                                                                
       01  BRANCH-GFO-FIELD.                                                    
           05  BRANCH-GFO            PIC XX.                                    
           05  FILLER                PIC XXX.                                   
                                                                                
       01  FILLER  COMP.                                                        
               05  WS-LINE-COUNT VALUE +0           PIC S9(4).                  
               05  WS-LNE-CNT    VALUE +0           PIC S9(4).                  
+T4009         05  WS-HEAD0-CNT  VALUE +0           PIC S9(4).                  
                                                                                
+T4009 01  OUT-PARAMETERS.                                                      
+T4009         05  OUT-SYS021        PIC X(6)   VALUE 'SYS021'.                 
+T4009         05  OUT-RETURN        PIC S9(1) COMP-3 VALUE +0.                 
+T4009         05  OUT-RECSIZE       PIC 9(5)   VALUE 00133.                    
+T4009         05  OUT-BLKSIZE       PIC 9(5)   VALUE 03990.                    
+T4009         05  OUT-FORMAT        PIC XX     VALUE 'FB'.                     
+T4009         05  OUT-SYS021-COUNT  PIC S9(7) COMP-3 VALUE +0.                 
                                                                                
       01  FILLER.                                                              
           03  WS-PAGE-NUMBER    VALUE +0    COMP-3 PIC S9(5).                  
           03  WS-STORED-PRODUCER VALUE ZEROS       PIC 9(6).                   
           03  WS-QDATE-AD       VALUE 'AD'         PIC X(2).                   
           03  WS-NEW            VALUE 'N'          PIC X(1).                   
           03  PREV-PCODE        VALUE '0'          PIC X.                      
           03  FOOTING-PRINTED-FLAG  VALUE 'Y'      PIC X.                      
           03  WS-NEW-MSGE                          PIC X(12)                   
               VALUE 'NEW/NOT SUSP'.                                            
           03  WS-HOLD-DATA                        PIC X(133).                  
           03  WS-HOLD-DATA2                       PIC X(133).                  
           03  FORM-STANDARD-ONCE VALUE '91'       PIC X(2).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *            NO OF GROUP OFFICES AND TOTALS                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-CURR-STATUS.                                                  
               05  WS-CURR-PRODUCER                PIC 9(6).                    
               05  WST-PREM-AMT   COMP-3 VALUE +0  PIC S9(7)V99.                
               05  WST-CURR-PREM  COMP-3 VALUE +0  PIC S9(7)V99.                
               05  WST-TOT-PREM   COMP-3 VALUE +0  PIC S9(7)V99.                
           03  WS-TABLE-STATUS OCCURS 40 TIMES     PIC X(21).                   
       01  WS-VARIABLES.                                                        
           03  SYNCED-VARIABLES  COMP.                                          
MAN07          05  WS-CURR-SUB   VALUE +1          PIC S9(4) COMP.              
MAN07          05  WS-MAX-SUB    VALUE +40         PIC S9(4) COMP.              
               05  WS-CURR-TOT   VALUE +1          PIC S9(4).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  END OF REPORT TOTALS                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-ENDTOT-PREM    VALUE +0  COMP-3  PIC S9(7)V99.                
           03  WS-ENDTOT-CURR    VALUE +0  COMP-3  PIC S9(7)V99.                
           03  WS-ENDTOT-TOT     VALUE +0  COMP-3  PIC S9(7)V99.                
       01  PRINT-LABELS-SYS067.                                                 
           03  PRINT-SYS067         PIC X(6)           VALUE 'SYS067'.          
           03  PRINT-SYS067-RECSIZE PIC 9(5)           VALUE 125.               
           03  PRINT-SYS067-BLKSIZE PIC 9(5)           VALUE 23375.             
           03  PRINT-SYS067-FORMAT  PIC X(2)           VALUE 'FB'.              
           03  PRINT-SYS067-COUNT   PIC S9(7)  COMP-3  VALUE +0.                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                     REPORT HEADINGS                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
+T4009     03  WS-HEAD0.                                                        
+T4009         05  FILLER        VALUE SPACES        PIC X(125).                
           03  WS-HEAD1.                                                        
               05  FILLER        VALUE 'GPRSOAR2'    PIC X(8).                  
               05  FILLER        VALUE SPACES        PIC X(31).                 
               05  FILLER                            PIC X(46)  VALUE           
           'PRODUCER COPY - REPORT OF LAPSE NOTICES MAILED'.                    
               05  FILLER        VALUE SPACES        PIC X(7).                  
               05  FILLER        VALUE 'REPORT DATE' PIC X(12).                 
               05  WS-HD1-DATE                       PIC X(9).          Y2K97260
               05  FILLER        VALUE SPACES        PIC X(7).          Y2K97260
               05  FILLER        VALUE 'PAGE '       PIC X(5).                  
               05  WS-HD1-PAGE   VALUE ZEROS         PIC ZZZZ9.                 
           03  WS-HEAD2.                                                        
               05  FILLER        VALUE SPACES        PIC X(23).                 
               05  FILLER                            PIC X(79)  VALUE           
           'THE FOLLOWING GROUP ACCOUNTS ARE NOW IN ARREARS AND COVERAGE        
      -    ' HAS BEEN SUSPENDED'.                                               
           03  WS-HEAD3.                                                        
               05  FILLER        VALUE SPACES        PIC X(1).                  
 GNE           05  FILLER                            PIC X(87)  VALUE           
 GNE         'PROD.   GROUP     ACC BRANCH         GROUP  NAME                  
 GNE  -    '    OVERDUE     PREMIUM '.                                          
               05  FILLER                            PIC X(45)  VALUE           
           ' CURRENT         TOTAL   CLAIMS SUSP PRODUCT  '.                    
           03  WS-HEAD4.                                                        
 GNE           05  FILLER                            PIC X(85)  VALUE           
 GNE         '         NUMBER    NO                                             
 GNE  -    '    DATE DUE      AMOUNT'.                                          
               05  FILLER                            PIC X(52)  VALUE           
           'PREMIUM DUE   PREMIUM DUE   EFFECT DATE    CODE     '.              
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   DETAIL LINE STRUCTURE                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-DETAIL1.                                                      
               05  FILLER                            PIC X(1).                  
               05  WSD-PRODUCER                      PIC ZZZZZ9.                
               05  FILLER                            PIC X(2).                  
GNE            05  WSD-GROUP                         PIC ZZZZ999.               
               05  FILLER                            PIC X(3).                  
               05  WSD-ACCT                          PIC X(3).                  
               05  FILLER                            PIC X(1).                  
               05  WSD-BRANCH                        PIC X(5).                  
      *        05  FILLER                            PIC X(1).                  
               05  WSD-GRPNAME                       PIC X(33).                 
               05  WSD-OVDU-DATE                     PIC X(9).          Y2K97260
               05  WSD-PREM-AMT                      PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WSD-CURR-PREM                     PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WSD-TOT-PREM                      PIC Z,ZZZ,ZZZ.99-.         
               05  WSD-CLAIM.                                                   
                   07  FILLER                        PIC X(1).                  
                   07  WS-CLMSUS-DATE                PIC X(9).          Y2K97260
                   07  FILLER                        PIC X(2).          Y2K97260
                   07  WS-PROD-CODE                  PIC X(10).                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  TOTAL LINE STRUCTURE                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-TOTAL1.                                                       
               05  WS-COMPANY-HD.                                               
                   07  FILLER                        PIC X(9).                  
      *            07  WS-TOT-PRODUCER               PIC 9(6).                  
      *            07  FILLER                        PIC X(2).                  
                   07  WS-TOT-HD                     PIC X(7).                  
               05  FILLER                            PIC X(54).                 
               05  WS-TOT-PREM-AMT                   PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WS-TOT-CURR-PREM                  PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WS-TOT-TOT-PREM                   PIC Z,ZZZ,ZZZ.99-.         
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   REPORT END LITERIALS                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-COMPANY-MSGE                       PIC X(14)                  
               VALUE 'COMPANY  TOTAL'.                                          
           03  WS-TOTAL-MSGE   VALUE '  TOTAL'         PIC X(7).                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 FOOTING LINES                                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  FOOTING-LINE-1.                                                  
               05  FILLER         VALUE ' '          PIC X.                     
               05  FILLER                            PIC X(83)                  
                   VALUE 'PLEASE CONTACT YOUR ACCOUNT MANAGER IN THE MAN        
      -        'ULIFE FINANCIAL REGIONAL GROUP OFFICE'.                         
               05  FILLER         VALUE SPACES       PIC X(49).                 
           03  FOOTING-LINE-2.                                                  
               05  FILLER         VALUE ' '          PIC X.                     
               05  FILLER                            PIC X(115)                 
                   VALUE '***URGENT***  PLEASE FOLLOW-UP WITH YOUR CLIEN        
      -        'T(S) AS THE ABOVE GROUP(S) HAVE CLAIMS SUSPENDED DUE TO         
      -        'NON-PAYMENT O'.                                                 
               05  FILLER         VALUE 'F PREMIUM'  PIC X(9).                  
               05  FILLER         VALUE SPACES       PIC X(5).                  
               05  FILLER         VALUE SPACES       PIC X(3).                  
           03  FOOTING-LINE-3.                                                  
               05  FILLER         VALUE ' '          PIC X.                     
               05  FILLER                            PIC X(115)                 
                   VALUE 'VEUILLEZ COMMUNIQUER AVEC VOTRE CHARGE DE PORT        
      -        'EFEUILLE AU BUREAU REGIONAL DE LA COLLECTIVE DE LA FINAN        
      -        'CIERE MANUVIE'.                                                 
               05  FILLER         VALUE SPACES       PIC X(17).                 
           03  FOOTING-LINE-4.                                                  
               05  FILLER         VALUE ' '          PIC X.                     
               05  FILLER                            PIC X(115)                 
                   VALUE '***URGENT*** VEUILLEZ FAIRE UN SUIVI AVEC VOS         
      -        'CLIENTS(S), CAR LES DEMANDES DE REGLEMENT DES GROUPE(S)         
      -        'SUSMENTIONNES'.                                                 
               05  FILLER         VALUE SPACES       PIC X(17).                 
           03  FOOTING-LINE-5.                                                  
               05  FILLER         VALUE ' '          PIC X.                     
               05  FILLER                            PIC X(63)                  
                   VALUE 'ONT ETE MISES EN SUSPENS EN RAISON DU NON-PAIE        
      -        'MENT DE LA PRIME.'.                                             
               05  FILLER         VALUE SPACES       PIC X(69).                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 BUILDING NAME TRAILER  030                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
                                                                                
       COPY GMBNATR.                                                            
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *               WORK AREA TO EXPAND GROUP NAME                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WS-NMADDR.                                                           
           03  WS-NAME-ADDR OCCURS 6 TIMES.                                     
               05  WS-NA-LN                          PIC X(33).                 
               05  FILLER                            PIC X(1).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *          WORK DISK USED FOR SECOND COPY OF REPORT              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WS-WORK-DISK.                                                        
           03  WS-WKD-LENGTH   VALUE +137 COMP SYNC  PIC S9(4).                 
           03  FILLER          VALUE LOW-VALUE       PIC X(2).                  
           03  WS-WKD-DATA.                                                     
               05  WS-WKD-CC                         PIC X(1).                  
               05  WS-WKD-AREA.                                                 
                   07  FILLER                        PIC X(1).                  
                   07  WS-WKD-OVFLW-GRP              PIC X(6).                  
                   07  FILLER                        PIC X(125).                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     WORK DISK USED FOR ERROR OCCURRING GPRINTAL PROCESSING     *        
      *                                                                *        
      *    CHANGE TO A COPY BOOK FOR THE ERROR RECORD.     MARCUS.     *        
      *----------------------------------------------------------------*        
                                                                                
GNE        COPY GERRREC7.                                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *      FROM GIPSY PRINT FILE GROUP OFFICE ARREAR RECORD          *        
      *                                                                *        
      *----------------------------------------------------------------*        
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
       LINKAGE SECTION.                                                         
       01  ARR-RECORD.                                                          
GNE                    COPY GGFOARR7.                                           
      *----------------------------------------------------------------*        
      *                                                                *        
      *               FROM GPRINTAL DRIVER MODULE                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LSMISC-AREA.                                                         
           03  FILLER                                PIC X(4).                  
           03  LSM-HIDATE                            PIC X(4).                  
           03  LSM-STATDATE                          PIC X(4).                  
           03  LSM-PREMDATE                          PIC X(4).                  
           03  LSM-RESTART.                                                     
               05  LSR-RECTYPE                       PIC X(1).                  
               05  LSR-REPTYPE                       PIC X(1).                  
               05  LSR-GRPOFF                        PIC X(5).                  
               05  FILLER                            PIC X(7).                  
           03  FILLER                                PIC X(4).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *         PRINT PARAMETER COPY BOOK FOR SYS022 TO SYS029         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRPRINT.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         TAPE PARAMETER COPY BOOK FOR SYS011 AND SYS014         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRTPARM.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             REPORT ACCUMULATOR COPY BOOK                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRACCUM.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      FROM GIPSY PRINT FILE GROUP OFFICE ARREAR RECORD          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PROCEDURE DIVISION USING ARR-RECORD                                      
                                LSMISC-AREA                                     
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   INITIALIZE ROUTINE                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *    DISPLAY '------------> GPRSOAR2 <----------'.                        
      *    READY TRACE.                                                         
           IF   ARR-TYPE      =    'H'                                          
            AND ARR-REPORT    =    'A'                                          
               GO TO INIT-ROUTINE.                                              
       UB-MODULE-CALL.                                                          
           CALL 'GPRSOOPR' USING ARR-RECORD                                     
                                 LSMISC-AREA                                    
                                 GPRPRINT                                       
                                 GPRTPARM                                       
                                 GPRACCUM.                                      
           GO TO END-OPERATIONS.                                                
       INIT-ROUTINE.                                                            
           PERFORM INITIALIZE-TABLE-BGN THRU                                    
                   INITIALIZE-TABLE-END VARYING LABEL-SUB                       
                   FROM 1                                                       
                   BY 1                                                         
                   UNTIL LABEL-SUB > 4.                                         
           MOVE 0   TO LABEL-SUB.                                               
-T4009*    CALL 'GPRSGMNT'              USING PRINT-SYS022                      
-T4009*                                 FORM-STANDARD-ONCE.                     
           CALL 'ZLINECT'               USING WS-LINE-COUNT.                    
-T4009*    SUBTRACT +18            FROM WS-LINE-COUNT.                          
+T4009     SUBTRACT +24            FROM WS-LINE-COUNT.                          
           MOVE WS-LINE-COUNT      TO   WS-LNE-CNT.                             
           MOVE ZEROS              TO   WS-STORED-PRODUCER.                     
           PERFORM ZERO-COUNTERS-BGN THRU                                       
                   ZERO-COUNTERS-END.                                           
           MOVE ARR-SRT-BR-BKR-AGT TO   WS-CURR-PRODUCER.                       
           CALL 'QDATE' USING           WS-QDATE-AD                             
                                        LSM-HIDATE                              
                                        WS-HD1-DATE.                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *       PROCESS TAPE RECORD READ FROM GIPSY PRINT FILE           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       REPORT2-PROCESSING.                                                      
           IF   ARR-TYPE     NOT  =    'H'                                      
               GO TO END-OF-REPORT2.                                            
           IF   ARR-REPORT   NOT  =    'A'                                      
               GO TO END-OF-REPORT2.                                            
           IF   ARR-REPORT-NUMBER NOT  =  '2'                                   
               GO TO END-OF-REPORT2.                                            
                                                                                
      *    REPORT IS TO INCLUDE ALL ALPHA CASES - REGARDLESS IF                 
      *    AGENT OR BROKERS, AND ALL CSP AND OMEGA CASES FOR AGENTS             
                                                                                
      *    IF   ARR-PCODE = '1'                                                 
      *         NEXT SENTENCE                                                   
      *    ELSE                                                                 
      *       IF (ARR-SRT-BR-BKR-AGT < 90000 OR                                 
      *        ( ARR-SRT-BR-BKR-AGT > 299999 AND                                
      *          ARR-SRT-BR-BKR-AGT < 900000 ) )                                
      * AGENT                                                                   
      *          NEXT SENTENCE                                                  
      *       ELSE                                                              
      * BROKER                                                                  
      *        MOVE ARR-SRT-BR-GFO-BR  TO BRANCH-GFO-FIELD                      
      *        IF BRANCH-GFO = '10'                                             
      *           NEXT SENTENCE                                                 
      *        ELSE                                                             
      *           GO TO READ-RECORD.                                            
                                                                                
           MOVE SPACES             TO WS-DETAIL1.                               
           MOVE ARR-SRT-BR-BKR-AGT TO WSD-PRODUCER.                             
           MOVE ARR-SRT-BR-GROUP   TO WSD-GROUP.                                
           MOVE ARR-SRT-BR-ACCT    TO WSD-ACCT.                                 
           MOVE ARR-SRT-BR-GFO-BR  TO WSD-BRANCH.                               
           CALL 'QDATE' USING WS-QDATE-AD                                       
                              ARR-OVERDATE                                      
                              WSD-OVDU-DATE.                                    
           MOVE ARR-OVERPREM       TO WSD-PREM-AMT.                             
           MOVE ARR-CURRPREM       TO WSD-CURR-PREM.                            
           MOVE ARR-TOTLPREM       TO WSD-TOT-PREM.                             
           IF  ARR-GRPIND = WS-NEW                                              
               MOVE WS-NEW-MSGE    TO WSD-CLAIM                                 
           ELSE                                                                 
               CALL 'QDATE' USING WS-QDATE-AD                                   
                                  ARR-SUSPDATE                                  
                                  WS-CLMSUS-DATE.                               
           IF  ARR-PCODE     = '1'                                              
               MOVE '  ALPHA   '  TO WS-PROD-CODE                               
           ELSE                                                                 
               MOVE 'OMEGA/CSP '  TO WS-PROD-CODE.                              
      *----------------------------------------------------------------*        
      *                                                                *        
      *      OBTAIN GROUP NAME FROM GIPSY MASTER TRAILER 030           *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE ARR-SRT-BR-GROUP TO E-GROUP.                                    
           MOVE ARR-SRT-BR-ACCT  TO E-ACCT.                                     
      *----------------------------------------------------------------*        
      *    SET UP THE NEW FIELDS ON THE ERROR RECORD.      MARCUS.     *        
      *----------------------------------------------------------------*        
           MOVE ARR-GRPOFF       TO E-OFFICE                                    
           MOVE ARR-PCODE        TO E-PROD-CD.                                  
           MOVE '030'            TO GBNTRIDENT.                                 
           MOVE SPACES           TO E-CODE.                                     
GNE        CALL GZACCMT7 USING E-NORM                                           
GNE                              GMBNATR                                        
GNE                              E-CODE.                                        
           IF  E-CODE NOT = SPACES                                              
           OR  GBNTRIDENT = SPACES                                              
               PERFORM ERR-ROUTINE-BGN THRU                                     
                       ERR-ROUTINE-END                                          
               GO TO LINE-CHECK.                                                
GNE        CALL GZNAEXP7 USING GMBNATR                                          
GNE                              WS-NMADDR                                      
GNE                              E-CODE.                                        
           IF  E-CODE NOT = SPACES                                              
               PERFORM ERR-ROUTINE-BGN THRU                                     
                       ERR-ROUTINE-END                                          
               GO TO LINE-CHECK.                                                
           MOVE WS-NA-LN (1)        TO WSD-GRPNAME.                             
       LINE-CHECK.                                                              
           IF  WS-LNE-CNT NOT = WS-LINE-COUNT                                   
           AND ARR-SRT-BR-BKR-AGT = WS-STORED-PRODUCER                          
               MOVE SPACES TO WS-WKD-CC                                         
           ELSE                                                                 
               MOVE '0' TO WS-WKD-CC.                                           
           IF  PREV-PCODE    = '1' AND                                          
               ARR-PCODE  NOT = '1'                                             
               MOVE '-'        TO WS-WKD-CC.                                    
           MOVE ARR-PCODE      TO PREV-PCODE.                                   
           MOVE WS-DETAIL1 TO WS-WKD-AREA.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  PRODUCER/AGENT CONTROL BREAK                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  WS-STORED-PRODUCER NOT = ZEROS                                   
           AND ARR-SRT-BR-BKR-AGT NOT = WS-STORED-PRODUCER                      
               PERFORM GROUP-BREAK-BGN THRU                                     
                       GROUP-BREAK-END.                                         
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           PERFORM ACCUM-TOTALS-BGN THRU                                        
                   ACCUM-TOTALS-END.                                            
       READ-RECORD.                                                             
           CALL 'DLSREAD' USING  TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 ARR-RECORD                                     
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
           IF  TAPE-RETURN NOT = ZEROS                                          
               GO TO END-OF-REPORT2.                                            
           GO TO REPORT2-PROCESSING.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 PRODUCES SUMMARY SHEET                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OF-REPORT2.                                                          
           PERFORM GROUP-BREAK-BGN THRU                                         
                   GROUP-BREAK-END.                                             
      *    SUBTRACT +1 FROM WS-CURR-TOT.                                        
      *    MOVE +1     TO WS-CURR-SUB.                                          
      *SUMMARY-LOOP.                                                            
      *    IF  WS-CURR-SUB > WS-CURR-TOT                                        
      *        GO TO SUMMARY-END.                                               
      *    MOVE WS-TABLE-STATUS (WS-CURR-SUB) TO WS-CURR-STATUS.                
      *    IF  WS-CURR-STATUS = HIGH-VALUES                                     
      *        GO                             TO SUMMARY-END.                   
      *    MOVE SPACES                        TO WS-TOTAL1.                     
      *    MOVE WS-CURR-PRODUCER              TO WS-TOT-PRODUCER.               
      *    MOVE WST-PREM-AMT                  TO WS-TOT-PREM-AMT.               
      *    MOVE WST-CURR-PREM                 TO WS-TOT-CURR-PREM.              
      *    MOVE WST-TOT-PREM                  TO WS-TOT-TOT-PREM.               
      *    MOVE WS-TOTAL1                     TO WS-WKD-AREA.                   
      *    MOVE '0'                           TO WS-WKD-CC.                     
      *    PERFORM PRINT-ROUTINE-BGN THRU                                       
      *            PRINT-ROUTINE-END.                                           
      *    ADD WST-PREM-AMT                   TO WS-ENDTOT-PREM.                
      *    ADD WST-CURR-PREM                  TO WS-ENDTOT-CURR.                
      *    ADD WST-TOT-PREM                   TO WS-ENDTOT-TOT.                 
      *    ADD +1                             TO WS-CURR-SUB.                   
      *    GO                                 TO SUMMARY-LOOP.                  
      *SUMMARY-END.                                                             
      *    MOVE SPACES                        TO WS-TOTAL1.                     
      *    MOVE WS-COMPANY-MSGE               TO WS-COMPANY-HD.                 
      *    MOVE WS-ENDTOT-PREM                TO WS-TOT-PREM-AMT.               
      *    MOVE WS-ENDTOT-CURR                TO WS-TOT-CURR-PREM.              
      *    MOVE WS-ENDTOT-TOT                 TO WS-TOT-TOT-PREM.               
      *    MOVE WS-TOTAL1                     TO WS-WKD-AREA.                   
      *    MOVE '-'                           TO WS-WKD-CC.                     
      *    MOVE ZEROS                         TO WS-LNE-CNT.                    
      *    PERFORM PRINT-ROUTINE-BGN THRU                                       
      *            PRINT-ROUTINE-END.                                           
           GO                                 TO END-OPERATIONS.                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             ROUTINE USED IN NORMAL PROCESSING                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-ROUTINE-BGN.                                                       
           IF  WS-WKD-CC = '1'                                                  
               MOVE +1               TO WS-LNE-CNT                              
           ELSE                                                                 
               IF  WS-WKD-CC = ' '                                              
                   ADD +1            TO WS-LNE-CNT                              
                ELSE                                                            
                   IF  WS-WKD-CC IS EQUAL '0'                                   
                       ADD +2        TO WS-LNE-CNT                              
                   ELSE                                                         
                       IF  WS-WKD-CC = '-'                                      
                           ADD +3    TO WS-LNE-CNT.                             
           IF  WS-LNE-CNT > WS-LINE-COUNT                                       
               MOVE WS-WKD-DATA      TO WS-HOLD-DATA                            
               PERFORM TITLE-ROUTINE-BGN THRU                                   
                       TITLE-ROUTINE-END                                        
               MOVE WS-HOLD-DATA     TO WS-WKD-DATA                             
               MOVE '0'              TO WS-WKD-CC                               
               MOVE WS-CURR-PRODUCER TO WS-STORED-PRODUCER                      
                                        WS-WKD-OVFLW-GRP                        
               PERFORM OBTAIN-LABELS-BGN THRU                                   
                       OBTAIN-LABELS-END                                        
               GO TO PRINT-ROUTINE-BGN.                                         
           PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT.                       
       PRINT-ROUTINE-END.                                                       
           EXIT.                                                                
       CALL-DLSWRITE.                                                           
+T4009     CALL 'DLSWRITE' USING OUT-SYS021,                                    
+T4009                           OUT-RETURN,                                    
+T4009                           WS-WKD-DATA,                                   
+T4009                           OUT-RECSIZE,                                   
+T4009                           OUT-BLKSIZE,                                   
+T4009                           OUT-FORMAT,                                    
+T4009                           OUT-SYS021-COUNT.                              
                                                                                
-T4009*    CALL 'DLSWRITE' USING PRINT-SYS022,                                  
-T4009*                          PRINT-RETURN,                                  
-T4009*                          WS-WKD-DATA,                                   
-T4009*                          PRINT-RECSIZE,                                 
-T4009*                          PRINT-BLKSIZE,                                 
-T4009*                          PRINT-FORMAT,                                  
-T4009*                          PRINT-SYS022-COUNT.                            
       CALL-DLSWRITE-EXIT.                                                      
           EXIT.                                                                
       ACCUM-TOTALS-BGN.                                                        
           MOVE ARR-SRT-BR-BKR-AGT TO WS-CURR-PRODUCER.                         
           ADD ARR-OVERPREM        TO WST-PREM-AMT.                             
           ADD ARR-CURRPREM        TO WST-CURR-PREM.                            
           ADD ARR-TOTLPREM        TO WST-TOT-PREM.                             
       ACCUM-TOTALS-END.                                                        
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             BUILD AND PRINT GROUP TOTAL LINE                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       GROUP-BREAK-BGN.                                                         
           MOVE WS-WKD-DATA      TO WS-HOLD-DATA2.                              
           MOVE SPACES           TO WS-TOTAL1.                                  
           MOVE '-'              TO WS-WKD-CC.                                  
      *    MOVE WS-CURR-PRODUCER TO WS-TOT-PRODUCER.                            
           MOVE WS-TOTAL-MSGE    TO WS-TOT-HD.                                  
           MOVE WST-PREM-AMT     TO WS-TOT-PREM-AMT.                            
           MOVE WST-CURR-PREM    TO WS-TOT-CURR-PREM.                           
           MOVE WST-TOT-PREM     TO WS-TOT-TOT-PREM.                            
           MOVE WS-TOTAL1        TO WS-WKD-AREA.                                
           SUBTRACT +5        FROM  WS-LNE-CNT.                                 
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           ADD +5               TO  WS-LNE-CNT.                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *               STORE GROUP TOTAL FIGURES                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  WS-CURR-SUB > WS-MAX-SUB                                         
               MOVE HIGH-VALUES    TO WS-TABLE-STATUS (WS-MAX-SUB)              
           ELSE                                                                 
               MOVE WS-CURR-STATUS TO WS-TABLE-STATUS (WS-CURR-SUB)             
               ADD +1              TO WS-CURR-SUB WS-CURR-TOT.                  
           PERFORM PRINT-FOOTING-BGN THRU                                       
                   PRINT-FOOTING-END.                                           
           MOVE ZEROS              TO WS-CURR-PRODUCER                          
                                      WST-PREM-AMT                              
                                      WST-CURR-PREM.                            
           MOVE +0                 TO WST-TOT-PREM.                             
           MOVE WS-LINE-COUNT          TO WS-LNE-CNT.                           
           MOVE WS-HOLD-DATA2          TO WS-WKD-DATA.                          
           MOVE '0'                    TO WS-WKD-CC.                            
           IF   ARR-TYPE          =    'H'                                      
            AND ARR-REPORT        =    'A'                                      
               MOVE ARR-SRT-BR-BKR-AGT TO WS-CURR-PRODUCER.                     
       GROUP-BREAK-END.                                                         
           EXIT.                                                                
       PRINT-FOOTING-BGN.                                                       
           IF FOOTING-PRINTED-FLAG = 'Y'                                        
              GO TO PRINT-FOOTING-END.                                          
           IF WS-LNE-CNT > WS-LINE-COUNT                                        
              MOVE FOOTING-LINE-1  TO WS-WKD-AREA                               
              PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT                     
              MOVE FOOTING-LINE-2  TO WS-WKD-AREA                               
              PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT                     
              MOVE FOOTING-LINE-3  TO WS-WKD-AREA                               
              PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT                     
              MOVE FOOTING-LINE-4  TO WS-WKD-AREA                               
              PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT                     
              MOVE FOOTING-LINE-5  TO WS-WKD-AREA                               
              PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT                     
              MOVE 'Y'      TO    FOOTING-PRINTED-FLAG                          
           ELSE                                                                 
              MOVE SPACES      TO WS-WKD-AREA                                   
              MOVE '-'         TO WS-WKD-CC                                     
              ADD +3           TO WS-LNE-CNT                                    
              PERFORM CALL-DLSWRITE THRU CALL-DLSWRITE-EXIT                     
              GO TO PRINT-FOOTING-BGN.                                          
       PRINT-FOOTING-END.                                                       
           EXIT.                                                                
       TITLE-ROUTINE-BGN.                                                       
           PERFORM PRINT-FOOTING-BGN THRU                                       
                   PRINT-FOOTING-END.                                           
           MOVE 'N'            TO FOOTING-PRINTED-FLAG.                         
           ADD +1              TO ACCUM-LAPSE-MAIL.                             
           ADD +1              TO WS-PAGE-NUMBER.                               
           MOVE '1'            TO WS-WKD-CC.                                    
+T4009     PERFORM PRINT-HEAD0 THRU                                             
+T4009             PRINT-HEAD0-END.                                             
+T4009     MOVE SPACES         TO WS-WKD-CC.                                    
+T4009     PERFORM PRINT-HEAD0 THRU                                             
+T4009             PRINT-HEAD0-END                                              
+T4009             VARYING WS-HEAD0-CNT                                         
+T4009             FROM 1                                                       
+T4009             BY 1                                                         
+T4009             UNTIL WS-HEAD0-CNT > 5.                                      
           MOVE WS-PAGE-NUMBER TO WS-HD1-PAGE.                                  
           MOVE WS-HEAD1       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES         TO WS-WKD-CC.                                    
           MOVE WS-HEAD2       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE ZERO           TO WS-WKD-CC.                                    
           MOVE WS-HEAD3       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES         TO WS-WKD-CC.                                    
           MOVE WS-HEAD4       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
       TITLE-ROUTINE-END.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         REINITIALIZE GROUP OFFICE TABLE TO ZEROS.              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ZERO-COUNTERS-BGN.                                                       
           MOVE +1    TO WS-CURR-SUB.                                           
           MOVE ZEROS TO WS-CURR-PRODUCER                                       
                         WST-PREM-AMT                                           
                         WST-CURR-PREM.                                         
           MOVE +0    TO WST-TOT-PREM.                                          
       ZERO-LOOP.                                                               
           MOVE WS-CURR-STATUS TO WS-TABLE-STATUS (WS-CURR-SUB).                
           IF  WS-CURR-SUB NOT < WS-MAX-SUB                                     
               MOVE +1         TO WS-CURR-SUB                                   
               GO              TO ZERO-COUNTERS-END.                            
           ADD +1              TO WS-CURR-SUB.                                  
           GO                  TO ZERO-LOOP.                                    
       ZERO-COUNTERS-END.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *            WRITE OUT AN ERROR RECORD ON SYS011                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ERR-ROUTINE-BGN.                                                         
           CALL 'DLSWRITE' USING  TAPE-SYS011                                   
                                  TAPE-RETURN                                   
                                  ERR-REC                                       
                                  TAPE-SYS011-RECSIZE                           
                                  TAPE-SYS011-BLKSIZE                           
                                  TAPE-SYS011-FORMAT                            
                                  TAPE-SYS011-COUNT.                            
           MOVE SPACES            TO E-CODE.                                    
       ERR-ROUTINE-END.                                                         
           EXIT.                                                                
       END-OPERATIONS.                                                          
           IF LABEL-TO-PRINT = 'Y'                                              
              PERFORM PROCESS-LABELS-BGN THRU                                   
                      PROCESS-LABELS-END.                                       
                                                                                
           IF   ARR-TYPE          =    'H'                                      
            AND ARR-REPORT        =    'B'                                      
             AND TAPE-RETURN = ZEROS                                            
               GO                 TO UB-MODULE-CALL.                            
           MULTIPLY 2 BY ACCUM-LAPSE-MAIL.                                      
           MULTIPLY 2 BY ACCUM-OVERDUE.                                         
                                                                                
+T4009     MOVE +4       TO OUT-RETURN.                                         
+T4009     PERFORM CALL-DLSWRITE                                                
+T4009        THRU CALL-DLSWRITE-EXIT.                                          
                                                                                
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
                                                                                
       OBTAIN-LABELS-BGN.                                                       
           ADD 1                    TO LABEL-SUB.                               
           MOVE 'Y'                 TO LABEL-TO-PRINT.                          
           MOVE ARR-SRT-BR-GFO-BR   TO LABEL-OFFICE (LABEL-SUB).                
      *                                                                         
      *    READ AGENT FILE FOR AGENT NAME USING BILLING-AGENT                   
      *    NUMBER FROM MASTER RECORD                                            
      *                                                                         
           MOVE WS-CURR-PRODUCER    TO GFMAGENT-CODE.                           
           MOVE '0'                 TO GFMAGENT-ACCOUNT.                        
           MOVE 'GETRAN'            TO GFMAGENT-FUNCTION.                       
           CALL 'GFMAGENT'   USING     GFMAGENT-FUNCTION                        
                                       GFMAGENT-ERROR                           
                                       AGENT-NAME-FILE                          
                                       GFMAGENT-KEY.                            
           IF GFMAGENT-ERROR EQUAL LOW-VALUES                                   
               MOVE AGT-NAME          TO LABEL-PRODUCER (LABEL-SUB)             
           ELSE                                                                 
               MOVE WS-CURR-PRODUCER  TO LABEL-PRODUCER (LABEL-SUB).            
           IF LABEL-SUB = 4                                                     
              PERFORM PROCESS-LABELS-BGN THRU                                   
                      PROCESS-LABELS-END.                                       
                                                                                
       OBTAIN-LABELS-END.                                                       
           EXIT.                                                                
                                                                                
       PROCESS-LABELS-BGN.                                                      
           MOVE SPACES              TO PRINT-LINE                               
                                       LABEL-01                                 
                                       LABEL-02.                                
           IF LABEL-OFFICE (1) NOT = SPACES                                     
              MOVE LABEL-OFFICE (1)     TO L1-OFFICE-1                          
              MOVE 'OFFICE :'           TO L1-OFFICE-DESC-1                     
              MOVE LABEL-PRODUCER (1)   TO L2-PRODUCER-1.                       
                                                                                
           IF LABEL-OFFICE (2) NOT = SPACES                                     
              MOVE LABEL-OFFICE (2)     TO L1-OFFICE-2                          
              MOVE 'OFFICE : '          TO L1-OFFICE-DESC-2                     
              MOVE LABEL-PRODUCER (2)   TO L2-PRODUCER-2.                       
                                                                                
           IF LABEL-OFFICE (3) NOT = SPACES                                     
              MOVE LABEL-OFFICE (3)     TO L1-OFFICE-3                          
              MOVE 'OFFICE :'           TO L1-OFFICE-DESC-3                     
              MOVE LABEL-PRODUCER (3)   TO L2-PRODUCER-3.                       
                                                                                
           IF LABEL-OFFICE (4) NOT = SPACES                                     
              MOVE LABEL-OFFICE (4)     TO L1-OFFICE-4                          
              MOVE 'OFFICE :'           TO L1-OFFICE-DESC-4                     
              MOVE LABEL-PRODUCER (4)   TO L2-PRODUCER-4.                       
                                                                                
           PERFORM PRINT-LABELS-BGN THRU                                        
                   PRINT-LABELS-END 2 TIMES.                                    
           MOVE LABEL-01            TO PRINT-LINE.                              
           PERFORM PRINT-LABELS-BGN THRU                                        
                   PRINT-LABELS-END.                                            
           MOVE SPACES              TO PRINT-LINE.                              
           PERFORM PRINT-LABELS-BGN THRU                                        
                   PRINT-LABELS-END.                                            
           MOVE LABEL-02            TO PRINT-LINE.                              
           PERFORM PRINT-LABELS-BGN THRU                                        
                   PRINT-LABELS-END.                                            
           MOVE SPACES              TO PRINT-LINE.                              
           PERFORM PRINT-LABELS-BGN THRU                                        
                   PRINT-LABELS-END 3 TIMES.                                    
                                                                                
           MOVE SPACES              TO PRINT-LINE                               
                                       LABEL-01                                 
                                       LABEL-02.                                
           MOVE 'N' TO LABEL-TO-PRINT.                                          
           PERFORM INITIALIZE-TABLE-BGN THRU                                    
                   INITIALIZE-TABLE-END VARYING LABEL-SUB                       
                   FROM 1                                                       
                   BY 1                                                         
                   UNTIL LABEL-SUB > 4.                                         
           MOVE 0   TO LABEL-SUB.                                               
                                                                                
       PROCESS-LABELS-END.                                                      
           EXIT.                                                                
                                                                                
       INITIALIZE-TABLE-BGN.                                                    
           MOVE SPACES TO LABEL-OFFICE (LABEL-SUB)                              
                          LABEL-PRODUCER (LABEL-SUB).                           
                                                                                
       INITIALIZE-TABLE-END.                                                    
           EXIT.                                                                
                                                                                
       PRINT-LABELS-BGN.                                                        
           CALL 'DLSWRITE' USING PRINT-SYS067                                   
                                 PRINT-RETURN                                   
                                 PRINT-LINE-AREA                                
                                 PRINT-SYS067-RECSIZE                           
                                 PRINT-SYS067-BLKSIZE                           
                                 PRINT-SYS067-FORMAT                            
                                 PRINT-SYS067-COUNT.                            
                                                                                
       PRINT-LABELS-END.                                                        
           EXIT.                                                                
                                                                                
+T4009 PRINT-HEAD0.                                                             
+T4009     MOVE WS-HEAD0       TO WS-WKD-AREA.                                  
+T4009     PERFORM PRINT-ROUTINE-BGN THRU                                       
+T4009             PRINT-ROUTINE-END.                                           
+T4009 PRINT-HEAD0-END.                                                         
+T4009     EXIT.                                                                
