       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    GTABSC.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      *AUTHOR.        ANITA NIKELSKI.                                           
      *DATE-WRITTEN.  JUL 1992.                                                 
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *    BATCH INTERFACE FOR ACCESSING SALE CREDIT INFORMATION.               
      *    RETRIEVES A SALE CREDIT SCALE & FACTOR VALUES BASED ON PARMS         
      *    RECEIVED.                                                            
      ******************************************************************        
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(24)      VALUE                       
           'GTABSC WS STARTS HERE*'.                                            
                                                                                
       01  GTABSC-RECORD.                                                       
        COPY GTABPARM.                                                          
                                                                                
        COPY GARDTCMP.                                                          
                                                                                
       01  WS-ZPARDUMP-FUNCTION      PIC X(1)       VALUE '1'.                  
                                                                                
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH   PIC S9(3)      VALUE +133  COMP-3.         
               10  WTL-MESS-CC       PIC X(1)       VALUE SPACES.               
               10  WTL-MESS-TEXT     PIC X(132)     VALUE SPACES.               
           05  WTL-FLAG              PIC X(1)       VALUE 'B'.                  
           05  WTL-REPLY             PIC X(3)       VALUE 'NO '.                
           05  WTL-REPLY-AREA        PIC X(80)      VALUE SPACES.               
                                                                                
       01  ERROR-MESSAGE-LIST.                                                  
           05  ERR-1                 PIC X(80)      VALUE                       
               ' *** GTABSC ABENDED'.                                           
           05  ERR-2.                                                           
               10  FILLER            PIC X(5)       VALUE ' *** '.              
               10  ERR-2-DDNAME      PIC X(7)       VALUE SPACES.               
               10  FILLER            PIC X(8)       VALUE ' ERROR. '.           
               10  ERR-2-FUNCTION    PIC X(6)       VALUE SPACES.               
               10  FILLER            PIC X(10)      VALUE ' RETURN = '.         
               10  ERR-2-RET-CODE    PIC X(5)       VALUE SPACES.               
               10  FILLER            PIC X(7)       VALUE ' KEY = '.            
               10  ERR-2-KEY         PIC X(25)      VALUE SPACES.               
               10  FILLER            PIC X(7)       VALUE SPACES.               
                                                                                
       01  ERROR-MESSAGE-TABLE REDEFINES ERROR-MESSAGE-LIST.                    
           05  ERROR-MESSAGE-ENTRY OCCURS 2 TIMES.                              
               10  ERROR-MESSAGE     PIC X(80).                                 
                                                                                
       01  VSAM-RATE-PARAMETERS.                                                
           05  VSAM-RATE-PARM1.                                                 
               10  VSAM-RATE-DDNAME  PIC X(7)       VALUE 'VSDSI50'.            
               10  VSAM-RATE-ACCTYPE PIC X(5)       VALUE 'KEYED'.              
               10  VSAM-RATE-RECTYPE PIC X(1)       VALUE 'V'.                  
               10  VSAM-RATE-FUNC    PIC X(6)       VALUE SPACES.               
               10  VSAM-RATE-ERROR   PIC X(5)       VALUE SPACES.               
                   88  VSAM-RATE-NOT-FOUND          VALUE 'R0804'.              
               10  VSAM-RATE-READ-CT PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-WRT-CT  PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-UPD-CT  PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-DEL-CT  PIC S9(7)      VALUE +0   COMP-3.          
               10  VSAM-RATE-RECLEN  PIC S9(4)      VALUE +0   COMP.            
           05  VSAM-RATE-PARM2.                                                 
               10  VSAM-RATE-KEY     PIC X(25)      VALUE LOW-VALUES.           
                                                                                
       01  WS-END                    PIC X(24)      VALUE                       
           'GTABSC WS ENDS   HERE*'.                                            
       01  WS-END-BYTE-X             PIC X(1)       VALUE '*'.                  
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GWCDUMP                      PIC X(8)  VALUE 'GWCDUMP'.          
MAN07  COPY GWRDUMP.                                                            
MAN07  01  ICBM.                                                                
MAN07  COPY ICBM.                                                               
       LINKAGE SECTION.                                                         
                                                                                
           COPY GSCCALP.                                                        
                                                                                
       PROCEDURE DIVISION USING GSC-CALC-PARMS.                                 
                                                                                
       0000-GTABSC.                                                             
      ******************************************************************        
      *    INIT RETURN AREA.                                                    
      *    CAN WE USE TABLE CURRENTLY LOADED? IF NOT, GET CORRECT TABLE.        
      *    FETCH DESIRED INFO                                                   
      ******************************************************************        
           MOVE SPACES              TO GSC-RET-SCALE                            
                                       GSC-CALC-RET-CODE.                       
      *                                                                         
           PERFORM 1000-BUILD-KEY THRU                                          
                   1000-BUILD-KEY-EXIT.                                         
           PERFORM 2000-FIND-CURR-TABLE THRU                                    
                   2000-FIND-CURR-TABLE-EXIT                                    
           IF  NOT GSC-CALC-RET-SUCCESS                                         
               GO TO 0000-GTABSC-EXIT.                                          
      *                                                                         
           IF GSC-FIND-FACTOR = 'Y'                                             
              MOVE 'C'             TO GSC-RET-FLAG                              
MAN07         CALL 'GSCFACT' USING GSC-CALC-PARMS                               
MAN07                              GTABSC-REC-DATA.                             
      *                                                                         
      *    IF YOU WANT ONLY WANT THE CURRENT FACTOR, STOP PROCESSING            
      *                                                                         
           IF NOT GSC-CURR-OLD-FACTOR                                           
               GO TO 0000-GTABSC-EXIT.                                          
                                                                                
           PERFORM 3000-FIND-OLD-TABLE THRU                                     
                   3000-FIND-OLD-TABLE-EXIT                                     
           IF  NOT GSC-CALC-RET-SUCCESS                                         
               GO TO 0000-GTABSC-EXIT.                                          
      *                                                                         
           IF GSC-FIND-FACTOR = 'Y'                                             
              MOVE 'O'             TO GSC-RET-FLAG                              
MAN07         CALL 'GSCFACT' USING GSC-CALC-PARMS                               
MAN07                              GTABSC-REC-DATA.                             
       0000-GTABSC-EXIT.                                                        
           GOBACK.                                                              
                                                                                
       1000-BUILD-KEY.                                                          
      ******************************************************************        
      *    BUILD VSAM KEY USING PARMS PASSED.                                   
      ******************************************************************        
           MOVE LOW-VALUES           TO GTABSC-KEY.                             
           MOVE 'SCRATES '           TO GTABSC-NAME.                            
           MOVE GSC-PREM-DUE-DATE    TO GARDTCMP-YYYYMMDD.                      
                                                                                
MAN07      CALL 'GACDTCMP' USING GARDTCMP-DATE-AREA.                            
                                                                                
           MOVE GARDTCMP-FORMATTED-YYYYMMDD                                     
                                     TO GTABSC-EFF-DATE                         
                                        GSC-PREM-DUE-DATE.                      
                                                                                
       1000-BUILD-KEY-EXIT.                                                     
           EXIT.                                                                
                                                                                
       2000-FIND-CURR-TABLE.                                                    
      ******************************************************************        
      *    FIND THE CORRECT RATE TABLE TO USE.                                  
      *    SET INIT VSAM POSITION.                                              
      *    READ NEXT TABLE - SHOULD BE THE 1 REQUIRED.                          
      ******************************************************************        
           MOVE GTABSC-KEY              TO VSAM-RATE-PARM2.                     
           MOVE '0'                     TO GSC-CALC-RET-CODE.                   
      *                                                                         
           MOVE 'SETLIM'                TO VSAM-RATE-FUNC.                      
           PERFORM 9000-READ-VSAM-RECORD THRU                                   
                   9000-READ-VSAM-RECORD-EXIT.                                  
           IF  VSAM-RATE-NOT-FOUND                                              
               MOVE '1'                 TO GSC-CALC-RET-CODE                    
               GO TO 2000-FIND-CURR-TABLE-EXIT.                                 
           IF  VSAM-RATE-ERROR NOT = LOW-VALUES                                 
               MOVE '1'                 TO GSC-CALC-RET-CODE                    
               GO TO 9999-ABANDON-SHIP.                                         
      *                                                                         
           MOVE 'GETSEQ'                TO VSAM-RATE-FUNC.                      
           PERFORM 9000-READ-VSAM-RECORD THRU                                   
                   9000-READ-VSAM-RECORD-EXIT.                                  
           IF  VSAM-RATE-ERROR NOT = LOW-VALUES                                 
               MOVE '1'                 TO GSC-CALC-RET-CODE                    
               GO TO 9999-ABANDON-SHIP.                                         
           IF  GTABSC-NAME   NOT = 'SCRATES '                                   
               MOVE '1'                 TO GSC-CALC-RET-CODE                    
               GO TO 2000-FIND-CURR-TABLE-EXIT.                                 
                                                                                
           MOVE GTABSC-COMMISSION-SCALE TO GSC-RET-SCALE.                       
      *                                                                         
       2000-FIND-CURR-TABLE-EXIT.                                               
           EXIT.                                                                
                                                                                
       3000-FIND-OLD-TABLE.                                                     
      ******************************************************************        
      *    READ PRIOR TABLE - TO OBTAIN PREVIOUS FACTORS                        
      ******************************************************************        
           MOVE '0'                     TO GSC-CALC-RET-CODE.                   
      *                                                                         
           MOVE 'GETSEQ'                TO VSAM-RATE-FUNC.                      
           PERFORM 9000-READ-VSAM-RECORD THRU                                   
                   9000-READ-VSAM-RECORD-EXIT.                                  
           IF  VSAM-RATE-ERROR NOT = LOW-VALUES                                 
               MOVE '1'                 TO GSC-CALC-RET-CODE                    
               GO TO 9999-ABANDON-SHIP.                                         
           IF  GTABSC-NAME   NOT = 'SCRATES '                                   
               MOVE '1'                 TO GSC-CALC-RET-CODE                    
               GO TO 3000-FIND-OLD-TABLE-EXIT.                                  
                                                                                
           MOVE GTABSC-COMMISSION-SCALE TO GSC-RET-SCALE.                       
      *                                                                         
      *    CHECK THE EFFECTIVE DATES.                                           
      *    DATES ARE COMPLEMENTED SO THE TEST IS THE OPPOSITE OF WHAT           
      *    YOU WOULD NORMALLY EXPECT.                                           
      *                                                                         
       3000-FIND-OLD-TABLE-EXIT.                                                
           EXIT.                                                                
                                                                                
       9000-READ-VSAM-RECORD.                                                   
           CALL 'ZACCVSAM' USING VSAM-RATE-PARM1                                
                                 VSAM-RATE-PARM2                                
                                 GTABSC-RECORD.                                 
       9000-READ-VSAM-RECORD-EXIT.                                              
           EXIT.                                                                
                                                                                
       9999-ABANDON-SHIP.                                                       
           MOVE VSAM-RATE-DDNAME          TO ERR-2-DDNAME.                      
           MOVE VSAM-RATE-FUNC            TO ERR-2-FUNCTION.                    
           MOVE VSAM-RATE-ERROR           TO ERR-2-RET-CODE.                    
           MOVE VSAM-RATE-KEY             TO ERR-2-KEY.                         
                                                                                
           MOVE ERROR-MESSAGE (+1)        TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
           MOVE ERROR-MESSAGE (+2)        TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
                                                                                
GNE   *%   CALL 'ZPARDUMP' USING WS-ZPARDUMP-FUNCTION                           
      *%                         WS-START                                       
      *%                         WS-END-BYTE-X.                                 
MAN07      MOVE 'GTABSC' TO GWRDUMP-PROGRAM-NAME                                
MAN07      CALL GWCDUMP USING ICBM                                              
MAN07                         GWRDUMP.                                          
