       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
GNE                                                                             
       PROGRAM-ID.    GPROVRAG.                                                 
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *AUTHOR.        MATT PRANGE.                                              
      *DATE-WRITTEN.  DEC  1991.                                                
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *    THIS PROGRAM PRINTS THE GIPSY OVERAGE EXPIRY REPORT AND              
      *    LETTERS.                                                             
      ******************************************************************        
      *    AUG/92 K. CURRIE                                                     
      *         - ADDED CODE THAT WOULD CREATE THE OVERAGE LETTERS.             
      *                                                                         
      *    OCT/97 D'WIZ SYSTEMS                          B. PUCAN       YEAR2000
      *           MODIFY FOR Y2K COMPLIANCE.                            YEAR2000
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      *                                                                 YEAR2000
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(24)      VALUE                       
           'GPROVRAG WS STARTS HERE '.                                          
                                                                                
       01  WS-SAVE-RUN-DATE.                                                    
           05  WS-SAVE-RUN-YEAR      PIC S9(3)      VALUE +0     COMP-3.        
           05  WS-SAVE-RUN-DAY       PIC S9(3)      VALUE +0     COMP-3.        
                                                                                
       01  WS-SINGLE-SPACE           PIC X(1)       VALUE ' '.                  
       01  WS-DOUBLE-SPACE           PIC X(1)       VALUE '0'.                  
       01  WS-TRIPLE-SPACE           PIC X(1)       VALUE '-'.                  
       01  WS-NEW-PAGE               PIC X(1)       VALUE '1'.                  
       01  WS-LINE-CNT               PIC S9(4)      VALUE +0     COMP.          
       01  WS-LINE-MAX               PIC S9(4)      VALUE +60    COMP.          
       01  WS-LINE-INCR              PIC S9(4)      VALUE +0     COMP.          
       01  WS-PAGE-CNT               PIC S9(4)      VALUE +0     COMP.          
       01  LETTR-EN-SUB              PIC S9(4)      VALUE +0     COMP.          
       01  LETTR-FR-SUB              PIC S9(4)      VALUE +0     COMP.          
       01  LETTR-EN-SUB-MAX          PIC S9(4)      VALUE +100   COMP.          
       01  LETTR-FR-SUB-MAX          PIC S9(4)      VALUE +100   COMP.          
       01  SUB-1                     PIC S9(4)      VALUE +0     COMP.          
       01  SUB-1-MAX                 PIC S9(4)      VALUE +20    COMP.          
       01  SUB-2                     PIC S9(4)      VALUE +0     COMP.          
       01  ADDR-SUB                  PIC S9(4)      VALUE +0     COMP.          
       01  WS-WORK-GROUP-ACCT.                                                  
GNE        05  WS-WORK-GROUP         PIC 9(7)       VALUE ZERO.                 
           05  FILLER                PIC X(1)       VALUE SPACES.               
           05  WS-WORK-ACCT          PIC X(3)       VALUE SPACES.               
                                                                                
       01  WS-WORK-TEXT              PIC X(20)      VALUE SPACES.               
       01  WS-WORK-AMT REDEFINES WS-WORK-TEXT                                   
                                     PIC $$$$,$$$,$$9.99-.                      
       01  WS-ARRAY1 REDEFINES WS-WORK-TEXT.                                    
           05  WS-ARRAY1-ENTRY OCCURS 20 TIMES.                                 
               10  WS-ARRAY1-CHAR    PIC X(1).                                  
       01  WS-ARRAY2.                                                           
           05  WS-ARRAY2-ENTRY OCCURS 20 TIMES.                                 
               10  WS-ARRAY2-CHAR    PIC X(1).                                  
                                                                                
       01  WS-LETTER-EN-RECORD       PIC X(80)      VALUE SPACES.               
                                                                                
       01  WS-LETTER-FR-RECORD       PIC X(80)      VALUE SPACES.               
                                                                                
       01  WS-LETTER-EN-TABLE.                                                  
           05  WS-LETTER-EN-ENTRY OCCURS 100 TIMES.                             
               10  WS-LETTER-EN-LINE PIC X(80).                                 
                                                                                
       01  WS-LETTER-FR-TABLE.                                                  
           05  WS-LETTER-FR-ENTRY OCCURS 100 TIMES.                             
               10  WS-LETTER-FR-LINE PIC X(80).                                 
                                                                                
       01  WS-LETTER-VAR-LINE.                                                  
           05  FILLER                PIC X(4)       VALUE '.SE '.               
           05  WS-LETTER-VAR-NAME    PIC X(7)       VALUE SPACES.               
           05  FILLER                PIC X(1)       VALUE QUOTE.                
           05  WS-LETTER-VAR-TEXT.                                              
               10  WS-LETTER-VAR-VAL PIC $$$,$$$,$$9.99.                        
               10  FILLER            PIC X(21)      VALUE SPACES.               
                                                                                
       01  WS-LETTER-WORK-DATE.                                                 
           05  WS-LETTER-WORK-MONTH  PIC X(9)       VALUE SPACES.               
           05  WS-LETTER-WORK-CHAR   PIC X(1)       VALUE SPACES.               
           05  WS-LETTER-WORK-DAY    PIC Z9.                                    
           05  WS-LETTER-WORK-COMMA  PIC X(2)       VALUE SPACES.               
           05  WS-LETTER-WORK-YEAR   PIC 9(4)       VALUE ZERO.                 
                                                                                
       01  WS-LETTER-RUN-DATE-EN     PIC X(20)      VALUE SPACES.               
       01  WS-LETTER-RUN-DATE-FR     PIC X(20)      VALUE SPACES.               
       01  WS-LETTER-EXPIRY-DATE     PIC X(20)      VALUE SPACES.               
                                                                                
       01  WS-MONTH-LIST.                                                       
           05  FILLER                PIC X(22)                                  
                                     VALUE 'JAN JANUARY  JANVIER '.             
           05  FILLER                PIC X(22)                                  
                                     VALUE 'FEB FEBRUARY F�VRIER  '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'MAR MARCH    MARS     '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'APR APRIL    AVRIL    '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'MAY MAY      MAI      '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'JUN JUNE     JUIN     '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'JUL JULY     JUILLET  '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'AUG AUGUST   A�OT     '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'SEP SEPTEMBERSEPTEMBRE'.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'OCT OCTOBER  OCTOBRE  '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'NOV NOVEMBER NOVEMBRE '.            
           05  FILLER                PIC X(22)                                  
                                     VALUE 'DEC DECEMBER D�CEMBRE '.            
       01  WS-MONTH-TABLE REDEFINES WS-MONTH-LIST.                              
           05  WS-MONTH-ENTRY OCCURS 12 TIMES.                                  
               10  WS-MONTH-ABBREV   PIC X(3).                                  
               10  FILLER            PIC X(1).                                  
               10  WS-MONTH-NAME-EN  PIC X(9).                                  
               10  WS-MONTH-NAME-FR  PIC X(9).                                  
                                                                                
       01  WS-CURR-TIME.                                                        
           05  WS-CURR-HOUR          PIC 9(2)       VALUE ZERO.                 
           05  WS-CURR-MINUTE        PIC 9(2)       VALUE ZERO.                 
           05  WS-CURR-SECOND        PIC 9(2)       VALUE ZERO.                 
           05  WS-CURR-TENTH         PIC 9(2)       VALUE ZERO.                 
       01  WS-CURR-DATE.                                                        
           05  WS-CURR-YEAR          PIC 9(4)       VALUE ZERO.         YEAR2000
MAN07      05  WS-CURR-MONTH         PIC 9(2)       VALUE ZERO.                 
           05  WS-CURR-DAY           PIC 9(2)       VALUE ZERO.                 
       01  WS-CURR-DATE2.                                                       
           05  WS-CURR-DD            PIC 9(4)       VALUE ZERO.         YEAR2000
           05  WS-CURR-MMM           PIC X(3)       VALUE SPACES.               
           05  WS-CURR-YY            PIC 9(2)       VALUE ZERO.                 
                                                                                
       01  LETTER-RECORD.                                                       
           05  FILLER                PIC X(80)      VALUE SPACES.               
                                                                                
       01  HDG1-RECORD.                                                         
           05  HDG1-CC               PIC X(1)       VALUE '1'.                  
           05  HDG1-PROGRAM          PIC X(8)       VALUE 'GPROVRAG'.           
           05  FILLER                PIC X(43)      VALUE SPACES.               
           05  FILLER                PIC X(27)      VALUE                       
               'GIPSY OVERAGE EXPIRY REPORT'.                                   
           05  FILLER                PIC X(44)      VALUE SPACES.               
           05  FILLER                PIC X(6)       VALUE                       
               'PAGE: '.                                                        
           05  HDG1-PAGE             PIC ZZZ9.                                  
                                                                                
       01  HDG2-RECORD.                                                         
           05  HDG2-CC               PIC X(1)       VALUE ' '.                  
           05  FILLER                PIC X(42)      VALUE SPACES.               
           05  FILLER                PIC X(30)      VALUE                       
               'OVERAGE COVERAGE EXPIRED FROM '.                                
           05  HDG2-FROM-DATE        PIC X(7)       VALUE SPACES.               
           05  FILLER                PIC X(4)       VALUE ' TO '.               
           05  HDG2-TO-DATE          PIC X(7)       VALUE SPACES.               
           05  FILLER                PIC X(42)      VALUE SPACES.               
                                                                                
       01  HDG3-RECORD.                                                         
           05  HDG3-CC               PIC X(1)       VALUE '0'.                  
           05  FILLER                PIC X(50)      VALUE                       
               '                            EXPIRY                '.            
           05  FILLER                PIC X(50)      VALUE                       
               '                                                  '.            
           05  FILLER                PIC X(32)      VALUE                       
               '                                '.                              
                                                                                
       01  HDG4-RECORD.                                                         
           05  HDG4-CC               PIC X(1)       VALUE ' '.                  
GNE        05  FILLER                PIC X(52)      VALUE                       
GNE            'GROUP     ACCT        CERT     DATE      CERTHOLDER '.          
           05  FILLER                PIC X(50)      VALUE                       
               'NAME                                              '.            
           05  FILLER                PIC X(32)      VALUE                       
               '                                '.                              
                                                                                
       01  HDG5-RECORD.                                                         
           05  HDG5-CC               PIC X(1)       VALUE ' '.                  
GNE        05  FILLER                PIC X(52)      VALUE                       
GNE            '-------   ----   ---------   ---------   -----------'.          
           05  FILLER                PIC X(50)      VALUE                       
               '---------------------                             '.            
           05  FILLER                PIC X(32)      VALUE                       
               '                                '.                              
                                                                                
       01  HDG99-RECORD.                                                        
           05  HDG99-CC              PIC X(1)       VALUE '-'.                  
           05  FILLER                PIC X(132)     VALUE                       
               '** END OF REPORT **'.                                           
                                                                                
       01  REPORT-RECORD-SAVE.                                                  
           05  RPT-SAVE-CC           PIC X(1)       VALUE SPACES.               
           05  FILLER                PIC X(132)     VALUE SPACES.               
                                                                                
       01  REPORT-RECORD.                                                       
           05  RPT-CC                PIC X(1)       VALUE SPACES.               
           05  FILLER                PIC X(132)     VALUE SPACES.               
                                                                                
       01  DETAIL-RECORD.                                                       
           05  DET-CC                PIC X(1)       VALUE ' '.                  
GNE        05  DET-GROUP             PIC 9(7)       VALUE ZERO.                 
           05  FILLER                PIC X(4)       VALUE SPACES.               
           05  DET-ACCT              PIC X(3)       VALUE SPACES.               
           05  FILLER                PIC X(3)       VALUE SPACES.               
           05  DET-CERT              PIC ZZZZZZZZ9.                             
           05  FILLER                PIC X(3)       VALUE SPACES.               
           05  DET-EXPIRY-DATE.                                                 
               10  DET-EXPIRY-DAY    PIC 9(2)       VALUE ZERO.                 
               10  DET-EXPIRY-MONTH  PIC X(3)       VALUE SPACES.               
               10  DET-EXPIRY-YEAR   PIC 9(4)       VALUE ZERO.                 
           05  FILLER                PIC X(3)       VALUE SPACES.               
           05  DET-NAME              PIC X(32)      VALUE SPACES.               
GNE        05  FILLER                PIC X(59)      VALUE SPACES.               
                                                                                
       01  FILLER                    PIC X(16)      VALUE                       
           'GARDATEP STARTS '.                                                  
                                                                                
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
       01  READ-LETTER-EN-PARMS.                                                
           05  READ-LETT-EN-SYSUNIT  PIC X(6)       VALUE 'SYS069'.             
           05  READ-LETT-EN-RET-CODE PIC S9(1)      VALUE +0   COMP-3.          
               88  READ-LETT-EN-OK                  VALUE +0.                   
               88  READ-LETT-EN-EOF                 VALUE +4.                   
           05  READ-LETT-EN-RECSZ    PIC 9(5)       VALUE 80.                   
           05  READ-LETT-EN-BLKSZ    PIC 9(5)       VALUE 6160.                 
           05  READ-LETT-EN-RECFM    PIC X(2)       VALUE 'FB'.                 
           05  READ-LETT-EN-REC-CNT  PIC S9(7)      VALUE +0   COMP-3.          
                                                                                
       01  READ-LETTER-FR-PARMS.                                                
           05  READ-LETT-FR-SYSUNIT  PIC X(6)       VALUE 'SYS040'.             
           05  READ-LETT-FR-RET-CODE PIC S9(1)      VALUE +0   COMP-3.          
               88  READ-LETT-FR-OK                  VALUE +0.                   
               88  READ-LETT-FR-EOF                 VALUE +4.                   
           05  READ-LETT-FR-RECSZ    PIC 9(5)       VALUE 80.                   
           05  READ-LETT-FR-BLKSZ    PIC 9(5)       VALUE 6160.                 
           05  READ-LETT-FR-RECFM    PIC X(2)       VALUE 'FB'.                 
           05  READ-LETT-FR-REC-CNT  PIC S9(7)      VALUE +0   COMP-3.          
                                                                                
       01  WRITE-REPORT-PARMS.                                                  
           05  WRITE-RPT-SYSUNIT     PIC X(6)       VALUE 'SYS041'.             
           05  WRITE-RPT-RET-CODE    PIC S9(1)      VALUE +0   COMP-3.          
               88  WRITE-RPT-OK                     VALUE +0.                   
               88  WRITE-RPT-EOF                    VALUE +4.                   
           05  WRITE-RPT-RECSZ       PIC 9(5)       VALUE 133.                  
           05  WRITE-RPT-BLKSZ       PIC 9(5)       VALUE 3990.                 
           05  WRITE-RPT-RECFM       PIC X(2)       VALUE 'FB'.                 
           05  WRITE-RPT-REC-CNT     PIC S9(7)      VALUE +0   COMP-3.          
                                                                                
       01  WRITE-LETTER-PARMS.                                                  
           05  WRITE-LETT-SYSUNIT    PIC X(6)       VALUE 'SYS042'.             
           05  WRITE-LETT-RET-CODE   PIC S9(1)      VALUE +0   COMP-3.          
               88  WRITE-LETT-OK                    VALUE +0.                   
               88  WRITE-LETT-EOF                   VALUE +4.                   
           05  WRITE-LETT-RECSZ      PIC 9(5)       VALUE 80.                   
           05  WRITE-LETT-BLKSZ      PIC 9(5)       VALUE 23440.                
           05  WRITE-LETT-RECFM      PIC X(2)       VALUE 'FB'.                 
           05  WRITE-LETT-REC-CNT    PIC S9(7)      VALUE +0   COMP-3.          
                                                                                
       01  WS-END                    PIC X(24)      VALUE                       
           'GPROVRAG WS ENDS   HERE '.                                          
       01  WS-END-BYTE-X             PIC X(1)       VALUE SPACES.               
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GC2DATE                      PIC X(8)  VALUE 'GC2DATE'.          
       LINKAGE SECTION.                                                         
                                                                                
       01  CLOSE-FILES-FLAG          PIC X(1).                                  
                                                                                
      *01  GOVERAGE.                                                            
           COPY GOVERAGE.                                                       
           05  FILLER                PIC X(7000).                               
                                                                                
      *01  GPRTPARM.                                                            
           COPY GPRTPARM.                                                       
                                                                                
      *01  GPRACCUM.                                                            
           COPY GPRACCUM.                                                       
                                                                                
       01  MISC-AREA.                                                           
           05  ST-LODATE             PIC X(4).                                  
           05  ST-HIDATE             PIC X(4).                                  
           05  ST-STATDATE           PIC X(4).                                  
           05  ST-PREMDATE           PIC X(4).                                  
           05  RESTART-INFO.                                                    
               10  RESTART-RECORD-TYPE-X.                                       
                   15  RESTART-RECORD-TYPE                                      
                                     PIC 9(1).                                  
               10  FILLER            PIC X(11).                                 
           05  ST-CUR-LODATE         PIC X(4).                                  
                                                                                
       PROCEDURE DIVISION USING CLOSE-FILES-FLAG                                
                                GOVERAGE                                        
                                GPRTPARM                                        
                                GPRACCUM                                        
                                MISC-AREA.                                      
                                                                                
       0000-GPROVRAG.                                                           
                                                                                
           IF  CLOSE-FILES-FLAG = 'Y'                                           
               PERFORM 1925-CLOSE-FILES THRU                                    
                       1925-CLOSE-FILES-EXIT                                    
               GO TO 0000-GPROVRAG-EXIT.                                        
                                                                                
           PERFORM 1000-INITIALIZATION THRU                                     
                   1000-INITIALIZATION-EXIT.                                    
           PERFORM 2000-MAIN-PROCESS THRU                                       
                   2000-MAIN-PROCESS-EXIT UNTIL                                 
                   GOVERAGE-RECTYPE NOT = 'X' OR                                
                   TAPE-RETURN      NOT = +0.                                   
           PERFORM 1900-FINALIZATION THRU                                       
                   1900-FINALIZATION-EXIT.                                      
                                                                                
       0000-GPROVRAG-EXIT.                                                      
           GOBACK.                                                              
                                                                                
       1000-INITIALIZATION.                                                     
      ******************************************************************        
      *                                                                         
      ******************************************************************        
           MOVE +99                        TO WS-LINE-CNT.                      
      *                                                                         
           PERFORM 1025-SET-REPORT-DATES THRU                                   
                   1025-SET-REPORT-DATES-EXIT.                                  
                                                                                
           PERFORM 1100-STORE-LETTER-EN THRU                                    
                   1100-STORE-LETTER-EN-EXIT.                                   
                                                                                
           PERFORM 1100-STORE-LETTER-FR THRU                                    
                   1100-STORE-LETTER-FR-EXIT.                                   
                                                                                
       1000-INITIALIZATION-EXIT.                                                
           EXIT.                                                                
                                                                                
       1025-SET-REPORT-DATES.                                                   
      **************************************************************            
      *    CHANGE SYSTEM DATE TO DESIRED FORMATS.                               
      *    THE '!' ARE INTERPRETED BY SCRIPT AS BLANKS BUT WILL                 
      *    KEEP TEXT STRING TOGETHER ON ONE LINE.                               
      **************************************************************            
           MOVE 'EA1E' TO GAC-DATE-PARAMETERS.                          YEAR2000
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           MOVE VDATE1-YYYYMMDD TO WS-CURR-DATE.                        YEAR2000
           MOVE WS-CURR-YEAR          TO WS-CURR-YY.                            
           MOVE WS-CURR-DAY           TO WS-CURR-DD.                            
           MOVE WS-MONTH-ABBREV (WS-CURR-MONTH)                                 
                                      TO WS-CURR-MMM.                           
                                                                                
           MOVE SPACES                TO WS-LETTER-WORK-DATE.                   
           MOVE WS-MONTH-NAME-EN (WS-CURR-MONTH)                                
                                      TO WS-LETTER-WORK-MONTH.                  
           MOVE '!'                   TO WS-LETTER-WORK-CHAR.                   
           MOVE WS-CURR-DAY           TO WS-LETTER-WORK-DAY.                    
           MOVE ',!'                  TO WS-LETTER-WORK-COMMA.                  
           COMPUTE WS-LETTER-WORK-YEAR = WS-CURR-YEAR.                  YEAR2000
           MOVE WS-LETTER-WORK-DATE   TO WS-WORK-TEXT.                          
           PERFORM 7000-TURF-ALL-BLANKS THRU                                    
                   7000-TURF-ALL-BLANKS-EXIT.                                   
           MOVE WS-ARRAY2             TO WS-LETTER-RUN-DATE-EN.                 
                                                                                
           MOVE SPACES                TO WS-LETTER-WORK-DATE.                   
           MOVE WS-MONTH-NAME-FR (WS-CURR-MONTH)                                
                                      TO WS-LETTER-WORK-MONTH.                  
           MOVE '!'                   TO WS-LETTER-WORK-CHAR.                   
           MOVE WS-CURR-DAY           TO WS-LETTER-WORK-DAY.            YEAR2000
           MOVE ',!'                  TO WS-LETTER-WORK-COMMA.                  
           COMPUTE WS-LETTER-WORK-YEAR = WS-CURR-YEAR.                          
           MOVE WS-LETTER-WORK-DATE   TO WS-WORK-TEXT.                          
           PERFORM 7000-TURF-ALL-BLANKS THRU                                    
                   7000-TURF-ALL-BLANKS-EXIT.                                   
           MOVE WS-ARRAY2             TO WS-LETTER-RUN-DATE-FR.                 
                                                                                
      ******************************************************************        
      *    SET THE 'FROM' AND 'TO' DATES FOR THE REPORT.                        
      ******************************************************************        
      *                                                                         
      *    CONVERT ALIS RUN HI-DATE TO DDMMMYY FORMAT                           
      *                                                                         
           MOVE '2B1E'                    TO VDATE-REQUEST-AREA.                
           MOVE ST-HIDATE                 TO VDATE-ALIS-DATE1.                  
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
      *                                                                         
      *    FORCE RUN HI-DATE IN DDMMMYY FORMAT TO THE 1ST OF THE MONTH.         
      *                                                                         
           MOVE '01'                      TO VDATE-EXT-DAY.                     
           MOVE '1B1E'                    TO VDATE-REQUEST-AREA.                
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           MOVE VDATE-ALIS-DATE1          TO WS-SAVE-RUN-DATE.                  
      *                                                                         
      *    SUBTRACT 1 MONTH TO GET LOW REPORT DATE.                             
      *                                                                         
           MOVE '4B  '                    TO VDATE-REQUEST-AREA.                
           MOVE WS-SAVE-RUN-DATE          TO VDATE-ALIS-DATE1.                  
           MOVE +0                        TO VDATE-ADJUST-YEARS                 
                                             VDATE-ADJUST-DAYS.                 
           MOVE -1                        TO VDATE-ADJUST-MONTHS.               
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
                                                                                
           MOVE '2B2E'                    TO VDATE-REQUEST-AREA.                
           MOVE VDATE-ALIS-DATE2          TO VDATE-ALIS-DATE1.                  
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           MOVE VDATE-EXT-DATE            TO HDG2-FROM-DATE.                    
      *                                                                         
      *    SUBTRACT 1 DAY TO GET HIGH REPORT DATE.                              
      *                                                                         
           MOVE '4B  '                    TO VDATE-REQUEST-AREA.                
           MOVE WS-SAVE-RUN-DATE          TO VDATE-ALIS-DATE1.                  
           MOVE +0                        TO VDATE-ADJUST-YEARS                 
                                             VDATE-ADJUST-MONTHS.               
           MOVE -1                        TO VDATE-ADJUST-DAYS.                 
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
                                                                                
           MOVE '2B2E'                    TO VDATE-REQUEST-AREA.                
           MOVE VDATE-ALIS-DATE2          TO VDATE-ALIS-DATE1.                  
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           MOVE VDATE-EXT-DATE            TO HDG2-TO-DATE.                      
       1025-SET-REPORT-DATES-EXIT.                                              
           EXIT.                                                                
                                                                                
       1100-STORE-LETTER-EN.                                                    
      **************************************************************            
      *    STORE CANNED LETTER LINES IN WS TABLE.                               
      *    KEEP TRACK OF HOW MANY LINES WERE READ IN.                           
      **************************************************************            
           MOVE +0               TO LETTR-EN-SUB.                               
           PERFORM 1100-SAVE-LETTER-EN-LINE THRU                                
                   1100-SAVE-LETTER-EN-LINE-EXIT UNTIL                          
                   READ-LETT-EN-EOF OR                                          
                   LETTR-EN-SUB > LETTR-EN-SUB-MAX.                             
           MOVE LETTR-EN-SUB     TO LETTR-EN-SUB-MAX.                           
       1100-STORE-LETTER-EN-EXIT.                                               
           EXIT.                                                                
                                                                                
       1100-SAVE-LETTER-EN-LINE.                                                
      **************************************************************            
      *    SAVE LETTER LINE IN TABLE.                                           
      **************************************************************            
           PERFORM 9000-READ-LETTER-EN THRU                                     
                   9000-READ-LETTER-EN-EXIT.                                    
           IF  READ-LETT-EN-EOF                                                 
               GO TO 1100-SAVE-LETTER-EN-LINE-EXIT.                             
           ADD  +1                  TO LETTR-EN-SUB.                            
           MOVE WS-LETTER-EN-RECORD TO WS-LETTER-EN-LINE (LETTR-EN-SUB).        
       1100-SAVE-LETTER-EN-LINE-EXIT.                                           
           EXIT.                                                                
                                                                                
       1100-STORE-LETTER-FR.                                                    
      **************************************************************            
      *    STORE CANNED LETTER LINES IN WS TABLE.                               
      *    KEEP TRACK OF HOW MANY LINES WERE READ IN.                           
      **************************************************************            
           MOVE +0               TO LETTR-FR-SUB.                               
           PERFORM 1100-SAVE-LETTER-FR-LINE THRU                                
                   1100-SAVE-LETTER-FR-LINE-EXIT UNTIL                          
                   READ-LETT-FR-EOF OR                                          
                   LETTR-FR-SUB > LETTR-FR-SUB-MAX.                             
           MOVE LETTR-FR-SUB     TO LETTR-FR-SUB-MAX.                           
       1100-STORE-LETTER-FR-EXIT.                                               
           EXIT.                                                                
                                                                                
       1100-SAVE-LETTER-FR-LINE.                                                
      **************************************************************            
      *    SAVE LETTER LINE IN TABLE.                                           
      **************************************************************            
           PERFORM 9000-READ-LETTER-FR THRU                                     
                   9000-READ-LETTER-FR-EXIT.                                    
           IF  READ-LETT-FR-EOF                                                 
               GO TO 1100-SAVE-LETTER-FR-LINE-EXIT.                             
           ADD  +1                  TO LETTR-FR-SUB.                            
           MOVE WS-LETTER-FR-RECORD TO WS-LETTER-FR-LINE (LETTR-FR-SUB).        
       1100-SAVE-LETTER-FR-LINE-EXIT.                                           
           EXIT.                                                                
                                                                                
       1900-FINALIZATION.                                                       
      ******************************************************************        
      *    WRITE 'END OF REPORT' LINE.                                          
      *    CLOSE FILES.                                                         
      ******************************************************************        
           MOVE HDG99-RECORD           TO REPORT-RECORD.                        
           PERFORM 8000-PRINT-REPORT-LINE THRU                                  
                   8000-PRINT-REPORT-LINE-EXIT.                                 
      *                                                                         
      *    PERFORM 1925-CLOSE-FILES THRU                                        
      *            1925-CLOSE-FILES-EXIT.                                       
       1900-FINALIZATION-EXIT.                                                  
           EXIT.                                                                
                                                                                
       1925-CLOSE-FILES.                                                        
      ******************************************************************        
      *    CLOSE FILES.                                                         
      ******************************************************************        
           MOVE +4                     TO WRITE-RPT-RET-CODE.                   
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE +4                     TO WRITE-LETT-RET-CODE.                  
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
       1925-CLOSE-FILES-EXIT.                                                   
           EXIT.                                                                
                                                                                
       2000-MAIN-PROCESS.                                                       
      ******************************************************************        
      *    PRINT CURRENT EXTRACT.                                               
      *    READ NEXT EXTRACT.                                                   
      ******************************************************************        
           IF  GOVERAGE-SUBTYPE-REPORT                                          
               PERFORM 3000-OVERAGE-REPORT THRU                                 
                       3000-OVERAGE-REPORT-EXIT                                 
           ELSE                                                                 
           IF  GOVERAGE-SUBTYPE-LETTER                                          
               PERFORM 4000-OVERAGE-LETTER THRU                                 
                       4000-OVERAGE-LETTER-EXIT.                                
      *                                                                         
           PERFORM 9000-READ-EXTRACT THRU                                       
                   9000-READ-EXTRACT-EXIT.                                      
       2000-MAIN-PROCESS-EXIT.                                                  
           EXIT.                                                                
                                                                                
       3000-OVERAGE-REPORT.                                                     
      ******************************************************************        
      *    PRINT CURRENT REPORT EXTRACT.                                        
      ******************************************************************        
           MOVE SPACES                     TO DETAIL-RECORD.                    
           MOVE WS-SINGLE-SPACE            TO DET-CC.                           
                                                                                
           MOVE GOVERAGE-GROUP             TO DET-GROUP.                        
           MOVE GOVERAGE-ACCT              TO DET-ACCT.                         
           MOVE GOVERAGE-CERT              TO DET-CERT.                         
                                                                                
           MOVE GOVERAGE-R-EXPIRY-DATE     TO VDATE-ALIS-DATE1.                 
           MOVE '2B1E'                     TO VDATE-REQUEST-AREA.               
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           IF  VDATE-RET-FAIL                                                   
               MOVE '?????????'            TO DET-EXPIRY-DATE                   
           ELSE                                                                 
               MOVE VDATE-EXT-DATE         TO DET-EXPIRY-DATE.                  
                                                                                
           MOVE GOVERAGE-R-CERT-NAME       TO DET-NAME.                         
      *                                                                         
           MOVE +1                         TO WS-LINE-INCR.                     
           MOVE DETAIL-RECORD              TO REPORT-RECORD.                    
           PERFORM 8000-PRINT-REPORT-LINE THRU                                  
                   8000-PRINT-REPORT-LINE-EXIT.                                 
       3000-OVERAGE-REPORT-EXIT.                                                
           EXIT.                                                                
                                                                                
       4000-OVERAGE-LETTER.                                                     
      ******************************************************************        
      *    PRINT CURRENT LETTER EXTRACT.                                        
      ******************************************************************        
      *    CONVERT EXPIRY DATE FROM ALIS TO DDMMMYYYY FORMAT.                   
           MOVE GOVERAGE-L-EXPIRY-DATE TO VDATE-ALIS-DATE1.                     
           MOVE '2B1E'                TO VDATE-REQUEST-AREA.                    
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
                                                                                
           MOVE SPACES                TO WS-LETTER-WORK-DATE.                   
           MOVE '!'                   TO WS-LETTER-WORK-CHAR.                   
           MOVE VDATE-EXT-DAY         TO WS-LETTER-WORK-DAY.                    
           MOVE ',!'                  TO WS-LETTER-WORK-COMMA.                  
           MOVE VDATE-EXT-YEAR        TO WS-LETTER-WORK-YEAR.                   
                                                                                
      *    CONVERT DUE DATE FROM ALIS TO DDMMYY FORMAT.                         
           MOVE GOVERAGE-L-EXPIRY-DATE TO VDATE-ALIS-DATE1.                     
           MOVE '9B  '                TO VDATE-REQUEST-AREA.                    
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
                                                                                
           IF  GOVERAGE-LANGUAGE = 'E'                                          
               MOVE WS-MONTH-NAME-EN (VDATE-MM)                                 
                                      TO WS-LETTER-WORK-MONTH                   
           ELSE                                                                 
               MOVE WS-MONTH-NAME-FR (VDATE-MM)                                 
                                      TO WS-LETTER-WORK-MONTH.                  
                                                                                
           MOVE WS-LETTER-WORK-DATE   TO WS-WORK-TEXT.                          
           PERFORM 7000-TURF-ALL-BLANKS THRU                                    
                   7000-TURF-ALL-BLANKS-EXIT.                                   
           MOVE WS-ARRAY2             TO WS-LETTER-EXPIRY-DATE.                 
                                                                                
           MOVE 'RNDATE '            TO WS-LETTER-VAR-NAME.                     
           IF  GOVERAGE-LANGUAGE = 'E'                                          
               MOVE WS-LETTER-RUN-DATE-EN                                       
                                     TO WS-LETTER-VAR-TEXT                      
           ELSE                                                                 
               MOVE WS-LETTER-RUN-DATE-FR                                       
                                     TO WS-LETTER-VAR-TEXT.                     
           MOVE WS-LETTER-VAR-LINE   TO LETTER-RECORD.                          
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
                                                                                
           PERFORM 4100-GROUP-ADDR-LINES THRU                                   
                   4100-GROUP-ADDR-LINES-EXIT VARYING                           
                   ADDR-SUB FROM +1 BY +1 UNTIL                                 
                   ADDR-SUB > +6.                                               
                                                                                
           MOVE 'GNUM   '            TO WS-LETTER-VAR-NAME.                     
           MOVE GOVERAGE-GROUP       TO WS-WORK-GROUP.                          
           MOVE GOVERAGE-ACCT        TO WS-WORK-ACCT.                           
           MOVE WS-WORK-GROUP-ACCT   TO WS-LETTER-VAR-TEXT.                     
           MOVE WS-LETTER-VAR-LINE   TO LETTER-RECORD.                          
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
                                                                                
           MOVE 'EMPNAME'            TO WS-LETTER-VAR-NAME.                     
           MOVE GOVERAGE-L-CERT-NAME TO WS-LETTER-VAR-TEXT.                     
           MOVE WS-LETTER-VAR-LINE   TO LETTER-RECORD.                          
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
                                                                                
           MOVE 'EXPDT  '            TO WS-LETTER-VAR-NAME.                     
           MOVE WS-LETTER-EXPIRY-DATE TO WS-LETTER-VAR-TEXT.                    
           MOVE WS-LETTER-VAR-LINE   TO LETTER-RECORD.                          
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
      *                                                                         
           IF  GOVERAGE-LANGUAGE = 'E'                                          
               PERFORM 4200-DUMP-CAN-LETTER-EN THRU                             
                       4200-DUMP-CAN-LETTER-EN-EXIT VARYING                     
                       LETTR-EN-SUB FROM +1 BY +1 UNTIL                         
                       LETTR-EN-SUB > LETTR-EN-SUB-MAX                          
           ELSE                                                                 
               PERFORM 4200-DUMP-CAN-LETTER-FR THRU                             
                       4200-DUMP-CAN-LETTER-FR-EXIT VARYING                     
                       LETTR-FR-SUB FROM +1 BY +1 UNTIL                         
                       LETTR-FR-SUB > LETTR-FR-SUB-MAX.                         
                                                                                
           ADD  +1  TO ACCUM-OVERAGE-LETTER.                                    
      *                                                                         
       4000-OVERAGE-LETTER-EXIT.                                                
           EXIT.                                                                
                                                                                
       4100-GROUP-ADDR-LINES.                                                   
      **************************************************************            
      *    ADDR LINE VARIABLES ARE OUTPUT.                                      
      **************************************************************            
           MOVE 'GADDR()'                  TO WS-LETTER-VAR-NAME.               
           MOVE GOVERAGE-L-NAAD-LINE (ADDR-SUB) TO WS-LETTER-VAR-TEXT.          
           MOVE WS-LETTER-VAR-LINE         TO LETTER-RECORD.                    
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
       4100-GROUP-ADDR-LINES-EXIT.                                              
           EXIT.                                                                
                                                                                
       4200-DUMP-CAN-LETTER-EN.                                                 
      **************************************************************            
      *    LETTER LINES SAVE IN WS TABLE ARE DUMPED.                            
      **************************************************************            
           MOVE WS-LETTER-EN-LINE (LETTR-EN-SUB) TO LETTER-RECORD.              
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
       4200-DUMP-CAN-LETTER-EN-EXIT.                                            
           EXIT.                                                                
                                                                                
       4200-DUMP-CAN-LETTER-FR.                                                 
      **************************************************************            
      *    LETTER LINES SAVE IN WS TABLE ARE DUMPED.                            
      **************************************************************            
           MOVE WS-LETTER-FR-LINE (LETTR-FR-SUB) TO LETTER-RECORD.              
           PERFORM 9000-WRITE-LETTER THRU                                       
                   9000-WRITE-LETTER-EXIT.                                      
       4200-DUMP-CAN-LETTER-FR-EXIT.                                            
           EXIT.                                                                
                                                                                
       7000-TURF-ALL-BLANKS.                                                    
      **************************************************************            
      *    ELIMINATE ANY BLANKS IN TEXT STRING.                                 
      *    NOTE: HAVE PLACED A '!' IN POSITIONS WHERE A BLANK IS                
      *          ACTUALLY WANTED AND SCRIPT WILL INTERPRET THIS.                
      **************************************************************            
           MOVE SPACES                TO WS-ARRAY2.                             
           MOVE +0                    TO SUB-2.                                 
           PERFORM 7010-COPY-ARRAY THRU                                         
                   7010-COPY-ARRAY-EXIT VARYING                                 
                   SUB-1 FROM +1 BY +1 UNTIL                                    
                   SUB-1 > SUB-1-MAX.                                           
       7000-TURF-ALL-BLANKS-EXIT.                                               
           EXIT.                                                                
                                                                                
       7010-COPY-ARRAY.                                                         
      **************************************************************            
      *    BYPASS LEADING BLANKS.                                               
      *    IF IMBEDDED BLANK FOUND, ONLY COPY IF 1ST OF SEVERAL.                
      **************************************************************            
           IF  WS-ARRAY1-CHAR (SUB-1) = SPACES                                  
               GO TO 7010-COPY-ARRAY-EXIT.                                      
      *                                                                         
           ADD  +1                     TO SUB-2.                                
           MOVE WS-ARRAY1-CHAR (SUB-1) TO WS-ARRAY2-CHAR (SUB-2).               
       7010-COPY-ARRAY-EXIT.                                                    
           EXIT.                                                                
                                                                                
       8000-PRINT-REPORT-LINE.                                                  
      ******************************************************************        
      *    CHECK IF NEXT LINE SHOULD BE PRINTED ON A NEW PAGE.                  
      ******************************************************************        
           IF  WS-LINE-CNT + WS-LINE-INCR > WS-LINE-MAX                         
               MOVE REPORT-RECORD         TO REPORT-RECORD-SAVE                 
               PERFORM 8100-PRINT-PAGE-HEADINGS THRU                            
                       8100-PRINT-PAGE-HEADINGS-EXIT                            
               MOVE REPORT-RECORD-SAVE    TO REPORT-RECORD.                     
                                                                                
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
                                                                                
           ADD  WS-LINE-INCR              TO WS-LINE-CNT.                       
       8000-PRINT-REPORT-LINE-EXIT.                                             
           EXIT.                                                                
                                                                                
       8100-PRINT-PAGE-HEADINGS.                                                
      ******************************************************************        
      *    PRINT PAGE HEADINGS.                                                 
      ******************************************************************        
           ADD  +1                    TO ACCUM-OVERAGE-REPORT.                  
      *                                                                         
           ADD  +1                    TO WS-PAGE-CNT.                           
           MOVE WS-PAGE-CNT           TO HDG1-PAGE.                             
           MOVE HDG1-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG2-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG3-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG4-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG5-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE +6                    TO WS-LINE-CNT.                           
       8100-PRINT-PAGE-HEADINGS-EXIT.                                           
           EXIT.                                                                
                                                                                
       9000-READ-EXTRACT.                                                       
           CALL 'DLSREAD'  USING TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 GOVERAGE                                       
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
       9000-READ-EXTRACT-EXIT.                                                  
           EXIT.                                                                
                                                                                
       9000-READ-LETTER-EN.                                                     
           CALL 'DLSREAD'  USING READ-LETT-EN-SYSUNIT                           
                                 READ-LETT-EN-RET-CODE                          
                                 WS-LETTER-EN-RECORD                            
                                 READ-LETT-EN-RECSZ                             
                                 READ-LETT-EN-BLKSZ                             
                                 READ-LETT-EN-RECFM                             
                                 READ-LETT-EN-REC-CNT.                          
       9000-READ-LETTER-EN-EXIT.                                                
           EXIT.                                                                
                                                                                
       9000-READ-LETTER-FR.                                                     
           CALL 'DLSREAD'  USING READ-LETT-FR-SYSUNIT                           
                                 READ-LETT-FR-RET-CODE                          
                                 WS-LETTER-FR-RECORD                            
                                 READ-LETT-FR-RECSZ                             
                                 READ-LETT-FR-BLKSZ                             
                                 READ-LETT-FR-RECFM                             
                                 READ-LETT-FR-REC-CNT.                          
       9000-READ-LETTER-FR-EXIT.                                                
           EXIT.                                                                
                                                                                
       9000-WRITE-REPORT.                                                       
           CALL 'DLSWRITE' USING WRITE-RPT-SYSUNIT                              
                                 WRITE-RPT-RET-CODE                             
                                 REPORT-RECORD                                  
                                 WRITE-RPT-RECSZ                                
                                 WRITE-RPT-BLKSZ                                
                                 WRITE-RPT-RECFM                                
                                 WRITE-RPT-REC-CNT.                             
       9000-WRITE-REPORT-EXIT.                                                  
           EXIT.                                                                
                                                                                
       9000-WRITE-LETTER.                                                       
           CALL 'DLSWRITE' USING WRITE-LETT-SYSUNIT                             
                                 WRITE-LETT-RET-CODE                            
                                 LETTER-RECORD                                  
                                 WRITE-LETT-RECSZ                               
                                 WRITE-LETT-BLKSZ                               
                                 WRITE-LETT-RECFM                               
                                 WRITE-LETT-REC-CNT.                            
       9000-WRITE-LETTER-EXIT.                                                  
           EXIT.                                                                
