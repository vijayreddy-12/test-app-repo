       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2RC1.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *REMARKS.                                                                 
      *    THIS PROGRAM EXTRACTS THE COMMISSION RECONCILIATION WORK             
      *    FILES FROM COMMISSION HISTORY DATABASE AND GIPSY MASTER.             
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * HISTORY:                                                      *         
      * 01AUG86 - F GAGNEF   - CREATED                                *         
      * 12MAR87 - L HAMPTON  - FIXED LOGIC FOR TERMINATION GROUPS TO  *         
      *                        DETERMINE IF THE GROUP IS PAID-UP.     *         
      * 20JUL87 - S WAGLER   - PUT IN CONTROL DATE AND RUN DATE LOGIC *         
      *           L HAMPTON    AND ADDED CONTROL INDICATORS TO        *         
      *                        GWCORCNTL.                             *         
      * 23NOV88 - D HAMILTON - CHANGE GBIDUE-DATE TO END OF MONTH     *         
      *                        WHEN TESTING ON TERMINATED SELF        *         
      *                        ADMIN GROUPS.                          *         
      *                                                               *         
      * 12JAN89 - M BURTON   - CHANGE THE SORT OF THE RECONCILIATION  *         
      *                        STATEMENTS TO BROKER/AGENT             *         
      *                         - BRANCH/BROKER/GROUP/EFF-DATE        *         
      *                         - GFO/AGENT/GROUP/EFF-DATE            *         
      *                                                               *         
      * 05FEB89 - M BURTON   - CHANGE THE OUTSTANDING REPORT TO       *         
      *                        EXCLUDE TERMINATED GROUPS IF MONEY     *         
      *                        OUTSTANDING IN NOT = 0                 *         
      *                         - ADD GFO, LAST RECON DATE, STATUS    *         
      *                           TO THE REPORT (SORT IT BY GFO)      *         
      *                         - THIS REPORT IS NO LONGER PRINTED    *         
      *                           FROM THIS PROGRAM  (SYS024)         *         
      *                                                               *         
      * 16AUG89 - A SCHLEICHER - IF BROKER SOLD AN ALPHA CASE USE THE *         
      *                          BRANCH INSTEAD OF THE GFO FIELD      *         
      *                          (EXT-COMM-REC-TYPE)                  *         
      *                                                               *         
      * 22JUN90 - M BURTON    - ADD A PARM FOR THE ZCURRDATE TO       *         
      *                         FACILITATE TESTING FOR THE COMMISSION *         
      *                         RELEASE                               *         
      *                                                               *         
      * 20SEP90 - M PRANGE    - BYPASS PURGED GIPSY MASTERS.          *         
      *                       - UPDATE NEXT RECON DATE WITH PSM-NEXT  *         
      *                         RENEW DATE FOR ACTIVE GROUPS.         *         
      *                       - IF NO COMM EXTRACTS PRODUCED, DO NOT  *         
      *                         PRODUCE A DATE EXTRACT. AN ERROR      *         
      *                         MESSAGE IS OUTPUT.                    *         
      *                                                               *         
      * 21SEP90 - A NIKELSKI  - CREATED AN EXTRACT IF A TERMINATED    *         
      *                         GROUP RECONCILED (SYS026)             *         
      *                       - EXTRACT USED BY EASYTREV PROGRAM      *         
      *                         GC121020                              *         
      *                                                               *         
      * 15OCT90 - I BUCKNELL  - ENHANCE CALCULATION OF SELF-ADMIN     *         
      *                         PAID-TO DATE; LOGIC FOR TERMINATED    *         
      *                         GROUPS NOW APPLIES TO INFORCE SA ALSO *         
      *                                                               *         
      *   JUN98 - J ELKINS    - ADD NEW FIELDS TO THE EXTRACT TERM    *         
      *                         FILE (DLSO26).  NEW FIELDS ARE        *         
      *                         PRODUCT-CODE, GFO, REP AND            *         
      *                         CONTRACT-ISSUE DATE.  ONLY WRITE      *         
      *                         RECORD IS CLAIMS SUSPENDED DATE IS    *         
      *                         WITHIN 12 MONTHS OF THE CONTRACT      *         
      *                         ISSUE DATE                            *         
      *                                                               *         
      *   DEC99 - R COLE      - T9898 - FIX Y2K BUG USING 2 DIGIT     *         
      *                         YEARS IN CALCULATIONS                 *         
      *   OCT00 - R COLE      - T12114 - ADD BRANCH NUMBER TO         *         
      *                         COMMISSIONS EXTRACT COPY BOOK         *         
      *                         AND POPULATE GGIBRANCH                *         
      *                                                               *         
      *    JUL/2005  R. KNAUD.                                        *         
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)        *         
      *                  CHANGE THE GMASTER IDMS READ TO:             *         
      *                      USE VOGPWRA7 TO READ THE VCM AND         *         
      *                      GIPSY MASTER FILES.                      *         
      *         - HUB:  COMM PSMASTER ROUTER (VOCOMM VOPSM/PSM)       *         
      *                  CHANGE THE PSMASTER IDMS READ TO:            *         
      *                  READ THE VO PSMASTER FIRST (USING GAEDATSR)  *         
      *                  AND IF THE REQUIRED RECORD IS NOT THERE,     *         
      *                  READ THE PSMASTER (USING GACCDMA7).          *         
      *                                                               *         
      *    FEB/2006  R. KNAUD.                                        *         
      *         - HUB:  PROCESS VO GROUPS DIFFERENTLY FROM THE        *         
      *                  NON-VO GROUPS.  USE VGWO-SOURCE-SYSTEM       *         
      *                  = 'V' TO DETERMINE VO CONTRACTS.             *         
      *                                                               *         
      *                                                                         
      *    OCT/08 IBM                                                           
      *         - ENTERPRISE COMPILER UPGRADE                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCRC1          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO02 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2RC1 W-S STARTS HERE **'.                                  
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
           03  FILLER                     PIC X(30).                            
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  VOGPWRA7                   PIC X(8) VALUE 'VOGPWRA7'.            
           05  GAEDATSR                   PIC X(8) VALUE 'GAEDATSR'.            
           05  GC2DATE                    PIC X(8) VALUE 'GC2DATE'.             
           05  ZCURRDAT                   PIC X(8) VALUE 'ZCURRDAT'.            
                                                                                
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------                           
      *  VO PS MASTER                                                           
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
             ' **** VO PS MASTER  ****    '.                                    
           COPY VOPSMAST.                                                       
      *----------------------------------------------                           
      *   PSMASTER                                                              
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
FXXTOK       ' **** PSMASTE7  ****    '.                                        
      * PSMASTE7                                                                
CPYNME     COPY PSMASTE7.                                                       
                                                                                
       01  WS-PARAMETERS.                                                       
                                                                                
           05  FILLER                     PIC X(32)       VALUE                 
                                                      'WS-PARAMETERS'.          
           05  GTM-SUB            COMP-3  VALUE +0        PIC S9.               
           05  GTM-SWITCH                 VALUE SPACE     PIC X.                
               88  GTM-DATA-FOUND         VALUE 'Y'.                            
           05  ACCT-SWITCH                VALUE SPACE     PIC X.                
               88  ACCOUNT-ACTIVE         VALUE 'A'.                            
               88  ACCOUNT-TERMINATED     VALUE 'T'.                            
           05  ERROR-SWITCH               VALUE '0'       PIC X.                
               88  COMP-IS-VALID          VALUE '0'.                            
           05  WS-BROKER-AGENT-NUMBER.                                          
               07  WS-BA-PART1.                                                 
                   10  WS-BA-FIRST        VALUE 0         PIC 9.                
                   10  WS-BA-SECOND       VALUE 0         PIC 9.                
               07  WS-BA-PART2            VALUE 0         PIC 9(4).             
           05  WS-EXT-MONTHS      COMP-3  VALUE +0        PIC S999.             
           05  WS-COMP-PROC-CNT   COMP-3  VALUE +0        PIC S9(5).            
           05  QDATE-FORMATA              VALUE 'AB'      PIC XX.               
           05  QDATE-FORMATB              VALUE 'BA'      PIC XX.               
           05  QDATE-FORMATC              VALUE 'AC'      PIC XX.               
           05  QDATE-FORMATD              VALUE 'CA'      PIC XX.               
           05  GPSY-RETURN-CODE           VALUE SPACES    PIC XXX.              
           05  ERROR-COUNT        COMP-3  VALUE ZERO      PIC S999.             
           05  WS-CONT-PROC-FLAG          VALUE 'Y'       PIC X.                
           05  WS-RECON-TERM-DATE.                                              
               10  WS-RECON-TERM-YEAR             COMP-3  PIC S9(3).            
               10  WS-RECON-TERM-DAY              COMP-3  PIC S9(3).            
      * VOCOMM VOPSM/PSM                                                        
           05  WS-PREV-GROUP         VALUE -1     COMP-3  PIC S9(7).            
           05  WS-CURR-GROUP         VALUE -1     COMP-3  PIC S9(7).            
           05  WS-VO-DUE-DATE.                                                  
               10  WS-VO-DUE-DD                       PIC 99.                   
               10  WS-VO-DUE-YYMM.                                              
                   15  WS-VO-DUE-YY                   PIC 99.                   
                   15  WS-VO-DUE-MM                   PIC 99.                   
           05  WS-VO-RECON-DATE.                                                
               10  WS-VO-RECON-DD                     PIC 99.                   
               10  WS-VO-RECON-YYMM.                                            
                   15  WS-VO-RECON-YY                 PIC 99.                   
                   15  WS-VO-RECON-MM                 PIC 99.                   
           05  WS-PSM-RENEW-DATE.                                               
               10  WS-PSM-RENEW-YEAR              COMP-3  PIC S9(3).            
               10  WS-PSM-RENEW-DAY               COMP-3  PIC S9(3).            
           05  WS-TODAY-DATE.                                                   
               10  WS-TODAY-DAY                           PIC 99.               
               10  FILLER                                 PIC X.                
               10  WS-TODAY-MONTH                         PIC 99.               
               10  FILLER                                 PIC X.                
               10  WS-TODAY-YEAR                          PIC 99.               
           05  WS-ALIS-RUN-DATE.                                                
               10  WS-ALIS-RUN-YEAR               COMP-3  PIC S999.             
               10  WS-ALIS-RUN-DAY                COMP-3  PIC S999.             
           05  WS-CURR-DATE.                                                    
               10  WS-CURR-DAY                            PIC 99.               
               10  WS-CURR-MONTH                          PIC 99.               
               10  WS-CURR-YEAR                           PIC 99.               
           05  WS-ALIS-CHECK-DATE.                                              
               10  WS-ALIS-CHECK-YR               COMP-3  PIC S999.             
               10  WS-ALIS-CHECK-DAY              COMP-3  PIC S999.             
           05  ALIS-CURR-DATE.                                                  
               10  ALIS-CURR-YEAR                 COMP-3  PIC S999.             
               10  ALIS-CURR-DAY                  COMP-3  PIC S999.             
           05  WS-TERM-EFF-DATE.                                                
               10  WS-TERM-EFF-YEAR               COMP-3  PIC S9(3).            
               10  WS-TERM-EFF-DAY                COMP-3  PIC S9(3).            
           05  WS-TERM-PRO-DATE.                                                
               10  WS-TERM-PRO-YEAR               COMP-3  PIC S9(3).            
               10  WS-TERM-PRO-DAY                COMP-3  PIC S9(3).            
           05  WS-LOW-DATE.                                                     
               10  FILLER        VALUE +000       COMP-3  PIC S9(3).            
               10  FILLER        VALUE +000       COMP-3  PIC S9(3).            
           05  WS-NUM-AMEND-END-DATE.                                           
               10  WS-NUM-AMEND-END-DAY                   PIC 99.               
               10  WS-NUM-AMEND-END-MONTH                 PIC 99.               
               10  WS-NUM-AMEND-END-YEAR                  PIC 99.               
           05  WS-NUM-TERM-DATE.                                                
               10  WS-NUM-TERM-DAY                        PIC 99.               
               10  WS-NUM-TERM-MONTH                      PIC 99.               
               10  WS-NUM-TERM-YEAR                       PIC 99.               
           05  WS-AMEND-END-DATE.                                               
               10  WS-AMEND-END-YEAR      COMP-3          PIC S999.             
               10  WS-AMEND-END-DAY       COMP-3          PIC S999.             
           05  WS-DATE-DUE.                                                     
               10  WS-DAY-DUE                            PIC 99.                
               10  WS-MONTH-DUE                          PIC 99.                
               10  WS-YEAR-DUE                           PIC 99.                
           05  WS-DUE-DATE.                                                     
               10  WS-DUE-YEAR        COMP-3          PIC S999.                 
               10  WS-DUE-DAY         COMP-3          PIC S999.                 
           05  MONTH-SUB              COMP SYNC       PIC S9(4).                
           05  WS-DATE.                                                         
             07  WS-DATE-VALUES.                                                
               10  FILLER       PIC 99            VALUE 31.                     
               10  FILLER       PIC 99            VALUE 28.                     
               10  FILLER       PIC 99            VALUE 31.                     
               10  FILLER       PIC 99            VALUE 30.                     
               10  FILLER       PIC 99            VALUE 31.                     
               10  FILLER       PIC 99            VALUE 30.                     
               10  FILLER       PIC 99            VALUE 31.                     
               10  FILLER       PIC 99            VALUE 31.                     
               10  FILLER       PIC 99            VALUE 30.                     
               10  FILLER       PIC 99            VALUE 31.                     
               10  FILLER       PIC 99            VALUE 30.                     
               10  FILLER       PIC 99            VALUE 31.                     
             07  WS-DATE-TABLE REDEFINES WS-DATE-VALUES.                        
               10  WS-DATE-TABLE-ENTRY OCCURS 12 TIMES.                         
                 13  WS-TABLE-DAY                 PIC 99.                       
      *                                                                         
           05  WS-MONTHS        PIC S99           VALUE +0.                     
      *                                                                         
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------------                     
      *          DATASERVER RECORDS                                             
      *----------------------------------------------------                     
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
       01  LOGICAL-RECORD-NAMES.                                                
           COPY HCSLRNAM.                                                       
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------------                     
      *          GIPSY ACCESS MODULE PARMS                                      
      *----------------------------------------------------                     
       01  GACCDMA7-PS-PARMS.                                                   
           05  GACCDMA7-PS-FUNC      PIC S9(4)    COMP   VALUE +18.             
REN        05  GACCDMA7-PS-GROUP     PIC S9(7)    COMP-3.                       
           05  GACCDMA7-PS-ACCT      PIC X(3).                                  
           05  GACCDMA7-PS-CERT      PIC S9(9)    COMP-3.                       
           05  GACCDMA7-PS-WORK      PIC X(9).                                  
       01  GACCDMA7-PS-RETURN        PIC X(3).                                  
           88  GACCDMA7-PS-RET-OK                 VALUE '   '.                  
           88  GACCDMA7-PS-EOF                    VALUE 'R01'.                  
           88  GACCDMA7-PS-NOT-FOUND              VALUE 'R01'.                  
           88  GACCDMA7-PS-DISK-ERROR             VALUE 'R03'.                  
           88  GACCDMA7-PS-FUNC-INVALID           VALUE 'R09'.                  
                                                                                
       01  GAC-DATE-PARAMETERS.                                                 
               COPY GARDATEP.                                                   
      *                                                                         
       01  DLS-PARMS.                                                           
           05  DLSR-SYSNUM      PIC X(6)          VALUE 'SYS019'.               
           05  DLSR-RETURN      PIC S9    COMP-3  VALUE ZERO.                   
           05  DLSR-REC-SIZE    PIC 9(5)          VALUE 80.                     
           05  DLSR-BLK-SIZE    PIC 9(5)          VALUE 80.                     
           05  DLSR-FORMAT      PIC XX            VALUE 'FB'.                   
           05  DLSR-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.                   
                                                                                
           05  DLSC-SYSNUM      PIC X(6)          VALUE 'SYS021'.               
           05  DLSC-RETURN      PIC S9    COMP-3  VALUE ZERO.                   
           05  DLSC-REC-SIZE    PIC 9(5)          VALUE 55.                     
           05  DLSC-BLK-SIZE    PIC 9(5)          VALUE 5500.                   
           05  DLSC-FORMAT      PIC XX            VALUE 'FB'.                   
           05  DLSC-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.                   
                                                                                
           05  DLSN-SYSNUM      PIC X(6)          VALUE 'SYS022'.               
           05  DLSN-RETURN      PIC S9    COMP-3  VALUE ZERO.                   
           05  DLSN-REC-SIZE    PIC 9(5)          VALUE 50.                     
           05  DLSN-BLK-SIZE    PIC 9(5)          VALUE 5000.                   
           05  DLSN-FORMAT      PIC XX            VALUE 'FB'.                   
           05  DLSN-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.                   
                                                                                
           05  DLSD-SYSNUM      PIC X(6)          VALUE 'SYS023'.               
           05  DLSD-RETURN      PIC S9    COMP-3  VALUE ZERO.                   
           05  DLSD-REC-SIZE    PIC 9(5)          VALUE 36.                     
           05  DLSD-BLK-SIZE    PIC 9(5)          VALUE 3600.                   
           05  DLSD-FORMAT      PIC XX            VALUE 'FB'.                   
           05  DLSD-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.                   
                                                                                
           05  DLSO-SYSNUM      PIC X(6)          VALUE 'SYS024'.               
           05  DLSO-RETURN      PIC S9    COMP-3  VALUE ZERO.                   
           05  OUTSTD-LINE      PIC X(40)         VALUE SPACES.                 
           05  DLSO-REC-SIZE    PIC 9(5)          VALUE 40.                     
           05  DLSO-BLK-SIZE    PIC 9(5)          VALUE 23440.                  
           05  DLSO-FORMAT      PIC XX            VALUE 'FB'.                   
           05  DLSO-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.                   
                                                                                
           05  DLSE-SYSNUM      PIC X(6)          VALUE 'SYS025'.               
           05  DLSE-RETURN      PIC S9    COMP-3  VALUE ZERO.                   
           05  ERROR-LINE       PIC X(133)        VALUE SPACES.                 
           05  DLSE-REC-SIZE    PIC 9(5)          VALUE 133.                    
           05  DLSE-BLK-SIZE    PIC 9(5)          VALUE 3990.                   
           05  DLSE-FORMAT      PIC XX            VALUE 'FB'.                   
           05  DLSE-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.                   
                                                                                
           05  DLS026-SYSNUM    PIC X(6)          VALUE 'SYS026'.               
           05  DLS026-RETURN    PIC S9    COMP-3  VALUE ZERO.                   
           05  DLS026-REC-SIZE  PIC 9(5)          VALUE 33.                     
           05  DLS026-BLK-SIZE  PIC 9(5)          VALUE 23463.                  
           05  DLS026-FORMAT    PIC XX            VALUE 'FB'.                   
           05  DLS026-REC-COUNT PIC S9(7) COMP-3  VALUE ZERO.                   
                                                                                
       01  EXTRACT-TERM-FILE.                                                   
           05  EXTRACT-TERM-PRODUCT-CODE  PIC X   VALUE SPACES.                 
           05  EXTRACT-TERM-GFO        PIC X(5)   VALUE SPACES.                 
           05  EXTRACT-TERM-REP        PIC 9(5)   VALUE 0.                      
REN        05  EXTRACT-TERM-GROUP      PIC 9(7)   VALUE 0.                      
           05  EXTRACT-TERM-ACCOUNT    PIC X(3)   VALUE SPACES.                 
           05  EXTRACT-TERM-RECON      PIC X(7)   VALUE SPACES.                 
           05  EXTRACT-TERM-CONTRACT-ISSUE PIC X(7) VALUE SPACES.               
      /                                                                         
      ***************************************************************           
      *   MESSAGES USED FOR THE ERROR LOGIC USING THE CALL TO WTL   *           
      ***************************************************************           
       01  WTL-AREA.                                                            
           05  WTL-FLAG                PIC X      VALUE 'B'.                    
           05  WTL-REPLY-YES           PIC XXX    VALUE 'YES'.                  
           05  WTL-REPLY-NO            PIC XXX    VALUE 'NO '.                  
           05  WTL-REPLY               PIC XXX    VALUE SPACES.                 
           05  WTL-REPLY-AREA          PIC X(10)  VALUE SPACES.                 
       01  WTL-MESSAGE-AREA.                                                    
           05  FILLER          COMP-3  PIC S9(3)  VALUE +121.                   
           05  FILLER                  PIC X      VALUE SPACES.                 
           05  WTL-MESSAGE             PIC X(120) VALUE SPACES.                 
      /                                                                         
       COPY GWCORC71.                                                           
      /                                                                         
       COPY GWCORC72.                                                           
      /                                                                         
       COPY GWCORC73.                                                           
      /                                                                         
       COPY GWCORRCD.                                                           
                                                                                
       COPY GWCORRRD.                                                           
                                                                                
      /                                                                         
       01  OUTSTANDING-REPORT.                                                  
                                                                                
           05  OUTSTD-DETAILS.                                                  
               10  OUTSTD-GFO             PIC 9(5).                             
REN            10  OUTSTD-GROUP           PIC 9(7).                             
               10  OUTSTD-ACCOUNT         PIC XXX.                              
               10  OUTSTD-LAST-RECON-DATE PIC X(7).                             
               10  OUTSTD-NEXT-RECON-DATE PIC X(7).                             
               10  OUTSTD-PAID-DATE       PIC X(7).                             
               10  OUTSTD-STATUS          PIC 99.                               
               10  FILLER                 PIC X(4)    VALUE SPACES.             
                                                                                
           05  END-LINE.                                                        
               10  END-CC                 PIC X       VALUE '-'.                
               10  FILLER                 PIC X(132)  VALUE                     
                                        '*** END OF REPORT ***'.                
      /                                                                         
       01  WTL-ERROR-MESSAGES.                                                  
           05  ERR-MESS1.                                                       
               10  FILLER                 PIC X(40) VALUE                       
                   '***  INVALID RUNDATE FORMAT         '.                      
           05  ERR-MESS2.                                                       
               10  FILLER                 PIC X(50)   VALUE                     
                   '***  INVALID RUNDATE - SEE RUN DOCUMENTATION'.              
           05  ERR-MESS3.                                                       
               10  FILLER                 PIC X(40)   VALUE                     
                   '***  SEVERE ERROR - CONTACT PROGRAMMER'.                    
       01  ERROR-REPORT.                                                        
           05  ERR-HDG-1.                                                       
               10  ERR-CC-1               PIC X       VALUE '1'.                
FXXTOK         10  FILLER                 PIC X(45)   VALUE 'GC2RC1'.           
               10  FILLER                 PIC X(45)   VALUE                     
                               'RECONCILIATION EXTRACT - ERROR REPORT'.         
               10  FILLER                 PIC X(5)    VALUE 'DATE'.             
               10  ERROR-DATE             PIC X(7)    VALUE SPACES.             
               10  FILLER                 PIC X(5)    VALUE SPACES.             
               10  FILLER                 PIC X(10)   VALUE SPACES.             
               10  FILLER                 PIC X(15)   VALUE SPACES.             
                                                                                
           05  ERR-HDG-2.                                                       
               10  ERR-CC-2               PIC X       VALUE '-'.                
               10  FILLER                 PIC X(12)   VALUE 'GROUP'.            
               10  FILLER                 PIC X(13)   VALUE 'ACCOUNT'.          
               10  FILLER                 PIC X(15)   VALUE 'EFFECTIVE'.        
               10  FILLER                 PIC X(11)   VALUE 'COMP'.             
               10  FILLER                 PIC X(10)   VALUE 'COMP'.             
               10  FILLER                 PIC X(10)   VALUE 'COMP'.             
               10  FILLER                 PIC X(09)   VALUE 'COV'.              
               10  FILLER                 PIC X(20)   VALUE                     
                                                'ERROR DESCRIPTION'.            
           05  ERR-HDG-3.                                                       
               10  ERR-CC-3               PIC X       VALUE ' '.                
               10  FILLER                 PIC X(27)   VALUE SPACES.             
               10  FILLER                 PIC X(13)   VALUE 'DATE'.             
               10  FILLER                 PIC X(11)   VALUE 'TYPE'.             
               10  FILLER                 PIC X(9)    VALUE 'DISP'.             
               10  FILLER                 PIC X(11)   VALUE 'REASON'.           
               10  FILLER                 PIC X(4)    VALUE 'TYPE'.             
                                                                                
           05  ERROR-DETAILS.                                                   
               10  EWRR-CC-4              PIC X       VALUE '0'.                
               10  ERROR-DETAIL-DATA.                                           
REN                15  ERROR-GROUP        PIC 9(7)    VALUE ZERO.               
REN                15  FILLER             PIC X(7)    VALUE SPACES.             
                   15  ERROR-ACCOUNT      PIC XXX     VALUE SPACES.             
                   15  FILLER             PIC X(9)    VALUE SPACES.             
                   15  ERROR-EFF-DATE     PIC X(7)    VALUE SPACES.             
                   15  FILLER             PIC X(9)    VALUE SPACES.             
                   15  ERROR-COMP-TYPE    PIC X       VALUE SPACE.              
                   15  FILLER             PIC X(9)    VALUE SPACES.             
                   15  ERROR-COMP-DISP    PIC X       VALUE SPACE.              
                   15  FILLER             PIC X(9)    VALUE SPACES.             
                   15  ERROR-COMP-REASON  PIC X       VALUE SPACE.              
                   15  FILLER             PIC X(9)    VALUE SPACES.             
                   15  ERROR-COV-TYPE     PIC X       VALUE SPACE.              
                   15  FILLER             PIC X(9)    VALUE SPACES.             
                   15  ERROR-NOTE         PIC X(50)   VALUE SPACES.             
                                                                                
           05  ERROR-TOTAL.                                                     
               10  ERR-CC-5               PIC X       VALUE '-'.                
               10  FILLER                 PIC X(5)    VALUE SPACES.             
               10  RPT-ERROR-COUNT        PIC ZZZZ9   VALUE ZERO.               
               10  FILLER                 PIC X(122)  VALUE                     
                       ' ERRORS WERE DETECTED DURING PROCESSING'.               
      /                                                                         
           05  ERROR-NOTES.                                                     
               10  ERROR-NOTE-1           PIC X(50)   VALUE                     
                   'NO GIPSY MASTER - PLEASE RECONCILE MANUALLY'.               
               10  ERROR-NOTE-2           PIC X(50)   VALUE                     
                   'INVALID COMP-TYPE - RECORD NOT RECONCILED'.                 
               10  ERROR-NOTE-3           PIC X(50)   VALUE                     
                   'INVALID DISPOSITION - RECORD NOT RECONCILED'.               
               10  ERROR-NOTE-4           PIC X(50)   VALUE                     
                   'INVALID REASON - RECORD NOT RECONCILED'.                    
               10  ERROR-NOTE-5           PIC X(50)   VALUE                     
                   'INVALID COVERAGE - RECORD NOT RECONCILED'.                  
               10  ERROR-NOTE-6           PIC X(50)   VALUE                     
                   'NO COMP RECS PROCESSED - ACCT DID NOT RECONCILE'.           
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - CONTROL RECORD DESCRIPTION                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCNTL                                                               
CPYNME     COPY GCICNTL.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - COMPENSATION RECORD DESCRIPTION           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          GIPSY - RECORDS                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
FXXTOK                                '** GC2RC1 W-S ENDS HERE **'.             
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO02'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  PARM.                                                                
           05  PARMLENGTH              PIC S9(4) COMP.                          
           05  PARMDATE.                                                        
               10  PARM-DD             PIC 99.                                  
               10  FILLER              PIC X.                                   
               10  PARM-MM             PIC 99.                                  
               10  FILLER              PIC X.                                   
               10  PARM-YY             PIC 99.                                  
                                                                                
       PROCEDURE DIVISION USING PARM.                                           
FXXTOK     MOVE 'GC2RC1'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       MAINLINE.                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                PROGRAM MAINLINE                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 000-INITIALIZE.                                              
           IF WS-CONT-PROC-FLAG = 'Y'                                           
               PERFORM 100-PROCESS-RECORDS THRU 100-EXIT                        
                  UNTIL DB-END-OF-SET.                                          
           PERFORM 500-END-OF-JOB.                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'CLOSE FILES'      TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 150-READ-VCM-GIPSY THRU 150-READ-VCM-GIPSY-EXIT.             
                                                                                
              MOVE +1                TO GACCDMA7-PS-FUNC.                       
              CALL 'GACCDMA7'     USING GACCDMA7-PS-PARMS                       
                                        GACCDMA7-PS-RETURN                      
                                        PSMASTE7.                               
                                                                                
      * VOCOMM VOPSM/PSM                                                        
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  LOGICAL-RECORD-NAME                           
                                  ICBM.                                         
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       000-INITIALIZE.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREA TO BE ACCESSED                              *         
      *     GET RUN-DATE AND EDIT FOR VALID DATE                      *         
      *     GET CURRENT DATE                                          *         
      *     GET CONTROL RECORD AND EDIT RUN DATE TO LAST RECONCILATION*         
      *         RUN DATE AND EDIT RUN DATE TO CURRENT DATE.           *         
      *     EDIT CONTROL INDICATORS ON THE CONTROL RECORD.            *         
      *     MODIFY CONTROL RECORD TO INDICATE THE START OF THE        *         
      *         RECONCILIATION PROCESS.                               *         
      *     WRITE THE RUN DATE TO EACH OF THE OUTPUT FILES.           *         
      *     WRITE HEADINGS ON OUTSTANDING REPORT                      *         
      *                       ERROR REPORT.                           *         
      *     GET FIRST GRACCT RECORD FROM DATA BASE                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * VOCOMM VOPSM/PSM                                                        
FXXTOK     MOVE 'GC2RC1'   TO ICBM-PROGRAM-NAME.                                
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
                                                                                
FXXTOK     MOVE 'GC2RC1' TO PROGRAM-NAME.                                       
      *%   BIND RUN-UNIT.                                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND GWCORCNTL.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGRACCT.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORCOMP.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'OPEN FILES'       TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 150-READ-VCM-GIPSY THRU 150-READ-VCM-GIPSY-EXIT.             
                                                                                
           PERFORM 550-READ-RUNDATE THRU 550-EXIT.                              
MAN02      CALL QDATEQ2 USING QDATE-FORMATD                                     
MAN02                         PROGRAM-RUN-DATE                                  
MAN02                         WS-ALIS-RUN-DATE.                                 
           IF WS-ALIS-RUN-DATE = '****'                                         
               MOVE SPACES    TO WTL-MESSAGE                                    
               MOVE ERR-MESS1 TO WTL-MESSAGE                                    
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           IF PARMLENGTH = 8                                                    
              MOVE PARMDATE TO WS-TODAY-DATE                                    
              DISPLAY PARMDATE ' PARMDATE '                                     
           ELSE                                                                 
              CALL  ZCURRDAT  USING WS-TODAY-DATE.                              
           MOVE WS-TODAY-MONTH TO WS-CURR-MONTH.                                
           MOVE WS-TODAY-DAY   TO WS-CURR-DAY.                                  
           MOVE WS-TODAY-YEAR  TO WS-CURR-YEAR.                                 
MAN02      CALL QDATEQ2 USING QDATE-FORMATB                                     
MAN02                         WS-CURR-DATE                                      
MAN02                         ALIS-CURR-DATE.                                   
                                                                                
      *%   OBTAIN FIRST GWCORCNTL WITHIN GW-COMP-AREA1.                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           IF (WS-ALIS-RUN-DATE GREATER THAN ALIS-CURR-DATE) OR                 
            (WS-ALIS-RUN-DATE NOT GREATER THAN LAST-RECON-RUN-DATE)             
               MOVE 'N' TO WS-CONT-PROC-FLAG                                    
               MOVE SPACES    TO WTL-MESSAGE                                    
               MOVE ERR-MESS2 TO WTL-MESSAGE                                    
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
           IF COMM-SCR-RECON-IND    = 'Y' AND                                   
              NAP-RECON-IND         = 'Y' AND                                   
              RECON-DATE-UPDATE-IND = 'Y'                                       
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'N' TO WS-CONT-PROC-FLAG                                    
               MOVE SPACES    TO WTL-MESSAGE                                    
               MOVE ERR-MESS3 TO WTL-MESSAGE                                    
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
           MOVE 'N' TO COMM-SCR-RECON-IND.                                      
           MOVE 'N' TO NAP-RECON-IND.                                           
           MOVE 'N' TO RECON-DATE-UPDATE-IND.                                   
      *%   MODIFY GWCORCNTL.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           MOVE 'Y' TO WS-CONT-PROC-FLAG.                                       
           MOVE LOW-VALUES           TO FILE-CONTROL-DATE-RECORD.               
           MOVE WS-ALIS-RUN-DATE     TO FILE-CONTROL-DATE.                      
           MOVE FILE-CONTROL-DATE-RECORD TO EXT-RECON-COMM-RECORD.              
           PERFORM 600-WRITE-COMM-REC.                                          
           MOVE FILE-CONTROL-DATE-RECORD TO EXT-RECON-NAP-RECORD.               
           PERFORM 610-WRITE-NAP-REC.                                           
           MOVE FILE-CONTROL-DATE-RECORD TO EXT-RECON-DATE-RECORD.              
           PERFORM 620-WRITE-DATE-REC.                                          
                                                                                
           MOVE PROGRAM-RUN-DATE TO ERROR-DATE.                                 
           MOVE ERR-HDG-1 TO ERROR-LINE.                                        
           PERFORM 810-PRINT-ERROR-LINE.                                        
           MOVE ERR-HDG-2 TO ERROR-LINE.                                        
           PERFORM 810-PRINT-ERROR-LINE.                                        
           MOVE ERR-HDG-3 TO ERROR-LINE.                                        
           PERFORM 810-PRINT-ERROR-LINE.                                        
                                                                                
      *%   OBTAIN FIRST GWCORGRACCT WITHIN GW-COMP-AREA1                        
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               DISPLAY 'NO GRACCT FOUND ON DB'.                                 
                                                                                
       099-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       100-PROCESS-RECORDS.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  IF  NEXT RECON DATE LESS THAN CURRENT DATE             *         
      *            NEXT SENTENCE                                      *         
      *        ELSE                                                   *         
      *            GET NEXT ACCOUNT.                                  *         
      *     -  GET GPSY MASTER RECORD MATCHING ACCOUNT.               *         
      *     -  IF  NOT FOUND                                          *         
      *     -      ERROR REPORT                                       *         
      *     -      GET NEXT ACCOUNT.                                  *         
      *     -  EXPAND GPSY MASTER RECORD.                             *         
      *     -  IF  PAY-TO-DATE DATE GREATER THAN NEXT RECON DATE      *         
      *            INVOKE COMP RECORDS                                *         
      *        ELSE                                                   *         
      *            INVOKE OUTSTANDING REPORT.                         *         
      *     -  GET NEXT ACCOUNT RECORD.                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  NEXT-RECON-DATE IS LESS THAN WS-ALIS-RUN-DATE                    
           AND NEXT-RECON-DATE IS GREATER THAN LAST-RECON-DATE                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 100-GET-NEXT-ACCOUNT.                                      
                                                                                
       100-GET-VOPSM-PSM-MASTER.                                                
      *****************************************************************         
      *  SEP/90 M. PRANGE.                                                      
      *       - NEED THE PSM MASTER FOR THIS GROUP IF NOT ALREADY               
      *         IN WORKING STORAGE. SAVE ITS RENEW-DATE.                        
      *****************************************************************         
           MOVE GROUP-NUMBER OF GWCORGRACCT TO EXT-COMM-GROUP-NUMBER.           
           MOVE EXT-COMM-GROUP-NUMBER-N     TO WS-CURR-GROUP.                   
                                                                                
           IF  WS-CURR-GROUP   = WS-PREV-GROUP                                  
               GO TO 100-GET-VCM-GPSY-MASTER.                                   
                                                                                
      * VOCOMM VOPSM/PSM                                                        
           MOVE LOW-VALUES       TO VOPSMASTER-RECORD.                          
           MOVE WS-CURR-GROUP    TO VOPSM-GROUP-NUMBER.                         
           MOVE LR-VO-PSMASTER-R TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING OBTAIN-KEYED                                
                                    VOPSMASTER-RECORD                           
                                    ICBM.                                       
           IF LR-STATUS-OK                                                      
              MOVE 'B' TO VDATE-REQ-SERVICE                                     
              MOVE 'B' TO VDATE-REQ-BASIS                                       
              MOVE '1' TO VDATE-REQ-DETAIL                                      
              MOVE 'E' TO VDATE-REQ-LANGUAGE                                    
              MOVE VOPSM-NXT-RNEW-YEAR  TO VDATE1-YYYY                          
              MOVE VOPSM-NXT-RNEW-MONTH TO VDATE1-MM                            
              MOVE VOPSM-NXT-RNEW-DAY   TO VDATE1-DD                            
              CALL GC2DATE USING GAC-DATE-PARAMETERS                            
                                                                                
              MOVE VOPSM-GROUP-NUMBER   TO WS-PREV-GROUP                        
              MOVE VDATE-ALIS-YEAR1     TO WS-PSM-RENEW-YEAR                    
              MOVE VDATE-ALIS-DAY1      TO WS-PSM-RENEW-DAY                     
           ELSE                                                                 
FXXTOK        MOVE LOW-VALUES        TO PSMASTE7                                
              MOVE WS-CURR-GROUP     TO GACCDMA7-PS-GROUP                       
              MOVE HIGH-VALUES       TO GACCDMA7-PS-ACCT                        
              CALL 'GACCDMA7'     USING GACCDMA7-PS-PARMS                       
                                        GACCDMA7-PS-RETURN                      
FXXTOK                                  PSMASTE7                                
                                                                                
              IF GACCDMA7-PS-RETURN = 'R01'                                     
                 MOVE -1                TO WS-PREV-GROUP                        
                 MOVE WS-LOW-DATE       TO WS-PSM-RENEW-DATE                    
              ELSE                                                              
                 IF GACCDMA7-PS-RETURN NOT = SPACES                             
FXXTOK              GO TO 799-SQL-STATUS                                        
                 ELSE                                                           
                    MOVE PSMGROUP-NUMBER      TO WS-PREV-GROUP                  
                    MOVE PSMNXT-RNEW-YR       TO WS-PSM-RENEW-YEAR              
                    MOVE PSMNXT-RNEW-DAY      TO WS-PSM-RENEW-DAY.              
                                                                                
       100-GET-VCM-GPSY-MASTER.                                                 
      *****************************************************************         
      *  SEP/90 M. PRANGE.                                                      
      *       - DON'T PRINT ERROR MESSAGE IF GIPSY MASTER PURGED.               
      *****************************************************************         
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT TO EXT-COMM-GROUP-NUMBER.           
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ KEYED (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES                    TO VGWI-SOURCE-SYSTEM.                
           MOVE 'READ KEYED'              TO VGWI-REQUEST.                      
           MOVE SPACES                    TO VGWI-COVERAGE-TYPE.                
           MOVE EXT-COMM-GROUP-NUMBER-N   TO VGWI-GROUP.                        
           MOVE GR-ACCOUNT OF GWCORGRACCT TO VGWI-ACCOUNT.                      
           MOVE 'GIPSY EXPANDED'          TO VGWI-LR-NAME.                      
           PERFORM 150-READ-VCM-GIPSY THRU 150-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           ELSE                                                                 
             IF VGWO-RET-CODE = '31'                                            
      *      READ-KEYED RECORD NOT FOUND                                        
                MOVE GROUP-NUMBER OF GWCORGRACCT    TO                          
                     EXT-DATE-GROUP-NUMBER                                      
                MOVE GR-ACCOUNT OF GWCORGRACCT      TO                          
                     EXT-DATE-GROUP-ACCOUNT                                     
                MOVE LAST-RECON-DATE OF GWCORGRACCT TO                          
                     EXT-LAST-RECON-DATE                                        
                MOVE LAST-RECON-DATE OF GWCORGRACCT TO                          
                     EXT-NEXT-RECON-DATE                                        
                PERFORM 620-WRITE-DATE-REC                                      
                GO TO 100-GET-NEXT-ACCOUNT                                      
             ELSE                                                               
                IF VGWO-RET-SEVERE-ERROR                                        
FXXTOK             GO TO 799-SQL-STATUS.                                        
                                                                                
           IF  WS-PSM-RENEW-DATE = WS-LOW-DATE                                  
               MOVE GGINEXT-ANNIVERSARY   TO WS-PSM-RENEW-DATE.                 
                                                                                
           PERFORM 110-DETERMINE-GROUP-STATUS.                                  
           IF  ACCOUNT-TERMINATED                                               
               IF  WS-TERM-EFF-DATE > WS-TERM-PRO-DATE                          
                   MOVE WS-TERM-EFF-DATE   TO WS-RECON-TERM-DATE                
               ELSE                                                             
                   MOVE WS-TERM-PRO-DATE   TO WS-RECON-TERM-DATE                
           ELSE                                                                 
               MOVE WS-LOW-DATE            TO WS-RECON-TERM-DATE.               
                                                                                
      *----------------------------------------------------------------         
      * FOR NON-VO GROUPS                                                       
      *----------------------------------------------------------------         
           IF VGWO-SOURCE-SYSTEM NOT = 'V'                                      
                                                                                
           IF ACCOUNT-TERMINATED                                                
               IF GGIBILLING-TYPE = 'SA'                                        
      ************ TERMINATED SELF ADMIN ******************************         
                   IF GBIDUE-YEAR = +0                                          
                       GO TO 100-GET-NEXT-ACCOUNT                               
                   ELSE                                                         
MAN02                  CALL QDATEQ2 USING QDATE-FORMATA                         
MAN02                                     GBIDUE-DATE                           
MAN02                                     WS-DATE-DUE                           
                       MOVE WS-MONTH-DUE TO MONTH-SUB                           
                       MOVE WS-DATE-TABLE-ENTRY (MONTH-SUB)                     
                                    TO WS-DAY-DUE                               
MAN02                  CALL QDATEQ2 USING QDATE-FORMATB                         
MAN02                                     WS-DATE-DUE                           
MAN02                                     WS-DUE-DATE                           
                       IF ( WS-DUE-DATE EQUAL TO WS-TERM-EFF-DATE               
                            OR WS-DUE-DATE EQUAL TO WS-TERM-PRO-DATE)           
                       AND GBILIFE EQUAL TO ZERO                                
                       AND GBILTD  EQUAL TO ZERO                                
                       AND GBIA-S  EQUAL TO ZERO                                
                           PERFORM 200-PROCESS-GROUP-ACCOUNT                    
                       ELSE                                                     
                           NEXT SENTENCE                                        
               ELSE                                                             
      ************ OTHER TERMINATED ***********************************         
                   IF ( GBIDUE-DATE EQUAL TO WS-TERM-EFF-DATE                   
                        OR GBIDUE-DATE EQUAL TO WS-TERM-PRO-DATE )              
                   AND GBILIFE EQUAL TO ZERO                                    
                   AND GBILTD  EQUAL TO ZERO                                    
                   AND GBIA-S  EQUAL TO ZERO                                    
                       PERFORM 200-PROCESS-GROUP-ACCOUNT                        
                   ELSE                                                         
                       NEXT SENTENCE                                            
           ELSE                                                                 
               IF GGIBILLING-TYPE = 'SA'                                        
      ************ INFORCE SELF-ADMIN *********************************         
                   IF GBIDUE-YEAR = +0                                          
                       GO TO 100-GET-NEXT-ACCOUNT                               
                   ELSE                                                         
MAN02                  CALL QDATEQ2 USING QDATE-FORMATA                         
MAN02                                     GBIDUE-DATE                           
MAN02                                     WS-DATE-DUE                           
                       MOVE WS-MONTH-DUE TO MONTH-SUB                           
                       MOVE WS-DATE-TABLE-ENTRY (MONTH-SUB)                     
                                    TO WS-DAY-DUE                               
MAN02                  CALL QDATEQ2 USING QDATE-FORMATB                         
MAN02                                     WS-DATE-DUE                           
MAN02                                     WS-DUE-DATE                           
      *----------------------------------------------------------------         
      * WS-DUE-DATE NOW CONTAINS DATE THE SELF-ADMIN GROUP IS CONSIDERED        
      * PAID TO, PROVIDED COVERAGE AMOUNTS ARE ALL ZERO.  I.B.                  
      *----------------------------------------------------------------         
                       IF WS-DUE-DATE  NOT <  NEXT-RECON-DATE                   
                       AND GBILIFE EQUAL TO ZERO                                
                       AND GBILTD  EQUAL TO ZERO                                
                       AND GBIA-S  EQUAL TO ZERO                                
                           PERFORM 200-PROCESS-GROUP-ACCOUNT                    
                       ELSE                                                     
                           PERFORM 700-OUTSTAND-REPORT THRU 709-EXIT            
               ELSE                                                             
      ************ OTHER INFORCE **************************************         
                   IF  GGIPAID-TO-DATE IS LESS THAN NEXT-RECON-DATE             
                       PERFORM 700-OUTSTAND-REPORT THRU 709-EXIT                
                   ELSE                                                         
                       PERFORM 200-PROCESS-GROUP-ACCOUNT.                       
                                                                                
      *----------------------------------------------------------------         
      * FOR VO GROUPS                                                           
      *----------------------------------------------------------------         
           IF VGWO-SOURCE-SYSTEM = 'V'                                          
              MOVE '9' TO VDATE-REQ-SERVICE                                     
              MOVE 'B' TO VDATE-REQ-BASIS                                       
              MOVE '2' TO VDATE-REQ-DETAIL                                      
              MOVE 'E' TO VDATE-REQ-LANGUAGE                                    
              MOVE GBIDUE-YEAR          TO VDATE-ALIS-YEAR1                     
              MOVE GBIDUE-DAY           TO VDATE-ALIS-DAY1                      
              CALL GC2DATE USING GAC-DATE-PARAMETERS                            
              MOVE VDATE-DD             TO WS-VO-DUE-DD                         
              MOVE VDATE-MM             TO WS-VO-DUE-MM                         
              MOVE VDATE-YY             TO WS-VO-DUE-YY                         
                                                                                
              MOVE '9' TO VDATE-REQ-SERVICE                                     
              MOVE 'B' TO VDATE-REQ-BASIS                                       
              MOVE '2' TO VDATE-REQ-DETAIL                                      
              MOVE 'E' TO VDATE-REQ-LANGUAGE                                    
              MOVE NEXT-RECON-YEAR      TO VDATE-ALIS-YEAR1                     
              MOVE NEXT-RECON-DAY       TO VDATE-ALIS-DAY1                      
              CALL GC2DATE USING GAC-DATE-PARAMETERS                            
              MOVE VDATE-DD             TO WS-VO-RECON-DD                       
              MOVE VDATE-MM             TO WS-VO-RECON-MM                       
              MOVE VDATE-YY             TO WS-VO-RECON-YY                       
                                                                                
              IF WS-VO-DUE-YYMM NOT <  WS-VO-RECON-YYMM                         
                 AND GBILIFE EQUAL TO ZERO                                      
                 AND GBILTD  EQUAL TO ZERO                                      
                 AND GBIA-S  EQUAL TO ZERO                                      
                   PERFORM 200-PROCESS-GROUP-ACCOUNT                            
              ELSE                                                              
                 IF (WS-VO-DUE-YYMM > WS-VO-RECON-YYMM)                         
                     AND                                                        
                    (GBILIFE = +0 OR +1)                                        
                     AND                                                        
                    (GBILTD  = +0 OR +1)                                        
                     AND                                                        
                    (GBIA-S  = +0 OR +1)                                        
                       PERFORM 200-PROCESS-GROUP-ACCOUNT.                       
                                                                                
       100-GET-NEXT-ACCOUNT.                                                    
      *%   FIND CURRENT GWCORGRACCT.                                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 11 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   OBTAIN NEXT GWCORGRACCT WITHIN GW-COMP-AREA1                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 12 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
       100-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       110-DETERMINE-GROUP-STATUS.                                              
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     -  CHECK IF ACCOUNT IS ACTIVE OR TERMINATED.              *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 0 TO GTM-SUB.                                                   
           MOVE 'N' TO GTM-SWITCH.                                              
                                                                                
           IF  GTMTRIDENT = '130'                                               
               MOVE 5 TO GTM-SUB                                                
               PERFORM 120-FIND-DATA                                            
                   UNTIL GTM-DATA-FOUND                                         
                   OR  GTM-SUB = 0.                                             
                                                                                
           IF  GTM-SUB IS GREATER THAN ZERO                                     
           AND GTMEFFECTIVE-DATE (GTM-SUB) IS NOT GREATER THAN                  
               NEXT-RECON-DATE OF GWCORGRACCT                                   
           AND GTMREIN-YEAR (GTM-SUB) = +000                                    
           AND GTMREIN-DAY  (GTM-SUB) = +000                                    
           AND GTMREIN-CODE (GTM-SUB) = SPACES                                  
               MOVE 'T' TO ACCT-SWITCH                                          
           ELSE                                                                 
               MOVE 'A' TO ACCT-SWITCH.                                         
                                                                                
           IF ACCOUNT-TERMINATED                                                
               MOVE GTMEFFECTIVE-DATE (GTM-SUB) TO WS-TERM-EFF-DATE             
               MOVE GTMPROCESSED-DATE (GTM-SUB) TO WS-TERM-PRO-DATE             
           ELSE                                                                 
               MOVE WS-LOW-DATE TO WS-TERM-EFF-DATE                             
                                   WS-TERM-PRO-DATE.                            
                                                                                
       110-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       120-FIND-DATA.                                                           
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  LOOP AROUND TO GET LAST TERMINATION TRAILER WITH DATA    *         
      *          ON THE GIPSY MASTER RECORD.                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  GTMEFFECTIVE-YEAR (GTM-SUB) IS NUMERIC                           
           AND GTMEFFECTIVE-YEAR (GTM-SUB) IS GREATER THAN ZERO                 
               MOVE 'Y' TO GTM-SWITCH                                           
           ELSE                                                                 
               SUBTRACT 1 FROM GTM-SUB.                                         
                                                                                
       120-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------                     
      * VOCOMM VCM/GIPSY                                                        
       150-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       150-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
      /                                                                         
       200-PROCESS-GROUP-ACCOUNT.                                               
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     -  GET FIRST COMP RECORD WITHIN ACCOUNT.                  *         
      *     -  INVOKE PROCESS COMP.                                   *         
      *     -  INVOKE CREATE DATE RECORD.                             *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *****************************************************************         
      *  SEP/90 M. PRANGE.                                                      
      *       - IF NO COMP RECORDS WERE PROCESSED, DO NOT OUTPUT A              
      *         DATE EXTRACT. PRINT AN ERROR.                                   
      *****************************************************************         
                                                                                
           MOVE +0                 TO WS-COMP-PROC-CNT.                         
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           PERFORM 300-PROCESS-COMP THRU 319-EXIT                               
               UNTIL DB-END-OF-SET.                                             
                                                                                
           IF  WS-COMP-PROC-CNT > +0                                            
               PERFORM 450-FORMAT-DATE-REC                                      
               IF  ACCOUNT-TERMINATED                                           
                   PERFORM 460-RECON-TERM-GROUPS                                
               ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               PERFORM 805-ERROR-REPORT.                                        
      /                                                                         
       300-PROCESS-COMP.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  BYPASS COMP RECORD IN THE FUTURE                       *         
      *     -  BYPASS EARNED AMENDMENT.                               *         
      *            IF  TERMINATED ACCOUNT                             *         
      *                INVOKE PROCESS RECOVER-AMENDMENTS              *         
      *            ELSE                                               *         
      *                INVOKE CREATE EXTRACT RECORD.                  *         
      *     -  GET NEXT COMP RECORD.                                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 0 TO WS-EXT-MONTHS.                                             
                                                                                
           IF  COMP-EFF-DATE IS GREATER THAN NEXT-RECON-DATE                    
               GO TO 310-GET-NEXT-COMP.                                         
                                                                                
           IF  COMP-TYPE = 'F'                                                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF (COMP-REASON = 'A' OR 'B')                                    
                   IF  COMP-DISP = 'E'                                          
                       GO TO 310-GET-NEXT-COMP                                  
                   ELSE                                                         
                       NEXT SENTENCE                                            
               ELSE                                                             
                   IF  RECON-IND = 'Y'                                          
                       NEXT SENTENCE                                            
                   ELSE                                                         
                       GO TO 310-GET-NEXT-COMP.                                 
                                                                                
           IF  ACCOUNT-TERMINATED                                               
           AND (COMP-REASON = 'A' OR 'B')                                       
               PERFORM 340-AMEND-RECOVERY                                       
           ELSE                                                                 
               IF  COMP-EFF-DATE GREATER THAN LAST-RECON-DATE                   
                   PERFORM 360-EXTRACT-COMP THRU 369-EXIT                       
               ELSE                                                             
                   NEXT SENTENCE.                                               
                                                                                
       310-GET-NEXT-COMP.                                                       
                                                                                
      *%   OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       319-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       340-AMEND-RECOVERY.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  CALC NUMBER OF MONTHS TO RECOVER.                      *         
      *     -  ONE MORE MONTH IS SUBTRACTED TO ENSURE THAT WHENEVER   *         
      *        AN ACCOUNT TERMINATES BEFORE THE END OF THE MONTH OR   *         
      *        AN AMENDMENT IS EFFECTIVE BEFORE THE END OF A MONTH    *         
      *        THAT THE AGENT GETS THE FULL MONTH BENEFIT ANYWAY...   *         
      *        ....MANUFACTURER'S WILL "KINDLY" ASSUME THE LOST...    *         
      *     -  INVOKE CREATE EXTRACT RECORD.                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           ADD 1 COMP-EFF-YEAR GIVING WS-AMEND-END-YEAR.                        
           MOVE COMP-EFF-DAY TO WS-AMEND-END-DAY.                               
                                                                                
           IF WS-AMEND-END-DATE GREATER THAN GTMEFFECTIVE-DATE (GTM-SUB)        
MAN02          CALL QDATEQ2 USING QDATE-FORMATA                                 
MAN02                             WS-AMEND-END-DATE                             
MAN02                             WS-NUM-AMEND-END-DATE                         
MAN02          CALL QDATEQ2 USING QDATE-FORMATA                                 
MAN02                             GTMEFFECTIVE-DATE (GTM-SUB)                   
MAN02                             WS-NUM-TERM-DATE                              
      *        COMPUTE WS-EXT-MONTHS =                                          
      *           (((WS-NUM-AMEND-END-YEAR - WS-NUM-TERM-YEAR) * 12)            
      *           + (WS-NUM-AMEND-END-MONTH - WS-NUM-TERM-MONTH) - 1)           
               COMPUTE WS-EXT-MONTHS =                                          
                  (((WS-AMEND-END-YEAR - GTMEFFECTIVE-YEAR (GTM-SUB))           
                                         * 12)                                  
                  + (WS-NUM-AMEND-END-MONTH - WS-NUM-TERM-MONTH) - 1)           
               IF  WS-EXT-MONTHS GREATER THAN 0                                 
                   PERFORM 360-EXTRACT-COMP THRU 369-EXIT                       
               ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               NEXT SENTENCE.                                                   
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  EDIT COMP RECORD.                                      *         
      *     -  IF  COMP-IS-VALID,                                     *         
      *        INVOKE CREATE EXTRACT COMMISSION RECORD                *         
      *                      OR      NAP RECORD                       *         
      *            DEPENDING ON COMP-TYPE.                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       360-EXTRACT-COMP.                                                        
                                                                                
           PERFORM 370-VALIDATE-COMP THRU 379-EXIT.                             
                                                                                
           IF COMP-IS-VALID                                                     
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 369-EXIT.                                                  
                                                                                
           IF  COMP-TYPE = 'S' OR 'F' OR 'C'                                    
               PERFORM 430-FORMAT-COMM-REC                                      
           ELSE                                                                 
               IF  COMP-TYPE = 'N'                                              
                   PERFORM 440-FORMAT-NAP-REC                                   
               ELSE                                                             
                   NEXT SENTENCE.                                               
                                                                                
       369-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       370-VALIDATE-COMP.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  VALIDATE COMP RECORD:   COMP-TYPE                      *         
      *                                COMP-DISP                      *         
      *                                COMP-REASON                    *         
      *                                COV-TYPE.                      *         
      *                                                               *         
      *     - IN  ANY ONE OF THE ABOVE INVALID - REPORT.              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE '0' TO ERROR-SWITCH.                                            
                                                                                
           IF  COMP-TYPE = 'S' OR 'F' OR 'C' OR 'N'                             
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE '2' TO ERROR-SWITCH                                         
               PERFORM 800-ERROR-REPORT                                         
               GO TO 379-EXIT.                                                  
                                                                                
           IF  COMP-DISP = 'P' OR 'E'                                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE '3' TO ERROR-SWITCH                                         
               PERFORM 800-ERROR-REPORT                                         
               GO TO 379-EXIT.                                                  
                                                                                
           IF  COMP-REASON = 'F' OR 'R' OR 'A' OR 'B'                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE '4' TO ERROR-SWITCH                                         
               PERFORM 800-ERROR-REPORT                                         
               GO TO 379-EXIT.                                                  
                                                                                
           IF  (COMP-TYPE = 'S' OR 'F' OR 'C')                                  
               IF  (COV-TYPE = 'L' OR 'T' OR 'O')                               
                   NEXT SENTENCE                                                
               ELSE                                                             
                   MOVE '5' TO ERROR-SWITCH                                     
                   PERFORM 800-ERROR-REPORT                                     
           ELSE                                                                 
               IF  COMP-TYPE = 'N'                                              
                   IF  (COV-TYPE = '#')                                         
                       NEXT SENTENCE                                            
                   ELSE                                                         
                       MOVE '5' TO ERROR-SWITCH                                 
                       PERFORM 800-ERROR-REPORT.                                
                                                                                
           IF  COMP-TYPE = 'F'                                                  
               IF  COMP-DISP = 'P'                                              
                   NEXT SENTENCE                                                
               ELSE                                                             
                   MOVE '3' TO ERROR-SWITCH                                     
                   PERFORM 800-ERROR-REPORT.                                    
                                                                                
       379-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       400-FIND-DATA.                                                           
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  LOOP AROUND TO GET LAST TERMINATION TRAILER WITH DATA    *         
      *          ON THE GIPSY MASTER RECORD.                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  GTMEFFECTIVE-YEAR (GTM-SUB) IS NUMERIC                           
           AND GTMEFFECTIVE-YEAR (GTM-SUB) IS GREATER THAN ZERO                 
               MOVE 'Y' TO GTM-SWITCH                                           
           ELSE                                                                 
               SUBTRACT 1 FROM GTM-SUB.                                         
      /                                                                         
       430-FORMAT-COMM-REC.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   - FORMAT COMMISSION EXTRACT RECORD                          *         
      *     JUN/98 REMOVED ALPHA SPECIFIC EDITS                       *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT TO EXT-COMM-GROUP-NUMBER.           
           MOVE GR-ACCOUNT OF GWCORGRACCT TO EXT-COMM-GROUP-ACCOUNT.            
           MOVE COMP-EFF-DATE TO EXT-COMM-EFF-DATE.                             
           MOVE AGENT-NUMBER TO EXT-COMM-AGENT-NUMBER                           
                                WS-BROKER-AGENT-NUMBER.                         
           IF WS-BA-PART1 = 09 OR WS-BA-FIRST = 9                               
      *       IF GGIPRODUCT-CODE = '1'                                          
      *          MOVE GGIBRANCH TO EXT-COMM-GFO-NUMBER                          
      *          MOVE '1' TO EXT-COMM-REC-TYPE                                  
      *       ELSE                                                              
                 MOVE GGIGROUP-OFFICE TO EXT-COMM-GFO-NUMBER                    
                 MOVE '2' TO EXT-COMM-REC-TYPE                                  
           ELSE                                                                 
              MOVE GGIBRANCH TO EXT-COMM-GFO-NUMBER                             
              MOVE '1' TO EXT-COMM-REC-TYPE.                                    
           MOVE GGIBRANCH TO EXT-COMM-BR-NUMBER.                                
           MOVE COMP-TYPE TO EXT-COMM-COMP-TYPE.                                
           MOVE COMP-REASON TO EXT-COMM-COMP-REASON.                            
           MOVE COMP-DISP TO EXT-COMM-COMP-DISP.                                
           MOVE COV-TYPE TO EXT-COMM-COV-TYPE.                                  
           MOVE COMP-AMT TO EXT-COMM-COMP-AMT.                                  
           MOVE WS-EXT-MONTHS TO EXT-COMM-MONTHS.                               
           IF  COMP-TYPE EQUAL TO 'S'                                           
           AND (COMP-REASON EQUAL TO 'A' OR 'B')                                
           AND WS-EXT-MONTHS EQUAL TO ZERO                                      
               NEXT SENTENCE                                                    
           ELSE                                                                 
               ADD +1        TO WS-COMP-PROC-CNT                                
               PERFORM 600-WRITE-COMM-REC.                                      
      /                                                                         
       440-FORMAT-NAP-REC.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  FORMAT NAP EXTRACT RECORD                                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT TO EXT-NAP-GROUP-NUMBER.            
           MOVE GR-ACCOUNT OF GWCORGRACCT TO EXT-NAP-GROUP-ACCOUNT.             
           MOVE AGENT-NUMBER TO EXT-NAP-AGENT-NUMBER.                           
           MOVE GFO-NUMBER TO EXT-NAP-GFO-NUMBER.                               
           MOVE COMP-TYPE TO EXT-NAP-COMP-TYPE.                                 
           MOVE COMP-DISP TO EXT-NAP-COMP-DISP.                                 
           MOVE COMP-REASON TO EXT-NAP-COMP-REASON.                             
           MOVE COMP-AMT TO EXT-NAP-COMP-AMT.                                   
           MOVE WS-EXT-MONTHS TO EXT-NAP-MONTHS.                                
           IF  (COMP-REASON EQUAL TO 'A' OR 'B')                                
           AND WS-EXT-MONTHS EQUAL TO ZERO                                      
               NEXT SENTENCE                                                    
           ELSE                                                                 
               PERFORM 610-WRITE-NAP-REC.                                       
      /                                                                         
       450-FORMAT-DATE-REC.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  FORMAT RECONCILIATION DATES EXTRACT RECORD               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *****************************************************************         
      *  SEP/90 M. PRANGE.                                                      
      *       - UPDATE NEXT RECON DATE WITH PSM-NEXT-RENEW DATE FOR             
      *         ACTIVE GROUPS.                                                  
      *****************************************************************         
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT TO EXT-DATE-GROUP-NUMBER.           
           MOVE GR-ACCOUNT OF GWCORGRACCT   TO EXT-DATE-GROUP-ACCOUNT.          
                                                                                
           MOVE NEXT-RECON-DATE OF GWCORGRACCT                                  
                                            TO EXT-LAST-RECON-DATE.             
           IF  ACCOUNT-TERMINATED                                               
               MOVE NEXT-RECON-DATE OF GWCORGRACCT                              
                                            TO EXT-NEXT-RECON-DATE              
           ELSE                                                                 
               IF  WS-PSM-RENEW-DAY = +1                                        
                   MOVE +365                TO EXT-NEXT-RECON-DAY               
                   COMPUTE EXT-NEXT-RECON-YEAR = WS-PSM-RENEW-YEAR - 1          
               ELSE                                                             
                   COMPUTE EXT-NEXT-RECON-DAY  = WS-PSM-RENEW-DAY - 1           
                   MOVE WS-PSM-RENEW-YEAR   TO EXT-NEXT-RECON-YEAR.             
                                                                                
           PERFORM 620-WRITE-DATE-REC.                                          
      /                                                                         
       460-RECON-TERM-GROUPS.                                                   
      *****************************************************************         
      *  SEP/90 A. NIKELSKI                                                     
      *       - IF A TERMINATED GROUP RECONCILES (DUE TO LAST PAYMENT           
      *         BEING RECEIVED I.E. OUTSTANDING AMOUNT ARE NOW ZERO)            
      *****************************************************************         
           IF WS-RECON-TERM-DATE = EXT-NEXT-RECON-DATE                          
              PERFORM 820-PRINT-EXTRACT-LINE.                                   
                                                                                
       500-END-OF-JOB.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  CLOSE EXTRACT FILES                                      *         
      *            REPORT FILES.                                     *          
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE ERROR-COUNT TO RPT-ERROR-COUNT.                                 
           MOVE ERROR-TOTAL TO ERROR-LINE.                                      
           PERFORM 810-PRINT-ERROR-LINE.                                        
           MOVE END-LINE TO ERROR-LINE.                                         
           PERFORM 810-PRINT-ERROR-LINE.                                        
                                                                                
           MOVE +4 TO DLSC-RETURN                                               
                      DLSN-RETURN                                               
                      DLSD-RETURN                                               
                      DLSO-RETURN                                               
                      DLSE-RETURN                                               
                      DLSR-RETURN                                               
                      DLS026-RETURN.                                            
           PERFORM 550-READ-RUNDATE THRU 550-EXIT.                              
           PERFORM 600-WRITE-COMM-REC.                                          
           PERFORM 610-WRITE-NAP-REC.                                           
           PERFORM 620-WRITE-DATE-REC.                                          
           PERFORM 710-PRINT-OUTSTAND-LINE.                                     
           PERFORM 810-PRINT-ERROR-LINE.                                        
      *    PERFORM 820-PRINT-EXTRACT-LINE.                                      
           PERFORM 830-WRITE-EXTRACT-FILE.                                      
      /                                                                         
       550-READ-RUNDATE.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  READ RUNDATE FROM SYS019                                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSREAD' USING DLSR-SYSNUM                                     
                                DLSR-RETURN                                     
                                PROGRAM-RUN-DATE-RECORD                         
                                DLSR-REC-SIZE                                   
                                DLSR-BLK-SIZE                                   
                                DLSR-FORMAT                                     
                                DLSR-REC-COUNT.                                 
                                                                                
           IF  DLSR-RETURN = +0                                                 
                          OR +4                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSREAD FAILED - SYS019' UPON CONSOLE                   
FXXTOK         GO TO 799-SQL-STATUS.                                            
       550-EXIT.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       600-WRITE-COMM-REC.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  WRITE COMMISSION EXTRACT RECORD                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           CALL 'DLSWRITE' USING DLSC-SYSNUM                                    
                                 DLSC-RETURN                                    
                                 EXT-RECON-COMM-RECORD                          
                                 DLSC-REC-SIZE                                  
                                 DLSC-BLK-SIZE                                  
                                 DLSC-FORMAT                                    
                                 DLSC-REC-COUNT.                                
                                                                                
           IF  DLSC-RETURN = +0                                                 
                          OR +4                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS021' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       610-WRITE-NAP-REC.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  WRITE NAP EXTRACT RECORD                                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLSN-SYSNUM                                    
                                 DLSN-RETURN                                    
                                 EXT-RECON-NAP-RECORD                           
                                 DLSN-REC-SIZE                                  
                                 DLSN-BLK-SIZE                                  
                                 DLSN-FORMAT                                    
                                 DLSN-REC-COUNT.                                
                                                                                
           IF  DLSN-RETURN = +0                                                 
                          OR +4                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS022' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       620-WRITE-DATE-REC.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  WRITE RECONCILIATION DATES EXTRACT RECORD                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLSD-SYSNUM                                    
                                 DLSD-RETURN                                    
                                 EXT-RECON-DATE-RECORD                          
                                 DLSD-REC-SIZE                                  
                                 DLSD-BLK-SIZE                                  
                                 DLSD-FORMAT                                    
                                 DLSD-REC-COUNT.                                
                                                                                
           IF  DLSD-RETURN = +0                                                 
                          OR +4                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS023' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       700-OUTSTAND-REPORT.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  FORMAT OUTSTANDING RECONCILIATIONS REPORT                *         
      *   -  REPORT ALL GROUPS WHICH SHOULD BE RECONCILING AND        *         
      *      ARE MORE THAN 30 DAYS IN ARREARS.                        *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  GGIPAID-TO-YEAR IS NUMERIC                                       
           AND GGIPAID-TO-DAY IS NUMERIC                                        
           AND GGIPAID-TO-YEAR IS GREATER THAN ZERO                             
           AND GGIPAID-TO-DAY IS GREATER THAN ZERO                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'MISSING' TO OUTSTD-PAID-DATE                               
               GO TO 705-CONTINUE.                                              
                                                                                
           MOVE GGIPAID-TO-DATE TO WS-ALIS-CHECK-DATE.                          
           ADD +30 TO WS-ALIS-CHECK-DAY.                                        
           IF WS-ALIS-CHECK-DAY GREATER THAN +365                               
               ADD +1 TO WS-ALIS-CHECK-YR                                       
               SUBTRACT +365 FROM WS-ALIS-CHECK-DAY.                            
                                                                                
           IF  WS-ALIS-CHECK-DATE IS LESS THAN WS-ALIS-RUN-DATE                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 709-EXIT.                                                  
                                                                                
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         GGIPAID-TO-DATE                                   
MAN02                         OUTSTD-PAID-DATE.                                 
                                                                                
       705-CONTINUE.                                                            
                                                                                
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         NEXT-RECON-DATE OF GWCORGRACCT                    
MAN02                         OUTSTD-NEXT-RECON-DATE.                           
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         LAST-RECON-DATE OF GWCORGRACCT                    
MAN02                         OUTSTD-LAST-RECON-DATE.                           
           MOVE GROUP-NUMBER OF GWCORGRACCT TO OUTSTD-GROUP.                    
           MOVE GR-ACCOUNT OF GWCORGRACCT TO OUTSTD-ACCOUNT.                    
           MOVE GGIGROUP-OFFICE  TO OUTSTD-GFO.                                 
           MOVE GGIACCOUNT-STATUS  TO OUTSTD-STATUS.                            
                                                                                
           MOVE OUTSTD-DETAILS TO OUTSTD-LINE.                                  
           PERFORM 710-PRINT-OUTSTAND-LINE.                                     
                                                                                
       709-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       710-PRINT-OUTSTAND-LINE.                                                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  PRINT OUTSTANDING RECONCILIATION REPORT                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLSO-SYSNUM                                    
                                 DLSO-RETURN                                    
                                 OUTSTD-LINE                                    
                                 DLSO-REC-SIZE                                  
                                 DLSO-BLK-SIZE                                  
                                 DLSO-FORMAT                                    
                                 DLSO-REC-COUNT.                                
                                                                                
           IF  DLSO-RETURN = +0                                                 
                          OR +4                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS024' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       800-ERROR-REPORT.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  FORMAT ERROR REPORT LINES.                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GROUP-NUMBER OF GWCORGRACCT TO ERROR-GROUP.                     
           MOVE GR-ACCOUNT OF GWCORGRACCT TO ERROR-ACCOUNT.                     
           MOVE COMP-TYPE TO ERROR-COMP-TYPE.                                   
           MOVE COMP-DISP TO ERROR-COMP-DISP.                                   
           MOVE COMP-REASON TO ERROR-COMP-REASON.                               
           MOVE COV-TYPE TO ERROR-COV-TYPE.                                     
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         COMP-EFF-DATE                                     
MAN02                         ERROR-EFF-DATE.                                   
                                                                                
           IF  ERROR-SWITCH = '2'                                               
               MOVE ERROR-NOTE-2 TO ERROR-NOTE                                  
           ELSE                                                                 
               IF  ERROR-SWITCH = '3'                                           
                   MOVE ERROR-NOTE-3 TO ERROR-NOTE                              
               ELSE                                                             
                   IF  ERROR-SWITCH = '4'                                       
                       MOVE ERROR-NOTE-4 TO ERROR-NOTE                          
                   ELSE                                                         
                       IF  ERROR-SWITCH = '5'                                   
                           MOVE ERROR-NOTE-5 TO ERROR-NOTE.                     
                                                                                
           MOVE ERROR-DETAILS TO ERROR-LINE.                                    
           PERFORM 810-PRINT-ERROR-LINE.                                        
           ADD 1 TO ERROR-COUNT.                                                
      /                                                                         
       805-ERROR-REPORT.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  FORMAT ERROR REPORT LINES.                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE SPACES                      TO ERROR-DETAIL-DATA.               
           MOVE GROUP-NUMBER OF GWCORGRACCT TO ERROR-GROUP.                     
           MOVE GR-ACCOUNT OF GWCORGRACCT   TO ERROR-ACCOUNT.                   
           MOVE ERROR-NOTE-6                TO ERROR-NOTE.                      
                                                                                
           MOVE ERROR-DETAILS TO ERROR-LINE.                                    
           PERFORM 810-PRINT-ERROR-LINE.                                        
           ADD 1 TO ERROR-COUNT.                                                
      /                                                                         
       810-PRINT-ERROR-LINE.                                                    
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  PRINT ERROR REPORT.                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLSE-SYSNUM                                    
                                 DLSE-RETURN                                    
                                 ERROR-LINE                                     
                                 DLSE-REC-SIZE                                  
                                 DLSE-BLK-SIZE                                  
                                 DLSE-FORMAT                                    
                                 DLSE-REC-COUNT.                                
                                                                                
           IF  DLSE-RETURN = +0                                                 
                          OR +4                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS025' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           MOVE SPACES TO ERROR-DETAIL-DATA.                                    
                                                                                
       820-PRINT-EXTRACT-LINE.                                                  
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  PRINT EXTRACT FILE                                       *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                                         
      * PRINT ONLY RECORDS WHOSE ISSUE DATE IS WITHIN 12 MONTHS OF              
      * SUSPENSION DATE JUN/98                                                  
      *                                                                         
           MOVE GGICONTRACT-ISSUE      TO   VDATE-ALIS-DATE1.                   
           MOVE GGICLAIMS-SUSPENDED    TO   VDATE-ALIS-DATE2.                   
           MOVE '3B2'                  TO   VDATE-REQUEST-AREA.                 
           MOVE +0                     TO   VDATE-ADJUST-MONTHS.                
           CALL  GC2DATE  USING GAC-DATE-PARAMETERS.                            
           IF VDATE-RET-FAIL                                                    
               DISPLAY '**********************************************'         
               DISPLAY 'ERROR CALLING GC2DATE ' VDATE-RET-CODE ' GROUP '        
                 GGIGROUP-NUMBER ' ACCT' GGIACCOUNT                             
               DISPLAY '**********************************************'         
               MOVE +999                TO  WS-MONTHS                           
           ELSE                                                                 
               MOVE VDATE-ADJUST-MONTHS TO  WS-MONTHS.                          
      *                                                                         
           IF WS-MONTHS < 13                                                    
                                                                                
      *%      OBTAIN CURRENT GWCORGRACCT                                        
IOS           MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                       
IOS           MOVE 3 TO FCCSPL-DML-SEQ-NO                                       
IOS           MOVE +6  TO FCCSPL-ADDRESS-COUNT                                  
MAN02         CALL GWFADDR                                                      
MAN02              USING FCCSPL-ADDRESS-AREA                                    
MAN02                    FCCSPL-SELECT-USING-CURR                               
MAN02                    FCCSPLIO-GWCORGRACCT                                   
MAN02                    FCCSPL-GWCORGRACCT                                     
MAN02                    GWCORGRACCT                                            
MAN02                    FCCSPL-OBTAIN                                          
MAN02                    FCCSPL-NOKEEP                                          
IOS           END-CALL                                                          
FXXTOK        CALL GWFSPLB1                                                     
IOS                USING DUMMY-PARM-1                                           
IOS                      DUMMY-PARM-2                                           
IOS                      DBLINK-SUBSCHEMA-CONTROL                               
IOS                      DBLINK-RECORD-SET-KEYS                                 
IOS                      DBLINK-CURSOR-CODES                                    
IOS           END-CALL                                                          
IOS           PERFORM 799-SQL-STATUS                                            
IOS              THRU 799-SQL-STATUS-EXIT                                       
MAN02         CALL QDATEQ2 USING QDATE-FORMATC                                  
MAN02                         LAST-RECON-DATE OF GWCORGRACCT                    
MAN02                         EXTRACT-TERM-RECON                                
      * POPULATE NEW FIELDS                                                     
              MOVE GGIPRODUCT-CODE TO EXTRACT-TERM-PRODUCT-CODE                 
              MOVE GGIGROUP-OFFICE TO EXTRACT-TERM-GFO                          
              MOVE GGIGROUP-REP    TO EXTRACT-TERM-REP                          
      *                                                                         
MAN02         CALL QDATEQ2 USING QDATE-FORMATC                                  
MAN02                            GGICONTRACT-ISSUE                              
MAN02                            EXTRACT-TERM-CONTRACT-ISSUE                    
      *                                                                         
              MOVE GROUP-NUMBER OF GWCORGRACCT TO EXTRACT-TERM-GROUP            
              MOVE GR-ACCOUNT   OF GWCORGRACCT TO EXTRACT-TERM-ACCOUNT          
              PERFORM 830-WRITE-EXTRACT-FILE.                                   
       830-WRITE-EXTRACT-FILE.                                                  
           CALL 'DLSWRITE' USING DLS026-SYSNUM                                  
                                 DLS026-RETURN                                  
                                 EXTRACT-TERM-FILE                              
                                 DLS026-REC-SIZE                                
                                 DLS026-BLK-SIZE                                
                                 DLS026-FORMAT                                  
                                 DLS026-REC-COUNT.                              
                                                                                
           IF  DLS026-RETURN = +0                                               
                          OR +4                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS026' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       WTL-TO-OPERATOR.                                                         
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           CALL 'WTL' USING WTL-MESSAGE-AREA                                    
                            WTL-FLAG                                            
                            WTL-REPLY                                           
                            WTL-REPLY-AREA.                                     
       WTL-TO-OPERATOR-EXIT.                                                    
           EXIT.                                                                
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
