       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    VOMAPPE7.                                                 
      *AUTHOR.        F. DAZA.                                                  
      *DATE-WRITTEN.  APR 2005.                                                 
      *DATE-COMPILED.                                                           
      *============================================================*            
      *                                                                         
      *    VO DATA MAPPER- THIS PROGRAM WILL CONVERT A VO MASTER                
      *                    RECORD TO ANOTHER FORMAT/LAYOUT                      
      *                    AS REQUESTED BY THE CALLING PROGRAM.                 
      *------------------------------------------------------------*            
      * APR/05 F DAZA      - CREATED                                            
      * JUN/06 J SASSO     - CHANGED LINK FILE                                  
      * AUG/06 F MUELLER   - FIX POSTAL CODE IN CONDENSED ADDRESS               
      * SEP/06 D VOLL      - MAP VST IF ANY PREMIUMS EXIST                      
65242 * OCT/06 W ROSS      - TREAT 99991231 IN VGI-CLAIMS-SUSPENDED             
65242 *                      AS A ZERO DATE                                     
      * APR/07 S CARLYLE   - TASK # 72602 - FIX ADDRESS MAPPING                 
      * JUL/08 IBM GR      - UPGRADED IN ECU PROJECT                            
      * MAR/10 E IVETAC    - TL 129742                                          
      * NOV/10 IDMSDB2     - IDMS TO DB2 CONVERSION PROJECT                     
      *                    - CREATED FOR 7-DIGIT GIPSY GROUP NUMBER             
      * MAY/13 L INBARAJ   - GROUP NUMBER EXPANSION PROJECT                     
      *------------------------------------------------------------*            
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                 PIC X(16) VALUE 'VOMAPPE7 START=>'.         
                                                                                
       01  WS-INDEX-FIELDS.                                                     
           05  X1           COMP    PIC S9(04).                                 
           05  X2           COMP    PIC S9(04).                                 
           05  X3           COMP    PIC S9(04).                                 
                                                                                
      *01  GNA-NAME-ADDRESS                                                     
           COPY GMNADTRX.                                                       
                                                                                
129742 01  WS-BAD-POSTAL-SW                PIC X(01).                           
129742     88 WS-BAD-POSTAL-Y              VALUE 'Y'.                           
129742     88 WS-BAD-POSTAL-N              VALUE 'N'.                           
129742 01  WS-POSTAL-CODE.                                                      
129742     05 WS-POSTAL-CODE-DIGITS        PIC X(06).                           
129742     05 WS-POSTAL-CODE-DIGITS-REDEF REDEFINES                             
129742        WS-POSTAL-CODE-DIGITS                                             
129742     OCCURS 6 TIMES                  PIC X(01).                           
                                                                                
       01  WS-WORK-CITY-PROV-LINES.                                             
           05  WS-WK-CITY-PROV             PIC X(30).                           
65242                                                                           
65242  01  WS-DATE-FIELDS.                                                      
65242      05  WS-HIGH-DATE                PIC X(08) VALUE '99991231'.          
65242      05  WS-LOW-DATE                 PIC X(08) VALUE '00010101'.          
           05  DUMMY-DATE       COMP-3     PIC S9(7) VALUE +0080107.            
                                                                                
      * CHARACTER TRANSLATION STRINGS                                           
       COPY VOMAPCTN.                                                           
                                                                                
       01  WS-VO-NAME-ADDRESS.                                                  
           05  WS-VO-POSTAL-CODE           PIC X(06).                           
           05  WS-VO-NAME                  PIC X(30).                           
           05  WS-VO-ADDRESS         OCCURS 5 TIMES.                            
               10 WS-VO-ADDRESS-LINE       PIC X(30).                           
           05  WS-VO-PARSED-ADDRESS.                                            
               10 WS-VO-ADDRESS-TYPE-CD    PIC 9(02).                           
               10 WS-VO-CONFIDENTIAL-FLG   PIC X(01).                           
               10 WS-VO-ADDRESS-NM         PIC X(50).                           
               10 WS-VO-CONTACT-NM         PIC X(30).                           
               10 WS-VO-ADDITIONAL-ADDR-NM PIC X(40).                           
               10 WS-VO-STREET-ADDRESS-NM  PIC X(40).                           
               10 WS-VO-SUITE-NM           PIC X(30).                           
               10 WS-VO-CITY-NM            PIC X(30).                           
               10 WS-VO-PROVINCE           PIC X(02).                           
               10 WS-VO-POSTAL-NUM         PIC X(15).                           
               10 WS-VO-COUNTRY            PIC X(03).                           
       01  WS-ADDRESS-FIELDS.                                                   
           05  WS-NAME-ADDRESS.                                                 
               10  WS-NAD-LINE          PIC X(31) OCCURS 6 TIMES.               
           05  WS-NAME-ADDRESS-CONV     PIC X(186).                             
           05  WS-NAME-ADDRESS-CONV-REDEF REDEFINES                             
               WS-NAME-ADDRESS-CONV OCCURS 6 TIMES.                             
               10 WS-NAME               PIC X(30).                              
               10 WS-DEL                PIC X(01).                              
           05  WS-NAD-WRK-LINE          PIC X(31).                              
           05  WS-NAD-POINTERS.                                                 
               10 NAD-L           COMP  PIC S9(04).                             
               10 NAD-CH          COMP  PIC S9(04).                             
               10 NAD-PTR         COMP  PIC S9(04).                             
               10 NAD-PTR2        COMP  PIC S9(04).                             
               10 NAD-EOL         COMP  PIC S9(04).                             
           05  WS-CITY-FIELDS.                                                  
               10 CTY-LINE              PIC X(30).                              
               10 CTY-NAM-LENGTH  COMP  PIC S9(04).                             
               10 CTY-OTH-LENGTH  COMP  PIC S9(04).                             
               10 CTY-PTR         COMP  PIC S9(04).                             
               10 CTY-PTR2        COMP  PIC S9(04).                             
               10 CTY-EOL         COMP  PIC S9(04).                             
           05  WS-LONGNAME-IND          PIC X(01)  VALUE 'N'.                   
               88 WS-LONGNAME                      VALUE 'L'.                   
               88 WS-NOT-A-LONGNAME                VALUE 'N'.                   
                                                                                
       01  CALLED-PROGRAMS.                                                     
           05  GC2DATE                  PIC X(08)  VALUE 'GC2DATE'.             
           05  CGC2DATE                 PIC X(08)  VALUE 'CGC2DATE'.            
                                                                                
       01  FILLER                       PIC X(10)  VALUE '*GMASTER7*'.          
           COPY GMASTER7.                                                       
                                                                                
       01  FILLER                       PIC X(09)  VALUE '*VMASTER*'.           
                                                                                
      *01  VMASTER.              <<< INCLUDED IN COPYBOOK                       
           COPY VMASTER.                                                        
      *01  VMASTER.                                                             
      *    05  FILLER PIC X(1) VALUE LOW-VALUES.                                
      *    COPY VMASTER REPLACING ==01  VMASTER.== BY ====.                     
                                                                                
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
                                                                                
       01  WS-END                   PIC X(16) VALUE '<===END VOMAPPE7'.         
      *---------------------------------------------------------------          
       LINKAGE SECTION.                                                         
       01  VOMAPPE7-PROTOCOL.           COPY VOMAPCIO.                          
                                                                                
       PROCEDURE DIVISION USING VOMAPPE7-PROTOCOL.                              
                                                                                
       MAINLINE.                                                                
      *============================================================*            
      *  MAINLINE ROUTINE                                                       
      *------------------------------------------------------------*            
                                                                                
           INITIALIZE VOMAPPER-OUTPUT                                           
           EVALUATE TRUE                                                        
              WHEN VOMI-LR-GIPSY-EXP                                            
      *       WHEN VOMI-LR-GIPSY-EXP-I                                          
              WHEN VOMI-LR-GIPSY-EXP-C                                          
                   PERFORM 1001-GIPSY-FORMAT THRU 1001-EXIT                     
              WHEN VOMI-LR-VO-RAW                                               
              WHEN VOMI-LR-DEFAULT                                              
                   PERFORM 2001-VO-FORMAT    THRU 2001-EXIT                     
              WHEN OTHER                                                        
                   MOVE '99' TO VOMO-RET-CODE                                   
                   MOVE 'LR NAME INVALID OR NOT DEFINED'                        
                     TO VOMO-RET-MESSAGE                                        
           END-EVALUATE.                                                        
       MAINLINE-EXIT.                                                           
           GOBACK.                                                              
                                                                                
                                                                                
       1001-GIPSY-FORMAT.                                                       
      *============================================================*            
      *  FORMAT VO RECORD AS PER GIPSY FORMAT                                   
      *------------------------------------------------------------*            
      *****************************************************************         
      *         GENERAL INFORMATION                                   *         
      *****************************************************************         
           MOVE VOMI-VO-RECORD TO VMASTER                                       
           INITIALIZE GMASTER7                                                  
           MOVE VGI-POLICY-NUM            TO GGIGROUP-NUMBER                    
           MOVE VGI-LOCATION-NUM          TO GGIACCOUNT                         
           MOVE VGI-MASTER-IDENT          TO GGIMASTER-IDENT                    
           MOVE 'M'                       TO GGIMASTER-IDENT                    
           MOVE VGI-IDENTITY              TO GGIIDENTITY                        
           MOVE VGI-BRANCH                TO GGIBRANCH                          
           MOVE VGI-GROUP-REP             TO GGIGROUP-REP                       
           MOVE VGI-GROUP-REP2            TO GGIGROUP-REP2                      
           MOVE VGI-GROUP-OFFICE          TO GGIGROUP-OFFICE                    
           MOVE VGI-SHARING-OFFICE        TO GGISHARING-OFFICE                  
           MOVE VGI-CLAIMS-OFFICE         TO GGICLAIMS-OFFICE                   
           MOVE VGI-COUNTRY               TO GGICOUNTRY                         
           MOVE VGI-CURRENCY              TO GGICURRENCY                        
           MOVE VGI-RESIDENCE             TO GGIRESIDENCE                       
           MOVE VGI-LANGUAGE              TO GGILANGUAGE                        
           MOVE VGI-PRODUCT-CODE          TO GGIPRODUCT-CODE                    
           MOVE VGI-POLICY-ACCT           TO GGIPOLICY-ACCT                     
           MOVE VGI-ACCT-TYPE             TO GGIACCT-TYPE.                      
           MOVE VGI-COVERAGE-CODE         TO GGICOVERAGE-CODE                   
           MOVE VGI-BENEFIT-SEL           TO GGIBENEFIT-SEL                     
           MOVE VGI-STD-IND-CLASS-CODE    TO GGISTD-IND-CLASS-CODE              
           MOVE VGI-CONTRIBUTION          TO GGICONTRIBUTION                    
           MOVE VGI-BENEFIT-LINK          TO GGIBENEFIT-LINK                    
           MOVE VGI-TAX                   TO GGITAX                             
           MOVE VGI-WITHHOLDING           TO GGIWITHHOLDING                     
           MOVE VGI-EMPLOYEE-LIST         TO GGIEMPLOYEE-LIST                   
           MOVE VGI-HANDLING-CODE         TO GGIHANDLING-CODE                   
           MOVE VGI-ARREARS-IND           TO GGIARREARS-IND                     
           MOVE VGI-ARREARS-COUNTER       TO GGIARREARS-COUNTER                 
           MOVE VGI-ARREARS-STATUS        TO GGIARREARS-STATUS                  
           MOVE VGI-RED-AGE-LIFE          TO GGIRED-AGE-LIFE                    
           MOVE VGI-RED-AGE-LTD           TO GGIRED-AGE-LTD                     
           MOVE VGI-RED-AGE-AD-D          TO GGIRED-AGE-AD-D                    
           MOVE VGI-RED-AGE-MEDICAL       TO GGIRED-AGE-MEDICAL                 
           MOVE VGI-RED-AGE-DENTAL        TO GGIRED-AGE-DENTAL                  
           MOVE VGI-RED-AGE-WI            TO GGIRED-AGE-WEEK-INDEM              
           MOVE VGI-TERM-AGE-LIFE         TO GGITERM-AGE-LIFE                   
           MOVE VGI-TERM-AGE-LTD          TO GGITERM-AGE-LTD                    
           MOVE VGI-TERM-AGE-AD-D         TO GGITERM-AGE-AD-D                   
           MOVE VGI-TERM-WAIT-PERIOD-LTD  TO GGITERM-WAIT-PERIOD-LTD            
           MOVE VGI-TERM-AGE-MEDICAL      TO GGITERM-AGE-MEDICAL                
           MOVE VGI-TERM-AGE-DENTAL       TO GGITERM-AGE-DENTAL                 
           MOVE VGI-TERM-AGE-WI           TO GGITERM-AGE-WEEK-INDEM             
           MOVE VGI-STEP-DOWN             TO GGISTEP-DOWN                       
           MOVE VGI-CHANGE-DATE           TO GGICHANGE-DATE                     
           MOVE VGI-ACCOUNT-STATUS        TO GGIACCOUNT-STATUS                  
                                                                                
           MOVE VGI-NEXT-ANNIVERSARY      TO VDATE1-YYYYMMDD                    
           PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                     
           MOVE VDATE-ALIS-DATE1          TO GGINEXT-ANNIVERSARY                
65242                                                                           
65242      IF VGI-CLAIMS-SUSPENDED = WS-HIGH-DATE                               
65242         MOVE WS-LOW-DATE            TO VDATE1-YYYYMMDD                    
65242      ELSE                                                                 
65242         MOVE VGI-CLAIMS-SUSPENDED   TO VDATE1-YYYYMMDD                    
65242      END-IF                                                               
           PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                     
           MOVE VDATE-ALIS-DATE1          TO GGICLAIMS-SUSPENDED                
65242                                                                           
           MOVE VGI-CONTRACT-ISSUE        TO VDATE1-YYYYMMDD                    
           PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                     
           MOVE VDATE-ALIS-DATE1          TO GGICONTRACT-ISSUE                  
           MOVE VGI-ACCT-EFFECTIVE        TO VDATE1-YYYYMMDD                    
           PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                     
           MOVE VDATE-ALIS-DATE1          TO GGI-ACCT-EFFECTIVE                 
           MOVE VGI-PAID-TO-DATE          TO VDATE1-YYYYMMDD                    
           PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                     
           MOVE VDATE-ALIS-DATE1          TO GGIPAID-TO-DATE                    
           MOVE VGI-LAST-CHANGE-DATE      TO VDATE1-YYYYMMDD                    
           PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                     
           MOVE VDATE-ALIS-DATE1          TO GGILAST-CHANGE-DATE                
           MOVE VGI-LAST-ACCOUNTING-DATE  TO VDATE1-YYYYMMDD                    
           PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                     
           MOVE VDATE-ALIS-DATE1          TO GGILAST-ACCOUNTING-DATE            
           MOVE VGI-POL-ARREARS           TO GGIPOL-ARREARS                     
           MOVE VGI-CASHFLOW-LST-POL-YR   TO GGICASHFLOW-LST-POL-YR             
           MOVE VGI-CASHFLOW-CURR-POL-YR  TO GGICASHFLOW-CURR-POL-YR            
           MOVE VGI-BILL-STAT-FORMAT      TO GGIBILL-STAT-FORMAT                
                                                                                
                                                                                
                                                                                
           MOVE VGI-CLAIMS-INFORMATION    TO GGICLAIMS-INFORMATION              
                                                                                
           PERFORM VARYING X1 FROM 1 BY 1 UNTIL X1 > 6                          
             MOVE VGI-FOGL-CODE(X1)                                             
                                          TO GGIFOGL-CODE(X1)                   
             MOVE VGI-FUND-TYPE(X1)                                             
                                          TO GGIFUND-TYPE(X1)                   
           END-PERFORM                                                          
                                                                                
           MOVE VGI-BILLING-OVERIDE       TO GGIBILLING-OVERIDE                 
           MOVE VGI-PH-EOB                TO GGIPH-EOB                          
           MOVE VGI-ADMIN-AREA            TO GGIADMIN-AREA                      
           MOVE VGI-LIVES-RANGE           TO GGILIVES-RANGE                     
           MOVE VGI-MAIL-INSTRUCTION      TO GGIMAIL-INSTRUCTION                
           MOVE VGI-UNDEFINED             TO GGIUNDEFINED                       
           IF  VST-PREM-LIFE         > 0                                        
            OR VST-PREM-LTD          > 0                                        
            OR VST-PREM-AD-D         > 0                                        
            OR VST-PREM-WI           > 0                                        
            OR VST-PREM-EHC-SINGLE   > 0                                        
            OR VST-PREM-EHC-FAMILY1  > 0                                        
            OR VST-PREM-EHC-FAMILY2  > 0                                        
            OR VST-PREM-DEN-SINGLE   > 0                                        
            OR VST-PREM-DEN-FAMILY1  > 0                                        
            OR VST-PREM-DEN-FAMILY2  > 0 THEN                                   
               MOVE '010'                     TO GSTTRIDENT                     
               MOVE 379                       TO GSTLENGTH                      
               MOVE VST-PAID-IND              TO GSTPAID-IND                    
               MOVE VST-OUT-LIFE              TO GSTOUT-LIFE                    
               MOVE VST-OUT-LTD               TO GSTOUT-LTD                     
               MOVE VST-OUT-A-S               TO GSTOUT-A-S                     
               MOVE VST-OUT-ADMIN-FEE         TO GSTOUT-ADMIN-FEE               
               MOVE VST-PREMIUM-IND           TO GSTPREMIUM-IND                 
               MOVE VST-ADVANCE               TO GSTADVANCE                     
               MOVE VST-CAL-YTD-LI-BILLED     TO GSTCAL-YTD-LI-BILLED           
               MOVE VST-CAL-YTD-LI-PAID       TO GSTCAL-YTD-LI-PAID             
               MOVE VST-CAL-YTD-AS-BILLED     TO GSTCAL-YTD-AS-BILLED           
               MOVE VST-CAL-YTD-AS-PAID       TO GSTCAL-YTD-AS-PAID             
               MOVE VST-CAL-YTD-LTD-BILLED    TO GSTCAL-YTD-LTD-BILLED          
               MOVE VST-CAL-YTD-LTD-PAID      TO GSTCAL-YTD-LTD-PAID            
               MOVE VST-CAL-YTD-ADMIN-FEE-BILLED                                
                 TO  GSTCAL-YTD-ADMIN-FEE-BILLED                                
               MOVE VST-CAL-YTD-ADMIN-FEE-PAID                                  
                 TO  GSTCAL-YTD-ADMIN-FEE-PAID                                  
               MOVE VST-PREM-LIFE             TO GSTPREM-LIFE                   
               MOVE VST-PREM-LTD              TO GSTPREM-LTD                    
               MOVE VST-PREM-AD-D             TO GSTPREM-AD-D                   
               MOVE VST-PREM-WI               TO GSTPREM-WI                     
               MOVE VST-PREM-EHC-SINGLE       TO GSTPREM-EHC-SINGLE             
               MOVE VST-PREM-EHC-FAMILY1      TO GSTPREM-EHC-FAMILY1            
               MOVE VST-PREM-EHC-FAMILY2      TO GSTPREM-EHC-FAMILY2            
               MOVE VST-PREM-DEN-SINGLE       TO GSTPREM-DEN-SINGLE             
               MOVE VST-PREM-DEN-FAMILY1      TO GSTPREM-DEN-FAMILY1            
               MOVE VST-PREM-DEN-FAMILY2      TO GSTPREM-DEN-FAMILY2            
               MOVE VST-PREM-ADJ-LIFE         TO GSTPREM-ADJ-LIFE               
               MOVE VST-PREM-ADJ-LTD          TO GSTPREM-ADJ-LTD                
               MOVE VST-PREM-ADJ-AD-D         TO GSTPREM-ADJ-AD-D               
               MOVE VST-PREM-ADJ-WI           TO GSTPREM-ADJ-WI                 
               MOVE VST-PREM-ADJ-EHC-SINGLE                                     
                 TO  GSTPREM-ADJ-EHC-SINGLE                                     
               MOVE VST-PREM-ADJ-EHC-FAMILY1                                    
                 TO  GSTPREM-ADJ-EHC-FAMILY1                                    
               MOVE VST-PREM-ADJ-EHC-FAMILY2                                    
                 TO  GSTPREM-ADJ-EHC-FAMILY2                                    
               MOVE VST-PREM-ADJ-DEN-SINGLE                                     
                 TO  GSTPREM-ADJ-DEN-SINGLE                                     
               MOVE VST-PREM-ADJ-DEN-FAMILY1                                    
                 TO  GSTPREM-ADJ-DEN-FAMILY1                                    
               MOVE VST-PREM-ADJ-DEN-FAMILY2                                    
                 TO  GSTPREM-ADJ-DEN-FAMILY2                                    
               MOVE VST-PROJ-LR-PREV-POLYR    TO GSTPROJ-LR-PREV-POLYR          
               MOVE VST-PROJ-LR-CURR-POLYR    TO GSTPROJ-LR-CURR-POLYR          
               MOVE VST-ACCEPT-LOSS-PREV      TO GSTACCEPT-LOSS-PREV            
               MOVE VST-PART                  TO GSTPART                        
               MOVE VST-NON-PART              TO GSTNON-PART                    
               MOVE VST-UNDEFINED             TO GSTUNDEFINED                   
               MOVE VST-NUM-COV-CODES         TO GSTNUM-COV-CODES               
               PERFORM VARYING X1 FROM 1 BY 1     UNTIL X1 > 15                 
                 MOVE VST-STAT-COV-CODE  (X1) TO GSTSTAT-COV-CODE  (X1)         
                 MOVE VST-STAT-VOL       (X1) TO GSTSTAT-VOL       (X1)         
                 MOVE VST-STAT-LIVES     (X1) TO GSTSTAT-LIVES     (X1)         
               END-PERFORM                                                      
           END-IF                                                               
           IF VBN-BILLING-NAME NOT = SPACES THEN                                
             MOVE '030'                       TO GBNTRIDENT                     
             MOVE 218                         TO GBNLENGTH                      
129742       MOVE VBN-POSTAL-CODE          TO WS-POSTAL-CODE-DIGITS             
129742       PERFORM 1010-VALIDATE-POSTAL                                       
129742          THRU 1010-VALIDATE-POSTAL-X                                     
129742       MOVE WS-POSTAL-CODE-DIGITS       TO GBNPOST-CODE                   
129742                                           WS-VO-POSTAL-CODE              
129742*      MOVE VBN-POSTAL-CODE             TO GBNPOST-CODE                   
             MOVE VBN-NAAD-PROC-DATE          TO VDATE1-YYYYMMDD                
             PERFORM 5000-CONVERT-TO-ALIS-DATE                                  
             MOVE VDATE-ALIS-DATE1            TO GBN-NAAD-PROC-DATE             
                                                                                
129742*      MOVE VBN-POSTAL-CODE             TO WS-VO-POSTAL-CODE              
             MOVE VBN-BILLING-NAME            TO WS-VO-NAME                     
             MOVE VBN-ADDRESS-LINE(1)         TO WS-VO-ADDRESS-LINE(1)          
             MOVE VBN-ADDRESS-LINE(2)         TO WS-VO-ADDRESS-LINE(2)          
             MOVE VBN-ADDRESS-LINE(3)         TO WS-VO-ADDRESS-LINE(3)          
             MOVE VBN-ADDRESS-LINE(4)         TO WS-VO-ADDRESS-LINE(4)          
             MOVE VBN-ADDRESS-LINE(5)         TO WS-VO-ADDRESS-LINE(5)          
             MOVE VBN-PARSED-BILLING-ADDRESS  TO WS-VO-PARSED-ADDRESS           
             PERFORM 4500-CONVERT-NAME-ADDRESS THRU 4500-EXIT                   
             MOVE WS-NAME-ADDRESS-CONV        TO GBNBILL-NAME-ADDR              
           END-IF                                                               
           IF VCN-CLAIMS-NAME  NOT = SPACES THEN                                
             MOVE '040'                       TO GCNTRIDENT                     
             MOVE 218                         TO GCNLENGTH                      
129742       MOVE VCN-POSTAL-CODE          TO WS-POSTAL-CODE-DIGITS             
129742       PERFORM 1010-VALIDATE-POSTAL                                       
129742          THRU 1010-VALIDATE-POSTAL-X                                     
129742       MOVE WS-POSTAL-CODE-DIGITS       TO GCNPOST-CODE                   
129742                                           WS-VO-POSTAL-CODE              
                                                                                
129742*      MOVE VCN-POSTAL-CODE             TO GCNPOST-CODE                   
129742*                                          WS-VO-POSTAL-CODE              
             MOVE VCN-CLAIMS-NAME             TO WS-VO-NAME                     
             MOVE VCN-ADDRESS-LINE(1)         TO WS-VO-ADDRESS-LINE(1)          
             MOVE VCN-ADDRESS-LINE(2)         TO WS-VO-ADDRESS-LINE(2)          
             MOVE VCN-ADDRESS-LINE(3)         TO WS-VO-ADDRESS-LINE(3)          
             MOVE VCN-ADDRESS-LINE(4)         TO WS-VO-ADDRESS-LINE(4)          
             MOVE VCN-ADDRESS-LINE(5)         TO WS-VO-ADDRESS-LINE(5)          
             MOVE VCN-PARSED-CLAIMS-ADDRESS   TO WS-VO-PARSED-ADDRESS           
             PERFORM 4500-CONVERT-NAME-ADDRESS THRU 4500-EXIT                   
             MOVE WS-NAME-ADDRESS-CONV        TO GCNCL-NAME-ADDR                
                                                                                
           END-IF                                                               
           IF VON-OTHER-NAME   NOT = SPACES THEN                                
             MOVE '045'                       TO GONTRIDENT                     
             MOVE 218                         TO GONLENGTH                      
             MOVE VON-IDENT                   TO GONIDENT                       
129742       MOVE VON-POSTAL-CODE          TO WS-POSTAL-CODE-DIGITS             
129742       PERFORM 1010-VALIDATE-POSTAL                                       
129742          THRU 1010-VALIDATE-POSTAL-X                                     
129742       MOVE WS-POSTAL-CODE-DIGITS       TO GONPOST-CODE                   
129742                                           WS-VO-POSTAL-CODE              
129742*      MOVE VON-POSTAL-CODE             TO GONPOST-CODE                   
129742*                                          WS-VO-POSTAL-CODE              
             MOVE VON-OTHER-NAME              TO WS-VO-NAME                     
             MOVE VON-ADDRESS-LINE(1)         TO WS-VO-ADDRESS-LINE(1)          
             MOVE VON-ADDRESS-LINE(2)         TO WS-VO-ADDRESS-LINE(2)          
             MOVE VON-ADDRESS-LINE(3)         TO WS-VO-ADDRESS-LINE(3)          
             MOVE VON-ADDRESS-LINE(4)         TO WS-VO-ADDRESS-LINE(4)          
             MOVE VON-ADDRESS-LINE(5)         TO WS-VO-ADDRESS-LINE(5)          
             MOVE VON-PARSED-OTHER-ADDRESS    TO WS-VO-PARSED-ADDRESS           
             PERFORM 4500-CONVERT-NAME-ADDRESS THRU 4500-EXIT                   
             MOVE WS-NAME-ADDRESS-CONV        TO GONOTHER-NAME-ADDR             
           END-IF                                                               
                                                                                
           IF VPS-START-DATE (1) > '19000101' THEN                              
             MOVE '100'                       TO GPSTRIDENT                     
             MOVE 436                         TO GPSLENGTH                      
             PERFORM VARYING X1 FROM 1 BY 1     UNTIL X1 > 10                   
               MOVE VPS-CODE             (X1) TO GPSCODE           (X1)         
               MOVE VPS-START-DATE       (X1) TO VDATE1-YYYYMMDD                
               PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                 
               MOVE VDATE-ALIS-DATE1          TO GPSTART-DATE      (X1)         
                                                                                
               MOVE VPS-STOP-DATE        (X1) TO VDATE1-YYYYMMDD                
               PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                 
               MOVE VDATE-ALIS-DATE1          TO GPSSTOP-DATE      (X1)         
                                                                                
               MOVE VPS-FRST-LIFE        (X1) TO GPSFRST-LIFE      (X1)         
               MOVE VPS-FRST-LTD         (X1) TO GPSFRST-LTD       (X1)         
               MOVE VPS-FRST-A-S         (X1) TO GPSFRST-A-S       (X1)         
                                                                                
             END-PERFORM                                                        
           END-IF                                                               
                                                                                
           PERFORM VARYING X1 FROM 1 BY 1     UNTIL X1 > 4                      
             IF VAG-AGENT-BRANCH (1) > '00000' THEN                             
               MOVE '110'                     TO GAGTRIDENT        (X1)         
               MOVE 494                       TO GAGLENGTH         (X1)         
               MOVE VAG-AGENT-CODE       (X1) TO GAGAGENT-CODE     (X1)         
               MOVE VAG-ACCOUNT          (X1) TO GAGACCOUNT        (X1)         
               MOVE VAG-AGENT-BRANCH     (X1) TO GAGAGENT-BRANCH   (X1)         
               MOVE VAG-RENEW-COMM-PD    (X1) TO GAGRENEW-COMM-PD  (X1)         
               MOVE VAG-RENEW-COMM-EARN  (X1) TO GAGRENEW-COMM-EARN(X1)         
               MOVE VAG-SALES-CRED-PD    (X1) TO GAGSALES-CRED-PD  (X1)         
               MOVE VAG-SALES-CRED-EARN  (X1) TO GAGSALES-CRED-EARN(X1)         
               MOVE VAG-CASE-CNT-PD      (X1) TO GAGCASE-CNT-PD    (X1)         
               MOVE VAG-CASE-CNT-EARN    (X1) TO GAGCASE-CNT-EARN  (X1)         
               MOVE VAG-NAP-PAID1        (X1) TO GAGNAP-PAID1      (X1)         
               MOVE VAG-NAP-EARNED1      (X1) TO GAGNAP-EARNED1    (X1)         
               MOVE VAG-NAP-PAID2        (X1) TO GAGNAP-PAID2      (X1)         
               MOVE VAG-NAP-EARNED2      (X1) TO GAGNAP-EARNED2    (X1)         
               MOVE VAG-PAYMENT-TYPE     (X1) TO GAGPAYMENT-TYPE   (X1)         
               MOVE VAG-CANN-COUNTER     (X1) TO GAGCANN-COUNTER   (X1)         
               MOVE VAG-PERCENT-DEFER    (X1) TO GAGPERCENT-DEFER  (X1)         
               MOVE VAG-ANNUALIZED-PAID  (X1) TO GAGANNUALIZED-PAID(X1)         
               MOVE VAG-ANNUALIZED-EARN  (X1) TO GAGANNUALIZED-EARN(X1)         
               PERFORM VARYING X2 FROM 1 BY 1   UNTIL X2 > 5                    
                 MOVE VAG-COMM-IND       (X1, X2)                               
                   TO  GAGCOMM-IND       (X1, X2)                               
                 MOVE VAG-START-DATE     (X1, X2) TO VDATE1-YYYYMMDD            
                 PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT               
                 MOVE VDATE-ALIS-DATE1                                          
                   TO  GAGSTART-DATE     (X1, X2)                               
                                                                                
                 MOVE VAG-STOP-DATE      (X1, X2) TO VDATE1-YYYYMMDD            
                 PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT               
                 MOVE VDATE-ALIS-DATE1                                          
                   TO  GAGSTOP-DATE      (X1, X2)                               
                 MOVE VAG-FRST-LIFE      (X1, X2)                               
                   TO  GAGFRST-LIFE      (X1, X2)                               
                 MOVE VAG-FRST-LTD       (X1, X2)                               
                   TO  GAGFRST-LTD       (X1, X2)                               
                 MOVE VAG-FRST-A-S       (X1, X2)                               
                   TO  GAGFRST-A-S       (X1, X2)                               
                 MOVE VAG-FRST-ADMIN-FEE (X1, X2)                               
                   TO  GAGFRST-ADMIN-FEE (X1, X2)                               
                 MOVE VAG-REN-LIFE       (X1, X2)                               
                   TO  GAGREN-LIFE       (X1, X2)                               
                 MOVE VAG-REN-LTD        (X1, X2)                               
                   TO  GAGREN-LTD        (X1, X2)                               
                 MOVE VAG-REN-A-S        (X1, X2)                               
                   TO  GAGREN-A-S        (X1, X2)                               
                 MOVE VAG-REN-ADMIN-FEE  (X1, X2)                               
                   TO  GAGREN-ADMIN-FEE  (X1, X2)                               
                 MOVE VAG-SCALE          (X1, X2)                               
                   TO  GAGSCALE          (X1, X2)                               
                 MOVE VAG-LTD-SCALE      (X1, X2)                               
                   TO  GAGLTD-SCALE      (X1, X2)                               
                 MOVE VAG-FLAT-RATE      (X1, X2)                               
                   TO  GAGFLAT-RATE      (X1, X2)                               
                 MOVE VAG-LTD-FLAT-RATE  (X1, X2)                               
                   TO  GAGLTD-FLAT-RATE  (X1, X2)                               
                 MOVE VAG-POINT          (X1, X2)                               
                   TO  GAGPOINT          (X1, X2)                               
               END-PERFORM                                                      
             END-IF                                                             
           END-PERFORM                                                          
                                                                                
           IF VTM-EFFECTIVE-DATE (1) > '19000101' THEN                          
             MOVE '130'                       TO GTMTRIDENT                     
             MOVE 116                         TO GTMLENGTH                      
             PERFORM VARYING X1 FROM 1 BY 1     UNTIL X1 > 5                    
               MOVE VTM-EFFECTIVE-DATE   (X1) TO VDATE1-YYYYMMDD                
               PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                 
               MOVE VDATE-ALIS-DATE1          TO GTMEFFECTIVE-DATE (X1)         
               MOVE VTM-PROCESSED-DATE   (X1) TO VDATE1-YYYYMMDD                
               PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                 
               MOVE VDATE-ALIS-DATE1          TO GTMPROCESSED-DATE (X1)         
               MOVE VTM-PURGE-DATE       (X1) TO VDATE1-YYYYMMDD                
               PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                 
               MOVE VDATE-ALIS-DATE1          TO GTMPURGE-DATE     (X1)         
               MOVE VTM-CODE             (X1) TO GTMCODE           (X1)         
               MOVE VTM-REIN-DATE        (X1) TO VDATE1-YYYYMMDD                
               PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                 
               MOVE VDATE-ALIS-DATE1          TO GTMREIN-DATE      (X1)         
               MOVE VTM-REIN-CODE        (X1) TO GTMREIN-CODE      (X1)         
             END-PERFORM                                                        
           END-IF                                                               
                                                                                
           IF VBI-DUE-DATE > '19000101' THEN                                    
             MOVE '080'                       TO GBITRIDENT                     
             MOVE 4432                        TO GBILENGTH                      
             MOVE '150'                       TO GTX-TRIDENT                    
             MOVE 2602                        TO GTX-LENGTH                     
             MOVE VBI-DUE-DATE                TO VDATE1-YYYYMMDD                
             PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                   
             MOVE VDATE-ALIS-DATE1            TO GBIDUE-DATE                    
             MOVE VBI-LIFE                    TO GBILIFE                        
             MOVE VBI-LTD                     TO GBILTD                         
             MOVE VBI-A-S                     TO GBIA-S                         
             MOVE VBI-ADMIN-FEE               TO GBIADMIN-FEE                   
             MOVE VBI-POSITION                TO GBIPOSITION                    
             PERFORM VARYING X1 FROM 1 BY 1     UNTIL X1 > 13                   
               MOVE VBI-TAX-CODE         (X1) TO GTX-OUTST-TAX-CODE(X1)         
               MOVE VBI-TAX-AMT          (X1) TO GTX-OUTST-TAX-AMT (X1)         
             END-PERFORM                                                        
             MOVE VBI-HISTORY-CNT             TO GBINO-HIST-SEG                 
             PERFORM VARYING X1 FROM 1 BY 1     UNTIL X1 > 25                   
               MOVE VBI-HIST-DUE-DATE    (X1) TO VDATE1-YYYYMMDD                
               PERFORM 5000-CONVERT-TO-ALIS-DATE THRU 5000-EXIT                 
               MOVE VDATE-ALIS-DATE1          TO GBIHIST-DUE-DATE  (X1)         
               MOVE VBI-HIST-PREPARED-DATE (X1) TO VDATE1-YYYYMMDD              
               PERFORM 5000-CONVERT-TO-ALIS-DATE                                
               MOVE VDATE-ALIS-DATE1                                            
                 TO  GBIHIST-PREPARED-DATE(X1)                                  
               MOVE VBI-PREM-DUE         (X1) TO GBI-PREM-DUE      (X1)         
               MOVE VBI-CERT-HOLDERS     (X1) TO GBICERT-HOLDERS   (X1)         
               MOVE VBI-HIST-ADMIN-FEE   (X1) TO GBIHIST-ADMIN-FEE (X1)         
               MOVE VBI-NO-COV-LINES     (X1) TO GBINO-COV-LINES   (X1)         
               PERFORM VARYING X2 FROM 1 BY 1   UNTIL X2 > 10                   
                 MOVE VBI-COV-CODE       (X1, X2)                               
                   TO GBICOV-CODE        (X1, X2)                               
                 MOVE VBI-AMT-BILLED     (X1, X2)                               
                   TO GBIAMT-BILLED      (X1, X2)                               
                 MOVE VBI-NO-LIVES       (X1, X2)                               
                   TO GBINO-LIVES        (X1, X2)                               
                 MOVE VBI-VOL            (X1, X2)                               
                   TO GBIVOL             (X1, X2)                               
               END-PERFORM                                                      
               PERFORM VARYING X2 FROM 1 BY 1 UNTIL X2 > 13                     
                 MOVE VBI-HIST-TAX-CODE  (X1, X2)                               
                   TO GTX-HIST-TAX-CODE  (X1, X2)                               
                 MOVE VBI-HIST-TAX-AMT   (X1, X2)                               
                   TO GTX-HIST-TAX-AMT   (X1, X2)                               
               END-PERFORM                                                      
             END-PERFORM                                                        
           END-IF                                                               
           MOVE GMASTER7                  TO VOMO-MAPPED-RECORD.                
           SET VOMO-RET-OK TO TRUE.                                             
       1001-EXIT.                                                               
           EXIT.                                                                
                                                                                
129742**************************************************************            
129742* VALIDATE POSTAL CODE - IF FORMAT NOT POSTAL CODE THEN                   
129742* INVALID, FORMAT IS:                                                     
129742* ALPHA,NUMBER,ALPHA,NUMBER,ALPHA,NUMBER                                  
129742**************************************************************            
129742*                                                                         
129742 1010-VALIDATE-POSTAL.                                                    
129742     MOVE 'N'                         TO WS-BAD-POSTAL-SW.                
129742     PERFORM VARYING X1 FROM 1 BY 1 UNTIL X1 > 6                          
129742     OR WS-BAD-POSTAL-Y                                                   
129742        IF X1 EQUAL 1 OR 3 OR 5                                           
129742           IF WS-POSTAL-CODE-DIGITS-REDEF (X1) NOT ALPHABETIC             
129742              MOVE 'Y'                TO WS-BAD-POSTAL-SW                 
129742           END-IF                                                         
129742        ELSE                                                              
129742           IF WS-POSTAL-CODE-DIGITS-REDEF (X1) NOT NUMERIC                
129742              MOVE 'Y'                TO WS-BAD-POSTAL-SW                 
129742           END-IF                                                         
129742        END-IF                                                            
129742     END-PERFORM.                                                         
129742*                                                                         
129742     IF WS-BAD-POSTAL-Y                                                   
129742        MOVE SPACES                TO WS-POSTAL-CODE-DIGITS               
129742     END-IF.                                                              
129742 1010-VALIDATE-POSTAL-X.                                                  
129742       EXIT.                                                              
                                                                                
       2001-VO-FORMAT.                                                          
      *============================================================*            
      *  FORMAT VO RECORD AS VO (STRAIGHT MOVE)                                 
      *------------------------------------------------------------*            
           MOVE VOMI-VO-RECORD TO VOMO-MAPPED-RECORD                            
           SET VOMO-RET-OK TO TRUE.                                             
       2001-EXIT.                                                               
           EXIT.                                                                
                                                                                
       5000-CONVERT-TO-ALIS-DATE.                                               
      *============================================================*            
      *  CONVERT FROM YYYYMMDD TO ALIS DATE (YYYDDD)                            
      *  (CALL THE APPROPIATE (IDMS OR BATCH) DATE ROUTINE)                     
      *------------------------------------------------------------*            
                                                                                
           MOVE 'B'                       TO VDATE-REQ-SERVICE                  
           MOVE 'B'                       TO VDATE-REQ-BASIS                    
           MOVE '1'                       TO VDATE-REQ-DETAIL                   
           MOVE 'E'                       TO VDATE-REQ-LANGUAGE                 
                                                                                
           IF VOMI-LR-GIPSY-EXP-C THEN                                          
               CALL CGC2DATE USING GAC-DATE-PARAMETERS DUMMY-DATE               
           ELSE                                                                 
               CALL GC2DATE  USING GAC-DATE-PARAMETERS                          
           END-IF                                                               
      *    CALL GC2DATE  USING GAC-DATE-PARAMETERS.                             
                                                                                
           IF NOT VDATE-RET-VALID THEN                                          
               MOVE 0 TO VDATE-ALIS-YEAR1                                       
                         VDATE-ALIS-DAY1                                        
           ELSE                                                                 
               CONTINUE                                                         
           END-IF.                                                              
                                                                                
       5000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       4500-CONVERT-NAME-ADDRESS.                                               
      *============================================================*            
      *  CONVERT THE NAME AND ADDRESS TO COMFORM WITH GIPSY FORMAT              
      * (PLENTY OF MANIPULATION BECAUSE VO DOESN'T PROVIDE THE ADDRESS          
      *  LINES AS IT SHOULD)                                                    
      *------------------------------------------------------------*            
           MOVE WS-VO-NAME                  TO WS-NAD-LINE(1).                  
                                                                                
      *-> FIGURE OUT IF WE ARE DEALING WITH A NAME THAT SPANS OVER              
      *-> TWO LINES SO WE CAN INSERT THE PROPER SEPARATORS LATER                
           IF WS-VO-ADDRESS-NM (31 : 20) NOT = SPACES THEN                      
               SET WS-LONGNAME TO TRUE                                          
           ELSE                                                                 
               SET WS-NOT-A-LONGNAME TO TRUE                                    
           END-IF.                                                              
                                                                                
      *-> IF WE HAVE A CONTACT NAME WE HAVE TO INCLUDE IT IN THE                
      *-> ADDRESS LINES (WE MAY ACTUALLY LOOSE THE 5TH ADDRESS LINE)            
           IF WS-VO-CONTACT-NM = SPACES THEN                                    
               MOVE WS-VO-ADDRESS-LINE(1)   TO WS-NAD-LINE(2)                   
               MOVE WS-VO-ADDRESS-LINE(2)   TO WS-NAD-LINE(3)                   
               MOVE WS-VO-ADDRESS-LINE(3)   TO WS-NAD-LINE(4)                   
               MOVE WS-VO-ADDRESS-LINE(4)   TO WS-NAD-LINE(5)                   
               MOVE WS-VO-ADDRESS-LINE(5)   TO WS-NAD-LINE(6)                   
           ELSE                                                                 
               STRING 'ATTN: ' WS-VO-CONTACT-NM DELIMITED BY SIZE               
                 INTO WS-NAD-WRK-LINE                                           
               IF WS-LONGNAME THEN                                              
                 MOVE WS-VO-ADDRESS-LINE(1) TO WS-NAD-LINE(2)                   
                 MOVE WS-NAD-WRK-LINE       TO WS-NAD-LINE(3)                   
               ELSE                                                             
                 MOVE WS-NAD-WRK-LINE       TO WS-NAD-LINE(2)                   
                 MOVE WS-VO-ADDRESS-LINE(1) TO WS-NAD-LINE(3)                   
               END-IF                                                           
               MOVE WS-VO-ADDRESS-LINE(2)   TO WS-NAD-LINE(4)                   
               MOVE WS-VO-ADDRESS-LINE(3)   TO WS-NAD-LINE(5)                   
               MOVE WS-VO-ADDRESS-LINE(4)   TO WS-NAD-LINE(6)                   
           END-IF.                                                              
                                                                                
                                                                                
      *-> ANALYSE THE CITY, PROVINCE, POSTAL CODE INFO TO DETERMINE             
      *-> WHERE (AND HOW) TO INSERT THE COMMA AFTER CITY                        
           INITIALIZE WS-WORK-CITY-PROV-LINES.                                  
                                                                                
           PERFORM VARYING CTY-PTR FROM 30 BY -1 UNTIL CTY-PTR = 1              
                OR WS-VO-CITY-NM (CTY-PTR : 1) NOT = SPACES                     
                   CONTINUE                                                     
           END-PERFORM.                                                         
           MOVE CTY-PTR TO CTY-NAM-LENGTH.                                      
           MOVE +1      TO CTY-PTR2.                                            
           MOVE SPACES  TO WS-WK-CITY-PROV.                                     
           STRING WS-VO-CITY-NM (1 : CTY-NAM-LENGTH)                            
                  ' '                                                           
                  WS-VO-PROVINCE DELIMITED BY SIZE                              
             INTO WS-WK-CITY-PROV                                               
             WITH POINTER CTY-PTR2                                              
           END-STRING.                                                          
                                                                                
      *-> PROCEED TO CONCATENATE THE ADDRESS LINES, REMOVE TRAILING             
      *-> SPACES ON EACH LINE AND INSERT THE PROPER SEPARATOR                   
           MOVE SPACES TO WS-NAME-ADDRESS-CONV.                                 
           MOVE +0     TO NAD-PTR.                                              
           PERFORM VARYING NAD-L FROM 1 BY 1 UNTIL NAD-L > 6                    
               MOVE WS-NAD-LINE (NAD-L) TO WS-NAD-WRK-LINE                      
               IF WS-NAD-WRK-LINE NOT = SPACES THEN                             
                  PERFORM VARYING NAD-CH FROM +30 BY -1                         
                    UNTIL WS-NAD-WRK-LINE (NAD-CH : 1) NOT = SPACES             
                          CONTINUE                                              
                  END-PERFORM                                                   
                  IF WS-NAD-WRK-LINE = WS-VO-CITY-NM                            
                  OR WS-NAD-WRK-LINE (1 : CTY-PTR2) = WS-WK-CITY-PROV           
      *->           THIS IS THE LINE THAT CONTAINS THE CITY                     
      *->           CALL THE ROUTINE TO INSERT A COMMA AFTER CITY               
                      MOVE NAD-CH TO CTY-EOL                                    
                      PERFORM 4550-INSERT-COMMA THRU 4550-EXIT                  
                  END-IF                                                        
                  ADD +1 TO NAD-PTR                                             
                  MOVE WS-NAD-WRK-LINE                                          
                    TO WS-NAME-ADDRESS-CONV (NAD-PTR : 30)                      
                  ADD +30       TO NAD-PTR                                      
                  EVALUATE NAD-L                                                
                    WHEN 1                                                      
                      IF WS-LONGNAME THEN                                       
                        MOVE '$' TO WS-NAME-ADDRESS-CONV (NAD-PTR : 1)          
                      ELSE                                                      
                        MOVE '*' TO WS-NAME-ADDRESS-CONV (NAD-PTR : 1)          
                      END-IF                                                    
                    WHEN 2                                                      
                      IF WS-LONGNAME THEN                                       
                        MOVE '*' TO WS-NAME-ADDRESS-CONV (NAD-PTR : 1)          
                      ELSE                                                      
                        MOVE '$' TO WS-NAME-ADDRESS-CONV (NAD-PTR : 1)          
                      END-IF                                                    
                    WHEN OTHER                                                  
                        MOVE '$' TO WS-NAME-ADDRESS-CONV (NAD-PTR : 1)          
                  END-EVALUATE                                                  
               END-IF                                                           
           END-PERFORM                                                          
                                                                                
      *****************************************************************         
      *  POSITION THE END DELIMITER AT THE PROPER LOCATION                      
      *****************************************************************         
           IF WS-NAME(6) NOT = SPACES                                           
              MOVE '<'                 TO WS-DEL(6)                             
           ELSE                                                                 
           IF WS-NAME(5) NOT = SPACES                                           
              MOVE '<'                 TO WS-DEL(5)                             
              MOVE ' '                 TO WS-DEL(6)                             
           ELSE                                                                 
           IF WS-NAME(4) NOT = SPACES                                           
              MOVE '<'                 TO WS-DEL(4)                             
              MOVE ' '                 TO WS-DEL(5)                             
                                          WS-DEL(6)                             
           ELSE                                                                 
           IF WS-NAME(3) NOT = SPACES                                           
              MOVE '<'                 TO WS-DEL(3)                             
              MOVE ' '                 TO WS-DEL(4)                             
                                          WS-DEL(5)                             
                                          WS-DEL(6)                             
           ELSE                                                                 
           IF WS-NAME(2) NOT = SPACES                                           
              MOVE '<'                 TO WS-DEL(2)                             
              MOVE ' '                 TO WS-DEL(3)                             
                                          WS-DEL(4)                             
                                          WS-DEL(5)                             
                                          WS-DEL(6)                             
           ELSE                                                                 
           IF WS-NAME(1) NOT = SPACES                                           
              MOVE '<'                 TO WS-DEL(1)                             
              MOVE ' '                 TO WS-DEL(2)                             
                                          WS-DEL(3)                             
                                          WS-DEL(4)                             
                                          WS-DEL(5)                             
                                          WS-DEL(6).                            
                                                                                
                                                                                
      *->  REPLACE THE LOWER CASE AND FRENCH CHARACTERS WITH WITH               
      *->  THEIR EQUIVALENT UPPER CASE                                          
           INSPECT WS-NAME-ADDRESS-CONV                                         
                  CONVERTING LOWERCASE-AND-FRENCH                               
                          TO UPPERCASE-AND-ENGLISH.                             
       4500-EXIT.                                                               
           EXIT.                                                                
                                                                                
       4550-INSERT-COMMA.                                                       
             EVALUATE TRUE                                                      
                WHEN CTY-EOL = 30                                               
                    CONTINUE                                                    
                WHEN WS-NAD-WRK-LINE = WS-VO-CITY-NM                            
      *->           SIMPLY REPLACE THE SPACE AFTER CITY WITH A COMMA            
                    ADD  1   TO CTY-NAM-LENGTH GIVING CTY-PTR                   
                    MOVE ',' TO WS-NAD-WRK-LINE (CTY-PTR : 1)                   
                    ADD  1   TO CTY-EOL                                         
                WHEN OTHER                                                      
      *->           WE'VE GOT ROOM, INSERT A COMMA AFTER THE CITY               
                    SUBTRACT  CTY-NAM-LENGTH FROM CTY-EOL                       
                                             GIVING CTY-OTH-LENGTH              
                    ADD  1 TO CTY-NAM-LENGTH GIVING CTY-PTR                     
                    MOVE SPACES TO CTY-LINE                                     
                    STRING WS-NAD-WRK-LINE (1 : CTY-NAM-LENGTH)                 
                           ','                                                  
                           WS-NAD-WRK-LINE (CTY-PTR : CTY-OTH-LENGTH)           
                      DELIMITED BY SIZE INTO CTY-LINE                           
                    ADD  1        TO CTY-EOL                                    
                    MOVE CTY-LINE TO WS-NAD-WRK-LINE                            
             END-EVALUATE.                                                      
       4550-EXIT.                                                               
           EXIT.                                                                
