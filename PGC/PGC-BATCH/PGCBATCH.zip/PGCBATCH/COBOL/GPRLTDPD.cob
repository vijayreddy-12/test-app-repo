       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRLTDPD.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
      *REMARKS.     THIS PROGRAM PRINTS THE LTD CASH PREMIUM PAID               
      *             REPORT WITH 2 COPIES.                                       
      *DATE-WRITTEN.  MODIFIED MAY 1984.                                        
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *           LINE AND PAGE SIZE AND COUNT VARIABLES               *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PAGE-SIZE               VALUE +0   COMP PIC S9(4).                   
       01  LINE-COUNT              VALUE +999 COMP PIC S9(4).                   
       01  PAGE-COUNT              VALUE +0 COMP-3 PIC S9(5).                   
GNE    01  PRINT-SYS020              PIC X(06) VALUE 'SYS020'.                  
GNE    01  PRINT-SYS020-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
      *----------------------------------------------------------------*        
      *                                                                *        
      *                     QDATE PARAMETERS                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  FUNCTION-AC             VALUE 'AC'      PIC X(2).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  PREVIOUSLY CONTROL KEYS                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PREVIOUS-CONTROL-KEY.                                                
           03  PREVIOUS-GLCODE                     PIC X(7).                    
           03  PREVIOUS-COUNTRY                    PIC X(1).                    
           03  PREVIOUS-RESIDENCE                  PIC 9(2).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *           PARAMETER USED IN CALLING "GNUMONIC"                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  GNUMTABL-PARAMS.                                                     
           03  GNUM-TABL-NO        VALUE +1 COMP   PIC S9(4).                   
           03  GNUM-RETURN.                                                     
               05  GNUM-COUNTRY                    PIC X(3).                    
               05  FILLER                          PIC X(12).                   
       01  STORE-COUNTRY                           PIC X(3).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *               CONTROL BREAK ACCUMULATORS                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PROGRAM-ACCUMULATORS.                                                
           03  RESIDENCE-PREMIUM     VALUE +0 COMP-3 PIC S9(8)V99.              
           03  RESIDENCE-COMMISSION  VALUE +0 COMP-3 PIC S9(8)V99.              
           03  COUNTRY-PREMIUM       VALUE +0 COMP-3 PIC S9(9)V99.              
           03  COUNTRY-COMMISSION    VALUE +0 COMP-3 PIC S9(9)V99.              
           03  GL-PREMIUM            VALUE +0 COMP-3 PIC S9(10)V99.             
           03  GL-COMMISSION         VALUE +0 COMP-3 PIC S9(10)V99.             
           03  TOTAL-PREMIUM         VALUE +0 COMP-3 PIC S9(10)V99.             
           03  TOTAL-COMMISSION      VALUE +0 COMP-3 PIC S9(10)V99.             
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   PAGE HEADING LAYOUT                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-HEADING-LINE.                                                     
           03  FILLER             VALUE '1'        PIC X(1).                    
           03  FILLER             VALUE 'GPRLTDPD' PIC X(8).                    
           03  FILLER             VALUE SPACES     PIC X(12).                   
           03  PR-HEADING                          PIC X(29).                   
           03  FILLER             VALUE SPACES     PIC X(15).                   
           03  FILLER             VALUE 'RUNDATE ' PIC X(8).                    
           03  PR-RUNDATE                          PIC X(7).                    
           03  FILLER             VALUE '  PAGE '  PIC X(7).                    
           03  PR-PAGE                             PIC ZZZZ9.                   
           03  FILLER             VALUE SPACES     PIC X(41).                   
       01  PR-DATE-LINE.                                                        
           03  FILLER             VALUE SPACES     PIC X(1).                    
           03  FILLER             VALUE SPACES     PIC X(29).                   
           03  PR-DATE                             PIC X(12).                   
           03  FILLER             VALUE SPACES     PIC X(91).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  COLUMN HEADING LAYOUT                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-SUBHEAD-LINE.                                                     
           03  FILLER              VALUE '0'       PIC X(1).                    
           03  FILLER                              PIC X(15)                    
               VALUE '  G.L. CODE    '.                                         
           03  FILLER                              PIC X(11)                    
               VALUE 'COUNTRY    '.                                             
           03  FILLER                              PIC X(15)                    
               VALUE 'RESIDENCE      '.                                         
           03  FILLER                              PIC X(15)                    
               VALUE 'PREMIUM        '.                                         
           03  FILLER                              PIC X(10)                    
               VALUE 'COMMISSION'.                                              
           03  FILLER              VALUE SPACES    PIC X(67).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    PRINT LINE LAYOUT                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-DATA-LINE.                                                        
           02  FILLER.                                                          
           03  PR-CC                               PIC X(1).                    
           02  PR-DATA.                                                         
           03  FILLER              VALUE SPACES    PIC X(3).                    
           03  PR-GLCODE                           PIC X(11).                   
           03  FILLER              VALUE SPACES    PIC X(3).                    
           03  PR-COUNTRY                          PIC X(3).                    
           03  FILLER              VALUE SPACES    PIC X(9).                    
           03  PR-RESIDENCE                        PIC 9(2).                    
           03  FILLER              VALUE SPACES    PIC X(5).                    
           03  PR-PREMIUM                          PIC ZZZZ,ZZZ,ZZZ.99-.        
           03  FILLER              VALUE SPACE     PIC X(1).                    
           03  PR-COMMISSION                       PIC ZZZZ,ZZZ,ZZZ.99-.        
           03  FILLER              VALUE SPACES    PIC X(2).                    
           03  PR-TOTAL-IND        VALUE SPACES    PIC X(3).                    
           03  FILLER              VALUE SPACES    PIC X(59).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                      PRINT BUFFER                              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-PRINT-LINE.                                                       
           03  FILLER                              PIC X(133).                  
                                                                                
       LINKAGE SECTION.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *           PRINT RECORD PASSED TO THIS PROGRAM                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-RECORD.                                                         
           03  FILLER                              PIC X(4).                    
           03  TAPE-KEY.                                                        
               05  TAPE-TYPE                       PIC X(1).                    
               05  TAPE-FORM                       PIC X(1).                    
           03  TAPE-CONTROL-KEY.                                                
               05  TAPE-GLCODE                     PIC X(7).                    
               05  TAPE-COUNTRY                    PIC X(1).                    
               05  TAPE-RESIDENCE                  PIC 9(2).                    
GNE        03  TAPE-GROUP                   COMP-3 PIC S9(7).                   
           03  TAPE-ACCOUNT                        PIC X(3).                    
           03  TAPE-PREMIUM                 COMP-3 PIC S9(7)V99.                
           03  TAPE-COMMISSION              COMP-3 PIC S9(7)V99.                
GNE        03  FILLER                              PIC X(42).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *           RESTART INFORMATION PASSED TO THIS PROGRAM           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  MISC-AREA.                                                           
           03  FILLER                              PIC X(4).                    
           03  ST-HIDATE                           PIC X(4).                    
           03  FILLER                              PIC X(24).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *     PRINT PARAMTETERS COPY BOOK FOR SYS022 THROUGH SYS029      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-PARAMETERS.                                                    
        COPY  GPRPRINT  REPLACING                                               
                                            ==01  GPRPRINT.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 REPORT HRADING AND DATE                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-PARAM-DATA.                                                       
           03  PR-HEAD-PARAM                       PIC X(50).                   
           03  PR-DATE-PARAM                       PIC X(12).                   
           03  PR-PAGE-NUMBER              COMP-3  PIC S9(5).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *        TAPE PARMETERS COPY BOOK FOR SYS011 AND SYS014          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-PARAMETERS.                                                     
        COPY  GPRTPARM  REPLACING                                               
                                            ==01  GPRTPARM.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *               REPORT ACCUMULATOR COPY BOOK                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-ACCUMULATORS.                                                 
        COPY  GPRACCUM  REPLACING                                               
                                            ==01  GPRACCUM.== BY ====.          
                                                                                
       PROCEDURE DIVISION USING TAPE-RECORD                                     
                                MISC-AREA                                       
                                PRINT-PARAMETERS                                
                                PR-PARAM-DATA                                   
                                TAPE-PARAMETERS                                 
                                REPORT-ACCUMULATORS.                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   INITIALIZATION LOGIC                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM INITIALIZATION THRU                                          
                   INITIALIZATION-EXIT.                                         
       PROCESS-RECORD.                                                          
      *----------------------------------------------------------------*        
      *                                                                *        
      *            PROCESS GENERAL LEDGER CONTROL BREAK                *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  TAPE-GLCODE IS NOT EQUAL TO PREVIOUS-GLCODE THEN                 
               PERFORM GL-CONTROL-BREAK THRU                                    
                       GL-CONTROL-BREAK-EXIT                                    
               GO TO ACCUMULATE.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                PROCESS COUNTRY CONTROL BREAK                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  TAPE-COUNTRY IS NOT EQUAL TO PREVIOUS-COUNTRY THEN               
               PERFORM COUNTRY-CONTROL-BREAK THRU                               
                       COUNTRY-CONTROL-BREAK-EXIT                               
               GO TO ACCUMULATE.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                PROCESS RESIDENCE CONTROL BREAK                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  TAPE-RESIDENCE IS NOT EQUAL TO PREVIOUS-RESIDENCE THEN           
               PERFORM RESIDENCE-CONTROL-BREAK THRU                             
                       RESIDENCE-CONTROL-BREAK-EXIT.                            
       ACCUMULATE.                                                              
      *----------------------------------------------------------------*        
      *                                                                *        
      *           ACCUMULATE PREMIUMS AND COMMISSIONS                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM ACCUMULATE-PREMCOMM THRU                                     
                   ACCUMULATE-PREMCOMM-EXIT.                                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *             READ A RECORD FROM THE INPUT FILE                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM READ-RECORD THRU                                             
                   READ-RECORD-EXIT.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *   IF YOU THE RETURN CODE IS ZERO AND THE RECORD TYPE IS "UA"   *        
      *   CONTINUE PROCESSING RECORDS                                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  TAPE-RETURN IS EQUAL TO ZEROES                                   
           AND TAPE-KEY IS EQUAL TO 'UA' THEN                                   
               GO TO PROCESS-RECORD.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *       PRINT THE FINAL TOTALS BEFORE RETURNING TO CALLER        *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM PRINT-FINAL-TOTAL THRU                                       
                   PRINT-FINAL-TOTAL-EXIT.                                      
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   INITIALIZE VARIABLES                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       INITIALIZATION.                                                          
           CALL 'ZLINECT' USING PAGE-SIZE.                                      
           CALL 'QDATE' USING FUNCTION-AC                                       
                              ST-HIDATE                                         
                              PR-RUNDATE.                                       
           MOVE PR-HEAD-PARAM TO PR-HEADING.                                    
           MOVE PR-DATE-PARAM TO PR-DATE.                                       
           MOVE PR-PAGE-NUMBER TO PAGE-COUNT.                                   
           MOVE TAPE-CONTROL-KEY TO PREVIOUS-CONTROL-KEY.                       
           MOVE TAPE-GLCODE TO PR-GLCODE.                                       
           CALL 'GNUMTABL' USING GNUM-TABL-NO                                   
                                 TAPE-COUNTRY                                   
                                 GNUM-RETURN.                                   
           MOVE GNUM-COUNTRY TO PR-COUNTRY                                      
                                STORE-COUNTRY.                                  
           MOVE TAPE-RESIDENCE TO PR-RESIDENCE.                                 
       INITIALIZATION-EXIT.                                                     
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *            PROCESS GENERAL LEDGER CONTROL BREAK                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       GL-CONTROL-BREAK.                                                        
           MOVE RESIDENCE-PREMIUM TO PR-PREMIUM.                                
           MOVE RESIDENCE-COMMISSION TO PR-COMMISSION.                          
           MOVE PREVIOUS-RESIDENCE TO PR-RESIDENCE.                             
           MOVE SPACES TO PR-CC.                                                
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD RESIDENCE-PREMIUM TO COUNTRY-PREMIUM.                            
           ADD RESIDENCE-COMMISSION TO COUNTRY-COMMISSION.                      
           MOVE STORE-COUNTRY TO PR-COUNTRY.                                    
           MOVE COUNTRY-PREMIUM TO PR-PREMIUM.                                  
           MOVE COUNTRY-COMMISSION TO PR-COMMISSION.                            
           MOVE '0' TO PR-CC.                                                   
           MOVE '*' TO PR-TOTAL-IND.                                            
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD COUNTRY-PREMIUM TO GL-PREMIUM.                                   
           ADD COUNTRY-COMMISSION TO GL-COMMISSION.                             
           CALL 'GNUMTABL' USING GNUM-TABL-NO                                   
                                 TAPE-COUNTRY                                   
                                 GNUM-RETURN.                                   
           MOVE GNUM-COUNTRY TO STORE-COUNTRY.                                  
           MOVE PREVIOUS-GLCODE TO PR-GLCODE.                                   
           MOVE GL-PREMIUM TO PR-PREMIUM.                                       
           MOVE GL-COMMISSION TO PR-COMMISSION.                                 
           MOVE '0' TO PR-CC.                                                   
           MOVE '**' TO PR-TOTAL-IND.                                           
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           MOVE ' ' TO PR-CC.                                                   
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD GL-PREMIUM TO TOTAL-PREMIUM.                                     
           ADD GL-COMMISSION TO TOTAL-COMMISSION.                               
           MOVE '0' TO PR-CC.                                                   
           MOVE TAPE-GLCODE TO PR-GLCODE.                                       
           MOVE GNUM-COUNTRY TO PR-COUNTRY.                                     
           MOVE ZEROES TO RESIDENCE-PREMIUM                                     
                          RESIDENCE-COMMISSION                                  
                          COUNTRY-PREMIUM                                       
                          COUNTRY-COMMISSION                                    
                          GL-PREMIUM                                            
                          GL-COMMISSION.                                        
       GL-CONTROL-BREAK-EXIT.                                                   
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              PROCESS COUNTRY CONTROL BREAK                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COUNTRY-CONTROL-BREAK.                                                   
           MOVE RESIDENCE-PREMIUM TO PR-PREMIUM.                                
           MOVE RESIDENCE-COMMISSION TO PR-COMMISSION.                          
           MOVE PREVIOUS-RESIDENCE TO PR-RESIDENCE.                             
           MOVE SPACES TO PR-CC.                                                
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD RESIDENCE-PREMIUM TO COUNTRY-PREMIUM.                            
           ADD RESIDENCE-COMMISSION TO COUNTRY-COMMISSION.                      
           MOVE STORE-COUNTRY TO PR-COUNTRY.                                    
           MOVE COUNTRY-PREMIUM TO PR-PREMIUM.                                  
           MOVE COUNTRY-COMMISSION TO PR-COMMISSION.                            
           MOVE '0' TO PR-CC.                                                   
           MOVE '*' TO PR-TOTAL-IND.                                            
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           MOVE ' ' TO PR-CC.                                                   
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD COUNTRY-PREMIUM TO GL-PREMIUM.                                   
           ADD COUNTRY-COMMISSION TO GL-COMMISSION.                             
           CALL 'GNUMTABL' USING GNUM-TABL-NO                                   
                                 TAPE-COUNTRY                                   
                                 GNUM-RETURN.                                   
           MOVE GNUM-COUNTRY TO PR-COUNTRY                                      
                                STORE-COUNTRY.                                  
           MOVE ZEROES TO RESIDENCE-PREMIUM                                     
                          RESIDENCE-COMMISSION                                  
                          COUNTRY-PREMIUM                                       
                          COUNTRY-COMMISSION.                                   
       COUNTRY-CONTROL-BREAK-EXIT.                                              
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             PROCESS RESIDENCE CONTROL BREAK                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       RESIDENCE-CONTROL-BREAK.                                                 
           MOVE RESIDENCE-PREMIUM TO PR-PREMIUM.                                
           MOVE RESIDENCE-COMMISSION TO PR-COMMISSION.                          
           MOVE PREVIOUS-RESIDENCE TO PR-RESIDENCE.                             
           MOVE SPACES TO PR-CC.                                                
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD RESIDENCE-PREMIUM TO COUNTRY-PREMIUM.                            
           ADD RESIDENCE-COMMISSION TO COUNTRY-COMMISSION.                      
           MOVE ZEROES TO RESIDENCE-PREMIUM                                     
                          RESIDENCE-COMMISSION.                                 
       RESIDENCE-CONTROL-BREAK-EXIT.                                            
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *           ACCUMULATE PREMMIUMS AND COMMISSIONS                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ACCUMULATE-PREMCOMM.                                                     
           MOVE TAPE-CONTROL-KEY TO PREVIOUS-CONTROL-KEY.                       
           ADD TAPE-PREMIUM TO RESIDENCE-PREMIUM.                               
           ADD TAPE-COMMISSION TO RESIDENCE-COMMISSION.                         
       ACCUMULATE-PREMCOMM-EXIT.                                                
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                PRINT THE FINAL TOTALS                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-FINAL-TOTAL.                                                       
           MOVE RESIDENCE-PREMIUM TO PR-PREMIUM.                                
           MOVE RESIDENCE-COMMISSION TO PR-COMMISSION.                          
           MOVE PREVIOUS-RESIDENCE TO PR-RESIDENCE.                             
           MOVE SPACES TO PR-CC.                                                
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD RESIDENCE-PREMIUM TO COUNTRY-PREMIUM.                            
           ADD RESIDENCE-COMMISSION TO COUNTRY-COMMISSION.                      
           MOVE STORE-COUNTRY TO PR-COUNTRY.                                    
           MOVE COUNTRY-PREMIUM TO PR-PREMIUM.                                  
           MOVE COUNTRY-COMMISSION TO PR-COMMISSION.                            
           MOVE '0' TO PR-CC.                                                   
           MOVE '*' TO PR-TOTAL-IND.                                            
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD COUNTRY-PREMIUM TO GL-PREMIUM.                                   
           ADD COUNTRY-COMMISSION TO GL-COMMISSION.                             
           MOVE PREVIOUS-GLCODE TO PR-GLCODE.                                   
           MOVE GL-PREMIUM TO PR-PREMIUM.                                       
           MOVE GL-COMMISSION TO PR-COMMISSION.                                 
           MOVE '0' TO PR-CC.                                                   
           MOVE '**' TO PR-TOTAL-IND.                                           
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           ADD GL-PREMIUM TO TOTAL-PREMIUM.                                     
           ADD GL-COMMISSION TO TOTAL-COMMISSION.                               
           MOVE 'FINAL TOTAL' TO PR-GLCODE.                                     
           MOVE TOTAL-PREMIUM TO PR-PREMIUM.                                    
           MOVE TOTAL-COMMISSION TO PR-COMMISSION.                              
           MOVE '***' TO PR-TOTAL-IND.                                          
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           MOVE PAGE-COUNT TO PR-PAGE-NUMBER.                                   
       PRINT-FINAL-TOTAL-EXIT.                                                  
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    PRINT PAGE HEADINGS                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-HEADINGS.                                                          
           ADD +1 TO ACCUM-LTDPREM.                                             
           ADD +1 TO PAGE-COUNT.                                                
           MOVE PAGE-COUNT TO PR-PAGE.                                          
           MOVE PR-HEADING-LINE TO PR-PRINT-LINE.                               
           PERFORM WRITE-LINE THRU                                              
                   WRITE-LINE-EXIT.                                             
           MOVE PR-DATE-LINE TO PR-PRINT-LINE                                   
           PERFORM WRITE-LINE THRU                                              
                   WRITE-LINE-EXIT.                                             
           MOVE PR-SUBHEAD-LINE TO PR-PRINT-LINE                                
           PERFORM WRITE-LINE THRU                                              
                   WRITE-LINE-EXIT.                                             
           MOVE +4 TO LINE-COUNT.                                               
           MOVE '0' TO PR-CC.                                                   
       PRINT-HEADINGS-EXIT.                                                     
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     MOVE DATA TO THE OUTPUT BUFFER AND CALL THE ROUTINE TO     *        
      *     PRINT THE OUTPUT BUFFER                                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-LINE.                                                              
           MOVE PR-DATA-LINE TO PR-PRINT-LINE.                                  
           IF  PR-CC IS EQUAL TO SPACES THEN                                    
               ADD +1 TO LINE-COUNT                                             
           ELSE                                                                 
               IF  PR-CC IS EQUAL TO '0' THEN                                   
                   ADD +2 TO LINE-COUNT                                         
               ELSE                                                             
                   IF  PR-CC IS EQUAL TO '0' THEN                               
                       ADD +3 TO LINE-COUNT                                     
                   ELSE                                                         
                       NEXT SENTENCE.                                           
           IF  LINE-COUNT IS GREATER THAN PAGE-SIZE THEN                        
               PERFORM PRINT-HEADINGS THRU                                      
                       PRINT-HEADINGS-EXIT                                      
               GO TO PRINT-LINE.                                                
           PERFORM WRITE-LINE THRU                                              
                   WRITE-LINE-EXIT.                                             
           MOVE SPACES TO PR-DATA.                                              
       PRINT-LINE-EXIT.                                                         
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *  SETUP CALL TO GRNERAL I/O REOUTINE TO WRITE THE OUTPUT BUFFER *        
      *                                                                *        
      *----------------------------------------------------------------*        
       WRITE-LINE.                                                              
GNE        CALL 'DLSWRITE' USING PRINT-SYS020                                   
                                 PRINT-RETURN                                   
                                 PR-PRINT-LINE                                  
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
GNE                              PRINT-SYS020-COUNT.                            
       WRITE-LINE-EXIT.                                                         
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *    SET UP CALL TO GENERAL I/O ROUTINE TO READ A PRINT RECORD   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       READ-RECORD.                                                             
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                TAPE-RECORD                                     
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
       READ-RECORD-EXIT.                                                        
           EXIT.                                                                
