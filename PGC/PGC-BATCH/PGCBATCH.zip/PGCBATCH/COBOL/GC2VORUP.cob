       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2VORUP.                                                    
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      ******************************************************************        
      *REMARKS.                                                                 
      *    THIS PROGRAM UPDATES THE COMMISSION HISTORY DATA BASE                
      *    WITH VO RENEWAL PREMIUM INFORMATION  (CLONED FROM                    
      *    GWCOCRUP AND MODIFIED TO PROCESS FOR VO).                            
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INPUT:     VORENEXT VO RENEWAL PREMIUMS EXTRACT FILE         *         
      *                (GCOMGRE7 LAYOUT)                              *         
      *             COMMISSION HISTORY DATABASE                       *         
      *                (IDMS DATABASE)                                *         
      *                                                               *         
      *  OUTPUT:    COMMISSION HISTORY UPDATE - ACTION REPORT         *         
      *             COMMISSION HISTORY DATABASE                       *         
      *                                                               *         
      *  FREQUENCY: DAILY                                             *         
      *                                                               *         
      *  MODULES:   GWCOCADG - ADD GROUP AND/OR GRACCT.               *         
      *                                                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *  HISTORY:                                                     *         
      *                                                               *         
      *  OCT2005   RLKNAUD     -  INITIAL CREATION.                   *         
      *                                                               *         
      *  OCT2008   IBM         -  COMPILER UPGRADE.                   *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVORUP           
      * SEP2011 - CARLYSH - ADDED OUTPUT FILES SYS022 & SYS023,                 
      *                     CHANGED FILE SETTINGS ON ACTION REPORT              
      *                     AND CHANGED INSTANCES OF GIPSY TO M/C               
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO02 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2VORUP W-S STARTS HERE **'.                                
                                                                                
      *----------------------------------------------                           
      *  VO PS MASTER                                                           
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
             ' **** VO PS MASTER  ****    '.                                    
           COPY VOPSMAST.                                                       
      *----------------------------------------------                           
      *   PSMASTER                                                              
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
FXXTOK       ' **** PSMASTE7  ****    '.                                        
      * PSMASTE7                                                                
CPYNME     COPY PSMASTE7.                                                       
      *----------------------------------------------------                     
      *          DATASERVER RECORDS                                             
      *----------------------------------------------------                     
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
       01  LOGICAL-RECORD-NAMES.                                                
           COPY HCSLRNAM.                                                       
      *----------------------------------------------------                     
      *          GAEDATSR DYNAMIC CALL PROGRAM                                  
      *----------------------------------------------------                     
       01  GAEDATSR                  PIC X(8) VALUE 'GAEDATSR'.                 
      *----------------------------------------------------                     
      *          GIPSY ACCESS MODULE PARMS                                      
      *----------------------------------------------------                     
       01  GACCDMA7-PS-PARMS.                                                   
           05  GACCDMA7-PS-FUNC      PIC S9(4)    COMP   VALUE +18.             
REN        05  GACCDMA7-PS-GROUP     PIC S9(7)    COMP-3.                       
           05  GACCDMA7-PS-ACCT      PIC X(3).                                  
           05  GACCDMA7-PS-CERT      PIC S9(9)    COMP-3.                       
           05  GACCDMA7-PS-WORK      PIC X(9).                                  
       01  GACCDMA7-PS-RETURN        PIC X(3).                                  
           88  GACCDMA7-PS-RET-OK                 VALUE '   '.                  
           88  GACCDMA7-PS-EOF                    VALUE 'R01'.                  
           88  GACCDMA7-PS-NOT-FOUND              VALUE 'R01'.                  
           88  GACCDMA7-PS-DISK-ERROR             VALUE 'R03'.                  
           88  GACCDMA7-PS-FUNC-INVALID           VALUE 'R09'.                  
                                                                                
       01  WS-PARAMETERS.                                                       
                                                                                
REN        05  WS-GROUP-NUMBER                            PIC X(7).             
           05  FILLER  REDEFINES WS-GROUP-NUMBER.                               
REN            10  WS-NUM-GROUP-NUMBER                    PIC 9(7).             
           05  WS-NUM-GROUP-NUM7                          PIC 9(7).             
           05  WS-PSMPOLICY-YEAR              PIC S9(3) COMP-3.                 
                                                                                
           05  WS-GPSY-RECS-NOT-FOUND     VALUE +0        PIC S9(5).            
           05  WS-NEW-ISSUES-FOUND        VALUE +0        PIC S9(5).            
           05  WS-WARNINGS                VALUE +0        PIC S9(5).            
           05  WS-REC-PROCESSED           VALUE +0        PIC S9(5).            
           05  QDATE-FORMATA              VALUE 'BA'      PIC XX.               
           05  QDATE-FORMATB              VALUE 'AB'      PIC XX.               
           05  QDATE-FORMATC              VALUE 'AC'      PIC XX.               
                                                                                
           05  DLSREAD-PARMS.                                                   
               10  READ-SYS010            VALUE 'SYS010'  PIC X(6).             
               10  READ-RET-CODE   COMP-3 VALUE +0        PIC S9.               
               10  READ-RECSIZE           VALUE 54        PIC 9(5).             
               10  READ-BLKSIZE           VALUE 5400      PIC 9(5).             
               10  READ-FORMAT            VALUE 'FB'      PIC X(2).             
               10  READ-REC-CNT    COMP-3 VALUE +0        PIC S9(7).            
                                                                                
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         COMMISSION HISTORY UPDATE - ACTION REPORT             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
                                                                                
       01  ACTION-REPORT-AREA.                                                  
                                                                                
           05  DLSW-ACTION-RPT.                                                 
               10  ACTION-SYS021           VALUE 'SYS021'  PIC X(6).            
               10  ACTION-RET-CODE  COMP-3 VALUE +0        PIC S9.              
               10  ACTION-LINE             VALUE SPACES    PIC X(133).          
               10  ACTION-RECSIZE          VALUE 133       PIC 9(5).            
               10  ACTION-BLKSIZE          VALUE 27930     PIC 9(5).            
               10  ACTION-FORMAT           VALUE 'FBA'     PIC X(3).            
               10  ACTION-COUNT     COMP-3 VALUE +0        PIC S9(7).           
                                                                                
           05  ACTION-SW                   PIC X       VALUE '0'.               
               88  NO-ACTION                           VALUE '0'.               
               88  NEW-GROUP                           VALUE '1'.               
               88  NEW-ACCOUNT                         VALUE '2'.               
               88  NO-INPUT                            VALUE '3'.               
               88  FIRST-YEAR-GROUP                    VALUE '4'.               
               88  NO-POINT-IN-SCALE                   VALUE '5'.               
               88  NO-RENEWAL-AMOUNTS                  VALUE '6'.               
               88  NOT-CURRENT-RENEWAL                 VALUE '7'.               
               88  NEGATIVE-PREMIUMS                   VALUE '8'.               
                                                                                
           05  ACTION-HEADINGS.                                                 
               10  ACTION-HDG-1.                                                
                   15  FILLER              PIC X(13)      VALUE                 
                                                       '1 GC2VORUP-1 '.         
                   15  FILLER              PIC X(30)      VALUE SPACES.         
                   15  FILLER              PIC X(55)      VALUE                 
                                        'MANUFACTURERS LIFE OF CANADA'.         
                   15  FILLER              PIC X(14)      VALUE                 
                                               'FILE DATE : '.                  
                   15  ACTION-FILE-DATE    PIC X(7)       VALUE SPACES.         
                                                                                
               10  ACTION-HDG-2.                                                
                   15  FILLER              PIC X(43)      VALUE SPACES.         
                   15  FILLER              PIC X(58)      VALUE                 
                           'COMMISSION HISTORY UPDATE - ACTION REPORT'.         
                   15  FILLER              PIC X(18)      VALUE SPACES.         
                                                                                
               10  ACTION-HDG-3.                                                
                   15  FILLER    PIC X(7)    VALUE '  GFO'.                     
                   15  FILLER    PIC X(10)   VALUE 'GROUP/ACC'.                 
                   15  FILLER    PIC X(6)    VALUE 'BRNCH'.                     
                   15  FILLER    PIC X(20)   VALUE 'ACTION MESSAGE'.            
                                                                                
           05  ACTION-LINES.                                                    
               10  ACTION-LINE-1.                                               
                   15  ACTION-CC-1            PIC X       VALUE '0'.            
                   15  ACTION-1-GFO           PIC X(5)    VALUE SPACES.         
                   15  FILLER                 PIC X       VALUE SPACES.         
REN                15  ACTION-1-GROUP         PIC X(7)    VALUE SPACES.         
                   15  FILLER                 PIC X       VALUE '-'.            
                   15  ACTION-1-ACCT          PIC X(3)    VALUE SPACES.         
                   15  FILLER                 PIC X       VALUE SPACES.         
                   15  ACTION-1-BRANCH        PIC X(5)    VALUE SPACES.         
                   15  FILLER                 PIC X(111)  VALUE                 
                 ' NEW GROUP RECORD HAS BEEN ADDED WITH RENEWAL INFO'.          
                                                                                
               10  ACTION-LINE-2.                                               
                   15  ACTION-CC-2         PIC X          VALUE '0'.            
                   15  FILLER              PIC X(52)      VALUE                 
                 'NEW ACCOUNT RECORD HAS BEEN ADDED WITH RENEWAL INFO'.         
                   15  FILLER              PIC X(52)      VALUE                 
                '- ENSURE THAT RECONCILIATION DATES ARE VALID - ENTER'.         
                   15  FILLER              PIC X(28)      VALUE                 
                                        ' CORRECTION ON-LINE      ***'.         
                                                                                
               10  ACTION-LINE-6.                                               
                   15  ACTION-CC-6         PIC X          VALUE '0'.            
                   15  ACTION-REC-PROCESSED PIC ZZZZ9     VALUE ZERO.           
                   15  FILLER              PIC X(40)      VALUE                 
                                ' RECORDS WERE SUCCESFULLY PROCESSED '.         
                                                                                
               10  ACTION-LINE-7.                                               
                   15  ACTION-CC-7         PIC X          VALUE '0'.            
                   15  ACTION-REC-CNT-7    PIC ZZZZ9     VALUE ZERO.            
                   15  FILLER              PIC X(40)      VALUE                 
                                ' POINT IN SCALE RECORDS NOT FOUND   '.         
                                                                                
               10  ACTION-LINE-8.                                               
                   15  ACTION-CC-8         PIC X          VALUE '0'.            
                   15  ACTION-REC-CNT-8    PIC ZZZZ9     VALUE ZERO.            
                   15  FILLER              PIC X(40)      VALUE                 
                                ' NEW ISSUES FOUND                   '.         
                                                                                
               10  ACTION-LINE-9.                                               
                   15  ACTION-CC-9         PIC X          VALUE '0'.            
                   15  ACTION-REC-CNT-9    PIC ZZZZ9     VALUE ZERO.            
                   15  FILLER              PIC X(40)      VALUE                 
                                ' WARNING MESSAGES                   '.         
                                                                                
               10  ACTION-LINE-10.                                              
                   15  ACTION-CC-10  PIC X   VALUE ' '.                         
                   15  ACTION-ADD-GFO         PIC X(5)    VALUE SPACES.         
                   15  FILLER                 PIC X       VALUE SPACES.         
REN                15  ACTION-ADD-GROUP       PIC X(7)    VALUE SPACES.         
                   15  FILLER                 PIC X       VALUE '-'.            
                   15  ACTION-ADD-ACCT        PIC X(3)    VALUE SPACES.         
                   15  FILLER                 PIC X       VALUE SPACES.         
                   15  ACTION-ADD-BRANCH      PIC X(5)    VALUE SPACES.         
                   15  FILLER     PIC X(18)  VALUE ' ACCT EFFECTIVE ='.         
                   15  ACTION-ADD-ACCT-EFFECTIVE  PIC X(7).                     
                   15  FILLER     PIC X(18)  VALUE ' LAST-RECON-DATE='.         
                   15  ACTION-ADD-LAST-DATE  PIC X(7).                          
                   15  FILLER     PIC X(16)  VALUE ' NEXT RENEWAL='.            
                   15  ACTION-ADD-RENEWAL         PIC X(7).                     
                   15  FILLER     PIC X(18)  VALUE ' NEXT-RECON-DATE='.         
                   15  ACTION-ADD-NEXT-DATE  PIC X(7).                          
                                                                                
               10  ACTION-LINE-11.                                              
                   15  ACTION-CC-11        PIC X      VALUE '0'.                
                   15  FILLER              PIC X(132) VALUE                     
                               ' NO INPUT READ DATABASE UNCHANGED'.             
                                                                                
               10  ACTION-LINE-12.                                              
                   15  ACTION-CC-12        PIC X      VALUE '0'.                
                   15  ACTION-ERR-CNT      PIC ZZZZ9  VALUE ZERO.               
                   15  FILLER              PIC X(127) VALUE                     
                ' ERRORS WERE DETECTED DURING PROGRAM EXECUTION'.               
                                                                                
               10  ACTION-LINE-13.                                              
                   15  ACTION-CC-13        PIC X     VALUE '0'.                 
                   15  ACTION-13-GFO       PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
REN                15  ACTION-13-GROUP     PIC X(7)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE '-'.                 
                   15  ACTION-13-ACCT      PIC X(3)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
                   15  ACTION-13-BRANCH    PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X(51) VALUE                      
                ' - FIRST YEAR GROUP. NO RENEWAL INFORMATION STORED.'.          
                   15  FILLER              PIC X(63) VALUE SPACES.              
                   15  FILLER              PIC X(03) VALUE '***'.               
                                                                                
               10  ACTION-LINE-14.                                              
                   15  ACTION-CC-14        PIC X     VALUE '0'.                 
                   15  ACTION-14-GFO       PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
REN                15  ACTION-14-GROUP     PIC X(7)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE '-'.                 
                   15  ACTION-14-ACCT      PIC X(3)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
                   15  ACTION-14-BRANCH    PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X(59) VALUE                      
                ' - NO POINT IN SCALE MASTER FOUND. RENEWAL RECORDS DROP        
      -         'PED.'.                                                         
                   15  FILLER              PIC X(49) VALUE SPACES.              
                   15  FILLER              PIC X(03) VALUE '***'.               
                                                                                
               10  ACTION-LINE-15.                                              
                   15  ACTION-CC-15        PIC X      VALUE '0'.                
                   15  ACTION-15-GFO       PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
REN                15  ACTION-15-GROUP     PIC X(7)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE '-'.                 
                   15  ACTION-15-ACCT      PIC X(3)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
                   15  ACTION-15-BRANCH    PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X(91) VALUE                      
                ' - NO RENEWAL PREMIUM WAS PICKED UP FROM M/C.    RENEWA        
      -         'L COMPENSATION WILL NOT BE ADVANCED.'.                         
                   15  FILLER              PIC X(17) VALUE SPACES.              
                   15  FILLER              PIC X(03) VALUE '***'.               
                                                                                
               10  ACTION-LINE-16.                                              
                   15  ACTION-CC-16        PIC X      VALUE '0'.                
                   15  ACTION-16-GFO       PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
REN                15  ACTION-16-GROUP     PIC X(7)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE '-'.                 
                   15  ACTION-16-ACCT      PIC X(3)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
                   15  ACTION-16-BRANCH    PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X(85) VALUE                      
                ' - NO RENEWAL PREMIUM STORED.  VERIFY THAT NEXT RENEWAL        
      -         ' DATE ON M/C IS CORRECT.  '.                                   
                   15  FILLER              PIC X(23) VALUE SPACES.              
                   15  FILLER              PIC X(03) VALUE '***'.               
                                                                                
               10  ACTION-LINE-17.                                              
                   15  ACTION-CC-17        PIC X      VALUE '0'.                
                   15  ACTION-17-GFO       PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
REN                15  ACTION-17-GROUP     PIC X(7)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE '-'.                 
                   15  ACTION-17-ACCT      PIC X(3)  VALUE SPACES.              
                   15  FILLER              PIC X     VALUE SPACES.              
                   15  ACTION-17-BRANCH    PIC X(5)  VALUE SPACES.              
                   15  FILLER              PIC X(12) VALUE                      
                       ' - NEGATIVE '.                                          
                   15  ACTION-17-TYPE      PIC X(4)   VALUE SPACES.             
                   15  FILLER              PIC X(12)  VALUE                     
                       ' PREMIUM OF '.                                          
                   15  ACTION-17-PREMIUM   PIC ZZZ,ZZZ,ZZ9.99-.                 
                   15  FILLER              PIC X(24)  VALUE                     
                       '  LOADED AS ZEROES.'.                                   
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         COMMISSION HISTORY UPDATE - ERROR REPORT              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
                                                                                
       01  ERROR-RECORD-AREA.                                                   
                                                                                
           05  DLSW-ERRREC-REC.                                                 
               10  ERRREC-SYS022           VALUE 'SYS022'  PIC X(6).            
               10  ERRREC-RET-CODE  COMP-3 VALUE +0        PIC S9.              
               10  ERRREC-LINE             VALUE SPACES    PIC X(54).           
               10  ERRREC-RECSIZE          VALUE 54        PIC 9(5).            
               10  ERRREC-BLKSIZE          VALUE 27972     PIC 9(5).            
               10  ERRREC-FORMAT           VALUE 'F '      PIC X(2).            
               10  ERRREC-COUNT     COMP-3 VALUE +0        PIC S9(7).           
                                                                                
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         COMMISSION HISTORY UPDATE - UPDATE REPORT             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
                                                                                
       01  UPDATE-RECORD-AREA.                                                  
                                                                                
           05  DLSW-UPDREC-REC.                                                 
               10  UPDREC-SYS023           VALUE 'SYS023'  PIC X(6).            
               10  UPDREC-RET-CODE  COMP-3 VALUE +0        PIC S9.              
               10  UPDREC-LINE             VALUE SPACES    PIC X(80).           
               10  UPDREC-RECSIZE          VALUE 80        PIC 9(5).            
               10  UPDREC-BLKSIZE          VALUE 27920     PIC 9(5).            
               10  UPDREC-FORMAT           VALUE 'F '      PIC X(2).            
               10  UPDREC-COUNT     COMP-3 VALUE +0        PIC S9(7).           
                                                                                
           05  UPDREC-HEADER1.                                                  
               10  FILLER              PIC X(13) VALUE                          
                                                     'GC2VORUP-2'.              
               10  FILLER              PIC X(28) VALUE                          
                                        'MANUFACTURERS LIFE OF CANADA'.         
               10  FILLER              PIC X(18) VALUE SPACES.                  
               10  FILLER              PIC X(12)      VALUE                     
                                               'FILE DATE : '.                  
               10  UPDREC-FILE-DATE    PIC X(7)       VALUE SPACES.             
                                                                                
           05  UPDREC-HEADER2.                                                  
               10  FILLER              PIC X(13)      VALUE SPACES.             
               10  FILLER              PIC X(41)      VALUE                     
                           'COMMISSION HISTORY UPDATE - UPDATE REPORT'.         
               10  FILLER              PIC X(26)      VALUE SPACES.             
                                                                                
           05  UPDREC-HEADER3.                                                  
               10  UPDHDR-GFO              VALUE 'GFO   '  PIC X(6).            
               10  UPDHDR-GROUP-NUMBER     VALUE 'GROUP  ' PIC X(7).            
               10  UPDHDR-GROUP-ACCOUNT    VALUE 'ACC '    PIC X(4).            
               10  UPDHDR-BRANCH           VALUE 'BRNCH '  PIC X(6).            
               10  UPDHDR-RENEW-EFF-DATE   VALUE 'REN-EFF' PIC X(7).            
               10  FILLER                  VALUE SPACES    PIC X(2).            
               10  UPDHDR-REN-LIFE-AMT VALUE '    LIFE AMT' PIC X(12).          
               10  FILLER                  VALUE SPACES    PIC X(2).            
               10  UPDHDR-REN-LTD-AMT  VALUE '     LTD AMT' PIC X(12).          
               10  FILLER                  VALUE SPACES    PIC X(2).            
               10  UPDHDR-REN-A-S-AMT  VALUE '     A-S AMT' PIC X(12).          
               10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDHDR-ACC-EFFECTIVE VALUE 'ACC-EFF' PIC X(7).               
      *        10  UPDHDR-ACCT-EFF-DATE    VALUE SPACES    PIC X(7).            
                                                                                
           05  UPDREC-RECORD.                                                   
               10  UPDREC-GFO              VALUE SPACES    PIC X(5).            
               10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDREC-GROUP-NUMBER     VALUE SPACES    PIC X(7).            
      *        10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDREC-GROUP-ACCOUNT    VALUE SPACES    PIC X(3).            
               10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDREC-BRANCH           VALUE SPACES    PIC X(5).            
               10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDREC-RENEW-EFF-DATE   VALUE SPACES    PIC X(7).            
               10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDREC-REN-LIFE-AMT VALUE ZEROES PIC ---------9.99.          
               10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDREC-REN-LTD-AMT  VALUE ZEROES PIC ---------9.99.          
               10  FILLER                  VALUE SPACES    PIC X(1).            
               10  UPDREC-REN-A-S-AMT  VALUE ZEROES PIC ---------9.99.          
               10  FILLER                  VALUE SPACES    PIC X(1).            
      *        10  UPDREC-NEXT-ANNIVERSARY VALUE SPACES    PIC X(7).            
      *        10  FILLER                  VALUE SPACES    PIC X(5).            
               10  UPDREC-ACCT-EFF-DATE    VALUE SPACES    PIC X(7).            
                                                                                
      /                                                                         
      *01  GCOMGRE7.                                                            
           COPY GCOMGRE7.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - CONTROL RECORD DESCRIPTION.                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCNTL                                                               
CPYNME     COPY GCICNTL.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP RECORD DESCRIPTION                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - RENEWAL RECORD DESCRIPTION                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORRENEWAL                                                            
CPYNME     COPY GCIRNEWL.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GIPSY EXPANDED  MASTER                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORADG-WORK-RECORD                                                    
CPYNME     COPY GCRADGW.                                                        
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
FXXTOK                                '** GC2VORUP  W-S ENDS HERE **'.          
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO02'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GC2ADG                       PIC X(8)  VALUE 'GC2ADG'.           
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2VORUP'         TO FCCSPL-CURR-PGM.                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       000-MAINLINE.                                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                PROGRAM MAINLINE                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 100-INITIALIZE.                                              
           PERFORM 200-PROCESS-RECORDS THRU                                     
                   200-PROCESS-RECORDS-EXIT UNTIL                               
                   READ-RET-CODE > +0.                                          
           PERFORM 300-END-OF-JOB.                                              
                                                                                
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  LOGICAL-RECORD-NAME                           
                                  ICBM.                                         
                                                                                
           MOVE +1                   TO GACCDMA7-PS-FUNC.                       
           CALL 'GACCDMA7'        USING GACCDMA7-PS-PARMS                       
                                        GACCDMA7-PS-RETURN                      
                                        PSMASTE7.                               
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       100-INITIALIZE.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREA TO BE ACCESSED                              *         
      *     PRINT REPORT HEADING                                      *         
      *     FIRST INPUT RECORD IS A HEADER DATE RECORD                *         
      *     GET DATE CONTROL RECORD IN DATA BASE                      *         
      *     MODIFY CONTROL RECORD WITH THE HEADER DATE VALUE          *         
      *     READ FIRST PREMIUM EXTRACT RECORD (2ND INPUT RECORD)      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
FXXTOK     MOVE 'GC2VORUP'    TO ICBM-PROGRAM-NAME.                             
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
                                                                                
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2VORUP' TO PROGRAM-NAME.                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           PERFORM 900-READ-EXTRACT.                                            
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         GCEX-RENEW-EFF-DATE                               
MAN02                         ACTION-FILE-DATE.                                 
           PERFORM 600-ACTION-REPORT.                                           
                                                                                
      *%   OBTAIN FIRST GWCORCNTL WITHIN GW-COMP-AREA1.                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           MOVE GCEX-RENEW-EFF-DATE TO LAST-REN-PREM-RUN-DATE.                  
      *%   MODIFY GWCORCNTL.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           ADD 1 TO WS-REC-PROCESSED.                                           
                                                                                
           PERFORM 900-READ-EXTRACT.                                            
                                                                                
           IF  READ-RET-CODE = +4                                               
               MOVE '3' TO ACTION-SW                                            
               PERFORM 600-ACTION-REPORT                                        
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           MOVE ACTION-FILE-DATE TO UPDREC-FILE-DATE                            
           MOVE UPDREC-HEADER1   TO UPDREC-LINE.                                
           PERFORM 930-WRITE-UPDREC.                                            
           MOVE UPDREC-HEADER2   TO UPDREC-LINE.                                
           PERFORM 930-WRITE-UPDREC.                                            
           MOVE UPDREC-HEADER3   TO UPDREC-LINE.                                
           PERFORM 930-WRITE-UPDREC.                                            
                                                                                
       100-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       200-PROCESS-RECORDS.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  GET PSMASTER (VO OR GIPSY) TO OBTAIN THE POLICY YEAR.  *         
      *     -  IF THE POLICY YEAR IS EQUAL TO 1, THIS IS A NEW ISSUE  *         
      *        ACCOUNT FOR WHICH WE DO NOT WANT TO STORE RENEWAL      *         
      *        AMOUNTS.  PRINT A MESSAGE, DROP RECORD, AND GET NEXT   *         
      *        INPUT RECORD.                                          *         
      *     -  FIND GROUP-ACCOUNT OWNER                               *         
      *        IF NOT FOUND                                           *         
      *           PERFORM CREATE OWNER GROUP-ACCOUNT.                 *         
      *      - MODIFY OWNER GWCOGRACCT WITH RENEWAL EFFECTIVE DATE    *         
      *            AND SET THE RENEWAL ADVANCE INDICATOR TO 'N'       *         
      *     -  DELETE RENEWAL RECORDS SET.                            *         
      *     -  CREATE NEW RENEWAL RECORDS SET.                        *         
      *     -  READ NEXT INPUT RECORD.                                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  GCEX-REN-LIFE-AMT = ZERO                                         
           AND GCEX-REN-LTD-AMT = ZERO                                          
           AND GCEX-REN-A-S-AMT = ZERO                                          
           THEN                                                                 
               ADD +1 TO WS-WARNINGS                                            
               MOVE '6' TO ACTION-SW                                            
               PERFORM 600-ACTION-REPORT                                        
               GO TO 200-READ-NEXT-EXTRACT.                                     
                                                                                
           MOVE GCEX-GROUP-NUMBER TO WS-GROUP-NUMBER.                           
           MOVE LOW-VALUES       TO VOPSMASTER-RECORD.                          
           MOVE WS-NUM-GROUP-NUMBER TO WS-NUM-GROUP-NUM7.                       
           MOVE WS-NUM-GROUP-NUM7   TO VOPSM-GROUP-NUMBER.                      
           MOVE LR-VO-PSMASTER-R TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING OBTAIN-KEYED                                
                                    VOPSMASTER-RECORD                           
                                    ICBM.                                       
           IF LR-STATUS-OK                                                      
              MOVE VOPSM-POLICY-YEAR    TO WS-PSMPOLICY-YEAR                    
           ELSE                                                                 
FXXTOK        MOVE LOW-VALUES          TO PSMASTE7                              
              MOVE WS-NUM-GROUP-NUMBER TO GACCDMA7-PS-GROUP                     
              MOVE HIGH-VALUES         TO GACCDMA7-PS-ACCT                      
              CALL 'GACCDMA7'       USING GACCDMA7-PS-PARMS                     
                                          GACCDMA7-PS-RETURN                    
FXXTOK                                    PSMASTE7                              
              IF GACCDMA7-PS-RETURN = 'R01'                                     
                 ADD +1 TO WS-GPSY-RECS-NOT-FOUND                               
                 MOVE '5' TO ACTION-SW                                          
                 PERFORM 600-ACTION-REPORT                                      
                 GO TO 200-READ-NEXT-EXTRACT                                    
              ELSE                                                              
                 IF GACCDMA7-PS-RETURN NOT = SPACES                             
FXXTOK              GO TO 799-SQL-STATUS                                        
                 ELSE                                                           
                    MOVE PSMPOLICY-YEAR       TO WS-PSMPOLICY-YEAR.             
                                                                                
           IF WS-PSMPOLICY-YEAR EQUAL TO +1                                     
               ADD +1 TO WS-NEW-ISSUES-FOUND                                    
               MOVE '4' TO ACTION-SW                                            
               PERFORM 600-ACTION-REPORT                                        
               GO TO 200-READ-NEXT-EXTRACT.                                     
                                                                                
           MOVE GCEX-GROUP-NUMBER TO GROUP-NUMBER OF GWCORGRACCT.               
           MOVE GCEX-GROUP-ACCOUNT TO GROUP-ACCOUNT OF GWCORGRACCT.             
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                   PERFORM 400-CREATE-OWNER-RECORDS.                            
                                                                                
           MOVE GCEX-RENEW-EFF-DATE                                             
               TO RENEWAL-EFFECTIVE-DATE OF GWCORGRACCT.                        
           MOVE 'N' TO RENEW-COMP-ADVANCED-IND OF GWCORGRACCT.                  
      *%   MODIFY GWCORGRACCT.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   OBTAIN FIRST GWCORRENEWAL WITHIN GRACCT-RENEWAL                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 FCCSPL-GRACCT-RENEWAL                                     
MAN02                 GWCORRENEWAL                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           PERFORM 500-DELETE-RENEWALS                                          
               UNTIL DB-END-OF-SET.                                             
                                                                                
           PERFORM 210-PROCESS-LIFE THRU                                        
                   210-PROCESS-LIFE-EXIT.                                       
                                                                                
           PERFORM 220-PROCESS-LTD THRU                                         
                   220-PROCESS-LTD-EXIT.                                        
                                                                                
           PERFORM 230-PROCESS-A-S THRU                                         
                   230-PROCESS-A-S-EXIT.                                        
                                                                                
           ADD 1 TO WS-REC-PROCESSED.                                           
                                                                                
           PERFORM 240-BUILD-UPDREC THRU                                        
                   240-BUILD-UPDREC-EXIT.                                       
                                                                                
           PERFORM 930-WRITE-UPDREC.                                            
                                                                                
       200-READ-NEXT-EXTRACT.                                                   
           PERFORM 900-READ-EXTRACT.                                            
                                                                                
       200-PROCESS-RECORDS-EXIT.                                                
           EXIT.                                                                
      /                                                                         
       210-PROCESS-LIFE.                                                        
      *****************************************************************         
      *   UPDATE LIFE RENEWAL AMOUNT.                                           
      *   NEGATIVE PREMIUM IS UPDATED AS ZERO. HILITE MESSAGE OUTPUT.           
      *****************************************************************         
           IF  GCEX-REN-LIFE-AMT = ZERO                                         
               GO TO 210-PROCESS-LIFE-EXIT.                                     
                                                                                
           MOVE 'T'                   TO COV-TYPE OF GWCORRENEWAL.              
           IF  GCEX-REN-LIFE-AMT < +0.00                                        
               MOVE +0.00             TO RENEWAL-AMOUNT OF GWCORRENEWAL         
               MOVE '8'               TO ACTION-SW                              
               PERFORM 600-ACTION-REPORT                                        
           ELSE                                                                 
               MOVE GCEX-REN-LIFE-AMT TO RENEWAL-AMOUNT OF GWCORRENEWAL.        
                                                                                
      *%   STORE GWCORRENEWAL.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 GWCORRENEWAL                                              
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
       210-PROCESS-LIFE-EXIT.                                                   
           EXIT.                                                                
                                                                                
       220-PROCESS-LTD.                                                         
      *****************************************************************         
      *   UPDATE LTD RENEWAL AMOUNT.                                            
      *   NEGATIVE PREMIUM IS UPDATED AS ZERO. HILITE MESSAGE OUTPUT.           
      *****************************************************************         
           IF  GCEX-REN-LTD-AMT = ZERO                                          
               GO TO 220-PROCESS-LTD-EXIT.                                      
                                                                                
           MOVE 'L'                   TO COV-TYPE OF GWCORRENEWAL.              
           IF  GCEX-REN-LTD-AMT < +0.00                                         
               MOVE +0.00             TO RENEWAL-AMOUNT OF GWCORRENEWAL         
               MOVE '8'               TO ACTION-SW                              
               PERFORM 600-ACTION-REPORT                                        
           ELSE                                                                 
               MOVE GCEX-REN-LTD-AMT  TO RENEWAL-AMOUNT OF GWCORRENEWAL.        
                                                                                
      *%   STORE GWCORRENEWAL.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 GWCORRENEWAL                                              
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
       220-PROCESS-LTD-EXIT.                                                    
           EXIT.                                                                
                                                                                
       230-PROCESS-A-S.                                                         
      *****************************************************************         
      *   UPDATE A-S RENEWAL AMOUNT.                                            
      *   NEGATIVE PREMIUM IS UPDATED AS ZERO. HILITE MESSAGE OUTPUT.           
      *****************************************************************         
           IF  GCEX-REN-A-S-AMT = ZERO                                          
               GO TO 230-PROCESS-A-S-EXIT.                                      
                                                                                
           MOVE 'O'                   TO COV-TYPE OF GWCORRENEWAL.              
           IF  GCEX-REN-A-S-AMT < +0.00                                         
               MOVE +0.00             TO RENEWAL-AMOUNT OF GWCORRENEWAL         
               MOVE '8'               TO ACTION-SW                              
               PERFORM 600-ACTION-REPORT                                        
           ELSE                                                                 
               MOVE GCEX-REN-A-S-AMT  TO RENEWAL-AMOUNT OF GWCORRENEWAL.        
                                                                                
      *%   STORE GWCORRENEWAL.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 GWCORRENEWAL                                              
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
       230-PROCESS-A-S-EXIT.                                                    
           EXIT.                                                                
      /                                                                         
       240-BUILD-UPDREC.                                                        
      *****************************************************************         
      *   BUILD RECORD FOR THE UPDATE REPORT.                                   
      *****************************************************************         
                                                                                
           CALL QDATEQ2 USING QDATE-FORMATC                                     
                              GCEX-RENEW-EFF-DATE                               
                              UPDREC-RENEW-EFF-DATE.                            
                                                                                
      *    CALL QDATEQ2 USING QDATE-FORMATC                                     
      *                       GCEX-NEXT-ANNIVERSARY                             
      *                       UPDREC-NEXT-ANNIVERSARY.                          
                                                                                
           CALL QDATEQ2 USING QDATE-FORMATC                                     
                              GCEX-ACCT-EFF-DATE                                
                              UPDREC-ACCT-EFF-DATE.                             
                                                                                
           MOVE GCEX-GFO              TO    UPDREC-GFO.                         
           MOVE GCEX-GROUP-NUMBER     TO    UPDREC-GROUP-NUMBER.                
           MOVE GCEX-GROUP-ACCOUNT    TO    UPDREC-GROUP-ACCOUNT.               
           MOVE GCEX-BRANCH           TO    UPDREC-BRANCH.                      
           MOVE GCEX-REN-LIFE-AMT     TO    UPDREC-REN-LIFE-AMT.                
           MOVE GCEX-REN-LTD-AMT      TO    UPDREC-REN-LTD-AMT.                 
           MOVE GCEX-REN-A-S-AMT      TO    UPDREC-REN-A-S-AMT.                 
                                                                                
           MOVE UPDREC-RECORD TO UPDREC-LINE.                                   
                                                                                
       240-BUILD-UPDREC-EXIT.                                                   
           EXIT.                                                                
      /                                                                         
       300-END-OF-JOB.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  PRINT CONTROL TOTALS ON REPORT                         *         
      *     -  CLOSE REPORT FILE                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE WS-REC-PROCESSED TO ACTION-REC-PROCESSED.                       
           MOVE ACTION-LINE-6 TO ACTION-LINE.                                   
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           IF WS-GPSY-RECS-NOT-FOUND GREATER THAN ZERO                          
           THEN                                                                 
               MOVE WS-GPSY-RECS-NOT-FOUND TO ACTION-REC-CNT-7                  
               MOVE ACTION-LINE-7 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF WS-NEW-ISSUES-FOUND GREATER THAN ZERO                             
           THEN                                                                 
               MOVE WS-NEW-ISSUES-FOUND TO ACTION-REC-CNT-8                     
               MOVE ACTION-LINE-8 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF WS-WARNINGS GREATER THAN ZERO                                     
           THEN                                                                 
               MOVE WS-WARNINGS TO ACTION-REC-CNT-9                             
               MOVE ACTION-LINE-9 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           MOVE '-* * * END OF REPORT * * *' TO ACTION-LINE.                    
           PERFORM 910-WRITE-ACTION.                                            
           MOVE +4 TO ACTION-RET-CODE.                                          
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE +4 TO ERRREC-RET-CODE.                                          
           PERFORM 920-WRITE-ERRREC.                                            
                                                                                
           MOVE SPACES TO UPDREC-LINE.                                          
           IF UPDREC-COUNT = +3                                                 
               MOVE '* * * NO UPDATES * * *' TO UPDREC-LINE                     
           ELSE                                                                 
               MOVE '* * * END OF REPORT * * *' TO UPDREC-LINE.                 
           PERFORM 930-WRITE-UPDREC.                                            
           MOVE +4 TO UPDREC-RET-CODE.                                          
           PERFORM 930-WRITE-UPDREC.                                            
                                                                                
      /                                                                         
       400-CREATE-OWNER-RECORDS.                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    -  SET WORK AREA                                           *         
      *    -  CALL GWCOCADG TO STORE RECORDS                          *         
      *    -  PRODUCE ACTION-REPORT.                                            
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE SPACES                TO GWCORADG-WORK-RECORD.                  
           MOVE GCEX-GROUP-NUMBER     TO GWCOEADG-W-GROUP-NUMBER.               
           MOVE GCEX-GROUP-ACCOUNT    TO GWCOEADG-W-GR-ACCOUNT.                 
           MOVE GCEX-ACCT-EFF-DATE    TO GWCOEADG-W-ACCT-EFF-DATE.              
           MOVE GCEX-RENEW-EFF-DATE   TO GWCOEADG-W-NEXT-RENEW-DATE.            
           ADD  +1                    TO GWCOEADG-W-NEXT-RENEW-YEAR.            
MAN02      CALL GC2ADG     USING DBLINK-SUBSCHEMA-CONTROL                       
MAN02                            DBLINK-RECORD-SET-KEYS                         
MAN02                            DBLINK-CURSOR-CODES                            
MAN02                            GWCORGROUP                                     
MAN02                            GWCORGRACCT                                    
MAN02                            GWCORADG-WORK-RECORD.                          
                                                                                
FXXTOK     MOVE 'GC2VORUP' TO PROGRAM-NAME.                                     
           MOVE GWCOEADG-W-ACTION-SWITCH TO ACTION-SW.                          
           PERFORM 600-ACTION-REPORT.                                           
                                                                                
       409-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       500-DELETE-RENEWALS.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    -  DELETE CURRENT RECORD                                   *         
      *    -  OBTAIN NEXT RECORD                                      *         
      *    -  LOOP AROUND UNTIL END-OF-SET.                           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   ERASE GWCORRENEWAL.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +5  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-DELETE                                             
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 FCCSPL-RESTRICT                                           
MAN02                 GWCORRENEWAL                                              
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   OBTAIN NEXT GWCORRENEWAL WITHIN GRACCT-RENEWAL                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 FCCSPL-GRACCT-RENEWAL                                     
MAN02                 GWCORRENEWAL                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       509-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       600-ACTION-REPORT.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   IF  ACTION-SW HAS A VALUE OF:                               *         
      *    0   = NO ACTION      -  PRINT HEADINGS                     *         
      *    1   - NEW-GROUP      -  NEW GROUP RECORD ADDED             *         
      *    1,2 - NEW-ACCOUNT    -  NEW ACCT RECORD ADDED              *         
      *    3   - NO-INPUT       -  EOF ON FIRST ATTEMP TO READ        *         
      *    4   - NEW ISSUE      -  NO RENEWAL INFORMATION STORED      *         
      *    5   - NO POINT IN SCALE - NO RENEWAL INFORMATION STORED    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  NO-ACTION                                                        
               MOVE ACTION-HDG-1 TO ACTION-LINE                                 
               PERFORM 910-WRITE-ACTION                                         
               MOVE ACTION-HDG-2 TO ACTION-LINE                                 
               PERFORM 910-WRITE-ACTION                                         
               MOVE ACTION-HDG-3 TO ACTION-LINE                                 
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NEW-GROUP                                                        
               MOVE GCEX-GFO           TO ACTION-1-GFO                          
               MOVE GCEX-GROUP-NUMBER  TO ACTION-1-GROUP                        
               MOVE GCEX-GROUP-ACCOUNT TO ACTION-1-ACCT                         
               MOVE GCEX-BRANCH        TO ACTION-1-BRANCH                       
               MOVE ACTION-LINE-1      TO ACTION-LINE                           
               MOVE '2'                TO ACTION-SW                             
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NEW-ACCOUNT                                                      
               MOVE ACTION-LINE-2 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION                                         
               MOVE GCEX-GFO           TO ACTION-ADD-GFO                        
               MOVE GCEX-GROUP-NUMBER  TO ACTION-ADD-GROUP                      
               MOVE GCEX-GROUP-ACCOUNT TO ACTION-ADD-ACCT                       
               MOVE GCEX-BRANCH        TO ACTION-ADD-BRANCH                     
               MOVE GWCOEADG-W-ACCT-EFF-DATE-EXT                                
                   TO ACTION-ADD-ACCT-EFFECTIVE                                 
               MOVE GWCOEADG-W-NEXT-RENEW-DATE-EXT                              
                   TO ACTION-ADD-RENEWAL                                        
               MOVE GWCOEADG-W-NEXT-RECON-DATE-EXT                              
                   TO ACTION-ADD-NEXT-DATE                                      
               MOVE GWCOEADG-W-LAST-RECON-DATE-EXT                              
                   TO ACTION-ADD-LAST-DATE                                      
               MOVE ACTION-LINE-10 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NO-INPUT                                                         
               MOVE ACTION-LINE-11 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  FIRST-YEAR-GROUP                                                 
               MOVE GCEX-GFO           TO ACTION-13-GFO                         
               MOVE GCEX-GROUP-NUMBER  TO ACTION-13-GROUP                       
               MOVE GCEX-GROUP-ACCOUNT TO ACTION-13-ACCT                        
               MOVE GCEX-BRANCH        TO ACTION-13-BRANCH                      
               MOVE ACTION-LINE-13 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NO-POINT-IN-SCALE                                                
               MOVE GCEX-GFO           TO ACTION-14-GFO                         
               MOVE GCEX-GROUP-NUMBER  TO ACTION-14-GROUP                       
               MOVE GCEX-GROUP-ACCOUNT TO ACTION-14-ACCT                        
               MOVE GCEX-BRANCH        TO ACTION-14-BRANCH                      
               MOVE ACTION-LINE-14 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION                                         
               MOVE GCOMGRE7 TO ERRREC-LINE                                     
               PERFORM 920-WRITE-ERRREC.                                        
                                                                                
           IF  NO-RENEWAL-AMOUNTS                                               
               MOVE GCEX-GFO           TO ACTION-15-GFO                         
               MOVE GCEX-GROUP-NUMBER  TO ACTION-15-GROUP                       
               MOVE GCEX-GROUP-ACCOUNT TO ACTION-15-ACCT                        
               MOVE GCEX-BRANCH        TO ACTION-15-BRANCH                      
               MOVE ACTION-LINE-15 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NOT-CURRENT-RENEWAL                                              
               MOVE GCEX-GFO           TO ACTION-16-GFO                         
               MOVE GCEX-GROUP-NUMBER  TO ACTION-16-GROUP                       
               MOVE GCEX-GROUP-ACCOUNT TO ACTION-16-ACCT                        
               MOVE GCEX-BRANCH        TO ACTION-16-BRANCH                      
               MOVE ACTION-LINE-16 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NEGATIVE-PREMIUMS                                                
               MOVE GCEX-GFO                TO ACTION-17-GFO                    
               MOVE GCEX-GROUP-NUMBER       TO ACTION-17-GROUP                  
               MOVE GCEX-GROUP-ACCOUNT      TO ACTION-17-ACCT                   
               MOVE GCEX-BRANCH             TO ACTION-17-BRANCH                 
               IF  COV-TYPE OF GWCORRENEWAL = 'T'                               
                   MOVE 'LIFE'              TO ACTION-17-TYPE                   
                   MOVE GCEX-REN-LIFE-AMT   TO ACTION-17-PREMIUM                
               ELSE                                                             
               IF  COV-TYPE OF GWCORRENEWAL = 'L'                               
                   MOVE 'LTD '              TO ACTION-17-TYPE                   
                   MOVE GCEX-REN-LTD-AMT    TO ACTION-17-PREMIUM                
               ELSE                                                             
               IF  COV-TYPE OF GWCORRENEWAL = 'O'                               
                   MOVE 'A-S '              TO ACTION-17-TYPE                   
                   MOVE GCEX-REN-A-S-AMT    TO ACTION-17-PREMIUM                
               ELSE                                                             
                   MOVE '????'              TO ACTION-17-TYPE                   
                   MOVE -0.00               TO ACTION-17-PREMIUM.               
           IF  NEGATIVE-PREMIUMS                                                
               MOVE ACTION-LINE-17          TO ACTION-LINE                      
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           MOVE '0' TO ACTION-SW.                                               
                                                                                
       600-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *       FOLLOWING ROUTINES PERFORM READS-WRITES OF I-O FILES    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       900-READ-EXTRACT.                                                        
                                                                                
           CALL 'DLSREAD' USING READ-SYS010                                     
                                READ-RET-CODE                                   
                                GCOMGRE7                                        
                                READ-RECSIZE                                    
                                READ-BLKSIZE                                    
                                READ-FORMAT                                     
                                READ-REC-CNT.                                   
                                                                                
           IF  READ-RET-CODE GREATER THAN +4                                    
               MOVE 'READ' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
       910-WRITE-ACTION.                                                        
                                                                                
           CALL 'DLSWRITE' USING ACTION-SYS021                                  
                                 ACTION-RET-CODE                                
                                 ACTION-LINE                                    
                                 ACTION-RECSIZE                                 
                                 ACTION-BLKSIZE                                 
                                 ACTION-FORMAT                                  
                                 ACTION-COUNT.                                  
                                                                                
           IF  ACTION-RET-CODE GREATER THAN +4                                  
               MOVE 'WRTE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
      /                                                                         
       920-WRITE-ERRREC.                                                        
                                                                                
           CALL 'DLSWRITE' USING ERRREC-SYS022                                  
                                 ERRREC-RET-CODE                                
                                 ERRREC-LINE                                    
                                 ERRREC-RECSIZE                                 
                                 ERRREC-BLKSIZE                                 
                                 ERRREC-FORMAT                                  
                                 ERRREC-COUNT.                                  
                                                                                
           IF  ERRREC-RET-CODE GREATER THAN +4                                  
               MOVE 'WRTE' TO ERROR-STATUS                                      
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
       920-EXIT.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       930-WRITE-UPDREC.                                                        
                                                                                
           CALL 'DLSWRITE' USING UPDREC-SYS023                                  
                                 UPDREC-RET-CODE                                
                                 UPDREC-LINE                                    
                                 UPDREC-RECSIZE                                 
                                 UPDREC-BLKSIZE                                 
                                 UPDREC-FORMAT                                  
                                 UPDREC-COUNT.                                  
                                                                                
           IF  UPDREC-RET-CODE GREATER THAN +4                                  
               MOVE 'WRTE' TO ERROR-STATUS                                      
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
       930-EXIT.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
