       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.  GWFSPLO1.                                                   
       AUTHOR.      FORECROSS CORPORATION.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *             I/O SPLITTING - ONLINE VERSION                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------*        
      *               RECORD XXXX1 BEGIN-WORKING-STORAGE               *        
      *----------------------------------------------------------------*        
       01  XXXX1-BEGIN-WORKING-STORAGE.                                         
               10  XXXX1-CONST-1            PIC X(32)                           
FXXTOK                 VALUE '** GWFSPLO1 WORKING STRG BEGINS'.                 
                                                                                
      *----------------------------------------------------------------*        
      *                RECORD XXCPYRGT COPYRIGHT-NOTICE                *        
      *----------------------------------------------------------------*        
       01  XXCPYRGT-COPYRIGHT-NOTICE.                                           
               10  FILLER                  PIC X(32)                            
                       VALUE 'COPYRIGHT 2000-2010   FORECROSS '.                
               10  FILLER                  PIC X(32)                            
                       VALUE 'CORPORATION. ALL RIGHTS RESERVED'.                
                                                                                
       01  WS-SAVE-DEBUG-FLAG               PIC X.                              
       01  WS-SQLCODE-DEBUG-DISPLAY         PIC -999.                           
       01  WS-99-DISPLAY                    PIC 99.                             
       01  WS-SUB1                          PIC 999.                            
       01  WS-SUB2                          PIC 999.                            
       01  WS-LINK-MODULE-NAME              PIC X(8).                           
       01  WS-IDMS-MAJOR-CODE               PIC XX   VALUE '14'.                
       01  WS-99999999-DISPLAY              PIC 99999999.                       
       01  WS-SQLCODE-DISPLAY.                                                  
           05  FILLER                       PIC X    VALUE '9'.                 
           05  WS-SQLCODE-NUMERIC           PIC 999.                            
       01  WS-RECORD-RELATED-FLAG           PIC X    VALUE 'N'.                 
           88  WS-RECORD-RELATED-YES                 VALUE 'Y'.                 
           88  WS-RECORD-RELATED-NO                  VALUE 'N'.                 
       01  WS-ABSTIME                       PIC S9(15)        COMP-3.           
       01  WS-SAVE-RECORD-NAME              PIC X(16).                          
       01  SPLITTER-TRACE-LINE1.                                                
           05  FILLER                       PIC X(19)      VALUE                
               'TRACE1, DATE/TIME: '.                                           
           05  SPLTRACE-TRACE-DATE          PIC X(10).                          
           05  FILLER                       PIC X    VALUE SPACES.              
           05  SPLTRACE-TRACE-TIME          PIC X(8).                           
           05  FILLER                       PIC X(19)      VALUE                
               ', CALLING PROGRAM: '.                                           
           05  SPLTRACE-CALLING-PROGRAM     PIC X(8).                           
       01  SPLITTER-TRACE-LINE2.                                                
           05  FILLER                       PIC X(16)      VALUE                
               'TRACE2, METHOD: '.                                              
           05  SPLTRACE-METHOD              PIC X(26).                          
           05  FILLER                       PIC X(14)      VALUE                
               ', DML SEQ NO: '.                                                
           05  SPLTRACE-DML-SEQ-NO          PIC ZZZ9.                           
       01  SPLITTER-TRACE-LINE3.                                                
           05  FILLER                       PIC X(29)      VALUE                
               'TRACE3, RETURN FROM I/O MOD: '.                                 
           05  SPLTRACE-I-O-MODULE          PIC X(8).                           
           05  FILLER                       PIC X(11)      VALUE                
               ', ERRSTAT: '.                                                   
           05  SPLTRACE-ERROR-STATUS        PIC X(4).                           
           05  FILLER                       PIC X(11)      VALUE                
               ', SQLCODE: '.                                                   
           05  SPLTRACE-SQLCODE             PIC -999.                           
       01  SPLITTER-TRACE-LINE4.                                                
           05  FILLER                       PIC X(16)      VALUE                
               'TRACE4, RECORD: '.                                              
           05  SPLTRACE-RECORD-NAME         PIC X(16).                          
           05  SPLTRACE-ERROR-MSG-LITERAL   PIC X(13)      VALUE                
               ', ERROR MSG: '.                                                 
           05  SPLTRACE-ERROR-MESSAGE       PIC X(80).                          
       01  SPLITTER-ERROR-AREA-0            PIC X(72) VALUE                     
           'SPLITTER ERROR - INFORMATION ON FOLLOWING 5 LINES:'.                
       01  SPLITTER-ERROR-AREA-1.                                               
           05  FILLER                       PIC X(3) VALUE '1  '.               
           05  SPERR-DATE                   PIC X(10).                          
           05  FILLER                       PIC X    VALUE SPACES.              
           05  SPERR-TIME                   PIC X(8).                           
           05  FILLER                       PIC X(11)                           
                                                VALUE ' EIBTRMID: '.            
           05  SPERR-EIBTRMID               PIC X(4).                           
           05  FILLER                       PIC X(9) VALUE ' USERID: '.         
           05  SPERR-USERID                 PIC X(8).                           
           05  FILLER                       PIC X(6) VALUE ' PGM: '.            
           05  SPERR-PROGRAM-NAME           PIC X(8).                           
       01  SPLITTER-ERROR-AREA-2.                                               
           05  FILLER                       PIC X(12)                           
                                                VALUE '2  DML SEQ#:'.           
           05  SPERR-DML-SEQ-NO             PIC ZZZ9.                           
           05  FILLER                       PIC X(6) VALUE ' REC: '.            
           05  SPERR-RECORD-NAME            PIC X(16).                          
           05  FILLER                       PIC X(6) VALUE ' SET: '.            
           05  SPERR-SET-NAME               PIC X(16).                          
       01  SPLITTER-ERROR-AREA-3.                                               
           05  FILLER                       PIC X(8) VALUE '3  ERR: '.          
           05  SPERR-ERROR-MESSAGE          PIC X(65).                          
       01  SPLITTER-ERROR-AREA-4.                                               
           05  FILLER                       PIC X(3) VALUE '4  '.               
           05  FILLER                       PIC X(8) VALUE 'METHOD: '.          
           05  SPERR-METHOD-NAME            PIC X(20).                          
           05  FILLER                       PIC X(10)                           
                                                VALUE ' ERRSTAT: '.             
           05  SPERR-ERROR-STATUS           PIC X(4).                           
           05  FILLER                       PIC X(9)                            
                                                VALUE ' SQLCODE:'.              
           05  SPERR-SQLCODE                PIC -ZZZ9.                          
       01  SPLITTER-ERROR-AREA-5.                                               
           05  FILLER                       PIC X(13)                           
                                            VALUE '5  SQLERRMC: '.              
           05  SPERR-SQLERRMC-AREA.                                             
               10  SPERR-SQLERRMC           PIC X                               
                   OCCURS 0 TO 70 TIMES                                         
                   DEPENDING ON SPERR-SQLERRML.                                 
       01  SPERR-SQLERRML       VALUE 70    PIC S9(4) COMP.                     
       01  WS-SQLCODE-ERROR-DISPLAY         PIC -ZZZ9.                          
                                                                                
      * FCCMODNM                                                                
CPYNME     COPY GWFMODN1.                                                       
                                                                                
           COPY GWFCRCD1 REPLACING DBLINK-CURSOR-CODES BY                       
           WS-CURSOR-CODES-BASE.                                                
      * PAD GCOM & GIPC CURSOR-CD REC TO SAME LEN AS GRID CURSOR-CD REC         
           10  WS-PAD-FOR-JUMP1             PIC X(326) VALUE SPACES.            
                                                                                
           COPY GWFCRCD1 REPLACING DBLINK-CURSOR-CODES BY                       
           WS-CURSOR-CODES-SAVE.                                                
           10  WS-PAD-FOR-JUMP2             PIC X(326) VALUE SPACES.            
                                                                                
       02  WS-EIBTASKN-SAVE                 PIC S9(7)        COMP-3             
                                            VALUE ZEROS.                        
       02  WS-EIBTASKN-WORK-X.                                                  
           05  WS-EIBTASKN-WORK             PIC S9(7)        COMP-3             
                                            VALUE ZEROS.                        
       02  WS-EIBTRMID                      PIC X(4)   VALUE SPACES.            
       01  FCC-USERID                       PIC X(8).                           
       01  SPLTRACE-LINE.                                                       
           05  SPLTRACE-PREFIX              PIC X(6).                           
           05  SPLTRACE-SPLITTER-SEQ-NO     PIC 999    VALUE ZERO.              
           05  FILLER                       PIC XXX    VALUE SPACES.            
           05  SPLTRACE-PROGRAM-NAME        PIC X(8).                           
           05  FILLER                       PIC X      VALUE '/'.               
           05  SPLTRACE-DML-SEQ-NOX         PIC 999.                            
           05  FILLER                       PIC X      VALUE SPACES.            
           05  SPLTRACE-METHOD-NAME         PIC X(26).                          
           05  FILLER                       PIC X(12)  VALUE                    
               ' SQLCODE/E-S'.                                                  
           05  SPLTRACE-SQLCODEX-GROUP.                                         
               10  SPLTRACE-SQLCODEX        PIC -999.                           
           05  FILLER                       PIC X      VALUE '/'.               
           05  SPLTRACE-ERROR-STATUSX-GROUP.                                    
               10  SPLTRACE-ERROR-STATUSX   PIC XXXX.                           
       01  FCC-CURSORCODE-TS-ID             PIC X(8)   VALUE '    CCOD'.        
       01  FCC-NUMITEMS                     PIC S9(4)         COMP.             
                                                                                
           EXEC SQL                                                             
               INCLUDE SQLCA                                                    
           END-EXEC.                                                            
*******    EXEC SQL                                                             
*******        INCLUDE CBCVDBKW                                                 
*******    END-EXEC.                                                            
      * CBCVDBLT                                                                
CPYNME     EXEC SQL INCLUDE GWTFCKEP END-EXEC.                                  
                                                                                
           COPY DFHAID.                                                         
           COPY DFHBMSCA.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *                RECORD XXXX2 END-WORKING-STORAGE                *        
      *----------------------------------------------------------------*        
       01  XXXX2-END-WORKING-STORAGE.                                           
               10  XXXX2-CONST-2            PIC X(32)                           
FXXTOK                 VALUE '** GWFSPLO1 WORKING STRG ENDS'.                   
                                                                                
       LINKAGE SECTION.                                                         
       01  DBLINK-SUBSCHEMA-CONTROL.                                            
           20  DBLINK-IDMS-SUBSCHEMA-CONTROL                                    
                                            PIC X(512).                         
      * CBCVDBSS                                                                
CPYNME     EXEC SQL INCLUDE GWFCVDBS END-EXEC.                                  
                                                                                
      * FCCSPLCA                                                                
CPYNME     COPY GWFCSPLC.                                                       
                                                                                
      * CBRSKEYS                                                                
CPYNME     EXEC SQL INCLUDE GWFRSKY1 END-EXEC.                                  
                                                                                
      * CBCURCOD                                                                
CPYNME     EXEC SQL INCLUDE GWFCRCD1 END-EXEC.                                  
                                                                                
       01  LS-METHOD-NAME                   PIC X(40).                          
       01  LS-I-O-MODULE-NAME               PIC X(8).                           
       01  LS-DBKEY                         PIC S9(8)         COMP.             
       01  LS-STRING-8                      PIC X(8).                           
       01  LS-STRING-16                     PIC X(16).                          
       01  LS-SORTKEY                       PIC X(200).                         
       01  LS-DBKEY-WORK                    PIC S9(8)         COMP.             
                                                                                
       PROCEDURE DIVISION USING DFHEIBLK                                        
                                DFHCOMMAREA                                     
                                DBLINK-SUBSCHEMA-CONTROL                        
                                DBLINK-RECORD-SET-KEYS                          
                                DBLINK-CURSOR-CODES.                            
                                                                                
      *----------------------------------------------------------------*        
      *             000-DRIVER ROUTINE                                 *        
      *----------------------------------------------------------------*        
       000-DRIVER SECTION.                                                      
                                                                                
           PERFORM 020-INITIALIZE.                                              
           PERFORM 040-MAINLINE.                                                
           PERFORM 990-RETURN.                                                  
                                                                                
       000-DRIVER-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             020-INITIALIZE ROUTINE                             *        
      *----------------------------------------------------------------*        
       020-INITIALIZE SECTION.                                                  
                                                                                
           SET ADDRESS OF LS-METHOD-NAME TO FCCSPL-ADDR-METHOD.                 
           SET ADDRESS OF LS-I-O-MODULE-NAME                                    
               TO FCCSPL-ADDR-I-O-MODULE                                        
           MOVE 'N' TO FCCSPL-EVALUATE-ERROR-FLAG.                              
           INITIALIZE  FCCSPL-ERROR-MESSAGE.                                    
           MOVE SPACES TO FCCSPL-RECORD-NAME.                                   
           MOVE SPACES TO FCCSPL-SET-NAME.                                      
           MOVE ZERO TO FCCSPL-IOMOD-SQLCODE.                                   
           MOVE ZERO TO FCCSPLLK-SQLCODE.                                       
           MOVE ZERO TO ERROR-STATUS.                                           
                                                                                
           PERFORM 060-CHECK-ADDRESSES.                                         
                                                                                
       020-INITIALIZE-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             040-MAINLINE ROUTINE                               *        
      *----------------------------------------------------------------*        
       040-MAINLINE SECTION.                                                    
                                                                                
           IF FCCSPL-ONLINE-DEBUG-TRACE                                         
               PERFORM 986-WRITE-TRACE-QUEUE                                    
           END-IF.                                                              
           MOVE '0' TO FCCSPL-RETURN-CODE.                                      
           MOVE LS-METHOD-NAME TO FCCSPL-METHOD-NAME.                           
           MOVE FCCSPL-PROGRAM-NAME TO SPLTRACE-PROGRAM-NAME.                   
           MOVE FCCSPL-DML-SEQ-NO TO SPLTRACE-DML-SEQ-NOX.                      
           MOVE FCCSPL-METHOD-NAME TO SPLTRACE-METHOD-NAME.                     
           EXEC CICS                                                            
               ASSIGN USERID(FCC-USERID)                                        
           END-EXEC.                                                            
                                                                                
      * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *         
      * SUPPORT FOR LU AND MQ BACK-END PROGRAMS.                                
      * MUST DEFAULT EIBTRMID TO SOMETHING UNIQUE. IT WILL BE LOW-VAL           
      * IF SPLITTER INVOKED BY LU OR MQ BACK-END PROGRAM.                       
           IF EIBTRMID = LOW-VALUES                                             
               MOVE EIBTASKN TO WS-EIBTASKN-WORK                                
               MOVE WS-EIBTASKN-WORK-X TO WS-EIBTRMID                           
             ELSE                                                               
               MOVE EIBTRMID TO WS-EIBTRMID                                     
           END-IF                                                               
      * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *         
           MOVE WS-EIBTRMID TO FCC-CURSORCODE-TS-ID(1:4)                        
           EXEC CICS                                                            
               READQ TS                                                         
               QUEUE (FCC-CURSORCODE-TS-ID)                                     
               INTO  (WS-CURSOR-CODES-SAVE)                                     
               ITEM  (1)                                                        
               RESP(FCCSPL-CICS-RESP)                                           
               LENGTH(LENGTH OF WS-CURSOR-CODES-SAVE)                           
           END-EXEC                                                             
           IF FCCSPL-CICS-RESP = DFHRESP(QIDERR)                                
               MOVE WS-CURSOR-CODES-BASE TO DBLINK-CURSOR-CODES                 
               GO TO 040-EVALUATE                                               
           END-IF                                                               
           IF FCCSPL-CICS-RESP = DFHRESP(LENGERR)                               
               MOVE WS-CURSOR-CODES-BASE TO DBLINK-CURSOR-CODES                 
             ELSE                                                               
           IF FCCSPL-CICS-RESP NOT = DFHRESP(NORMAL)                            
               MOVE FCCSPL-CICS-RESP TO WS-99999999-DISPLAY                     
               MOVE SPACES TO FCCSPL-ERROR-MESSAGE                              
               STRING 'FC READQ TS, INVALID RETURN, CICS-RESP = '               
                       DELIMITED BY SIZE                                        
                   WS-99999999-DISPLAY                                          
                       DELIMITED BY SIZE                                        
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 980-ABORT                                                
               GO TO 040-MAINLINE-EXIT                                          
           END-IF                                                               
           END-IF                                                               
           EXEC CICS                                                            
               DELETEQ TS                                                       
               QUEUE (FCC-CURSORCODE-TS-ID)                                     
               RESP(FCCSPL-CICS-RESP)                                           
           END-EXEC                                                             
           IF FCCSPL-CICS-RESP NOT = DFHRESP(NORMAL)                            
               MOVE FCCSPL-CICS-RESP TO WS-99999999-DISPLAY                     
               MOVE SPACES TO FCCSPL-ERROR-MESSAGE                              
               STRING 'FC DELETEQ TS, INVALID RETURN, CICS-RESP = '             
                       DELIMITED BY SIZE                                        
                   WS-99999999-DISPLAY                                          
                       DELIMITED BY SIZE                                        
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 980-ABORT                                                
               GO TO 040-MAINLINE-EXIT                                          
           END-IF.                                                              
                                                                                
           IF WS-EIBTASKN-SAVE NOT = EIBTASKN                                   
               MOVE WS-CURSOR-CODES-BASE TO DBLINK-CURSOR-CODES                 
           ELSE                                                                 
               MOVE WS-CURSOR-CODES-SAVE TO DBLINK-CURSOR-CODES                 
           END-IF.                                                              
                                                                                
       040-EVALUATE.                                                            
                                                                                
      **********************************                                        
      *    PREVENT THE USE OF UNINITIALIZED KEYS WHICH CAN OCCUR IF THE         
      *    TOP ADS DIALOG DOES NOT CONTAIN ANY DML AND PERHAPS OTHER            
      *    PLACES                                                               
      **********************************                                        
           IF DBLINK-KEYS-INIT-REQD                                             
               MOVE SPACES TO DBLINK-RECORD-KEYS                                
               MOVE LOW-VALUES TO DBLINK-SET-KEYS                               
               MOVE SPACES TO DBLINK-SET-FLAGS                                  
               MOVE LOW-VALUES TO DBLINK-IDENTITIES                             
           END-IF                                                               
                                                                                
           EVALUATE FCCSPL-METHOD-NAME                                          
               WHEN 'BEGIN-THREAD'                                              
                   MOVE '14' TO WS-IDMS-MAJOR-CODE                              
                   MOVE ZERO TO ERROR-STATUS                                    
                   PERFORM 100-BIND-RUN-UNIT                                    
               WHEN 'LOCK'                                                      
                   MOVE '09' TO WS-IDMS-MAJOR-CODE                              
                   MOVE ZERO TO ERROR-STATUS                                    
               WHEN 'COMMIT'                                                    
                   MOVE '18' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 110-COMMIT                                           
               WHEN 'ROLLBACK'                                                  
                   MOVE '19' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 120-ROLLBACK                                         
               WHEN 'END-THREAD'                                                
                   MOVE '01' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 160-FINISH                                           
               WHEN 'LOCK-TABLE'                                                
                   MOVE '09' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 170-LOCK-TABLE                                       
               WHEN 'KEEP-LONGTERM'                                             
                   MOVE '51' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 180-KEEP-LONGTERM                                    
               WHEN 'SAVE-DBKEY'                                                
                   MOVE '15' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 200-SAVE-DBKEY                                       
               WHEN 'CREATE-RELATIONSHIP'                                       
                   MOVE '07' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 210-CONNECT                                          
               WHEN 'DELETE-RELATIONSHIP'                                       
                   MOVE '11' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 220-DISCONNECT                                       
               WHEN 'DELETE'                                                    
               WHEN 'DELETE-NON-PRIMARY-KSF'                                    
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 230-ERASE                                            
               WHEN 'DELETE-CASCADE'                                            
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 231-ERASE-ALL                                        
               WHEN 'DELETE-PERMANENT'                                          
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 232-ERASE-PERMANENT                                  
               WHEN 'DELETE-SELECTIVE'                                          
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 233-ERASE-SELECTIVE                                  
               WHEN 'SELECT-USING-PRIM-KEY'                                     
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 240-OBTAIN-CALC                                      
               WHEN 'SELECT-USING-CURR'                                         
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 241-OBTAIN-CURRENT                                   
               WHEN 'SELECT-USING-DBKEY'                                        
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 242-OBTAIN-DBKEY                                     
               WHEN 'SELECT-PARENT'                                             
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 243-OBTAIN-OWNER                                     
               WHEN 'SELECT-NEXT-USING-ALT-KEY'                                 
               WHEN 'SELECT-FIRST-USING-ALT-KEY'                                
               WHEN 'SELECT-PRIOR-USING-ALT-KEY'                                
               WHEN 'SELECT-USING-ALT-KEY'                                      
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 244-OBTAIN-USING-SORTKEY                             
               WHEN 'FETCH-FIRST'                                               
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-LAST'                                                
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-NEXT'                                                
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-NEXT-A'                                              
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'SELECT-NEXT'                                               
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-PRIOR'                                               
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-NTH'                                                 
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'SELECT-DELETE'                                             
                   MOVE '99' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 247-SELECT-DELETE                                    
               WHEN 'IF-DEPENDENTS-EXIST'                                       
                   MOVE '16' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 260-IF-SET-EMPTY                                     
      *        WHEN 'NOT-IF-DEPENDENTS-EXIST'                                   
      * THE NOT IS HANDLED IN THE CALLING PROGRAMS CONVERSION                   
      *   SETTING THE 1601 FOR NOT TESTS ELSE 0000                              
      * THE I/O MODULE CONTAINS NO "NOT" VARIATIONS FOR THIS DML                
      *            MOVE '16' TO WS-IDMS-MAJOR-CODE                              
      *            PERFORM 260-IF-SET-EMPTY                                     
               WHEN 'IF-PARENT-EXISTS'                                          
                   MOVE '16' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 262-IF-SET-MEMBER                                    
      *        WHEN 'NOT-IF-PARENT-EXISTS'                                      
      * THE NOT IS HANDLED IN THE CALLING PROGRAMS CONVERSION                   
      *   SETTING THE 1601 FOR NOT TESTS ELSE 0000                              
      * THE I/O MODULE CONTAINS NO "NOT" VARIATIONS FOR THIS DML                
      *            MOVE '16' TO WS-IDMS-MAJOR-CODE                              
      *            PERFORM 262-IF-SET-MEMBER                                    
               WHEN 'UPDATE'                                                    
                   MOVE '08' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 270-MODIFY                                           
               WHEN 'INSERT'                                                    
                   MOVE '12' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 280-STORE                                            
               WHEN 'RETURN-DBKEY'                                              
                   MOVE '17' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 290-RETURN                                           
               WHEN 'CLOSE-ALL-CURSORS'                                         
                   MOVE '99' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 420-LINK-TO-SQL-MODULE                               
               WHEN OTHER                                                       
                   STRING 'INVALID METHOD = '                                   
                       FCCSPL-METHOD-NAME                                       
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 970-EVALUATE-ERROR                                   
           END-EVALUATE.                                                        
                                                                                
       040-MAINLINE-EXIT.                                                       
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             060-CHECK-ADDRESSES ROUTINE                        *        
      *----------------------------------------------------------------*        
       060-CHECK-ADDRESSES SECTION.                                             
                                                                                
           MOVE ZERO TO WS-SUB1.                                                
                                                                                
       060-CHECK-ADDRESSES-010.                                                 
                                                                                
           ADD 1 TO WS-SUB1.                                                    
           IF WS-SUB1 > 10                                                      
               STRING 'ALL 10 ADDRESSES USED'                                   
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
               PERFORM 980-ABORT                                                
           END-IF.                                                              
           IF FCCSPL-ADDRESS-BASE (WS-SUB1) = ZERO                              
               COMPUTE FCCSPL-NUM-ADDR = WS-SUB1 - 1                            
               GO TO 060-CHECK-ADDRESSES-EXIT                                   
           END-IF.                                                              
           GO TO 060-CHECK-ADDRESSES-010.                                       
                                                                                
       060-CHECK-ADDRESSES-EXIT.                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             100-BIND-RUN-UNIT ROUTINE                          *        
      *----------------------------------------------------------------*        
       100-BIND-RUN-UNIT SECTION.                                               
                                                                                
           MOVE FCCSPL-DEBUG-FLAG TO WS-SAVE-DEBUG-FLAG.                        
           MOVE SPACES TO DBLINK-RECORD-KEYS.                                   
           MOVE LOW-VALUES TO DBLINK-SET-KEYS.                                  
           MOVE SPACES TO DBLINK-SET-FLAGS.                                     
           MOVE LOW-VALUES TO DBLINK-IDENTITIES                                 
           INITIALIZE DBLINK-SUBSCHEMA-CTRL.                                    
           MOVE FCCSPL-PROGRAM-NAME TO PROGRAM-NAME OF                          
                                       DBLINK-SUBSCHEMA-CTRL.                   
           INITIALIZE FCCSPLCA-C.                                               
           MOVE WS-SAVE-DEBUG-FLAG TO FCCSPL-DEBUG-FLAG.                        
           MOVE 'FCCSPLPT' TO FCCSPL-PROGRAM-QUEUE.                             
           MOVE 'FCCSPLRT' TO FCCSPL-RECORD-QUEUE.                              
           MOVE 'FCKY'     TO FCCSPL-CURRTABL-Q-ID.                             
           MOVE 'CBRS'     TO FCCSPL-CBRSKEYS-Q-ID.                             
           MOVE 'N'        TO FCCSPL-SYNCH-ERROR-FLAG.                          
           MOVE ZERO TO ERROR-STATUS.                                           
                                                                                
       100-BIND-RUN-UNIT-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             110-COMMIT ROUTINE                                 *        
      *----------------------------------------------------------------*        
       110-COMMIT SECTION.                                                      
                                                                                
           EXEC CICS                                                            
               SYNCPOINT                                                        
               RESP(FCCSPL-CICS-RESP)                                           
           END-EXEC                                                             
                                                                                
           IF FCCSPL-CICS-RESP = DFHRESP(NORMAL)                                
               MOVE WS-CURSOR-CODES-BASE TO DBLINK-CURSOR-CODES                 
               MOVE  ZERO TO ERROR-STATUS                                       
               GO TO 110-COMMIT-EXIT                                            
           END-IF                                                               
                                                                                
           MOVE FCCSPL-CICS-RESP TO WS-99999999-DISPLAY                         
           STRING 'CICS SYNCPOINT ERROR, RESP = '                               
                WS-99999999-DISPLAY                                             
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
           PERFORM 980-ABORT.                                                   
                                                                                
       110-COMMIT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             120-ROLLBACK ROUTINE                               *        
      *----------------------------------------------------------------*        
       120-ROLLBACK SECTION.                                                    
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 2 AND 3                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'ROLLBACK, PARMS NOT 2 OR 3, BUT = '                      
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           PERFORM 124-SQL-ROLLBACK.                                            
                                                                                
       120-ROLLBACK-EXIT.                                                       
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             124-SQL-ROLLBACK ROUTINE                           *        
      *----------------------------------------------------------------*        
       124-SQL-ROLLBACK SECTION.                                                
                                                                                
           EXEC CICS                                                            
               SYNCPOINT ROLLBACK                                               
               RESP(FCCSPL-CICS-RESP)                                           
           END-EXEC                                                             
                                                                                
           IF FCCSPL-CICS-RESP = DFHRESP(NORMAL)                                
               MOVE SPACES TO DBLINK-RECORD-KEYS                                
               MOVE LOW-VALUES TO DBLINK-SET-KEYS                               
               MOVE SPACES TO DBLINK-SET-FLAGS                                  
               MOVE LOW-VALUES TO DBLINK-IDENTITIES                             
               MOVE WS-CURSOR-CODES-BASE TO DBLINK-CURSOR-CODES                 
               GO TO 124-SQL-ROLLBACK-EXIT                                      
           END-IF                                                               
                                                                                
           MOVE FCCSPL-CICS-RESP TO WS-99999999-DISPLAY                         
           STRING 'CICS SYNCPOINT ROLLBACK, RESP = '                            
                   WS-99999999-DISPLAY                                          
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
                                                                                
           PERFORM 980-ABORT.                                                   
                                                                                
       124-SQL-ROLLBACK-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             160-FINISH ROUTINE                                 *        
      *----------------------------------------------------------------*        
       160-FINISH SECTION.                                                      
                                                                                
           PERFORM 110-COMMIT.                                                  
                                                                                
           MOVE 'N' TO FCCSPLLK-BEGIN-THREAD-FLAG.                              
                                                                                
       160-FINISH-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             170-LOCK-TABLE ROUTINE                             *        
      *----------------------------------------------------------------*        
       170-LOCK-TABLE SECTION.                                                  
                                                                                
           MOVE 1 TO WS-SUB2.                                                   
                                                                                
       170-CHECK-AND-PROCESS.                                                   
                                                                                
           IF FCCSPL-VARDATA (WS-SUB2:8) = SPACES                               
               OR WS-SUB2 NOT < 400                                             
                   GO TO 170-LOCK-TABLE-EXIT                                    
           END-IF.                                                              
           MOVE FCCSPL-VARDATA (WS-SUB2:8)                                      
               TO LS-I-O-MODULE-NAME.                                           
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (3)                                            
           MOVE LS-STRING-16 TO FCCSPL-LOCK-MODE.                               
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
           IF ERROR-STATUS NOT = ZERO                                           
               GO TO 170-LOCK-TABLE-EXIT                                        
           END-IF.                                                              
           ADD 8 TO WS-SUB2                                                     
           GO TO 170-CHECK-AND-PROCESS.                                         
                                                                                
       170-LOCK-TABLE-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             180-KEEP-LONGTERM ROUTINE                          *        
      *----------------------------------------------------------------*        
       180-KEEP-LONGTERM SECTION.                                               
                                                                                
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (3)                                            
           EVALUATE LS-STRING-16                                                
               WHEN 'RELEASE-ALL'                                               
                   PERFORM 182-RELEASE-ALL                                      
                   GO TO 180-KEEP-LONGTERM-EXIT                                 
               WHEN 'SHARE-WAIT'                                                
                   MOVE '02' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'UP-EXCL-NOWAIT'                                            
                   MOVE '08' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN 'UP-SHR-NOWAIT'                                             
                   MOVE '04' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'EXCL-NOWAIT'                                               
                   MOVE '05' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'RELEASE'                                                   
                   MOVE '06' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN 'NOTIFY-CURRENT'                                            
                   MOVE '07' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'UP-EXCL-NODEAD-N'                                          
                   MOVE '08' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN 'TEST-NOTIFY'                                               
                   MOVE '09' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN OTHER                                                       
                   STRING 'INVALID KEEP LONGTERM, TYPE = '                      
                       DELIMITED BY SIZE                                        
                       LS-STRING-16 DELIMITED BY SPACES                         
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 970-EVALUATE-ERROR                                   
                   GO TO 180-KEEP-LONGTERM-EXIT                                 
           END-EVALUATE                                                         
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       180-KEEP-LONGTERM-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             182-RELEASE-ALL  ROUTINE                           *        
      *----------------------------------------------------------------*        
       182-RELEASE-ALL  SECTION.                                                
                                                                                
           MOVE EIBTRMID TO FC-EIBTRMID.                                        
           EXEC SQL                                                             
FXXTOK         DELETE FROM TFCKEP                                               
                WHERE FC_EIBTRMID = :FC-EIBTRMID                                
           END-EXEC                                                             
           MOVE SQLCODE TO FCCSPL-SQLCODE                                       
           IF SQLCODE = ZERO OR +100                                            
               MOVE ZERO TO ERROR-STATUS                                        
               GO TO 182-RELEASE-ALL-EXIT                                       
           END-IF.                                                              
           PERFORM 198-ADJUST-ERROR-STATUS.                                     
                                                                                
       182-RELEASE-ALL-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             184-GET-IO-MODULE-NAME ROUTINE                     *        
      *----------------------------------------------------------------*        
       184-GET-IO-MODULE-NAME SECTION.                                          
                                                                                
           MOVE EIBTRMID TO FC-EIBTRMID.                                        
           EXEC SQL                                                             
               SELECT FC_KEEP_LONG_REC                                          
                   INTO :FC-KEEP-LONG-REC                                       
FXXTOK             FROM TFCKEP                                                  
                   WHERE FC_KEEP_LONG_ID = :FC-KEEP-LONG-ID                     
                   AND   FC_EIBTRMID         = :FC-EIBTRMID                     
                   AND   FC_KEEP_LONG_TYPE   = 'NOTIFY'                         
           END-EXEC.                                                            
           IF SQLCODE = +100                                                    
               MOVE '5121' TO ERROR-STATUS                                      
               GO TO 184-GET-IO-MODULE-NAME-EXIT                                
           END-IF.                                                              
           MOVE FC-KEEP-LONG-REC TO FCCSPL-RECORD-NAME                          
           PERFORM 300-FIND-I-O-MODULE-NAME.                                    
                                                                                
       184-GET-IO-MODULE-NAME-EXIT.                                             
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             198-ADJUST-ERROR-STATUS ROUTINE                    *        
      *----------------------------------------------------------------*        
       198-ADJUST-ERROR-STATUS SECTION.                                         
                                                                                
           IF SQLCODE < ZERO                                                    
               MOVE '9' TO WS-SQLCODE-DISPLAY                                   
               COMPUTE WS-SQLCODE-NUMERIC =                                     
                                SQLCODE * (-1)                                  
           ELSE                                                                 
               MOVE '8' TO WS-SQLCODE-DISPLAY                                   
               MOVE              SQLCODE TO WS-SQLCODE-NUMERIC                  
           END-IF                                                               
           MOVE WS-SQLCODE-DISPLAY TO ERROR-STATUS.                             
                                                                                
       198-ADJUST-ERROR-STATUS-EXIT.                                            
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             200-SAVE-DBKEY                                     *        
      *----------------------------------------------------------------*        
       200-SAVE-DBKEY   SECTION.                                                
                                                                                
           MOVE RECORD-NAME TO WS-SAVE-RECORD-NAME.                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 4 AND 5 AND 6                               
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'ACCEPT DBK, NUM PARMS NOT 4/5, BUT = '                   
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-DBKEY TO FCCSPL-ADDRESS (3).                       
           MOVE FCCSPL-ADDRESS-BASE (3) TO FCCSPL-A-DBKEY.                      
           MOVE ZERO TO LS-DBKEY.                                               
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (4)                                            
           MOVE LS-STRING-16 TO FCCSPL-ACCEPT-TYPE                              
                                                                                
           IF FCCSPL-NUM-ADDR = 5                                               
               SET ADDRESS OF LS-STRING-16                                      
                   TO FCCSPL-ADDRESS (5)                                        
               IF FCCSPL-ACCEPT-RECORD                                          
                   MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                      
                   MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME               
               ELSE                                                             
                   MOVE LS-STRING-16 TO FCCSPL-SET-NAME                         
                   MOVE SPACES TO FCCSPL-ACCEPT-SUBTYPE                         
               END-IF                                                           
           ELSE                                                                 
           IF FCCSPL-NUM-ADDR = 6                                               
               SET ADDRESS OF LS-STRING-16                                      
                   TO FCCSPL-ADDRESS (5)                                        
               MOVE LS-STRING-16 TO FCCSPL-SET-NAME                             
               SET ADDRESS OF LS-STRING-16                                      
                   TO FCCSPL-ADDRESS (6)                                        
               MOVE LS-STRING-16 TO FCCSPL-ACCEPT-SUBTYPE                       
           ELSE                                                                 
               MOVE RECORD-NAME TO FCCSPL-RECORD-NAME                           
               PERFORM 300-FIND-I-O-MODULE-NAME                                 
               MOVE 'RECORD' TO FCCSPL-ACCEPT-TYPE                              
           END-IF.                                                              
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
           IF RECORD-NAME = SPACES                                              
               MOVE WS-SAVE-RECORD-NAME TO RECORD-NAME                          
           END-IF.                                                              
                                                                                
       200-SAVE-DBKEY-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             210-CONNECT ROUTINE                                *        
      *----------------------------------------------------------------*        
       210-CONNECT   SECTION.                                                   
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'CONNECT - NUM PARMS NOT 5, BUT = '                       
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME.                      
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       210-CONNECT-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             220-DISCONNECT ROUTINE                             *        
      *----------------------------------------------------------------*        
       220-DISCONNECT   SECTION.                                                
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'DISCONNECT - NUM PARMS NOT 5, BUT = '                    
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       220-DISCONNECT-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             230-ERASE ROUTINE                                  *        
      *----------------------------------------------------------------*        
       230-ERASE   SECTION.                                                     
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'ERASE - NUM PARMS NOT 5, BUT = '                         
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE SPACES TO FCCSPL-ERASE-TYPE.                                    
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       230-ERASE-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             231-ERASE-ALL ROUTINE                              *        
      *----------------------------------------------------------------*        
       231-ERASE-ALL   SECTION.                                                 
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'ERASE ALL - NUM PARMS NOT 5, BUT = '                     
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE 'ALL' TO FCCSPL-ERASE-TYPE.                                     
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       231-ERASE-ALL-EXIT.                                                      
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             232-ERASE-PERMANENT ROUTINE                        *        
      *----------------------------------------------------------------*        
       232-ERASE-PERMANENT SECTION.                                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'ERASE PERMNENT - NUM PARMS NOT 5, BUT '                  
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE 'PERMANENT' TO FCCSPL-ERASE-TYPE.                               
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       232-ERASE-PERMANENT-EXIT.                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             233-ERASE-SELECTIVE ROUTINE                        *        
      *----------------------------------------------------------------*        
       233-ERASE-SELECTIVE SECTION.                                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'ERASE SELECTIV - NUM PARMS NOT 5, BUT '                  
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE 'SELECTIVE' TO FCCSPL-ERASE-TYPE.                               
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       233-ERASE-SELECTIVE-EXIT.                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             240-OBTAIN-CALC ROUTINE                            *        
      *----------------------------------------------------------------*        
       240-OBTAIN-CALC   SECTION.                                               
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 6                                           
              AND FCCSPL-NUM-ADDR NOT = 7                                       
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'F/O CALC, NUM PARMS NOT 6, BUT = '                       
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           IF FCCSPL-NUM-ADDR = 6                                               
               MOVE 'CALC' TO FCCSPL-OBTAIN-CALC-TYPE                           
           ELSE                                                                 
               MOVE 'DUPLICATE' TO FCCSPL-OBTAIN-CALC-TYPE                      
           END-IF.                                                              
                                                                                
           SUBTRACT 1 FROM FCCSPL-NUM-ADDR                                      
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           ADD 1 TO FCCSPL-NUM-ADDR                                             
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       240-OBTAIN-CALC-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             241-OBTAIN-CURRENT ROUTINE                         *        
      *----------------------------------------------------------------*        
       241-OBTAIN-CURRENT   SECTION.                                            
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5 AND 6                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'F/O CURR, NUM PARMS NOT 5/6, BUT = '                     
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           SUBTRACT 1 FROM FCCSPL-NUM-ADDR                                      
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           ADD 1 TO FCCSPL-NUM-ADDR                                             
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
                                                                                
           IF LS-STRING-16 = 'CURRENT'                                          
               MOVE SPACES TO FCCSPL-OBTAIN-CURR-TYPE                           
               MOVE RECORD-NAME TO FCCSPL-RECORD-NAME                           
               PERFORM 300-FIND-I-O-MODULE-NAME                                 
               PERFORM 400-LINK-TO-I-O-MODULE                                   
           ELSE                                                                 
               MOVE 'RECORD' TO FCCSPL-OBTAIN-CURR-TYPE                         
               MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                          
               MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD                  
               PERFORM 400-LINK-TO-I-O-MODULE                                   
           END-IF.                                                              
                                                                                
       241-OBTAIN-CURRENT-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             242-OBTAIN-DBKEY ROUTINE                           *        
      *----------------------------------------------------------------*        
       242-OBTAIN-DBKEY   SECTION.                                              
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 6 AND 7                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'F/O DB-KEY, NUM PARMS NOT 6/7, BUT = '                   
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-DBKEY-WORK TO FCCSPL-ADDRESS (3).                  
           MOVE FCCSPL-ADDRESS-BASE (3) TO FCCSPL-A-DBKEY.                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           SUBTRACT 1 FROM FCCSPL-NUM-ADDR                                      
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           ADD 1 TO FCCSPL-NUM-ADDR                                             
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           IF FCCSPL-NUM-ADDR = 6                                               
               PERFORM 295-FIND-IOMOD-VIA-DBKEY                                 
               IF SQLCODE NOT = ZERO                                            
                   PERFORM 198-ADJUST-ERROR-STATUS                              
                   GO TO 242-OBTAIN-DBKEY-EXIT                                  
               END-IF                                                           
               MOVE 'RECORD' TO FCCSPL-OBTAIN-DBKEY-TYPE                        
           ELSE                                                                 
               SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                
               MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                          
               MOVE 'RECORD' TO FCCSPL-OBTAIN-DBKEY-TYPE                        
               MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD                  
           END-IF                                                               
           PERFORM 400-LINK-TO-I-O-MODULE                                       
                                                                                
           IF LS-DBKEY-WORK = ZERO                                              
               AND ERROR-STATUS = '0326'                                        
                   MOVE '0302' TO ERROR-STATUS                                  
           END-IF.                                                              
                                                                                
       242-OBTAIN-DBKEY-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             243-OBTAIN-OWNER ROUTINE                           *        
      *----------------------------------------------------------------*        
       243-OBTAIN-OWNER   SECTION.                                              
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 7                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'F/O OWNER, NUM PARMS NOT 7, BUT = '                      
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (6)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (7)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       243-OBTAIN-OWNER-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             244-OBTAIN-USING-SORTKEY ROUTINE                   *        
      *----------------------------------------------------------------*        
       244-OBTAIN-USING-SORTKEY   SECTION.                                      
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 8                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'F/O USING, NUM PARMS NOT 8, BUT = '                      
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3)                    
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-SORTKEY TO FCCSPL-ADDRESS (6)                      
           MOVE LS-SORTKEY TO FCCSPL-SORTKEY                                    
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (7)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (8)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       244-OBTAIN-USING-SORTKEY-EXIT.                                           
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             245-OBTAIN-FLNPN ROUTINE                           *        
      *----------------------------------------------------------------*        
       245-OBTAIN-FLNPN   SECTION.                                              
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 7                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'F/O FLNPN, NUM PARMS NOT 7, BUT = '                      
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3)                    
                                                                                
           IF LS-STRING-16 = 'ANY'                                              
               STRING 'OBTAIN FLNPN ERR, * ANY * NOT ALLOWED'                   
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 980-ABORT                                                
           ELSE                                                                 
               MOVE 'RECORD' TO FCCSPL-OBTAIN-FLNPN-TYPE                        
               MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                          
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (6)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (7)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       245-OBTAIN-FLNPN-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             247-SELECT-DELETE ROUTINE                          *        
      *----------------------------------------------------------------*        
       247-SELECT-DELETE SECTION.                                               
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'SELECT/DEL NUM PARMS NOT 5, BUT = '                      
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           MOVE 'CALC' TO FCCSPL-OBTAIN-CALC-TYPE                               
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       247-SELECT-DELETE-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             260-IF-SET-EMPTY ROUTINE                           *        
      *----------------------------------------------------------------*        
       260-IF-SET-EMPTY   SECTION.                                              
                                                                                
           MOVE RECORD-NAME TO WS-SAVE-RECORD-NAME.                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'IF EMPTY - NUM PARMS NOT 5, BUT = '                      
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5)                    
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
           IF RECORD-NAME = SPACES                                              
               MOVE WS-SAVE-RECORD-NAME TO RECORD-NAME                          
           END-IF.                                                              
                                                                                
       260-IF-SET-EMPTY-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             262-IF-SET-MEMBER ROUTINE                          *        
      *----------------------------------------------------------------*        
       262-IF-SET-MEMBER   SECTION.                                             
                                                                                
           MOVE RECORD-NAME TO WS-SAVE-RECORD-NAME.                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'IF MEMBER - NUM PARMS NOT 5, BUT = '                     
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5)                    
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
           IF RECORD-NAME = SPACES                                              
               MOVE WS-SAVE-RECORD-NAME TO RECORD-NAME                          
           END-IF.                                                              
                                                                                
       262-IF-SET-MEMBER-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             270-MODIFY ROUTINE                                 *        
      *----------------------------------------------------------------*        
       270-MODIFY   SECTION.                                                    
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 4                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'MODIFY - NUM PARMS NOT 4, BUT = '                        
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       270-MODIFY-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             280-STORE ROUTINE                                  *        
      *----------------------------------------------------------------*        
       280-STORE   SECTION.                                                     
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 4                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'STORE - NUM PARMS NOT 4, BUT = '                         
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       280-STORE-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             290-RETURN ROUTINE                                 *        
      *----------------------------------------------------------------*        
       290-RETURN SECTION.                                                      
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 6 AND 7                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
               STRING 'RETURN, NUM PARMS NOT 6 OR 7, BUT = '                    
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-DBKEY TO FCCSPL-ADDRESS (3).                       
           MOVE FCCSPL-ADDRESS-BASE (3) TO FCCSPL-A-DBKEY.                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5)                    
           MOVE LS-STRING-16 TO FCCSPL-RETURN-TYPE                              
           MOVE FCCSPL-ADDRESS-BASE (6) TO FCCSPL-A-RECORD                      
                                                                                
           IF FCCSPL-NUM-ADDR = 7                                               
               IF FCCSPL-TYPE-USING                                             
                   SET ADDRESS OF LS-SORTKEY TO FCCSPL-ADDRESS (7)              
                   MOVE LS-SORTKEY TO FCCSPL-SORTKEY                            
                   MOVE FCCSPL-SORTKEY TO FCCSPL-KEY                            
               ELSE                                                             
                   STRING 'RETURN, 7 PARMS, TYPE SHOULD BE USING BUT = '        
                       DELIMITED BY SIZE                                        
                   FCCSPL-RETURN-TYPE                                           
                       DELIMITED BY SPACE                                       
                   INTO FCCSPL-ERROR-MESSAGE                                    
                   PERFORM 970-EVALUATE-ERROR                                   
                END-IF                                                          
           ELSE                                                                 
               IF FCCSPL-TYPE-USING                                             
                   STRING 'RETURN, 6 PARMS, TYPE SHOULD NOT BE USING'           
                       DELIMITED BY SIZE                                        
                   INTO FCCSPL-ERROR-MESSAGE                                    
                   PERFORM 970-EVALUATE-ERROR                                   
                END-IF                                                          
           END-IF.                                                              
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       290-RETURN-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             295-FIND-IOMOD-VIA-DBKEY ROUTINE                   *        
      *----------------------------------------------------------------*        
       295-FIND-IOMOD-VIA-DBKEY SECTION.                                        
                                                                                
*******    EXEC SQL                                                             
*******        SELECT FC_RECORD_NAME                                            
*******        INTO  :FCCSPL-RECORD-NAME                                        
*******        FROM   FCDBKEY                                                   
*******        WHERE  FC_DBKEY = :LS-DBKEY-WORK                                 
*******    END-EXEC.                                                            
*******    IF SQLCODE NOT = ZERO                                                
*******        GO TO 295-FIND-IOMOD-VIA-DBKEY-EXIT                              
*******    END-IF.                                                              
*******    PERFORM 300-FIND-I-O-MODULE-NAME.                                    
                   STRING 'INVALID METHOD = '                                   
                       FCCSPL-METHOD-NAME                                       
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 970-EVALUATE-ERROR.                                  
                                                                                
       295-FIND-IOMOD-VIA-DBKEY-EXIT.                                           
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             300-FIND-I-O-MODULE-NAME ROUTINE                   *        
      *----------------------------------------------------------------*        
       300-FIND-I-O-MODULE-NAME SECTION.                                        
                                                                                
           SET FCCSPLNM-INDEX TO 1.                                             
                                                                                
           SEARCH ALL FCCSPLNM-TABLE-ENTRY                                      
               AT END                                                           
                   STRING '300 REC NAME SEARCH NOFIND, REC = '                  
                       FCCSPL-RECORD-NAME                                       
                           DELIMITED BY SIZE                                    
                           INTO FCCSPL-ERROR-MESSAGE                            
                       PERFORM 980-ABORT                                        
               WHEN FCCSPLNM-RECORD-NAME (FCCSPLNM-INDEX) =                     
                        FCCSPL-RECORD-NAME                                      
                   MOVE FCCSPLNM-I-O-MODULE-NAME (FCCSPLNM-INDEX)               
                       TO LS-I-O-MODULE-NAME                                    
           END-SEARCH.                                                          
           IF LS-I-O-MODULE-NAME = '$ERROR$'                                    
               STRING '300 REC NAME SEARCH $ERROR$, REC = '                     
                   FCCSPL-RECORD-NAME                                           
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 980-ABORT                                            
           END-IF.                                                              
                                                                                
       300-FIND-I-O-MODULE-NAME-EXIT.                                           
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             400-LINK-TO-I-O-MODULE ROUTINE                     *        
      *----------------------------------------------------------------*        
       400-LINK-TO-I-O-MODULE SECTION.                                          
                                                                                
           MOVE ZERO TO SQLCODE.                                                
                                                                                
           PERFORM 420-LINK-TO-SQL-MODULE                                       
                                                                                
           MOVE FCCSPLLK-SQLCODE TO FCCSPL-SQLCODE                              
                                                                                
           IF ERROR-STATUS = '7777'                                             
               STRING 'METHOD = '                                               
                   FCCSPL-METHOD-NAME (1:26)                                    
                   ', EVALUATE ERROR 7777'                                      
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
               PERFORM 985-WRITE-ERROR-QUEUE                                    
           END-IF                                                               
           IF (ERROR-STATUS (1:1) = '8'                                         
                OR  ERROR-STATUS (1:1) = '9')                                   
                   IF FCCSPL-ERROR-MESSAGE = SPACES                             
                       STRING 'ERROR, METHOD = '                                
                           FCCSPL-METHOD-NAME (1:26)                            
                           ', ERROR-STATUS = '                                  
                           ERROR-STATUS                                         
                               DELIMITED BY SIZE                                
                               INTO FCCSPL-ERROR-MESSAGE                        
                   END-IF                                                       
                   PERFORM 985-WRITE-ERROR-QUEUE                                
           END-IF.                                                              
                                                                                
           IF ERROR-STATUS (3:2) = '29'                                         
               IF FCCSPL-ERROR-MESSAGE = SPACES                                 
                   MOVE SQLCODE TO WS-SQLCODE-ERROR-DISPLAY                     
                   STRING 'ROLLBACK, METH: '                                    
                       FCCSPL-METHOD-NAME (1:12)                                
                       ', ERROR-STATUS: '                                       
                       ERROR-STATUS                                             
                       ', SQLCODE: '                                            
                       WS-SQLCODE-ERROR-DISPLAY                                 
                           DELIMITED BY SIZE                                    
                           INTO FCCSPL-ERROR-MESSAGE                            
               END-IF                                                           
               PERFORM 985-WRITE-ERROR-QUEUE                                    
           END-IF.                                                              
                                                                                
           IF FCCSPL-ONLINE-DEBUG-TRACE                                         
               PERFORM 987-WRITE-TRACE-QUEUE                                    
           END-IF.                                                              
                                                                                
       400-LINK-TO-I-O-MODULE-EXIT.                                             
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             420-LINK-TO-SQL-MODULE ROUTINE                     *        
      *----------------------------------------------------------------*        
       420-LINK-TO-SQL-MODULE SECTION.                                          
                                                                                
           IF FCCSPLLK-SQLCODE NOT NUMERIC                                      
               MOVE ZERO TO FCCSPLLK-SQLCODE                                    
           END-IF.                                                              
           MOVE FCCSPL-PROGRAM-NAME TO DBLINK-PROGRAM-NAME.                     
           IF LS-I-O-MODULE-NAME = 'GLBLCTL'                                    
               MOVE '9997' TO ERROR-STATUS                                      
               GO TO 420-LINK-TO-SQL-MODULE-EXIT                                
           END-IF.                                                              
           MOVE LS-I-O-MODULE-NAME TO WS-LINK-MODULE-NAME.                      
MAN        MOVE '4' TO WS-LINK-MODULE-NAME (3:1)                                
                                                                                
           CALL WS-LINK-MODULE-NAME                                             
                 USING                                                          
                     DFHEIBLK                                                   
                     DFHCOMMAREA                                                
                     DBLINK-SUBSCHEMA-CONTROL                                   
                     DBLINK-RECORD-SET-KEYS                                     
                     DBLINK-CURSOR-CODES.                                       
                                                                                
           IF FCCSPL-METHOD-NAME = 'SAVE-DBKEY'                                 
              AND ERROR-STATUS = '0306'                                         
                  MOVE ZERO TO ERROR-STATUS                                     
                  MOVE -1 TO LS-DBKEY                                           
           END-IF                                                               
                                                                                
           MOVE SPACES TO FCCSPL-CURR-REC-NAME                                  
           MOVE SPACES TO FCCSPL-CURR-REC-KEY                                   
           IF FCCSPLLK-SQLCODE = -913                                           
               PERFORM 124-SQL-ROLLBACK                                         
               MOVE -911 TO FCCSPLLK-SQLCODE                                    
           END-IF                                                               
                                                                                
           IF FCCSPLLK-SQLCODE = -911                                           
               MOVE WS-IDMS-MAJOR-CODE TO ERROR-STATUS (1:2)                    
               MOVE '29' TO ERROR-STATUS (3:2)                                  
           END-IF                                                               
                                                                                
           IF FCCSPL-EVALUATE-ERROR-FLAG = 'Y'                                  
               MOVE '9998' TO ERROR-STATUS                                      
               MOVE 'N' TO FCCSPL-EVALUATE-ERROR-FLAG                           
           END-IF.                                                              
                                                                                
           IF ERROR-STATUS = '9999'                                             
               IF FCCSPL-IOMOD-SQLCODE < ZERO                                   
                   MOVE '9' TO WS-SQLCODE-DISPLAY                               
                   COMPUTE WS-SQLCODE-NUMERIC =                                 
                       FCCSPL-IOMOD-SQLCODE * (-1)                              
               ELSE                                                             
                   MOVE '8' TO WS-SQLCODE-DISPLAY                               
                   MOVE FCCSPL-IOMOD-SQLCODE TO WS-SQLCODE-NUMERIC              
               END-IF                                                           
               MOVE WS-SQLCODE-DISPLAY TO ERROR-STATUS                          
           END-IF.                                                              
                                                                                
       420-LINK-TO-SQL-MODULE-EXIT.                                             
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             970-EVALUATE-ERROR ROUTINE                         *        
      *----------------------------------------------------------------*        
       970-EVALUATE-ERROR SECTION.                                              
                                                                                
           IF ERROR-STATUS = ZERO                                               
               MOVE '7777' TO ERROR-STATUS                                      
           END-IF.                                                              
                                                                                
           PERFORM 985-WRITE-ERROR-QUEUE                                        
                                                                                
           EXEC CICS                                                            
               SYNCPOINT ROLLBACK                                               
           END-EXEC                                                             
                                                                                
           MOVE LOW-VALUES TO FCCSPL-ADDRESSES.                                 
           EXEC CICS                                                            
               ABEND ABCODE('SPLT')                                             
           END-EXEC.                                                            
                                                                                
       970-EVALUATE-ERROR-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             980-ABORT ROUTINE                                  *        
      *----------------------------------------------------------------*        
       980-ABORT SECTION.                                                       
                                                                                
           PERFORM 985-WRITE-ERROR-QUEUE                                        
                                                                                
           EXEC CICS                                                            
               SYNCPOINT ROLLBACK                                               
           END-EXEC                                                             
                                                                                
      **********************************                                        
      ** IN CASE CALLING PROGRAM HAS HANDLE ABEND IN IT                         
      **********************************                                        
           MOVE LOW-VALUES TO FCCSPL-ADDRESSES.                                 
                                                                                
           EXEC CICS                                                            
               ABEND ABCODE('SPLT')                                             
           END-EXEC.                                                            
                                                                                
       980-ABORT-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             985-WRITE-ERROR-QUEUE ROUTINE                      *        
      *----------------------------------------------------------------*        
       985-WRITE-ERROR-QUEUE SECTION.                                           
                                                                                
           MOVE SPACES TO SPERR-DATE.                                           
           MOVE SPACES TO SPERR-TIME.                                           
           MOVE SPACES TO SPERR-EIBTRMID.                                       
           MOVE SPACES TO SPERR-USERID.                                         
           MOVE SPACES TO SPERR-PROGRAM-NAME.                                   
           MOVE ZERO TO SPERR-DML-SEQ-NO.                                       
           MOVE SPACES TO SPERR-RECORD-NAME.                                    
           MOVE SPACES TO SPERR-SET-NAME.                                       
           MOVE SPACES TO SPERR-ERROR-MESSAGE.                                  
           MOVE SPACES TO SPERR-METHOD-NAME.                                    
           MOVE SPACES TO SPERR-ERROR-STATUS.                                   
           MOVE ZERO TO SPERR-SQLCODE.                                          
           MOVE SPACES TO SPERR-SQLERRMC-AREA.                                  
           MOVE ZERO TO SPERR-DML-SEQ-NO.                                       
           MOVE ZERO TO SPERR-SQLCODE.                                          
                                                                                
           EXEC CICS ASKTIME ABSTIME(WS-ABSTIME)                                
                                                 END-EXEC.                      
                                                                                
           EXEC CICS FORMATTIME ABSTIME(WS-ABSTIME)                             
                     DATESEP('-')  YYYYMMDD(SPERR-DATE)                         
                       TIME(SPERR-TIME) TIMESEP                                 
           END-EXEC.                                                            
                                                                                
           MOVE FCCSPL-PROGRAM-NAME   TO SPERR-PROGRAM-NAME                     
           MOVE FCCSPL-RECORD-NAME    TO SPERR-RECORD-NAME                      
           MOVE FCCSPL-ERROR-MESSAGE  TO SPERR-ERROR-MESSAGE                    
           MOVE FCCSPL-SET-NAME       TO SPERR-SET-NAME                         
           MOVE FCCSPL-METHOD-NAME    TO SPERR-METHOD-NAME                      
           MOVE FCCSPL-DML-SEQ-NO     TO SPERR-DML-SEQ-NO                       
           MOVE FCCSPL-IOMOD-SQLCODE  TO SPERR-SQLCODE                          
           MOVE ERROR-STATUS TO SPERR-ERROR-STATUS                              
           MOVE WS-EIBTRMID  TO SPERR-EIBTRMID.                                 
                                                                                
           EXEC CICS                                                            
               ASSIGN USERID(SPERR-USERID)                                      
           END-EXEC.                                                            
                                                                                
           IF FCCSPL-IOMOD-SQLCODE NOT < ZERO                                   
               MOVE ZERO TO SPERR-SQLERRML                                      
           ELSE                                                                 
               MOVE FCCSPL-IOMOD-SQLERRML TO SPERR-SQLERRML                     
           END-IF.                                                              
                                                                                
           MOVE FCCSPL-IOMOD-SQLERRMC TO SPERR-SQLERRMC-AREA                    
                                                                                
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITERR')                                                
               FROM(SPLITTER-ERROR-AREA-0)                                      
               LENGTH(LENGTH OF SPLITTER-ERROR-AREA-0)                          
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITERR')                                                
               FROM(SPLITTER-ERROR-AREA-1)                                      
               LENGTH(LENGTH OF SPLITTER-ERROR-AREA-1)                          
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITERR')                                                
               FROM(SPLITTER-ERROR-AREA-2)                                      
               LENGTH(LENGTH OF SPLITTER-ERROR-AREA-2)                          
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITERR')                                                
               FROM(SPLITTER-ERROR-AREA-3)                                      
               LENGTH(LENGTH OF SPLITTER-ERROR-AREA-3)                          
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITERR')                                                
               FROM(SPLITTER-ERROR-AREA-4)                                      
               LENGTH(LENGTH OF SPLITTER-ERROR-AREA-4)                          
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITERR')                                                
               FROM(SPLITTER-ERROR-AREA-5)                                      
               LENGTH(LENGTH OF SPLITTER-ERROR-AREA-5)                          
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
       985-WRITE-ERROR-QUEUE-EXIT.                                              
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             986-WRITE-TRACE-QUEUE ROUTINE                      *        
      *----------------------------------------------------------------*        
       986-WRITE-TRACE-QUEUE SECTION.                                           
                                                                                
           EXEC CICS                                                            
               ASKTIME ABSTIME(WS-ABSTIME)                                      
           END-EXEC.                                                            
           EXEC CICS                                                            
               FORMATTIME ABSTIME(WS-ABSTIME)                                   
                   DATESEP('-')  YYYYMMDD(SPLTRACE-TRACE-DATE)                  
                   TIME(SPLTRACE-TRACE-TIME) TIMESEP                            
           END-EXEC.                                                            
           MOVE FCCSPL-PROGRAM-NAME TO SPLTRACE-CALLING-PROGRAM.                
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITDBG')                                                
               FROM(SPLITTER-TRACE-LINE1)                                       
               LENGTH(LENGTH OF SPLITTER-TRACE-LINE1)                           
               NOHANDLE                                                         
           END-EXEC.                                                            
           MOVE LS-METHOD-NAME TO SPLTRACE-METHOD.                              
           MOVE FCCSPL-DML-SEQ-NO TO SPLTRACE-DML-SEQ-NO.                       
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITDBG')                                                
               FROM(SPLITTER-TRACE-LINE2)                                       
               LENGTH(LENGTH OF SPLITTER-TRACE-LINE2)                           
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
       986-WRITE-TRACE-QUEUE-EXIT.                                              
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             987-WRITE-TRACE-QUEUE ROUTINE                      *        
      *----------------------------------------------------------------*        
       987-WRITE-TRACE-QUEUE SECTION.                                           
                                                                                
           MOVE ERROR-STATUS TO SPLTRACE-ERROR-STATUS                           
           MOVE FCCSPL-IOMOD-SQLCODE TO SPLTRACE-SQLCODE                        
           MOVE WS-LINK-MODULE-NAME TO SPLTRACE-I-O-MODULE                      
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITDBG')                                                
               FROM(SPLITTER-TRACE-LINE3)                                       
               LENGTH(LENGTH OF SPLITTER-TRACE-LINE3)                           
               NOHANDLE                                                         
           END-EXEC.                                                            
           MOVE FCCSPL-RECORD-NAME    TO SPLTRACE-RECORD-NAME                   
           MOVE FCCSPL-ERROR-MESSAGE  TO SPLTRACE-ERROR-MESSAGE                 
           IF SPLTRACE-ERROR-MESSAGE = SPACES                                   
               MOVE SPACES TO SPLTRACE-ERROR-MSG-LITERAL                        
           ELSE                                                                 
               MOVE ', ERROR MSG: ' TO SPLTRACE-ERROR-MSG-LITERAL               
           END-IF                                                               
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLITDBG')                                                
               FROM(SPLITTER-TRACE-LINE4)                                       
               LENGTH(LENGTH OF SPLITTER-TRACE-LINE4)                           
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
       987-WRITE-TRACE-QUEUE-EXIT.                                              
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             990-RETURN ROUTINE                                 *        
      *----------------------------------------------------------------*        
       990-RETURN SECTION.                                                      
                                                                                
           MOVE LOW-VALUES TO FCCSPL-ADDRESSES.                                 
           MOVE ZERO TO FCCSPL-A-RECORD.                                        
           MOVE 'N' TO WS-RECORD-RELATED-FLAG.                                  
           MOVE SPACES TO FCCSPL-RECORD-NAME                                    
           MOVE 'Y' TO DBLINK-INIT-HV-FLAG                                      
           PERFORM 995-SPLTRACE.                                                
           MOVE DBLINK-CURSOR-CODES TO WS-CURSOR-CODES-SAVE.                    
           MOVE EIBTASKN TO WS-EIBTASKN-SAVE.                                   
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE (FCC-CURSORCODE-TS-ID)                                     
               FROM(WS-CURSOR-CODES-SAVE)                                       
               LENGTH(LENGTH OF WS-CURSOR-CODES-SAVE)                           
               RESP(FCCSPL-CICS-RESP)                                           
           END-EXEC                                                             
           IF FCCSPL-CICS-RESP NOT = DFHRESP(NORMAL)                            
               MOVE FCCSPL-CICS-RESP TO WS-99999999-DISPLAY                     
               MOVE SPACES TO FCCSPL-ERROR-MESSAGE                              
               STRING 'FC WRITEQ TS, INVALID RETURN, CICS-RESP = '              
                       DELIMITED BY SIZE                                        
                   WS-99999999-DISPLAY                                          
                       DELIMITED BY SIZE                                        
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 980-ABORT                                                
           END-IF.                                                              
           GOBACK.                                                              
                                                                                
       990-RETURN-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             995-SPLTRACE ROUTINE                               *        
      *----------------------------------------------------------------*        
       995-SPLTRACE SECTION.                                                    
                                                                                
           EXEC CICS                                                            
               ASSIGN USERID(FCC-USERID)                                        
           END-EXEC.                                                            
           IF FCC-USERID NOT = 'FCDEBUG'                                        
               GO TO 995-SPLTRACE-EXIT                                          
           END-IF.                                                              
           IF SPLTRACE-SPLITTER-SEQ-NO = ZERO                                   
               MOVE '****  ' TO SPLTRACE-PREFIX                                 
           ELSE                                                                 
               MOVE SPACES TO SPLTRACE-PREFIX                                   
           END-IF.                                                              
           ADD 1 TO SPLTRACE-SPLITTER-SEQ-NO.                                   
           IF FCCSPL-IOMOD-SQLCODE = ZERO                                       
               MOVE SPACES TO SPLTRACE-SQLCODEX-GROUP                           
           ELSE                                                                 
               MOVE FCCSPL-IOMOD-SQLCODE  TO SPLTRACE-SQLCODEX                  
           END-IF.                                                              
           IF ERROR-STATUS = ZERO                                               
               MOVE SPACES TO SPLTRACE-ERROR-STATUSX-GROUP                      
           ELSE                                                                 
               MOVE ERROR-STATUS TO SPLTRACE-ERROR-STATUSX                      
           END-IF.                                                              
           EXEC CICS                                                            
               WRITEQ TS                                                        
               QUEUE('SPLTRACE')                                                
               FROM(SPLTRACE-LINE)                                              
               LENGTH(LENGTH OF SPLTRACE-LINE)                                  
               NOHANDLE                                                         
           END-EXEC.                                                            
                                                                                
       995-SPLTRACE-EXIT.                                                       
           EXIT.                                                                
                                                                                
