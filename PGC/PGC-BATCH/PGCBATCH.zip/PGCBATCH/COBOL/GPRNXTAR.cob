       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
GNE                                                                             
       PROGRAM-ID. GPRNXTAR.                                                    
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
      *REMARKS.  THIS PROGRAM READ THE INPUT FILE SEQUENTIALLY TO               
      *          PICK UP ALL THE 'T' RECORD-TYPE. ALL THE INFORMATION           
      *          THAT PICK UP WILL WRITE TO A TEMPORARY FILE. AFTER             
      *          IT SORTED BY GFO NUMBERS, THAT OUTPUT FILE IS TO               
      *          BE USED IN THE GPRARRLS PROGRAM.                               
      *DATE-WRITTEN.  FEBRUARY 1988.                                            
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  WS-REC-CHG              PIC X(1) VALUE 'T'.                          
       01  WS-FLAG                 PIC X(1) VALUE 'N'.                          
                                                                                
       01  HO-RECORD.                                                           
           03  FILLER                            PIC X(4).                      
           03  TEMPREC-CHG-HO                    PIC X(1).                      
           03  TEMPCURR-KEY-HO.                                                 
               07  TEMPARR-IND-HO                PIC X(1).                      
               07  TEMPARR-STAT-HO               PIC X(1).                      
           03  TEMPGRP-OFF-HO                    PIC X(5).                      
GNE        03  TEMPGRP-NUM-HO         COMP-3     PIC S9(7).                     
           03  TEMPACCT-HO                       PIC X(3).                      
           03  TEMPTYPE-HO                       PIC X(1).                      
           03  TEMPACCT-STAT-HO                  PIC X(2).                      
           03  TEMPEFF-DATE-HO                   PIC X(4).                      
           03  TEMPPAID-DATE-HO                  PIC X(4).                      
           03  TEMPTOT-OUTS-HO         COMP-3    PIC S9(7)V99.                  
           03  TEMPARR-CNT-HO          COMP-3    PIC S9(3).                     
           03  TEMPNXT-DATE-HO                   PIC X(4).                      
           03  TEMPNXT-ACT-HO                    PIC X(1).                      
           03  TEMPEARLY-HO                      PIC X(1).                      
           03  TEMP-HIDATE-HO                    PIC X(4).                      
           03  TEMP-HOSA-HO                      PIC X(1).                      
           03  SORTHO-GRP-OFF                       PIC X(5).                   
GNE        03  SORTHO-GRP-NUM            COMP-3     PIC S9(7).                  
           03  SORTHO-ACCT                          PIC X(3).                   
           03  SORTHO-CURR-KEY.                                                 
               07  SORTHO-IND                    PIC X(1).                      
               07  SORTHO-STAT                   PIC X(1).                      
           03  SORTHO-TYPE                       PIC X(1).                      
GNE        03  FILLER                            PIC X(65).                     
                                                                                
       01  SA-RECORD.                                                           
           03  FILLER                            PIC X(4).                      
           03  TEMPREC-CHG-SA                    PIC X(1).                      
           03  TEMPCURR-KEY-SA.                                                 
               07  TEMPARR-IND-SA                PIC X(1).                      
               07  TEMPARR-STAT-SA               PIC X(1).                      
           03  TEMPGRP-OFF-SA                    PIC X(5).                      
GNE        03  TEMPGRP-NUM-SA         COMP-3     PIC S9(7).                     
           03  TEMPACCT-SA                       PIC X(3).                      
           03  TEMPTYPE-SA                       PIC X(1).                      
           03  TEMPACCT-STAT-SA                  PIC X(2).                      
           03  TEMPEFF-DATE-SA                   PIC X(4).                      
           03  TEMPPAID-DATE-SA                  PIC X(4).                      
           03  TEMPTOT-OUTS-SA         COMP-3    PIC S9(7)V99.                  
           03  TEMPARR-CNT-SA          COMP-3    PIC S9(3).                     
           03  TEMPNXT-DATE-SA                   PIC X(4).                      
           03  TEMPNXT-ACT-SA                    PIC X(1).                      
           03  TEMPEARLY-SA                      PIC X(1).                      
           03  TEMP-HIDATE-SA                    PIC X(4).                      
           03  TEMP-HOSA-SA                      PIC X(1).                      
           03  SORTSA-CURR-KEY.                                                 
               07  SORTSA-IND                    PIC X(1).                      
               07  SORTSA-STAT                   PIC X(1).                      
GNE        03  SORTSA-GRP-NUM         COMP-3     PIC S9(7).                     
           03  SORTSA-ACCT                       PIC X(3).                      
           03  SORTSA-TYPE                       PIC X(1).                      
           03  SORTSA-GRP-OFF                    PIC X(5).                      
GNE        03  FILLER                            PIC X(65).                     
                                                                                
        01 SYS052-PARMS.                                                        
           03  PRINT-SYS052                 PIC X(6) VALUE 'SYS052'.            
           03  52-PRINT-RETURN     COMP-3   PIC S9   VALUE +0.                  
           03  52-PRINT-RECSIZE             PIC X(5) VALUE '00133'.             
           03  52-PRINT-BLKSIZE             PIC X(5) VALUE '03990'.             
           03  52-PRINT-FORMAT              PIC X(2) VALUE 'FB'.                
           03  PRINT-SYS052-COUNT  COMP-3   PIC S9(7) VALUE +0.                 
                                                                                
        LINKAGE SECTION.                                                        
      *------------------------------------------------------------*            
      *                                                            *            
      *       FROM GIPSY PRINT FILE "NEXT SCHEDULED ACTIVITY"      *            
      *                                                            *            
      *------------------------------------------------------------*            
       01  LSTAPE-RECORD.                                                       
           03  FILLER                            PIC X(4).                      
           03  LSTREC-CHG                        PIC X(1).                      
           03  LSTCURR-KEY.                                                     
               07  LSTARR-IND                    PIC X(1).                      
               07  LSTARR-STAT                   PIC X(1).                      
GNE        03  LSTGRP-NUM             COMP-3     PIC S9(7).                     
           03  LSTACCT                           PIC X(3).                      
           03  LSTTYPE                           PIC X(1).                      
           03  LSTGRP-OFF                        PIC X(5).                      
           03  LSTACCT-STAT                      PIC X(2).                      
           03  LSTEFF-DATE                       PIC X(4).                      
           03  LSTPAID-DATE                      PIC X(4).                      
           03  LSTTOT-OUTS             COMP-3    PIC S9(7)V99.                  
           03  LSTARR-CNT              COMP-3    PIC S9(3).                     
           03  LSTNXT-DATE                       PIC X(4).                      
           03  LSTNXT-ACT                        PIC X(1).                      
           03  LSTEARLY                          PIC X(1).                      
      *------------------------------------------------------------*            
      *                                                            *            
      *                 FROM GPRINTAL DRIVER MODULE                *            
      *                                                            *            
      *------------------------------------------------------------*            
       01  LSMISC-AREA.                                                         
           03  FILLER                  PIC X(4).                                
           03  LSM-HIDATE              PIC X(4).                                
           03  FILLER                  PIC X(24).                               
                                                                                
      *------------------------------------------------------------*            
      *                                                            *            
      *     PRINT PARAMETERS COPY FOR SYS022 THROUGH SYS029        *            
      *                                                            *            
      *------------------------------------------------------------*            
       COPY GPRPRINT.                                                           
                                                                                
      *------------------------------------------------------------*            
      *                                                            *            
      *       TAPE-PARAMETERS COPY BOOK FOR SYS011 AND SYS014      *            
      *                                                            *            
      *------------------------------------------------------------*            
       COPY GPRTPARM.                                                           
                                                                                
      *------------------------------------------------------------*            
      *                                                            *            
      *              REPORT ACCUMULATORS COPY BOOK                 *            
      *                                                            *            
      *------------------------------------------------------------*            
       COPY GPRACCUM.                                                           
                                                                                
       PROCEDURE DIVISION USING LSTAPE-RECORD                                   
                                LSMISC-AREA                                     
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
           ADD +1 TO ACCUM-ARREARS.                                             
           MOVE SPACES TO HO-RECORD                                             
                          SA-RECORD.                                            
           PERFORM CHECK-INDICATOR.                                             
           PERFORM READ-TAPE                                                    
              UNTIL WS-FLAG = 'Y'.                                              
           PERFORM CLOSE-FILE.                                                  
           GOBACK.                                                              
                                                                                
       READ-TAPE.                                                               
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                LSTAPE-RECORD                                   
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
           IF TAPE-RETURN EQUAL ZERO                                            
              PERFORM CHECK-INDICATOR                                           
           ELSE                                                                 
              MOVE 'Y' TO WS-FLAG.                                              
                                                                                
       CHECK-INDICATOR.                                                         
           IF LSTREC-CHG EQUAL WS-REC-CHG                                       
              IF LSTTYPE EQUAL 'B'                                              
                 MOVE 'S' TO TEMP-HOSA-SA                                       
                 PERFORM SA-WRITE-PROCESSING                                    
              ELSE                                                              
                 MOVE 'H' TO TEMP-HOSA-HO                                       
                 PERFORM HO-WRITE-PROCESSING                                    
           ELSE                                                                 
              MOVE 'Y' TO WS-FLAG.                                              
                                                                                
       SA-WRITE-PROCESSING.                                                     
           MOVE LSM-HIDATE TO TEMP-HIDATE-SA.                                   
           MOVE LSTREC-CHG TO TEMPREC-CHG-SA.                                   
           MOVE LSTARR-IND TO TEMPARR-IND-SA                                    
                              SORTSA-IND.                                       
           MOVE LSTARR-STAT TO TEMPARR-STAT-SA                                  
                               SORTSA-STAT.                                     
           MOVE LSTGRP-NUM TO TEMPGRP-NUM-SA                                    
                              SORTSA-GRP-NUM.                                   
           MOVE LSTACCT TO TEMPACCT-SA                                          
                           SORTSA-ACCT.                                         
           MOVE LSTTYPE TO TEMPTYPE-SA                                          
                           SORTSA-TYPE.                                         
           MOVE LSTGRP-OFF TO TEMPGRP-OFF-SA                                    
                              SORTSA-GRP-OFF.                                   
           MOVE LSTACCT-STAT TO TEMPACCT-STAT-SA.                               
           MOVE LSTEFF-DATE TO TEMPEFF-DATE-SA.                                 
           MOVE LSTPAID-DATE TO TEMPPAID-DATE-SA.                               
           MOVE LSTTOT-OUTS TO TEMPTOT-OUTS-SA.                                 
           MOVE LSTARR-CNT TO TEMPARR-CNT-SA.                                   
           MOVE LSTNXT-DATE TO TEMPNXT-DATE-SA.                                 
           MOVE LSTNXT-ACT TO TEMPNXT-ACT-SA.                                   
           MOVE LSTEARLY TO TEMPEARLY-SA.                                       
           CALL 'DLSWRITE' USING PRINT-SYS052                                   
                                 52-PRINT-RETURN                                
                                 SA-RECORD                                      
                                 52-PRINT-RECSIZE                               
                                 52-PRINT-BLKSIZE                               
                                 52-PRINT-FORMAT                                
                                 PRINT-SYS052-COUNT.                            
           IF 52-PRINT-RETURN NOT EQUAL +0                                      
              MOVE 'Y' TO WS-FLAG.                                              
           MOVE SPACES TO LSTAPE-RECORD                                         
                          SA-RECORD.                                            
                                                                                
       HO-WRITE-PROCESSING.                                                     
           MOVE LSM-HIDATE TO TEMP-HIDATE-HO.                                   
           MOVE LSTREC-CHG TO TEMPREC-CHG-HO.                                   
           MOVE LSTARR-IND TO TEMPARR-IND-HO                                    
                              SORTHO-IND.                                       
           MOVE LSTARR-STAT TO TEMPARR-STAT-HO                                  
                               SORTHO-STAT.                                     
           MOVE LSTGRP-NUM TO TEMPGRP-NUM-HO                                    
                              SORTHO-GRP-NUM.                                   
           MOVE LSTACCT TO TEMPACCT-HO                                          
                           SORTHO-ACCT.                                         
           MOVE LSTTYPE TO TEMPTYPE-HO                                          
                           SORTHO-TYPE.                                         
           MOVE LSTGRP-OFF TO TEMPGRP-OFF-HO                                    
                              SORTHO-GRP-OFF.                                   
           MOVE LSTACCT-STAT TO TEMPACCT-STAT-HO.                               
           MOVE LSTEFF-DATE TO TEMPEFF-DATE-HO.                                 
           MOVE LSTPAID-DATE TO TEMPPAID-DATE-HO.                               
           MOVE LSTTOT-OUTS TO TEMPTOT-OUTS-HO.                                 
           MOVE LSTARR-CNT TO TEMPARR-CNT-HO.                                   
           MOVE LSTNXT-DATE TO TEMPNXT-DATE-HO.                                 
           MOVE LSTNXT-ACT TO TEMPNXT-ACT-HO.                                   
           MOVE LSTEARLY TO TEMPEARLY-HO.                                       
           CALL 'DLSWRITE' USING PRINT-SYS052                                   
                                 52-PRINT-RETURN                                
                                 HO-RECORD                                      
                                 52-PRINT-RECSIZE                               
                                 52-PRINT-BLKSIZE                               
                                 52-PRINT-FORMAT                                
                                 PRINT-SYS052-COUNT.                            
           IF 52-PRINT-RETURN NOT EQUAL +0                                      
              MOVE 'Y' TO WS-FLAG.                                              
           MOVE SPACES TO LSTAPE-RECORD                                         
                          HO-RECORD.                                            
                                                                                
       CLOSE-FILE.                                                              
           MOVE +4 TO 52-PRINT-RETURN.                                          
           IF PRINT-SYS052-COUNT NOT EQUAL +0 THEN                              
              CALL 'DLSWRITE' USING PRINT-SYS052                                
                                    52-PRINT-RETURN                             
                                    HO-RECORD                                   
                                    52-PRINT-RECSIZE                            
                                    52-PRINT-BLKSIZE                            
                                    52-PRINT-FORMAT                             
                                    PRINT-SYS052-COUNT.                         
                                                                                
