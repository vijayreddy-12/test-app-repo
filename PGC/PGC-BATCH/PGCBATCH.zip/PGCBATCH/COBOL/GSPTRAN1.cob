       IDENTIFICATION DIVISION.                                                 
GNE                                                                             
       PROGRAM-ID.    GSPTRAN1.                                                 
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      *REMARKS.       THIS PROGRAM PRINTS THE TRANSACTION REGISTER INFO.        
      *               IT SETS UP THE PRINT LINES FOR ALL BENEFIT, AND           
      *               DETAIL TRANSACTION RECORDS, AS WELL AS THE RATES          
      *               AND MASTER CHANGE RECORDS.  DAILY INCONSISTENCY           
      *               FOR THE MASTER AND LAST CHANGE DATE (FOR MASTER)          
      *               ARE ALSO SET UP.  TRANSACTION RECORDS WITH THE            
      *               RATES RECORD OR SPECIFIC TRAILERS, HAVE THE PRINT         
      *               LINES SET UP IN ONE OF THE FOLLOWING PROGRAMS;            
      *               GSPTRAN2, GSPTRAN3, GSPTRAN4, OR GSPTRAN5.                
      *               GSPTRAN1 CAN BE INVOKED FROM EITHER GPRTRAN1 OR           
      *               GSPLIRT.                                                  
      ******************************************************************        
      *  UPDATE HISTORY                                                         
      ******************************************************************        
      * JAN 87 - CAROL TOMAN - PRINT THE EVIDENCE OF INSURABILITY               
      *                        DATE INSTEAD OF BENEFICIARY CHANGE DTE           
      *                                                                         
      * JAN 88 - MARCUS DRURY- RECOMPILE TO INCLUDE NEW COPY OF                 
      *                        GSPPRTPR.                                        
      *                                                                         
      * SEP 91 - MATT PRANGE - ADD NEW DETAIL FIELDS.                           
      *                                                                         
      * JUN/93 - MATT PRANGE - ADD LOGIC TO PRINT NEW TAX TRLR.                 
      *                      - INCREASED SIZE OF PRINT AREA FOR D90'S.          
      *                                                                         
      * MAR/96 - MATT PRANGE - ADD LOGIC TO PRINT COB-IND.                      
      *                                                                         
      * DEC/97 - M. HUNTER   - ADD NEW VALUE FOR COB-IND AND CHANGE             
      *                        MEANING OF 'N'                                   
      *                                                                         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
                                                                                
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77  SUB1        COMP    SYNC    VALUE +0    PIC S9(4).                   
       77  SUB2        COMP            VALUE +0    PIC S9(4).                   
       77  SUB3        COMP            VALUE +0    PIC S9(4).                   
       77  SUB4        COMP            VALUE +0    PIC S9(4).                   
       77  NO-REQUIRED-REPORTS         VALUE +0    PIC S9(4) COMP.              
       77  NO-LINES-REQD       COMP    VALUE +0    PIC S9(4).                   
       77  TEST-NO-LINES-LEFT  COMP    VALUE +0    PIC S9(4).                   
       77  TR-LINCT    COMP            VALUE +0    PIC S9(4).                   
       77  EOP-IND     COMP            VALUE +0    PIC S9(4).                   
       77  REPORT-NO   COMP-3                      PIC S9.                      
       77  NO-TRLR     COMP-3                      PIC S9(3).                   
       77  QDATE-FUNCT                 VALUE 'AC'  PIC XX.                      
       77  QDATE-FUNCT-BC              VALUE 'BC'  PIC XX.                      
       77  CURR-DATE                               PIC X(8).                    
       77  HDG-REQ-SW                              PIC X.                       
                                                                                
GNE    01  WS-ADDR-FLAG  VALUE SPACES                PIC X.                     
                                                                                
       01  TRLR-150-HIST-HEAD1.                                                 
           05  FILLER             PIC X(91) VALUE                               
               '  DUE     #    TAX               '.                             
       01  TRLR-150-HIST-HEAD2.                                                 
           05  FILLER             PIC X(91) VALUE                               
               '  DATE  TAXES  CODE   BILLED TAX '.                             
                                                                                
       01  PRINT-ACCUM-IND.                                                     
           03  LIN-CTR     COMP  OCCURS 5 TIMES    PIC S9(4).                   
           03  REM-LIN     COMP  OCCURS 5 TIMES    PIC S9(4).                   
           03  PRT-LST-CHG-IND.                                                 
               05  PRT-LST-CHG-DATE OCCURS 5 TIMES PIC X.                       
           03  PRT-GRP-INDS.                                                    
GNE            05  PRT-GRP          OCCURS 5 TIMES PIC S9(7) COMP-3.            
               05  PRT-ACCOUNT.                                                 
                   10  PRT-ACCT     OCCURS 5 TIMES PIC XXX.                     
                                                                                
       01  CURRENT-LINE.                                                        
           05  PSM-LINE.                                                        
               10  FILLER                          PIC X(11).                   
               10  CURR-PSM.                                                    
                   15  FILLER                      PIC XXX.                     
                   15  CURR-PSM-FILL               PIC X(17).                   
           05  FILLER      REDEFINES PSM-LINE.                                  
               10  FILLER                          PIC X(5).                    
               10  CURR-BENCODE                    PIC XX.                      
               10  FILLER                          PIC X(13).                   
           05  FILLER      REDEFINES   PSM-LINE.                                
GNE            10  CURR-GROUP                      PIC ZZZZZZ9.                 
               10  FILLER                          PIC X.                       
               10  CURR-ACCT                       PIC XXX.                     
               10  FILLER                          PIC XX.                      
               10  CURR-CERT                       PIC Z(8)9.                   
               10  FILLER  REDEFINES CURR-CERT.                                 
                   15  CURR-TRLR                   PIC XXXXX.                   
                                                                                
       01  SAVE-MASTER-CHG-LINES.                                               
           03  SAVE-MAST-CHG-LINE  OCCURS 4 TIMES                               
                                         PIC X(133).                            
       01  GTRLGTH-PARAMETERS.                                                  
           03  GTRLGTH-RETURN-AREA.                                             
               05  FILLER                PIC X(4).                              
               05  GTR-RET-OCC1          PIC S9(4) COMP.                        
               05  GTR-RET-MIN1          PIC S9(4) COMP.                        
               05  GTR-RET-MAX1          PIC S9(4) COMP.                        
               05  GTR-RET-OCC2          PIC S9(4) COMP.                        
               05  GTR-RET-LGH2          PIC S9(4) COMP.                        
               05  GTR-RET-OCC3          PIC S9(4) COMP.                        
               05  GTR-RET-LGH3          PIC S9(4) COMP.                        
           03  GTRLGTH-RETURN-CODE       PIC X SYNC.                            
                                                                                
       01  TRAILER-PRINT-AREA.                                                  
           05  TRAILER-LINE  OCCURS 255 TIMES      PIC X(91).                   
                                                                                
       01  PRINT-AREA.                                                          
           05  PR-CC           VALUE '1'           PIC X.                       
           05  PR-LINE         VALUE SPACES.                                    
               10  FILLER                          PIC X(5).                    
               10  PR1-BENCODE                     PIC XX.                      
               10  FILLER                          PIC X(8).                    
               10  PR1-TRCODE                      PIC XXX.                     
               10  PR1-IO                          PIC XXX.                     
               10  FILLER                          PIC XX.                      
               10  PR1-DESCRIPTION                 PIC X(77).                   
               10  FILLER                          PIC X(32).                   
           05  FILLER      REDEFINES   PR-LINE.                                 
GNE            10  PR2-GROUP                       PIC ZZZZZZ9.                 
               10  FILLER                          PIC X.                       
               10  PR2-ACCT                        PIC XXX.                     
               10  FILLER                          PIC XX.                      
               10  PR2-CERT                        PIC Z(8)9.                   
               10  FILLER  REDEFINES PR2-CERT.                                  
                   15  PR2-TRLR                    PIC XXXXX.                   
           05  FILLER      REDEFINES   PR-LINE.                                 
               10  FILLER                          PIC X(25).                   
               10  PR3-TITLE1                      PIC X(7).                    
               10  PR3-IDENT                       PIC X(5).                    
               10  FILLER                          PIC X(5).                    
               10  PR3-TITLE                       PIC X(13).                   
               10  PR3-DATE                        PIC X(7).                    
           05  FILLER      REDEFINES   PR-LINE.                                 
               10  FILLER                          PIC X(11).                   
               10  PR4-INCON                       PIC X(64).                   
           05  FILLER      REDEFINES   PR-LINE.                                 
               10 FILLER                           PIC X(25).                   
               10  PR5-TITLE                       PIC XXX.                     
               10  FILLER                          PIC XX.                      
               10  PR5-TRAILER.                                                 
                   15  PR5-TRIDENT                 PIC X(5).                    
                   15  FILLER                      PIC X(86).                   
           05  FILLER      REDEFINES   PR-LINE.                                 
               10  FILLER                          PIC X(22).                   
               10  PR6-INCON                       PIC X(80).                   
           05  FILLER      REDEFINES   PR-LINE.                                 
               10  FILLER                          PIC X(22).                   
               10  PR7-TRCODE                      PIC XXX.                     
               10  PR7-CHANGES.                                                 
                   15  FILLER                      PIC X(5).                    
                   15  PR7-BDATE                   PIC X(7).                    
                   15  FILLER                      PIC X.                       
                   15  PR7-BDEPT                   PIC X(5).                    
                   15  FILLER                      PIC X.                       
                   15  PR7-BNUMBER                 PIC ZZZ9.                    
                   15  FILLER                      PIC XX.                      
                   15  PR7-TDATE                   PIC X(7).                    
                   15  FILLER                      PIC X.                       
                   15  PR7-TDEPT                   PIC X(5).                    
                   15  FILLER                      PIC XX.                      
                   15  PR7-PAGECARD                PIC XX.                      
                   15  FILLER                      PIC X.                       
                   15  PR7-CODE1                   PIC X(50).                   
                   15  FILLER                      PIC X(14).                   
               10  PR8-CHANGES REDEFINES PR7-CHANGES.                           
                   15  PR8-TITLE                   PIC X(9).                    
                   15  PR8-BIRTHDAY                PIC X(7).                    
                   15  FILLER                      PIC XX.                      
                   15  TRB-SEX                     PIC X.                       
                   15  FILLER                      PIC XXX.                     
                   15  TRB-RES                     PIC XX.                      
                   15  FILLER                      PIC X(3).                    
                   15  TRB-TAX-EXEMPT              PIC X.                       
                   15  FILLER                      PIC X(3).                    
                   15  TRB-LANG                    PIC XX.                      
                   15  FILLER                      PIC X.                       
                   15  TRB-CLMFLD                  PIC X.                       
                   15  FILLER                      PIC X.                       
                   15  PR8-EE-HIRE                 PIC X(7).                    
                   15  FILLER                      PIC X.                       
                   15  PR8-SP-DOB                  PIC X(7).                    
                   15  FILLER                      PIC X.                       
                   15  PR8-FUTURE-EFFECT           PIC X(7).                    
                   15  FILLER                      PIC XXX.                     
                   15  TRB-DEC-REF-ACC-CODE        PIC XX.                      
                   15  FILLER                      PIC X(4).                    
                   15  TRB-WAIVER-WAITING-PER      PIC X.                       
                   15  FILLER                      PIC XXX.                     
                   15  TRB-EXCESS-IND              PIC X.                       
                   15  FILLER                      PIC X(3).                    
                   15  PR8-EVID-OF-INS-DATE        PIC X(7).                    
                   15  FILLER                      PIC XXX.                     
                   15  TRB-NEXT-ACCT               PIC XXX.                     
                   15  FILLER                      PIC X(6).                    
                   15  TRB-PREV-ACCT               PIC XXX.                     
               10  PR8-NAME-CHANGES REDEFINES PR7-CHANGES.                      
                   15  FILLER                      PIC X(9).                    
                   15  PR8-CURR-LIT                PIC X(7).                    
                   15  TRB-CURRNAME                PIC X(32).                   
                   15  FILLER                      PIC X(1).                    
                   15  PR8-PREV-LIT                PIC X(7).                    
                   15  TRB-PREVNAME                PIC X(32).                   
                   15  FILLER                      PIC X(1).                    
                   15  PR8-DIV-LIT                 PIC X(4).                    
                   15  TRB-DIVISION                PIC Z9.                      
               10  PR8B-ECLIPSE-CHANGES REDEFINES PR7-CHANGES.                  
                   15  FILLER                      PIC X(9).                    
                   15  PR8B-CARD-LIT               PIC X(7).                    
                   15  PR8B-CARDNAME               PIC X(24).                   
                   15  FILLER                      PIC X(4).                    
                   15  PR8B-OVERAGE-LIT            PIC X(14).                   
                   15  PR8B-OVERAGE-DATE           PIC X(7).                    
                   15  FILLER                      PIC X(4).                    
                   15  PR8B-TPA-LIT                PIC X(13).                   
                   15  PR8B-TPA-COV-CODE           PIC X(2).                    
                   15  FILLER                      PIC X(4).                    
                   15  PR8B-COB-LIT                PIC X(4).                    
                   15  PR8B-COB-IND                PIC X(1).                    
               10  PR9-CHANGES REDEFINES PR7-CHANGES.                           
                   15  FILLER                      PIC X(2).                    
                   15  TRD90-IDENT                 PIC X(5).                    
                   15  FILLER                      PIC X(2).                    
                   15  TRDU-BDATE                  PIC X(7).                    
                   15  FILLER                      PIC X.                       
                   15  TRDU-BDEPT                  PIC X(5).                    
                   15  FILLER                      PIC X.                       
                   15  TRDU-BNUMBER                PIC ZZZ9.                    
                   15  FILLER                      PIC X(4).                    
                   15  TRDU-CODE                   PIC X(76).                   
               10  PR10-CHANGES REDEFINES PR7-CHANGES.                          
                   15  PR10-EFFDATE                PIC X(7).                    
                   15  FILLER                      PIC X.                       
                   15  PR10-PRODATE                PIC X(7).                    
                   15  FILLER                      PIC X.                       
                   15  TRDC-CLASS                  PIC XX.                      
                   15  TRDC-CHG1                   PIC X.                       
                   15  FILLER                      PIC XX.                      
                   15  TRDC-OCC-LTD                PIC X.                       
                   15  TRDC-CHG2                   PIC X.                       
                   15  FILLER                      PIC XX.                      
                   15  TRDC-MODE                   PIC XX.                      
                   15  FILLER                      PIC XXX.                     
                   15  TRDC-SMODE                  PIC X.                       
                   15  TRDC-CHG3                   PIC X.                       
                   15  FILLER                      PIC X.                       
                   15  TRDC-SAMT                   PIC Z(5).99.                 
                   15  TRDC-CHG4                   PIC X.                       
                   15  FILLER                      PIC X.                       
                   15  TRDC-CD-CODE                PIC 999.                     
                   15  TRDC-CD-IND-COV             PIC X.                       
                   15  FILLER                      PIC XX.                      
                   15  TRDC-CD-VOL                 PIC Z(6)9.                   
                   15  FILLER                      PIC X.                       
                   15  TRDC-CD-SEL-IND             PIC XX.                      
                   15  FILLER                      PIC X.                       
                   15  TRDC-CD-PREM                PIC Z(4)9.99.                
           05  FILLER      REDEFINES   PR-LINE.                                 
               10  FILLER                          PIC X(120).                  
               10  PR11-ERRORS OCCURS 3 TIMES.                                  
                   15  FILLER                      PIC X.                       
                   15  PR11-ERR                    PIC XXX.                     
           05  FILLER      REDEFINES   PR-LINE.                                 
               10  FILLER                          PIC X(11).                   
               10  PR12-PSM-FINAL                  PIC X(20).                   
           05  FILLER      REDEFINES   PR-LINE.                                 
               10  FILLER                          PIC X(92).                   
               10  PR-HEAD-LIST                    PIC X(16).                   
                                                                                
       01  HEADINGS-AND-LITERALS.                                               
           05  HEAD1.                                                           
               10  H1-CC       VALUE ' '           PIC X.                       
               10  HD1-PROGRAM VALUE SPACES        PIC X(8).                    
               10  FILLER      VALUE SPACES        PIC X(7).                    
               10  HD1-LODATE  VALUE SPACES        PIC X(7).                    
               10  HD1-SLASH   VALUE SPACES        PIC XXX.                     
               10  HD1-HIDATE  VALUE SPACES        PIC X(7).                    
               10  FILLER    VALUE SPACES          PIC X(8).                    
               10  FILLER                          PIC X(52)   VALUE            
              'G I P S Y   T R A N S A C T I O N   R E G I S T E R '.           
               10  FILLER      VALUE SPACES        PIC X(4).                    
               10  HD1-RUNLIT  VALUE SPACES        PIC X(9).                    
               10  HD1-RUNDATE VALUE SPACES        PIC X(7).                    
               10  HD1-PAGE    VALUE SPACES        PIC X(8).                    
               10  HD1-PAGECT                      PIC ZZZZZ.                   
           05  HEAD2.                                                           
               10  FILLER      VALUE '0'           PIC X.                       
               10  FILLER      VALUE SPACES        PIC X(58).                   
               10  FILLER  VALUE 'FOR RUN '        PIC X(8).                    
               10  H2-DATE                         PIC X(7).                    
           05  SUB-HEAD1.                                                       
               10  FILLER                          PIC X(19)   VALUE            
              '0BENEFIT CODE  TRAN'.                                            
               10  FILLER      VALUE SPACES        PIC X(103).                  
               10  FILLER                          PIC X(11)   VALUE            
              'ERROR CODES'.                                                    
           05  SUB-HEAD2.                                                       
GNE+1          10  FILLER                          PIC X(27)   VALUE            
GNE           '0 GROUP ACCT TRLR CERT TRAN'.                                    
GNE-1          10  FILLER      VALUE SPACES        PIC X(95).                   
               10  FILLER      VALUE 'ERROR CODES' PIC X(11).                   
           05  SUB-HEAD-DETAIL-BASIC.                                           
               10  FILLER      VALUE SPACES        PIC X(11).                   
               10  FILLER      VALUE 'DOB'         PIC X(6).                    
               10  FILLER                          PIC X(36)                    
                   VALUE 'SEX RES TAXEX LG FLD EE HIRE SP DOB'.                 
               10  FILLER                          PIC X(32)                    
                   VALUE 'FUT EFF ACC CD WWP ELGE E I DTE'.                     
               10  FILLER                          PIC X(16)                    
                   VALUE 'NXT ACC PREV ACC'.                                    
           05  SUB-HEAD-COV-1.                                                  
               10  FILLER                          PIC X(20)                    
                   VALUE ' EFFECT  PROC'.                                       
               10  FILLER  VALUE 'OCC'             PIC X(9).                    
               10  FILLER  VALUE 'SAL'             PIC X(6).                    
               10  FILLER  VALUE 'SAL'             PIC X(8).                    
               10  FILLER  VALUE 'COV'             PIC X(13).                   
               10  FILLER  VALUE 'SEL'             PIC X(3).                    
           05  SUB-HEAD-COV-2.                                                  
               10  FILLER                          PIC X(16)                    
                   VALUE '  DATE   DATE'.                                       
               10  FILLER                          PIC X(27)                    
                   VALUE 'CLS LTD MODE MDE   AMT'.                              
               10  FILLER                          PIC X(23)                    
                   VALUE 'CDE   VOLUME IND   PREM'.                             
           05  LIT-1.                                                           
               10  FILLER                          PIC X(17) VALUE              
              '*** INCONSISTENT '.                                              
               10  L1-REC-TYP                      PIC X(12).                   
               10  FILLER                          PIC X(11) VALUE              
              ' RECORD ***'.                                                    
           05  LIT-2.                                                           
               10  FILLER                          PIC X(17) VALUE              
              '*** INCONSISTENT '.                                              
               10  L2-REC-TYP                      PIC X(12).                   
               10  FILLER                          PIC X(18) VALUE              
              ' RECORD - FOR RUN '.                                             
               10  L2-DATE                         PIC X(7).                    
               10  FILLER     VALUE ' ***'         PIC X(4).                    
           05  LIT-3.                                                           
               10  FILLER                          PIC X(30)   VALUE            
              '*** DETAIL RECORD WARNINGS ***'.                                 
           05  LIT-4.                                                           
               10  FILLER                          PIC X(30)   VALUE            
              '*** RATES  RECORD WARNINGS ***'.                                 
           05  LIT-REC-TYPS.                                                    
               10  LIT-MAS   VALUE 'MASTER'        PIC X(12).                   
               10  LIT-PSM   VALUE 'P.S.M.'        PIC X(12).                   
               10  LIT-MAS-RATES                   PIC X(12)                    
                             VALUE 'MASTER/RATES'.                              
               10  LIT-RATES-MAS                   PIC X(12)                    
                             VALUE 'RATES/MASTER'.                              
               10  LIT-PSM-FINAL.                                               
                   15  FILLER                      PIC X(13)                    
                   VALUE 'P.S.M. AS OF '.                                       
                   15  LIT-PSM-DATE                PIC X(7).                    
                                                                                
       01  CONTROL-FIELDS.                                                      
           05  CURRENT-CTL-FLD     VALUE   LOW-VALUES.                          
               10  CCF-SEG1.                                                    
                 15  CCF-SEG2.                                                  
                   20  CCF-SEG3.                                                
                     25  CCF-SEG4.                                              
                       30  CCF-SEG5.                                            
                         35  CCF-SEG6.                                          
                           40  CCF-PART6           PIC X.                       
GNE+1                    35  CCF-PART5             PIC XXXX.                    
                       30  CCF-PART4               PIC XXX.                     
                     25  CCF-PART3                 PIC X.                       
                   20  CCF-PART2.                                               
                     25 CCF-PART2-CERTX            PIC X(5).                    
                     25 CCF-PART2-FILLER           PIC X(25).                   
                   20  CCF-PART2-RATES REDEFINES CCF-PART2.                     
                     25 CCF-PART2-1                PIC X(10).                   
                     25 CCF-PART2-2                PIC X(20).                   
                 15  CCF-PART1                     PIC X.                       
           05  PREVIOUS-CTL-FLD.                                                
               10  PCF-SEG1.                                                    
                 15  PCF-SEG2.                                                  
                   20  PCF-SEG3.                                                
                     25  PCF-SEG4.                                              
                       30  PCF-SEG5.                                            
                         35  PCF-SEG6.                                          
                           40  PCF-PART6           PIC X.                       
GNE+1                    35  PCF-PART5             PIC XXXX.                    
                       30  PCF-PART4               PIC XXX.                     
                     25  PCF-PART3                 PIC X.                       
                   20  PCF-PART2                   PIC X(30).                   
                 15  PCF-PART1                     PIC X.                       
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       77  BILLING-IND                             PIC X.                       
       01  TRANSREG-DATE.                                                       
           05  LO-DATE                             PIC X(4).                    
           05  HI-DATE                             PIC X(4).                    
                                                                                
       01  TRANSREG-RECORD.                                                     
           05  TR-RECLENGTH    COMP                PIC S9(4).                   
           05  FILLER                              PIC XXX.                     
GNE        05  TR-GROUP        COMP-3              PIC S9(7).                   
GNE        05  TR-GROUPX REDEFINES TR-GROUP        PIC XXXX.                    
           05  TR-ACCT                             PIC XXX.                     
           05  TR-FILEID                           PIC X.                       
GNE-1      05  TR-KEY                              PIC X(37).                   
           05  TR-RATE-KEY REDEFINES TR-KEY.                                    
               10  TR-COV-CODE     COMP-3          PIC S9(3).                   
               10  TR-EFFECTIVE-DATE               PIC X(4).                    
               10  TR-PROCESS-DATE                 PIC X(4).                    
               10  TR-RATE-RECTYP2                 PIC X.                       
               10  TR-CLASSES                      PIC X(20).                   
GNE-1          10  FILLER                          PIC X(6).                    
           05  TR-OTHER-KEY REDEFINES TR-KEY.                                   
               10  TR-RECTYP2                      PIC X.                       
               10  TR-CERT         COMP-3          PIC S9(9).                   
               10  TR-CERTX    REDEFINES TR-CERT   PIC X(5).                    
               10  TR-TRAILER  REDEFINES TR-CERT   PIC XXX.                     
               10  TR-BENCODE  REDEFINES TR-CERT   PIC XX.                      
               10  TR-RECTYP3                      PIC X.                       
               10  TR-RUNDATE                      PIC X(4).                    
               10  TR-RECTYP4                      PIC X.                       
               10  TR-MASTER-ROOT.                                              
                   15  TRM-TRDATE                  PIC X(4).                    
                   15  FILLER                      PIC XX.                      
                   15  TRM-PAGECARD                PIC XX.                      
                   15  FILLER                      PIC X(11).                   
                   15  TRM-UPPROC                  PIC X.                       
               10  TR-ROOT-PART3.                                               
                   15  TR3-IDENT                   PIC X(5).                    
GNE-1 *            15  FILLER                      PIC X.                       
           05  TR-RECORD-AREA                      PIC X(4432).                 
           05  FILLER      REDEFINES   TR-RECORD-AREA.                          
               10  FILLER                          PIC X(2).                    
               10  TRCH-BDATE                      PIC X(7).                    
               10  TRCH-BDEPT                      PIC X(5).                    
               10  TRCH-BNUMBER                    PIC X(4).                    
               10  TRCH-TDATE                      PIC X(7).                    
               10  TRCH-TDEPT                      PIC X(5).                    
               10  FILLER                          PIC XX.                      
               10  TRCH-TRCODE                     PIC XXX.                     
               10  FILLER                          PIC X(13).                   
               10  TRCH-PAGECARD                   PIC XX.                      
               10  TRCH-CODE1                      PIC X(50).                   
               10  TRCH-CODE2                      PIC X(50).                   
               10  FILLER                          PIC X(10).                   
               10  TRCH-ERRCODE OCCURS 10 TIMES    PIC XXX.                     
GNE        05  FILLER      REDEFINES   TR-RECORD-AREA.                          
               10  FILLER                          PIC X(2).                    
               10  TRCH-M-BDATE                    PIC X(7).                    
               10  TRCH-M-BDEPT                    PIC X(5).                    
               10  TRCH-M-BNUMBER                  PIC X(4).                    
               10  TRCH-M-TDATE                    PIC X(7).                    
               10  TRCH-M-TDEPT                    PIC X(5).                    
               10  FILLER                          PIC XX.                      
               10  TRCH-M-TRCODE                   PIC XXX.                     
GNE+2          10  FILLER                          PIC X(15).                   
               10  TRCH-M-PAGECARD                 PIC XX.                      
               10  TRCH-M-CODE1                    PIC X(50).                   
               10  TRCH-M-CODE2                    PIC X(50).                   
               10  FILLER                          PIC X(10).                   
               10  TRCH-M-ERRCODE OCCURS 10 TIMES  PIC XXX.                     
GNE        05  FILLER      REDEFINES   TR-RECORD-AREA.                          
               10  FILLER                          PIC X(1).                    
               10  TRCH-MA-BDATE                   PIC X(7).                    
               10  TRCH-MA-BDEPT                   PIC X(5).                    
               10  TRCH-MA-BNUMBER                 PIC X(4).                    
               10  TRCH-MA-TDATE                   PIC X(7).                    
               10  TRCH-MA-TDEPT                   PIC X(5).                    
               10  FILLER                          PIC XX.                      
               10  TRCH-MA-TRCODE                  PIC XXX.                     
GNE+2          10  FILLER                          PIC X(15).                   
               10  TRCH-MA-PAGECARD                PIC XX.                      
               10  TRCH-MA-CODE1                   PIC X(50).                   
               10  TRCH-MA-CODE2                   PIC X(50).                   
               10  FILLER                          PIC X(8).                    
               10  TRCH-MA-ERRCODE OCCURS 10 TIMES PIC XXX.                     
           05  FILLER      REDEFINES   TR-RECORD-AREA.                          
               10  FILLER                          PIC X(2).                    
               10  TRCH-D-BDATE                    PIC X(7).                    
               10  TRCH-D-BDEPT                    PIC X(5).                    
               10  TRCH-D-BNUMBER                  PIC X(4).                    
               10  TRCH-D-TDATE                    PIC X(7).                    
               10  TRCH-D-TDEPT                    PIC X(5).                    
               10  FILLER                          PIC XX.                      
               10  TRCH-D-TRCODE                   PIC XXX.                     
               10  FILLER                          PIC X(13).                   
               10  TRCH-D-PAGECARD                 PIC XX.                      
               10  TRCH-D-CODE1                    PIC X(50).                   
               10  TRCH-D-CODE2                    PIC X(50).                   
               10  FILLER                          PIC X(12).                   
               10  TRCH-D-ERRCODE OCCURS 10 TIMES PIC XXX.                      
           05  TR-DET-COVERAGE REDEFINES TR-RECORD-AREA.                        
               10  TRDC-CHG1                       PIC X.                       
               10  TRDC-CHG2                       PIC X.                       
               10  TRDC-CHG3                       PIC X.                       
               10  TRDC-CHG4                       PIC X.                       
               10  TRDC-CHG-IND-COV OCCURS 20 TIMES PIC X.                      
               10  TRDC-EFFDATE                    PIC X(4).                    
               10  TRDC-PRODATE                    PIC X(4).                    
               10  TRDC-CLASS                      PIC XX.                      
               10  TRDC-OCC-LTD                    PIC X.                       
               10  TRDC-MODE                       PIC XX.                      
               10  TRDC-SMODE                      PIC X.                       
               10  TRDC-SAMT   COMP-3              PIC S9(5)V99.                
               10  FILLER                          PIC X(20).                   
               10  TRDC-NO-CODES COMP-3            PIC S9(3).                   
               10  TRDC-COVERAGE-DATA OCCURS 20 TIMES.                          
                   15  TRDC-CD-CODE COMP-3         PIC S9(3).                   
                   15  TRDC-CD-VOL  COMP-3         PIC S9(7).                   
                   15  TRDC-CD-SEL-IND             PIC XX.                      
                   15  TRDC-CD-PREM COMP-3         PIC S9(5)V99.                
               10  TRDC-ERROR   OCCURS 10 TIMES    PIC XXX.                     
           05  TR-BASIC REDEFINES TR-RECORD-AREA.                               
               10  TRB-SIN     COMP-3              PIC S9(9).                   
               10  TRB-BIRTH                       PIC X(4).                    
               10  TRB-SEX                         PIC X.                       
               10  TRB-RES                         PIC XX.                      
               10  TRB-LANG                        PIC X.                       
               10  TRB-CLMFLD                      PIC X.                       
               10  TRB-EE-HIRED-DATE               PIC X(4).                    
               10  TRB-SP-BIRTHDATE                PIC X(4).                    
               10  TRB-FUTURE-EFFECTIVE-DATE       PIC X(4).                    
               10  TRB-DEC-REF-ACC-CODE            PIC XX.                      
               10  TRB-WAIVER-WAITING-PER          PIC X.                       
               10  TRB-EXCESS-IND                  PIC X.                       
               10  TRB-EVID-OF-INS-DATE            PIC X(4).                    
               10  TRB-PREV-ACCT                   PIC X(3).                    
               10  TRB-NEXT-ACCT                   PIC X(3).                    
               10  TRB-DIVISION                    PIC S9(3)  COMP-3.           
               10  TRB-EVID-OF-INS-LIFE            PIC X(2).                    
               10  TRB-EVID-OF-INS-LTD             PIC X(2).                    
               10  FILLER                          PIC X(66).                   
               10  NMTRLR-ID                       PIC X(3).                    
               10  NMTRLR-LENGTH      COMP-3       PIC S9(5).                   
               10  TRB-CURRNAME                    PIC X(32).                   
               10  TRB-PREVNAME                    PIC X(32).                   
               10  TRB-CARDNAME                    PIC X(24).                   
               10  TRB-OVERAGE-DATE.                                            
                   15  TRB-OVERAGE-YEAR            PIC S9(3)  COMP-3.           
                   15  TRB-OVERAGE-DAY             PIC S9(3)  COMP-3.           
               10  TRB-TPA-COV-CODE                PIC X(2).                    
               10  TRB-TAX-EXEMPT                  PIC X.                       
               10  TRB-COB-IND                     PIC X(1).                    
           05  TR-DET-UPDATE REDEFINES TR-RECORD-AREA.                          
GNE            10  FILLER                          PIC X(2).                    
               10  TRDU-BDATE                      PIC X(7).                    
               10  TRDU-BDEPT                      PIC X(5).                    
               10  TRDU-BNUMBER                    PIC X(4).                    
               10  FILLER                          PIC X(14).                   
               10  TRDU-TRAN                       PIC XXX.                     
GNE+2          10  FILLER                          PIC X(19).                   
               10  TRDU-CODE                       PIC X(48).                   
           05  TR-D90-UPDATE REDEFINES TR-RECORD-AREA.                          
GNE            10  FILLER                          PIC X(2).                    
               10  TR90-BDATE                      PIC X(7).                    
               10  TR90-BDEPT                      PIC X(5).                    
               10  TR90-BNUMBER                    PIC X(4).                    
               10  FILLER                          PIC X(14).                   
               10  TR90-TRAN                       PIC X(3).                    
GNE+?          10  FILLER                          PIC X(8).                    
               10  TR90-IDENT                      PIC X(5).                    
               10  FILLER                          PIC X(9).                    
               10  TR90-CODE                       PIC X(101).                  
           05  TR-TRAILER000 REDEFINES  TR-RECORD-AREA                          
GNE+1                      OCCURS  1  TIMES        PIC X(559).                  
           05  TR-TRAILER010 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(379).                  
           05  TR-TRAILER030 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(218).                  
           05  TR-TRAILER050 REDEFINES  TR-RECORD-AREA                          
                               OCCURS 2 TIMES      PIC X(67).                   
           05  TR-TRAILER080 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(4432).                 
           05  TR-TRAILER090 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(866).                  
           05  TR-TRAILER100 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(436).                  
           05  TR-TRAILER110 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  4  TIMES        PIC X(494).                  
           05  TR-TRAILER120 REDEFINES  TR-RECORD-AREA                          
                           OCCURS 10 TIMES         PIC X(61).                   
           05  TR-TRAILER125 REDEFINES  TR-RECORD-AREA                          
                           OCCURS 1 TIMES          PIC X(496).                  
           05  TR-TRAILER130 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(116).                  
           05  TR-TRAILER140 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(416).                  
           05  TR-TRAILER150 REDEFINES  TR-RECORD-AREA                          
                           OCCURS  1  TIMES        PIC X(2602).                 
           05  TR-ERROR REDEFINES TR-RECORD-AREA                                
                               OCCURS 10 TIMES     PIC XXX.                     
GNE        05  FILLER   REDEFINES TR-RECORD-AREA.                               
GNE            10  TR-1-CHECK                      PIC X.                       
GNE            10  TR-1-ERROR    OCCURS 10 TIMES   PIC XXX.                     
           05  FILLER      REDEFINES   TR-RECORD-AREA.                          
               10  TRBEN-DESC                      PIC X(37).                   
           05  FILLER      REDEFINES   TR-RECORD-AREA.                          
               10  FILLER                          PIC X(30).                   
               10  TRBC-TRAN                       PIC XXX.                     
               10  TRBC-DESC                       PIC X(77).                   
GNE        05  FILLER      REDEFINES TR-RECORD-AREA.                            
GNE            10  FILLER                          PIC X.                       
GNE            10  TR-POINT-IN-SCALE  OCCURS  1  TIMES PIC X(390).              
GNE        05  FILLER      REDEFINES TR-RECORD-AREA.                            
GNE            10  FILLER                          PIC X.                       
GNE            10  TR-RATES-RECORD-2               PIC X(334).                  
GNE        05  FILLER      REDEFINES TR-RECORD-AREA.                            
GNE            10  TR-RATES-RECORD-4               PIC X(334).                  
                                                                                
       01  PRINT-PARAMETERS.                                                    
                                     COPY GSPPRTPM REPLACING                    
                                    ==01  PRINT-PARAMETERS.== BY ====.          
                                                                                
       01  PRINT-PARAMETERS-R  REDEFINES PRINT-PARAMETERS.                      
           03  PRINT-SYS001 OCCURS 8 TIMES                                      
                                   PIC X(6).                                    
           03  PRINT-RETURN1 OCCURS 8 TIMES                                     
                                   PIC X.                                       
           03  PRINT-RECSIZE-R     PIC X(5).                                    
           03  PRINT-BLKSIZE-R     PIC X(5).                                    
           03  PRINT-FORMATT-R     PIC XX.                                      
           03  PRINT-COUNTER1 OCCURS 8 TIMES                                    
                                   PIC X(4).                                    
           03  PAGE-CTR1 OCCURS 8 TIMES                                         
                                   PIC S9(5) COMP-3.                            
                                                                                
       PROCEDURE DIVISION USING TRANSREG-DATE                                   
                                TRANSREG-RECORD                                 
                                PRINT-PARAMETERS                                
                                BILLING-IND.                                    
                                                                                
GNE        MOVE SPACES TO WS-ADDR-FLAG.                                         
           MOVE CURRENT-CTL-FLD TO PREVIOUS-CTL-FLD.                            
      ******************************************************************        
      *    IF FIRST CALL (PCF-SEG1 = LOW-VALUES) PRINT THE FIRST PAGE           
      *    OF TRANSACTION REGISTER ON ALL 5 SYS NUMBERS (ONLY ON 1 IF           
      *    BILLING RUN)                                                         
      ******************************************************************        
           IF  PCF-SEG1 EQUAL LOW-VALUES                                        
               PERFORM FIRST-PAGE-RTN THRU FIRST-PAGE-RTN-EXIT.                 
      *                                                                         
      *    SET UP CONTROL FIELDS                                                
      *                                                                         
           MOVE TR-GROUPX      TO  CCF-PART5.                                   
           IF TR-ACCT = LOW-VALUE                                               
                MOVE '$$$'   TO  CCF-PART4                                      
           ELSE                                                                 
                MOVE TR-ACCT TO  CCF-PART4.                                     
           MOVE TR-FILEID      TO  CCF-PART6.                                   
           IF TR-FILEID EQUAL '4'                                               
              MOVE TR-RATE-KEY         TO CCF-PART2-1                           
              MOVE TR-CLASSES          TO CCF-PART2-2                           
              MOVE LOW-VALUES          TO CCF-PART1                             
              MOVE TR-RATE-RECTYP2     TO CCF-PART3                             
           ELSE                                                                 
               MOVE TR-CERTX       TO  CCF-PART2-CERTX                          
               MOVE LOW-VALUES     TO  CCF-PART2-FILLER                         
               MOVE TR-RECTYP3     TO  CCF-PART1                                
               MOVE TR-RECTYP2     TO  CCF-PART3.                               
      *                                                                         
      *    DO CONTROL PROCESSING                                                
      *                                                                         
           IF  CCF-SEG1 EQUAL TO PCF-SEG1                                       
                   MOVE ' ' TO PR-CC                                            
                   ELSE                                                         
                        MOVE '0' TO PR-CC.                                      
           IF  CCF-SEG2 EQUAL TO PCF-SEG2                                       
                   GO TO NORMAL-PROCESS.                                        
           IF  CCF-SEG4 EQUAL TO PCF-SEG4                                       
                   GO TO REINIT2.                                               
           MOVE '00000' TO PRT-LST-CHG-IND.                                     
           MOVE '-' TO PR-CC.                                                   
           IF  CCF-SEG5 EQUAL TO PCF-SEG5                                       
                   GO TO REINIT4.                                               
           IF  CCF-SEG6 EQUAL TO PCF-SEG6                                       
                   GO TO REINIT5.                                               
           IF  PCF-PART6 EQUAL '2'                                              
               IF BILLING-IND EQUAL '1'                                         
                  MOVE EOP-IND TO LIN-CTR (1)                                   
               ELSE                                                             
                  MOVE EOP-IND TO LIN-CTR (4).                                  
           MOVE SPACES TO CURRENT-LINE.                                         
       REINIT5.                                                                 
           IF  CCF-PART6 EQUAL '2'                                              
               GO TO REINIT2.                                                   
           IF  CCF-PART5 NOT EQUAL PCF-PART5                                    
               MOVE TR-GROUP TO PR2-GROUP.                                      
           MOVE TR-GROUP TO CURR-GROUP.                                         
       REINIT4.                                                                 
           IF  CCF-PART6 NOT = '2'                                              
               IF  TR-ACCT = LOW-VALUE                                          
                    MOVE '$$$' TO PR2-ACCT CURR-ACCT                            
               ELSE                                                             
                    MOVE TR-ACCT TO PR2-ACCT CURR-ACCT.                         
           IF  CCF-PART5 EQUAL PCF-PART5 AND CCF-PART4 EQUAL PCF-PART4          
               MOVE SPACES TO PR2-ACCT.                                         
       REINIT2.                                                                 
           MOVE SPACE TO CURR-PSM.                                              
           IF  CCF-PART6 EQUAL TO '2'                                           
               MOVE TR-BENCODE TO PR1-BENCODE                                   
               MOVE TR-BENCODE TO  CURR-BENCODE                                 
           ELSE                                                                 
               IF CCF-PART6 EQUAL '4'                                           
                  MOVE 'RATES' TO CURR-TRLR  PR2-TRLR                           
               ELSE                                                             
                  IF CCF-PART6 EQUAL '7'                                        
                     MOVE TR-CERT TO CURR-CERT PR2-CERT                         
                  ELSE                                                          
                     PERFORM CONVERT-TRLR-ID THRU CTI-EXIT                      
                     IF TR-TRAILER = '999'                                      
                        IF TRM-UPPROC = 'E'                                     
                           CALL 'QDATE' USING QDATE-FUNCT                       
                                              TR-RUNDATE                        
                                              LIT-PSM-DATE                      
                           MOVE LIT-PSM-FINAL TO PR12-PSM-FINAL                 
                                                 CURR-PSM.                      
                                                                                
       NORMAL-PROCESS.                                                          
           IF  CCF-PART6 EQUAL TO '2'                                           
                   GO TO BENEFIT-ROUT.                                          
           IF  CCF-PART6 EQUAL TO '3'                                           
                   GO TO MASTER-ROUT.                                           
           IF  CCF-PART6 EQUAL TO '4'                                           
                   GO TO RATES-ROUT.                                            
           GO TO DETAIL-ROUT.                                                   
                                                                                
      ************     HEADING AND PRINT ROUTINES FOR REPORTS *******           
                                                                                
       PRINT-IT.                                                                
           IF  PR-CC EQUAL TO ' ' OR '1'                                        
                   ADD +1 TO LIN-CTR (REPORT-NO).                               
           IF  PR-CC EQUAL TO '0'                                               
                   ADD +2 TO LIN-CTR (REPORT-NO).                               
           IF  PR-CC EQUAL TO '-'                                               
                   ADD +3 TO LIN-CTR (REPORT-NO).                               
           PERFORM CALL-PRO.                                                    
           MOVE SPACES TO PR-LINE.                                              
                                                                                
       HEAD-ROUT.                                                               
           ADD +1 TO PAGE-CTR1 (REPORT-NO).                                     
           MOVE PAGE-CTR1 (REPORT-NO) TO HD1-PAGECT.                            
           MOVE HEAD1 TO PRINT-AREA.                                            
           PERFORM CALL-PRO.                                                    
           IF  TR-FILEID EQUAL TO '2'                                           
                   MOVE SUB-HEAD1 TO PRINT-AREA                                 
           ELSE                                                                 
                   MOVE SUB-HEAD2 TO PRINT-AREA.                                
           PERFORM CALL-PRO.                                                    
           MOVE CURRENT-LINE TO PR-LINE.                                        
           MOVE +3 TO LIN-CTR (REPORT-NO).                                      
       HEAD-EXIT.                                                               
           EXIT.                                                                
                                                                                
       CALL-PRO.                                                                
           CALL 'DLSWRITE' USING   PRINT-SYS001   (REPORT-NO)                   
                                   PRINT-RETURN1  (REPORT-NO)                   
                                   PRINT-AREA      PRINT-RECSIZE-R              
                                   PRINT-BLKSIZE-R PRINT-FORMATT-R              
                                   PRINT-COUNTER1 (REPORT-NO).                  
                                                                                
      ******************************************************************        
      *    PRINT THE FIRST PAGE ON EACH REPORT.  INITIALIZE THE PRINT           
      *    LINES FOR THE PAGE HEADINGS.                                         
      ******************************************************************        
       FIRST-PAGE-RTN.                                                          
           CALL 'ZLINECT' USING EOP-IND                                         
           CALL 'QDATE' USING QDATE-FUNCT, HI-DATE, H2-DATE                     
           MOVE +0         TO PAGE-CTR1 (1)  PAGE-CTR1 (2)                      
                              PAGE-CTR1 (3)  PAGE-CTR1 (4)                      
                              PAGE-CTR1 (5).                                    
           IF BILLING-IND EQUAL '1'                                             
              MOVE +1 TO NO-REQUIRED-REPORTS                                    
           ELSE                                                                 
              MOVE +5 TO NO-REQUIRED-REPORTS.                                   
           MOVE +0 TO REPORT-NO.                                                
       FIRST-PAGE-LOOP.                                                         
           ADD +1 TO REPORT-NO.                                                 
           IF REPORT-NO GREATER THAN NO-REQUIRED-REPORTS                        
              GO TO FIRST-PAGE-INIT-HEAD.                                       
           MOVE EOP-IND    TO LIN-CTR (REPORT-NO).                              
           MOVE '1' TO PRINT-AREA.                                              
           PERFORM CALL-PRO                                                     
           MOVE '-'        TO PR-CC                                             
           PERFORM CALL-PRO   4 TIMES                                           
           MOVE PAGE-CTR1 (REPORT-NO) TO HD1-PAGECT                             
           MOVE HEAD1         TO PRINT-AREA                                     
           IF BILLING-IND EQUAL '1'                                             
              MOVE '- ALL REPORTS' TO PR-HEAD-LIST                              
           ELSE                                                                 
           IF REPORT-NO EQUAL 1                                                 
              MOVE '- DETAIL' TO PR-HEAD-LIST                                   
           ELSE                                                                 
           IF REPORT-NO EQUAL 2                                                 
              MOVE '- RATES' TO PR-HEAD-LIST                                    
           ELSE                                                                 
           IF REPORT-NO EQUAL 3                                                 
              MOVE '- PREMIUM' TO PR-HEAD-LIST                                  
           ELSE                                                                 
           IF REPORT-NO EQUAL 4                                                 
              MOVE '- GENERAL POLICY' TO PR-HEAD-LIST                           
           ELSE                                                                 
           IF REPORT-NO EQUAL 5                                                 
              MOVE '- COMMISSIONS' TO PR-HEAD-LIST.                             
           PERFORM CALL-PRO                                                     
           MOVE HEAD2      TO PRINT-AREA                                        
           PERFORM CALL-PRO.                                                    
           GO TO FIRST-PAGE-LOOP.                                               
       FIRST-PAGE-INIT-HEAD.                                                    
           MOVE '1'        TO H1-CC                                             
           MOVE 'GSPTRAN1' TO HD1-PROGRAM                                       
           MOVE 'RUN DATE' TO HD1-RUNLIT                                        
GNE        CALL 'ZCURRDAT' USING CURR-DATE                                      
           CALL 'QDATE' USING QDATE-FUNCT-BC, CURR-DATE, HD1-RUNDATE            
           CALL 'QDATE' USING QDATE-FUNCT, LO-DATE, HD1-LODATE                  
           MOVE '   PAGE ' TO HD1-PAGE                                          
           IF HI-DATE NOT EQUAL LO-DATE                                         
               MOVE ' -'    TO HD1-SLASH                                        
               MOVE H2-DATE TO HD1-HIDATE.                                      
           MOVE +0 TO PRT-GRP (1)   PRT-GRP (2)                                 
                      PRT-GRP (3)   PRT-GRP (4)                                 
                      PRT-GRP (5).                                              
           MOVE SPACES TO PRT-ACCOUNT  PR-LINE.                                 
       FIRST-PAGE-RTN-EXIT.                                                     
           EXIT.                                                                
                                                                                
      **********       DETAIL ROUTINES             **********                   
      *                                                                         
      *    PRINT THE INFORMATION FROM THE DETAIL WARNING CARDS, CHANGE          
      *    CARDS, BASIC DETAIL INFORMATION AND COVERAGE INFORMATION             
      ******************************************************************        
                                                                                
       DETAIL-ROUT.                                                             
           MOVE 1 TO REPORT-NO.                                                 
           PERFORM CHECK-GROUP-PRNT THRU CHECK-GROUP-PRNT-EXIT.                 
           COMPUTE REM-LIN (REPORT-NO) = EOP-IND - LIN-CTR (REPORT-NO).         
           SUBTRACT +1 FROM REM-LIN (REPORT-NO).                                
           IF  PR-CC EQUAL TO '0'                                               
                   SUBTRACT +1 FROM REM-LIN (REPORT-NO).                        
           IF  PR-CC EQUAL TO '-'                                               
                   SUBTRACT +2 FROM REM-LIN (REPORT-NO).                        
           IF  REM-LIN (REPORT-NO) LESS THAN +0                                 
                   PERFORM HEAD-ROUT THRU HEAD-EXIT                             
                   COMPUTE REM-LIN (REPORT-NO) = EOP-IND -                      
                                                 LIN-CTR (REPORT-NO).           
           IF  CCF-PART1 EQUAL '5'                                              
               GO TO COVERAGE-ROUT.                                             
           IF  CCF-PART1 EQUAL '1'                                              
               PERFORM NO-OF-INCON-ERRS                                         
               MOVE LIT-3 TO PR6-INCON                                          
               GO TO INIT-INCON-LOOP.                                           
           IF  CCF-PART1 EQUAL '3' OR '6'                                       
               GO TO DETAIL-CHANGES.                                            
                                                                                
      ****  BASIC INFORMATION PRINT                                             
                                                                                
           SUBTRACT 4 FROM REM-LIN (REPORT-NO).                                 
           IF  REM-LIN (REPORT-NO) LESS THAN +0                                 
               PERFORM HEAD-ROUT THRU HEAD-EXIT.                                
           MOVE SUB-HEAD-DETAIL-BASIC TO PR7-CHANGES.                           
           IF  CCF-PART1 EQUAL '2'                                              
               MOVE 'BAS INP  '   TO  PR8-TITLE                                 
           ELSE                                                                 
               MOVE 'BAS OUT  '  TO  PR8-TITLE.                                 
           PERFORM PRINT-IT.                                                    
           MOVE ' ' TO PR-CC.                                                   
           MOVE CORR   TR-BASIC    TO  PR8-CHANGES.                             
           CALL 'QDATE' USING QDATE-FUNCT TRB-BIRTH         PR8-BIRTHDAY        
           CALL 'QDATE' USING QDATE-FUNCT TRB-EE-HIRED-DATE PR8-EE-HIRE         
           CALL 'QDATE' USING QDATE-FUNCT TRB-SP-BIRTHDATE  PR8-SP-DOB          
           CALL 'QDATE' USING QDATE-FUNCT TRB-FUTURE-EFFECTIVE-DATE             
                                          PR8-FUTURE-EFFECT                     
           CALL 'QDATE' USING QDATE-FUNCT TRB-EVID-OF-INS-DATE                  
                                          PR8-EVID-OF-INS-DATE                  
           PERFORM PRINT-IT.                                                    
           MOVE CORR   TR-BASIC    TO  PR8-NAME-CHANGES.                        
           MOVE 'CURR -' TO  PR8-CURR-LIT.                                      
           MOVE 'PREV -' TO  PR8-PREV-LIT.                                      
           MOVE 'DIV '   TO  PR8-DIV-LIT.                                       
           PERFORM PRINT-IT.                                                    
                                                                                
           MOVE 'CARD - '              TO PR8B-CARD-LIT.                        
           MOVE TRB-CARDNAME           TO PR8B-CARDNAME.                        
                                                                                
           MOVE 'ECLIPSE CODE '        TO PR8B-TPA-LIT.                         
           MOVE TRB-TPA-COV-CODE       TO PR8B-TPA-COV-CODE.                    
                                                                                
           MOVE 'OVERAGE EXPDT '       TO PR8B-OVERAGE-LIT.                     
           CALL 'QDATE' USING QDATE-FUNCT TRB-OVERAGE-DATE                      
                                          PR8B-OVERAGE-DATE.                    
           IF  PR8B-OVERAGE-DATE = '*******'                                    
               MOVE SPACES             TO PR8B-OVERAGE-DATE.                    
                                                                                
           MOVE 'COB '                 TO PR8B-COB-LIT.                         
           IF  TRB-COB-IND = SPACES                                             
               MOVE '0'                TO PR8B-COB-IND                          
           ELSE                                                                 
               MOVE TRB-COB-IND        TO PR8B-COB-IND.                         
                                                                                
           PERFORM PRINT-IT.                                                    
                                                                                
           GO TO GET-BACK.                                                      
                                                                                
      ****  DETAIL CHANGE PRINT                                                 
                                                                                
       DETAIL-CHANGES.                                                          
GNE   *    PERFORM NO-OF-CHANGE-ERRS.                                           
           IF  TR-RECLENGTH NOT EQUAL +208                                      
               IF TRCH-D-ERRCODE (+4) NOT EQUAL '   '                           
                  SUBTRACT +1 FROM REM-LIN (REPORT-NO)                          
                  IF TRCH-D-ERRCODE (+7) NOT EQUAL '   '                        
                     SUBTRACT +1 FROM REM-LIN (REPORT-NO)                       
                     IF TRCH-D-ERRCODE (+10) NOT EQUAL '   '                    
                        SUBTRACT +1 FROM REM-LIN (REPORT-NO)                    
                     ELSE                                                       
                        NEXT SENTENCE                                           
                  ELSE                                                          
                     NEXT SENTENCE                                              
               ELSE                                                             
                  IF  TRCH-D-CODE2 NOT = SPACE                                  
                      SUBTRACT +1 FROM REM-LIN (REPORT-NO)                      
                  ELSE                                                          
                      NEXT SENTENCE                                             
           ELSE                                                                 
               IF  TRCH-D-CODE2 NOT = SPACE                                     
                   SUBTRACT +1 FROM REM-LIN (REPORT-NO).                        
           IF  REM-LIN (REPORT-NO) NOT GREATER THAN +0                          
                   PERFORM HEAD-ROUT THRU HEAD-EXIT.                            
                                                                                
           IF  TRDU-TRAN = 'D90'                                                
               MOVE  TR90-BDATE    TO  TRDU-BDATE   OF PR9-CHANGES              
               MOVE  TR90-BDEPT    TO  TRDU-BDEPT   OF PR9-CHANGES              
               MOVE  TR90-BNUMBER  TO  TRDU-BNUMBER OF PR9-CHANGES              
               MOVE  TR90-IDENT    TO  TRD90-IDENT                              
               MOVE  TR90-CODE     TO  TRDU-CODE    OF PR9-CHANGES              
           ELSE                                                                 
               MOVE CORR TR-DET-UPDATE TO PR9-CHANGES.                          
           MOVE TRDU-TRAN      TO  PR7-TRCODE.                                  
           MOVE +0 TO SUB3.                                                     
           GO TO CHANGE-D-ERR-INIT.                                             
                                                                                
      ******************************************************************        
      *    COMPUTE THE NO. OF LINES REQUIRED TO PRINT THE COVERAGE INFO.        
      *    DECIDE IF HEADINGS ARE NEEDED (IF NEW PAGE HEADINGS REQ'D).          
      *    IF THE FIRST LINE OF THE DETAIL INFO WITH HEADINGS AS REQ'D          
      *    WILL NOT FIT ON THE PAGE - GO TO NEXT PAGE.  OTHERWISE PUT           
      *    THE LINES THAT WILL FIT ON THE PAGE AND THEN GO TO NEXT PAGE.        
      ******************************************************************        
       COVERAGE-ROUT.                                                           
           MOVE +1 TO NO-LINES-REQD.                                            
           IF  TR-RECLENGTH NOT EQUAL +354                                      
               IF TRDC-ERROR (+4) NOT EQUAL '   '                               
                  ADD +1 TO NO-LINES-REQD                                       
                  IF TRDC-ERROR (+7) NOT EQUAL '   '                            
                     ADD +1 TO NO-LINES-REQD                                    
                     IF TRDC-ERROR (+10) NOT EQUAL '   '                        
                        ADD +1 TO NO-LINES-REQD.                                
           IF  NO-LINES-REQD LESS THAN TRDC-NO-CODES                            
               MOVE TRDC-NO-CODES TO NO-LINES-REQD.                             
           IF  (CCF-PART6 EQUAL PCF-PART6 AND CCF-PART1 EQUAL PCF-PART1)        
               AND (LIN-CTR (REPORT-NO) NOT EQUAL +3)                           
               MOVE '0' TO HDG-REQ-SW                                           
           ELSE                                                                 
               ADD 2 TO NO-LINES-REQD                                           
               MOVE '1' TO HDG-REQ-SW.                                          
           COMPUTE TEST-NO-LINES-LEFT = EOP-IND - LIN-CTR (REPORT-NO).          
           IF (TEST-NO-LINES-LEFT GREATER THAN 3) OR                            
              (TEST-NO-LINES-LEFT NOT LESS THAN 1                               
                                           AND HDG-REQ-SW EQUAL '0')            
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE '1' TO HDG-REQ-SW                                           
               PERFORM HEAD-ROUT THRU HEAD-EXIT.                                
           IF  HDG-REQ-SW EQUAL '1'                                             
               PERFORM PRT-DETL-COV-HEAD THRU PRT-DETL-COV-HEAD-EXIT.           
           CALL 'QDATE' USING QDATE-FUNCT, TRDC-EFFDATE, PR10-EFFDATE.          
           CALL 'QDATE' USING QDATE-FUNCT, TRDC-PRODATE, PR10-PRODATE.          
           MOVE CORR   TR-DET-COVERAGE TO  PR10-CHANGES.                        
           MOVE +0 TO SUB1, SUB2, SUB3.                                         
       MOVE-COV-LOOP.                                                           
           ADD +1 TO SUB1.                                                      
           IF SUB1 GREATER THAN TRDC-NO-CODES                                   
              GO TO DONE-COV-MOVE.                                              
           MOVE CORR TRDC-COVERAGE-DATA (SUB1) TO PR10-CHANGES.                 
           MOVE TRDC-CHG-IND-COV (SUB1) TO TRDC-CD-IND-COV.                     
       TRDC-ERROR-MOVE.                                                         
           ADD +1 TO SUB2.                                                      
           ADD +1 TO SUB3.                                                      
           IF  SUB3 EQUAL  +11 OR TRDC-ERROR (SUB3) EQUAL SPACES                
               GO TO DONE-COV-ERR.                                              
           MOVE TRDC-ERROR (SUB3) TO PR11-ERR (SUB2).                           
           IF  SUB2 EQUAL TO +3                                                 
                   PERFORM DETL-CHK-PAGE-END THRU DETL-CHK-PAGE-END-EXIT        
                   MOVE ' ' TO PR-CC                                            
                   MOVE +0 TO SUB2                                              
                   GO TO MOVE-COV-LOOP.                                         
           GO TO TRDC-ERROR-MOVE.                                               
                                                                                
       DONE-COV-MOVE.                                                           
           IF SUB3 EQUAL +11 OR TRDC-ERROR (SUB3) EQUAL SPACES                  
              GO TO GET-BACK.                                                   
           GO TO TRDC-ERROR-MOVE.                                               
                                                                                
       DONE-COV-ERR.                                                            
           IF PR-LINE NOT EQUAL SPACES                                          
              PERFORM DETL-CHK-PAGE-END THRU DETL-CHK-PAGE-END-EXIT             
              MOVE ' ' TO PR-CC                                                 
              GO TO MOVE-COV-LOOP.                                              
           MOVE ' ' TO PR-CC.                                                   
           GO TO GET-BACK.                                                      
                                                                                
       PRT-DETL-COV-HEAD.                                                       
           MOVE SUB-HEAD-COV-1 TO PR8-CHANGES.                                  
           PERFORM PRINT-IT.                                                    
           MOVE ' ' TO PR-CC.                                                   
           MOVE SUB-HEAD-COV-2 TO PR8-CHANGES.                                  
           PERFORM PRINT-IT.                                                    
       PRT-DETL-COV-HEAD-EXIT.                                                  
           EXIT.                                                                
       DETL-CHK-PAGE-END.                                                       
           PERFORM PRINT-IT.                                                    
           COMPUTE TEST-NO-LINES-LEFT = EOP-IND - LIN-CTR (REPORT-NO).          
           IF  TEST-NO-LINES-LEFT LESS THAN +0                                  
               PERFORM HEAD-ROUT THRU HEAD-EXIT                                 
               PERFORM PRT-DETL-COV-HEAD THRU PRT-DETL-COV-HEAD-EXIT.           
       DETL-CHK-PAGE-END-EXIT.                                                  
           EXIT.                                                                
                                                                                
      **********       BENEFIT CODE ROUTINES       **********                   
      *                                                                         
      *    PRINT THE BENEFIT CHANGES OR RECORDS FROM TRANS. REG.                
      ******************************************************************        
                                                                                
       BENEFIT-ROUT.                                                            
           IF BILLING-IND EQUAL '1'                                             
              MOVE 1 TO REPORT-NO                                               
           ELSE                                                                 
              MOVE 4 TO REPORT-NO.                                              
           PERFORM CHECK-GROUP-PRNT THRU CHECK-GROUP-PRNT-EXIT.                 
           COMPUTE REM-LIN (REPORT-NO) = EOP-IND - LIN-CTR (REPORT-NO).         
           SUBTRACT +1 FROM REM-LIN (REPORT-NO).                                
           IF  PR-CC EQUAL TO '0'                                               
                   SUBTRACT +1 FROM REM-LIN (REPORT-NO).                        
           IF  PR-CC EQUAL TO '-'                                               
                   SUBTRACT +2 FROM REM-LIN (REPORT-NO).                        
           IF  REM-LIN (REPORT-NO) LESS THAN +0                                 
                   PERFORM HEAD-ROUT THRU HEAD-EXIT                             
                   COMPUTE REM-LIN (REPORT-NO) = EOP-IND -                      
                                                 LIN-CTR (REPORT-NO).           
           IF  TR-RECTYP3 EQUAL TO '2'                                          
                   MOVE 'INP' TO PR1-IO.                                        
           IF  TR-RECTYP3 EQUAL TO '4'                                          
                   MOVE 'OUT' TO PR1-IO.                                        
           IF  TR-RECTYP3 EQUAL TO '2' OR '4'                                   
                   MOVE TRBEN-DESC TO PR1-DESCRIPTION                           
                   PERFORM PRINT-IT                                             
                   GO TO GET-BACK.                                              
           PERFORM NO-OF-CHANGE-ERRS.                                           
           MOVE TRBC-TRAN  TO  PR1-TRCODE.                                      
           MOVE TRBC-DESC  TO  PR1-DESCRIPTION.                                 
           MOVE +2 TO SUB3.                                                     
           GO TO CHANGE-ERR-INIT.                                               
                                                                                
      ***********             RATES ROUTINES                   *********        
      *                                                                         
      *    PRINT WARNING RECORDS, OR CHANGE RECORDS.  CALL GSPTTRTE TO          
      *    PRINT RATE RECORD                                                    
      ******************************************************************        
                                                                                
       RATES-ROUT.                                                              
           IF BILLING-IND EQUAL '1'                                             
              MOVE 1 TO REPORT-NO                                               
           ELSE                                                                 
              MOVE 2 TO REPORT-NO.                                              
       RATES-ROUT-INC-LOOP.                                                     
           MOVE SPACES TO PR3-IDENT  PR3-TITLE1.                                
           PERFORM CHECK-GROUP-PRNT THRU CHECK-GROUP-PRNT-EXIT.                 
           COMPUTE REM-LIN (REPORT-NO) = EOP-IND - LIN-CTR (REPORT-NO).         
           SUBTRACT +1 FROM REM-LIN (REPORT-NO).                                
           IF  PR-CC EQUAL TO '0'                                               
                   SUBTRACT +1 FROM REM-LIN (REPORT-NO).                        
           IF  PR-CC EQUAL TO '-'                                               
                   SUBTRACT +2 FROM REM-LIN (REPORT-NO).                        
           IF  REM-LIN (REPORT-NO) LESS THAN +0                                 
                   PERFORM HEAD-ROUT THRU HEAD-EXIT                             
                   COMPUTE REM-LIN (REPORT-NO) = EOP-IND -                      
                                                 LIN-CTR (REPORT-NO).           
      * WARNING RECORDS                                                         
           IF  CCF-PART3 EQUAL '1'                                              
               PERFORM NO-OF-INCON-ERRS                                         
               MOVE LIT-4 TO PR6-INCON                                          
               GO TO INIT-INCON-LOOP.                                           
      * INCONSISTENCY RECORDS                                                   
           IF  CCF-PART3 EQUAL '5' OR '6'                                       
               GO TO MOVE-INCON-ERRS.                                           
      * RATE RECORDS TYPE 2 (GNE)                                               
           IF  TR-RATE-RECTYP2 EQUAL TO '2'                                     
                   CALL 'GSPTTRTE' USING TR-LINCT, TRAILER-PRINT-AREA           
                                         TR-RATES-RECORD-2                      
                   GO TO PRINT-RATES-TRLRS.                                     
      * RATE RECORDS TYPE 4 (GNE)                                               
           IF  TR-RATE-RECTYP2 EQUAL TO '2' OR '4'                              
                   CALL 'GSPTTRTE' USING TR-LINCT, TRAILER-PRINT-AREA           
                                         TR-RATES-RECORD-4                      
                   GO TO PRINT-RATES-TRLRS.                                     
      * CHANGE RECORDS (TREATED LIKE MASTER CHANGE RECORDS)                     
           GO TO MASTER-CHANGES.                                                
       PRINT-RATES-TRLRS.                                                       
           MOVE '0' TO PR-CC.                                                   
           SUBTRACT +1 FROM REM-LIN (REPORT-NO).                                
           MOVE +0 TO SUB3.                                                     
           IF REM-LIN (REPORT-NO) LESS THAN +3                                  
                 PERFORM HEAD-ROUT THRU HEAD-EXIT                               
                 COMPUTE REM-LIN (REPORT-NO) = EOP-IND -                        
                                               LIN-CTR (REPORT-NO).             
           IF  TR-RATE-RECTYP2 EQUAL TO '2'                                     
                   MOVE 'INP' TO PR1-IO.                                        
           IF  TR-RATE-RECTYP2 EQUAL TO '4'                                     
                   MOVE 'OUT' TO PR1-IO.                                        
       PRINT-RATES-LOOP.                                                        
           ADD +1 TO SUB3.                                                      
           IF  SUB3 IS GREATER THAN TR-LINCT                                    
               GO TO GET-BACK.                                                  
           MOVE TRAILER-LINE (SUB3) TO PR5-TRAILER.                             
           SUBTRACT +1 FROM REM-LIN (REPORT-NO).                                
           PERFORM PRINT-IT.                                                    
           MOVE SPACE TO PR-CC.                                                 
           IF LIN-CTR (REPORT-NO) NOT LESS THAN EOP-IND                         
              PERFORM HEAD-ROUT THRU HEAD-EXIT.                                 
           GO TO PRINT-RATES-LOOP.                                              
                                                                                
      **********       MASTER ROUTINES             **********                   
      *                                                                         
      *    SET UP THE PRINT LINES FOR MASTER CHANGE RECORDS, DAILY IN-          
      *    CONSISTENCY RECORDS AND LAST CHANGE DATE.  IF INPUT OR OUTPUT        
      *    TRAILERS, CALL THE APPROPRIATE ROUTINE TO SET UP THE PRINT           
      *    LINES.                                                               
      ******************************************************************        
                                                                                
       MASTER-ROUT.                                                             
      *  MASTER LAST CHANGE RECORD                                              
           IF  TR-RECTYP2 EQUAL '1'                                             
               GO TO MAST-LST-CHANGE-PROC.                                      
      *  SET THE APPROPRIATE REPORT NO ACCORDING TO BILLING RUN OR TRLR         
      *  ID                                                                     
           IF BILLING-IND EQUAL '1'                                             
              MOVE 1 TO REPORT-NO                                               
              GO TO MST-LOOP-FOR-DAILY-INCONSIST.                               
           IF  TR-TRAILER EQUAL '125'                                           
               MOVE 2 TO REPORT-NO.                                             
           IF  TR-TRAILER EQUAL '010' OR '080' OR '090' OR '130' OR             
                                '030' OR '040' OR '045' OR '150' OR             
                                SPACES                                          
               MOVE 3 TO REPORT-NO.                                             
           IF  TR-TRAILER EQUAL '000' OR '050' OR '120' OR '140'                
               MOVE 4 TO REPORT-NO.                                             
           IF  TR-TRAILER EQUAL '999' OR '100' OR '110'                         
               MOVE 5 TO REPORT-NO.                                             
           IF  TR-RECTYP2 EQUAL '2'                                             
               MOVE 3 TO REPORT-NO.                                             
           IF  TR-TRAILER EQUAL '030' OR '040' OR '045' OR HIGH-VALUES          
               MOVE '1' TO WS-ADDR-FLAG.                                        
      *                                                                         
      *    CHECK IF THE MASTER LAST CHANGE LINE HAS TO BE WRITTEN OUT           
      *                                                                         
       MST-LOOP-FOR-DAILY-INCONSIST.                                            
           PERFORM CHK-MST-LST-PRT THRU CHK-MST-LST-PRT-EXIT                    
           COMPUTE REM-LIN (REPORT-NO) = EOP-IND - LIN-CTR (REPORT-NO).         
           SUBTRACT +1 FROM REM-LIN (REPORT-NO).                                
           IF  PR-CC EQUAL TO '0'                                               
                   SUBTRACT +1 FROM REM-LIN (REPORT-NO).                        
           IF  PR-CC EQUAL TO '-'                                               
                   SUBTRACT +2 FROM REM-LIN (REPORT-NO).                        
           IF  REM-LIN (REPORT-NO) LESS THAN +0                                 
                   PERFORM HEAD-ROUT THRU HEAD-EXIT                             
                   COMPUTE REM-LIN (REPORT-NO) = EOP-IND -                      
                                                 LIN-CTR (REPORT-NO).           
           IF  TR-RECTYP2 EQUAL '2'                                             
                   GO TO MOVE-INCON-ERRS.                                       
           IF  TR-RECTYP4  EQUAL  '1' OR '2'                                    
                   GO TO MOVE-INCON-ERRS.                                       
           IF  TR-RECTYP4 EQUAL '3'                                             
                   GO TO MASTER-CHANGES.                                        
           IF  TR-ACCT = LOW-VALUE                                              
               MOVE +1 TO NO-TRLR                                               
           ELSE                                                                 
               CALL 'GTRLGTH' USING TR-TRAILER                                  
                                    GTRLGTH-RETURN-AREA                         
                                    GTRLGTH-RETURN-CODE                         
               COMPUTE NO-TRLR = (TR-RECLENGTH - 50) /                          
                      ((((GTR-RET-LGH3 * GTR-RET-OCC3) + GTR-RET-LGH2) *        
                      GTR-RET-OCC2) + GTR-RET-MAX1).                            
           MOVE +0 TO SUB2.                                                     
                                                                                
       BUILD-TRAILERS.                                                          
           ADD +1 TO SUB2.                                                      
           IF  SUB2 GREATER THAN NO-TRLR                                        
                   GO TO GET-BACK.                                              
           PERFORM BUILD-TRLR-LINES THRU BTL-EXIT.                              
           IF TR-LINCT = 0                                                      
              GO TO GET-BACK.                                                   
           IF TRM-UPPROC = 'E'                                                  
              SUBTRACT +1 FROM REM-LIN (REPORT-NO).                             
           IF REM-LIN (REPORT-NO) GREATER THAN +3                               
              NEXT SENTENCE                                                     
           ELSE                                                                 
              PERFORM HEAD-ROUT THRU HEAD-EXIT.                                 
           IF  SUB2 EQUAL TO +1                                                 
               IF  TR-RECTYP3 EQUAL '4'                                         
                   IF TRM-UPPROC = 'E'                                          
                       MOVE '0' TO PR-CC                                        
                       MOVE CURR-PSM TO PR12-PSM-FINAL                          
                       PERFORM PRINT-IT                                         
                       MOVE +0 TO SUB3                                          
                       GO TO PRINT-TRLRS                                        
                   ELSE                                                         
                       MOVE 'OUT' TO PR5-TITLE                                  
               ELSE                                                             
                   MOVE 'INP' TO PR5-TITLE.                                     
           MOVE +0 TO SUB3                                                      
           MOVE '0' TO PR-CC.                                                   
       PRINT-TRLRS.                                                             
           ADD +1 TO SUB3.                                                      
           IF  SUB3 IS GREATER THAN TR-LINCT                                    
               COMPUTE REM-LIN (REPORT-NO) = EOP-IND -                          
                                                 LIN-CTR (REPORT-NO)            
               GO TO BUILD-TRAILERS.                                            
           MOVE TRAILER-LINE (SUB3) TO PR5-TRAILER.                             
           IF  TR-TRAILER EQUAL TO '030' AND SUB3 EQUAL TO +1                   
               AND SUB2 EQUAL TO +1                                             
                   MOVE TR3-IDENT TO PR5-TRIDENT.                               
           IF  TR-TRAILER EQUAL TO '999' AND SUB3 EQUAL TO +1                   
                   MOVE SPACES TO CURR-PSM.                                     
           PERFORM PRINT-IT.                                                    
           MOVE SPACE TO PR-CC.                                                 
           IF LIN-CTR (REPORT-NO) NOT LESS THAN EOP-IND                         
              PERFORM HEAD-ROUT THRU HEAD-EXIT                                  
              IF TR-TRAILER = '080'                                             
                 MOVE TRAILER-LINE (4) TO PR5-TRAILER                           
                 PERFORM PRINT-IT                                               
                 MOVE SPACE TO PR-CC                                            
                 MOVE TRAILER-LINE (5) TO PR5-TRAILER                           
                 PERFORM PRINT-IT                                               
              ELSE                                                              
              IF TR-TRAILER = '150'                                             
                 MOVE TRLR-150-HIST-HEAD1   TO PR5-TRAILER                      
                 PERFORM PRINT-IT                                               
                 MOVE SPACE TO PR-CC                                            
                 MOVE TRLR-150-HIST-HEAD2   TO PR5-TRAILER                      
                 PERFORM PRINT-IT.                                              
           GO TO PRINT-TRLRS.                                                   
                                                                                
       BUILD-TRLR-LINES.                                                        
           IF      TR-TRAILER  EQUAL '000'                                      
               CALL 'GSPTTR00' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER000 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '010'                                      
               CALL 'GSPTTR01' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER010 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '030' OR '040' OR '045'                    
               CALL 'GSPTTRNA' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER030 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '050'                                      
               CALL 'GSPTTR05' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER050 (SUB2), SUB2                       
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '080'                                      
               CALL 'GSPTTR08' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER080 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '090'                                      
               CALL 'GSPTTR09' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER090 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '100'                                      
               CALL 'GSPTTR10' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER100 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '110'                                      
               CALL 'GSPTTR11' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER110 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '120'                                      
               CALL 'GSPTTR12' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER120 (SUB2), SUB2                       
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '125'                                      
               CALL 'GSPTTRAM' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER125 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '130'                                      
               CALL 'GSPTTR13' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER130 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '140'                                      
               CALL 'GSPTTR14' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER140 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER  EQUAL '150'                                      
               CALL 'GSPTTR15' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-TRAILER150 (SUB2)                             
           ELSE                                                                 
                IF TR-TRAILER EQUAL TO '999'                                    
               CALL 'GSPTTPSM' USING TR-LINCT, TRAILER-PRINT-AREA,              
                               TR-POINT-IN-SCALE (SUB2).                        
       BTL-EXIT.                                                                
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *    SPACE OUT THE MASTER CHANGE LINES.  TURN THE SWITCHES ON TO          
      *    INDICATE HEADINGS REQUIRED IF INFO RELATED TO THE MASTER IS          
      *    PRESENT.  SET UP THE PRINT LINES INCLUDING THE ERROR CODES           
      ******************************************************************        
       MAST-LST-CHANGE-PROC.                                                    
           MOVE SPACES          TO SAVE-MASTER-CHG-LINES PR2-TRLR.              
           MOVE '11111'         TO PRT-LST-CHG-IND.                             
           MOVE 'LAST CHANGE  ' TO PR3-TITLE                                    
           MOVE 'IDENT  '  TO  PR3-TITLE1                                       
           MOVE TR3-IDENT  TO  PR3-IDENT                                        
           CALL 'QDATE' USING QDATE-FUNCT TRM-TRDATE PR3-DATE                   
           MOVE PRINT-AREA TO SAVE-MAST-CHG-LINE (1).                           
           IF  TR-RECLENGTH EQUAL +50                                           
               GO TO MAST-LST-CHG-END.                                          
           MOVE +0 TO SUB1, SUB2.                                               
       MAST-LST-CHG-ERR-LOOP.                                                   
           ADD +1 TO SUB1.                                                      
           ADD +1 TO SUB2.                                                      
           IF  SUB1 GREATER THAN +10 OR                                         
               TR-ERROR (SUB1) EQUAL TO SPACES                                  
               IF PRINT-AREA NOT EQUAL TO SPACES                                
                  COMPUTE SUB4 = (SUB1 - 1) / 3 + 1                             
                  MOVE PRINT-AREA TO SAVE-MAST-CHG-LINE (SUB4)                  
                  GO TO MAST-LST-CHG-END                                        
               ELSE                                                             
                  GO TO MAST-LST-CHG-END.                                       
GNE        IF TR-1-CHECK EQUAL TO SPACES                                        
GNE            MOVE TR-1-ERROR (SUB1) TO PR11-ERR (SUB2)                        
GNE        ELSE                                                                 
GNE            MOVE TR-ERROR (SUB1) TO PR11-ERR (SUB2).                         
           IF  SUB2 EQUAL TO +3                                                 
               MOVE +0 TO SUB2                                                  
               COMPUTE SUB4 = (SUB1 - 1) / 3 + 1                                
               MOVE PRINT-AREA TO SAVE-MAST-CHG-LINE (SUB4)                     
               MOVE SPACES TO PRINT-AREA.                                       
           GO TO MAST-LST-CHG-ERR-LOOP.                                         
       MAST-LST-CHG-END.                                                        
           MOVE CURR-TRLR TO PR2-TRLR.                                          
           GO TO GET-BACK.                                                      
                                                                                
      ******************************************************************        
      *    CHECK IF THE LST CHANGE DATE HAS TO BE WRITTEN OUT, FIND THE         
      *    NUMBER OF LINES REQUIRED.  PRODUCE HEADINGS IF NECESSARY.            
      ******************************************************************        
       CHK-MST-LST-PRT.                                                         
           IF PRT-LST-CHG-DATE (REPORT-NO) EQUAL '0'                            
              PERFORM CHECK-GROUP-PRNT THRU CHECK-GROUP-PRNT-EXIT               
              GO TO CHK-MST-LST-PRT-EXIT.                                       
           MOVE '0' TO PRT-LST-CHG-DATE (REPORT-NO).                            
           COMPUTE REM-LIN (REPORT-NO) = EOP-IND - LIN-CTR (REPORT-NO)          
                                         - 3.                                   
           IF SAVE-MAST-CHG-LINE (2) NOT EQUAL SPACES                           
              SUBTRACT +1 FROM REM-LIN (REPORT-NO)                              
              IF SAVE-MAST-CHG-LINE (3) NOT EQUAL SPACES                        
                 SUBTRACT +1 FROM REM-LIN (REPORT-NO)                           
                 IF SAVE-MAST-CHG-LINE (4) NOT EQUAL SPACES                     
                    SUBTRACT +1 FROM REM-LIN (REPORT-NO).                       
           IF REM-LIN (REPORT-NO) LESS THAN +0                                  
                  PERFORM HEAD-ROUT THRU HEAD-EXIT.                             
           MOVE SAVE-MAST-CHG-LINE (1) TO PRINT-AREA.                           
           PERFORM CHECK-GROUP-PRNT THRU CHECK-GROUP-PRNT-EXIT                  
           PERFORM PRINT-IT.                                                    
           IF SAVE-MAST-CHG-LINE (2) EQUAL SPACES                               
              GO TO CHK-MST-INIT.                                               
           MOVE SAVE-MAST-CHG-LINE (2) TO PRINT-AREA.                           
           PERFORM PRINT-IT.                                                    
           IF SAVE-MAST-CHG-LINE (3) EQUAL SPACES                               
              GO TO CHK-MST-INIT.                                               
           MOVE SAVE-MAST-CHG-LINE (3) TO PRINT-AREA.                           
           PERFORM PRINT-IT.                                                    
           IF SAVE-MAST-CHG-LINE (4) NOT EQUAL SPACES                           
              MOVE SAVE-MAST-CHG-LINE (4) TO PRINT-AREA                         
              PERFORM PRINT-IT.                                                 
       CHK-MST-INIT.                                                            
           MOVE '0' TO PR-CC.                                                   
           MOVE CURR-TRLR TO PR2-TRLR.                                          
       CHK-MST-LST-PRT-EXIT.                                                    
           EXIT.                                                                
                                                                                
       MOVE-INCON-ERRS.                                                         
      ******************************************************************        
      *    CALCULATE THE NO. OF LINES REQUIRED TO PRINT INCONSISTENCY           
      *    ERRORS.  PERFORM HEADING ROUTINE IF NOT ENOUGH LINES LEFT ON         
      *    THE PAGE.                                                            
      ******************************************************************        
       NO-OF-INCON-ERRS.                                                        
           IF  TR-RECLENGTH NOT EQUAL +50                                       
               THEN                                                             
                    IF TR-ERROR (+4) NOT EQUAL '   '                            
               SUBTRACT +1 FROM REM-LIN (REPORT-NO)                             
               IF TR-ERROR (+7) NOT EQUAL '   '                                 
               SUBTRACT +1 FROM REM-LIN (REPORT-NO)                             
               IF TR-ERROR (+10) NOT EQUAL '   '                                
               SUBTRACT +1 FROM REM-LIN (REPORT-NO).                            
           IF  REM-LIN (REPORT-NO) LESS THAN +0                                 
                   PERFORM HEAD-ROUT THRU HEAD-EXIT.                            
       NIE-END.                                                                 
      ******************************************************************        
      *    FOR DAILY INCONSISTENCY PRINT LITERAL INDICATING IF MASTER,          
      *    PSM OR RATES/MASTER INCONSISTENCY                                    
      ******************************************************************        
           IF  TRM-UPPROC = 'B' AND CCF-PART1 EQUAL HIGH-VALUES                 
               IF  TR-ACCT = LOW-VALUE                                          
                   MOVE LIT-PSM TO L1-REC-TYP                                   
                   MOVE LIT-1 TO PR4-INCON                                      
                   GO TO INIT-INCON-LOOP                                        
               ELSE                                                             
                   MOVE LIT-MAS TO L1-REC-TYP                                   
                   MOVE LIT-1 TO PR4-INCON                                      
                   GO TO INIT-INCON-LOOP.                                       
           IF  CCF-PART3 EQUAL '2'                                              
               MOVE LIT-MAS-RATES TO L1-REC-TYP                                 
               MOVE LIT-1 TO PR4-INCON                                          
               GO TO INIT-INCON-LOOP.                                           
           IF  CCF-PART3 EQUAL '5'                                              
               MOVE LIT-RATES-MAS TO L1-REC-TYP                                 
               MOVE LIT-1 TO PR4-INCON                                          
               GO TO INIT-INCON-LOOP.                                           
      ******************************************************************        
      *    FOR MONTHLY INCONSISTENCY PRINT LITERAL INDICATING IF MASTER,        
      *    PSM OR RATES/MASTER INCONSISTENCY                                    
      ******************************************************************        
           CALL 'QDATE' USING QDATE-FUNCT TR-RUNDATE L2-DATE                    
           IF  TRM-UPPROC = 'C' AND CCF-PART1 EQUAL '3' AND                     
                                    TR-RECTYP4 EQUAL '2'                        
               IF  TR-ACCT = LOW-VALUE                                          
                   MOVE LIT-PSM TO L2-REC-TYP                                   
                   MOVE LIT-2 TO PR6-INCON                                      
                   GO TO INIT-INCON-LOOP                                        
               ELSE                                                             
                   MOVE LIT-MAS TO L2-REC-TYP                                   
                   MOVE LIT-2 TO PR6-INCON                                      
                   GO TO INIT-INCON-LOOP.                                       
           IF  CCF-PART3 EQUAL '6'                                              
               CALL 'QDATE' USING QDATE-FUNCT TR-PROCESS-DATE L2-DATE.          
           IF  CCF-PART3 EQUAL '3'                                              
               MOVE LIT-MAS-RATES TO L2-REC-TYP                                 
               MOVE LIT-2 TO PR6-INCON.                                         
           IF  CCF-PART3 EQUAL '6'                                              
               MOVE LIT-RATES-MAS TO L2-REC-TYP                                 
               MOVE LIT-2 TO PR6-INCON.                                         
                                                                                
      ******************************************************************        
      *    PRINT THE INCONSISTENCY LINES - THIS IS USED FOR DETAIL,             
      *    RATES AND MASTER ROUTINES.                                           
      ******************************************************************        
       INIT-INCON-LOOP.                                                         
           IF  TR-RECLENGTH EQUAL +50                                           
               PERFORM PRINT-IT                                                 
               GO TO INCON-MOVE-DONE.                                           
           MOVE +0 TO SUB1, SUB2.                                               
       INCON-ERR-LOOP.                                                          
           ADD +1 TO SUB1.                                                      
           IF  SUB1 GREATER THAN +10 OR                                         
               TR-ERROR (SUB1) EQUAL TO SPACES                                  
               IF PR-LINE NOT EQUAL TO SPACES                                   
                  PERFORM PRINT-IT                                              
                    GO TO INCON-MOVE-DONE                                       
               ELSE                                                             
                    GO TO INCON-MOVE-DONE.                                      
           IF  SUB2 EQUAL TO +3                                                 
                   MOVE +0 TO SUB2                                              
                   PERFORM PRINT-IT                                             
                   MOVE ' ' TO PR-CC.                                           
           ADD +1 TO SUB2.                                                      
GNE        IF TR-1-CHECK EQUAL TO SPACES                                        
GNE            MOVE TR-1-ERROR (SUB1) TO PR11-ERR (SUB2)                        
GNE        ELSE                                                                 
GNE            MOVE TR-ERROR (SUB1) TO PR11-ERR (SUB2).                         
           GO TO INCON-ERR-LOOP.                                                
       INCON-MOVE-DONE.                                                         
           IF TR-RECTYP2 EQUAL '2' AND CCF-PART6 EQUAL '3'                      
                                   AND REPORT-NO EQUAL +3                       
              ADD +1 TO REPORT-NO                                               
              GO TO MST-LOOP-FOR-DAILY-INCONSIST.                               
           IF (CCF-PART6 EQUAL '4') AND                                         
                         (TR-RATE-RECTYP2 EQUAL '5' OR '6') AND                 
                         (REPORT-NO EQUAL +2 OR 3)                              
              ADD +1 TO REPORT-NO                                               
              GO TO RATES-ROUT-INC-LOOP.                                        
           GO TO GET-BACK.                                                      
                                                                                
       MASTER-CHANGES.                                                          
      ******************************************************************        
      *    CALCULATE THE NO. OF LINES REQUIRED TO PRINT MASTER CHANGE           
      *    ERRORS.  PERFORM HEADING ROUTINE IF NOT ENOUGH LINES LEFT ON         
      *    THE PAGE.  THIS MUCH DONE FOR ALL CHANGE TYPES (DETAIL, RATE         
      *    BENEFIT AND MASTER                                                   
      ******************************************************************        
                                                                                
       NO-OF-CHANGE-ERRS.                                                       
           IF  TR-RECLENGTH NOT EQUAL +208                                      
               IF TRCH-ERRCODE (+4) NOT EQUAL '   '                             
                  SUBTRACT +1 FROM REM-LIN (REPORT-NO)                          
                  IF TRCH-ERRCODE (+7) NOT EQUAL '   '                          
                     SUBTRACT +1 FROM REM-LIN (REPORT-NO)                       
                     IF TRCH-ERRCODE (+10) NOT EQUAL '   '                      
                        SUBTRACT +1 FROM REM-LIN (REPORT-NO)                    
                     ELSE                                                       
                        NEXT SENTENCE                                           
                  ELSE                                                          
                     NEXT SENTENCE                                              
               ELSE                                                             
                  IF  TRCH-CODE2 NOT = SPACE                                    
                      SUBTRACT +1 FROM REM-LIN (REPORT-NO)                      
                  ELSE                                                          
                      NEXT SENTENCE                                             
           ELSE                                                                 
               IF  TRCH-CODE2 NOT = SPACE                                       
                   SUBTRACT +1 FROM REM-LIN (REPORT-NO).                        
           IF  REM-LIN (REPORT-NO) NOT GREATER THAN +0                          
                   PERFORM HEAD-ROUT THRU HEAD-EXIT.                            
                                                                                
      ******************************************************************        
      *    MOVE CHANGE CODE INFO FOR MASTER AND RATES                           
      ******************************************************************        
       NCE-END.                                                                 
           MOVE TRCH-TRCODE    TO  PR7-TRCODE.                                  
           MOVE TRCH-PAGECARD  TO  PR7-PAGECARD.                                
           MOVE TRCH-BDATE     TO  PR7-BDATE.                                   
           MOVE TRCH-BDEPT     TO  PR7-BDEPT.                                   
           MOVE TRCH-BNUMBER   TO  PR7-BNUMBER.                                 
           MOVE TRCH-TDATE     TO  PR7-TDATE.                                   
           MOVE TRCH-TDEPT     TO  PR7-TDEPT.                                   
           MOVE TRCH-CODE1     TO  PR7-CODE1.                                   
GNE        IF TR-RATE-RECTYP2 = 3 OR TR-FILEID = 3                              
               MOVE TRCH-M-TRCODE    TO  PR7-TRCODE                             
               MOVE TRCH-M-PAGECARD  TO  PR7-PAGECARD                           
               MOVE TRCH-M-BDATE     TO  PR7-BDATE                              
               MOVE TRCH-M-BDEPT     TO  PR7-BDEPT                              
               MOVE TRCH-M-BNUMBER   TO  PR7-BNUMBER                            
               MOVE TRCH-M-TDATE     TO  PR7-TDATE                              
               MOVE TRCH-M-TDEPT     TO  PR7-TDEPT                              
               MOVE TRCH-M-CODE1     TO  PR7-CODE1                              
           END-IF.                                                              
GNE        IF TR-FILEID = 3 AND WS-ADDR-FLAG NOT EQUAL SPACES                   
               MOVE TRCH-MA-TRCODE    TO  PR7-TRCODE                            
               MOVE TRCH-MA-PAGECARD  TO  PR7-PAGECARD                          
               MOVE TRCH-MA-BDATE     TO  PR7-BDATE                             
               MOVE TRCH-MA-BDEPT     TO  PR7-BDEPT                             
               MOVE TRCH-MA-BNUMBER   TO  PR7-BNUMBER                           
               MOVE TRCH-MA-TDATE     TO  PR7-TDATE                             
               MOVE TRCH-MA-TDEPT     TO  PR7-TDEPT                             
               MOVE TRCH-MA-CODE1     TO  PR7-CODE1                             
           END-IF.                                                              
       NCE-RATES-END.                                                           
           MOVE +0 TO SUB3.                                                     
      ******************************************************************        
      *    PRINT THE CHANGE LINES - INCLUDING ERROR CODES.  THIS IS USED        
      *    FOR ALL TYPES - DETAIL, RATES, BENEFIT AND MASTER ROUTINES.          
      ******************************************************************        
       CHANGE-ERR-INIT.                                                         
           IF  TR-RECLENGTH = +208                                              
               PERFORM PRINT-IT                                                 
               MOVE ' ' TO PR-CC                                                
               IF TRCH-CODE2 NOT = SPACE                                        
                       MOVE TRCH-CODE2 TO PR7-CODE1                             
                       PERFORM PRINT-IT                                         
                       GO TO MAST-OUT                                           
                   ELSE                                                         
                       GO TO MAST-OUT.                                          
           MOVE +0 TO SUB1 SUB2.                                                
       MAST-ERR-MOVE.                                                           
           ADD +1 TO SUB1.                                                      
           IF  SUB1 IS GREATER THAN +10 OR                                      
                   TRCH-ERRCODE (SUB1) EQUAL SPACES                             
                   THEN                                                         
                        IF PR-LINE NOT EQUAL TO SPACES                          
                       PERFORM PRINT-IT                                         
                       ADD +1 TO SUB3                                           
                       GO TO MAST-OUT                                           
                   ELSE                                                         
                        GO TO MAST-OUT.                                         
           IF  SUB3 EQUAL TO +1 AND TRCH-CODE2 NOT EQUAL TO SPACES              
                   MOVE ' ' TO PR-CC                                            
                   MOVE TRCH-CODE2 TO PR7-CODE1.                                
           ADD +1 TO SUB2.                                                      
           IF WS-ADDR-FLAG EQUAL SPACES                                         
               MOVE TRCH-ERRCODE (SUB1) TO PR11-ERR (SUB2).                     
           IF WS-ADDR-FLAG NOT EQUAL SPACES                                     
               MOVE TRCH-MA-ERRCODE (SUB1) TO PR11-ERR (SUB2).                  
                                                                                
           IF SUB2 EQUAL +3                                                     
                   ADD +1 TO SUB3                                               
                   MOVE +0 TO SUB2                                              
                   PERFORM PRINT-IT                                             
                   MOVE ' ' TO PR-CC.                                           
           GO TO MAST-ERR-MOVE.                                                 
       MAST-OUT.                                                                
           IF  SUB3 EQUAL TO +1 AND TRCH-CODE2 NOT EQUAL TO SPACES              
                   MOVE ' ' TO PR-CC                                            
                   MOVE TRCH-CODE2 TO PR7-CODE1                                 
                   PERFORM PRINT-IT.                                            
           GO TO GET-BACK.                                                      
                                                                                
       CHANGE-D-ERR-INIT.                                                       
           IF  TR-RECLENGTH = +208                                              
               PERFORM PRINT-IT                                                 
               MOVE ' ' TO PR-CC                                                
               IF TRCH-D-CODE2 NOT = SPACE                                      
                       MOVE TRCH-D-CODE2 TO PR7-CODE1                           
                       PERFORM PRINT-IT                                         
                       GO TO MAST-D-OUT                                         
                   ELSE                                                         
                       GO TO MAST-D-OUT.                                        
           MOVE +0 TO SUB1 SUB2.                                                
       MAST-D-ERR-MOVE.                                                         
           ADD +1 TO SUB1.                                                      
           IF  SUB1 IS GREATER THAN +10 OR                                      
                   TRCH-D-ERRCODE (SUB1) EQUAL SPACES                           
                   THEN                                                         
                        IF PR-LINE NOT EQUAL TO SPACES                          
                       PERFORM PRINT-IT                                         
                       ADD +1 TO SUB3                                           
                       GO TO MAST-D-OUT                                         
                   ELSE                                                         
                        GO TO MAST-D-OUT.                                       
           IF  SUB3 EQUAL TO +1 AND TRCH-D-CODE2 NOT EQUAL TO SPACES            
                   MOVE ' ' TO PR-CC                                            
                   MOVE TRCH-D-CODE2 TO PR7-CODE1.                              
           ADD +1 TO SUB2.                                                      
           MOVE TRCH-D-ERRCODE (SUB1) TO PR11-ERR (SUB2).                       
           IF SUB2 EQUAL +3                                                     
                   ADD +1 TO SUB3                                               
                   MOVE +0 TO SUB2                                              
                   PERFORM PRINT-IT                                             
                   MOVE ' ' TO PR-CC.                                           
           GO TO MAST-D-ERR-MOVE.                                               
       MAST-D-OUT.                                                              
           IF  SUB3 EQUAL TO +1 AND TRCH-D-CODE2 NOT EQUAL TO SPACES            
                   MOVE ' ' TO PR-CC                                            
                   MOVE TRCH-D-CODE2 TO PR7-CODE1                               
                   PERFORM PRINT-IT.                                            
           GO TO GET-BACK.                                                      
                                                                                
      ******************************************************************        
      *    CHANGE THE TRAILER ID INTO A LITERAL FOR REPORT PURPOSES             
      ******************************************************************        
       CONVERT-TRLR-ID.                                                         
           IF TR-TRAILER = '000'                                                
                MOVE 'MGEN' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '010'                                           
                MOVE 'MSTS' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '030'                                           
                MOVE 'MBND' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '040'                                           
                MOVE 'MCND' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '045'                                           
                MOVE 'MOND' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '050'                                           
                MOVE 'MRIN' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '080'                                           
                MOVE 'MBIL' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '090'                                           
                MOVE 'MPAY' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '100'                                           
                MOVE 'MPRM' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '110'                                           
                MOVE 'MAGT' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '120'                                           
                MOVE 'MNOT' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '125'                                           
                MOVE 'MAMD' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '130'                                           
                MOVE 'MTER' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '140'                                           
                MOVE 'MIDC' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '150'                                           
                MOVE 'MTAX' TO CURR-TRLR  PR2-TRLR                              
           ELSE                                                                 
                IF TR-TRAILER = '999'                                           
                MOVE 'MPS' TO CURR-TRLR  PR2-TRLR.                              
       CTI-EXIT.                                                                
           EXIT.                                                                
      ******************************************************************        
      *    CHECK THE LAST GROUP PRINTED ON THIS REPORT TO SEE IF THE            
      *    NEXT GROUP NUMBER SHOULD BE PRINTED.                                 
      ******************************************************************        
       CHECK-GROUP-PRNT.                                                        
           IF PRT-GRP (REPORT-NO) NOT EQUAL TR-GROUP                            
              MOVE TR-GROUP TO PRT-GRP (REPORT-NO)                              
              MOVE TR-GROUP TO PR2-GROUP                                        
              MOVE CURR-ACCT TO PRT-ACCT (REPORT-NO)                            
              MOVE CURR-ACCT TO PR2-ACCT                                        
              MOVE '-' TO PR-CC                                                 
              GO TO CHECK-GROUP-PRNT-EXIT.                                      
           IF PRT-ACCT (REPORT-NO) NOT EQUAL CURR-ACCT                          
              MOVE CURR-ACCT TO PRT-ACCT (REPORT-NO)                            
              MOVE CURR-ACCT TO PR2-ACCT                                        
              MOVE '-' TO PR-CC.                                                
       CHECK-GROUP-PRNT-EXIT.                                                   
           EXIT.                                                                
                                                                                
       GET-BACK.                                                                
           GOBACK.                                                              
