       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. GPRAGCOM.                                                    
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS. THIS MODULE, CALLED BY GPRINTAL, PRODUCES                       
      *         THE FIRST YEAR COMMISSIONS REPORT, IT IS                        
      *         PASSED THE FIRST TYPE 'Q' RECORD AND READS                      
      *         ALL SUBSEQUENT RECORDS UNTIL TYPE CHANGES,                      
      *         AT WHICH POINT IT RETURNS TO THE CALLING                        
      *         MODULE.                                                         
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  START                          *         
      *****************************************************************         
      *                                                               *         
      *  AUG/89  M DRURY  - ADD TWO NEW FIELDS TO ERROR FILE          *         
      *                   - CHANGE ERROR RECORD TO COPY BOOK          *         
      *                   - CHANGE RECORD-AREA (LINKAGE) TO BE COPY   *         
      *                        BOOK.                                  *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  END                            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *                                                               *         
      *                                                               *         
      *DATE-WRITTEN.  MODIFIED MAY 1984.                                        
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77   FILLER                           PIC X(50)   VALUE                  
            '***** START OF WORKING STORAGE FOR GPRAGCOM *****'.                
       01  MAX-LINES       COMP SYNC VALUE +0      PIC S9(4).                   
       01  LINE-COUNT      COMP                    PIC S9(4).                   
       01  LINES-REM       COMP                    PIC S9(4).                   
       01  PAGE-COUNT      COMP-3    VALUE +0      PIC S9(5).                   
       01  ZFUNCT                    VALUE 'AC'    PIC X(2).                    
       01  STORE-AG-CODE   COMP-3                  PIC S9(6).                   
       01  AGENT-TOTAL-PREM        COMP-3          PIC S9(9)V99.                
       01  AGENT-TOTAL-COMM        COMP-3          PIC S9(9)V99.                
       01  FORM-STANDARD             VALUE '91'    PIC X(2).                    
                                                                                
       01  PRINT-SYS038              PIC X(06) VALUE 'SYS038'.                  
       01  PRINT-SYS038-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
                                                                                
       01  WK-AREA.                                                             
           03  PREV-CC-FLD VALUE LOW-VALUE.                                     
               05  P-SEG1.                                                      
                   07  P-SEG2.                                                  
                       09  P-SEG3.                                              
                           11  FILLER              PIC X(1).                    
                       09  FILLER                  PIC X(2).                    
                   07  P-AGENT                     PIC X(6).                    
                                                                                
       01  GFMAGENT-PARAMETERS.                                                 
           03  GFMA-FUNCTION                       PIC X(6).                    
           03  GFMA-ERROR                          PIC X(5).                    
           03  GFMA-RECORD.                                                     
               05  GFMA-KEY.                                                    
                   07  GFMA-CODE       COMP-3      PIC S9(7).                   
                   07  GFMA-ACCT                   PIC X(1).                    
               05  FILLER                          PIC X(8).                    
               05  GFMA-NAME                       PIC X(25).                   
               05  FILLER                          PIC X(33).                   
                                                                                
       01  FIELD-OFFICE-FILE.                                                   
           03  PARM1.                                                           
               05  FOF-DDNAME              PIC X(7)   VALUE 'VSDSI31'.          
               05  FOF-ACCTYPE             PIC X(5)   VALUE 'KEYED'.            
               05  FOF-RECTYPE             PIC X(1)   VALUE 'V'.                
               05  FOF-FUNCTION            PIC X(6)   VALUE 'GETRAN'.           
               05  FOF-ERRCODE             PIC X(5).                            
               05  FOF-READCT              PIC S9(7)  COMP-3.                   
               05  FOF-WRITECT             PIC S9(7)  COMP-3.                   
               05  FOF-UPDATECT            PIC S9(7)  COMP-3.                   
               05  FOF-DELETCT             PIC S9(7)  COMP-3.                   
               05  FOF-RECLGTH             PIC S9(4)  COMP.                     
           03  PARM2.                                                           
               05  FOF-BRANCH             PIC X(5).                             
                                                                                
       01  PARM3.                                                               
                  COPY FDOFFILE REPLACING                                       
                                   ==01  FIELD-OFFICE-FILE.== BY ====.          
                                                                                
      *                                                                         
      *   CHANGE ERROR FILE TO A COPY BOOK.             MARCUS.                 
      *                                                                         
GNE        COPY GERRREC7.                                                       
                                                                                
       01  GIPSY-ACCESS-PARAMETERS.                                             
           03  TRAILER-AREA.                                                    
               05  TRAILER-ID     VALUE '000'      PIC X(3).                    
               05  FILLER                          PIC X(25).                   
               05  TR-COUNTRY                      PIC X(1).                    
               05  FILLER                          PIC X(189).                  
           03  ERROR-CODE         VALUE SPACES     PIC X(3).                    
                                                                                
       01  HEADINGS-FOOTNOTES.                                                  
           03  HEAD-1.                                                          
               05  FILLER                          PIC X(50)  VALUE             
               '1GPRAGCOM     FIRST  YEAR  GROUP  COMMISSIONS  FOR'.            
               05  FILLER                          PIC X(10)  VALUE             
               '  PERIOD  '.                                                    
               05  HD1-FROM-DT                     PIC X(7).                    
               05  FILLER                          PIC X(4)   VALUE             
               ' TO '.                                                          
               05  HD1-TO-DT                       PIC X(7).                    
               05  FILLER                          PIC X(14)  VALUE             
               '       BRANCH '.                                                
               05  HD1-BR-NO                       PIC X(6).                    
               05  FILLER                          PIC X(1)   VALUE ' '.        
               05  HD1-BR-NAME                     PIC X(25).                   
               05  FILLER                          PIC X(7)   VALUE             
               '  PAGE '.                                                       
               05 HD1-PAGE-NUMBER                  PIC ZZZZ9.                   
                                                                                
           03  HEAD-2.                                                          
               05  FILLER                          PIC X(50)  VALUE             
               '                     FOR  DEVELOPMENT  PLAN  VALID'.            
               05  FILLER                          PIC X(21)  VALUE             
               'ATION  PURPOSES  ONLY'.                                         
                                                                                
           03  HEAD-3.                                                          
               05  FILLER                          PIC X(52)  VALUE             
  GNE          '0    AGENT                               GROUP    AC'.          
               05  FILLER                          PIC X(42)  VALUE             
               'CT   AGENT SHARE     FIRST YEAR    PAYMENT'.                    
                                                                                
           03  HEAD-4.                                                          
               05  FILLER                          PIC X(52)  VALUE             
  GNE          '     CODE         AGENT NAME             NUMBER    N'.          
               05  FILLER                          PIC X(42)  VALUE             
               'O   FIRST YR PREM   COMMISSIONS   RECEIVED'.                    
                                                                                
           03  FOOT-1.                                                          
               05  FILLER                          PIC X(50)  VALUE             
               '- NOTE.  ANNUALIZED - COMMISSIONS PAID IN ADVANCE '.            
               05  FILLER                          PIC X(19)  VALUE             
               'OF PREMIUM DUE DATE'.                                           
                                                                                
           03  FOOT-2.                                                          
               05  FILLER                          PIC X(50)  VALUE             
               '         EARNED     - ACTUAL COMMISSION EARNED. RE'.            
               05  FILLER                          PIC X(24)  VALUE             
               ' ANNUALIZED COMMISSIONS.'.                                      
                                                                                
           03  FOOT-3.                                                          
               05  FILLER                          PIC X(50)  VALUE             
               '         PAID       - COMMISSIONS THAT HAVE NOT BE'.            
               05  FILLER                          PIC X(14)  VALUE             
               'EN ANNUALIZED.'.                                                
                                                                                
           03  FOOT-4.                                                          
               05  FILLER                          PIC X(50)  VALUE             
               '         IT IS NECESSARY TO LIST COMMISSIONS FOR A'.            
               05  FILLER                          PIC X(20)  VALUE             
               'LL CAREER CONTRACTS.'.                                          
                                                                                
           03  FOOT-5.                                                          
               05  FILLER                          PIC X(50)  VALUE             
               '         FINANCED AGENTS CAN EASILY BE IDENTIFIED '.            
               05  FILLER                          PIC X(43)  VALUE             
               'FOR PURPOSES OF POSTING VALIDATION CREDITS.'.                   
                                                                                
       01  PRINT-LINE.                                                          
           03  CC                                  PIC X(1).                    
           03  PRT.                                                             
               05  FILLER                          PIC X(3).                    
               05  P-AG-CODE                       PIC X(6).                    
               05  FILLER                          PIC X(3).                    
               05  P-AG-NAME                       PIC X(25).                   
               05  FILLER                          PIC X(3).                    
GNE            05  P-GROUP                         PIC ZZZZZZ9.                 
               05  P-GROUP-X REDEFINES P-GROUP     PIC X(7).                    
               05  FILLER                          PIC X(2).                    
               05  P-ACCT                          PIC X(3).                    
               05  FILLER                          PIC X(3).                    
               05  P-PREM                          PIC ZZ,ZZZ,ZZZ.99.           
               05  P-PREM-DB                       PIC X(2).                    
               05  FILLER                          PIC X(1).                    
               05  P-COMM                          PIC ZZZZ,ZZZ.99.             
               05  P-COMM-DB                       PIC X(2).                    
               05  FILLER                          PIC X(1).                    
               05  P-DT-REC                        PIC X(7).                    
               05  FILLER                          PIC X(3).                    
               05  P-COM-NME                       PIC X(10).                   
               05  FILLER                          PIC X(27).                   
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
       LINKAGE SECTION.                                                         
      *****************************************************************         
      *    CHANGE RECORD-AREA  TO BE COPY BOOK                        *         
      *    CHANGE ALL R-...    TO BE GFY-...         MARCUS           *         
      *****************************************************************         
      *01  RECORD-AREA.                                                         
      *    03  FILLER                              PIC X(4).                    
      *    03  R-KEY-FIELDS.                                                    
      *        05  CUR-CC-FLD.                                                  
      *            07  C-SEG1.                                                  
      *                09  C-SEG2.                                              
      *                    11  C-SEG3.                                          
      *                        13  R-REC-TYPE      PIC X(1).                    
      *                    11  R-BRANCH            PIC X(5).                    
      *                09  R-AGENT                 PIC X(6).                    
      *    03  R-GROUP                   COMP-3    PIC S9(5).                   
      *    03  R-ACCT                              PIC X(3).                    
      *    03  R-PAYDATE                           PIC X(4).                    
      *    03  R-PREM                    COMP-3    PIC S9(7)V99.                
      *    03  R-COMM                    COMP-3    PIC S9(7)V99.                
      *    03  R-FST-YR-TYPE                       PIC X(1).                    
      *    03  R-PROD-CODE                         PIC X.                       
      *    03  R-GFO                               PIC X(5).                    
      *    03  FILLER                              PIC X(32).                   
GNE        COPY GFYCOMM7.                                                       
                                                                                
       01  MISC-DATA.                                                           
           03  FILLER                              PIC X(4).                    
           03  HI-DATE                             PIC X(4).                    
           03  FILLER                              PIC X(20).                   
           03  LO-DATE                             PIC X(4).                    
                                                                                
           COPY GPRPRINT.                                                       
                                                                                
           COPY GPRTPARM.                                                       
                                                                                
           COPY GPRACCUM.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                M. L. S.   MAINLINE SECTION                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PROCEDURE DIVISION USING  GFYCOMMS                                       
                                 MISC-DATA                                      
                                 GPRPRINT                                       
                                 GPRTPARM                                       
                                 GPRACCUM.                                      
      *----------------------------------------------------------------*        
      *-   ADD NEXT LINE TO SET UP ERROR RECORD   MARCUS SEP/89.      -*        
      *----------------------------------------------------------------*        
           MOVE 'Q'      TO      E-REC-TYPE.                                    
           CALL 'ZLINECT' USING MAX-LINES.                                      
           CALL 'QDATE' USING  ZFUNCT                                           
                               LO-DATE                                          
                               HD1-FROM-DT.                                     
           CALL 'QDATE' USING  ZFUNCT                                           
                               HI-DATE                                          
                               HD1-TO-DT.                                       
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-STANDARD.                                 
           GO TO MLS-REINIT-BRANCH.                                             
       MLS-GCR-RTN.                                                             
           MOVE GFY-CC-FLD TO PREV-CC-FLD.                                      
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                GFYCOMMS                                        
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
           IF  TAPE-RETURN IS NOT EQUAL TO +0 THEN                              
               MOVE HIGH-VALUE TO GFY-CC-FLD.                                   
       MLS-CONTROL-RTN.                                                         
           IF  GFY-SEG1 IS EQUAL TO P-SEG1 THEN                                 
               GO TO MLS-NORMAL-PROCESS                                         
           ELSE                                                                 
               PERFORM AGENT-TOTAL THRU                                         
                       AG-TOT-EXIT.                                             
           IF  GFY-SEG2 IS EQUAL TO P-SEG2 THEN                                 
               GO TO MLS-REINIT-AGENT.                                          
           IF  GFY-SEG3 IS EQUAL TO P-SEG3 THEN                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               PERFORM HEAD-RTN THRU                                            
                       HD-RTN-EXIT                                              
               MOVE 'CLOFIL' TO GFMA-FUNCTION                                   
               PERFORM CALL-GFMAGENT THRU                                       
                       CALL-GFMAGENT-EXIT                                       
               MOVE 'CLOFIL' TO FOF-FUNCTION                                    
               CALL 'ZACCVSAM' USING PARM1                                      
                                     PARM2                                      
                                     PARM3                                      
               GOBACK.                                                          
       MLS-REINIT-BRANCH.                                                       
           MOVE GFY-BRANCH TO HD1-BR-NO                                         
                            FOF-BRANCH.                                         
           CALL 'ZACCVSAM' USING PARM1                                          
                                 PARM2                                          
                                 PARM3.                                         
           IF  FOF-ERRCODE IS NOT EQUAL TO LOW-VALUES THEN                      
               MOVE SPACE TO HD1-BR-NAME                                        
               PERFORM BRANCH-ERROR-RTN THRU                                    
                       BR-ERR-EXIT                                              
           ELSE                                                                 
               MOVE FOF-BRANCH-NAME TO HD1-BR-NAME.                             
           PERFORM HEAD-RTN THRU                                                
                   HD-RTN-EXIT.                                                 
       MLS-REINIT-AGENT.                                                        
           IF  CC IS EQUAL TO '-' THEN                                          
               ADD +2  TO  LINE-COUNT.                                          
           IF  LINE-COUNT NOT LESS THAN MAX-LINES THEN                          
               SUBTRACT +2 FROM LINE-COUNT                                      
               PERFORM HEAD-RTN THRU                                            
                       HD-RTN-EXIT.                                             
           MOVE GFY-AGENTCD TO GFMA-CODE                                        
                           STORE-AG-CODE                                        
                           P-AG-CODE.                                           
           MOVE SPACES TO GFMA-ACCT.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *                     GET AGENTS NAME                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE 'SETLIM' TO GFMA-FUNCTION.                                      
           PERFORM CALL-GFMAGENT THRU                                           
                   CALL-GFMAGENT-EXIT.                                          
           IF  GFMA-FUNCTION IS EQUAL TO 'SETLIM' THEN                          
               MOVE 'GETSEQ' TO GFMA-FUNCTION                                   
               PERFORM CALL-GFMAGENT THRU                                       
                       CALL-GFMAGENT-EXIT                                       
               IF  STORE-AG-CODE IS EQUAL TO GFMA-CODE                          
               AND GFMA-FUNCTION IS EQUAL TO 'GETSEQ' THEN                      
                   MOVE GFMA-NAME TO P-AG-NAME.                                 
           IF  STORE-AG-CODE IS NOT EQUAL TO GFMA-CODE THEN                     
               MOVE 'R0810' TO GFMA-ERROR.                                      
           IF GFMA-FUNCTION IS NOT EQUAL TO 'GETSEQ' AND 'SETLIM' THEN          
               PERFORM AGENTS-ERROR-RTN THRU                                    
                       AG-ERR-EXIT.                                             
           MOVE +0 TO AGENT-TOTAL-PREM                                          
                      AGENT-TOTAL-COMM.                                         
       MLS-NORMAL-PROCESS.                                                      
           MOVE GFY-GROUP TO P-GROUP.                                           
           MOVE GFY-GRPACCT TO P-ACCT.                                          
           MOVE GFY-PREMAMNT TO P-PREM.                                         
           MOVE GFY-COMMAMNT TO P-COMM.                                         
           IF  GFY-PREMAMNT IS GREATER THAN +0 THEN                             
               MOVE 'DB' TO P-PREM-DB.                                          
           IF  GFY-COMMAMNT LESS THAN +0 THEN                                   
               MOVE 'DB' TO P-COMM-DB.                                          
           ADD GFY-PREMAMNT TO AGENT-TOTAL-PREM.                                
           ADD GFY-COMMAMNT TO AGENT-TOTAL-COMM.                                
           CALL 'QDATE' USING ZFUNCT                                            
                              GFY-PAYDATE                                       
                              P-DT-REC.                                         
           IF  GFY-FST-YR-TYPE IS EQUAL TO '1' THEN                             
               MOVE 'ANNUALIZED' TO P-COM-NME                                   
           ELSE                                                                 
               IF  GFY-FST-YR-TYPE IS EQUAL TO '4' THEN                         
                   MOVE 'EARNED' TO P-COM-NME                                   
               ELSE                                                             
                   MOVE 'PAID' TO P-COM-NME.                                    
           PERFORM PRINTIT THRU                                                 
                   PR-EXIT.                                                     
           ADD +1 TO LINE-COUNT.                                                
           IF  LINE-COUNT IS NOT LESS THAN MAX-LINES THEN                       
               PERFORM HEAD-RTN THRU                                            
                       HD-RTN-EXIT.                                             
           GO TO MLS-GCR-RTN.                                                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    SUBROUTINES  SECTION                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       AGENT-TOTAL.                                                             
           ADD +2 TO LINE-COUNT.                                                
           IF  LINE-COUNT IS GREATER THAN MAX-LINES THEN                        
               SUBTRACT +2 FROM LINE-COUNT                                      
               PERFORM HEAD-RTN THRU                                            
                       HD-RTN-EXIT                                              
           ELSE                                                                 
               MOVE '0' TO CC.                                                  
           MOVE 'TOTAL' TO P-GROUP-X.                                           
           MOVE AGENT-TOTAL-PREM TO P-PREM.                                     
           MOVE AGENT-TOTAL-COMM TO P-COMM.                                     
           IF  AGENT-TOTAL-PREM GREATER THAN +0 THEN                            
               MOVE 'DB' TO P-PREM-DB.                                          
           IF  AGENT-TOTAL-COMM LESS THAN +0 THEN                               
               MOVE 'DB' TO P-COMM-DB.                                          
           PERFORM PRINTIT THRU                                                 
                   PR-EXIT.                                                     
           MOVE '-' TO CC.                                                      
       AG-TOT-EXIT.                                                             
                   EXIT.                                                        
       HEAD-RTN.                                                                
           IF  PREV-CC-FLD IS EQUAL TO LOW-VALUE THEN                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               COMPUTE LINES-REM = MAX-LINES - LINE-COUNT                       
               PERFORM GET-TO-BOTTOM THRU GET-BOT-EXIT                          
                   UNTIL LINES-REM NOT GREATER THAN +0                          
               MOVE FOOT-1 TO PRINT-LINE                                        
               PERFORM PRINTIT THRU                                             
                       PR-EXIT                                                  
               MOVE FOOT-2 TO PRINT-LINE                                        
               PERFORM PRINTIT THRU                                             
                       PR-EXIT                                                  
               MOVE FOOT-3 TO PRINT-LINE                                        
               PERFORM PRINTIT THRU                                             
                       PR-EXIT                                                  
               MOVE FOOT-4 TO PRINT-LINE                                        
               PERFORM PRINTIT THRU                                             
                       PR-EXIT                                                  
               MOVE FOOT-5 TO PRINT-LINE                                        
               PERFORM PRINTIT THRU                                             
                       PR-EXIT                                                  
               IF  GFY-SEG3 NOT EQUAL TO P-SEG3 THEN                            
                   GO TO HD-RTN-EXIT.                                           
           ADD +1 TO ACCUM-1STYRCOM.                                            
           ADD +1 TO PAGE-COUNT.                                                
           MOVE +15 TO LINE-COUNT.                                              
           MOVE PAGE-COUNT TO HD1-PAGE-NUMBER.                                  
           MOVE HEAD-1 TO  PRINT-LINE.                                          
           PERFORM PRINTIT THRU                                                 
                   PR-EXIT.                                                     
           MOVE HEAD-2 TO  PRINT-LINE.                                          
           PERFORM PRINTIT THRU                                                 
                   PR-EXIT.                                                     
           MOVE HEAD-3 TO  PRINT-LINE.                                          
           PERFORM PRINTIT THRU                                                 
                   PR-EXIT.                                                     
           MOVE HEAD-4 TO  PRINT-LINE.                                          
           PERFORM PRINTIT THRU                                                 
                   PR-EXIT.                                                     
           MOVE '0' TO CC.                                                      
       HD-RTN-EXIT.                                                             
           EXIT.                                                                
       GET-TO-BOTTOM.                                                           
           IF  LINES-REM IS LESS THAN +3 THEN                                   
               MOVE ' ' TO CC                                                   
               SUBTRACT +1 FROM LINES-REM                                       
           ELSE                                                                 
               MOVE '-' TO CC                                                   
               SUBTRACT +3 FROM LINES-REM.                                      
           PERFORM PRINTIT THRU                                                 
                   PR-EXIT.                                                     
       GET-BOT-EXIT.                                                            
           EXIT.                                                                
       PRINTIT.                                                                 
           CALL 'DLSWRITE' USING PRINT-SYS038                                   
                                 PRINT-RETURN                                   
                                 PRINT-LINE                                     
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS038-COUNT.                            
           MOVE SPACE TO PRINT-LINE.                                            
       PR-EXIT.                                                                 
           EXIT.                                                                
       CALL-GFMAGENT.                                                           
           CALL 'GFMAGENT' USING GFMA-FUNCTION                                  
                                 GFMA-ERROR                                     
                                 GFMA-RECORD                                    
                                 GFMA-KEY.                                      
       CALL-GFMAGENT-EXIT.                                                      
           EXIT.                                                                
      *                                                                         
      *   THE FOLLOWING ROUTINE WRITES ERROR RECORDS USED BY GPRERROR           
      *                                                                         
       AGENTS-ERROR-RTN.                                                        
GNE        CALL GZACCMT7 USING GFY-GROUP                                        
GNE                              TRAILER-AREA                                   
GNE                              ERROR-CODE.                                    
           IF ERROR-CODE IS NOT EQUAL TO SPACES THEN                            
              MOVE SPACES TO TR-COUNTRY                                         
           ELSE                                                                 
              IF TR-COUNTRY IS NOT EQUAL TO '0' THEN                            
                 MOVE '1' TO TR-COUNTRY.                                        
           MOVE TR-COUNTRY TO E-COUNTRY.                                        
           IF GFMA-ERROR IS EQUAL TO 'R0810' THEN                               
               MOVE 'A01' TO E-CODE                                             
           ELSE                                                                 
               MOVE 'A02' TO E-CODE.                                            
           MOVE GFY-AGENTCD TO E-AGENT.                                         
      *                                                                         
      *   MOVE THE TWO NEW FIELDS TO THE ERROR FILE     MARCUS.                 
      *                                                                         
           MOVE GFY-PROD-CODE TO E-PROD-CD.                                     
           MOVE GFY-OFFICE TO E-OFFICE.                                         
                                                                                
           PERFORM CALL-ERR-WRT THRU                                            
                   CALL-ERR-WRT-EXIT.                                           
       AG-ERR-EXIT.                                                             
           EXIT.                                                                
       BRANCH-ERROR-RTN.                                                        
           MOVE 'B01' TO E-CODE.                                                
           MOVE GFY-BRANCH TO E-AGENT.                                          
      *                                                                         
      *   MOVE THE TWO NEW FIELDS TO THE ERROR FILE     MARCUS.                 
      *                                                                         
           MOVE GFY-PROD-CODE TO E-PROD-CD.                                     
           MOVE GFY-OFFICE TO E-OFFICE.                                         
                                                                                
           PERFORM CALL-ERR-WRT THRU                                            
                   CALL-ERR-WRT-EXIT.                                           
       BR-ERR-EXIT.                                                             
           EXIT.                                                                
       CALL-ERR-WRT.                                                            
           CALL 'DLSWRITE' USING  TAPE-SYS011                                   
                                  TAPE-RETURN                                   
                                  ERR-REC                                       
                                  TAPE-SYS011-RECSIZE                           
                                  TAPE-SYS011-BLKSIZE                           
                                  TAPE-SYS011-FORMAT                            
                                  TAPE-SYS011-COUNT.                            
       CALL-ERR-WRT-EXIT.                                                       
           EXIT.                                                                
