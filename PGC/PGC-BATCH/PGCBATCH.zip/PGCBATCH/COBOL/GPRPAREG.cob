       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRPAREG.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      ******************************************************************        
      *REMARKS. THE FUNCTION OF THIS MODULE IS TO PROVIDE AN                    
      *         INTERFACE BETWEEN GPRINTAL + GSPPAREG, IT'S                     
      *         ONLY PURPOSE IS TO CONTROL THE READING OF                       
      *         P+A TRANSACTION RECORDS AND PASS THEM TO                        
      *         GSPPAREG WHICH DOES NOT HAVE ANY READING ABILITY                
      *         AS IT IS ALSO CALLED BY GSPLIRT WHERE ALL RECORDS               
      *         ARE PASSED TO IT FROM THE MAINLINE.                             
      *DATE-WRITTEN.  MODIFIED MAY 1984                                         
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
      /                                                                         
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  FIRST-REC-TYPE              PIC X(1).                                
       01  PASS-DATE                   PIC X(4).                                
       01  PASPRT-AREA                 PIC X(133).                              
       01  PASPRT-PARAMETERS.          COPY GSPPRTPM REPLACING                  
                                    ==01  PRINT-PARAMETERS.== BY ====.          
       01  PASTAP-PARAMETERS.                                                   
           03  PASTAP-SYS011           PIC X(6)   VALUE 'SYS011'.               
           03  PASTAP-SYS012           PIC X(6)   VALUE 'SYS012'.               
           03  PASTAP-SYS013           PIC X(6)   VALUE 'SYS013'.               
           03  PASTAP-SYS014           PIC X(6)   VALUE 'SYS014'.               
           03  PASTAP-SYS015           PIC X(6)   VALUE 'SYS015'.               
           03  PASTAP-SYS016           PIC X(6)   VALUE 'SYS016'.               
           03  PASTAP-SYS017           PIC X(6)   VALUE 'SYS017'.               
           03  PASTAP-SYS018           PIC X(6)   VALUE 'SYS018'.               
           03  PASTAP-SYS019           PIC X(6)   VALUE 'SYS019'.               
           03  PASTAP-SYS020           PIC X(6)   VALUE 'SYS020'.               
                                                                                
           03  PASTAP-RETURN           PIC S9(1)  VALUE +0  COMP-3.             
                                                                                
           03  PASTAP-RSIZE11          PIC 9(5)   VALUE 19056.                  
           03  PASTAP-RSIZE12          PIC 9(5)   VALUE 19056.                  
           03  PASTAP-RSIZE13          PIC 9(5)   VALUE 19056.                  
           03  PASTAP-RSIZE14          PIC 9(5)   VALUE 19056.                  
           03  PASTAP-RSIZE15          PIC 9(5)   VALUE 19056.                  
           03  PASTAP-RSIZE16          PIC 9(5)   VALUE 01000.                  
           03  PASTAP-RSIZE17          PIC 9(5)   VALUE 07289.                  
           03  PASTAP-RSIZE18          PIC 9(5)   VALUE 00080.                  
           03  PASTAP-RSIZE19          PIC 9(5)   VALUE 00116.                  
           03  PASTAP-RSIZE20          PIC 9(5)   VALUE 00194.                  
                                                                                
           03  PASTAP-BSIZE11          PIC 9(5)   VALUE 19060.                  
           03  PASTAP-BSIZE12          PIC 9(5)   VALUE 19060.                  
           03  PASTAP-BSIZE13          PIC 9(5)   VALUE 19060.                  
           03  PASTAP-BSIZE14          PIC 9(5)   VALUE 19060.                  
           03  PASTAP-BSIZE15          PIC 9(5)   VALUE 19060.                  
           03  PASTAP-BSIZE16          PIC 9(5)   VALUE 01004.                  
           03  PASTAP-BSIZE17          PIC 9(5)   VALUE 07293.                  
           03  PASTAP-BSIZE18          PIC 9(5)   VALUE 00800.                  
           03  PASTAP-BSIZE19          PIC 9(5)   VALUE 01160.                  
           03  PASTAP-BSIZE20          PIC 9(5)   VALUE 01944.                  
                                                                                
           03  PASTAP-FRMT11           PIC X(2)   VALUE 'VB'.                   
           03  PASTAP-FRMT12           PIC X(2)   VALUE 'VB'.                   
           03  PASTAP-FRMT13           PIC X(2)   VALUE 'VB'.                   
           03  PASTAP-FRMT14           PIC X(2)   VALUE 'VB'.                   
           03  PASTAP-FRMT15           PIC X(2)   VALUE 'VB'.                   
           03  PASTAP-FRMT16           PIC X(2)   VALUE 'VB'.                   
           03  PASTAP-FRMT17           PIC X(2)   VALUE 'VB'.                   
           03  PASTAP-FRMT18           PIC X(2)   VALUE 'FB'.                   
           03  PASTAP-FRMT19           PIC X(2)   VALUE 'FB'.                   
           03  PASTAP-FRMT20           PIC X(2)   VALUE 'VB'.                   
                                                                                
           03  PASTAP-CNTR11           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR12           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR13           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR14           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR15           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR16           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR17           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR18           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR19           PIC S9(7)  VALUE +0  COMP-3.             
           03  PASTAP-CNTR20           PIC S9(7)  VALUE +0  COMP-3.             
      /                                                                         
       LINKAGE SECTION.                                                         
       01  PASS-RECORD.                                                         
           03  FILLER                  PIC X(4).                                
           03  P-A-REC-TYPE            PIC X(1).                                
           03  FILLER                  PIC X(70).                               
       01  MISC-DATA.                                                           
           03  FILLER                  PIC X(4).                                
           03  HI-DATE                 PIC X(4).                                
           03  FILLER                  PIC X(24).                               
       01  PRINT-PARAMETERS. COPY 'GPRPRINT' REPLACING                          
                                            ==01  GPRPRINT.== BY ====.          
       01  TAPE-PARAMETERS. COPY 'GPRTPARM' REPLACING                           
                                            ==01  GPRTPARM.== BY ====.          
       01  REPORT-ACCUMULATORS. COPY 'GPRACCUM' REPLACING                       
                                            ==01  GPRACCUM.== BY ====.          
      /                                                                         
       PROCEDURE DIVISION USING PASS-RECORD                                     
                                MISC-DATA                                       
                                PRINT-PARAMETERS                                
                                TAPE-PARAMETERS                                 
                                REPORT-ACCUMULATORS.                            
           MOVE HI-DATE TO PASS-DATE.                                           
           MOVE P-A-REC-TYPE TO FIRST-REC-TYPE.                                 
           MOVE 'SYS013' TO PRINT-SYS022 OF PASPRT-PARAMETERS.                  
           MOVE 'SYS001' TO PASTAP-SYS015.                                      
       PASSING-LOOP.                                                            
           CALL 'GSPPAREG' USING PASS-RECORD                                    
                                 PASS-DATE                                      
                                 PASPRT-AREA                                    
                                 PASPRT-PARAMETERS                              
                                 PASTAP-PARAMETERS.                             
           IF  P-A-REC-TYPE IS NOT EQUAL TO FIRST-REC-TYPE THEN                 
               MOVE +4 TO PRINT-RETURN22                                        
               CALL 'DLSWRITE' USING PRINT-SYS022  OF PASPRT-PARAMETERS         
                                   PRINT-RETURN22  OF PASPRT-PARAMETERS         
                                   PASPRT-AREA                                  
                                   PRINT-RECSIZE   OF PASPRT-PARAMETERS         
                                   PRINT-BLKSIZE   OF PASPRT-PARAMETERS         
                                   PRINT-FORMATT   OF PASPRT-PARAMETERS         
                                   PRINT-COUNTER22 OF PASPRT-PARAMETERS         
               ADD +3 TO PAGE-CTR22                                             
               ADD PAGE-CTR22 TO ACCUM-PATRANREG                                
               GO TO END-OF-JOB.                                                
           CALL 'DLSREAD' USING  TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 PASS-RECORD                                    
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               MOVE HIGH-VALUE TO P-A-REC-TYPE.                                 
           GO TO PASSING-LOOP.                                                  
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
