       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.      GC2DLY.                                                 
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *DATE-WRITTEN.    AUG 07.                                                 
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *    CREATE DATA LOADER EXTRACT FILE FROM COMMISSION RELEASE     *        
      *    RECORD TO BE USED PRODUCE SUPPLEMENTAL STATEMENTS.          *        
      *         INPUT  - COMMISSION RELEASE RECORDS                    *        
      *         INPUT  - GIPSY MASTER VSAM FILE (GMASTER)              *        
      *         INPUT  - VO PSMASTER FILE  (VOPSMAST)                  *        
      *         INPUT  - VO CONTRACT MASTER FILE (VMASTER)             *        
      *         INPUT  - INPUTS: COMMISSION DATABASE                   *        
      *         OUTPUT - DATA LOADER EXTRACT FILE                      *        
      ******************************************************************        
      *    AUG/07 E. BUNGAY.                                                    
      *         - PROGRAM CREATION.                                             
      *    OCT/08 IBM GR                                                        
      *         - UPGRADED IN ENTERPRISE COMPILER PROJECT                       
      *                                                                         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCDLY          
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
ALME01* JUN2022 - CORRECT THE LOGIC THAT MAPS THE COMMISSION AMOUNT,            
ALME01*           COMMISSION BASE AND COMMISSION RATE TO THE GROUP              
ALME01*           BENEFITS SUPPLEMENTAL COMMISSION STATEMENT                    
      * JUN2024 - CORRECT THE LOGIC THAT PULL THE START/STOP DT WHEN            
      *         - PREM DUE DATE IS ZERO.                                        
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-FIELDS.                                                           
           05  W-S-BEGINS          PIC X(32)  VALUE                             
FXXTOK     'GC2DLY START WORKING STORAGE  '.                                    
                                                                                
           05  WS-GAEDATSR-VERB             PIC X(16).                          
           05  GRACCT-RECORD-OK                           PIC X(01).            
           05  WS-ACCT-STATUS             VALUE SPACES    PIC X(1).             
REN        05  NUM-GROUP-NUMBER           VALUE +0        PIC S9(7).            
           05  WS-SOURCE-CODE             VALUE SPACES    PIC X(5).             
           05  WS-GROUP-NBR7              COMP-3          PIC S9(7).            
GNE        05  WS-GROUP-NBR5              COMP-3          PIC S9(7).            
           05  WS-PREV-GROUP              COMP-3          PIC S9(15).           
           05  WS-GROUP15                                 PIC 9(15).            
           05  WS-GROUP10-5 REDEFINES WS-GROUP15.                               
REN            10  WS-GROUPF10                            PIC 9(08).            
REN            10  WS-GROUPL5                             PIC 9(07).            
           05  WS-GROUP8-7 REDEFINES WS-GROUP15.                                
               10  WS-GROUPF8                             PIC 9(08).            
               10  WS-GROUPL7                             PIC 9(07).            
           05  WS-GROUPX   REDEFINES WS-GROUP15.                                
REN            10  WS-GROUPX10                            PIC X(08).            
REN            10  WS-GROUPX5                             PIC X(07).            
           05  WS-CONTRACT-NUMBER.                                              
REN            10  WS-CONTRACT-F7         VALUE SPACES    PIC X(07).            
REN            10  WS-CONTRACT-L3         VALUE SPACES    PIC X(03).            
           05  WS-PREV-SUB-ACCT                           PIC X(4).             
           05  WS-SUB-ACCOUNT.                                                  
               10  WS-SUB-ACCT1                           PIC X(1).             
               10  WS-SUB-ACCT3                           PIC X(3).             
           05  WS-POLICY-NUM              COMP-3          PIC S9(7).            
           05  WS-FOGL-CODE.                                                    
               10  WS-FOGL-CODE4                          PIC 9(4).             
               10  FILLER                                 PIC 9(2).             
               10  WS-FOGL-CODE7                          PIC 9(1).             
               10  FILLER                                 PIC 9(3).             
           05  WS-LOGIC-TYPE                              PIC X(16).            
                                                                                
       01  WS-COUNTERS.                                                         
           05  AGT-SUB            COMP-3  VALUE +0        PIC S9.               
           05  TRL-SUB            COMP-3  VALUE +0        PIC S9.               
           05  SUB                COMP-3  VALUE +0        PIC S9.               
           05  WS-SEQ-NUMBER              VALUE ZEROS     PIC 9(7).             
           05  WS-TOT-VMASTER-CNT                         PIC 9(7).             
           05  WS-TOT-DETAIL-CNT                          PIC 9(9).             
ALME01     05  WS-G-C-SUB                 VALUE +0        PIC S99.              
                                                                                
       01  WS-SWITCHES.                                                         
ALME01     05  WS-END-SEARCH              VALUE 'N'       PIC X.                
ALME01         88  END-SEARCH-YES         VALUE 'Y'.                            
           05  WS-TERM-SWITCH             VALUE 'N'       PIC X.                
           05  WS-COMP-SWITCH             VALUE 'N'       PIC X.                
           05  WS-FIRST-YEAR-SWITCH       VALUE 'N'       PIC X.                
               88  FIRST-YEAR             VALUE 'Y'.                            
           05  WS-LONG-FIRST-YEAR-SWITCH  VALUE 'N'       PIC X.                
               88  LONG-FIRST-YEAR        VALUE 'Y'.                            
           05  WS-COMP-DONE               VALUE 'N'       PIC X.                
           05  WS-GRACCT-FOUND            VALUE 'N'       PIC X.                
               88  GRACCT-FOUND           VALUE 'Y'.                            
               88  GRACCT-NOT-FOUND       VALUE 'N'.                            
           05  WS-WRITE-EXTRACT           VALUE 'N'       PIC X.                
               88  WRITE-EXTRACT          VALUE 'Y'.                            
           05  WS-START-DATE-SWITCH       VALUE 'N'       PIC X.                
               88  START-DATE-NOT-FOUND   VALUE 'N'.                            
               88  START-DATE-FOUND       VALUE 'Y'.                            
           05  WS-STOP-DATE-SWITCH        VALUE 'N'       PIC X.                
               88  STOP-DATE-FOUND        VALUE 'Y'.                            
           05  AGENT-SWITCH               VALUE 'N'       PIC X.                
               88  AGENT-INFO-FOUND       VALUE 'Y'.                            
           05  GIPSY-SWITCH               VALUE 'N'       PIC X.                
               88  GIPSY-FOUND            VALUE 'Y'.                            
               88  GIPSY-NOT-FOUND        VALUE 'N'.                            
           05  WS-END-OF-COMM-FILE        VALUE 'N'       PIC X.                
               88  END-OF-COMMISSIONS     VALUE 'Y'.                            
           05  WS-SERIOUS-ERROR-SW        VALUE 'N'       PIC X.                
               88  SERIOUS-ERROR          VALUE 'Y'.                            
           05  WS-END-OF-DLOADER-FILE     VALUE 'N'       PIC X.                
               88  END-OF-DLOADER         VALUE 'Y'.                            
           05  WS-END-OF-DATEPARM         VALUE 'N'       PIC X.                
               88  END-OF-DATEPARM        VALUE 'Y'.                            
           05  WS-VALID-RENEW-DATE        VALUE 'N'       PIC X.                
               88  VALID-RENEW-DATE       VALUE 'Y'.                            
               88  INVALID-RENEW-DATE     VALUE 'N'.                            
           05  WS-RECONCILED-SW                           PIC X(01).            
               88  RECONCILED             VALUE 'Y'.                            
               88  NOT-RECONCILED         VALUE 'N'.                            
           05  WS-VMASTER-EOF                             PIC X.                
                                                                                
       01  WS-DATES.                                                            
           05  WS-START-DATE              VALUE SPACES    PIC X(8).             
           05  WS-STOP-DATE               VALUE SPACES    PIC X(8).             
           05  WS-TEST-YEAR        COMP-3 VALUE ZEROES    PIC S9(3).            
           05  WS-GTMEFFECTIVE-YYY COMP-3 VALUE ZEROS     PIC S9(3).            
           05  WS-TERM-EFFECTIVE-DATE.                                          
               10  WS-TERM-EFFECTIVE-DATE-YYYY            PIC 9(4).             
               10  WS-TERM-EFFECTIVE-DATE-MM              PIC 9(2).             
               10  WS-TERM-EFFECTIVE-DATE-DD              PIC 9(2).             
           05  WS-TERM-PROCESS-DATE.                                            
               10  WS-TERM-PROCESS-DATE-YYYY              PIC 9(4).             
               10  WS-TERM-PROCESS-DATE-MM                PIC 9(2).             
               10  WS-TERM-PROCESS-DATE-DD                PIC 9(2).             
           05  WS-DACR-ACCT-EFF-DATE-A1YS1D VALUE SPACES  PIC X(8).             
           05  WS-LAST-RECON-DATE         VALUE SPACES    PIC X(8).             
           05  WS-LAST-RECON-DATE-A1D     VALUE SPACES    PIC X(8).             
           05  WS-LAST-RECON-DATE-A1DS1Y  VALUE SPACES    PIC X(8).             
           05  WS-LAST-RECON-DATE-A1Y     VALUE SPACES    PIC X(8).             
           05  WS-NEXT-RECON-DATE-A1D     VALUE SPACES    PIC X(8).             
           05  WS-NEXT-RECON-DATE-A1Y     VALUE SPACES    PIC X(8).             
           05  WS-NEXT-RECON-DATE-S1Y     VALUE SPACES    PIC X(8).             
           05  WS-CONVERT-DATE-BEFORE     VALUE SPACES    PIC X(8).             
           05  WS-CONVERT-DATE-AFTER      VALUE SPACES    PIC X(8).             
           05  WS-NEXT-RECON-DATE         VALUE SPACES    PIC X(8).             
           05  WS-RENEW-EFFECT-DATE.                                            
               10  WS-RENEW-EFFECT-DATE-YYYY              PIC 9(4).             
               10  WS-RENEW-EFFECT-DATE-MM                PIC 9(2).             
               10  WS-RENEW-EFFECT-DATE-DD                PIC 9(2).             
           05  WS-RENEW-EFFECT-DATE-S1Y.                                        
               10  WS-RENEW-EFFECT-DATE-SYYYY             PIC 9(4).             
               10  WS-RENEW-EFFECT-DATE-SMM               PIC 9(2).             
               10  WS-RENEW-EFFECT-DATE-SDD               PIC 9(2).             
           05  WS-RENEW-EFFECT-DATE-S1D.                                        
               10  WS-RENEW-EFFECT-DATE-S1D-YYYY          PIC 9(4).             
               10  WS-RENEW-EFFECT-DATE-S1D-MM            PIC 9(2).             
               10  WS-RENEW-EFFECT-DATE-S1D-DD            PIC 9(2).             
           05  WS-PROC-DATE               VALUE SPACES    PIC X(8).             
           05  WS-GAGSTART-DATE COMP-3.                                         
               10  WS-GAGSTART-YEAR       VALUE ZEROS     PIC S9(3).            
               10  WS-GAGSTART-DAY        VALUE ZEROS     PIC S9(3).            
           05  WS-GAGSTOP-DATE COMP-3.                                          
               10  WS-GAGSTOP-YEAR        VALUE ZEROS     PIC S9(3).            
               10  WS-GAGSTOP-DAY         VALUE ZEROS     PIC S9(3).            
           05  WS-ACCT-EFFECT-DATE.                                             
               10  WS-ACCT-EFF-YYYY                       PIC 9(4).             
               10  WS-ACCT-EFF-MM                         PIC 9(2).             
               10  WS-ACCT-EFF-DD                         PIC 9(2).             
           05  WS-WORK-DATE-JUL COMP-3.                                         
               10  WS-WORK-DATE-YYY      VALUE ZEROS      PIC S9(3).            
               10  WS-WORK-DATE-DDD      VALUE ZEROS      PIC S9(3).            
           05  WS-PSM-RENEW-DATE COMP-3.                                        
               10  WS-PSM-RENEW-YEAR     VALUE ZEROS      PIC S9(3).            
               10  WS-PSM-RENEW-DAY      VALUE ZEROS      PIC S9(3).            
           05  WS-PREM-DUE-DATE COMP-3.                                         
               10  WS-PREM-DUE-YYY       VALUE ZEROS      PIC S9(3).            
               10  WS-PREM-DUE-DDD       VALUE ZEROS      PIC S9(3).            
           05  WS-JULIAN-DATE COMP-3.                                           
               10  WS-JULIAN-YYY         VALUE ZEROS      PIC S9(3).            
               10  WS-JULIAN-DDD         VALUE ZEROS      PIC S9(3).            
           05  WS-WORK-DATE.                                                    
               10  WS-WORK-DATE-YYYY     VALUE ZEROS      PIC 9(4).             
               10  WS-WORK-DATE-MM       VALUE ZEROS      PIC 9(2).             
               10  WS-WORK-DATE-DD       VALUE ZEROS      PIC 9(2).             
           05  WS-COMP-EFF-DATE.                                                
               10  WS-COMP-EFF-DATE-YYYY VALUE ZEROS      PIC 9(4).             
               10  WS-COMP-EFF-DATE-MM   VALUE ZEROS      PIC 9(2).             
               10  WS-COMP-EFF-DATE-DD   VALUE ZEROS      PIC 9(2).             
           05  WS-PREM-DUE-DATE-X8.                                             
               10  WS-PREM-DUE-DATE-YYYY VALUE ZEROS      PIC 9(4).             
               10  WS-PREM-DUE-DATE-MM   VALUE ZEROS      PIC 9(2).             
               10  WS-PREM-DUE-DATE-DD   VALUE ZEROS      PIC 9(2).             
           05  WS-COMP-PROC-DATE.                                               
               10  WS-COMP-PROC-DATE-YYYY VALUE ZEROS     PIC 9(4).             
               10  WS-COMP-PROC-DATE-MM   VALUE ZEROS     PIC 9(2).             
               10  WS-COMP-PROC-DATE-DD   VALUE ZEROS     PIC 9(2).             
                                                                                
      *01  DATE-PARAMETERS.      COPY GARDATEP.                                 
                                                                                
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
           03  FILLER                                     PIC X(30).            
                                                                                
      *----------------------------------------------                           
      *  VO PS MASTER                                                           
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
             ' **** VO PS MASTER  ****    '.                                    
           COPY VOPSMAST.                                                       
                                                                                
      *----------------------------------------------                           
      *  PSMASTER                                                               
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
FXXTOK       ' **** PSMASTE7  ****    '.                                        
      * PSMASTE7                                                                
CPYNME     COPY PSMASTE7.                                                       
                                                                                
      *----------------------------------------------------------------         
      *    VO CONTRACT MASTER RECORD - VMASTER                                  
      *----------------------------------------------------------------         
      *01  VMASTER.                                                             
MAN02 *%   COPY VMASTER.                                                        
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  VOGPWRA7                  VALUE 'VOGPWRA7' PIC X(8).             
           05  GC2DATE                   VALUE 'GC2DATE'  PIC X(8).             
           05  GAEDATSR                     PIC X(8)  VALUE 'GAEDATSR'.         
                                                                                
       01  VOGPWRA7-PROTOCOL.                                                   
                                         COPY VOGPWCIO.                         
       01  VOGPW-DATA-RECORD                              PIC X(15700).         
                                                                                
      *****************************************************************         
      *    GACDATE                                                              
      ******************************************************************        
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
      *-----------------------------                                            
      *          DATASERVER RECORDS                                             
      *-----------------------------                                            
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
       01  LOGICAL-RECORD-NAMES.                                                
                                      COPY HCSLRNAM.                            
              10  LR-COMMSSN-IN       PIC X(16) VALUE 'CARD-DATA-070'.          
              10  LR-GARDTCRD-IN      PIC X(16) VALUE 'CARD-DATA-011'.          
              10  LR-DLOADER-IN       PIC X(16) VALUE 'CARD-DATA-012'.          
              10  LR-DLOADER-OUT      PIC X(16) VALUE 'PRINT-DATA-020'.         
              10  LR-DLRFTP-OUT       PIC X(16) VALUE 'PRINT-DATA-022'.         
              10  LR-DLRERR-OUT       PIC X(16) VALUE 'PRINT-DATA-023'.         
                                                                                
      *----------------------------------------------------                     
      *          GIPSY ACCESS MODULE PARMS                                      
      *----------------------------------------------------                     
       01  GACCDMA7-PS-PARMS.                                                   
           05  GACCDMA7-PS-FUNC             PIC S9(4) COMP VALUE +18.           
REN        05  GACCDMA7-PS-GROUP            PIC S9(7) COMP-3.                   
           05  GACCDMA7-PS-ACCT             PIC X(3).                           
           05  GACCDMA7-PS-CERT             PIC S9(9) COMP-3.                   
           05  GACCDMA7-PS-WORK             PIC X(9).                           
       01  GACCDMA7-PS-RETURN               PIC X(3).                           
           88  GACCDMA7-PS-RET-OK                     VALUE '   '.              
           88  GACCDMA7-PS-EOF                        VALUE 'R01'.              
           88  GACCDMA7-PS-NOT-FOUND                  VALUE 'R01'.              
           88  GACCDMA7-PS-DISK-ERROR                 VALUE 'R03'.              
           88  GACCDMA7-PS-FUNC-INVALID               VALUE 'R09'.              
                                                                                
      *****************************************************************         
      *    TEXT LINES                                                           
      *****************************************************************         
       01  IN-COM-RELEASE-RECORD.                                               
           05  FILLER                       PIC X(4).                           
           05  IN-COM-RECORD                PIC X(300).                         
      *01  COMMISSIONS RELEASE RECORD.                                          
           COPY GCOMDACR.                                                       
                                                                                
       01  GARDTCRD-RECORD.                                                     
           COPY GARDTCRD.                                                       
                                                                                
       01  DATALOADER-RECORD.                                                   
           COPY GCOMSUPL.                                                       
                                                                                
       01  DLOADER-FTP-RECORD.                                                  
           05  FILLER      PIC X(80) VALUE 'SUPPLEMENTAL EXTRACT SENT'.         
                                                                                
      *************************************************************             
      *      COMMISSIONS SUPPLEMENTAL ERROR RECORD                *             
      *               RECORD LENGTH 80                            *             
      *************************************************************             
       01  DLOADER-ERROR-RECORD.                                                
           05  FILLER                    PIC X(6)  VALUE ' ADV: '.              
           05  DER-ADVISOR-NUMBER        PIC X(6).                              
           05  FILLER                    PIC X(6)  VALUE ' GRP: '.              
REN        05  DER-GROUP-NUMBER          PIC X(7).                              
           05  FILLER                    PIC X(7)  VALUE ' ACCT: '.             
           05  DER-SUB-ACCOUNT           PIC X(3).                              
           05  FILLER                    PIC X(17) VALUE                        
FXXTOK                                        '  MSG= GC2DLY: '.                
           05  DER-DESCRIPTION           PIC X(30).                             
                                                                                
       01  DER-MESSAGE-LIST.                                                    
           05  DER-1.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'GIPSY MASTER / VCM NOT FOUND  '.                         
           05  DER-2.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'DATE PARAMETER FILE EMPTY     '.                         
           05  DER-3.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'CURR DATE NOT FND IN DATE FILE'.                         
           05  DER-4.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'COMMISSIONS INPUT FILE EMPTY  '.                         
           05  DER-5.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'UNKNOWN ENTRY, NOT WRITTEN OUT'.                         
           05  DER-6.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID ACCT EFFECTIVE DATE   '.                         
           05  DER-7.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID NEXT RECON DATE       '.                         
           05  DER-8.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID NEXT RECON DATE + 1 YR'.                         
           05  DER-9.                                                           
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID NEXT RECON DATE - 1 YR'.                         
           05  DER-10.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID LAST RECON DATE       '.                         
           05  DER-11.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID LAST RECON DATE + 1 YR'.                         
           05  DER-12.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID GTMEFFECTIVE DATE     '.                         
           05  DER-13.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID GTMPROCESSED DATE     '.                         
           05  DER-14.                                                          
               10  FILLER                PIC X(30)  VALUE                       
FXXTOK                'COULD NOT READ GIPSY PSMASTE7 '.                         
           05  DER-15.                                                          
               10  FILLER                PIC X(30)  VALUE                       
FXXTOK                'SEVERE ERROR:  GIPSY PSMASTE7 '.                         
           05  DER-16.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID GAGSTART-DATE         '.                         
           05  DER-17.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID GAGSTOP-DATE          '.                         
           05  DER-18.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID RENEWAL DATE CONVERSN '.                         
           05  DER-19.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID COMP-PROCESS-DATE     '.                         
           05  DER-20.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'INVALID COMP-EFF-DATE         '.                         
           05  DER-21.                                                          
               10  FILLER                PIC X(30)  VALUE                       
                      'GWCORGRACCT ERROR - NOT FOUND '.                         
                                                                                
       01  DER-MESSAGE-TABLE REDEFINES DER-MESSAGE-LIST.                        
           05  DER-MESSAGE-ENTRY OCCURS 21 TIMES.                               
               10  DER-MESSAGE              PIC X(30).                          
                                                                                
       01  DER-SUB                          PIC S9(4) VALUE +0   COMP.          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   MESSAGES USED FOR THE ERROR LOGIC USING THE CALL TO WTL     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X               PIC X(04).                          
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES-AREA.                                               
               10  WTL-MESS-LENGTH          PIC S9(3) VALUE +133 COMP-3.        
               10  WTL-MESS-CC              PIC X(1)  VALUE SPACES.             
               10  WTL-MESS-TEXT            PIC X(132) VALUE SPACES.            
           05  WTL-FLAG                     PIC X(1)  VALUE 'B'.                
           05  WTL-REPLY                    PIC X(3)  VALUE 'NO '.              
           05  WTL-REPLY-AREA               PIC X(80) VALUE SPACES.             
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                        PIC X(80) VALUE                     
FXXTOK        'GC2DLY - ERROR READING GARDTCRD / DLSI11'.                       
           05  WTL-2                        PIC X(80) VALUE                     
FXXTOK        'GC2DLY - ERROR READING DACR INPUT / DLSI10'.                     
           05  WTL-3                        PIC X(80) VALUE                     
FXXTOK        'GC2DLY - ERROR READING SUPPLEMENTAL FILE / DLSI12'.              
           05  WTL-4                        PIC X(80) VALUE                     
FXXTOK        'GC2DLY - ERROR WRITING SUPPLEMENTAL FILE / DLSO20'.              
           05  WTL-5                        PIC X(80) VALUE                     
FXXTOK        'GC2DLY - ERROR WRITING ERROR FILE / DLSO23'.                     
           05  WTL-6                        PIC X(80) VALUE                     
FXXTOK        'GC2DLY - ERROR WRITING FTP TRIGGER FILE / DLSO22'.               
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY OCCURS 6 TIMES.                                
               10  WTL-MESSAGE              PIC X(80).                          
                                                                                
       01  WTL-SUB                          PIC S9(4) VALUE +0   COMP.          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       01  FILLER                           PIC X(32) VALUE                     
             'SUBSCHEMA-CONTROL               '.                                
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       01  FILLLER                          PIC X(32) VALUE                     
             ' **** GWCORGRACCT   ****       '.                                 
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
                                                                                
       01  FILLLER                          PIC X(32) VALUE                     
             ' **** GWCORCOMP   ****       '.                                   
                                                                                
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
                                                                                
       01  W-S-ENDS                         PIC X(30) VALUE                     
FXXTOK     'GC2DLY END WORKING STORAGE'.                                        
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA                                              
FLT30                              END-EXEC.                                    
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GACBMAS7                     PIC X(8)  VALUE 'GACBMAS7'.         
MAN07      05  CEE3ABD                      PIC X(8)  VALUE 'CEE3ABD'.          
MAN07      05  SNAPAID                      PIC X(8)  VALUE 'SNAPAID'.          
GNE    01  ABDCODE                          PIC S9(4) COMP VALUE +1043.         
GNE    01  ABDCLEANUP                       PIC S9(4) COMP VALUE +1.            
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2DLY'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       0000-GWCOCDLY.                                                           
                                                                                
           PERFORM 1000-INITIALIZATION THRU                                     
                   1000-INITIALIZATION-EXIT.                                    
                                                                                
           PERFORM 2000-PROCESS-COMMISSION THRU                                 
                   2000-PROCESS-COMMISSION-EXIT UNTIL                           
                   END-OF-COMMISSIONS.                                          
                                                                                
           PERFORM 1900-FINALIZATION THRU                                       
                   1900-FINALIZATION-EXIT.                                      
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
                                                                                
       0000-GWCOCDLY-EXIT.                                                      
           EXIT.                                                                
                                                                                
       1000-INITIALIZATION.                                                     
      *****************************************************                     
           INITIALIZE DLOADER-ERROR-RECORD.                                     
           MOVE SPACES              TO GARDTCRD-IDENTIFIER.                     
           MOVE 0                   TO GARDTCRD-DAY.                            
           MOVE SPACES              TO GARDTCRD-MON.                            
           MOVE 0                   TO GARDTCRD-YY.                             
           MOVE 'N'                 TO WS-END-OF-DATEPARM                       
                                       WS-SERIOUS-ERROR-SW.                     
           MOVE ZEROS               TO WS-TOT-DETAIL-CNT                        
                                       WS-POLICY-NUM                            
                                       WS-TOT-VMASTER-CNT.                      
FXXTOK     MOVE 'GC2DLY'          TO ICBM-PROGRAM-NAME.                         
           MOVE LOW-VALUES          TO LINKAGE-CONTROL.                         
                                                                                
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2DLY' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA3 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      ****************************************************                      
      ***    GET CURRENT DATE FROM DATE PARM FILE      ***                      
      ****************************************************                      
           MOVE LR-GARDTCRD-IN             TO LOGICAL-RECORD-NAME.              
           MOVE OBTAIN-FIRST               TO WS-GAEDATSR-VERB.                 
                                                                                
           PERFORM 9000-READ-REC-SYS011                                         
              THRU 9000-READ-REC-SYS011-EXIT.                                   
                                                                                
           IF END-OF-DATEPARM                                                   
              MOVE SPACES                   TO DER-GROUP-NUMBER                 
              MOVE SPACES                   TO DER-SUB-ACCOUNT                  
              MOVE SPACES                   TO DER-ADVISOR-NUMBER               
              MOVE +2                       TO DER-SUB                          
              MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION                     
              MOVE 'Y'                      TO WS-SERIOUS-ERROR-SW              
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
                                                                                
             IF GARDTCRD-IDENTIFIER NOT = 'CURRENT'                             
                MOVE OBTAIN-NEXT           TO WS-GAEDATSR-VERB                  
                PERFORM 9000-READ-REC-SYS011                                    
                   THRU 9000-READ-REC-SYS011-EXIT                               
                  UNTIL GARDTCRD-IDENTIFIER = 'CURRENT'                         
                     OR END-OF-DATEPARM                                         
                                                                                
                IF END-OF-DATEPARM                                              
                   MOVE SPACES                TO DER-GROUP-NUMBER               
                   MOVE SPACES                TO DER-SUB-ACCOUNT                
                   MOVE SPACES                TO DER-ADVISOR-NUMBER             
                   MOVE +3                    TO DER-SUB                        
                   MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION                
                   MOVE 'Y'                   TO WS-SERIOUS-ERROR-SW            
                   PERFORM 9400-WRITE-REC-SYS023                                
                      THRU 9400-WRITE-SYS023-EXIT                               
                END-IF                                                          
             END-IF                                                             
           END-IF.                                                              
                                                                                
           COMPUTE WS-TEST-YEAR = GARDTCRD-Y4 - 1800 - 1.                       
                                                                                
      *****************************************************************         
      ** GET MONTHLY ADVISOR FROM & TO DATES FROM THE PARM DATE FILE **         
      *****************************************************************         
           MOVE GARDTCRD-Y4M2D2         TO WS-PROC-DATE.                        
                                                                                
      *****************************************************                     
      *  OPEN FILES (VCM/GIPSY FILES)                     *                     
      *****************************************************                     
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-OPEN-FILES     TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 8100-READ-VCM-GIPSY THRU 8100-READ-VCM-GIPSY-EXIT.           
                                                                                
      *****************************************************                     
      *  READ NEXT (VCM/GIPSY FILES)                     *                      
      *****************************************************                     
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-READ-NEXT      TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 8100-READ-VCM-GIPSY THRU 8100-READ-VCM-GIPSY-EXIT.           
           IF VGWO-RET-OK                                                       
FXXTOK             MOVE VOGPW-DATA-RECORD TO GMASTER7                           
           ELSE                                                                 
             IF VGWO-RET-SEVERE-ERROR                                           
FXXTOK          GO TO 799-SQL-STATUS                                            
             END-IF.                                                            
                                                                                
      ***************************************************************           
      ***    RETRIEVE SEQUENCE NUMBER FROM PREVIOUS SUPPLEMENTAL  ***           
      ***    FILE, ADD 1 TO IT AND MOVE TO EXTRACT HEADER RECORD  ***           
      ***************************************************************           
           MOVE OBTAIN-FIRST               TO WS-GAEDATSR-VERB.                 
           PERFORM 9200-READ-REC-SYS012 THRU 9200-READ-REC-SYS012-EXIT.         
           IF END-OF-DLOADER                                                    
              MOVE 1                     TO WS-SEQ-NUMBER                       
           ELSE                                                                 
              MOVE LEXTRACT-SEQUENCE-NUMBER TO WS-SEQ-NUMBER                    
              COMPUTE WS-SEQ-NUMBER = WS-SEQ-NUMBER + 1                         
           END-IF.                                                              
                                                                                
      ********************************************************                  
      ***  READ FIRST COMMISSION INPUT RECORD              ***                  
      ***  IF NO RECORDS ON INPUT FILE WRITE MESSAGE TO    ***                  
      ***  ERROR FILE.                                     ***                  
      ********************************************************                  
           MOVE 'N'                         TO WS-END-OF-COMM-FILE.             
           MOVE OBTAIN-FIRST                TO WS-GAEDATSR-VERB.                
           PERFORM 9100-READ-REC-SYS010 THRU 9100-READ-REC-SYS010-EXIT.         
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
             IF END-OF-COMMISSIONS                                              
                MOVE SPACES                 TO DER-GROUP-NUMBER                 
                MOVE SPACES                 TO DER-SUB-ACCOUNT                  
                MOVE SPACES                 TO DER-ADVISOR-NUMBER               
                MOVE +4                     TO DER-SUB                          
                MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION                   
                MOVE 'Y'                    TO WS-SERIOUS-ERROR-SW              
                PERFORM 9400-WRITE-REC-SYS023                                   
                   THRU 9400-WRITE-SYS023-EXIT                                  
             END-IF                                                             
           END-IF.                                                              
           MOVE 0                           TO WS-PREV-GROUP.                   
           MOVE SPACES                      TO WS-PREV-SUB-ACCT.                
                                                                                
       1000-INITIALIZATION-EXIT.                                                
           EXIT.                                                                
                                                                                
       1900-FINALIZATION.                                                       
      ********************************************************                  
      ***  WRITE SUPPLEMENTAL HEADER RECORD                ***                  
      ********************************************************                  
           MOVE SPACES                TO DATALOADER-RECORD.                     
           MOVE WS-TOT-DETAIL-CNT     TO LEXTRACT-TOTAL-DETAIL-REC.             
           MOVE WS-SEQ-NUMBER         TO LEXTRACT-SEQUENCE-NUMBER.              
           MOVE 'H'                   TO LEXTRACT-DET-RECTYPE.                  
           MOVE 'SUPPLEMENT'          TO LEXTRACT-FILE-TYPE.                    
           MOVE 'MANULIFE  '          TO LEXTRACT-SYSTEM-IDENTIFIER.            
           MOVE WS-PROC-DATE          TO LEXTRACT-DATE.                         
                                                                                
           PERFORM 9300-WRITE-DLOADER-SYS020 THRU                               
                   9300-WRITE-DLOADER-SYS020-EXIT.                              
                                                                                
           PERFORM 9500-WRITE-DLRFTP-SYS022 THRU                                
                   9500-WRITE-DLRFTP-SYS022-EXIT.                               
                                                                                
      ********************************************************                  
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
      ********************************************************                  
           MOVE SPACES                TO VOGPWRAP-OUTPUT                        
                                         VOGPW-DATA-RECORD.                     
           MOVE SPACES                TO VGWI-SOURCE-SYSTEM.                    
           MOVE 'CLOSE FILES'         TO VGWI-REQUEST.                          
           MOVE SPACES                TO VGWI-COVERAGE-TYPE.                    
           MOVE 0                     TO VGWI-GROUP.                            
           MOVE SPACES                TO VGWI-ACCOUNT.                          
           MOVE 'GIPSY EXPANDED'      TO VGWI-LR-NAME.                          
           PERFORM 8100-READ-VCM-GIPSY THRU 8100-READ-VCM-GIPSY-EXIT.           
           DISPLAY ' GIPSY MASTER CLOSED'.                                      
                                                                                
      ***************************************************************           
      * CLOSE OUTPUT FILES.                                       ***           
      ***************************************************************           
           MOVE SPACES                TO LOGICAL-RECORD-NAME.                   
           CALL GAEDATSR        USING FINISH-LR                                 
                                      LOGICAL-RECORD-NAME                       
                                      ICBM.                                     
           DISPLAY 'VOMASTER CLOSED'.                                           
                                                                                
           IF SERIOUS-ERROR                                                     
              MOVE '16' TO RETURN-CODE                                          
              DISPLAY 'CHECK ERROR FILE - IF EXTRACT OK RESTART JOB'            
                      ' AT NEXT STEP (SORT)'                                    
              STOP RUN.                                                         
                                                                                
           MOVE +1                        TO GACCDMA7-PS-FUNC                   
GNE        CALL GACBMAS7             USING GACCDMA7-PS-PARMS                    
GNE                                          GACCDMA7-PS-RETURN                 
GNE                                          PSMASTE7.                          
                                                                                
       1900-FINALIZATION-EXIT.                                                  
           EXIT.                                                                
                                                                                
      **************************************************************            
      ** FOR EACH COMMISSIONS RECORD READ WRITE A SUPPLEMENTAL    **            
      ** DETAIL RECORD.                                           **            
      **************************************************************            
       2000-PROCESS-COMMISSION.                                                 
                                                                                
           MOVE IN-COM-RELEASE-RECORD TO GCOMDACR.                              
                                                                                
      **************************************************************            
      ** SALES CREDIT RECORDS ARE EXCLUDED FROM THE EXTRACT       **            
      ** IF COMMISSION RECORD NOT WRITTEN TO EXTRACT DISPLAY THE  **            
      ** COMMISSION RECORD INFO.                                  **            
      **************************************************************            
           IF  GDACR-CODE(1) > +140                                             
              GO TO 2000-NEXT-COMMISSION.                                       
                                                                                
           MOVE 'N'                   TO WS-COMP-SWITCH.                        
           MOVE 'Y'                   TO WS-WRITE-EXTRACT                       
           MOVE 'N'                   TO WS-RECONCILED-SW.                      
           MOVE 'N'                   TO WS-GRACCT-FOUND.                       
           MOVE 'Y'                   TO GRACCT-RECORD-OK.                      
           MOVE SPACES                TO DATALOADER-RECORD.                     
           MOVE ZEROS                 TO LEXTRACT-FROM-DATE                     
                                         LEXTRACT-TO-DATE.                      
           MOVE GDACR-GROUP           TO WS-GROUP15.                            
REN        MOVE WS-GROUPL7            TO WS-CONTRACT-F7.                        
REN        MOVE SPACES                TO WS-CONTRACT-L3.                        
           MOVE WS-GROUPL7            TO WS-POLICY-NUM.                         
           MOVE GDACR-SUB-ACCOUNT     TO WS-SUB-ACCOUNT.                        
                                                                                
      ************************************************************              
      *** USE 7TH DIGIT OF FOGL-CODE TO DETERMINE PRODUCT CODE ***              
      ************************************************************              
           MOVE GDACR-FOGL-CODE           TO WS-FOGL-CODE.                      
           EVALUATE WS-FOGL-CODE7                                               
               WHEN  1                                                          
                        MOVE   'A'        TO LEXTRACT-PRODUCT-CODE              
               WHEN  2                                                          
                        MOVE   'S'        TO LEXTRACT-PRODUCT-CODE              
               WHEN  3                                                          
                        MOVE   'S'        TO LEXTRACT-PRODUCT-CODE              
               WHEN OTHER                                                       
                        MOVE   'C'        TO LEXTRACT-PRODUCT-CODE              
           END-EVALUATE.                                                        
                                                                                
      ******************************************************************        
      *** USE FIRST 4 DIGITS OF FOGL-CODE TO DETERMINE BENEFIT GROUP ***        
      ******************************************************************        
           EVALUATE WS-FOGL-CODE4                                               
              WHEN 2204                                                         
                        MOVE 'LTD       ' TO LEXTRACT-BENEFIT-GROUPING          
              WHEN 2314                                                         
                        MOVE 'LIFE      ' TO LEXTRACT-BENEFIT-GROUPING          
              WHEN OTHER                                                        
                        MOVE 'A&S       ' TO LEXTRACT-BENEFIT-GROUPING          
           END-EVALUATE.                                                        
                                                                                
      ************************************************************              
      **    CONVERT COMMISSIONS ACCT-EFFECTIVE DATE ADD 1 YEAR ***              
      **    SUBTRACT 1 DAY.                                    ***              
      ************************************************************              
           MOVE GDACR-ACCT-EFFECTIVE-DATE   TO WS-WORK-DATE.                    
           COMPUTE WS-WORK-DATE-YYYY = WS-WORK-DATE-YYYY + 1.                   
           MOVE WS-WORK-DATE           TO WS-CONVERT-DATE-BEFORE.               
           PERFORM 5600-CALC-DAY-BEFORE THRU 5600-CALC-DAY-BEFORE-EXIT.         
           MOVE WS-CONVERT-DATE-AFTER  TO WS-DACR-ACCT-EFF-DATE-A1YS1D.         
                                                                                
      ******************************************************************        
      ***            DETERMINE IF SCALE OR RATE WAS USED             ***        
      ******************************************************************        
           IF GDACR-SCALE = SPACES                                              
ALME01        MOVE SPACES             TO LEXTRACT-SCALE                         
ALME01        MOVE 'N' TO WS-END-SEARCH                                         
ALME01        MOVE ZEROS              TO LEXTRACT-FLAT-RATE                     
ALME01        PERFORM VARYING WS-G-C-SUB FROM 1 BY 1                            
ALME01                UNTIL END-SEARCH-YES OR WS-G-C-SUB > 10                   
ALME01          IF GDACR-CODE(WS-G-C-SUB) = 109                                 
ALME01             SET END-SEARCH-YES TO TRUE                                   
ALME01             MOVE GDACR-CPAMT(WS-G-C-SUB)                                 
ALME01                                TO LEXTRACT-FLAT-RATE                     
ALME01          END-IF                                                          
ALME01        END-PERFORM                                                       
           ELSE                                                                 
              MOVE GDACR-SCALE        TO LEXTRACT-SCALE                         
              MOVE ZEROS              TO LEXTRACT-FLAT-RATE.                    
                                                                                
      ******************************************************************        
      ***            SET PAID / EARN INDICATOR                       ***        
      ******************************************************************        
           IF GDACR-CODE(1) = +118                                              
              MOVE 'E'                TO LEXTRACT-COMP-TYPE                     
           ELSE                                                                 
              MOVE 'P'                TO LEXTRACT-COMP-TYPE.                    
                                                                                
      ************************************************************              
      *** GET VO/GIPSY TO SEE IF ACCOUNT TERMINATED            ***              
      ************************************************************              
           IF GDACR-GROUP = WS-PREV-GROUP AND                                   
              GDACR-SUB-ACCOUNT = WS-PREV-SUB-ACCT                              
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE '00000000'            TO WS-START-DATE                       
              MOVE '00000000'            TO WS-STOP-DATE                        
              MOVE '00000000'            TO WS-TERM-EFFECTIVE-DATE              
                                            WS-TERM-PROCESS-DATE                
              MOVE 'N'                   TO WS-TERM-SWITCH                      
              MOVE 'N'                   TO WS-FIRST-YEAR-SWITCH                
              MOVE 'N'                   TO WS-LONG-FIRST-YEAR-SWITCH           
              PERFORM 2100-GET-GIPSY-VO-INFO THRU 2100-EXIT                     
              PERFORM 2200-GET-ACCOUNT-INFO THRU 2200-EXIT                      
           END-IF.                                                              
                                                                                
           IF GRACCT-RECORD-OK = 'N'                                            
              GO TO 2000-NEXT-COMMISSION                                        
           END-IF.                                                              
                                                                                
      *****************************************************************         
      *** IF PREM DUE DATE ZEROS OBTAIN IT FROM COMP RECORD         ***         
      *** NEED THIS DATE TO ENSURE WE GET THE RIGHT START/STOP DATE ***         
      *****************************************************************         
           IF GDACR-PREM-DUE-DATE = ZEROS                                       
              MOVE 'Y'  TO WS-COMP-SWITCH                                       
              PERFORM 5700-FIND-COMP THRU 5700-EXIT                             
           END-IF.                                                              
                                                                                
      ************************************************************              
      *** GET START/STOP DATES FROM GIPSY                      ***              
      ************************************************************              
           PERFORM 3100-AGENT-START-DATES THRU 3100-EXIT.                       
                                                                                
      ************************************************************              
      *** IF THIS IS A TERMINATED CASE, NEED TO CONFIRM IF                      
      *** THE LAST RECONCILIATION WAS PROCESSED,                                
      *** AND SET DATES ACCORDINGLY.                                            
      ************************************************************              
           IF WS-ACCT-STATUS = 'T' AND                                          
              WS-TERM-PROCESS-DATE   = GDACR-PREM-DUE-DATE AND                  
              WS-TERM-EFFECTIVE-DATE = WS-RENEW-EFFECT-DATE-S1D                 
              PERFORM 2600-CHECK-RECONCILIATION THRU 2600-EXIT.                 
                                                                                
      ******************************************************************        
      ***            DETERMINE IF LONG FIRST YEAR                    ***        
      ***  IF SAME GROUP/ACCOUNT AND 121 FOLLOWS A 113 THEN IT'S A   ***        
      ***  LONG FIRST YEAR.                                          ***        
      ******************************************************************        
           IF GDACR-GROUP = WS-PREV-GROUP                                       
              AND GDACR-SUB-ACCOUNT = WS-PREV-SUB-ACCT                          
              AND FIRST-YEAR                                                    
              AND GDACR-CODE(1) = +121                                          
                   MOVE 'Y' TO WS-LONG-FIRST-YEAR-SWITCH                        
           END-IF.                                                              
                                                                                
      ******************************************************************        
      *** DETERMINE YEAR INDICATOR - FIRST YEAR OR RENEWAL YEAR      ***        
      ******************************************************************        
           IF GDACR-PREMNO = +1                                                 
           OR GDACR-CODE(1) = +113                                              
                MOVE 'F'          TO LEXTRACT-YEAR-INDICATOR                    
                MOVE 'Y'          TO WS-FIRST-YEAR-SWITCH                       
           ELSE                                                                 
                MOVE 'R'          TO LEXTRACT-YEAR-INDICATOR                    
           END-IF.                                                              
                                                                                
           MOVE 'D'                   TO LEXTRACT-DET-RECTYPE.                  
           MOVE WS-CONTRACT-NUMBER    TO LEXTRACT-CONTRACT.                     
           MOVE WS-SUB-ACCT3          TO LEXTRACT-BILLING-DIVISION.             
           MOVE WS-PROC-DATE          TO LEXTRACT-PROC-DATE.                    
           MOVE WS-ACCT-STATUS        TO LEXTRACT-ACCOUNT-STATUS.               
           MOVE GDACR-AGENT-CODE      TO LEXTRACT-ADVISOR-NUMBER.               
           MOVE GDACR-BILLING-NAME    TO LEXTRACT-GROUP-ACCOUNT-NAME.           
           MOVE GDACR-CAUSE           TO LEXTRACT-COMMISSION-ACTIVITY.          
ALME01     MOVE ZEROS                 TO LEXTRACT-COMMISSION-BASE.              
ALME01     MOVE 'N'                   TO WS-END-SEARCH.                         
ALME01     PERFORM VARYING WS-G-C-SUB FROM 1 BY 1                               
ALME01             UNTIL END-SEARCH-YES OR WS-G-C-SUB > 10                      
ALME01       IF (GDACR-CODE(WS-G-C-SUB) = 107 OR                                
ALME01           GDACR-CODE(WS-G-C-SUB) = 108)                                  
ALME01           SET END-SEARCH-YES   TO TRUE                                   
ALME01           MOVE GDACR-CMAMT(WS-G-C-SUB)                                   
ALME01                                TO LEXTRACT-COMMISSION-BASE               
ALME01       END-IF                                                             
ALME01     END-PERFORM                                                          
           MOVE GDACR-SHARE           TO LEXTRACT-SPLIT.                        
           MOVE GDACR-CMAMT(1)        TO LEXTRACT-COMP-AMT.                     
                                                                                
           MOVE GDACR-GROUP            TO WS-PREV-GROUP.                        
           MOVE GDACR-SUB-ACCOUNT      TO WS-PREV-SUB-ACCT.                     
                                                                                
      ****************************************************************          
      *** SET DATES BASED ON ACTIVITY TYPE                                      
      ****************************************************************          
           IF GDACR-CODE(2) = +108                                              
              PERFORM 5500-GET-MTH-ADVISOR-DATES THRU 5500-EXIT                 
           ELSE                                                                 
                                                                                
              IF WS-ACCT-STATUS = 'T'                                           
                 PERFORM 5100-GET-TERM-DATES THRU 5100-EXIT                     
              ELSE                                                              
                 EVALUATE GDACR-CAUSE                                           
                   WHEN 344                                                     
                              PERFORM 5100-GET-TERM-DATES                       
                                 THRU 5100-EXIT                                 
                                                                                
                   WHEN 343                                                     
                              PERFORM 5200-GET-AMEND-DATES                      
                                 THRU 5200-EXIT                                 
                                                                                
                   WHEN 342                                                     
                              PERFORM 5050-GET-RECON-DATES                      
                                 THRU 5050-EXIT                                 
                                                                                
                   WHEN 341                                                     
                              PERFORM 5000-GET-PAID-EARN-DATES                  
                                 THRU 5000-EXIT                                 
                                                                                
                   WHEN OTHER                                                   
      **************************************************************            
      ** SHOULDN'T HAPPEN BUT IF INVALID CAUSE CODE OR GDACR-CODE1**            
      ** HAS FOUND IT'S WAY INTO THE FILE THEN IT WILL BE CAUGHT. **            
      ** IF COMMISSION RECORD NOT WRITTEN TO EXTRACT DISPLAY THE  **            
      ** COMMISSION RECORD INFO SO IT CAN BE INVESTIGATED         **            
      **************************************************************            
                        MOVE WS-GROUPX5       TO DER-GROUP-NUMBER               
                        MOVE WS-SUB-ACCT3     TO DER-SUB-ACCOUNT                
                        MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER             
                        MOVE +5               TO DER-SUB                        
                        MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION           
                        MOVE 'Y'              TO WS-SERIOUS-ERROR-SW            
                        PERFORM 9400-WRITE-REC-SYS023                           
                           THRU 9400-WRITE-SYS023-EXIT                          
                    DISPLAY 'UNKNOWN ENTRY, NOT WRITTEN TO EXTRACT'             
                    DISPLAY 'VLNO:'          GDACR-VLNO                         
                            ' GROUP:'        GDACR-GROUP                        
                            ' SUB-ACCOUNT:'  GDACR-SUB-ACCOUNT                  
                    DISPLAY 'AGENT:'         GDACR-AGENT-CODE                   
                    DISPLAY 'GDACR-CAUSE:'   GDACR-CAUSE                        
                            ' GDACR-CODE1:'  GDACR-CODE(1)                      
                            ' GDACR-CMAMT1:' GDACR-CMAMT(1)                     
                    DISPLAY ' '                                                 
              END-EVALUATE.                                                     
                                                                                
      ****************************************************************          
      *** WRITE COMMISSIONS RECORD TO SUPPLEMENTAL EXTRACT FILE    ***          
      ****************************************************************          
       2000-WRITE-COMMISSIONS.                                                  
                                                                                
           COMPUTE WS-TOT-DETAIL-CNT = WS-TOT-DETAIL-CNT + 1.                   
                                                                                
           PERFORM 9300-WRITE-DLOADER-SYS020                                    
              THRU 9300-WRITE-DLOADER-SYS020-EXIT.                              
                                                                                
      ****************************************************************          
      *** GET NEXT COMMISSIONS RECORD FROM GDACR INPUT FILE        ***          
      ****************************************************************          
       2000-NEXT-COMMISSION.                                                    
           MOVE OBTAIN-NEXT                  TO WS-GAEDATSR-VERB.               
           PERFORM 9100-READ-REC-SYS010 THRU 9100-READ-REC-SYS010-EXIT.         
                                                                                
       2000-PROCESS-COMMISSION-EXIT.                                            
           EXIT.                                                                
                                                                                
       2100-GET-GIPSY-VO-INFO.                                                  
      ***************************************************************           
      **  RETRIEVE THE GIPSY OR VO MASTER INFO                     **           
      **         - IF THE ACCOUNT STATUS IS GREATER THAN 19        **           
      **           AND LESS THAN 27 THEN THE ACCOUNT IS            **           
      **           TERMINATED, RETRIEVE THE TERMINATION DATE.      **           
      ***************************************************************           
           MOVE GROUP-NUMBER OF GWCORGRACCT TO NUM-GROUP-NUMBER.                
                                                                                
      **********************************************************                
      *  READ KEYED (VCM/GIPSY FILES)                                           
      **********************************************************                
           SET  VGWI-SOURCE-UNKNOWN         TO TRUE.                            
           SET  VGWI-READ-KEYED             TO TRUE.                            
           SET  VGWI-LR-GIPSY-EXP           TO TRUE.                            
           SET  VGWI-COV-ANY                TO TRUE.                            
           MOVE WS-GROUPX5                  TO VGWI-GROUP.                      
           MOVE WS-SUB-ACCT3                TO VGWI-ACCOUNT.                    
           PERFORM 8100-READ-VCM-GIPSY THRU 8100-READ-VCM-GIPSY-EXIT.           
                                                                                
      **********************************************************                
      *  IF NOT FOUND, WRITE GROUP-ACCT NOT FOUND MESSAGE                       
      **********************************************************                
           IF NOT VGWO-RET-OK                                                   
                                                                                
                 MOVE WS-GROUPX5            TO DER-GROUP-NUMBER                 
                 MOVE WS-SUB-ACCT3          TO DER-SUB-ACCOUNT                  
                 MOVE GDACR-AGENT-CODE      TO DER-ADVISOR-NUMBER               
                 MOVE +1 TO DER-SUB                                             
                 MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION                  
                 MOVE 'Y'                   TO WS-SERIOUS-ERROR-SW              
                 MOVE 'N'                   TO GRACCT-RECORD-OK                 
                                                                                
                 PERFORM 9400-WRITE-REC-SYS023 THRU                             
                         9400-WRITE-SYS023-EXIT                                 
                 GO TO 2100-EXIT                                                
           END-IF.                                                              
                                                                                
FXXTOK     MOVE VOGPW-DATA-RECORD        TO GMASTER7                            
                                                                                
           MOVE '2B2E'                  TO GAC-DATE-PARAMETERS.                 
           MOVE GGI-ACCT-EFFECTIVE      TO VDATE-ALIS-DATE1.                    
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
                                                                                
           IF VDATE-RET-CODE NOT EQUAL ZERO                                     
              DISPLAY 'WS-GROUPX5:' WS-GROUPX5                                  
                      ' INVALID ACCT-EFFECTIVE DATE:'                           
                      WS-WORK-DATE-YYY, '-', WS-WORK-DATE-DDD                   
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +6                         TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION                     
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD      TO WS-ACCT-EFFECT-DATE                  
           END-IF.                                                              
                                                                                
      **********************************************************                
      ** IF TERMINATED GET THE VALID TERMINATION DATE ***                       
      **********************************************************                
           IF GGIACCOUNT-STATUS > '19' AND                                      
              GGIACCOUNT-STATUS < '27'                                          
                 MOVE 'T'                   TO WS-ACCT-STATUS                   
                 PERFORM 3025-GET-TERM-DATES THRU 3025-EXIT                     
                         VARYING SUB FROM 5 BY -1                               
                         UNTIL SUB = 0                                          
                            OR WS-TERM-SWITCH = 'Y'                             
                                                                                
                 IF WS-PROC-DATE < WS-TERM-PROCESS-DATE                         
                    MOVE 'A' TO WS-ACCT-STATUS                                  
                    MOVE 'N' TO WS-TERM-SWITCH                                  
                 END-IF                                                         
            ELSE                                                                
                 MOVE 'A'                   TO WS-ACCT-STATUS                   
                 MOVE 'N' TO WS-TERM-SWITCH                                     
           END-IF.                                                              
                                                                                
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2200-GET-ACCOUNT-INFO.                                                   
      ***************************************************************           
      *** RETRIEVE THE IDMS GROUP ACCOUNT RECORD GWCORGRACCT TO   ***           
      *** DETERMINE THE FROM, TO & EFFECTIVE DATES                ***           
      ***************************************************************           
           MOVE WS-GROUPX5             TO GROUP-NUMBER OF GWCORGRACCT.          
           MOVE WS-SUB-ACCT3           TO GR-ACCOUNT   OF GWCORGRACCT.          
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                                                                                
                   MOVE WS-GROUPX5            TO DER-GROUP-NUMBER               
                   MOVE WS-SUB-ACCT3          TO DER-SUB-ACCOUNT                
                   MOVE SPACES                TO DER-ADVISOR-NUMBER             
                   MOVE +21                   TO DER-SUB                        
                   MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION                
                   MOVE 'Y'                   TO WS-SERIOUS-ERROR-SW            
                   PERFORM 9400-WRITE-REC-SYS023                                
                      THRU 9400-WRITE-SYS023-EXIT                               
                   DISPLAY 'GWCORGRACCT RECORD NOT FOUND - ERROR'               
                      ' GROUP-ACCOUNT:' WS-GROUPX5, WS-SUB-ACCT3                
                   MOVE 'N'                  TO GRACCT-RECORD-OK.               
                                                                                
      *****************************************************************         
      ****  ONLY NEED THE RENEWAL DATE IF THE ACCOUNT IS TERMINATED ***         
      ****  IF INVALID SET THE INDICATOR SO WE KNOW TO RETRIEVE IT  ***         
      ****  FROM VO/GIPSY.                                          ***         
      ******************** ********************************************         
           IF WS-ACCT-STATUS = 'T' OR                                           
              WS-PROC-DATE < WS-TERM-PROCESS-DATE                               
              MOVE 'N'                 TO WS-VALID-RENEW-DATE                   
              IF RENEWAL-EFFECTIVE-YEAR NOT NUMERIC OR                          
                 RENEWAL-EFFECTIVE-DAY  NOT NUMERIC                             
                 NEXT SENTENCE                                                  
              ELSE                                                              
                 IF RENEWAL-EFFECTIVE-YEAR > 0 AND                              
                    RENEWAL-EFFECTIVE-DAY  > 0                                  
                    MOVE RENEWAL-EFFECTIVE-DATE TO WS-WORK-DATE-JUL             
                    PERFORM 4000-GET-RENEWAL-DATE THRU 4000-EXIT                
                    MOVE 'Y'           TO WS-VALID-RENEW-DATE.                  
                                                                                
      **************************************************************            
      ** IF ACCOUNT IS TERMINATED AND THE RENEWAL-DATE ON GRACCT  **            
      ** IS INVALID THEN PICK IT UP FROM THE VO/GIPSY NASTER      **            
      **************************************************************            
           IF WS-ACCT-STATUS = 'T' AND INVALID-RENEW-DATE                       
              PERFORM 3050-GET-VOPSM-PSM-MASTER THRU 3050-EXIT.                 
                                                                                
      ******************************************************************        
      ****   THERE ARE A FEW ACCOUNTS THAT HAVE AN INVALID           ***        
      ****   NEXT-RECON-DATE (999 IN YEAR FIELD). IF THIS IS THE     ***        
      ****   THE CASE THEN NEXT-RECON-DATE IS SET TO LAST-RECON-DATE ***        
      ****   PLUS 1 YEAR.                                            ***        
      ******************************************************************        
           IF NEXT-RECON-YEAR = 999                                             
              MOVE LAST-RECON-DATE     TO NEXT-RECON-DATE                       
              COMPUTE NEXT-RECON-YEAR = NEXT-RECON-YEAR + 1                     
           END-IF.                                                              
                                                                                
           IF WS-PROC-DATE < WS-TERM-PROCESS-DATE                               
              MOVE WS-RENEW-EFFECT-DATE-S1D-YYYY TO VDATE1-YYYY                 
              MOVE WS-RENEW-EFFECT-DATE-S1D-MM   TO VDATE1-MM                   
              MOVE WS-RENEW-EFFECT-DATE-S1D-DD   TO VDATE1-DD                   
              PERFORM 7000-DATE-JULIAN THRU 7000-EXIT                           
              MOVE WS-JULIAN-DATE            TO LAST-RECON-DATE                 
              COMPUTE WS-JULIAN-YYY = WS-JULIAN-YYY + 1                         
              MOVE WS-JULIAN-DATE            TO NEXT-RECON-DATE.                
                                                                                
      *****************************************************************         
      ****   REFORMAT NEXT RECON DATE                             *****         
      *****************************************************************         
           MOVE NEXT-RECON-DATE        TO VDATE-ALIS-DATE1.                     
           PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT.                         
           IF VDATE-RET-IND NOT = +0                                            
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +7                         TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION                     
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD     TO WS-NEXT-RECON-DATE                    
           END-IF.                                                              
                                                                                
      *****************************************************                     
      ****   NEXT RECON DATE PLUS 1 DAY               *****                     
      *****************************************************                     
           MOVE WS-NEXT-RECON-DATE     TO WS-CONVERT-DATE-BEFORE.               
           PERFORM 5600-CALC-DAY-AFTER THRU 5600-CALC-DAY-AFTER-EXIT.           
           MOVE WS-CONVERT-DATE-AFTER  TO WS-NEXT-RECON-DATE-A1D.               
                                                                                
      *****************************************************                     
      ****   NEXT RECON DATE PLUS 1 YEAR              *****                     
      *****************************************************                     
           MOVE '2B2E'                 TO GAC-DATE-PARAMETERS.                  
           MOVE NEXT-RECON-DATE        TO VDATE-ALIS-DATE1.                     
           ADD 1                       TO VDATE-ALIS-YEAR1.                     
           PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT.                         
           IF VDATE-RET-IND NOT = +0                                            
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +8                         TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB)      TO DER-DESCRIPTION                
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD     TO WS-NEXT-RECON-DATE-A1Y                
           END-IF.                                                              
                                                                                
      *****************************************************                     
      ****   NEXT RECON DATE MINUS 1 YEAR             *****                     
      *****************************************************                     
           MOVE '2B2E'                 TO GAC-DATE-PARAMETERS.                  
           MOVE NEXT-RECON-DATE        TO VDATE-ALIS-DATE1.                     
           SUBTRACT 1 FROM                VDATE-ALIS-YEAR1.                     
           PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT.                         
           IF VDATE-RET-IND NOT = +0                                            
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +9                         TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB)      TO DER-DESCRIPTION                
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD     TO WS-NEXT-RECON-DATE-S1Y                
           END-IF.                                                              
                                                                                
      ************************************************************              
      **** REFORMAT LAST-RECON DATE                          *****              
      ************************************************************              
           MOVE '2B2E'                 TO GAC-DATE-PARAMETERS.                  
           MOVE LAST-RECON-DATE        TO VDATE-ALIS-DATE1.                     
           PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT.                         
           IF VDATE-RET-IND NOT = +0                                            
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +10                        TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB)      TO DER-DESCRIPTION                
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD     TO WS-LAST-RECON-DATE                    
           END-IF.                                                              
                                                                                
      *****************************************************                     
      ****   LAST RECON DATE PLUS 1 DAY               *****                     
      *****************************************************                     
           MOVE WS-LAST-RECON-DATE     TO WS-CONVERT-DATE-BEFORE.               
           PERFORM 5600-CALC-DAY-AFTER THRU 5600-CALC-DAY-AFTER-EXIT.           
           MOVE WS-CONVERT-DATE-AFTER  TO WS-LAST-RECON-DATE-A1D.               
                                                                                
      ************************************************************              
      **    LAST RECON DATE PLUS 1 DAY MINUS 1 YEAR         ******              
      ************************************************************              
           MOVE WS-LAST-RECON-DATE     TO WS-WORK-DATE.                         
           COMPUTE WS-WORK-DATE-YYYY = WS-WORK-DATE-YYYY - 1.                   
           MOVE WS-WORK-DATE           TO WS-CONVERT-DATE-BEFORE.               
           PERFORM 5600-CALC-DAY-AFTER THRU 5600-CALC-DAY-AFTER-EXIT.           
           MOVE WS-CONVERT-DATE-AFTER  TO WS-LAST-RECON-DATE-A1DS1Y.            
                                                                                
      *****************************************************                     
      ****   LAST RECON DATE PLUS 1 YEAR              *****                     
      *****************************************************                     
           MOVE '2B2E'                 TO GAC-DATE-PARAMETERS.                  
           MOVE LAST-RECON-DATE        TO VDATE-ALIS-DATE1.                     
           ADD 1                       TO VDATE-ALIS-YEAR1.                     
           PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT.                         
           IF VDATE-RET-IND NOT = +0                                            
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +11                        TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB)      TO DER-DESCRIPTION                
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD     TO WS-LAST-RECON-DATE-A1Y                
           END-IF.                                                              
                                                                                
       2200-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2600-CHECK-RECONCILIATION.                                               
      ******************************************************                    
      ***  CHECK IF INPUT CRR RECORD IS RECONCILIED      ***                    
      ******************************************************                    
           MOVE 'Y'  TO WS-RECONCILED-SW.                                       
           MOVE WS-RENEW-EFFECT-DATE-S1D-YYYY TO VDATE1-YYYY                    
           MOVE WS-RENEW-EFFECT-DATE-S1D-MM   TO VDATE1-MM                      
           MOVE WS-RENEW-EFFECT-DATE-S1D-DD   TO VDATE1-DD                      
           PERFORM 7000-DATE-JULIAN THRU 7000-EXIT                              
           MOVE WS-JULIAN-DATE           TO COMP-EFF-DATE OF GWCORCOMP.         
      *%   OBTAIN GWCORCOMP WITHIN GRACCT-COMP USING                            
      *%       COMP-EFF-DATE OF GWCORCOMP                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +8  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-ALT-KEY                               
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 COMP-EFF-DATE OF GWCORCOMP                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
              MOVE 'N'  TO WS-RECONCILED-SW.                                    
                                                                                
       2600-EXIT.                                                               
            EXIT.                                                               
                                                                                
       3025-GET-TERM-DATES.                                                     
      *****************************************************************         
      *   GET GISPY TERMINATION DATE                                *           
      *****************************************************************         
           IF GTMEFFECTIVE-YEAR (SUB) NUMERIC AND                               
              GTMEFFECTIVE-YEAR (SUB) > ZERO                                    
              MOVE 'Y'                     TO WS-TERM-SWITCH                    
              MOVE GTMEFFECTIVE-YEAR (SUB) TO WS-GTMEFFECTIVE-YYY               
              MOVE GTMEFFECTIVE-DATE (SUB) TO VDATE-ALIS-DATE1                  
              PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT                       
              IF VDATE-RET-IND NOT = +0                                         
                 MOVE WS-GROUPX5              TO DER-GROUP-NUMBER               
                 MOVE WS-SUB-ACCT3            TO DER-SUB-ACCOUNT                
                 MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                    
                 MOVE +12                     TO DER-SUB                        
                 MOVE DER-MESSAGE (DER-SUB)   TO DER-DESCRIPTION                
                 MOVE 'Y'                     TO WS-SERIOUS-ERROR-SW            
                 PERFORM 9400-WRITE-REC-SYS023                                  
                    THRU 9400-WRITE-SYS023-EXIT                                 
              ELSE                                                              
                 MOVE VDATE1-YYYYMMDD      TO WS-TERM-EFFECTIVE-DATE            
              END-IF                                                            
           END-IF.                                                              
                                                                                
           IF GTMPROCESSED-YEAR (SUB) NUMERIC AND                               
              GTMPROCESSED-YEAR (SUB) > ZERO                                    
              MOVE GTMPROCESSED-DATE (SUB) TO VDATE-ALIS-DATE1                  
              PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT                       
              IF VDATE-RET-IND NOT = +0                                         
                 MOVE WS-GROUPX5              TO DER-GROUP-NUMBER               
                 MOVE WS-SUB-ACCT3            TO DER-SUB-ACCOUNT                
                 MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                    
                 MOVE +13                     TO DER-SUB                        
                 MOVE DER-MESSAGE (DER-SUB)   TO DER-DESCRIPTION                
                 MOVE 'Y'                     TO WS-SERIOUS-ERROR-SW            
                 PERFORM 9400-WRITE-REC-SYS023                                  
                    THRU 9400-WRITE-SYS023-EXIT                                 
              ELSE                                                              
                 MOVE VDATE1-YYYYMMDD      TO WS-TERM-PROCESS-DATE              
              END-IF                                                            
           END-IF.                                                              
                                                                                
       3025-EXIT.                                                               
           EXIT.                                                                
                                                                                
       3050-GET-VOPSM-PSM-MASTER.                                               
      ******************************************************************        
      *       - NEED THE PSM MASTER FOR THIS GROUP TO RETRIEVE THE    **        
      *         RENEWAL DATE, IF IT WAS BLANK ON THE GRACCT RECORD    **        
      ******************************************************************        
                                                                                
      * VOCOMM VOPSM/PSM                                                        
           MOVE WS-GROUPL7                   TO WS-GROUP-NBR7.                  
           MOVE WS-GROUPL5                   TO WS-GROUP-NBR5.                  
           MOVE LOW-VALUES                   TO VOPSMASTER-RECORD.              
           MOVE WS-GROUP-NBR7                TO VOPSM-GROUP-NUMBER.             
           MOVE LR-VO-PSMASTER-R             TO LOGICAL-RECORD-NAME.            
                                                                                
           CALL GAEDATSR                  USING OBTAIN-KEYED                    
                                                VOPSMASTER-RECORD               
                                                ICBM.                           
           IF LR-STATUS-OK                                                      
              MOVE 'B'                       TO VDATE-REQ-SERVICE               
              MOVE 'B'                       TO VDATE-REQ-BASIS                 
              MOVE '1'                       TO VDATE-REQ-DETAIL                
              MOVE 'E'                       TO VDATE-REQ-LANGUAGE              
                                                                                
              IF WS-TERM-EFFECTIVE-DATE-YYYY IS NUMERIC AND                     
                 VOPSM-NXT-RNEW-MONTH IS NUMERIC AND                            
                 VOPSM-NXT-RNEW-DAY   IS NUMERIC                                
                 MOVE WS-TERM-EFFECTIVE-DATE-YYYY TO VDATE1-YYYY                
                 MOVE VOPSM-NXT-RNEW-MONTH   TO VDATE1-MM                       
                 MOVE VOPSM-NXT-RNEW-DAY     TO VDATE1-DD                       
                 CALL GC2DATE USING GAC-DATE-PARAMETERS                         
                 MOVE VDATE-ALIS-YEAR1       TO WS-PSM-RENEW-YEAR               
                 MOVE VDATE-ALIS-DAY1        TO WS-PSM-RENEW-DAY                
              ELSE                                                              
                 MOVE ZEROS                  TO WS-PSM-RENEW-DATE               
              END-IF                                                            
                                                                                
           ELSE                                                                 
FXXTOK        MOVE LOW-VALUES                TO PSMASTE7                        
              MOVE WS-GROUP-NBR7             TO GACCDMA7-PS-GROUP               
              MOVE HIGH-VALUES               TO GACCDMA7-PS-ACCT                
GNE           CALL GACBMAS7             USING GACCDMA7-PS-PARMS                 
GNE                                             GACCDMA7-PS-RETURN              
GNE                                             PSMASTE7                        
                                                                                
              IF GACCDMA7-PS-RETURN = 'R01'                                     
                 MOVE WS-GROUPX5              TO DER-GROUP-NUMBER               
                 MOVE WS-SUB-ACCT3            TO DER-SUB-ACCOUNT                
                 MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                    
                 MOVE +14                     TO DER-SUB                        
                 MOVE DER-MESSAGE (DER-SUB)   TO DER-DESCRIPTION                
                 MOVE 'Y'                     TO WS-SERIOUS-ERROR-SW            
                 PERFORM 9400-WRITE-REC-SYS023                                  
                    THRU 9400-WRITE-SYS023-EXIT                                 
                 MOVE ZEROS                  TO WS-PSM-RENEW-DATE               
              ELSE                                                              
                 IF GACCDMA7-PS-RETURN NOT = SPACES                             
FXXTOK              DISPLAY 'ERROR READING PSMASTE7 -'                          
                    ' PROGRAM-LINKAGE-STATUS:' PROGRAM-LINKAGE-STATUS           
                                                                                
                      MOVE WS-GROUPX5         TO DER-GROUP-NUMBER               
                      MOVE WS-SUB-ACCT3       TO DER-SUB-ACCOUNT                
                      MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER               
                      MOVE +15                TO DER-SUB                        
                      MOVE DER-MESSAGE (DER-SUB) TO DER-DESCRIPTION             
                      MOVE 'Y'                TO WS-SERIOUS-ERROR-SW            
                      PERFORM 9400-WRITE-REC-SYS023                             
                         THRU 9400-WRITE-SYS023-EXIT                            
                 ELSE                                                           
                    IF WS-GTMEFFECTIVE-YYY IS NUMERIC AND                       
                       PSMNXT-RNEW-DAY IS NUMERIC                               
                       MOVE WS-GTMEFFECTIVE-YYY TO WS-PSM-RENEW-YEAR            
                       MOVE PSMNXT-RNEW-DAY     TO WS-PSM-RENEW-DAY             
                    ELSE                                                        
                       MOVE ZEROS               TO WS-PSM-RENEW-DATE            
                    END-IF.                                                     
           MOVE WS-PSM-RENEW-DATE               TO WS-WORK-DATE-JUL.            
           PERFORM 4000-GET-RENEWAL-DATE THRU 4000-EXIT.                        
                                                                                
       3050-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *****************************************************************         
      *  RETRIEVE THE START & STOP DATES FROM GIPSY MASTER          ***         
      *****************************************************************         
       3100-AGENT-START-DATES.                                                  
           MOVE 0                             TO TRL-SUB.                       
           MOVE 'N'                           TO AGENT-SWITCH.                  
           PERFORM 3710-SEARCH-AGENT THRU 3710-EXIT                             
             UNTIL AGENT-INFO-FOUND OR                                          
                   TRL-SUB GREATER THAN 3.                                      
                                                                                
      *****************************************************************         
      *  ONLY SEARCH TRAILER IF THE CORRECT AGENT IS FOUND          ***         
      *****************************************************************         
                                                                                
           IF AGENT-INFO-FOUND                                                  
              MOVE 'N'                        TO WS-START-DATE-SWITCH           
              MOVE 'N'                        TO WS-STOP-DATE-SWITCH            
              MOVE 0                          TO AGT-SUB                        
              PERFORM 3720-SEARCH-TRAILER THRU 3720-EXIT                        
                UNTIL STOP-DATE-FOUND OR                                        
                      AGT-SUB > 4.                                              
                                                                                
       3100-EXIT.                                                               
           EXIT.                                                                
                                                                                
       3710-SEARCH-AGENT.                                                       
      *****************************************************************         
      *     GET AGENT INFORMATION FROM GIPSY MASTER                  **         
      *     WE ARE ON THE CORRECT AGENT                              **         
      *****************************************************************         
           ADD 1        TO TRL-SUB.                                             
           IF  GAGAGENT-CODE (TRL-SUB) IS NUMERIC                               
           AND GAGAGENT-CODE (TRL-SUB) = GDACR-AGENT-CODE                       
               MOVE 'Y' TO AGENT-SWITCH.                                        
                                                                                
       3710-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *****************************************************************         
      *     WE ARE ON THE CORRECT AGENT                              **         
      *     GET START & STOP DATES FROM THE CORRECT TRAILERS         **         
      *     GET THE START-DATE FROM THE FIRST VALID TRAILER AND      **         
      *     GET THE STOP-DATE FROM THE LAST VALID TRAILER.           **         
      *****************************************************************         
       3720-SEARCH-TRAILER.                                                     
           ADD 1        TO AGT-SUB.                                             
           IF  GAGSTART-YEAR (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTART-DAY  (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTOP-YEAR  (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTOP-DAY   (TRL-SUB, AGT-SUB) IS NUMERIC                      
               NEXT SENTENCE                                                    
           ELSE                                                                 
             GO TO 3720-EXIT.                                                   
                                                                                
           IF GAGSTART-DAY (TRL-SUB, AGT-SUB) > 0                               
              MOVE GAGSTART-YEAR (TRL-SUB, AGT-SUB) TO WS-GAGSTART-YEAR         
              MOVE GAGSTART-DAY (TRL-SUB, AGT-SUB)  TO WS-GAGSTART-DAY.         
           IF GAGSTOP-DAY (TRL-SUB, AGT-SUB) > 0                                
              MOVE GAGSTOP-DATE (TRL-SUB, AGT-SUB)  TO WS-GAGSTOP-DATE.         
                                                                                
           IF GAGSTART-DAY (TRL-SUB, AGT-SUB) > 0 AND                           
              START-DATE-NOT-FOUND                                              
              MOVE WS-GAGSTART-DATE        TO VDATE-ALIS-DATE1                  
              PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT                       
              IF VDATE-RET-IND NOT = +0                                         
                 MOVE WS-GROUPX5              TO DER-GROUP-NUMBER               
                 MOVE WS-SUB-ACCT3            TO DER-SUB-ACCOUNT                
                 MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                    
                 MOVE +16                     TO DER-SUB                        
                 MOVE DER-MESSAGE (DER-SUB)   TO DER-DESCRIPTION                
                 MOVE 'Y'                     TO WS-SERIOUS-ERROR-SW            
                 PERFORM 9400-WRITE-REC-SYS023                                  
                    THRU 9400-WRITE-SYS023-EXIT                                 
              ELSE                                                              
                 MOVE 'Y'                  TO WS-START-DATE-SWITCH              
                 MOVE VDATE1-YYYYMMDD      TO WS-START-DATE                     
           END-IF                                                               
                                                                                
           MOVE GDACR-PREM-DUE-DATE        TO WS-PREM-DUE-DATE-X8.              
                                                                                
           MOVE 'B'                        TO VDATE-REQ-SERVICE                 
           MOVE 'B'                        TO VDATE-REQ-BASIS                   
           MOVE '1'                        TO VDATE-REQ-DETAIL                  
           MOVE 'E'                        TO VDATE-REQ-LANGUAGE                
           IF WS-PREM-DUE-DATE-YYYY IS NUMERIC AND                              
              WS-PREM-DUE-DATE-MM   IS NUMERIC AND                              
              WS-PREM-DUE-DATE-DD   IS NUMERIC                                  
              MOVE WS-PREM-DUE-DATE-YYYY   TO VDATE1-YYYY                       
              MOVE WS-PREM-DUE-DATE-MM     TO VDATE1-MM                         
              MOVE WS-PREM-DUE-DATE-DD     TO VDATE1-DD                         
              CALL GC2DATE USING GAC-DATE-PARAMETERS                            
              MOVE VDATE-ALIS-YEAR1        TO WS-PREM-DUE-YYY                   
              MOVE VDATE-ALIS-DAY1         TO WS-PREM-DUE-DDD                   
           ELSE                                                                 
              MOVE ZEROS                   TO WS-PREM-DUE-YYY                   
              MOVE ZEROS                   TO WS-PREM-DUE-DDD.                  
                                                                                
      ************************************************************              
      ***  MAKE SURE WE PICK UP THE MATCHING START/STOP DATE   ***              
      ***  FOR THE GDACR-PREM-DUE-DATE.                        ***              
      ************************************************************              
           IF (GDACR-PREM-DUE-DATE > WS-START-DATE  OR                          
              GDACR-PREM-DUE-DATE  = WS-START-DATE) AND                         
              (WS-PREM-DUE-DATE < WS-GAGSTOP-DATE OR                            
              WS-PREM-DUE-DATE = WS-GAGSTOP-DATE)                               
              MOVE 'Y' TO WS-STOP-DATE-SWITCH                                   
              MOVE WS-GAGSTOP-DATE         TO VDATE-ALIS-DATE1                  
              PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT                       
              IF VDATE-RET-IND NOT = +0                                         
                 MOVE WS-GROUPX5              TO DER-GROUP-NUMBER               
                 MOVE WS-SUB-ACCT3            TO DER-SUB-ACCOUNT                
                 MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                    
                 MOVE +17                     TO DER-SUB                        
                 MOVE DER-MESSAGE (DER-SUB)   TO DER-DESCRIPTION                
                 MOVE 'Y'                     TO WS-SERIOUS-ERROR-SW            
                 PERFORM 9400-WRITE-REC-SYS023                                  
                    THRU 9400-WRITE-SYS023-EXIT                                 
              ELSE                                                              
                 MOVE VDATE1-YYYYMMDD      TO WS-STOP-DATE.                     
                                                                                
       3720-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************                    
      ****  REFORMAT RENEWAL EFFECTIVE DATES            ****                    
      ******************************************************                    
       4000-GET-RENEWAL-DATE.                                                   
           MOVE '2B2E'                  TO GAC-DATE-PARAMETERS.                 
           MOVE WS-WORK-DATE-JUL        TO VDATE-ALIS-DATE1.                    
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           IF VDATE-RET-CODE NOT EQUAL ZERO                                     
              DISPLAY 'WS-GROUPX5:' WS-GROUPX5                                  
                      ' INVALID RENEWAL-DATE:' WS-WORK-DATE-YYY                 
                                               WS-WORK-DATE-DDD                 
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +18                        TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB)      TO DER-DESCRIPTION                
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD      TO WS-RENEW-EFFECT-DATE                 
      *****************************************************                     
      ****   RENEWAL DATE MINUS 1 YEAR                *****                     
      *****************************************************                     
              MOVE WS-RENEW-EFFECT-DATE TO WS-RENEW-EFFECT-DATE-S1Y             
              COMPUTE WS-RENEW-EFFECT-DATE-SYYYY =                              
                      WS-RENEW-EFFECT-DATE-SYYYY - 1                            
           MOVE WS-RENEW-EFFECT-DATE   TO WS-CONVERT-DATE-BEFORE                
           PERFORM 5600-CALC-DAY-BEFORE THRU 5600-CALC-DAY-BEFORE-EXIT          
           MOVE WS-CONVERT-DATE-AFTER  TO WS-RENEW-EFFECT-DATE-S1D              
           END-IF.                                                              
                                                                                
       4000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ** EXTRACT FROM & TO DATES FOR PAID COMMISSIONS AND EARNS        *        
      **                                                                        
      **                                                                        
      ** B.BEAUBIEN:   MARCH 2008                                               
      **                                                                        
      ** SOMETIMES 2 MONTHS PREMIUM PAID AT ONCE                                
      ** (AND FALLS OVER THE RECONCILIAION DATE)                                
      ** IF PREM DUE DT > NEXT RECON. DATE,                                     
      ** ADVANCE THE FROM AND TO DATE BY 1 YEAR                                 
      **                                                                        
      ** DO NOT APPLY THE ABOVE TO RECORDS WITH STALE RECONCILIATION            
      ** DATES.     CURRENT DATE  -  1 YEAR                                     
      ******************************************************************        
       5000-GET-PAID-EARN-DATES.                                                
           MOVE 'PAID-EARN LOGIC ' TO WS-LOGIC-TYPE.                            
                                                                                
           IF (GDACR-CAUSE = 341 AND                                            
               WS-LAST-RECON-DATE < WS-ACCT-EFFECT-DATE  AND                    
               GDACR-PREM-DUE-DATE <  WS-NEXT-RECON-DATE) AND                   
               (GDACR-CODE(1) = +118 OR GDACR-CODE(1) = +113 OR                 
                GDACR-CODE(1) = +121 OR GDACR-CODE(1) = +131)                   
               MOVE WS-ACCT-EFFECT-DATE          TO LEXTRACT-FROM-DATE          
               MOVE WS-NEXT-RECON-DATE           TO LEXTRACT-TO-DATE            
           ELSE                                                                 
             IF (GDACR-PREM-DUE-DATE >= WS-NEXT-RECON-DATE                      
             AND  NEXT-RECON-YEAR >= WS-TEST-YEAR)                              
                MOVE WS-NEXT-RECON-DATE-A1D      TO LEXTRACT-FROM-DATE          
                MOVE WS-NEXT-RECON-DATE-A1Y      TO LEXTRACT-TO-DATE            
           ELSE                                                                 
             IF GDACR-PREM-DUE-DATE >= WS-LAST-RECON-DATE-A1D                   
                MOVE WS-LAST-RECON-DATE-A1D      TO LEXTRACT-FROM-DATE          
                MOVE WS-NEXT-RECON-DATE          TO LEXTRACT-TO-DATE            
             ELSE                                                               
                 MOVE WS-LAST-RECON-DATE-A1DS1Y  TO LEXTRACT-FROM-DATE          
                 MOVE WS-LAST-RECON-DATE         TO LEXTRACT-TO-DATE.           
                                                                                
           IF WS-START-DATE > LEXTRACT-FROM-DATE AND                            
              WS-START-DATE < LEXTRACT-TO-DATE                                  
              MOVE WS-START-DATE           TO LEXTRACT-FROM-DATE                
           END-IF.                                                              
                                                                                
           MOVE GDACR-PREM-DUE-DATE              TO LEXTRACT-EFF-DATE.          
                                                                                
      **** NOTE: USE STOP DATE FOR OLD AGENT CHANGE                 ***         
                                                                                
           IF WS-STOP-DATE = GDACR-PREM-DUE-DATE AND                            
              WS-STOP-DATE <= WS-LAST-RECON-DATE-A1D                            
              MOVE WS-NEXT-RECON-DATE       TO LEXTRACT-TO-DATE                 
              MOVE WS-STOP-DATE             TO LEXTRACT-EFF-DATE                
           ELSE                                                                 
           IF WS-STOP-DATE = GDACR-PREM-DUE-DATE                                
              MOVE WS-STOP-DATE             TO LEXTRACT-TO-DATE                 
              MOVE WS-STOP-DATE             TO LEXTRACT-EFF-DATE.               
                                                                                
       5000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ** EXTRACT FROM & TO DATES FOR RECONCILLIATIONS                 **        
      ******************************************************************        
       5050-GET-RECON-DATES.                                                    
                                                                                
           MOVE 'RECONCILIATION  ' TO WS-LOGIC-TYPE.                            
           IF GDACR-CODE(1) = +113                                              
              MOVE WS-ACCT-EFFECT-DATE          TO LEXTRACT-FROM-DATE           
              MOVE WS-LAST-RECON-DATE           TO LEXTRACT-TO-DATE             
           ELSE                                                                 
             IF GDACR-CODE(1) = +121 AND LONG-FIRST-YEAR                        
                MOVE WS-ACCT-EFFECT-DATE        TO LEXTRACT-FROM-DATE           
                MOVE WS-LAST-RECON-DATE         TO LEXTRACT-TO-DATE             
             ELSE                                                               
                MOVE WS-LAST-RECON-DATE-A1DS1Y  TO LEXTRACT-FROM-DATE           
                MOVE WS-LAST-RECON-DATE         TO LEXTRACT-TO-DATE.            
                                                                                
           IF WS-START-DATE > LEXTRACT-FROM-DATE AND                            
              WS-START-DATE < LEXTRACT-TO-DATE                                  
              MOVE WS-START-DATE           TO LEXTRACT-FROM-DATE                
           END-IF.                                                              
                                                                                
           MOVE GDACR-PREM-DUE-DATE             TO LEXTRACT-EFF-DATE.           
                                                                                
       5050-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ** EXTRACT FROM & TO DATES FOR TERMINATIONS                     **        
      ******************************************************************        
      ******************************************************************        
      *** EXECUTE TERMINATION LOGIC TO OBTAIN FROM & TO DATES.         *        
      *** THE ACCT-STATUS WOULD BE AN 'A' IF PROCESS DATE <            *        
      *** TERM PROCESS DATE AND THEREFORE WILL NOT FALL INTO THIS CODE *        
      ******************************************************************        
       5100-GET-TERM-DATES.                                                     
                                                                                
           MOVE 'TERMINATION     ' TO WS-LOGIC-TYPE.                            
                                                                                
           IF FIRST-YEAR OR LONG-FIRST-YEAR                                     
              MOVE WS-ACCT-EFFECT-DATE         TO LEXTRACT-FROM-DATE            
              MOVE WS-TERM-EFFECTIVE-DATE      TO LEXTRACT-TO-DATE              
              MOVE WS-TERM-EFFECTIVE-DATE      TO LEXTRACT-EFF-DATE             
              IF WS-START-DATE >  LEXTRACT-FROM-DATE  AND                       
                 WS-START-DATE <  LEXTRACT-TO-DATE                              
                 MOVE WS-START-DATE               TO LEXTRACT-FROM-DATE         
              END-IF                                                            
              GO TO 5100-EXIT.                                                  
                                                                                
           IF WS-TERM-EFFECTIVE-DATE = WS-RENEW-EFFECT-DATE-S1D AND             
              RECONCILED                                                        
              MOVE WS-RENEW-EFFECT-DATE        TO LEXTRACT-FROM-DATE            
              MOVE GDACR-PREM-DUE-DATE         TO LEXTRACT-TO-DATE              
              MOVE GDACR-PREM-DUE-DATE         TO LEXTRACT-EFF-DATE             
              IF LEXTRACT-FROM-DATE > LEXTRACT-TO-DATE                          
                 MOVE WS-RENEW-EFFECT-DATE-S1Y TO LEXTRACT-FROM-DATE            
              END-IF                                                            
              IF WS-START-DATE >  LEXTRACT-FROM-DATE  AND                       
                 WS-START-DATE <  LEXTRACT-TO-DATE                              
                 MOVE WS-START-DATE               TO LEXTRACT-FROM-DATE         
              END-IF                                                            
              GO TO 5100-EXIT                                                   
           ELSE                                                                 
             IF  WS-TERM-EFFECTIVE-DATE = WS-RENEW-EFFECT-DATE-S1D              
             AND NOT-RECONCILED                                                 
                MOVE WS-RENEW-EFFECT-DATE-S1Y  TO LEXTRACT-FROM-DATE            
                MOVE WS-TERM-EFFECTIVE-DATE    TO LEXTRACT-TO-DATE              
                MOVE WS-TERM-EFFECTIVE-DATE    TO LEXTRACT-EFF-DATE             
                IF LEXTRACT-FROM-DATE > LEXTRACT-TO-DATE                        
                   MOVE WS-RENEW-EFFECT-DATE-S1Y TO LEXTRACT-FROM-DATE          
                END-IF                                                          
                IF WS-START-DATE >  LEXTRACT-FROM-DATE  AND                     
                   WS-START-DATE <  LEXTRACT-TO-DATE                            
                   MOVE WS-START-DATE          TO LEXTRACT-FROM-DATE            
                END-IF                                                          
                GO TO 5100-EXIT.                                                
                                                                                
           MOVE WS-TERM-EFFECTIVE-DATE      TO LEXTRACT-EFF-DATE                
           MOVE WS-TERM-EFFECTIVE-DATE      TO LEXTRACT-TO-DATE.                
                                                                                
           IF WS-TERM-EFFECTIVE-DATE <= WS-RENEW-EFFECT-DATE-S1D                
              MOVE WS-RENEW-EFFECT-DATE-S1Y  TO LEXTRACT-FROM-DATE              
           ELSE                                                                 
              MOVE WS-RENEW-EFFECT-DATE       TO LEXTRACT-FROM-DATE             
           END-IF.                                                              
                                                                                
           IF WS-START-DATE >  LEXTRACT-FROM-DATE  AND                          
              WS-START-DATE <  LEXTRACT-TO-DATE                                 
              MOVE WS-START-DATE               TO LEXTRACT-FROM-DATE            
           END-IF.                                                              
                                                                                
       5100-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ** EXTRACT FROM & TO DATES FOR AMENDMENTS                       **        
      ******************************************************************        
       5200-GET-AMEND-DATES.                                                    
           MOVE 'AMENDMENT       ' TO WS-LOGIC-TYPE.                            
                                                                                
           IF GDACR-PREM-DUE-DATE < WS-LAST-RECON-DATE                          
              MOVE GDACR-PREM-DUE-DATE    TO LEXTRACT-FROM-DATE                 
              MOVE WS-LAST-RECON-DATE     TO LEXTRACT-TO-DATE                   
           ELSE                                                                 
              MOVE GDACR-PREM-DUE-DATE    TO LEXTRACT-FROM-DATE                 
              MOVE WS-NEXT-RECON-DATE     TO LEXTRACT-TO-DATE.                  
                                                                                
           IF WS-START-DATE >  LEXTRACT-FROM-DATE  AND                          
              WS-START-DATE <  LEXTRACT-TO-DATE                                 
              MOVE WS-START-DATE         TO LEXTRACT-FROM-DATE                  
           END-IF.                                                              
           MOVE GDACR-PREM-DUE-DATE      TO LEXTRACT-EFF-DATE.                  
                                                                                
       5200-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ** EXTRACT FROM & TO DATES FOR MONTHLY ADVISORS                 **        
      **      ADVISORS PAID MONTHLY WILL GENERATE A FROM / TO DATE    **        
      **      FOR THE MONTH THE PREMIUM WAS PAID                      **        
      **      FROM DATE IS THE 1ST OF MONTH, TO DATE IS LAST DAY      **        
      ******************************************************************        
       5500-GET-MTH-ADVISOR-DATES.                                              
                                                                                
           MOVE 'MONTHLY ADVISOR ' TO WS-LOGIC-TYPE.                            
                                                                                
           MOVE GDACR-PREM-DUE-DATE      TO LEXTRACT-EFF-DATE                   
                                            LEXTRACT-FROM-DATE                  
                                            LEXTRACT-TO-DATE.                   
      *-----------------------------------------------------------------        
      *  "FROM"DATE IS THE 1ST OF MONTH, "TO" DATE IS LAST DAY OF MTH **        
      *-----------------------------------------------------------------        
           MOVE 01                       TO LEXTRACT-FROM-DATE-DD.              
           MOVE 31                       TO LEXTRACT-TO-DATE-DD.                
                                                                                
           EVALUATE  LEXTRACT-EFF-DATE-MM                                       
              WHEN  02                                                          
                             MOVE 28 TO LEXTRACT-TO-DATE-DD                     
              WHEN  04                                                          
                             MOVE 30 TO LEXTRACT-TO-DATE-DD                     
              WHEN  06                                                          
                             MOVE 30 TO LEXTRACT-TO-DATE-DD                     
              WHEN  09                                                          
                             MOVE 30 TO LEXTRACT-TO-DATE-DD                     
              WHEN  11                                                          
                             MOVE 30 TO LEXTRACT-TO-DATE-DD                     
           END-EVALUATE.                                                        
                                                                                
       5500-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      ** GET THE DATE OF THE DAY AFTER THE DATE SUPPLIED HERE         **        
      ******************************************************************        
       5600-CALC-DAY-AFTER.                                                     
      *    CONVERT YYYYMMDD DATE       TO ALIS FORMAT                           
           MOVE WS-CONVERT-DATE-BEFORE TO VDATE1-YYYYMMDD.                      
           MOVE 'B'                    TO VDATE-REQ-SERVICE.                    
           MOVE 'B'                    TO VDATE-REQ-BASIS.                      
           MOVE '1'                    TO VDATE-REQ-DETAIL.                     
           MOVE 'E'                    TO VDATE-REQ-LANGUAGE.                   
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
      *    ADD 1 DAY                   TO ALIS DATE                             
           MOVE '4'                    TO VDATE-REQ-SERVICE                     
           MOVE ZERO                   TO VDATE-ADJUST-MONTHS                   
                                          VDATE-ADJUST-YEARS.                   
           MOVE +1                     TO VDATE-ADJUST-DAYS.                    
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
      *    CONVERT ALIS DATE BACK      TO YYYYMMDD FORMAT                       
           MOVE VDATE-ALIS-DATE2       TO VDATE-ALIS-DATE1.                     
           MOVE '2'                    TO VDATE-REQ-SERVICE.                    
           MOVE 'B'                    TO VDATE-REQ-BASIS.                      
           MOVE '1'                    TO VDATE-REQ-DETAIL.                     
           MOVE 'E'                    TO VDATE-REQ-LANGUAGE.                   
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           MOVE VDATE1-YYYYMMDD        TO WS-CONVERT-DATE-AFTER.                
                                                                                
       5600-CALC-DAY-AFTER-EXIT.                                                
            EXIT.                                                               
                                                                                
      ******************************************************************        
      ** GET THE DATE OF THE DAY BEFORE THE DATE SUPPLIED HERE        **        
      ******************************************************************        
       5600-CALC-DAY-BEFORE.                                                    
      *    CONVERT YYYYMMDD DATE       TO ALIS FORMAT                           
           MOVE WS-CONVERT-DATE-BEFORE TO VDATE1-YYYYMMDD.                      
           MOVE 'B'                    TO VDATE-REQ-SERVICE.                    
           MOVE 'B'                    TO VDATE-REQ-BASIS.                      
           MOVE '1'                    TO VDATE-REQ-DETAIL.                     
           MOVE 'E'                    TO VDATE-REQ-LANGUAGE.                   
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
      *    SUBTRACT 1 DAY FROM ALIS DATE                                        
           MOVE '4'                    TO VDATE-REQ-SERVICE                     
           MOVE ZERO                   TO VDATE-ADJUST-MONTHS                   
                                          VDATE-ADJUST-YEARS.                   
           MOVE -1                     TO VDATE-ADJUST-DAYS.                    
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
      *    CONVERT ALIS DATE BACK      TO YYYYMMDD FORMAT                       
           MOVE VDATE-ALIS-DATE2       TO VDATE-ALIS-DATE1.                     
           MOVE '2'                    TO VDATE-REQ-SERVICE.                    
           MOVE 'B'                    TO VDATE-REQ-BASIS.                      
           MOVE '1'                    TO VDATE-REQ-DETAIL.                     
           MOVE 'E'                    TO VDATE-REQ-LANGUAGE.                   
           CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
           MOVE VDATE1-YYYYMMDD        TO WS-CONVERT-DATE-AFTER.                
                                                                                
       5600-CALC-DAY-BEFORE-EXIT.                                               
            EXIT.                                                               
                                                                                
       5700-FIND-COMP.                                                          
      ******************************************************                    
      ***  GET FIRST IDMS COMP RECORD          *************                    
      ******************************************************                    
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                     GO TO 5700-EXIT.                                           
           MOVE 'N'     TO WS-COMP-DONE.                                        
                                                                                
           PERFORM 5800-GET-GWCORCOMP THRU 5800-EXIT                            
                   UNTIL WS-COMP-DONE = 'Y'.                                    
                                                                                
       5700-EXIT.                                                               
            EXIT.                                                               
                                                                                
       5800-GET-GWCORCOMP.                                                      
      *************************************************************             
      ***  GET IDMS COMP RECORD THAT MATCHES CURR PROCESS DATE.  **             
      ***  COMP PROCESS DATE MUST EQUAL THE CURRENT PROCESS DATE **             
      ***  AND THE COMP-AMT MUST EQUAL THE GDACR-CMAMT ON THE    **             
      ***  INPUT COMMISSIONS RECORD. USE THE COMP-EFF-DATE AS    **             
      ***  THE PREM-DUE-DATE.                                     **            
      *************************************************************             
           MOVE COMP-PROCESS-DATE          TO VDATE-ALIS-DATE1.                 
           PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT                          
           IF VDATE-RET-IND NOT = +0                                            
              MOVE WS-GROUPX5                 TO DER-GROUP-NUMBER               
              MOVE WS-SUB-ACCT3               TO DER-SUB-ACCOUNT                
              MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                       
              MOVE +19                        TO DER-SUB                        
              MOVE DER-MESSAGE (DER-SUB)      TO DER-DESCRIPTION                
              MOVE 'Y'                        TO WS-SERIOUS-ERROR-SW            
              PERFORM 9400-WRITE-REC-SYS023                                     
                 THRU 9400-WRITE-SYS023-EXIT                                    
           ELSE                                                                 
              MOVE VDATE1-YYYYMMDD         TO WS-COMP-PROC-DATE                 
           END-IF.                                                              
                                                                                
           IF WS-COMP-PROC-DATE = WS-PROC-DATE                                  
      *       COMP-AMT          = GDACR-CMAMT(1)                                
                                                                                
              MOVE COMP-EFF-DATE           TO VDATE-ALIS-DATE1                  
              PERFORM 8000-DATE-CONVERSION THRU 8000-EXIT                       
              IF VDATE-RET-IND NOT = +0                                         
                 MOVE WS-GROUPX5              TO DER-GROUP-NUMBER               
                 MOVE WS-SUB-ACCT3            TO DER-SUB-ACCOUNT                
                 MOVE GDACR-AGENT-CODE TO DER-ADVISOR-NUMBER                    
                 MOVE +20                     TO DER-SUB                        
                 MOVE DER-MESSAGE (DER-SUB)   TO DER-DESCRIPTION                
                 MOVE 'Y'                     TO WS-SERIOUS-ERROR-SW            
                 PERFORM 9400-WRITE-REC-SYS023                                  
                    THRU 9400-WRITE-SYS023-EXIT                                 
              ELSE                                                              
                 MOVE VDATE1-YYYYMMDD      TO WS-COMP-EFF-DATE                  
                                                                                
           IF COMP-AMT          = GDACR-CMAMT(1) AND                            
              WS-COMP-EFF-DATE  = GDACR-ACCT-EFFECTIVE-DATE                     
                                                                                
              MOVE WS-COMP-EFF-DATE        TO GDACR-PREM-DUE-DATE               
              MOVE 'Y'                     TO WS-COMP-DONE                      
              GO TO 5800-EXIT.                                                  
                                                                                
      *%   OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               MOVE 'Y'                    TO WS-COMP-DONE.                     
                                                                                
       5800-EXIT.                                                               
            EXIT.                                                               
      *-----------------------------------------------------------------        
       7000-DATE-JULIAN.                                                        
      *-----------------------------------------------------------------        
                                                                                
           MOVE 'B'                        TO VDATE-REQ-SERVICE                 
           MOVE 'B'                        TO VDATE-REQ-BASIS                   
           MOVE '1'                        TO VDATE-REQ-DETAIL                  
           MOVE 'E'                        TO VDATE-REQ-LANGUAGE                
           CALL GC2DATE USING GAC-DATE-PARAMETERS                               
           MOVE VDATE-ALIS-YEAR1           TO WS-JULIAN-YYY                     
           MOVE VDATE-ALIS-DAY1            TO WS-JULIAN-DDD.                    
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       8000-DATE-CONVERSION.                                                    
      *-----------------------------------------------------------------        
           MOVE '2B2E' TO VDATE-REQUEST-AREA                                    
           CALL GC2DATE USING GAC-DATE-PARAMETERS                               
                                                                                
           IF VDATE-RET-CODE NOT EQUAL ZERO                                     
              DISPLAY '***  ERROR DATE CONVERSION : ',                          
                       VDATE-RETURN-AREA      , '     ',                        
                       VDATE-ALIS-DATE1       , '     ',                        
                       VDATE1-YYYYMMDD                                          
           END-IF.                                                              
                                                                                
       8000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ********************************************************                  
      * READ VOCOMM VCM/GIPSY MASTER                       ***                  
      ********************************************************                  
       8100-READ-VCM-GIPSY.                                                     
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       8100-READ-VCM-GIPSY-EXIT.                                                
           EXIT.                                                                
                                                                                
      ***********************************************************               
      ** READ DATE PARAMETER FILE                             ***               
      ***********************************************************               
       9000-READ-REC-SYS011.                                                    
           MOVE LR-GARDTCRD-IN              TO LOGICAL-RECORD-NAME.             
           CALL GAEDATSR                 USING WS-GAEDATSR-VERB                 
                                               GARDTCRD-RECORD                  
                                               ICBM.                            
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'                   TO WS-END-OF-DATEPARM               
              ELSE                                                              
                DISPLAY 'ERROR READING GARDTCRD DATE PARM' ICBM                 
                MOVE +1                     TO WTL-SUB                          
                MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                     
                PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                        
              END-IF                                                            
           END-IF.                                                              
       9000-READ-REC-SYS011-EXIT.                                               
           EXIT.                                                                
                                                                                
      ***********************************************************               
      ** READ COMMISSIONS RECORDS (GDACR FILES)               ***               
      ***********************************************************               
       9100-READ-REC-SYS010.                                                    
           MOVE LR-COMMSSN-IN       TO LOGICAL-RECORD-NAME.                     
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       IN-COM-RELEASE-RECORD                    
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'           TO WS-END-OF-COMM-FILE                      
              ELSE                                                              
                DISPLAY 'ERROR READING INPUT COMMISSIONS FILE' ICBM             
                MOVE +2  TO WTL-SUB                                             
                MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                     
                PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                        
              END-IF                                                            
           END-IF.                                                              
                                                                                
       9100-READ-REC-SYS010-EXIT.                                               
           EXIT.                                                                
                                                                                
      ***********************************************************               
      ** READ INPUT SUPPLEMENTAL FILE - OBTAIN SEQ NUMBER     ***               
      ***********************************************************               
       9200-READ-REC-SYS012.                                                    
           MOVE LR-DLOADER-IN               TO LOGICAL-RECORD-NAME.             
           CALL GAEDATSR                 USING WS-GAEDATSR-VERB                 
                                               DATALOADER-RECORD                
                                               ICBM.                            
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'                   TO WS-END-OF-DLOADER-FILE           
              ELSE                                                              
                DISPLAY 'ERROR READING INPUT SUPPLEMENTAL FILE' ICBM            
                MOVE +3                     TO WTL-SUB                          
                MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                     
                PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                        
              END-IF                                                            
           END-IF.                                                              
       9200-READ-REC-SYS012-EXIT.                                               
           EXIT.                                                                
                                                                                
      ***********************************************************               
      ** WRITE SUPPLEMENTAL EXTRACT RECORD                    ***               
      ***********************************************************               
       9300-WRITE-DLOADER-SYS020.                                               
      *    PERFORM 9800-DISPLAY    THRU 9800-EXIT.                              
                                                                                
           MOVE 'PRINT-DATA-020'          TO LOGICAL-RECORD-NAME.               
                                                                                
           CALL GAEDATSR               USING STORE-LR                           
                                             DATALOADER-RECORD                  
                                             ICBM.                              
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING SUPPLEMENTAL EXTRACT: ' ICBM           
              MOVE +4                     TO WTL-SUB                            
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
           INITIALIZE DATALOADER-RECORD.                                        
                                                                                
       9300-WRITE-DLOADER-SYS020-EXIT.                                          
           EXIT.                                                                
                                                                                
      ***********************************************************               
      ** WRITE SUPPLEMENTAL EXTRACT ERROR RECORD              ***               
      ***********************************************************               
       9400-WRITE-REC-SYS023.                                                   
           MOVE 'PRINT-DATA-023'          TO LOGICAL-RECORD-NAME.               
                                                                                
           CALL GAEDATSR               USING STORE-LR                           
                                             DLOADER-ERROR-RECORD               
                                             ICBM.                              
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING ERROR FILE: ' ICBM                     
              MOVE +5                     TO WTL-SUB                            
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
           INITIALIZE DLOADER-ERROR-RECORD.                                     
                                                                                
       9400-WRITE-SYS023-EXIT.                                                  
           EXIT.                                                                
                                                                                
      ***********************************************************               
      ** WRITE SUPPLEMENTAL EXTRACT TRIGGER FILE RECORD       ***               
      ***********************************************************               
       9500-WRITE-DLRFTP-SYS022.                                                
           MOVE 'PRINT-DATA-022'          TO LOGICAL-RECORD-NAME.               
                                                                                
           CALL GAEDATSR               USING STORE-LR                           
                                             DLOADER-FTP-RECORD                 
                                             ICBM.                              
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING FTP REC: ' ICBM                        
              MOVE +6                     TO WTL-SUB                            
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
           INITIALIZE DLOADER-FTP-RECORD.                                       
                                                                                
       9500-WRITE-DLRFTP-SYS022-EXIT.                                           
           EXIT.                                                                
                                                                                
      ***********************************************************               
      ** DISPLAY STATEMENTS - USED FOR DEBUGGING              ***               
      ***********************************************************               
       9800-DISPLAY.                                                            
           DISPLAY '+++ '     WS-LOGIC-TYPE                                     
           DISPLAY ' GROUP:'                   WS-GROUPL7                       
                   ' ACCT: '                   WS-SUB-ACCT3                     
                   ' AGENT: '                  GDACR-AGENT-CODE                 
                   ' STATUS: '                 WS-ACCT-STATUS                   
                   ' FOGL: '                   GDACR-FOGL-CODE                  
           DISPLAY ' CAUSE CODE: '             GDACR-CAUSE                      
                   ' GDACR-CODE(1): '          GDACR-CODE(1)                    
                   ' PREMNO: '                 GDACR-PREMNO                     
                   ' LEXTRACT-YEAR-IND: '      LEXTRACT-YEAR-INDICATOR          
           DISPLAY ' ACCT-EFF-DATE: '         GDACR-ACCT-EFFECTIVE-DATE         
                   ' WS-RENEW-EFFECT: '        WS-RENEW-EFFECT-DATE             
                   ' PREM-DUE-DATE: '          GDACR-PREM-DUE-DATE              
           DISPLAY ' WS-LAST-RECON: '          WS-LAST-RECON-DATE               
                   ' WS-NEXT-RECON: '          WS-NEXT-RECON-DATE               
           DISPLAY ' WS-NEXT-RECON-A1D: '      WS-NEXT-RECON-DATE-A1D           
                   ' WS-NEXT-RECON-A1Y: '      WS-NEXT-RECON-DATE-A1Y           
           DISPLAY ' WS-LAST-RECON-A1D: '      WS-LAST-RECON-DATE-A1D           
                   ' WS-START-DATE: '          WS-START-DATE                    
                   ' WS-STOP-DATE: '           WS-STOP-DATE                     
           DISPLAY ' LEXTRACT-FROM: '          LEXTRACT-FROM-DATE               
                   ' LEXTRACT-TO: '            LEXTRACT-TO-DATE                 
                   ' LEXTRACT-EFF: '           LEXTRACT-EFF-DATE                
           DISPLAY ' WS-TERM-EFF: '            WS-TERM-EFFECTIVE-DATE           
                   ' WS-TERM-PROC: '           WS-TERM-PROCESS-DATE             
                   ' LEXTRACT-PROC: '          LEXTRACT-PROC-DATE               
                                                                                
           DISPLAY ' '.                                                         
                                                                                
           IF LEXTRACT-EFF-DATE > LEXTRACT-TO-DATE                              
              DISPLAY '*****  WARNING:   EFFECTIVE DATE > TO DATE'              
           END-IF.                                                              
                                                                                
       9800-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9999-WTL-ABEND                                                          
      ******************************************************************        
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL'             USING  WTL-MESSAGES-AREA                      
                                         WTL-FLAG                               
                                         WTL-REPLY                              
                                         WTL-REPLY-AREA.                        
                                                                                
GNE   *%   CALL 'ILBOABN0'        USING  WS-COMP-CODE.                          
GNE        CALL SNAPAID                                                         
GNE        MOVE +13 TO RETURN-CODE                                              
GNE        CALL CEE3ABD USING ABDCODE                                           
GNE                           ABDCLEANUP.                                       
                                                                                
       9999-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH                                            
CPYNME                               END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
MAN07 *9999-DUMP-ROUTINE.                                                       
MAN07 ******************************************************************        
MAN07 *    SERIOUS ERROR OCCURRED.                                              
MAN07 *    DISPLAY SOME CONSOLE MESSAGES, TAKE A DUMP THEN ABEND.               
MAN07 *    COPYBOOK GWRDUMP IS REQUIRED                                         
MAN07 ******************************************************************        
MAN07 *                                                                         
MAN07 *    MOVE WS-PROGRAM-ID TO GWRDUMP-PROGRAM-NAME.                          
MAN07 *    CALL GWCDUMP    USING ICBM                                           
MAN07 *                          GWRDUMP.                                       
MAN07 *                                                                         
MAN07 *9999-EXIT.                                                               
MAN07 *    EXIT.                                                                
