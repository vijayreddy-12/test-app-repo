       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GC2PRNTL.                                                   
      *REMARKS.  CLONE OF GPRINTAL                                              
      *          GC2PRNTL RUNS AFTER GSPLIRT HAS PRODUCED THE REPORT            
      *          FILE WHICH IS READ BY GC2PRNTL.  GC2PRNTL HAS THE              
      *          ABILITY TO PRINT ALL REPORTS, ALL FORMS STARTING               
      *          FOR SPECIFIC REPORT TYPE OR SPECIFIC REPORT TYPES.             
      *          IT WILL FURTHER PRODUCE SPECIFIC REPORT TYPES FOR              
      *          A PARTICULAR FORM, GROUP AND ACCOUNT.                          
      *                                                                         
      ******************************************************************        
      *                       HISTORY                                  *        
      *----------------------------------------------------------------*        
      *                                                                *        
      *  JULY 2005  REGINA KNAUD  -  VOCOMM VCM/GIPSY:                 *        
      *                              CLONE GPRINTAL FOR VO COMMISSIONS *        
      *                                                                *        
      *  07OCT08  IBMECU        - ENTERPRISE COMPILER UPGRADE          *        
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *           MAKE CALLS TO GC2NAPPR AND GC2COMCR STATIC BECAUSE            
      *           POSITION IN READING NEXT REC ON DLSI74 IS LOST                
      *----------------------------------------------------------------*        
      *DATE-WRITTEN.  JULY 2005.                                                
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  START-DATA-DIVISION     PIC X(16)  VALUE '* START  OF WS *'.         
                                                                                
      *01  WS-DYNAMIC-PROGRAM-CALLS.                                            
      *    05  GC2NAPPR                   PIC X(8)    VALUE 'GC2NAPPR'.         
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      REPLYS FROM VARIOUS QUESTION THAT HAVE BEEN ASKED         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  RESTART-REPLY               PIC X(1)  VALUE SPACES.                  
       01  EOF-REPLY                   PIC X(1)  VALUE SPACES.                  
       01  EOJ-REPLY                   PIC X(1)  VALUE SPACES.                  
       01  RESTART-CODE.                                                        
           03  RESTART-TYPE            PIC X(1)  VALUE SPACES.                  
           03  RESTART-FORM            PIC X(1)  VALUE SPACES.                  
GNE        03  RESTART-GROUP           PIC X(7)  VALUE SPACES.                  
       01  COPY-INDICATOR              PIC X.                                   
       01  COMMISSION-RUN              PIC X(1)  VALUE 'N'.                     
       01  GC2NAPPR-CALLED-FLAG        PIC X(1)  VALUE 'N'.                     
       01  GPRBILLS-CALLED-FLAG        PIC X(1)  VALUE 'N'.                     
       01  GPRCERTL-CALLED-FLAG        PIC X(1)  VALUE 'N'.                     
       01  GPROVRAG-CALLED-FLAG        PIC X(1)  VALUE 'N'.                     
       01  CLOSE-FILES-FLAG            PIC X(1)  VALUE 'N'.                     
      *----------------------------------------------------------------*        
      *                                                                *        
      *      WORK AREA FOR GRINTAL                                     *        
      *                               ADDED JUNE 6-88  BRENT G. WILKE  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WORK-AREA.                                                           
           05  CONTROL-SYS052           PIC XXX.                                
               88  SYS052-CLOSED           VALUE 'YES'.                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *      INFORMATION ABOUT THE TYPE OF RESTART AND THE             *        
      *      FINAL RECORD COUNTS                                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  END-COUNT                   PIC S9(7)  COMP-3  VALUE +0.             
      *----------------------------------------------------------------*        
      *                                                                *        
      *            THERE ARE 4 POSSIBLE RUN TYPES:                     *        
      *                                                                *        
      *  1) RESTART REPLY IS "N" ("NORMAL" RUN)                        *        
      *                                                                *        
      *  2) RESTART REPLY IS "Y" AND READ TO END OF FILE REPLY IS "Y"  *        
      *     (SPECIFIC REPORT TYPES FOR SPECIFIC FORMS, GROUP NUMBER    *        
      *      AND ACCOUNT FOR RECORD TYPES 2, 3, 5 AND 6 ONLY)          *        
      *                                                                *        
      *  3) RESTART REPLY IS "Y", READ TO END OF FILE REPLY IS "N"     *        
      *     AND RESTART CODE IS "ERRORS" ( ERRORS ONLY FOR SPECIFIC    *        
      *     REPORTS, RECORD TYPES 2, 3, 4, 5 AND 6)                    *        
      *                                                                *        
      *  4) RESTART REPLY IS "Y" AND READ TO END OF FILE REPLY IS "N"  *        
      *     AND USER SUPPLIED RESTART CODE ( SPECIFIC REPORT TYPE FOR  *        
      *     SPECIFIC FORM, GROUP NUMBER AMD ACCOUNT)                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  RUN-TYPE                    PIC S9(1)  COMP-3  VALUE +0.             
      *----------------------------------------------------------------*        
      *                                                                *        
      *                                                                *        
      *   NOTE ====>   THE RECORD LAYOUT THAT FOLLOWS IS FOR THE       *        
      *                DATE RECORD ONLY.... (TYPE A)                   *        
      *                BECAUSE OF THE PREVIOUS SORT, IT IS THE FIRST   *        
      *                RECORD READ, AND THE REMAINING RECORDS ARE READ *        
      *                OVER TOP OF THE DATE RECORD. THEREFOR THE RECORD*        
      *                FORMATS OF THE OTHERS ARE NOT THE SAME AS THIS. *        
      *                                                                *        
      *                                                MARCUS  '89     *        
      *----------------------------------------------------------------*        
       01  TAPE-RECORD.                                                         
           03  TAPE-RECORD-LENGTH   PIC X(4).                                   
           03  TAPE-RECORD-TYPE     PIC X(1).                                   
           03  TAPE-LODATE          PIC X(4).                                   
           03  TAPE-HIDATE          PIC X(4).                                   
           03  TAPE-BILL            PIC X(1).                                   
           03  TAPE-STATDATE        PIC X(4).                                   
           03  TAPE-PREMDATE        PIC X(4).                                   
           03  TAPE-CURRENT-LODATE  PIC X(4).                                   
           03  TAPE-COPY-INDICATOR  PIC X.                                      
           03  FILLER               PIC X(5423).                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     THE FOLLOWING DATA IS OBTAINED FROM THE DATE RECORD        *        
      *                                                                *        
      *     ST-LODATE      - LOW DATE                                  *        
      *     ST-HIDATE      - HIGH DATE                                 *        
      *     ST-STATDATE    - STATEMENT DATE                            *        
      *     ST-PREMDATE    - PREMIUM CLOSING DATE                      *        
      *     RESTART-INFO   - RESTART INFORMATION FROM THE CONSOLE      *        
      *                      RECORD TYPE (NUMERIC AND CHARACTER)       *        
      *                      FORM NUMBER                               *        
      *                      GROUP NUMBER                              *        
      *     ST-CURR-LODATE - CURRENT LOW DATE                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  MISC-AREA.                                                           
           03  ST-LODATE               PIC X(4).                                
           03  ST-HIDATE               PIC X(4).                                
           03  ST-STATDATE             PIC X(4).                                
           03  ST-PREMDATE             PIC X(4).                                
           03  RESTART-INFO.                                                    
               05  RESTART-RECORD-TYPE PIC 9(1).                                
               05  RESTART-RECORD-TYPE-X REDEFINES RESTART-RECORD-TYPE          
                                       PIC X(1).                                
               05  FILLER              PIC X(11).                               
           03  ST-CUR-LODATE           PIC X(4).                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *        TAPE PARAMTER COPY BOOK FOR SYS011 AND SYS014           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-PARAMETERS.                                                     
        COPY  GPRTPARM  REPLACING                                               
                                            ==01  GPRTPARM.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *     PRINT PARAMETER COPY BOOK FOR SYS022 TO SYS029 INCLUSIVE   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-PARAMETERS.                                                    
        COPY  GPRPRINT  REPLACING                                               
                                            ==01  GPRPRINT.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *              REPORT ACCUMULATORS COPY BOOK                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-ACCUMULATORS.                                                 
        COPY  GPRACCUM  REPLACING                                               
                                            ==01  GPRACCUM.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *        AREA USED BY "WTL" MESSAGES TO TALK TO THE USER         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WTL-PARAMETERS.                                                      
           03  WTL-MESSAGES.                                                    
               05  WTL-MSG-LENGTH        PIC S9(3) COMP-3 VALUE +80.            
               05  WTL-CARRIAGE-CONTROL  PIC X(1)         VALUE SPACES.         
               05  WTL-CONTENT           PIC X(79)        VALUE SPACES.         
           03  WTL-FLAG                  PIC X(1)         VALUE 'B'.            
           03  WTL-REPLY                 PIC X(3)         VALUE SPACES.         
           03  WTL-REPLY-AREA            PIC X(130)       VALUE SPACES.         
       01  WTL-COUNT                     PIC 9(1)         VALUE ZEROS.          
       01  MYPRT-PARMS.                                                         
           03  MYPRT-FORMAT     VALUE 'FB'         PIC XX.                      
           03  MYPRT-RECSIZE         PIC 9(5)  VALUE 00165.                     
           03  MYPRT-BLKSIZE         PIC 9(5)  VALUE 00165.                     
           03  SYS052-PARMS.                                                    
               05  SYS052              PIC X(6)  VALUE 'SYS052'.                
               05  SYS052-RETCODE      PIC S9(1) VALUE +0  COMP-3.              
               05  SYS052-LRECL        PIC 9(5)  VALUE 00133.                   
               05  SYS052-BLKSIZE      PIC 9(5)  VALUE 03990.                   
               05  SYS052-RECFM        PIC XX    VALUE 'FB'.                    
               05  SYS052-REC-CNT      PIC S9(7) VALUE +0  COMP-3.              
      *    03  PRINT-SYS053     VALUE 'SYS053'     PIC X(6).                    
      *    03  PRINT-SYS054     VALUE 'SYS054'     PIC X(6).                    
           03  EXT-PARMS.                                                       
               05  EXT-SYS025          PIC X(6)  VALUE 'SYS075'.                
               05  EXT-RETURN          PIC S9(1) VALUE +0  COMP-3.              
               05  EXT-RECSIZE         PIC 9(5)  VALUE 19056.                   
               05  EXT-BLKSIZE         PIC 9(5)  VALUE 19060.                   
               05  EXT-FORMAT          PIC XX    VALUE 'VB'.                    
               05  EXT-SYS025-COUNT    PIC S9(7) VALUE +0  COMP-3.              
           03  DUMMY-REC               PIC X     VALUE ' '.                     
       01  END-DATA-DIVISION       PIC X(16)  VALUE '** END OF WS  **'.         
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
      *    05  GC2NAPPR                     PIC X(8)  VALUE 'GC2NAPPR'.         
      *    05  GC2COMCR                     PIC X(8)  VALUE 'GC2COMCR'.         
MAN07      05  GPRSOARR                     PIC X(8)  VALUE 'GPRSOARR'.         
       LINKAGE SECTION.                                                         
       01  PARM.                                                                
           05  PARMLENGTH                     PIC S9(4) COMP.                   
           05  PARMCARD                       PIC X(07).                        
                                                                                
       PROCEDURE DIVISION USING PARM.                                           
      *    DISPLAY  '====>  GC2PRNTL   <====='.                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                READ DATE RECORD FROM TAPE                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE 'N'               TO GPRBILLS-CALLED-FLAG                       
                                     GPRCERTL-CALLED-FLAG                       
                                     GC2NAPPR-CALLED-FLAG                       
                                     GPROVRAG-CALLED-FLAG.                      
                                                                                
           IF PARMLENGTH = 7                                                    
              MOVE 'Y'         TO COMMISSION-RUN                                
           ELSE                                                                 
              MOVE 'N'         TO COMMISSION-RUN.                               
                                                                                
           PERFORM READ-TAPE THRU READ-TAPE-EXIT.                               
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO END-OF-JOB.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *            CHECK TO SEE IF THIS IS THE CYCLE FILE              *        
      *                                                                *        
      *----------------------------------------------------------------*        
           DISPLAY 'TAPE-RECORD ..' TAPE-RECORD.                                
           IF TAPE-RECORD-TYPE EQUAL 'A'                                        
              MOVE TAPE-COPY-INDICATOR TO COPY-INDICATOR.                       
           IF  TAPE-BILL IS EQUAL TO '1' THEN                                   
               MOVE TAPE-STATDATE TO ST-STATDATE                                
           ELSE                                                                 
               MOVE SPACES TO ST-STATDATE.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *         INITIALIZE "MISCELLANOUS" INFORMATION AREA             *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE LOW-VALUES TO RESTART-INFO.                                     
           MOVE TAPE-LODATE TO ST-LODATE.                                       
           MOVE TAPE-HIDATE TO ST-HIDATE.                                       
           MOVE TAPE-PREMDATE TO ST-PREMDATE.                                   
           MOVE TAPE-CURRENT-LODATE TO ST-CUR-LODATE.                           
      *----------------------------------------------------------------*        
      *                                                                *        
      *                READ DATA RECORD FROM TAPE                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM  READ-TAPE THRU                                              
                    READ-TAPE-EXIT.                                             
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO END-OF-JOB.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     ASK THE OPERATOR IF THIS IS A RESTART.  IF THIS IS NOT     *        
      *     A RESTART THEN SELECT A PRINT PROGRAM.  WHEN THE RETURN    *        
      *     CODE FROM THE TAPE IS NOT ZEROS THEN WE ARE FINISHED.      *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM  ASK-RESTART-QUESTION THRU                                   
                    ASK-RESTART-QUESTION-EXIT.                                  
           IF  RESTART-REPLY IS EQUAL TO 'Q' THEN                               
               GO TO END-OF-JOB.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     THIS IS NOT A RESTART RUN SO KEEP SELECTING PRINT          *        
      *     PROGRAMS UNTIL THE END OF FILE IS ENCOUNTERED THEN         *        
      *     WE CAN LEAVE.                                              *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  RESTART-REPLY IS EQUAL TO 'N' THEN                               
               MOVE +1 TO RUN-TYPE                                              
               PERFORM  NO-RESTART-REPORT THRU                                  
                        NO-RESTART-REPORT-EXIT                                  
               GO TO END-OF-JOB.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         ASK IF THIS IS A RUN UNTIL END OF FILE OR NOT          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM  ASK-EOF-QUESTION THRU                                       
                    ASK-EOF-QUESTION-EXIT.                                      
           IF  EOF-REPLY IS EQUAL TO 'Q' THEN                                   
               GO TO END-OF-JOB.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              ASK FOR THE RESTART INFORMATION                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       RESTART-INFORMATION.                                                     
           PERFORM  ASK-RSTCODE-QUESTION THRU                                   
                    ASK-RSTCODE-QUESTION-EXIT.                                  
           IF  EOJ-REPLY IS EQUAL TO 'Q'                                        
               GO TO END-OF-JOB.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     CHECK TO SEE IF THE USER IS FINISHED PROCESSING.  IF       *        
      *     THEY ARE NOT FINISHED FIND OUT WHICH TYPE OF REPORTS       *        
      *     ARE TO BE PRODUCED.                                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  EOJ-REPLY IS EQUAL TO 'E'                                        
               MOVE HIGH-VALUES TO RESTART-INFO                                 
               MOVE 1 TO RESTART-RECORD-TYPE                                    
               MOVE +3 TO RUN-TYPE                                              
               PERFORM  ERROR-ONLY-REPORT THRU                                  
                        ERROR-ONLY-REPORT-EXIT                                  
                        GO TO END-OF-JOB.                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *                                                                *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE RESTART-CODE TO RESTART-INFO.                                   
           IF  EOF-REPLY IS EQUAL TO 'Y' THEN                                   
               IF  RESTART-RECORD-TYPE-X GREATER THAN '1' THEN                  
                   MOVE HIGH-VALUES TO RESTART-INFO                             
                   MOVE '1' TO RESTART-RECORD-TYPE-X                            
                   MOVE +2 TO RUN-TYPE                                          
                   PERFORM  SELECT-RANGE-REPORT THRU                            
                            SELECT-RANGE-REPORT-EXIT                            
                            GO TO END-OF-JOB                                    
               ELSE                                                             
                   MOVE +1 TO RUN-TYPE                                          
                   PERFORM  SELECT-RANGE-REPORT THRU                            
                            SELECT-RANGE-REPORT-EXIT                            
                            GO TO END-OF-JOB                                    
           ELSE                                                                 
               MOVE +4 TO RUN-TYPE                                              
               PERFORM  SELECT-SINGLE-REPORT THRU                               
                        SELECT-SINGLE-REPORT-EXIT                               
               GO TO RESTART-INFORMATION.                                       
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     WE ARE FINISHED PRODUCING REPORTS SO CLOSE ALL INPUT       *        
      *     FILES THEN CLOSE THE OUTPUT FILES AND THEN CLOSE ALL       *        
      *     PRINT FILES THAT ARE OPEN.                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OF-JOB.                                                              
           MOVE +4 TO EXT-RETURN.                                               
           CALL 'DLSWRITE' USING EXT-SYS025     EXT-RETURN                      
                                 DUMMY-REC      EXT-RECSIZE                     
                                 EXT-BLKSIZE    EXT-FORMAT                      
                                 EXT-SYS025-COUNT.                              
      * SYS052 ALREADY CLOSED IN GPRNXTAR                                       
           IF CONTROL-SYS052 EQUAL 'YES' OR                                     
              CONTROL-SYS052 EQUAL LOW-VALUES                                   
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +4 TO SYS052-RETCODE                                         
              CALL 'DLSWRITE' USING SYS052         SYS052-RETCODE               
                                    DUMMY-REC      SYS052-LRECL                 
                                    SYS052-BLKSIZE SYS052-RECFM                 
                                    SYS052-REC-CNT.                             
           MOVE +4 TO TAPE-RETURN.                                              
           CALL 'DLSWRITE' USING TAPE-SYS011                                    
                                 TAPE-RETURN                                    
                                 TAPE-RECORD                                    
                                 TAPE-SYS011-RECSIZE                            
                                 TAPE-SYS011-BLKSIZE                            
                                 TAPE-SYS011-FORMAT                             
                                 TAPE-SYS011-COUNT.                             
      *                                                                         
      ****************************************************************          
      *   CALL GPRBILLS  TO CLOSE SYS053 AND SYS054.                            
      ****************************************************************          
      *                                                                         
           IF  GPRBILLS-CALLED-FLAG = 'N'                                       
               MOVE 'Y'              TO CLOSE-FILES-FLAG                        
               CALL 'GPRBILLS' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     RUN-TYPE                                   
                                     COPY-INDICATOR                             
                                     CLOSE-FILES-FLAG.                          
      *                                                                         
      ****************************************************************          
      *   CALL GPRCERTL  TO CLOSE SYS064 AND SYS065.                            
      ****************************************************************          
      *                                                                         
           IF  GPRCERTL-CALLED-FLAG = 'N'                                       
               MOVE 'Y'              TO CLOSE-FILES-FLAG                        
               CALL 'GPRCERTL' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     RUN-TYPE                                   
                                     CLOSE-FILES-FLAG.                          
      *                                                                         
      ****************************************************************          
      *   CALL GPROVRAG  TO CLOSE SYS071 AND SYS072.                            
      ****************************************************************          
      *                                                                         
           IF  GPROVRAG-CALLED-FLAG = 'N'                                       
               MOVE 'Y'              TO CLOSE-FILES-FLAG                        
               CALL 'GPROVRAG' USING CLOSE-FILES-FLAG                           
                                     TAPE-RECORD                                
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     MISC-AREA.                                 
                                                                                
      ****************************************************************          
      *   THE CALL TO GSPERROR WAS COMMENTED OUT AS PART OF THE      *          
      *       GPSY-REL-1 CHANGES....  MARCUS  SEP/89                 *          
      ****************************************************************          
      *                                                                         
      *    CALL 'GPRERROR' USING TAPE-PARAMETERS                                
      *                          PRINT-PARAMETERS                               
      *                          REPORT-ACCUMULATORS.                           
           CALL 'GPRCOUNT' USING REPORT-ACCUMULATORS                            
                                 PRINT-PARAMETERS.                              
           IF COMMISSION-RUN = 'Y' AND                                          
              GC2NAPPR-CALLED-FLAG = 'N'                                        
               MOVE ' '          TO  TAPE-RECORD-TYPE                           
               CALL 'GC2NAPPR' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS.                       
           MOVE +4 TO PRINT-RETURN.                                             
           IF  PRINT-SYS022-COUNT IS NOT EQUAL TO +0 THEN                       
               CALL 'DLSWRITE' USING PRINT-SYS022                               
                                     PRINT-RETURN                               
                                     TAPE-RECORD                                
                                     PRINT-RECSIZE                              
                                     PRINT-BLKSIZE                              
                                     PRINT-FORMAT                               
                                     PRINT-SYS022-COUNT.                        
           IF  PRINT-SYS023-COUNT IS NOT EQUAL TO +0 THEN                       
               CALL 'DLSWRITE' USING PRINT-SYS023                               
                                     PRINT-RETURN                               
                                     TAPE-RECORD                                
                                     PRINT-RECSIZE                              
                                     PRINT-BLKSIZE                              
                                     PRINT-FORMAT                               
                                     PRINT-SYS023-COUNT.                        
           IF  PRINT-SYS024-COUNT IS NOT EQUAL TO +0 THEN                       
               CALL 'DLSWRITE' USING PRINT-SYS024                               
                                     PRINT-RETURN                               
                                     TAPE-RECORD                                
                                     PRINT-RECSIZE                              
                                     PRINT-BLKSIZE                              
                                     PRINT-FORMAT                               
                                     PRINT-SYS024-COUNT.                        
           IF  PRINT-SYS025-COUNT IS NOT EQUAL TO +0 THEN                       
               CALL 'DLSWRITE' USING PRINT-SYS025                               
                                     PRINT-RETURN                               
                                     TAPE-RECORD                                
                                     PRINT-RECSIZE                              
                                     PRINT-BLKSIZE                              
                                     PRINT-FORMAT                               
                                     PRINT-SYS025-COUNT.                        
           IF  PRINT-SYS026-COUNT IS NOT EQUAL TO +0 THEN                       
               CALL 'DLSWRITE' USING PRINT-SYS026                               
                                     PRINT-RETURN                               
                                     TAPE-RECORD                                
                                     PRINT-RECSIZE                              
                                     PRINT-BLKSIZE                              
                                     PRINT-FORMAT                               
                                     PRINT-SYS026-COUNT.                        
           IF  PRINT-SYS027-COUNT IS NOT EQUAL TO +0 THEN                       
               CALL 'DLSWRITE' USING PRINT-SYS027                               
                                     PRINT-RETURN                               
                                     TAPE-RECORD                                
                                     PRINT-RECSIZE                              
                                     PRINT-BLKSIZE                              
                                     PRINT-FORMAT                               
                                     PRINT-SYS027-COUNT.                        
           IF  PRINT-SYS028-COUNT IS NOT EQUAL TO +0 THEN                       
               CALL 'DLSWRITE' USING PRINT-SYS028                               
                                     PRINT-RETURN                               
                                     TAPE-RECORD                                
                                     PRINT-RECSIZE                              
                                     PRINT-BLKSIZE                              
                                     PRINT-FORMAT                               
                                     PRINT-SYS028-COUNT.                        
           CALL 'DLSWRITE' USING PRINT-SYS029                                   
                                 PRINT-RETURN                                   
                                 TAPE-RECORD                                    
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS029-COUNT.                            
                                                                                
           STOP RUN.                                                            
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                THIS IS A NORMAL RUN (NO RESTART)               *        
      *                                                                *        
      *    THIS ROUTINE IS USED TO SELECT A PRINT PROGRAM DEPENDING    *        
      *    ON THE TYPE OF RECORD THAT IS READ.  THE ONLY WAY OUT OF    *        
      *    THIS ROUTINE IS WHEN A NON-ZERO RETURN CODE IS RECEIVED.    *        
      *                                                                *        
      *    THE NEXT TAPE-RECORD IS READ BY THE CALLED PROGRAM.         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NO-RESTART-REPORT.                                                       
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO NO-RESTART-REPORT-EXIT.                                    
           PERFORM  SELECT-PRINT-PROGRAM THRU                                   
                    SELECT-PRINT-PROGRAM-EXIT.                                  
           GO TO NO-RESTART-REPORT.                                             
       NO-RESTART-REPORT-EXIT.                                                  
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      THIS ROUTINE IS USED TO PRODUCE THE ERROR REPORTS         *        
      *                                                                *        
      *    THE TAPE IS FIRST POSITIONED TO THE TYPE OF RECORD THAT     *        
      *    WILL BE NEEDED FOR THIS REPORT (RECORD TYPES 2 3 4 5 6).    *        
      *    THE ROUTINE TO SELECT PRINT PROGRAMS IS THEN USED TO READ   *        
      *    THAT TYPE OF RECORD.  THE RECORD TYPE IS THEN CHANGED AND   *        
      *    THE PROCEDURE REPEATED UNTIL A NON-ZERO RETURN CODE IS      *        
      *    RECEIVED.                                                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ERROR-ONLY-REPORT.                                                       
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO ERROR-ONLY-REPORT-EXIT.                                    
           IF  RESTART-RECORD-TYPE GREATER THAN TAPE-RECORD-TYPE THEN           
               PERFORM  READ-TAPE THRU                                          
                        READ-TAPE-EXIT                                          
               GO TO ERROR-ONLY-REPORT.                                         
           IF  RESTART-RECORD-TYPE NOT EQUAL TO TAPE-RECORD-TYPE THEN           
               ADD +1 TO RESTART-RECORD-TYPE                                    
               GO TO ERROR-ONLY-REPORT.                                         
           PERFORM  SELECT-PRINT-PROGRAM THRU                                   
                    SELECT-PRINT-PROGRAM-EXIT.                                  
           GO TO ERROR-ONLY-REPORT.                                             
       ERROR-ONLY-REPORT-EXIT.                                                  
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      * THIS ROUTINE PRODUCES ALL REPORTS FROM A SELECTED POINT        *        
      *                                                                *        
      *    THE TAPE IS FIRST POSITIONED TO THE TYPE OF RECORD THAT     *        
      *    WILL BE NEEDED FOR THE REPORT.  THE ROUTINE TO SELECT       *        
      *    PRINT PROGRAMS WILL READ FROM THAT TYPE OF READ UNTIL       *        
      *    A NON-ZERO RETURN CODE IS RECEIVED.                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       SELECT-RANGE-REPORT.                                                     
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO SELECT-RANGE-REPORT-EXIT.                                  
           IF  RESTART-RECORD-TYPE GREATER THAN TAPE-RECORD-TYPE THEN           
               PERFORM  READ-TAPE THRU                                          
                        READ-TAPE-EXIT                                          
               GO TO SELECT-RANGE-REPORT.                                       
           PERFORM  SELECT-PRINT-PROGRAM THRU                                   
                    SELECT-PRINT-PROGRAM-EXIT.                                  
           GO TO SELECT-RANGE-REPORT.                                           
       SELECT-RANGE-REPORT-EXIT.                                                
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *       THIS ROUTINE IS USED TO PRODUCE SELECTED REPORTS         *        
      *                                                                *        
      *    THE TAPE IS FIRST POSITIONED TO THE TYPE OF RECORD THAT     *        
      *    WILL BE NEEDED FOR THIS REPORT.  THE ROUTINE TO SELECT      *        
      *    PRINT PROGRAM IS THEN USED TO READ THOSE TYPES OF RECORDS.  *        
      *    IF THE TAPE HAS BEEN POSITIONED PAST THE TYPE OF RECORD     *        
      *    REQUIRED, EXIT                                              *        
      *----------------------------------------------------------------*        
       SELECT-SINGLE-REPORT.                                                    
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO SELECT-SINGLE-REPORT-EXIT.                                 
           IF  RESTART-RECORD-TYPE GREATER THAN TAPE-RECORD-TYPE THEN           
               PERFORM  READ-TAPE THRU                                          
                        READ-TAPE-EXIT                                          
               GO TO SELECT-SINGLE-REPORT.                                      
           IF  RESTART-RECORD-TYPE LESS THAN TAPE-RECORD-TYPE THEN              
               GO TO SELECT-SINGLE-REPORT-EXIT.                                 
           PERFORM  SELECT-PRINT-PROGRAM THRU                                   
                    SELECT-PRINT-PROGRAM-EXIT.                                  
       SELECT-SINGLE-REPORT-EXIT.                                               
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *       SET UP THE CALL TO A GENERAL I/O ROUTINE "DLSREAD"       *        
      *                                                                *        
      *     FOR THIS ROUTINE TO WORK YOU MUST SUPPLY IT WITH THE       *        
      *     SYSTEM NUMBER, AREA IN WHICH TO STORE THE DATA, LOGICAL    *        
      *     RECORD LENGTH, LOGICAL BLOCK SIZE AND THE RECORD FORMAT.   *        
      *     THE I/O ROUTINE WILL RETURN TO THE CALLER A RETURN CODE,   *        
      *     DATA IF ANY WAS READ AND THE NUMBER OF RECORD READ AT'     *        
      *     THIS POINT.                                                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       READ-TAPE.                                                               
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                TAPE-RECORD                                     
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
       READ-TAPE-EXIT.                                                          
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *        SET UP THE CALL TO A CONSOLE I/O ROUTINE "WTL"          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       CALL-WTL.                                                                
           CALL 'WTL' USING WTL-MESSAGES                                        
                            WTL-FLAG                                            
                            WTL-REPLY                                           
                            WTL-REPLY-AREA.                                     
       CALL-WTL-EXIT.                                                           
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             ASK USER IF THIS IS A RESTART OR NOT               *        
      *                                                                *        
      *     INITIALIZE RESTART REPLY AREA THEN TELL THE USER WHICH     *        
      *     PHASE HAS SENT THE MESSAGE AND WHY.  THEN ASK THE USER     *        
      *     THE QUESTION.  IF THE REPLY IS NOT "Y" OR "N" SLAP THE     *        
      *     USER WRIST AND ASK AGAIN.  THE USER HAS THREE TRIES AT     *        
      *     THE QUESTION.  IF AFTER THE THIRD TIME THE REPLY IS        *        
      *     STILL INVALID.  SET THE REPLY TO "Q" (QUIT) AND EXIT       *        
      *     THIS ROUTINE.                                              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ASK-RESTART-QUESTION.                                                    
           MOVE SPACES TO RESTART-REPLY.                                        
           MOVE ZERO TO WTL-COUNT.                                              
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           MOVE 'NO ' TO WTL-REPLY.                                             
           MOVE '*** GC2PRNTL    RESTART INQUIRY' TO WTL-CONTENT.               
           PERFORM  CALL-WTL THRU                                               
                    CALL-WTL-EXIT.                                              
       RESTART-QUESTION.                                                        
           IF  WTL-COUNT GREATER THAN 2 THEN                                    
               MOVE 'Q' TO RESTART-REPLY                                        
               MOVE 'NO ' TO WTL-REPLY                                          
               MOVE '*** MORE THAN 3 INVALID REPLIES' TO WTL-CONTENT            
               PERFORM  CALL-WTL THRU                                           
                        CALL-WTL-EXIT                                           
               MOVE '*** GC2PRNTL TERMINATED' TO WTL-CONTENT                    
               PERFORM  CALL-WTL THRU                                           
                        CALL-WTL-EXIT                                           
               GO TO ASK-RESTART-QUESTION-EXIT.                                 
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           MOVE 'YES' TO WTL-REPLY.                                             
           MOVE '*** RESTART JOB?    Y OR N' TO WTL-CONTENT.                    
           PERFORM  CALL-WTL THRU                                               
                    CALL-WTL-EXIT.                                              
      *                                                                         
      *     NOTE THAT THE "NOT" CONDITION CHANGES THE "OR" TO AN                
      *     "AND" CONDITION WHEN CHECKING THE YES OR NO REPLY                   
      *                                                                         
           IF  WTL-REPLY-AREA IS NOT EQUAL TO 'Y' AND 'N' THEN                  
               MOVE SPACES TO WTL-REPLY-AREA                                    
               MOVE 'NO ' TO WTL-REPLY                                          
               MOVE '*** INVALID RESPONSE' TO WTL-CONTENT                       
               PERFORM  CALL-WTL THRU                                           
                        CALL-WTL-EXIT                                           
               ADD 1 TO WTL-COUNT                                               
               GO TO RESTART-QUESTION.                                          
           MOVE WTL-REPLY-AREA TO RESTART-REPLY.                                
       ASK-RESTART-QUESTION-EXIT.                                               
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *          ASK USER IF THIS IS A RESTART OR NOT                  *        
      *                                                                *        
      *    INITIALIZE EOF REPLY AREA THEN TELL THE USER WHICH PHASE    *        
      *    HAS SENT THE MESSAGE AND WHY.  THEN ASK THE USER THE        *        
      *    QUESTION.  IF THE REPLY IS NOT "Y" OR "N" SLAP THEIR        *        
      *    WRIST AND ASK AGAIN.  THE USER HAS THREE TRIES AT THE       *        
      *    QUESTION.  IF AFTER THE THIRD TIME THE REPLY IS STILL       *        
      *    INVALID.  SET THE REPLY TO "Q" (QUIT) AND EXIT THIS         *        
      *    ROUTINE.                                                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ASK-EOF-QUESTION.                                                        
           MOVE SPACES TO EOF-REPLY.                                            
           MOVE ZERO TO WTL-COUNT.                                              
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           MOVE 'NO ' TO WTL-REPLY.                                             
           MOVE '*** GC2PRNTL    END OF FILE INQUIRY' TO WTL-CONTENT.           
           PERFORM  CALL-WTL THRU                                               
                    CALL-WTL-EXIT.                                              
       EOF-QUESTION.                                                            
           IF  WTL-COUNT GREATER THAN 2 THEN                                    
               MOVE 'Q' TO EOF-REPLY                                            
               MOVE 'NO ' TO WTL-REPLY                                          
               MOVE '*** MORE THAN 3 INVALID REPLIES' TO WTL-CONTENT            
               PERFORM  CALL-WTL THRU                                           
                        CALL-WTL-EXIT                                           
               MOVE '*** GC2PRNTL TERMINATED' TO WTL-CONTENT                    
               PERFORM  CALL-WTL THRU                                           
                        CALL-WTL-EXIT                                           
               GO TO ASK-EOF-QUESTION-EXIT.                                     
           MOVE SPACES TO WTL-REPLY-AREA                                        
           MOVE 'YES' TO WTL-REPLY.                                             
           MOVE '*** RUN TO END OF FILE?    Y OR N' TO WTL-CONTENT              
           PERFORM  CALL-WTL THRU                                               
                    CALL-WTL-EXIT.                                              
      *                                                                         
      *     NOTE THAT THE "NOT" CONDITION CHANGES THE "OR" TO AN                
      *     "AND" CONDITION WHEN CHECKING THE YES OR NO REPLY                   
      *                                                                         
           IF  WTL-REPLY-AREA IS NOT EQUAL TO 'Y' AND 'N' THEN                  
               MOVE SPACES TO WTL-REPLY-AREA                                    
               MOVE 'NO ' TO WTL-REPLY                                          
               MOVE '*** INVALID RESPONSE' TO WTL-CONTENT                       
               PERFORM  CALL-WTL THRU                                           
                        CALL-WTL-EXIT                                           
               ADD 1 TO WTL-COUNT                                               
               GO TO EOF-QUESTION.                                              
           MOVE WTL-REPLY-AREA TO EOF-REPLY.                                    
       ASK-EOF-QUESTION-EXIT.                                                   
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *               ASK USER FOR THE RESTART CODE                    *        
      *                                                                *        
      *    INITIALIZE EOJ REPLY AREA AND THE RESTART CODE AREA         *        
      *    THEN TELL THE USER WHICH PHASE HAS SENT THE MESSAGE         *        
      *    AND WHY.  THEN ASK THE USER THE QUESTION.                   *        
      *                                                                *        
      *   IF THE REPLY WAS BLANK AND THE READ TO EOF REPLY WAS         *        
      *   "Y" SLAP THE USERS WRIST AND ASK THE QUESTION AGAIN.         *        
      *   IF RESTART REPLY WAS BLANK AND THE READ TO EOF REPLY         *        
      *   WAS "N" THEN WE ARE FINISHED AND THE EOJ-REPLY IS SET        *        
      *   TO "Q" AND THIS ROUTINE IS ENDED.                            *        
      *                                                                *        
      *   IF THE RESTART REPLY IS "ERRORS" AND THE READ EOF REPLY      *        
      *   WAS "N" SLAP THE USERS WRIST AND THEN ASK THE QUESTION       *        
      *   AGAIN.  IF THE RESTART REPLY WAS "ERRORS" AND THE READ       *        
      *   EOF REPLY WAS "Y" THEN SET THE EOJ-REPLY TO "E" AND THIS     *        
      *   ROUTINE IS ENDED.                                            *        
      *                                                                *        
      *   IF THE RESTART REPORT TYPE IS NOT NUMERIC THEN THIS          *        
      *   ROUTINE IS ENDED.                                            *        
      *                                                                *        
      *   IF THE RESTART REPORT TYPE IS NUMERIC, THE RESTART GROUP     *        
      *   IS NOT NUMERIC OR THE RESTART FORM IS ALPHABETIC AND NOT     *        
      *   BLANK SLAP THE USERS WRIST AND ASK THE QUESTION AGAIN.       *        
      *   IF RESTART REPORT TYPE IS NUMBERIS AND THE GROUP NUMBER      *        
      *   IS NUMERIC AND THE RESTART FORM IS NUMBERIC THEN THIS        *        
      *   ROUTINE IS ENDED.                                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ASK-RSTCODE-QUESTION.                                                    
           MOVE SPACES TO EOJ-REPLY.                                            
           MOVE SPACES TO RESTART-CODE.                                         
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           MOVE 'NO ' TO WTL-REPLY.                                             
           MOVE '*** GC2PRNTL    RESTART CODE INQUIRY' TO WTL-CONTENT.          
           PERFORM  CALL-WTL THRU                                               
                    CALL-WTL-EXIT.                                              
       RSTCODE-QUESTION.                                                        
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           MOVE 'YES' TO WTL-REPLY.                                             
           MOVE '*** ENTER RESTART CODE' TO WTL-CONTENT.                        
           PERFORM  CALL-WTL THRU                                               
                    CALL-WTL-EXIT.                                              
           IF  WTL-REPLY-AREA IS EQUAL TO SPACES THEN                           
               IF  EOF-REPLY IS EQUAL TO 'Y' THEN                               
                   MOVE SPACES TO WTL-REPLY-AREA                                
                   MOVE 'NO ' TO WTL-REPLY                                      
                   MOVE '*** INVALID RESPONSE' TO WTL-CONTENT                   
                   PERFORM  CALL-WTL THRU                                       
                            CALL-WTL-EXIT                                       
                   GO TO RSTCODE-QUESTION                                       
               ELSE                                                             
                   MOVE 'Q' TO EOJ-REPLY                                        
                   GO TO ASK-RSTCODE-QUESTION-EXIT.                             
           IF  WTL-REPLY-AREA IS EQUAL TO 'ERRORS' THEN                         
               IF  EOF-REPLY IS EQUAL TO 'N' THEN                               
                   MOVE SPACES TO WTL-REPLY-AREA                                
                   MOVE 'NO ' TO WTL-REPLY                                      
                   MOVE '*** INVALID RESPONSE' TO WTL-CONTENT                   
                   PERFORM  CALL-WTL THRU                                       
                            CALL-WTL-EXIT                                       
                   GO TO RSTCODE-QUESTION                                       
               ELSE                                                             
                   MOVE 'E' TO EOJ-REPLY                                        
                   GO TO ASK-RSTCODE-QUESTION-EXIT.                             
           MOVE WTL-REPLY-AREA TO RESTART-CODE                                  
           IF  RESTART-TYPE IS NUMERIC                                          
           AND ((RESTART-GROUP IS NOT EQUAL TO SPACES                           
                AND    RESTART-GROUP IS NOT NUMERIC)                            
               OR   (RESTART-FORM ALPHABETIC-UPPER AND                          
                     RESTART-FORM IS NOT EQUAL TO SPACES))                      
                     MOVE SPACES TO WTL-REPLY-AREA                              
                     MOVE 'NO ' TO WTL-REPLY                                    
                     MOVE '*** INVALID RESPONSE' TO WTL-CONTENT                 
                     PERFORM  CALL-WTL THRU                                     
                              CALL-WTL-EXIT                                     
                     GO TO RSTCODE-QUESTION.                                    
       ASK-RSTCODE-QUESTION-EXIT.                                               
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *       SELECT PRINT PROGRAM DEPENDING ON THE RECORD TYPE        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       SELECT-PRINT-PROGRAM.                                                    
      *                                                                         
      *    ARREARS REPORT - OVERDUE PREMIUM REPORT                              
      *                                                                         
      *         RECORD-TYPE H ====>   GFMINTM5                                  
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'H' THEN                            
               CALL  GPRSOARR  USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    P & A TRANSACTION REPORT                                             
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'J' THEN                            
               CALL 'GPRPAREG' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    GIPSY TRANSACTION REPORT (PRINT PARAMETERS NOT NEEDED)               
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'K' THEN                            
               CALL 'GPRTRAN1' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    ONE PART PRINT OUT                                                   
      *                                                                         
      *         RECORD-TYPE N ====>   GFMWRIDL                                  
      *                               GFMEDM2D                                  
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'N' THEN                            
               CALL 'GPRCHNGS' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    NAP REPORT                                                           
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'P' THEN                            
               MOVE 'Y'          TO  GC2NAPPR-CALLED-FLAG                       
               CALL 'GC2NAPPR' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    FIRST YEAR COMMISSIONS REPORT                                        
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'Q' THEN                            
               CALL 'GPRAGCOM' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    REMINDER RECORD REPORT                                               
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'R' THEN                            
               CALL 'GPRREMIN' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    NEXT SCHEDUALED ACTIVITY REPORT                                      
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'T' THEN                            
               CALL 'GPRNXTAR' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                    REPORT-ACCUMULATORS                         
               MOVE 'YES' TO CONTROL-SYS052                                     
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    TWO PART PRINT OUT                                                   
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'U' THEN                            
               CALL 'GPRMNTHS' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    BILLING EXCEPTION REPORT                                             
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'V' THEN                            
               CALL 'GPRBILEX' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    COMMISSION RELEASE SUMMARY AND CONTROL TOTALS REPORTS                
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'W' THEN                            
               CALL 'GC2COMCR' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    OVERAGE EXPIRY LETTERS AND REPORT                                    
      *       RECORD-TYPE - X         GFMOVRAG                                  
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO 'X' THEN                            
               CALL 'GPROVRAG' USING CLOSE-FILES-FLAG                           
                                     TAPE-RECORD                                
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     MISC-AREA                                  
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    BILLING STATEMENTS                                                   
      *                                                                         
      *         RECORD-TYPE 2 ====>   GFMEMD90                                  
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO '2' THEN                            
               MOVE 'Y'                  TO GPRBILLS-CALLED-FLAG                
               MOVE 'N'                  TO CLOSE-FILES-FLAG                    
               CALL 'GPRBILLS' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     RUN-TYPE                                   
                                     COPY-INDICATOR                             
                                     CLOSE-FILES-FLAG                           
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    IDENTIFICATION CERTIFICATES                                          
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO '3' THEN                            
               CALL 'GPRIDCER' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     RUN-TYPE                                   
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    ADDRESS LABELS                                                       
      *                                                                         
      *         RECORD-TYPE 4 ====>   GFMINTM4                                  
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO '4' THEN                            
               CALL 'GPRADLAB' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    GROUP CERTIFICATES                                                   
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO '5' THEN                            
               MOVE 'Y'                  TO GPRCERTL-CALLED-FLAG                
               MOVE 'N'                  TO CLOSE-FILES-FLAG                    
               CALL 'GPRCERTL' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     RUN-TYPE                                   
                                     CLOSE-FILES-FLAG                           
               GO TO SELECT-PRINT-PROGRAM-EXIT.                                 
      *                                                                         
      *    LAPSED NOTICES                                                       
      *         RECORD-TYPE 6 ====>   GFMINTM5                                  
      *                                                                         
           IF  TAPE-RECORD-TYPE IS EQUAL TO '6' THEN                            
               CALL 'GPRLAPNT' USING TAPE-RECORD                                
                                     MISC-AREA                                  
                                     PRINT-PARAMETERS                           
                                     TAPE-PARAMETERS                            
                                     REPORT-ACCUMULATORS                        
                                     RUN-TYPE.                                  
       SELECT-PRINT-PROGRAM-EXIT.                                               
           EXIT.                                                                
