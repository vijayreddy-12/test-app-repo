       ID DIVISION.                                                             
FXXTOK PROGRAM-ID.    GC2PRM.                                                   
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *AUTHOR.        IAN BUCKNELL.                                             
      *DATE-WRITTEN.  SEP 12,1990.                                              
      *DATE-COMPILED.                                                           
                                                                                
      *****************************************************************         
      * REMARKS.                                                                
      * REPORT: DIFFERENCES GREATER THAN $500 BETWEEN PRE-RELEASE               
      *         PREMIUM AND FIRST BILL PREMIUM, FOR GROUPS GOING                
      *         IN FORCE                                                        
      * ---------------------------------------------------------------         
      * THIS PROGRAM PRODUCES A REPORT ONLY.  AN EXTRACT TRIGGER FILE           
      * WAS PRODUCED BY GIPSY GFMMAINL (PROGRAM GFMPREMX) CONTAINING            
      * A RECORD FOR ANY GROUP GOING INFORCE ON THAT RUN.  THIS PROGRAM         
      * WILL READ THAT FILE AND COMPARE THE FIRST MONTH'S $PREMIUM              
      * STORED THERE TO THE PRE-RELEASE $PREMIUM STORED ON THE                  
      * COMMISSIONS DATABASE, REPORTING ON DIFFERENCES >$500.                   
      * ---------------------------------------------------------------         
      * 12SEP90, IAN BUCKNELL, ORIGINAL CODE PRODUCED AS PART OF                
      *                        SUPPORT RELEASE 3 (COMMISSIONS)                  
      *                                                                         
      * 03OCT08   IBM        - ENTERPRISE COMPILER UPGRADE            *         
      *****************************************************************         
      *DATE-COMPILED.                                                           
      *                                                                         
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
      *SCHEMA SECTION.                                                          
      *DB SSGWCO01 WITHIN SCGWCO01.                                             
      /                                                                         
       WORKING-STORAGE SECTION.                                                 
                                                                                
      *================================================================         
      * MISCELLANEOUS                                                           
      *================================================================         
       01  MISCELLANEOUS.                                                       
           05  START-BANNER               PIC X(50) VALUE                       
FXXTOK         '***** START OF WORKING STORAGE FOR GC2PRM *****'.               
           05  SAVE-AGENT            PIC X(6).                                  
           05  DATE-STUFF.                                                      
               10  QDATE-BD     VALUE 'BD'           PIC XX.                    
               10  RUN-DATE.                                                    
                   15  RUN-DATE-DD  VALUE LOW-VALUES  PIC X(2).                 
                   15  RUN-DATE-MM  VALUE LOW-VALUES  PIC X(2).                 
                   15  RUN-DATE-YY  VALUE LOW-VALUES  PIC X(2).                 
                   15  FILLER       VALUE LOW-VALUES  PIC X(2).                 
           05  MATH-CLASS.                                                      
               10  COMM-PREM-ACCUM   PIC S9(9)V99  COMP-3  VALUE ZERO.          
               10  DIFFERENCE-CALC   PIC S9(9)V99  COMP-3  VALUE ZERO.          
               10  GE500-PRE-REL     PIC S9(9)V99  COMP-3  VALUE ZERO.          
               10  GE500-CURRENT     PIC S9(9)V99  COMP-3  VALUE ZERO.          
               10  GE500-DIFFERENCE  PIC S9(9)V99  COMP-3  VALUE ZERO.          
               10  TOTAL-PRE-REL     PIC S9(9)V99  COMP-3  VALUE ZERO.          
               10  TOTAL-CURRENT     PIC S9(9)V99  COMP-3  VALUE ZERO.          
               10  TOTAL-DIFFERENCE  PIC S9(9)V99  COMP-3  VALUE ZERO.          
                                                                                
       01  COUNTERS-ETC.                                                        
           05  TEMP                COMP SYNC PIC S9(4).                         
           05  LINE-CNT            COMP SYNC PIC S9(4)  VALUE +90.              
           05  LINE-LIMIT          COMP SYNC PIC S9(4)  VALUE +55.              
           05  PAGE-CNT            COMP-3    PIC S9(4)  VALUE +0.               
                                                                                
       01  SWITCHES.                                                            
           05  NOT-ON-COMM-SW                PIC X      VALUE SPACE.            
           05  ERROR-BANNER                  PIC X(6)   VALUE 'ERR-SW'.         
      *    05  ERROR-SW            COMP      PIC S9     VALUE +0.               
           05  ERROR-SW            COMP      PIC S9(3)  VALUE +0.               
               88  ABORT     VALUE  +100.                                       
                                                                                
      /                                                                         
      *================================================================         
      * IFPRMEXT FILE IN                                                        
      *================================================================         
      *    *-----------------------------------------------------------         
      *    * PARMS ETC                                                          
      *    *-----------------------------------------------------------         
       01  IFPRMEXT-PARMS.                                                      
           05  SYS010-SYS010                 PIC X(6)   VALUE 'SYS010'.         
           05  SYS010-RET-CODE       COMP-3  PIC S9     VALUE +0.               
               88  IFPRMEXT-EOF                         VALUE +4.               
           05  SYS010-REC-SIZE               PIC X(5)   VALUE '00029'.          
           05  SYS010-BLOCK-SIZE             PIC X(5)   VALUE '23461'.          
           05  SYS010-REC-FORMAT             PIC X(2)   VALUE 'FB'.             
           05  SYS010-REC-COUNT      COMP-3  PIC S9(7)  VALUE +0.               
                                                                                
      *    *-----------------------------------------------------------         
      *    * RECORD IMAGE                                                       
      *    *-----------------------------------------------------------         
       COPY IFPRMEX7.                                                           
                                                                                
      /                                                                         
      *COPY IDMS SUBSCHEMA-NAMES.                                               
      *COPY IDMS SUBSCHEMA-CTRL.                                                
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      *================================================================         
      * COMMISSIONS DATABASE                                                    
      *================================================================         
       01  FILLER VALUE 'GWCORGRACCT RECORD------' PIC X(24).                   
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
       01  FILLER VALUE 'GWCORCOMP RECORD -------' PIC X(24).                   
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
                                                                                
      /                                                                         
      *================================================================         
      * REPORT OUT                                                              
      *================================================================         
      *    *-----------------------------------------------------------         
      *    * PARMS ETC                                                          
      *    *-----------------------------------------------------------         
       01  REPORT-PARMS.                                                        
           05  SYS020-SYS020                 PIC X(6)   VALUE 'SYS020'.         
           05  SYS020-RET-CODE       COMP-3  PIC S9     VALUE +0.               
           05  SYS020-REC-SIZE               PIC X(5)   VALUE '00133'.          
           05  SYS020-BLOCK-SIZE             PIC X(5)   VALUE '03990'.          
           05  SYS020-REC-FORMAT             PIC X(2)   VALUE 'FB'.             
           05  SYS020-REC-COUNT      COMP-3  PIC S9(7)  VALUE +0.               
                                                                                
       01  REPORT-WORK-AREA.                                                    
           05  STAGED-REPORT-LINE.                                              
               10  STAGED-REPORT-CC          PIC X.                             
               10  FILLER                    PIC X(132).                        
           05  REPORT-LINE.                                                     
               10  REPORT-CC                 PIC X.                             
               10  FILLER                    PIC X(132).                        
                                                                                
      *    *-----------------------------------------------------------         
      *    * GOOD NEWS                                                          
      *    *-----------------------------------------------------------         
       01  STANDARD-MESSAGES.                                                   
           05  HEAD1.                                                           
               10  HEAD1-CC             PIC X      VALUE '1'.                   
FXXTOK         10  FILLER               PIC X(8)   VALUE 'GC2PRM'.              
               10  FILLER               PIC X(29)  VALUE SPACES.                
               10  FILLER               PIC X(56)  VALUE                        
             'FOR GROUPS GOING IN FORCE, DIFFERENCES GREATER THAN $500'.        
               10  FILLER               PIC X(30)  VALUE SPACES.                
               10  REPORT-DATE.                                                 
                   15  REPORT-DATE-DD   PIC 99.                                 
                   15  REPORT-DATE-MMM  PIC XXX.                                
                   15  REPORT-DATE-Y4   PIC 9999.                               
           05  HEAD2.                                                           
               10  HEAD2-CC             PIC X      VALUE SPACES.                
               10  FILLER               PIC X(40)  VALUE SPACES.                
               10  FILLER               PIC X(50)  VALUE                        
                   'BETWEEN PRE-RELEASE PREMIUM AND FIRST BILL PREMIUM'.        
               10  FILLER               PIC X(33)  VALUE SPACES.                
               10  FILLER               PIC X(5)   VALUE 'PAGE'.                
               10  HEAD2-PAGE-CNT       PIC ZZZ9.                               
           05  HEAD3.                                                           
               10  HEAD3-CC             PIC X      VALUE '0'.                   
REN            10  FILLER               PIC X(44)  VALUE SPACES.                
               10  FILLER               PIC X(19)  VALUE 'PRE-RELEASE'.         
               10  FILLER               PIC X(30)  VALUE '1ST BILL'.            
               10  FILLER               PIC X(07)  VALUE 'PAY'.                 
               10  FILLER               PIC X(10)  VALUE 'LTD PAY'.             
REN            10  FILLER               PIC X(22)  VALUE 'PRODUCER'.            
           05  HEAD4.                                                           
               10  HEAD4-CC             PIC X      VALUE SPACES.                
               10  FILLER               PIC X(17)  VALUE SPACES.                
REN            10  FILLER               PIC X(09)  VALUE 'GFO'.                 
               10  FILLER               PIC X(08)  VALUE 'GROUP'.               
               10  FILLER               PIC X(12)  VALUE 'ACCT'.                
               10  FILLER               PIC X(17)  VALUE 'PREMIUM'.             
               10  FILLER               PIC X(15)  VALUE 'PREMIUM'.             
               10  FILLER               PIC X(14)  VALUE 'DIFFERENCE'.          
               10  FILLER               PIC X(09)  VALUE 'SCALE'.               
               10  FILLER               PIC X(10)  VALUE 'SCALE'.               
REN            10  FILLER               PIC X(21)  VALUE 'NUMBER'.              
           05  DETAIL-LINE.                                                     
               10  FILLER               PIC X      VALUE SPACES.                
               10  FILLER               PIC X(16)  VALUE SPACES.                
               10  DETAIL-GFO           PIC X(05).                              
               10  FILLER               PIC X(03)  VALUE SPACES.                
REN            10  DETAIL-GROUP         PIC X(07).                              
               10  FILLER               PIC X(03)  VALUE SPACES.                
               10  DETAIL-ACCT          PIC X(03).                              
               10  FILLER               PIC X(03)  VALUE SPACES.                
               10  DETAIL-PRE-REL       PIC ZZZ,ZZZ,ZZ9.99-.                    
               10  FILLER               PIC X(02)  VALUE SPACES.                
               10  DETAIL-CURRENT       PIC ZZZ,ZZZ,ZZ9.99-.                    
               10  FILLER               PIC X(02)  VALUE SPACES.                
               10  DETAIL-DIFFERENCE    PIC ZZZ,ZZZ,ZZ9.99-.                    
               10  FILLER               PIC X(04)  VALUE SPACES.                
               10  DETAIL-SCALE         PIC X(03).                              
               10  FILLER               PIC X(06)  VALUE SPACES.                
               10  DETAIL-SCALE-LTD     PIC X(03).                              
               10  FILLER               PIC X(06)  VALUE SPACES.                
               10  DETAIL-PRODUCER      PIC X(06).                              
REN            10  FILLER               PIC X(15)  VALUE SPACES.                
           05  TOTAL1.                                                          
               10  TOTAL1-CC            PIC X      VALUE '-'.                   
REN            10  FILLER               PIC X(40)  VALUE                        
                   'NET DIFFERENCES OF +/- $500'.                               
               10  TOTAL1-PRE-REL       PIC ZZZ,ZZZ,ZZ9.99-.                    
               10  FILLER               PIC X(02)  VALUE SPACES.                
               10  TOTAL1-CURRENT       PIC ZZZ,ZZZ,ZZ9.99-.                    
               10  FILLER               PIC X(02)  VALUE SPACES.                
               10  TOTAL1-DIFFERENCE    PIC ZZZ,ZZZ,ZZ9.99-.                    
REN            10  FILLER               PIC X(44)  VALUE SPACES.                
           05  TOTAL2.                                                          
               10  TOTAL2-CC            PIC X      VALUE '0'.                   
REN            10  FILLER               PIC X(40)  VALUE                        
                   'NET OF ALL DIFFERENCES'.                                    
               10  TOTAL2-PRE-REL       PIC ZZZ,ZZZ,ZZ9.99-.                    
               10  FILLER               PIC X(02)  VALUE SPACES.                
               10  TOTAL2-CURRENT       PIC ZZZ,ZZZ,ZZ9.99-.                    
               10  FILLER               PIC X(02)  VALUE SPACES.                
               10  TOTAL2-DIFFERENCE    PIC ZZZ,ZZZ,ZZ9.99-.                    
REN            10  FILLER               PIC X(44)  VALUE SPACES.                
                                                                                
      *    *-----------------------------------------------------------         
      *    * BAD NEWS                                                           
      *    *-----------------------------------------------------------         
       01  WARNING-MSG-TABLE.                                                   
           05  WARNING-MSG-VALUES.                                              
               10  FILLER              PIC X(133)  VALUE                        
FXXTOK         ' GC2PRM - WARNING - (UNUSED)'.                                  
           05  WARNING-MSGS  REDEFINES  WARNING-MSG-VALUES.                     
               10  WARNING-MSG         PIC X(133)  OCCURS 1.                    
                                                                                
       01  ERROR-MSG-TABLE.                                                     
           05  ERROR-MSG-VALUES.                                                
               10  FILLER              PIC X(133)  VALUE                        
               '-GWCOCPRM ** ERROR ** READING IFPRMEXT INPUT FILE'.             
           05  ERROR-MSGS  REDEFINES  ERROR-MSG-VALUES.                         
               10  ERROR-MSG           PIC X(133)  OCCURS 1.                    
                                                                                
      /                                                                         
      *****************************************************************         
      *****************************************************************         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
           05  ZCURRDAT                     PIC X(8)  VALUE 'ZCURRDAT'.         
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2PRM'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
      *****************************************************************         
      *****************************************************************         
                                                                                
       0000-MAINLINE.                                                           
      *================================================================         
      * MAINLINE                                                                
      *================================================================         
      *    *-----------------------------------------------------------         
      *    * SET UP                                                             
      *    *-----------------------------------------------------------         
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2PRM' TO PROGRAM-NAME.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   READY GW-COMP-AREA1   USAGE-MODE RETRIEVAL.                          
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2   USAGE-MODE RETRIEVAL.                          
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           CALL   ZCURRDAT   USING  RUN-DATE.                                   
MAN02      CALL  QDATEQ2  USING  QDATE-BD                                       
MAN02                            RUN-DATE                                       
MAN02                            REPORT-DATE.                                   
                                                                                
      *    *-----------------------------------------------------------         
      *    * READ FIRST RECORD                                                  
      *    *-----------------------------------------------------------         
           PERFORM  7000-READ-IFPRMEXT   THRU  7000-EXIT.                       
           IF ABORT                                                             
               PERFORM  9150-ERRORS      THRU  9150-EXIT                        
               GO TO    0000-CLOSE.                                             
           IF IFPRMEXT-EOF                                                      
               MOVE  '-........ NOTHING TO REPORT .........'                    
                                              TO    STAGED-REPORT-LINE          
               PERFORM  9110-WRITE            THRU  9110-EXIT.                  
                                                                                
      *    *-----------------------------------------------------------         
      *    * LOOP TILL YOU DROOP                                                
      *    *-----------------------------------------------------------         
           PERFORM 2000-PROCESS THRU 2000-EXIT                                  
                   UNTIL IFPRMEXT-EOF.                                          
                                                                                
       0000-CLEANUP.                                                            
      *================================================================         
      * DROP THE LANDING GEAR WE'RE COMIN' IN                                   
      *================================================================         
           COMPUTE  TEMP  =  LINE-LIMIT  -  6.                                  
           IF  LINE-CNT  >  TEMP                                                
               PERFORM  9120-NEWPAGE      THRU  9120-EXIT.                      
           MOVE  GE500-PRE-REL            TO    TOTAL1-PRE-REL.                 
           MOVE  GE500-CURRENT            TO    TOTAL1-CURRENT.                 
           MOVE  GE500-DIFFERENCE         TO    TOTAL1-DIFFERENCE.              
           MOVE  TOTAL1                   TO    STAGED-REPORT-LINE.             
           PERFORM  9110-WRITE            THRU  9110-EXIT.                      
      *    MOVE  TOTAL-PRE-REL            TO    TOTAL2-PRE-REL.                 
      *    MOVE  TOTAL-CURRENT            TO    TOTAL2-CURRENT.                 
      *    MOVE  TOTAL-DIFFERENCE         TO    TOTAL2-DIFFERENCE.              
      *    MOVE  TOTAL2                   TO    STAGED-REPORT-LINE.             
      *    PERFORM  9110-WRITE            THRU  9110-EXIT.                      
           MOVE  '-END OF REPORT'         TO    REPORT-LINE.                    
           PERFORM  9130-PRINT            THRU  9130-EXIT.                      
                                                                                
       0000-CLOSE.                                                              
      *    *-----------------------------------------------------------         
      *    * CLOSE UP SHOP                                                      
      *    *-----------------------------------------------------------         
           MOVE  +4                       TO    SYS010-RET-CODE.                
           PERFORM  7000-READ-IFPRMEXT    THRU  7000-EXIT.                      
           MOVE  +4                       TO    SYS020-RET-CODE.                
           PERFORM  9130-PRINT            THRU  9130-EXIT.                      
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
                                                                                
       2000-PROCESS.                                                            
      *================================================================         
      * HERE BE THE FUN PART,...                                                
      *================================================================         
           MOVE SPACE  TO  NOT-ON-COMM-SW.                                      
      *    *-----------------------------------------------------------         
      *    * FIRST, READ GWCORGRACCT RECORD                                     
      *    *-----------------------------------------------------------         
           MOVE IFPRMEXT-GROUP   TO   GROUP-NUMBER OF GWCORGRACCT.              
           MOVE IFPRMEXT-ACCT    TO   GR-ACCOUNT   OF GWCORGRACCT.              
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 MOVE  'Y'    TO  NOT-ON-COMM-SW                                
                 MOVE  ZERO   TO  COMM-PREM-ACCUM                               
                 GO TO 2000-READ-ALL-GWCORCOMP.                                 
                                                                                
      *    *-----------------------------------------------------------         
      *    * LOOP THRU GWCORCOMPS TO RUN UP A TOTAL PREMIUM FIGURE              
      *    *-----------------------------------------------------------         
           MOVE  ZERO  TO   COMM-PREM-ACCUM.                                    
                                                                                
      *%   OBTAIN FIRST WITHIN GRACCT-COMP                                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 GO TO 2000-READ-ALL-GWCORCOMP.                                 
                                                                                
           MOVE AGENT-NUMBER TO SAVE-AGENT.                                     
           GO TO 2000-PROCESS-GWCORCOMP.                                        
                                                                                
       2000-NEXT-GWCORCOMP.                                                     
      *    *-----------------------------------------------------------         
      *    * GRAB ANOTHER COMP                                                  
      *    *-----------------------------------------------------------         
      *%   OBTAIN NEXT WITHIN GRACCT-COMP                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 GO TO 2000-READ-ALL-GWCORCOMP.                                 
                                                                                
       2000-PROCESS-GWCORCOMP.                                                  
      *    *-----------------------------------------------------------         
      *    * PRE-RELEASE?                                                       
      *    *-----------------------------------------------------------         
           IF PREM-SOURCE OF GWCORCOMP NOT = 'PR'                               
               GO TO 2000-NEXT-GWCORCOMP.                                       
                                                                                
      *    *----------------------------------------------------------*         
      *    * IGNORE NAPS & SCR ENTIRELY                                         
      *    *----------------------------------------------------------*         
           IF COMP-TYPE OF GWCORCOMP NOT = 'C'                                  
               GO TO 2000-NEXT-GWCORCOMP.                                       
                                                                                
      *    *-----------------------------------------------------------         
      *    * PREMIUM FIGURES WILL BE REPEATED ON THE DATABASE IF MORE           
      *    * THAN ONE AGENT, SO STICK WITH THE FIRST ONE ENCOUNTERED            
      *    *-----------------------------------------------------------         
           IF AGENT-NUMBER NOT = SAVE-AGENT                                     
               GO TO 2000-NEXT-GWCORCOMP.                                       
                                                                                
      *    *-----------------------------------------------------------         
      *    * O.K., SCHLUCK IT IN THE HOPPER                                     
      *    *-----------------------------------------------------------         
           ADD  PREM-AMT OF GWCORCOMP  TO  COMM-PREM-ACCUM.                     
                                                                                
           GO TO 2000-NEXT-GWCORCOMP.                                           
                                                                                
       2000-READ-ALL-GWCORCOMP.                                                 
      *    *-----------------------------------------------------------         
      *    * COMMISSION DATABASE FIGURES ARE ANNUALIZED--ADJUST DOWN            
      *    *-----------------------------------------------------------         
           COMPUTE  COMM-PREM-ACCUM  =  COMM-PREM-ACCUM / 12.                   
                                                                                
      *    *-----------------------------------------------------------         
      *    * CALCULATE DIFFERENCE                                               
      *    *-----------------------------------------------------------         
           COMPUTE   DIFFERENCE-CALC =                                          
                              IFPRMEXT-GPSY-PREM  -  COMM-PREM-ACCUM.           
                                                                                
      *    *-----------------------------------------------------------         
      *    * KEEP RUNNING TAB ON ALL DIFFERENCES                                
      *    *-----------------------------------------------------------         
           ADD  COMM-PREM-ACCUM           TO    TOTAL-PRE-REL.                  
           ADD  IFPRMEXT-GPSY-PREM        TO    TOTAL-CURRENT.                  
           ADD  DIFFERENCE-CALC           TO    TOTAL-DIFFERENCE.               
                                                                                
      *    *-----------------------------------------------------------         
      *    * IGNORE NO PRE-RELEASE OR IF DIFFERENCE LT $500                     
      *    *-----------------------------------------------------------         
           IF NOT-ON-COMM-SW = SPACE                                            
               IF COMM-PREM-ACCUM  = ZERO  OR                                   
                  (DIFFERENCE-CALC > -500  AND  DIFFERENCE-CALC < +500)         
                   GO TO 2000-SKIP.                                             
                                                                                
      *    *-----------------------------------------------------------         
      *    * SPILL A REPORT LINE                                                
      *    *-----------------------------------------------------------         
           MOVE  IFPRMEXT-GFO             TO  DETAIL-GFO.                       
           MOVE  IFPRMEXT-GROUP           TO  DETAIL-GROUP.                     
           MOVE  IFPRMEXT-ACCT            TO  DETAIL-ACCT.                      
           MOVE  COMM-PREM-ACCUM          TO  DETAIL-PRE-REL.                   
           MOVE  IFPRMEXT-GPSY-PREM       TO  DETAIL-CURRENT.                   
           MOVE  DIFFERENCE-CALC          TO  DETAIL-DIFFERENCE.                
           MOVE  IFPRMEXT-SCALE           TO  DETAIL-SCALE.                     
           MOVE  IFPRMEXT-SCALE-LTD       TO  DETAIL-SCALE-LTD.                 
           MOVE  IFPRMEXT-PRODUCER        TO  DETAIL-PRODUCER.                  
                                                                                
           MOVE     DETAIL-LINE           TO    STAGED-REPORT-LINE.             
           PERFORM  9110-WRITE            THRU  9110-EXIT.                      
                                                                                
      *    *-----------------------------------------------------------         
      *    * KEEP RUNNING TAB FOR +/- 500 DIFFERENCES                           
      *    *-----------------------------------------------------------         
           ADD  COMM-PREM-ACCUM           TO    GE500-PRE-REL.                  
           ADD  IFPRMEXT-GPSY-PREM        TO    GE500-CURRENT.                  
           ADD  DIFFERENCE-CALC           TO    GE500-DIFFERENCE.               
                                                                                
       2000-SKIP.                                                               
      *    *-----------------------------------------------------------         
      *    * READ ANOTHER EXTRACT RECORD                                        
      *    *-----------------------------------------------------------         
           PERFORM  7000-READ-IFPRMEXT   THRU  7000-EXIT.                       
           IF ABORT                                                             
               PERFORM  9150-ERRORS      THRU  9150-EXIT                        
               GO TO    0000-CLOSE.                                             
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      /                                                                         
       7000-READ-IFPRMEXT.                                                      
      *================================================================         
      * READ A RECORD FROM THE IFPRMEXT FILE                                    
      *================================================================         
           CALL  'DLSREAD'   USING  SYS010-SYS010                               
                                    SYS010-RET-CODE                             
                                    IFPRMEXT-RECORD                             
                                    SYS010-REC-SIZE                             
                                    SYS010-BLOCK-SIZE                           
                                    SYS010-REC-FORMAT                           
                                    SYS010-REC-COUNT.                           
           IF  SYS010-RET-CODE  >  +4                                           
               MOVE  +100  TO  ERROR-SW.                                        
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      /                                                                         
       9110-WRITE.                                                              
      *================================================================         
      * WRITE A LINE FROM STAGED-REPORT-LINE                                    
      *================================================================         
           IF  LINE-CNT > LINE-LIMIT                                            
               PERFORM  9120-NEWPAGE  THRU  9120-EXIT.                          
           MOVE  STAGED-REPORT-LINE   TO    REPORT-LINE.                        
           PERFORM  9130-PRINT        THRU  9130-EXIT.                          
       9110-EXIT.                                                               
           EXIT.                                                                
                                                                                
       9120-NEWPAGE.                                                            
      *================================================================         
      * CUT DOWN ANOTHER TREE                                                   
      *================================================================         
           MOVE  HEAD1                  TO    REPORT-LINE.                      
           PERFORM  9130-PRINT          THRU  9130-EXIT.                        
           ADD  +1                      TO    PAGE-CNT.                         
           MOVE  PAGE-CNT               TO    HEAD2-PAGE-CNT.                   
           MOVE  HEAD2                  TO    REPORT-LINE.                      
           PERFORM  9130-PRINT          THRU  9130-EXIT.                        
           MOVE  HEAD3                  TO    REPORT-LINE.                      
           PERFORM  9130-PRINT          THRU  9130-EXIT.                        
           MOVE  HEAD4                  TO    REPORT-LINE.                      
           PERFORM  9130-PRINT          THRU  9130-EXIT.                        
           MOVE  '0'                    TO    STAGED-REPORT-CC.                 
       9120-EXIT.                                                               
           EXIT.                                                                
                                                                                
       9130-PRINT.                                                              
      *================================================================         
      * CALL DLSWRITE TO PUSH A REAL PRINTER LINE                               
      *================================================================         
           CALL  'DLSWRITE'  USING  SYS020-SYS020                               
                                    SYS020-RET-CODE                             
                                    REPORT-LINE                                 
                                    SYS020-REC-SIZE                             
                                    SYS020-BLOCK-SIZE                           
                                    SYS020-REC-FORMAT                           
                                    SYS020-REC-COUNT.                           
           IF REPORT-CC = SPACES                                                
               ADD +1 TO LINE-CNT                                               
           ELSE                                                                 
                IF REPORT-CC = '0'                                              
                    ADD +2 TO LINE-CNT                                          
                ELSE                                                            
                     IF REPORT-CC = '-'                                         
                         ADD +3 TO LINE-CNT                                     
                     ELSE                                                       
                          IF REPORT-CC = '1'                                    
                              MOVE +1 TO LINE-CNT.                              
       9130-EXIT.                                                               
           EXIT.                                                                
     /                                                                          
       9140-WARNINGS.                                                           
      *================================================================         
      * COMPLAIN BUT STRUGGLE ON                                                
      *================================================================         
           MOVE  WARNING-MSG (ERROR-SW)      TO    STAGED-REPORT-LINE.          
           PERFORM  9110-WRITE               THRU  9110-EXIT.                   
           MOVE  +0                          TO    ERROR-SW.                    
           MOVE  +4                          TO    RETURN-CODE.                 
       9140-EXIT.                                                               
           EXIT.                                                                
                                                                                
       9150-ERRORS.                                                             
      *================================================================         
      * PUBLISH THE BAD NEWS                                                    
      *================================================================         
           COMPUTE  TEMP  =  ERROR-SW  /  +100.                                 
           MOVE  ERROR-MSG (TEMP)            TO    STAGED-REPORT-LINE.          
           PERFORM  9110-WRITE               THRU  9110-EXIT.                   
           MOVE  +12                         TO    RETURN-CODE.                 
       9150-EXIT.                                                               
           EXIT.                                                                
                                                                                
      /                                                                         
      *%   COPY IDMS IDMS-STATUS.                                               
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
