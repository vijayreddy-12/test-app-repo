       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.  GC2PURGE.                                                   
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *===============================================================*         
      * COMMISSION DATABASE PURGE PROCESSING - PURGE PROGRAM          *         
      *      THIS PROGRAM PURGES THE GROUPS AS SELECTED BY "COPRGSEL" *         
      * AND BACKED UP BY "COPRGBKP".                                  *         
      *---------------------------------------------------------------*         
      * DDNAME      DESCRIPTION                                       *         
      *  DLSI19   - GROUP NUMBER FILE INDICATING GROUPS TO PURGE      *         
      *  SYSPRINT - LOGGING FILE FOR PROGRAM                          *         
      *---------------------------------------------------------------*         
      * DATE      USERID   DESCRIPTION                                *         
      * ..FEB1995 BORSIJO  .PROGRAM CREATED FROM RNPURGE              *         
      * ..FEB2003 BEAUBIB  .CONVERT TO COBOL 2                        *         
      * ..FEB2003 BEAUBIB  .BRING UP TO CURRENT STANDARD - GAEDATSR   *         
      * ..JAN2006 MELANBR  .ISSUE COMMIT AFTER ERASE                  *         
      * ..OCT2008 IBM      .COMPILER UPGRADE.                                   
      *****************************************************************         
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES COPURGE           
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS.                                      
      *IDMS-RECORDS MANUAL.                                                     
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS.                                                           
           05  FILLER                PIC X(32)        VALUE                     
FXXTOK         '** GC2PURGE  W-S STARTS HERE **'.                               
                                                                                
       01  DYNAMIC-PROGRAMS.                                                    
           05  GAEDATSR                PIC X(8)       VALUE 'GAEDATSR'.         
           05  GWCDUMP                 PIC X(8)       VALUE 'GWCDUMP'.          
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
                                                                                
      *---------------------------------------------------------------*         
      * WORKING STORAGE ITEMS AND LITERALS                            *         
      *---------------------------------------------------------------*         
       01  DYNAMIC-STORAGE.                                                     
           03  WS-DUMP-2               PIC X(1)  VALUE '2'.                     
           03  WS-VERB                 PIC X(16) VALUE SPACES.                  
                                                                                
      *---------------------------------------------------------------*         
      * DLSI10 - CONTROL CARD INPUT FILE                              *         
      *---------------------------------------------------------------*         
       01  INPUT-RECORD.                                                        
           05  INPUT-PROGRAM-NAME      PIC X(8).                                
           05  FILLER                  PIC X(1).                                
           05  INPUT-GROUP-7           PIC 9(7).                                
           05  FILLER                  PIC X(64).                               
                                                                                
      *---------------------------------------------------------------*         
      *          DATASERVER RECORDS                                   *         
      *---------------------------------------------------------------*         
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
      *---------------------------------------------------------------*         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *---------------------------------------------------------------*         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      *---------------------------------------------------------------*         
      * COMMISSIONS DATABASE RECORDS                                  *         
      *---------------------------------------------------------------*         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGROUP                      '.                                  
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2PURGE'         TO FCCSPL-CURR-PGM.                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
      *---------------------------------------------------------------*         
      * INITIALIZE:  INITIATE IDMS ENVIRONMENT                        *         
      *              GET FIRST CONTROL CARD                           *         
      *---------------------------------------------------------------*         
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2PURGE' TO PROGRAM-NAME.                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   READY  GW-COMP-AREA1  USAGE-MODE IS UPDATE.                          
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY  GW-COMP-AREA2  USAGE-MODE IS UPDATE.                          
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY  GW-COMP-AREA3  USAGE-MODE IS UPDATE.                          
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           MOVE LOW-VALUES                TO LINKAGE-CONTROL.                   
FXXTOK     MOVE 'GC2PURGE'                 TO ICBM-PROGRAM-NAME.                
           MOVE OBTAIN-FIRST TO WS-VERB.                                        
                                                                                
           PERFORM 900-READ-INPUT                                               
              THRU 900-READ-INPUT-EXIT.                                         
                                                                                
      *---------------------------------------------------------------*         
      *  PROCESS ALL CONTROL CARDS                                              
      *---------------------------------------------------------------*         
           MOVE OBTAIN-NEXT TO WS-VERB.                                         
           PERFORM 200-PURGE-RECORDS                                            
              THRU 200-PURGE-RECORDS-EXIT                                       
               UNTIL NOT LR-STATUS-OK.                                          
                                                                                
      *---------------------------------------------------------------*         
      * TERMINATION:  CLOSE ALL FILES                                 *         
      *---------------------------------------------------------------*         
           CALL GAEDATSR    USING FINISH-LR                                     
                                  INPUT-RECORD                                  
                                  ICBM.                                         
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
                                                                                
      *---------------------------------------------------------------*         
      * MAIN-LINE:   PURGE REQUESTED GROUP                            *         
      *             -OBTAIN REQUESTED GROUP                           *         
      *             -IF GROUP PRESENT, PURGE                          *         
      *             -OBTAIN NEXT REQUEST CARD                         *         
      *---------------------------------------------------------------*         
       200-PURGE-RECORDS.                                                       
REN        MOVE INPUT-GROUP-7       TO GROUP-NUMBER OF GWCORGROUP.              
                                                                                
      *%   OBTAIN CALC GWCORGROUP                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT ANY-ERROR-STATUS                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               DISPLAY 'OBTAIN CALC OF GWCORGROUP '                             
                       GROUP-NUMBER OF GWCORGROUP                               
                       ' NOT SUCCESSFUL (' ERROR-STATUS ')'.                    
                                                                                
           IF DB-STATUS-OK                                                      
               PERFORM 500-PURGE-GROUP                                          
                  THRU 500-PURGE-GROUP-EXIT.                                    
                                                                                
           PERFORM 900-READ-INPUT                                               
              THRU 900-READ-INPUT-EXIT.                                         
                                                                                
       200-PURGE-RECORDS-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
      * SUBROUTINE:  PURGE THE GROUP AS REQUESTED                     *         
      *             -DISPLAY RESULTS OF PURGE REQUEST                 *         
      *---------------------------------------------------------------*         
       500-PURGE-GROUP.                                                         
                                                                                
      *%   ERASE GWCORGROUP ALL MEMBERS.                                        
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +5  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-DELETE-CASCADE                                     
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 FCCSPL-CASCADE                                            
MAN02                 GWCORGROUP                                                
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           IF ANY-ERROR-STATUS                                                  
               PERFORM 800-PURGE-ERROR                                          
                  THRU 800-PURGE-ERROR-EXIT.                                    
                                                                                
      *%   COMMIT                                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-COMMIT                                             
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT                                          
           DISPLAY 'GROUP ' INPUT-GROUP-7 ' SUCCESSFULLY '                      
                   'PURGED (COMMITED)'.                                         
       500-PURGE-GROUP-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
      * SUBROUTINE:  REPORT INFORMATION ABOUT PURGE ERROR             *         
      *             -DISPLAY CURRENT INFORMATION                      *         
      *             -INVOKE IDMS-STATUS-CHECKING                      *         
      *             -TERMINATE EXECUTION WITH A DUMP                  *         
      *---------------------------------------------------------------*         
       800-PURGE-ERROR.                                                         
           DISPLAY '** PURGE ERROR ON GROUP ' GWCORGROUP ' **'.                 
           DISPLAY '   IDMS ERROR STATUS = ' ERROR-STATUS.                      
      *%   PERFORM IDMS-STATUS.                                                 
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           CALL GWCDUMP USING ICBM                                              
                              GWRDUMP.                                          
                                                                                
       800-PURGE-ERROR-EXIT.                                                    
           EXIT.                                                                
      *---------------------------------------------------------------*         
      * SUBROUTINE:  READ PURGE REQUEST CARD INPUT FILE               *         
      *---------------------------------------------------------------*         
       900-READ-INPUT.                                                          
           INITIALIZE INPUT-RECORD.                                             
           MOVE 'CARD-DATA-010'      TO LOGICAL-RECORD-NAME.                    
                                                                                
           CALL GAEDATSR          USING  WS-VERB                                
                                         INPUT-RECORD                           
                                         ICBM.                                  
                                                                                
            IF NOT LR-STATUS-OK AND NOT LR-NOT-FOUND                            
      *     IF NOT LR-STATUS-OK                                                 
               DISPLAY '*** ERROR READING INPUT: ' ICBM                         
            ELSE                                                                
               DISPLAY 'NOW PROCESSING: ' INPUT-RECORD                          
            END-IF.                                                             
                                                                                
       900-READ-INPUT-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *%   COPY IDMS IDMS-STATUS.                                               
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
