       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2TRN.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
      *    THIS PROGRAM EXTRACTS THE GWCORTRANS RECORDS AND SPLITS              
      *    THEM INTO A COMMISSION RELEASE FILE AND A PRINT FILE.                
      *    THE COMMISSION RELEASE FILE IS THEN SENT TO AGENCY AND               
      *    THE PRINT FILE IS RUN THROUGH GPRINTAL FOR PRINTING.                 
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INPUT:     GWCORTRANS                                        *         
      *                                                               *         
      *  OUTPUT:    COMMISSION RELEASE FILE                           *         
      *             PRINT FILE (GPRINTAL)                             *         
      *                                                               *         
      *  FREQUENCY: DAILY                                             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  HISTORY : JUN90 - A SCHLEICHER - RECOMPLIED - CHANGE TO      *         
      *                                                GWCORTRANS     *         
      *            SEP90 - A NIKELSKI   - EXCLUDED WRITTING OUT NAP   *         
      *                                   RECORDS WITH A              *         
      *                                   COMP-TYPE = 'S' (SYS020)    *         
      *                                   WHICH IS USED BY GPRNAPPR   *         
      *            DEC90 - A NIKELSKI   - CHANGE TO READ OF DATABASE  *         
      *                                                               *         
      *            OCT08 - IBM            COMPILER UPGRADE.                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCTRN          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO02 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  LCP-YYYYMMDD-TIME.                                                   
           05  LCP-YYYYMMDD.                                                    
               10  LCP-CENTURY           PIC X(2).                              
               10  LCP-YY                PIC X(2).                              
               10  LCP-MM                PIC 9(2).                              
               10  LCP-DD                PIC X(2).                              
           05  LCP-TIME.                                                        
               10  LCP-HHMMSS.                                                  
                   15  LCP-HH            PIC X(2).                              
                   15  LCP-MN            PIC X(2).                              
                   15  LCP-SS            PIC X(2).                              
               10  LCP-HS                PIC X(2).                              
           05  LCP-GMT                   PIC X(5).                              
       01  LCP-MMDDYY-08.                                                       
           05  LCP-MM                    PIC 9(2).                              
           05  FILLER                    PIC X VALUE '/'.                       
           05  LCP-DD                    PIC X(2).                              
           05  FILLER                    PIC X VALUE '/'.                       
           05  LCP-YY                    PIC X(2).                              
       01  WS-BEGINS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2TRN W-S STARTS HERE **'.                                  
       01  WS-PARAMETERS.                                                       
           05  QDATE-FORMATB           PIC XX            VALUE 'BA'.            
           05  WS-END-OF-PROCESSING    PIC X             VALUE 'N'.             
           05  WS-VALID-COMP-TYPE      PIC X             VALUE 'N'.             
           05  WS-FOUND-GROUP          PIC X             VALUE 'N'.             
           05  WS-NAPS-PROCESSED       PIC S9(5)         VALUE ZERO.            
           05  WS-CR-PROCESSED         PIC S9(5)         VALUE ZERO.            
           05  WS-AUDITS-PROCESSED     PIC S9(5)         VALUE ZERO.            
           05  WS-TRANS-NOT-PROCESSED  PIC S9(5)         VALUE ZERO.            
           05  WS-TEMP-AMT             PIC 9(9)V99-      VALUE ZERO.            
           05  WS-ACCUM-AMT COMP-3     PIC S9(9)V99      VALUE ZERO.            
           05  WS-GROUP-REP            PIC 9(5)          VALUE ZERO.            
           05  WS-CURR-DATE.                                                    
               10  WS-CURR-MONTH    PIC 99.                                     
               10  FILLER           PIC X.                                      
               10  WS-CURR-DAY      PIC 99.                                     
               10  FILLER           PIC X.                                      
               10  WS-CURR-YEAR     PIC 99.                                     
           05  WS-RUN-DATE.                                                     
               10  WS-RUN-DAY       PIC 99.                                     
               10  WS-RUN-MONTH     PIC 99.                                     
               10  WS-RUN-YEAR      PIC 99.                                     
           05  ALIS-CURR-DATE.                                                  
               10  ALIS-CURR-YEAR   PIC S9(3) COMP-3.                           
               10  ALIS-CURR-DAY    PIC S9(3) COMP-3.                           
           05  CURR-EFF-DATE.                                                   
               10  CURR-EFF-YEAR    PIC S9(3) COMP-3.                           
               10  CURR-EFF-DAY     PIC S9(3) COMP-3.                           
           05  PREV-EFF-DATE.                                                   
               10  PREV-EFF-YEAR    PIC S9(3) COMP-3.                           
               10  PREV-EFF-DAY     PIC S9(3) COMP-3.                           
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'WS-AUDIT-RECORD                 '.                                  
                                                                                
       01  WS-AUDIT-RECORD.                                                     
           05  WS-AUDIT-HEADER      PIC X(48).                                  
           05  WS-AUDIT-DETAIL1     PIC X(100).                                 
           05  WS-AUDIT-DETAIL2     PIC X(100).                                 
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'DATE-RECORD-OUT                 '.                                  
                                                                                
       01  DATE-RECORD-OUT.                                                     
           05  DATE-RECORD-LENGTH   PIC S9(4) COMP    VALUE +100.               
           05  FILLER               PIC X(7)          VALUE LOW-VALUES.         
           05  DATE-OUT             PIC X(4).                                   
           05  FILLER               PIC X(87)         VALUE LOW-VALUES.         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'COMMISSION-RELEASE-RECORD-IN    '.                                  
                                                                                
       01  COMMISSION-RELEASE-RECORD-IN.                                        
           05  CR-HEADER-IN.                                                    
               10  CR-LENGTH-IN     PIC S9(4) COMP.                             
               10  FILLER           PIC XX.                                     
REN        05  FILLER               PIC X(12).                                  
           05  CR-DATA-IN           PIC X(300).                                 
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'COMMISSION-RELEASE-RECORD-OUT   '.                                  
                                                                                
       01  COMMISSION-RELEASE-RECORD-OUT.                                       
           05  CR-HEADER-OUT.                                                   
               10  CR-LENGTH-OUT    PIC S9(4) COMP    VALUE +316.               
               10  FILLER           PIC XX.                                     
           05  CR-DATA-OUT          PIC X(300).                                 
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'PRINT-RECORD-OUT                '.                                  
                                                                                
       01  PRINT-RECORD-OUT.                                                    
           05  FILLER               PIC S9(4) COMP    VALUE +348.               
           05  FILLER               PIC XX.                                     
           05  FILLER               PIC X(344).                                 
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'REPORT-OUT                      '.                                  
                                                                                
       01  REPORT-OUT.                                                          
           05  REPORT-HEADING1.                                                 
               10  FILLER              PIC X(13)      VALUE                     
FXXTOK                                              '1 GC2TRN  '.               
               10  FILLER              PIC X(30)      VALUE SPACES.             
               10  FILLER              PIC X(55)      VALUE                     
                                    'MANUFACTURERS LIFE OF CANADA'.             
               10  FILLER              PIC X(14)      VALUE                     
                                           'CURRENT DATE:'.                     
               10  REPORT-DATE         PIC X(8)       VALUE SPACES.             
               10  FILLER              PIC X(13)      VALUE SPACES.             
                                                                                
           05  REPORT-HEADING2.                                                 
               10  FILLER              PIC X(38)      VALUE SPACES.             
               10  FILLER              PIC X(58)      VALUE                     
                       'COMMISSION TRANSACTION SUMMARY REPORT  '.               
               10  FILLER              PIC X(37)      VALUE SPACES.             
                                                                                
           05  REPORT-DETAIL-LINE1.                                             
               10  FILLER              PIC X(5)      VALUE '-'.                 
               10  RPT-DETAIL1         PIC X(48).                               
               10  FILLER              PIC X(80)      VALUE SPACES.             
                                                                                
           05  REPORT-DETAIL-LINE2.                                             
               10  FILLER              PIC X(10)      VALUE '0'.                
               10  RPT-DETAIL2         PIC X(100).                              
               10  FILLER              PIC X(23)      VALUE SPACES.             
                                                                                
           05  REPORT-TOTAL-LINE.                                               
               10  FILLER              PIC X(5)      VALUE '-'.                 
               10  CTL-MESSAGE         PIC X(40).                               
               10  CTL-AMOUNT          PIC ZZZZ9.                               
               10  FILLER              PIC X(83)      VALUE SPACES.             
                                                                                
           05  WS-REPORT-LINE-OUT      PIC X(133).                              
                                                                                
      * GNAPREC                                                                 
CPYNME     COPY GNAPREC7.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'DLS-WRITE-PARMS                 '.                                  
                                                                                
       01  DLS-WRITE-PARMS.                                                     
                                                                                
      **  FILE DESCRIPTION FOR FEED TO GPRINTAL                                 
                                                                                
           05  DLS-SYS020-SYSNUM    PIC X(6)          VALUE 'SYS070'.           
           05  DLS-SYS020-RETURN    PIC S9    COMP-3  VALUE ZERO.               
           05  DLS-SYS020-REC-SIZE  PIC 9(5)          VALUE 19056.              
           05  DLS-SYS020-BLK-SIZE  PIC 9(5)          VALUE 19060.              
           05  DLS-SYS020-FORMAT    PIC XX            VALUE 'VB'.               
           05  DLS-SYS020-REC-COUNT PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
      **  FILE DESCRIPTION FOR FEED TO AGENCY                                   
                                                                                
           05  DLS-SYS021-SYSNUM    PIC X(6)          VALUE 'SYS071'.           
           05  DLS-SYS021-RETURN    PIC S9    COMP-3  VALUE ZERO.               
           05  DLS-SYS021-REC-SIZE  PIC 9(5)          VALUE 304.                
           05  DLS-SYS021-BLK-SIZE  PIC 9(5)          VALUE 23412.              
           05  DLS-SYS021-FORMAT    PIC XX            VALUE 'VB'.               
           05  DLS-SYS021-REC-COUNT PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
      **  FILE DESCRIPTION FOR COMMISSION COUNTROL REPORT                       
                                                                                
           05  DLS-SYS022-SYSNUM    PIC X(6)          VALUE 'SYS022'.           
           05  DLS-SYS022-RETURN    PIC S9    COMP-3  VALUE ZERO.               
           05  DLS-SYS022-REC-SIZE  PIC 9(5)          VALUE 133.                
           05  DLS-SYS022-BLK-SIZE  PIC 9(5)          VALUE 3990.               
           05  DLS-SYS022-FORMAT    PIC XX            VALUE 'FB'.               
           05  DLS-SYS022-REC-COUNT PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE - TRANSACTION RECORD DESCRIPTION            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORTRANS                      '.                                  
                                                                                
      * GWCORTRANS                                                              
CPYNME     COPY GCITRAN.                                                        
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGRACCT                     '.                                  
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCOMP                       '.                                  
                                                                                
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           'WORKING STORAGE ENDS HERE'.                                         
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO02'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2TRN'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       000-MAINLINE.                                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                PROGRAM MAINLINE                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           PERFORM 100-INITIALIZE THRU 199-EXIT.                                
           PERFORM 200-PROCESS-RECORDS THRU 299-EXIT                            
               UNTIL WS-END-OF-PROCESSING = 'Y'.                                
           PERFORM 300-END-OF-JOB THRU 399-EXIT.                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       100-INITIALIZE.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     CALL PROGRAM-CHECK                                        *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREA TO BE ACCESSED                             *          
      *     GET RUN DATE                                              *         
      *     GET FIRST GRACCT RECORD FROM DATA BASE                    *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *    CALL 'PROGCHEK' USING WS-PARAMETERS                                  
      *                          WS-BEGINS                                      
      *                          WS-ENDS.                                       
                                                                                
FXXTOK     MOVE 'GC2TRN' TO PROGRAM-NAME.                                       
      *%   BIND RUN-UNIT.                                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND GWCORTRANS.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGRACCT.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORCOMP.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA3 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           MOVE FUNCTION CURRENT-DATE TO LCP-YYYYMMDD-TIME                      
           MOVE CORRESPONDING LCP-YYYYMMDD TO LCP-MMDDYY-08                     
           MOVE LCP-MMDDYY-08 TO WS-CURR-DATE.                                  
           MOVE WS-CURR-DAY TO WS-RUN-DAY.                                      
           MOVE WS-CURR-MONTH TO WS-RUN-MONTH.                                  
           MOVE WS-CURR-YEAR TO WS-RUN-YEAR.                                    
MAN02      CALL QDATEQ2 USING QDATE-FORMATB                                     
MAN02                         WS-RUN-DATE                                       
MAN02                         ALIS-CURR-DATE.                                   
           MOVE ALIS-CURR-DATE TO DATE-OUT.                                     
           MOVE DATE-RECORD-OUT TO PRINT-RECORD-OUT.                            
           PERFORM 400-WRITE-PRINT-RECORD THRU 499-EXIT.                        
                                                                                
           MOVE 'N'                      TO WS-END-OF-PROCESSING.               
                                                                                
           MOVE WS-CURR-DATE TO REPORT-DATE.                                    
           MOVE REPORT-HEADING1 TO WS-REPORT-LINE-OUT.                          
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE REPORT-HEADING2 TO WS-REPORT-LINE-OUT.                          
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
      *%   OBTAIN FIRST GWCORTRANS WITHIN GW-COMP-AREA3                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORTRANS                                       
MAN02                 FCCSPL-GWCORTRANS                                         
MAN02                 FCCSPL-GW-COMP-AREA3                                      
MAN02                 GWCORTRANS                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               MOVE 'Y'           TO WS-END-OF-PROCESSING.                      
      /                                                                         
       199-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       200-PROCESS-RECORDS.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *        IF  TRANSACTION TYPE IS NAP                            *         
      *        THEN                                                   *         
      *            WRITE RECORD TO PRINT FILE                         *         
      *            ERASE RECORD FROM DATA BASE                        *         
      *        ELSE                                                   *         
      *        IF  TRANSACTION TYPE IS COMMISSION RELEASE             *         
      *        THEN                                                   *         
      *            WRITE RECORD TO PRINT FILE                         *         
      *            WRITE RECORD TO COMMISSION RELEASE FILE            *         
      *            ERASE RECORD FROM DATA BASE                        *         
      *        ELSE                                                   *         
      *            DO NOTHING                                         *         
      *        GET NEXT TRANSACTION RECORD FROM DATA BASE             *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  TRANS-TYPE = 'NP'                                                
           THEN                                                                 
               MOVE 'N'                   TO WS-VALID-COMP-TYPE                 
               MOVE TRANS-DETAILS         TO GNAPREC                            
               PERFORM 800-FIND-COMP-TYPE THRU 899-EXIT                         
      *%       FIND CURRENT GWCORTRANS                                          
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 1 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +6  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-SELECT-USING-CURR                              
MAN02                     FCCSPLIO-GWCORTRANS                                   
MAN02                     FCCSPL-GWCORTRANS                                     
MAN02                     GWCORTRANS                                            
MAN02                     FCCSPL-FIND                                           
MAN02                     FCCSPL-NOKEEP                                         
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               IF WS-VALID-COMP-TYPE = 'Y'                                      
                  MOVE TRANS-DETAILS TO PRINT-RECORD-OUT                        
                  PERFORM 400-WRITE-PRINT-RECORD THRU 499-EXIT                  
      *%          ERASE GWCORTRANS                                              
IOS               MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                   
IOS               MOVE 2 TO FCCSPL-DML-SEQ-NO                                   
IOS               MOVE +5  TO FCCSPL-ADDRESS-COUNT                              
MAN02             CALL GWFADDR                                                  
MAN02                  USING FCCSPL-ADDRESS-AREA                                
MAN02                        FCCSPL-DELETE                                      
MAN02                        FCCSPLIO-GWCORTRANS                                
MAN02                        FCCSPL-GWCORTRANS                                  
MAN02                        FCCSPL-RESTRICT                                    
MAN02                        GWCORTRANS                                         
IOS               END-CALL                                                      
FXXTOK            CALL GWFSPLB1                                                 
IOS                    USING DUMMY-PARM-1                                       
IOS                          DUMMY-PARM-2                                       
IOS                          DBLINK-SUBSCHEMA-CONTROL                           
IOS                          DBLINK-RECORD-SET-KEYS                             
IOS                          DBLINK-CURSOR-CODES                                
IOS               END-CALL                                                      
IOS               PERFORM 799-SQL-STATUS                                        
IOS                  THRU 799-SQL-STATUS-EXIT                                   
                  ADD +1 TO WS-NAPS-PROCESSED                                   
               ELSE                                                             
      *%          ERASE GWCORTRANS                                              
IOS               MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                   
IOS               MOVE 3 TO FCCSPL-DML-SEQ-NO                                   
IOS               MOVE +5  TO FCCSPL-ADDRESS-COUNT                              
MAN02             CALL GWFADDR                                                  
MAN02                  USING FCCSPL-ADDRESS-AREA                                
MAN02                        FCCSPL-DELETE                                      
MAN02                        FCCSPLIO-GWCORTRANS                                
MAN02                        FCCSPL-GWCORTRANS                                  
MAN02                        FCCSPL-RESTRICT                                    
MAN02                        GWCORTRANS                                         
IOS               END-CALL                                                      
FXXTOK            CALL GWFSPLB1                                                 
IOS                    USING DUMMY-PARM-1                                       
IOS                          DUMMY-PARM-2                                       
IOS                          DBLINK-SUBSCHEMA-CONTROL                           
IOS                          DBLINK-RECORD-SET-KEYS                             
IOS                          DBLINK-CURSOR-CODES                                
IOS               END-CALL                                                      
IOS               PERFORM 799-SQL-STATUS                                        
IOS                  THRU 799-SQL-STATUS-EXIT                                   
           ELSE                                                                 
               IF TRANS-TYPE = 'CR'                                             
               THEN                                                             
                   MOVE TRANS-DETAILS TO PRINT-RECORD-OUT                       
                   PERFORM 400-WRITE-PRINT-RECORD THRU 499-EXIT                 
                   MOVE TRANS-DETAILS TO COMMISSION-RELEASE-RECORD-IN           
                   MOVE CR-HEADER-IN TO CR-HEADER-OUT                           
                   COMPUTE CR-LENGTH-OUT = CR-LENGTH-OUT - 12                   
                   MOVE CR-DATA-IN TO CR-DATA-OUT                               
                   PERFORM 500-WRITE-AGENCY-RECORD THRU 599-EXIT                
      *%           ERASE GWCORTRANS                                             
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 4 TO FCCSPL-DML-SEQ-NO                                  
IOS                MOVE +5  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-DELETE                                     
MAN02                         FCCSPLIO-GWCORTRANS                               
MAN02                         FCCSPL-GWCORTRANS                                 
MAN02                         FCCSPL-RESTRICT                                   
MAN02                         GWCORTRANS                                        
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
                   ADD +1 TO WS-CR-PROCESSED                                    
               ELSE                                                             
                   IF TRANS-TYPE = 'A'                                          
                   THEN                                                         
                       MOVE TRANS-DETAILS TO WS-AUDIT-RECORD                    
                       PERFORM 600-WRITE-AUDIT-RECORD THRU 699-EXIT             
      *%               ERASE GWCORTRANS                                         
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 5 TO FCCSPL-DML-SEQ-NO                                  
IOS                MOVE +5  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-DELETE                                     
MAN02                         FCCSPLIO-GWCORTRANS                               
MAN02                         FCCSPL-GWCORTRANS                                 
MAN02                         FCCSPL-RESTRICT                                   
MAN02                         GWCORTRANS                                        
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT                                  
                       ADD +1 TO WS-AUDITS-PROCESSED                            
                   ELSE                                                         
                       ADD +1 TO WS-TRANS-NOT-PROCESSED.                        
                                                                                
      *%   OBTAIN NEXT GWCORTRANS WITHIN GW-COMP-AREA3                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORTRANS                                       
MAN02                 FCCSPL-GWCORTRANS                                         
MAN02                 FCCSPL-GW-COMP-AREA3                                      
MAN02                 GWCORTRANS                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               MOVE 'Y'           TO WS-END-OF-PROCESSING.                      
      /                                                                         
       299-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       300-END-OF-JOB.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   -  PRINT FILE RECORD COUNTS                                 *         
      *   -  CLOSE FILES                                              *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'NAP RECORDS PROCESSED' TO CTL-MESSAGE.                         
           MOVE WS-NAPS-PROCESSED TO CTL-AMOUNT.                                
           MOVE REPORT-TOTAL-LINE TO WS-REPORT-LINE-OUT.                        
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE 'COMMISSION RELEASE RECORDS PROCESSED' TO CTL-MESSAGE.          
           MOVE WS-CR-PROCESSED TO CTL-AMOUNT.                                  
           MOVE REPORT-TOTAL-LINE TO WS-REPORT-LINE-OUT.                        
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE 'AUDIT RECORDS PROCESSED' TO CTL-MESSAGE.                       
           MOVE WS-AUDITS-PROCESSED TO CTL-AMOUNT.                              
           MOVE REPORT-TOTAL-LINE TO WS-REPORT-LINE-OUT.                        
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE 'TRANSACTION RECORDS NOT PROCESSED' TO CTL-MESSAGE.             
           MOVE WS-TRANS-NOT-PROCESSED TO CTL-AMOUNT.                           
           MOVE REPORT-TOTAL-LINE TO WS-REPORT-LINE-OUT.                        
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE 'RECORDS ON AGENCY FILE' TO CTL-MESSAGE.                        
           MOVE DLS-SYS021-REC-COUNT TO CTL-AMOUNT.                             
           MOVE REPORT-TOTAL-LINE TO WS-REPORT-LINE-OUT.                        
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE 'RECORDS ON PRINT FILE' TO CTL-MESSAGE.                         
           MOVE DLS-SYS020-REC-COUNT TO CTL-AMOUNT.                             
           MOVE REPORT-TOTAL-LINE TO WS-REPORT-LINE-OUT.                        
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE SPACES TO WS-REPORT-LINE-OUT.                                   
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
                                                                                
           MOVE +4 TO DLS-SYS020-RETURN.                                        
           CALL 'DLSWRITE' USING DLS-SYS020-SYSNUM                              
                                 DLS-SYS020-RETURN                              
                                 PRINT-RECORD-OUT                               
                                 DLS-SYS020-REC-SIZE                            
                                 DLS-SYS020-BLK-SIZE                            
                                 DLS-SYS020-FORMAT                              
                                 DLS-SYS020-REC-COUNT.                          
           IF DLS-SYS020-RETURN EQUAL TO +4                                     
           THEN                                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'CLSE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
           MOVE +4 TO DLS-SYS021-RETURN.                                        
           CALL 'DLSWRITE' USING DLS-SYS021-SYSNUM                              
                                 DLS-SYS021-RETURN                              
                                 COMMISSION-RELEASE-RECORD-OUT                  
                                 DLS-SYS021-REC-SIZE                            
                                 DLS-SYS021-BLK-SIZE                            
                                 DLS-SYS021-FORMAT                              
                                 DLS-SYS021-REC-COUNT.                          
           IF DLS-SYS021-RETURN EQUAL TO +4                                     
           THEN                                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'CLSE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
           MOVE +4 TO DLS-SYS022-RETURN.                                        
           CALL 'DLSWRITE' USING DLS-SYS022-SYSNUM                              
                                 DLS-SYS022-RETURN                              
                                 WS-REPORT-LINE-OUT                             
                                 DLS-SYS022-REC-SIZE                            
                                 DLS-SYS022-BLK-SIZE                            
                                 DLS-SYS022-FORMAT                              
                                 DLS-SYS022-REC-COUNT.                          
           IF DLS-SYS022-RETURN EQUAL TO +4                                     
           THEN                                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'CLSE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
      /                                                                         
       399-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       400-WRITE-PRINT-RECORD.                                                  
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   -  WRITE RECORD TO PRINT FILE                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLS-SYS020-SYSNUM                              
                                 DLS-SYS020-RETURN                              
                                 PRINT-RECORD-OUT                               
                                 DLS-SYS020-REC-SIZE                            
                                 DLS-SYS020-BLK-SIZE                            
                                 DLS-SYS020-FORMAT                              
                                 DLS-SYS020-REC-COUNT.                          
           IF DLS-SYS020-RETURN EQUAL TO ZERO                                   
           THEN                                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'WRTE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
      /                                                                         
       499-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       500-WRITE-AGENCY-RECORD.                                                 
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   -  WRITE RECORD TO AGENCY FILE                              *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLS-SYS021-SYSNUM                              
                                 DLS-SYS021-RETURN                              
                                 COMMISSION-RELEASE-RECORD-OUT                  
                                 DLS-SYS021-REC-SIZE                            
                                 DLS-SYS021-BLK-SIZE                            
                                 DLS-SYS021-FORMAT                              
                                 DLS-SYS021-REC-COUNT.                          
           IF DLS-SYS021-RETURN EQUAL TO ZERO                                   
           THEN                                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'WRTE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
      /                                                                         
       599-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       600-WRITE-AUDIT-RECORD.                                                  
                                                                                
           MOVE WS-AUDIT-HEADER TO RPT-DETAIL1.                                 
           MOVE REPORT-DETAIL-LINE1 TO WS-REPORT-LINE-OUT.                      
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
           MOVE WS-AUDIT-DETAIL1 TO RPT-DETAIL2.                                
           MOVE REPORT-DETAIL-LINE2 TO WS-REPORT-LINE-OUT.                      
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
           MOVE WS-AUDIT-DETAIL2 TO RPT-DETAIL2.                                
           MOVE REPORT-DETAIL-LINE2 TO WS-REPORT-LINE-OUT.                      
           PERFORM 700-WRITE-REPORT THRU 799-EXIT.                              
      /                                                                         
       699-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       700-WRITE-REPORT.                                                        
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   -  WRITE CONTROL REPORT FOR COMMISSIONS.                    *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLS-SYS022-SYSNUM                              
                                 DLS-SYS022-RETURN                              
                                 WS-REPORT-LINE-OUT                             
                                 DLS-SYS022-REC-SIZE                            
                                 DLS-SYS022-BLK-SIZE                            
                                 DLS-SYS022-FORMAT                              
                                 DLS-SYS022-REC-COUNT.                          
           IF DLS-SYS022-RETURN EQUAL TO ZERO                                   
           THEN                                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'WRTE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
      /                                                                         
       799-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       800-FIND-COMP-TYPE.                                                      
           MOVE GNAP-GROUP          TO GROUP-NUMBER OF GWCORGRACCT.             
           MOVE GNAP-ACCOUNT        TO GR-ACCOUNT   OF GWCORGRACCT.             
                                                                                
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 13 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  DISPLAY ' !! GROUP NOT FOUND ' GNAP-GROUP ' ACCT'             
                  GNAP-ACCOUNT.                                                 
                                                                                
           MOVE 'N'                 TO WS-FOUND-GROUP.                          
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 14 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE 'Y'          TO WS-FOUND-GROUP.                          
                                                                                
           MOVE COMP-EFF-DATE OF GWCORCOMP TO PREV-EFF-DATE.                    
           MOVE +0                         TO WS-ACCUM-AMT.                     
           MOVE GNAP-GFO-REP               TO WS-GROUP-REP.                     
                                                                                
           PERFORM 900-LOOP-COMPS   THRU 999-EXIT                               
                                    UNTIL WS-FOUND-GROUP = 'Y'.                 
                                                                                
       899-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       900-LOOP-COMPS.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    IF COMP-TYPE = 'S' DON'T PUT ON NAPS REPORT                *         
      *       - TO CHECK IF COMP-TYPE = 'S' HAVE TO CHECK             *         
      *         AGENT-NUMBER, GFO-NUMBER AND COMP-AMT                 *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE COMP-EFF-DATE OF GWCORCOMP TO CURR-EFF-DATE.                    
                                                                                
      *******************************************************                   
      * IN THERE ARE MORE THAN 1 NAP BEING SENT OVER,  THEY                     
      * ARE ACCUMULATED, WHICH MEANS YOU CAN'T COMPARE THE                      
      * VALUE ON THE DATABASE                                                   
      *******************************************************                   
           IF CURR-EFF-DATE = PREV-EFF-DATE                                     
              IF AGENT-NUMBER OF GWCORCOMP   = GNAP-AGENT-CODE AND              
                 GFO-NUMBER   OF GWCORCOMP   = GNAP-GFO-OFFICE AND              
                 COMP-TYPE    OF GWCORCOMP   = 'N'             AND              
                 GROUP-REP    OF GWCORCOMP   = WS-GROUP-REP                     
                 ADD COMP-AMT     OF GWCORCOMP   TO WS-ACCUM-AMT                
              ELSE                                                              
                 NEXT SENTENCE                                                  
           ELSE                                                                 
              MOVE +0                         TO WS-ACCUM-AMT.                  
                                                                                
      *******************************************************                   
      * COMPARE IN THE CASE WHERE THERE IS ONLY 1 NAP BEING                     
      * SENT OVER                                                               
      *******************************************************                   
           IF AGENT-NUMBER OF GWCORCOMP   = GNAP-AGENT-CODE AND                 
              GFO-NUMBER   OF GWCORCOMP   = GNAP-GFO-OFFICE AND                 
              COMP-AMT     OF GWCORCOMP   = GNAP-AMOUNT                         
              IF COMP-TYPE OF GWCORCOMP = 'N'                                   
                 MOVE 'Y'                TO WS-VALID-COMP-TYPE                  
                 MOVE 'Y'                TO WS-FOUND-GROUP                      
              ELSE                                                              
                 MOVE 'Y'                TO WS-FOUND-GROUP.                     
                                                                                
      ************************************************************              
      * COMPARE IN THE CASE WHERE THERE IS MORE THEN 1 NAP BEING                
      * SENT OVER                                                               
      ************************************************************              
           IF AGENT-NUMBER OF GWCORCOMP   = GNAP-AGENT-CODE AND                 
              GFO-NUMBER   OF GWCORCOMP   = GNAP-GFO-OFFICE AND                 
              WS-ACCUM-AMT                = GNAP-AMOUNT                         
              IF COMP-TYPE OF GWCORCOMP = 'N'                                   
                 MOVE 'Y'                TO WS-VALID-COMP-TYPE                  
                 MOVE 'Y'                TO WS-FOUND-GROUP                      
              ELSE                                                              
                 MOVE 'Y'                TO WS-FOUND-GROUP.                     
                                                                                
           MOVE COMP-EFF-DATE OF GWCORCOMP TO PREV-EFF-DATE.                    
                                                                                
           IF WS-FOUND-GROUP NOT = 'Y'                                          
      *%      OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                          
IOS           MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                       
IOS           MOVE 15 TO FCCSPL-DML-SEQ-NO                                      
IOS           MOVE +7  TO FCCSPL-ADDRESS-COUNT                                  
MAN02         CALL GWFADDR                                                      
MAN02              USING FCCSPL-ADDRESS-AREA                                    
MAN02                    FCCSPL-FETCH-NEXT                                      
MAN02                    FCCSPLIO-GWCORCOMP                                     
MAN02                    FCCSPL-GWCORCOMP                                       
MAN02                    FCCSPL-GRACCT-COMP                                     
MAN02                    GWCORCOMP                                              
MAN02                    FCCSPL-OBTAIN                                          
MAN02                    FCCSPL-NOKEEP                                          
IOS           END-CALL                                                          
FXXTOK        CALL GWFSPLB1                                                     
IOS                USING DUMMY-PARM-1                                           
IOS                      DUMMY-PARM-2                                           
IOS                      DBLINK-SUBSCHEMA-CONTROL                               
IOS                      DBLINK-RECORD-SET-KEYS                                 
IOS                      DBLINK-CURSOR-CODES                                    
IOS           END-CALL                                                          
IOS           IF NOT DB-END-OF-SET                                              
IOS              PERFORM 799-SQL-STATUS-02                                      
IOS                 THRU 799-SQL-STATUS-02-EXIT                                 
IOS           ELSE                                                              
                  MOVE 'Y'          TO WS-FOUND-GROUP.                          
                                                                                
       999-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                      END OF SOURCE                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
