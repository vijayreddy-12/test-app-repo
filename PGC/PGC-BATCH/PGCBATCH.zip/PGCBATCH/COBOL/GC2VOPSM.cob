                                                                                
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VOPSM.                                                 
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  OCT 2005.                                                 
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *                                                                         
      *          << REFORMAT THE VO PSMASTER EXTRACT RECORDS >>                 
      *                                                                         
      *    THIS PROGRAM REFORMATS THE VO PSMASTER EXTRACT RECORDS               
      *    (THESE ARE THE VO PSMASTER RECORDS THAT COME FROM THE                
      *     VO PROCESSING) INTO THE MAINFRAME VO PSMASTER RECORD                
      *    LAYOUT.                                                              
      *                                                                         
      *    THE VO PSMASTER RECORDS THAT COME FROM THE VO PROCESSING             
      *    HAVE RECORD LAYOUT AS REFLECTED IN COPYBOOK VOPSMEXT.                
      *    THE MAINFRAME VO PSMASTER RECORDS HAVE RECORD LAYOUT AS              
      *    REFLECTED IN COPYBOOK VOPSMAST.                                      
      *                                                                         
      *    IN REFORMATTING THE VO PSMASTER RECORDS COMING FROM THE              
      *    VO PROCESSING, CHANGE ANY LEAP DATES FEB 29 TO FEB 28.               
      *                                                                         
      *    THE OUTPUT FILE FROM THIS PROGRAM IS THEN USED TO POPULATE/          
      *    UPDATE THE MAINFRAME VO PSMASTER VSAM FILE (IDCAMS).                 
      *                                                                         
      *                                                                         
      *    CALLING PROGRAM:  NONE                                               
      *    CALLED PROGRAMS:  GAEDATSR                                           
      *                                                                         
      *    COPYBOOKS:                                                           
      *        VSPSMEXT                                                         
      *        VOPSMAST                                                         
      *        ICBM                                                             
      *        GARDSVRB                                                         
      *        HCSLRNAM                                                         
      *                                                                         
      ******************************************************************        
      *    MMM/CCYY   -    NAME            -   DESCRIPTION                      
      *    OCT/2005        REGINA KNAUD        INITIAL CREATION.                
      *    OCT 2008        IBM                 COMPILER UPGRADE.                
SC1018*    OCT 2018        COGNIZANT           ADDED RENEWAL NOTICE             
      *                                        PERIOD AT THE END.               
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVOPSM           
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                         PIC X(24) VALUE                     
FXXTOK     'GC2VOPSM WS STARTS HERE '.                                          
                                                                                
      *01  VOPSMEXT-RECORD.                                                     
           COPY VOPSMEXT.                                                       
                                                                                
      *01  VOPSMASTER-RECORD.                                                   
           COPY VOPSMAST.                                                       
SC1018     05  VOPSM-NOTICE-PRD             PIC 9(03).                          
                                                                                
      *--------------------------------------                                   
      *    ABEND VARIABLES                                                      
      *--------------------------------------                                   
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X               PIC X(04).                          
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES-AREA.                                               
               10  WTL-MESS-LENGTH          PIC S9(3) VALUE +133 COMP-3.        
               10  WTL-MESS-CC              PIC X(1)  VALUE SPACES.             
               10  WTL-MESS-TEXT            PIC X(132) VALUE SPACES.            
           05  WTL-FLAG                     PIC X(1)  VALUE 'B'.                
           05  WTL-REPLY                    PIC X(3)  VALUE 'NO '.              
           05  WTL-REPLY-AREA               PIC X(80) VALUE SPACES.             
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                        PIC X(80)                           
           VALUE 'VOPSMNUM AND VOPSMEXT VERSION NUMBERS ARE DIFFERENT'.         
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY            OCCURS 1.                           
               10  WTL-MESSAGE              PIC X(80).                          
       01  WTL-SUB                          PIC S9(4) COMP.                     
                                                                                
       01  WS-VARIABLES.                                                        
FXXTOK     05  WS-PGM-GWVOPSM               PIC X(8) VALUE 'GC2VOPSM'.          
           05  WS-VOPSMEXT-EOF              PIC X.                              
           05  WS-SKIP-RECORD               PIC X.                              
           05  WS-SBS                       PIC 99.                             
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GWCDUMP                 PIC X(8)       VALUE 'GWCDUMP'.          
           05  GAEDATSR                PIC X(8)       VALUE 'GAEDATSR'.         
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
      *    VOPSMNUM(0) FILE                                                     
       01  VOPSMNUM-IN-BATCH-NUM.                                               
           05  VOPSMNUM-IN-BATCH-NUMBER    PIC 9(7).                            
           05  FILLER                      PIC X(73).                           
                                                                                
      *    VOPSMNUM(+1) FILE                                                    
       01  VOPSMNUM-OUT-BATCH-NUM.                                              
           05  VOPSMNUM-OUT-BATCH-NUMBER   PIC 9(7).                            
           05  FILLER                      PIC X(73) VALUE SPACES.              
                                                                                
      *--------------------------------------                                   
      *    DATASERVER                                                           
      *--------------------------------------                                   
       01  ICBM.                                                                
           COPY ICBM.                                                           
                                                                                
       01  ICBMVERB.                                                            
           COPY GARDSVRB.                                                       
                                                                                
       01  LOGICAL-RECORD-NAMES.                                                
           COPY HCSLRNAM.                                                       
           10  LR-VOPSMEXT-IN      PIC X(16) VALUE 'CARD-DATA-010'.             
           10  LR-IN-BATCH-NUM     PIC X(16) VALUE 'CARD-DATA-011'.             
           10  LR-VOPSMAST-OUT     PIC X(16) VALUE 'PRINT-DATA-020'.            
           10  LR-OUT-BATCH-NUM    PIC X(16) VALUE 'PRINT-DATA-021'.            
                                                                                
       01  WS-END                                PIC X(24) VALUE                
FXXTOK     'GC2VOPSM WS ENDS   HERE '.                                          
       01  WS-END-BYTE-X                         PIC X(1)  VALUE SPACE.         
                                                                                
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
       0000-MAIN-GWVOPSM.                                                       
FXXTOK     DISPLAY 'GC2VOPSM - DISPLAYS BEGIN'.                                 
                                                                                
           PERFORM 1000-INITIAL-RTN         THRU 1000-EXIT.                     
           PERFORM 2000-PROCESS-VOPSMEXT    THRU 2000-EXIT                      
                   UNTIL WS-VOPSMEXT-EOF = 'Y'.                                 
           PERFORM 7000-WRITE-OUT-BATCH-NUM THRU 7000-EXIT.                     
           PERFORM 9000-END-RTN             THRU 9000-EXIT.                     
                                                                                
FXXTOK     DISPLAY 'GC2VOPSM - DISPLAYS END'.                                   
       0000-EXIT.                                                               
           STOP RUN.                                                            
                                                                                
       1000-INITIAL-RTN.                                                        
           MOVE LOW-VALUES         TO LINKAGE-ANCHOR.                           
           MOVE SPACE              TO LINKAGE-STATUS.                           
           MOVE WS-PGM-GWVOPSM     TO ICBM-PROGRAM-NAME.                        
           MOVE 'N'                TO WS-VOPSMEXT-EOF.                          
                                                                                
      ***  READ THE FIRST VOPSMEXT RECORD WHICH IS A FILE NUMBER RECORD         
           MOVE LR-VOPSMEXT-IN     TO  LOGICAL-RECORD-NAME.                     
           CALL GAEDATSR        USING  OBTAIN-FIRST                             
                                       VOPSMEXT-RECORD                          
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              PERFORM 1010-CHECK-IN-BATCH-NUM THRU 1010-EXIT                    
           ELSE                                                                 
              MOVE 'Y' TO WS-VOPSMEXT-EOF                                       
              MOVE LINKAGE-STATUS         TO WTL-REPLY-AREA                     
              GO TO 9999-ABANDON-SHIP                                           
           END-IF.                                                              
                                                                                
      ***  READ THE SECOND VOPSMEXT RECORD WHICH IS THE START                   
      ***       OF THE DATA RECORDS.                                            
           MOVE LR-VOPSMEXT-IN     TO  LOGICAL-RECORD-NAME.                     
           CALL GAEDATSR        USING  OBTAIN-NEXT                              
                                       VOPSMEXT-RECORD                          
                                       ICBM.                                    
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-VOPSMEXT-EOF                                       
           END-IF.                                                              
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *                                                                         
      *****************************************************************         
      * 1010-CHECK-IN-BATCH-NUM                                                 
      *     READ THE VOPSMNUM FILE.                                             
      *     CHECK THE FILE NUMBER FROM THE VOPSMNUM AND VOPSMEXT FILES.         
      *     IF THE FILE NUMBERS ARE THE SAME, INCREMENT THE VOPSMNUM            
      *        FILE NUMBER BY 1 (FOR THE NEXT CYCLE'S PROCESSING) AND           
      *        PROCESS TILL THE END OF THE VOPSMEXT FILE.                       
      *     IF THE FILE NUMBERS ARE NOT THE SAME, DO NOT INCREMENT              
      *        THE VOPSMNUM FILE NUMBER AND DO NOT PROCESS THE REST             
      *        OF THE VOPSMEXT FILE;  ABEND PROCESSING.                         
      *****************************************************************         
       1010-CHECK-IN-BATCH-NUM.                                                 
                                                                                
           MOVE LR-IN-BATCH-NUM     TO LOGICAL-RECORD-NAME.                     
           CALL GAEDATSR         USING OBTAIN-FIRST                             
                                       VOPSMNUM-IN-BATCH-NUM                    
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
      *  THE FIRST VOPSMEXT RECORD CONTAINS THE FILE NUMBER.                    
      *  THE FIELDNAME USED IS VOPSMX-GROUP-NUMBER BUT SINCE                    
      *  IT IS PROCESSING THE FIRST VOPSMEXT RECORD, THIS FIELD                 
      *  REALLY CONTAINS THE FILE NUMBER VALUE, NOT A GROUP NUMBER.             
              IF VOPSMNUM-IN-BATCH-NUMBER = VOPSMX-GROUP-NUMBER                 
                 COMPUTE VOPSMNUM-OUT-BATCH-NUMBER =                            
                         VOPSMNUM-IN-BATCH-NUMBER  + 1                          
              ELSE                                                              
                 MOVE 'Y'          TO WS-VOPSMEXT-EOF                           
                 MOVE +1           TO WTL-SUB                                   
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 MOVE LINKAGE-STATUS         TO WTL-REPLY-AREA                  
                 GO TO 9999-ABANDON-SHIP                                        
              END-IF                                                            
           ELSE                                                                 
              MOVE 'Y'          TO WS-VOPSMEXT-EOF                              
              MOVE LINKAGE-STATUS         TO WTL-REPLY-AREA                     
              GO TO 9999-ABANDON-SHIP                                           
           END-IF.                                                              
                                                                                
       1010-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *                                                                         
       2000-PROCESS-VOPSMEXT.                                                   
      ******************************************************************        
      *    REFORMAT THE VOPSMEXT RECORD INTO THE VOPSMAST RECORD.               
      *    IN REFORMATTING THE DATES, CHANGE LEAP DATE FEB 29 TO                
      *    FEB 28.                                                              
      *    WRITE OUT THE VOPSMAST RECORD.                                       
      *    READ NEXT VOPSMEXT RECORD.                                           
      ******************************************************************        
           MOVE 'N' TO WS-SKIP-RECORD.                                          
                                                                                
           IF VOPSMX-GROUP-NUMBER IS NUMERIC                                    
              IF VOPSMX-GROUP-NUMBER > 0                                        
                 MOVE VOPSMX-GROUP-NUMBER TO VOPSM-GROUP-NUMBER                 
              ELSE                                                              
                 MOVE 'Y' TO WS-SKIP-RECORD                                     
              END-IF                                                            
           ELSE                                                                 
              MOVE 'Y' TO WS-SKIP-RECORD                                        
           END-IF.                                                              
                                                                                
           IF VOPSMX-POLICY-YEAR IS NUMERIC                                     
              MOVE VOPSMX-POLICY-YEAR TO VOPSM-POLICY-YEAR                      
           ELSE                                                                 
              MOVE 'Y' TO WS-SKIP-RECORD                                        
           END-IF.                                                              
                                                                                
           IF VOPSMX-NXT-RNEW-YEAR IS NUMERIC                                   
              MOVE VOPSMX-NXT-RNEW-YEAR TO VOPSM-NXT-RNEW-YEAR                  
           ELSE                                                                 
              MOVE 'Y' TO WS-SKIP-RECORD                                        
           END-IF.                                                              
                                                                                
SC1018     IF VOPSMX-REN-NOT-PER IS NUMERIC                                     
SC1018        MOVE VOPSMX-REN-NOT-PER TO VOPSM-NOTICE-PRD                       
SC1018     ELSE                                                                 
SC1018        MOVE 60 TO VOPSM-NOTICE-PRD                                       
SC1018     END-IF.                                                              
                                                                                
           IF VOPSMX-NXT-RNEW-MONTH IS NUMERIC                                  
              MOVE VOPSMX-NXT-RNEW-MONTH TO VOPSM-NXT-RNEW-MONTH                
           ELSE                                                                 
              MOVE 0 TO VOPSM-NXT-RNEW-MONTH                                    
              MOVE 'Y' TO WS-SKIP-RECORD                                        
           END-IF.                                                              
                                                                                
           IF VOPSMX-NXT-RNEW-DAY IS NUMERIC                                    
              MOVE VOPSMX-NXT-RNEW-DAY TO VOPSM-NXT-RNEW-DAY                    
              IF VOPSM-NXT-RNEW-MONTH = 02                                      
                 AND                                                            
                 VOPSM-NXT-RNEW-DAY = 29                                        
                 MOVE 28 TO VOPSM-NXT-RNEW-DAY                                  
              END-IF                                                            
           ELSE                                                                 
              MOVE 'Y' TO WS-SKIP-RECORD                                        
           END-IF.                                                              
                                                                                
           PERFORM VARYING WS-SBS FROM 1 BY 1 UNTIL WS-SBS > 5                  
              IF VOPSMX-EFF-YEAR (WS-SBS) IS NUMERIC                            
                 MOVE VOPSMX-EFF-YEAR (WS-SBS) TO                               
                      VOPSM-EFF-YEAR (WS-SBS)                                   
              ELSE                                                              
                 MOVE 0 TO VOPSM-EFF-YEAR (WS-SBS)                              
              END-IF                                                            
              IF VOPSMX-EFF-MONTH (WS-SBS) IS NUMERIC                           
                 MOVE VOPSMX-EFF-MONTH (WS-SBS) TO                              
                      VOPSM-EFF-MONTH (WS-SBS)                                  
              ELSE                                                              
                 MOVE 0 TO VOPSM-EFF-MONTH (WS-SBS)                             
              END-IF                                                            
              IF VOPSMX-EFF-DAY (WS-SBS) IS NUMERIC                             
                 MOVE VOPSMX-EFF-DAY (WS-SBS) TO                                
                      VOPSM-EFF-DAY (WS-SBS)                                    
                 IF VOPSM-EFF-MONTH (WS-SBS) = 02                               
                    AND                                                         
                    VOPSM-EFF-DAY (WS-SBS)   = 29                               
                    MOVE 28 TO VOPSM-EFF-DAY (WS-SBS)                           
                 END-IF                                                         
              ELSE                                                              
                 MOVE 0 TO VOPSM-EFF-DAY (WS-SBS)                               
              END-IF                                                            
              MOVE VOPSMX-COMB-IND (WS-SBS) TO                                  
                   VOPSM-COMB-IND (WS-SBS)                                      
           END-PERFORM.                                                         
                                                                                
           IF WS-SKIP-RECORD = 'N'                                              
              PERFORM 3000-WRITE-VOPSMAST THRU 3000-EXIT                        
           END-IF.                                                              
                                                                                
           MOVE LR-VOPSMEXT-IN     TO  LOGICAL-RECORD-NAME.                     
           CALL GAEDATSR        USING  OBTAIN-NEXT                              
                                       VOPSMEXT-RECORD                          
                                       ICBM.                                    
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-VOPSMEXT-EOF                                       
           END-IF.                                                              
       2000-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       3000-WRITE-VOPSMAST.                                                     
           MOVE LR-VOPSMAST-OUT             TO  LOGICAL-RECORD-NAME.            
           CALL GAEDATSR        USING STORE-LR                                  
                                      VOPSMASTER-RECORD                         
                                      ICBM.                                     
           IF NOT LR-STATUS-OK                                                  
              MOVE LINKAGE-STATUS         TO WTL-REPLY-AREA                     
              GO TO 9999-ABANDON-SHIP                                           
           END-IF.                                                              
                                                                                
       3000-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
      **************************************************************            
      *                                                                         
       7000-WRITE-OUT-BATCH-NUM.                                                
           MOVE LR-OUT-BATCH-NUM      TO LOGICAL-RECORD-NAME.                   
           CALL GAEDATSR           USING STORE-LR                               
                                         VOPSMNUM-OUT-BATCH-NUM                 
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE LINKAGE-STATUS         TO WTL-REPLY-AREA                     
              GO TO 9999-ABANDON-SHIP                                           
           END-IF.                                                              
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
      ******************************************************************        
      *                                                                         
       9000-END-RTN.                                                            
           MOVE SPACES   TO LOGICAL-RECORD-NAME.                                
           CALL GAEDATSR        USING FINISH-LR                                 
                                  LOGICAL-RECORD-NAME                           
                                  ICBM.                                         
       9000-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
      ******************************************************************        
      *                                                                         
       9999-ABANDON-SHIP.                                                       
                                                                                
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL' USING  WTL-MESSAGES-AREA                                  
                              WTL-FLAG                                          
                              WTL-REPLY                                         
                              WTL-REPLY-AREA.                                   
                                                                                
           CALL GWCDUMP    USING ICBM                                           
                                 GWRDUMP.                                       
                                                                                
