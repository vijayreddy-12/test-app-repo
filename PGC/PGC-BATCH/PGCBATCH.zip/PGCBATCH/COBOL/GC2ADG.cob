       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2ADG.                                                      
      *%****************************************************************        
      *%  DATE 11/08/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      *REMARKS.                                                                 
      *    THIS MODULE CREATES GROUP AND/OR GRACCT RECORDS ON THE               
      *        COMMISSION HISTORY DATABASE.                                     
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  IMPORTANT:                                                   *         
      *                                                               *         
      *  THIS PROGRAM IS THE BATCH VERSION OF GWCOCAG2.  IF THIS      *         
      *  PROGRAM CHANGES YOU MAY HAVE TO CHANGE GWCOCAG2 ALSO.        *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INPUT:   - COMMISSION HISTORY DATABASE - SUBSCHEMA-CTRL      *         
      *                                         - GWCORGROUP          *         
      *                                         - GWCORGRACCT         *         
      *           - GWCORADG-WORK-RECORD                              *         
      *                                                               *         
      *  OUTPUT:    COMMISSION HISTORY DATABASE                       *         
      *                                                               *         
      *  FREQUENCY: VIA CALLS                                         *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *  HISTORY                                                                
      *  06AUG87 L HAMPTON - CHANGED FROM SSGWCO03 TO 02                        
      *                                                                         
      *  NOV/90  M PRANGE  - REFERENCES TO ANNIV DATE CHANGED TO                
      *                      RENEW DATE.                                        
      *                                                                         
      *  NOV/90  M DRURY   - INIT THE COMP-LIVES FIELD ON THE                   
      *                      GWCORGRACCT REC TO ZEROS.                          
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO02 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2ADG W-S STARTS HERE **'.                                  
      /                                                                         
      *----------------------------------------------------------------         
      *    DYNAMIC CALLED ROUTINES                                              
      *----------------------------------------------------------------         
       01  WS-CALLED-MODULES.                                                   
           05  QDATEQ2           PIC X(08)    VALUE 'QDATEQ2'.                  
                                                                                
       01  WS-PARAMETERS.                                                       
                                                                                
           05  QDATE-FORMAT               VALUE 'AC'      PIC XX.               
                                                                                
           05  WTL-MESSAGE.                                                     
               10  WTL-MSG-LENGTH PIC S999  COMP-3 VALUE +80.                   
               10  WTL-MSG-CC     PIC X            VALUE '0'.                   
               10  FILLER         PIC X(7)         VALUE 'GROUP='.              
REN            10  WTL-GROUP-NUMBER   PIC 9(7)     VALUE ZERO.                  
               10  FILLER             PIC XX       VALUE SPACES.                
               10  FILLER             PIC X(9)     VALUE 'ACCOUNT='.            
               10  WTL-GROUP-ACCOUNT  PIC XXX      VALUE SPACES.                
               10  FILLER             PIC XXX      VALUE SPACES.                
               10  WTL-ERROR-MSG      PIC X(50)    VALUE SPACES.                
                                                                                
      /                                                                         
      *%   COPY IDMS SUBSCHEMA-NAMES.                                           
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           '** GWCORCADG W-S ENDS HERE **'.                                     
      /                                                                         
IOS    01  DFHEIBLK                               PIC X(10).                    
IOS    01  DFHCOMMAREA                            PIC X(10).                    
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO02'   PIC X(8).                     
IOS                                                                             
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       LINKAGE SECTION.                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CTRL.                                            
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP RECORD DESCRIPTION                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * GWCORADG-WORK-RECORD                                                    
CPYNME     COPY GCRADGW.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    -  CALC GROUP RECORD                                       *         
      *       IF NOT FOUND                                            *         
      *          CREATE GROUP RECORD.                                 *         
      *    -  CALC GRACCT RECORD                                      *         
      *       IF NOT FOUND                                            *         
      *          CREATE GRACCT RECORD.                                *         
      *    -  EDIT DATES.                                             *         
      *    -  RETURN.                                                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       PROCEDURE DIVISION USING DBLINK-SUBSCHEMA-CONTROL                        
                                DBLINK-RECORD-SET-KEYS                          
                                DBLINK-CURSOR-CODES                             
                                GWCORGROUP                                      
                                GWCORGRACCT                                     
                                GWCORADG-WORK-RECORD.                           
FXXTOK     MOVE 'GC2ADG'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       000-ENTRY.                                                               
                                                                                
FXXTOK     MOVE 'GC2ADG' TO PROGRAM-NAME.                                       
                                                                                
           MOVE GWCOEADG-W-GROUP-NUMBER                                         
                TO GROUP-NUMBER OF GWCORGROUP.                                  
      *%   OBTAIN CALC GWCORGROUP                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
FXXTOK*    CALL GWFSPLO1                                                        
IOS             USING DFHEIBLK                                                  
IOS                   DFHCOMMAREA                                               
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      *%       STORE GWCORGROUP                                                 
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 2 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORGROUP                                   
MAN02                     FCCSPL-GWCORGROUP                                     
MAN02                     GWCORGROUP                                            
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
FXXTOK*        CALL GWFSPLO1                                                    
IOS                 USING DFHEIBLK                                              
IOS                       DFHCOMMAREA                                           
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               MOVE '1' TO GWCOEADG-W-ACTION-SWITCH.                            
                                                                                
           MOVE GWCOEADG-W-GROUP-ACCOUNT                                        
               TO GROUP-ACCOUNT OF GWCORGRACCT.                                 
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
FXXTOK*    CALL GWFSPLO1                                                        
IOS             USING DFHEIBLK                                                  
IOS                   DFHCOMMAREA                                               
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               PERFORM 100-SET-GRACCT                                           
      *%       STORE GWCORGRACCT                                                
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 4 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORGRACCT                                  
MAN02                     FCCSPL-GWCORGRACCT                                    
MAN02                     GWCORGRACCT                                           
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
FXXTOK*        CALL GWFSPLO1                                                    
IOS                 USING DFHEIBLK                                              
IOS                       DFHCOMMAREA                                           
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
               IF  GWCOEADG-W-ACTION-SWITCH = SPACE                             
                   MOVE '2' TO GWCOEADG-W-ACTION-SWITCH.                        
                                                                                
           CALL QDATEQ2 USING QDATE-FORMAT                                      
                              LAST-RECON-DATE OF GWCORGRACCT                    
                              GWCOEADG-W-LAST-RECON-DATE-EXT.                   
                                                                                
           IF  GWCOEADG-W-LAST-RECON-DATE-EXT = '*******'                       
               MOVE GROUP-NUMBER OF GWCORGRACCT TO WTL-GROUP-NUMBER             
               MOVE GROUP-ACCOUNT OF GWCORGRACCT TO WTL-GROUP-ACCOUNT           
               MOVE 'WARNING - LAST-RECON-DATE IS INVALID'                      
                   TO WTL-ERROR-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE.                                    
                                                                                
           CALL QDATEQ2 USING QDATE-FORMAT                                      
                              NEXT-RECON-DATE OF GWCORGRACCT                    
                              GWCOEADG-W-NEXT-RECON-DATE-EXT.                   
                                                                                
           IF  GWCOEADG-W-NEXT-RECON-DATE-EXT = '*******'                       
               MOVE GROUP-NUMBER OF GWCORGRACCT TO WTL-GROUP-NUMBER             
               MOVE GROUP-ACCOUNT OF GWCORGRACCT TO WTL-GROUP-ACCOUNT           
               MOVE 'WARNING - NEXT-RECON-DATE IS INVALID'                      
                   TO WTL-ERROR-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE.                                    
                                                                                
           CALL QDATEQ2 USING QDATE-FORMAT                                      
                              GWCOEADG-W-ACCT-EFF-DATE                          
                              GWCOEADG-W-ACCT-EFF-DATE-EXT.                     
                                                                                
           IF  GWCOEADG-W-ACCT-EFF-DATE-EXT = '*******'                         
               MOVE GROUP-NUMBER OF GWCORGRACCT TO WTL-GROUP-NUMBER             
               MOVE GROUP-ACCOUNT OF GWCORGRACCT TO WTL-GROUP-ACCOUNT           
               MOVE 'WARNING - ACCT-EFF-DATE IS INVALID'                        
                   TO WTL-ERROR-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE.                                    
                                                                                
           CALL QDATEQ2 USING QDATE-FORMAT                                      
                              GWCOEADG-W-NEXT-RENEW-DATE                        
                              GWCOEADG-W-NEXT-RENEW-DATE-EXT.                   
                                                                                
           IF  GWCOEADG-W-NEXT-RENEW-DATE-EXT = '*******'                       
               MOVE GROUP-NUMBER OF GWCORGRACCT TO WTL-GROUP-NUMBER             
               MOVE GROUP-ACCOUNT OF GWCORGRACCT TO WTL-GROUP-ACCOUNT           
               MOVE 'WARNING - NEXT-RENEW-DATE IS INVALID'                      
                   TO WTL-ERROR-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE.                                    
                                                                                
        099-RETURN.                                                             
                                                                                
           GOBACK.                                                              
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *       FOLLOWING ROUTINE SETS UP A NEW GRACCT RECORD           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       100-SET-GRACCT.                                                          
                                                                                
           MOVE ZERO TO RENEWAL-EFFECTIVE-YEAR OF GWCORGRACCT                   
                        RENEWAL-EFFECTIVE-DAY OF GWCORGRACCT                    
                        COMP-LIVES            OF GWCORGRACCT.                   
           MOVE 'Y' TO RENEW-COMP-ADVANCED-IND OF GWCORGRACCT.                  
                                                                                
           IF  GWCOEADG-W-NEXT-RENEW-DAY = +001                                 
               SUBTRACT 1 FROM GWCOEADG-W-NEXT-RENEW-YEAR                       
                   GIVING NEXT-RECON-YEAR OF GWCORGRACCT                        
               MOVE +365 TO NEXT-RECON-DAY OF GWCORGRACCT                       
           ELSE                                                                 
               SUBTRACT 1 FROM GWCOEADG-W-NEXT-RENEW-DAY                        
                   GIVING NEXT-RECON-DAY OF GWCORGRACCT                         
               MOVE GWCOEADG-W-NEXT-RENEW-YEAR                                  
                    TO NEXT-RECON-YEAR OF GWCORGRACCT.                          
                                                                                
           IF  GWCOEADG-W-ACCT-EFF-DAY = +001                                   
               SUBTRACT 1 FROM GWCOEADG-W-ACCT-EFF-YEAR                         
                   GIVING LAST-RECON-YEAR OF GWCORGRACCT                        
               MOVE +365 TO LAST-RECON-DAY OF GWCORGRACCT                       
           ELSE                                                                 
               SUBTRACT 1 FROM GWCOEADG-W-ACCT-EFF-DAY                          
                   GIVING LAST-RECON-DAY OF GWCORGRACCT                         
               MOVE GWCOEADG-W-ACCT-EFF-YEAR                                    
                    TO LAST-RECON-YEAR OF GWCORGRACCT.                          
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
