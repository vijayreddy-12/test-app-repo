       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. QDATE.                                                       
      *-------------------------------------------------------------*           
      * HISTORY LOG                                                             
      * 02JUL08    IBM GR    UPGRADED IN ENTERPRISE COMPILER PROJECT            
      *-------------------------------------------------------------*           
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
       FILE-CONTROL.                                                            
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
           EJECT                                                                
       WORKING-STORAGE SECTION.                                                 
       01  QDATEQ           PIC X(8) VALUE 'QDATEQ'.                            
       LINKAGE SECTION.                                                         
      *                                                                         
      *     ZDATE PARAMETERS                                                    
      *                                                                         
       01  ZDATE-PAR1.                                                          
           03 ZDATE-FROM                     PIC X.                             
           03 ZDATE-TO                       PIC X.                             
       01  ZDATE-SOURCE.                                                        
           03 ZDATE-ALPHA                    PIC X(9).                          
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05 ZDATE-ALIS-YR              PIC S999 COMP-3.                   
               05 ZDATE-ALIS-DAY             PIC S999 COMP-3.                   
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05 ZDATE-DD                   PIC 99.                            
               05 ZDATE-MM                   PIC 99.                            
               05 ZDATE-YY                   PIC 99.                            
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05  FILLER                    PIC XX.                            
               05 ZDATE-MMM                  PIC XXX.                           
               05 ZDATE-YY2                  PIC 99.                            
           03  FILLER REDEFINES ZDATE-ALPHA.                                    
               05 ZDATE-YY3                  PIC 99.                            
               05  FILLER                    PIC X.                             
               05 ZDATE-MM3                  PIC 99.                            
               05  FILLER                    PIC X.                             
               05 ZDATE-DD3                  PIC 99.                            
       01  ZDATE-TARGET.                                                        
           03 ZDATE-TARGET-ALPHA             PIC X(9).                          
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05 ZDATE-TARGET-ALIS-YEAR     PIC S999 COMP-3.                   
               05 ZDATE-TARGET-ALIS-DAY      PIC S999 COMP-3.                   
           03 ZDATE-TARGET-ERROR REDEFINES ZDATE-TARGET-ALPHA                   
                                             PIC X(4).                          
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05 ZDATE-TARGET-DD            PIC XX.                            
               05 ZDATE-TARGET-MM            PIC XX.                            
               05 ZDATE-TARGET-YY            PIC 99.                            
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05 ZDATE-TARGET-SYSTEM        PIC XX/XX/XX.                      
           03  FILLER REDEFINES ZDATE-TARGET-ALPHA.                             
               05  FILLER                    PIC X(5).                          
               05 ZDATE-TARGET-YYYY.                                            
                   07 ZDATE-TARGET-SHORTYY   PIC 99.                            
                   07 ZDATE-TARGET-BLANK     PIC XX.                            
       EJECT                                                                    
       PROCEDURE DIVISION USING ZDATE-PAR1 ZDATE-SOURCE ZDATE-TARGET.           
       0000-MAINLINE.                                                           
      *    CALL QDATEQ USING ZDATE-PAR1 ZDATE-SOURCE ZDATE-TARGET.              
           CALL 'QDATEQ' USING ZDATE-PAR1 ZDATE-SOURCE ZDATE-TARGET.            
           GOBACK.                                                              
