       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2RC3.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
      *    THIS PROGRAM READS THE EXTRACT NAPS RECORDS FROM GWCORCRC1           
      *        TO RECONCILE NAPS RECORDS.                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * HISTORY:  20JULY87  S WAGLER  -USE RUN DATE AS OPPOSED TO     *         
      *                     L HAMPTON -CURRENT DATE AND TO EDIT THE   *         
      *                                CONTROL DATE ON THE FILE TO THE*         
      *                                RUN DATE.                      *         
      *             JUN90  A SCHLEICHER - RECOMPILED - CHANGE TO      *         
      *                                                GWCORTRANS     *         
      *                                                               *         
      *    JUL/2005  R. KNAUD.                                        *         
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)        *         
      *                  CHANGE THE GMASTER IDMS READ TO:                       
      *                      USE VOGPWRA7 TO READ THE VCM AND         *         
      *                      GIPSY MASTER FILES.                      *         
      *                                                               *         
      *                                                                         
      *    OCT/08 IBM                                                           
      *         - ENTERPRISE COMPILER UPGRADE                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      /                                                                         
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCRC3          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO02 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2RC3 W-S STARTS HERE **'.                                  
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
           03  FILLER                     PIC X(30).                            
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  VOGPWRA7                   PIC X(8)    VALUE 'VOGPWRA7'.         
                                                                                
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
       01  WS-PARAMETERS.                                                       
                                                                                
           05  EOF-SWITCH                 VALUE 'N'       PIC X.                
               88  EOF-ON-EXTRACT         VALUE 'Y'.                            
           05  NEW-ACCOUNT-IND            VALUE 'N'       PIC X.                
               88  NEW-ACCOUNT-READ       VALUE 'Y'.                            
           05  NEW-AGENT-IND              VALUE 'N'       PIC X.                
               88  NEW-AGENT-READ         VALUE 'Y'.                            
           05  NEW-GFO-IND                VALUE 'N'       PIC X.                
               88  NEW-GFO-READ           VALUE 'Y'.                            
           05  ERROR-SWITCH               VALUE '0'       PIC X.                
               88  ERROR-GFO              VALUE '1'.                            
               88  ERROR-DISP             VALUE '2'.                            
           05  QDATE-FORMATC              VALUE 'CA'      PIC XX.               
           05  GPSY-RETURN-CODE           VALUE SPACES    PIC XXX.              
           05  WS-CONT-PROC-FLAG          VALUE 'Y'       PIC X.                
           05  AMEND-RECOV-AMT        COMP-3  VALUE +0    PIC S9(9)V99.         
           05  TOT-NAP-PAID-AMEND-FY  COMP-3  VALUE +0    PIC S9(9)V99.         
           05  TOT-NAP-PAID-AMEND-RN  COMP-3  VALUE +0    PIC S9(9)V99.         
           05  WS-RECON-AMT           COMP-3  VALUE +0    PIC S9(9)V99.         
           05  TOTAL-NAP-PAID         COMP-3  VALUE +0    PIC S9(9)V99.         
           05  TOTAL-NAP-EARNED       COMP-3  VALUE +0    PIC S9(9)V99.         
           05  WS-COMP-AMT            COMP-3  VALUE +0    PIC S9(9).            
                                                                                
           05  WS-PREV-KEY.                                                     
REN            10  WS-PREV-GROUP              PIC X(7)   VALUE ZERO.            
               10  WS-PREV-ACCOUNT            PIC XXX    VALUE SPACES.          
               10  WS-PREV-AGENT              PIC 9(6)   VALUE ZERO.            
               10  WS-PREV-GFO                PIC 9(5)   VALUE ZERO.            
                                                                                
           05  WS-ALIS-RUN-DATE.                                                
               10  FILLER             COMP-3  PIC S999   VALUE ZERO.            
               10  FILLER             COMP-3  PIC S999   VALUE ZERO.            
                                                                                
           05  GNUMONIC.                                                        
               10  GNUM-TABLE         COMP    PIC S9(4)  VALUE +34.             
               10  GNUM-REP                   PIC X(5)   VALUE SPACES.          
               10  GNUM-RETURN.                                                 
                   15  GNUM-RETURN-1-5        PIC X(5)   VALUE SPACES.          
                   15  FILLER                 PIC X(15).                        
                                                                                
           05  EXP-AREA.                                                        
               10  NAME-AND-DEL OCCURS 6 TIMES.                                 
                   15  EXP-NAME              PIC X(30).                         
                   15  EXP-DEL               PIC X.                             
                                                                                
           05  EXP-ERR-CODE                  PIC XXX     VALUE SPACES.          
                                                                                
      /                                                                         
       01  FILLER                            PIC X(32)   VALUE                  
                                    'ACTION REPORT STARTS HERE'.                
       01  ACTION-REPORT.                                                       
           05  ACTION-HDG-1.                                                    
               10  ACTION-CC-1          PIC X         VALUE '1'.                
FXXTOK         10  FILLER               PIC X(10)     VALUE 'GC2RC3'.           
               10  FILLER               PIC X(35)     VALUE SPACES.             
               10  FILLER               PIC X(45)     VALUE                     
                                  'NAP RECONCILIATION - ERROR REPORT'.          
               10  FILLER               PIC X(9)      VALUE 'RUN DATE'.         
               10  ACTION-DATE          PIC X(7)      VALUE SPACES.             
               10  FILLER               PIC X(6)      VALUE SPACES.             
               10  FILLER               PIC X(6)      VALUE SPACES.             
               10  FILLER               PIC X(5)      VALUE SPACES.             
               10  FILLER               PIC X(5)      VALUE SPACES.             
           05  ACTION-HDG-2.                                                    
               10  ACTION-CC-2          PIC X         VALUE '-'.                
               10  FILLER               PIC X(10)     VALUE 'GROUP'.            
               10  FILLER               PIC X(10)     VALUE 'ACCOUNT'.          
               10  FILLER               PIC X(10)     VALUE 'AGENT'.            
               10  FILLER               PIC X(9)      VALUE 'GFO'.              
               10  FILLER               PIC X(7)      VALUE 'COMP'.             
               10  FILLER               PIC X(8)      VALUE 'COMP'.             
               10  FILLER               PIC X(10)     VALUE 'COMP'.             
               10  FILLER               PIC X(18)     VALUE 'AMOUNT'.           
               10  FILLER               PIC X(50)     VALUE                     
                                                      'DESCRIPTION'.            
           05  ACTION-HDG-3.                                                    
               10  ACTION-CC-3          PIC X         VALUE SPACE.              
               10  FILLER               PIC X(39)     VALUE SPACES.             
               10  FILLER               PIC X(7)      VALUE 'TYPE'.             
               10  FILLER               PIC X(7)      VALUE 'DISP'.             
               10  FILLER               PIC X(79)     VALUE 'REASON'.           
                                                                                
           05  ACTION-DETAIL.                                                   
               10  ACTION-CC-4          PIC X         VALUE '0'.                
REN            10  ACTION-GROUP         PIC 9(7)      VALUE ZERO.               
REN            10  FILLER               PIC X(5)      VALUE SPACES.             
               10  ACTION-ACCOUNT       PIC XXX       VALUE SPACES.             
               10  FILLER               PIC X(5)      VALUE SPACES.             
               10  ACTION-AGENT         PIC 9(6)      VALUE ZERO.               
               10  FILLER               PIC X(4)      VALUE SPACES.             
               10  ACTION-GFO           PIC 9(5)      VALUE ZERO.               
               10  FILLER               PIC X(6)      VALUE SPACES.             
               10  ACTION-TYPE          PIC X         VALUE SPACE.              
               10  FILLER               PIC X(6)      VALUE SPACES.             
               10  ACTION-DISP          PIC X         VALUE SPACE.              
               10  FILLER               PIC X(6)      VALUE SPACES.             
               10  ACTION-REASON        PIC X         VALUE SPACE.              
               10  FILLER               PIC X         VALUE SPACES.             
               10  ACTION-AMT           PIC ZZZZZZZZ9.99-                       
                                                      VALUE ZERO.               
               10  FILLER               PIC X(2)      VALUE SPACES.             
               10  ACTION-MSG           PIC X(60)     VALUE SPACES.             
                                                                                
           05  END-LINE.                                                        
               10  END-CC               PIC X         VALUE '-'.                
               10  FILLER               PIC X(132)    VALUE                     
                                            '*** END OF REPORT ***'.            
      /                                                                         
       01  FILLER                       PIC X(32)     VALUE                     
                                        'ACTION MESSAGES STARTS HERE'.          
       01  ACTION-MESSAGES.                                                     
           05  ACTION-MSG-1         PIC X(60)         VALUE                     
       'NO GFO MATCH ON GIPSY. PLEASE RECONCILE THIS AMOUNT MANUALLY'.          
           05  ACTION-MSG-2         PIC X(50)         VALUE                     
                     '- DISPOSITION - MUST BE P(PAID) OR E(EARNED)'.            
           05  ACTION-MSG-3         PIC X(50)         VALUE                     
                     'COMM-SCR-RECON-ID/NAP-RECON-IND NOT EQ YES  '.            
                                                                                
           05  WRITE-PARMS.                                                     
               10  DLSA-SYSNNN      PIC X(6)          VALUE 'SYS021'.           
               10  DLSA-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  ACTION-LINE      PIC X(133)        VALUE SPACES.             
               10  DLSA-REC-SIZE    PIC 9(5)          VALUE 133.                
               10  DLSA-BLK-SIZE    PIC 9(5)          VALUE 3990.               
               10  DLSA-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSA-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
                                   'EXTRACT RECORD STARTS HERE'.                
       01  EXTRACT-NAP-REC.                                                     
                            COPY GWCORC72 REPLACING                             
                                ==01  EXT-RECON-NAP-RECORD.== BY ====.          
                                                                                
           05  READ-PARMS.                                                      
               10  DLSN-SYSNNN      PIC X(6)          VALUE 'SYS010'.           
               10  DLSN-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSN-REC-SIZE    PIC 9(5)          VALUE 50.                 
               10  DLSN-BLK-SIZE    PIC 9(5)          VALUE 5000.               
               10  DLSN-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSN-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
           05  RUNDATE-READ-PARMS.                                              
               10  DLSR-SYSNNN      PIC X(6)          VALUE 'SYS019'.           
               10  DLSR-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSR-REC-SIZE    PIC 9(5)          VALUE 80.                 
               10  DLSR-BLK-SIZE    PIC 9(5)          VALUE 80.                 
               10  DLSR-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSR-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
       01  FILLER                   PIC X(32)         VALUE                     
                                        'GNAP RECORD STARTS HERE'.              
       01  GNAP-RECORD.                                                         
      * GNAPREC                                                                 
                        COPY GNAPREC7 REPLACING                                 
                                             ==01  GNAPREC.== BY ====.          
      /                                                                         
       01  FILLER                  PIC X(32)          VALUE                     
                                       'SUBSCHEMA STARTS HERE'.                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - CONTROL RECORD DESCRIPTION                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCNTL                                                               
CPYNME     COPY GCICNTL.                                                        
      /                                                                         
       01  FILLER                    PIC X(32)        VALUE                     
                                         'GRACCT RECORD STARTS HERE'.           
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
       01  FILLER                    PIC X(32)       VALUE                      
                                        'COMP RECORD STARTS HERE'.              
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - COMPENSATION RECORD DESCRIPTION           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
       01  FILLER                  PIC X(32)         VALUE                      
                                      'AGENT RECORD STARTS HERE'.               
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - AGENT RECORD DESCRIPTION                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
      /                                                                         
       01  FILLER                  PIC X(32)          VALUE                     
                                      'GFO RECORD STARTS HERE'.                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GFO RECORD DESCRIPTION                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGFO                                                                
CPYNME     COPY GCIGFO.                                                         
      /                                                                         
       01  FILLER                  PIC X(32)            VALUE                   
                                      'TRANS REC STARTS HERE'.                  
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATA BASE - TRANSACTIONS RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORTRANS                                                              
CPYNME     COPY GCITRAN.                                                        
      /                                                                         
       01  FILLER                   PIC X(32)      VALUE                        
                                        'GPSY MASTER STARTS HERE'.              
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          GIPSY - RECORDS                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       COPY GWCORRCD.                                                           
                                                                                
       COPY GWCORRRD.                                                           
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   MESSAGES USED FOR THE ERROR LOGIC USING THE CALL TO WTL     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       01  WTL-AREA.                                                            
           05  WTL-FLAG              PIC X             VALUE 'B'.               
           05  WTL-REPLY-YES         PIC XXX           VALUE 'YES'.             
           05  WTL-REPLY-NO          PIC XXX           VALUE 'NO '.             
           05  WTL-REPLY             PIC XXX           VALUE SPACES.            
           05  WTL-REPLY-AREA        PIC X(10)         VALUE SPACES.            
       01  WTL-MESSAGE-AREA.                                                    
           05  FILLER         COMP-3 PIC S9(3)         VALUE +121.              
           05  FILLER                PIC X             VALUE SPACES.            
           05  WTL-MESSAGE           PIC X(120)        VALUE SPACES.            
                                                                                
       01  WTL-ERROR-MESSAGES.                                                  
           05  ERR-MESS1.                                                       
               10  FILLER                     PIC X(40)  VALUE                  
                   '*** INVALID RUNDATE FORMAT             '.                   
           05  ERR-MESS2.                                                       
               10  FILLER                     PIC X(50)  VALUE                  
                   '*** FILE CONTROL DATE DOES NOT MATCH RUNDATE'.              
           05  ERR-MESS3.                                                       
               10  FILLER                     PIC X(50)  VALUE                  
                   '*** SEVERE ERROR - CHECK RESTART JCL   '.                   
      /                                                                         
       01  WS-ENDS                            PIC X(32)  VALUE                  
FXXTOK                                '** GC2RC3 W-S ENDS HERE **'.             
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO02'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2RC3'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       MAINLINE.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                PROGRAM MAINLINE                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 000-INITIALIZE.                                              
           IF WS-CONT-PROC-FLAG = 'Y'                                           
               PERFORM 100-PROCESS-GRACCTS THRU 100-EXIT                        
                   UNTIL EOF-ON-EXTRACT.                                        
           PERFORM 300-END-OF-JOB.                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'CLOSE FILES'      TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 350-READ-VCM-GIPSY THRU 350-READ-VCM-GIPSY-EXIT.             
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       000-INITIALIZE.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREAS TO BE ACCESSED                             *         
      *     GET RUN DATE AND FILE CONTROL DATE                        *         
      *     EDIT TO MAKE SURE YOU HAVE PICKED UP THE RIGHT FILE       *         
      *     GET CONTROL RECORD TO MAKE SURE THAT THE PREVIOUS STEPS   *         
      *         HAVE RUN SUCCESSFULLY.                                *         
      *     MODIFY THE CONTROL RECORD TO INDICATE THAT THIS STEP HAS  *         
      *         COMPLETED SUCCESSFULLY.                               *         
      *     PRINT HEADINGS ON ACTION REPORT                           *         
      *     READ FIRST EXTRACT RECORD                                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
FXXTOK     MOVE 'GC2RC3' TO PROGRAM-NAME.                                       
      *%   BIND RUN-UNIT.                                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND GWCORCNTL.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGRACCT.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORCOMP.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORAGENT.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGFO.                                                       
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORTRANS.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA3 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'OPEN FILES'       TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 350-READ-VCM-GIPSY THRU 350-READ-VCM-GIPSY-EXIT.             
                                                                                
           PERFORM 310-READ-RUNDATE THRU 310-EXIT.                              
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         PROGRAM-RUN-DATE                                  
MAN02                         WS-ALIS-RUN-DATE.                                 
           IF WS-ALIS-RUN-DATE = '****'                                         
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS1    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           PERFORM 290-READ-EXTRACT.                                            
           MOVE EXTRACT-NAP-REC TO FILE-CONTROL-DATE-RECORD.                    
                                                                                
           IF FILE-CONTROL-DATE EQUAL WS-ALIS-RUN-DATE                          
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS2    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
      *%   OBTAIN FIRST GWCORCNTL WITHIN GW-COMP-AREA1.                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 12 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           IF COMM-SCR-RECON-IND = 'Y' AND                                      
              NAP-RECON-IND = 'N' AND                                           
              RECON-DATE-UPDATE-IND = 'N'                                       
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'N' TO WS-CONT-PROC-FLAG                                    
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS3    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           MOVE 'Y' TO NAP-RECON-IND.                                           
      *%   MODIFY GWCORCNTL.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 13 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           MOVE 'Y' TO WS-CONT-PROC-FLAG.                                       
           MOVE WS-ALIS-RUN-DATE TO COMP-PROCESS-DATE.                          
           MOVE PROGRAM-RUN-DATE TO ACTION-DATE.                                
                                                                                
           MOVE ACTION-HDG-1 TO ACTION-LINE.                                    
           PERFORM 700-WRITE-REPORT.                                            
           MOVE ACTION-HDG-2 TO ACTION-LINE.                                    
           PERFORM 700-WRITE-REPORT.                                            
           MOVE ACTION-HDG-3 TO ACTION-LINE.                                    
           PERFORM 700-WRITE-REPORT.                                            
                                                                                
           PERFORM 290-READ-EXTRACT.                                            
      /                                                                         
       300-END-OF-JOB.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  TERMINATE ERROR REPORT.                                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE END-LINE TO ACTION-LINE.                                        
           PERFORM 700-WRITE-REPORT.                                            
           MOVE +4 TO DLSA-RET-CODE.                                            
           PERFORM 700-WRITE-REPORT.                                            
           MOVE +4 TO DLSR-RET-CODE.                                            
           PERFORM 310-READ-RUNDATE THRU 310-EXIT.                              
      /                                                                         
       310-READ-RUNDATE.                                                        
                                                                                
           CALL 'DLSREAD' USING DLSR-SYSNNN                                     
                                DLSR-RET-CODE                                   
                                PROGRAM-RUN-DATE-RECORD                         
                                DLSR-REC-SIZE                                   
                                DLSR-BLK-SIZE                                   
                                DLSR-FORMAT                                     
                                DLSR-REC-COUNT.                                 
                                                                                
           IF  DLSR-RET-CODE = 0                                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  DLSR-RET-CODE = 4                                            
                   MOVE 'Y' TO EOF-SWITCH                                       
               ELSE                                                             
                   DISPLAY 'ERROR READING RUNDATE - SYS019'                     
FXXTOK             GO TO 799-SQL-STATUS.                                        
       310-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------                     
      * VOCOMM VCM/GIPSY                                                        
       350-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       350-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
       100-PROCESS-GRACCTS.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  GET GPSY MASTER RECORD MATCHING EXTRACT                *         
      *        IF NOT FOUND                                           *         
      *           ABEND.                                              *         
      *     -  EXPAND GPSY MASTER RECORD                              *         
      *     -  INVOKE PROCESS AGENT                                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ KEYED (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES                    TO VGWI-SOURCE-SYSTEM.                
           MOVE 'READ KEYED'              TO VGWI-REQUEST.                      
           MOVE SPACES                    TO VGWI-COVERAGE-TYPE.                
           MOVE EXT-NAP-GROUP-NUMBER-N    TO VGWI-GROUP.                        
           MOVE EXT-NAP-GROUP-ACCOUNT     TO VGWI-ACCOUNT.                      
           MOVE 'GIPSY EXPANDED'          TO VGWI-LR-NAME.                      
           PERFORM 350-READ-VCM-GIPSY THRU 350-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           ELSE                                                                 
              IF VGWO-RET-SEVERE-ERROR                                          
FXXTOK           GO TO 799-SQL-STATUS.                                          
                                                                                
           MOVE 'N' TO NEW-ACCOUNT-IND.                                         
           MOVE EXT-NAP-SORT-KEY TO WS-PREV-KEY.                                
           PERFORM 110-PROCESS-AGENTS THRU 110-EXIT                             
               UNTIL NEW-ACCOUNT-READ OR EOF-ON-EXTRACT.                        
      /                                                                         
       100-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       110-PROCESS-AGENTS.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    -   INVOKE PROCESS-GFO                                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'N' TO NEW-AGENT-IND.                                           
           PERFORM 120-PROCESS-GFOS THRU 120-EXIT                               
               UNTIL NEW-AGENT-READ OR EOF-ON-EXTRACT.                          
                                                                                
       110-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       120-PROCESS-GFOS.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    -   INVOKE PROCESS-COMPS                                   *         
      *               RECONCILIATION                                  *         
      *               ERROR-REPORT.                                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'N' TO NEW-GFO-IND.                                             
           MOVE ZERO TO TOTAL-NAP-PAID                                          
                        TOTAL-NAP-EARNED                                        
                        TOT-NAP-PAID-AMEND-FY                                   
                        TOT-NAP-PAID-AMEND-RN.                                  
           PERFORM 200-PROCESS-COMPS THRU 290-EXIT                              
               UNTIL NEW-GFO-READ OR EOF-ON-EXTRACT.                            
           PERFORM 300-RECONCILIATION.                                          
                                                                                
       120-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       200-PROCESS-COMPS.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  CALC AMEND AMOUNT                                      *         
      *     -  CALC NAPS PAID/EARNED AMOUNT                           *         
      *     -  SAVE INPUT EXTRACT KEY                                 *         
      *     -  INVOKE ERROR-REPORT                                    *         
      *     -  READ NEXT EXTRACT                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  EXT-NAP-COMP-DISP = 'P'                                          
               IF  EXT-NAP-COMP-REASON = 'A'                                    
                   COMPUTE AMEND-RECOV-AMT ROUNDED =                            
                       (EXT-NAP-COMP-AMT / 12)                                  
                       * EXT-NAP-MONTHS * -1                                    
                   ADD AMEND-RECOV-AMT TO TOT-NAP-PAID-AMEND-FY                 
               ELSE                                                             
                   IF  EXT-NAP-COMP-REASON = 'B'                                
                       COMPUTE AMEND-RECOV-AMT ROUNDED =                        
                           (EXT-NAP-COMP-AMT / 12)                              
                           * EXT-NAP-MONTHS * -1                                
                       ADD AMEND-RECOV-AMT TO TOT-NAP-PAID-AMEND-RN             
                   ELSE                                                         
                       ADD EXT-NAP-COMP-AMT TO TOTAL-NAP-PAID                   
           ELSE                                                                 
               IF  EXT-NAP-COMP-DISP = 'E'                                      
                   ADD EXT-NAP-COMP-AMT TO TOTAL-NAP-EARNED                     
               ELSE                                                             
                   MOVE '2' TO ERROR-SWITCH                                     
                   PERFORM 600-ACTION-REPORT THRU 699-EXIT.                     
                                                                                
       290-READ-EXTRACT.                                                        
                                                                                
           MOVE EXT-NAP-SORT-KEY TO WS-PREV-KEY.                                
           CALL 'DLSREAD' USING DLSN-SYSNNN                                     
                                DLSN-RET-CODE                                   
                                EXTRACT-NAP-REC                                 
                                DLSN-REC-SIZE                                   
                                DLSN-BLK-SIZE                                   
                                DLSN-FORMAT                                     
                                DLSN-REC-COUNT.                                 
                                                                                
           IF  DLSN-RET-CODE = 0                                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  DLSN-RET-CODE = 4                                            
                   MOVE 'Y' TO EOF-SWITCH                                       
               ELSE                                                             
                   DISPLAY 'ERROR READING EXTRACT - ABEND' UPON CONSOLE         
FXXTOK             GO TO 799-SQL-STATUS.                                        
                                                                                
           IF  EOF-ON-EXTRACT                                                   
           THEN                                                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  EXT-NAP-GROUP-NUMBER = WS-PREV-GROUP                         
               AND EXT-NAP-GROUP-ACCOUNT = WS-PREV-ACCOUNT                      
               THEN                                                             
                   IF EXT-NAP-AGENT-NUMBER = WS-PREV-AGENT                      
                   THEN                                                         
                       IF EXT-NAP-GFO-NUMBER = WS-PREV-GFO                      
                       THEN                                                     
                           MOVE 'N' TO NEW-ACCOUNT-IND                          
                           MOVE 'N' TO NEW-AGENT-IND                            
                           MOVE 'N' TO NEW-GFO-IND                              
                       ELSE                                                     
                           MOVE 'Y' TO NEW-GFO-IND                              
                   ELSE                                                         
                       MOVE 'Y' TO NEW-AGENT-IND                                
                       MOVE 'Y' TO NEW-GFO-IND                                  
               ELSE                                                             
                   MOVE 'Y' TO NEW-ACCOUNT-IND                                  
                   MOVE 'Y' TO NEW-AGENT-IND                                    
                   MOVE 'Y' TO NEW-GFO-IND.                                     
       290-EXIT.                                                                
           EXIT.                                                                
                                                                                
      /                                                                         
       300-RECONCILIATION.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     FOR ANY BREAK ON GROUP OR ACCOUNT OR AGENT OR GFO         *         
      *        FOR ANY RECONCILIABLE AMOUNT                           *         
      *            INVOKE STORE-A-NAP-RECORD                          *         
      *            INVOKE STORE-A-COMP-RECORD.                        *         
      *    CLEAR TEMP W-S-TOTALS                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           SUBTRACT TOTAL-NAP-PAID FROM TOTAL-NAP-EARNED                        
               GIVING WS-RECON-AMT.                                             
                                                                                
           IF  WS-RECON-AMT = ZERO                                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'P' TO COMP-DISP OF GWCORCOMP                               
               MOVE 'Y' TO RECON-IND OF GWCORCOMP                               
               MOVE 'F' TO COMP-REASON OF GWCORCOMP                             
               PERFORM 400-CREATE-NAP-REC.                                      
                                                                                
           IF  TOT-NAP-PAID-AMEND-FY = ZERO                                     
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE TOT-NAP-PAID-AMEND-FY TO WS-RECON-AMT                       
               MOVE 'P' TO COMP-DISP OF GWCORCOMP                               
               MOVE 'N' TO RECON-IND OF GWCORCOMP                               
               MOVE 'A' TO COMP-REASON OF GWCORCOMP                             
               PERFORM 400-CREATE-NAP-REC.                                      
                                                                                
           IF  TOT-NAP-PAID-AMEND-RN = ZERO                                     
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE TOT-NAP-PAID-AMEND-RN TO WS-RECON-AMT                       
               MOVE 'P' TO COMP-DISP OF GWCORCOMP                               
               MOVE 'N' TO RECON-IND OF GWCORCOMP                               
               MOVE 'B' TO COMP-REASON OF GWCORCOMP                             
               PERFORM 400-CREATE-NAP-REC.                                      
                                                                                
      /                                                                         
       400-CREATE-NAP-REC.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     FORMAT NAP RECORD                                         *         
      *     INVOKE STORE NAP RECORD                                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'P' TO GNAP-RECORD-TYPE.                                        
           MOVE WS-PREV-GFO TO GNAP-GFO-OFFICE.                                 
                                                                                
           MOVE WS-PREV-GROUP TO GNAP-GROUP.                                    
           MOVE WS-PREV-ACCOUNT TO GNAP-ACCOUNT.                                
           MOVE WS-PREV-AGENT TO GNAP-AGENT-CODE.                               
           MOVE GGIFOGL-CODE (1) TO GNAP-FOGL-CODE.                             
           MOVE 'RC' TO GNAP-PREM-TYPE.                                         
           CALL 'GZNAEXP7' USING GBNBILLING-NAME-ADDRESS                        
                                 EXP-AREA                                       
                                 EXP-ERR-CODE.                                  
                                                                                
           IF  EXP-ERR-CODE = SPACES                                            
               MOVE EXP-NAME (1) TO GNAP-GROUP-NAME                             
           ELSE                                                                 
               MOVE SPACES TO GNAP-GROUP-NAME.                                  
                                                                                
           IF  WS-PREV-GFO = GGIGROUP-OFFICE                                    
           AND WS-PREV-GFO = GGISHARING-OFFICE                                  
           THEN                                                                 
               COMPUTE WS-RECON-AMT ROUNDED = WS-RECON-AMT / 2                  
               COMPUTE WS-COMP-AMT ROUNDED = WS-RECON-AMT * 1                   
               MOVE WS-COMP-AMT TO GNAP-AMOUNT                                  
               MOVE GGIGROUP-REP TO GNAP-GFO-REP                                
               PERFORM 450-STORE-NAP-RECORD                                     
               MOVE GGIGROUP-REP2 TO GNAP-GFO-REP                               
               PERFORM 450-STORE-NAP-RECORD                                     
           ELSE                                                                 
               COMPUTE WS-COMP-AMT ROUNDED = WS-RECON-AMT * 1                   
               MOVE WS-COMP-AMT TO GNAP-AMOUNT                                  
               IF  WS-PREV-GFO = GGIGROUP-OFFICE                                
               THEN                                                             
                   MOVE GGIGROUP-REP TO GNAP-GFO-REP                            
                   PERFORM 450-STORE-NAP-RECORD                                 
               ELSE                                                             
               IF  WS-PREV-GFO = GGISHARING-OFFICE                              
               THEN                                                             
                   MOVE GGIGROUP-REP2 TO GNAP-GFO-REP                           
                   PERFORM 450-STORE-NAP-RECORD                                 
               ELSE                                                             
                   MOVE '1' TO ERROR-SWITCH                                     
                   PERFORM 600-ACTION-REPORT THRU 699-EXIT.                     
      /                                                                         
       450-STORE-NAP-RECORD.                                                    
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     STORE NAP RECORD INTO DATA BASE TRANS AREA                *         
      *     INVOKE STORE COMP RECORD IN DATA BASE                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE GNAP-GFO-REP TO GNUM-REP.                                       
           CALL 'GNUMTABL' USING GNUM-TABLE                                     
                                 GNUM-REP                                       
                                 GNUM-RETURN.                                   
                                                                                
           IF  GNUM-RETURN-1-5 = SPACES                                         
               MOVE SPACES TO GNUM-RETURN.                                      
                                                                                
           MOVE GNUM-RETURN TO GNAP-REP-NAME.                                   
                                                                                
           MOVE 'NP' TO TRANS-TYPE.                                             
           MOVE GNAP-RECORD TO TRANS-DETAILS.                                   
           MOVE -1 TO DIRECT-DBKEY.                                             
      *%   STORE GWCORTRANS.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORTRANS                                       
MAN02                 FCCSPL-GWCORTRANS                                         
MAN02                 GWCORTRANS                                                
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           PERFORM 500-STORE-COMP-REC.                                          
      /                                                                         
       500-STORE-COMP-REC.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     GET OWNER GRACCT                                          *         
      *     GET OWNER AGENT                                           *         
      *     GET OWNER GFO                                             *         
      *     FORMAT COMP RECORD                                        *         
      *     STORE COMP RECORD                                         *         
      *     CONNECT COMP RECORD TO OWNER GFO RECORD                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
            IF  WS-PREV-GROUP = GROUP-NUMBER OF GWCORGRACCT                     
            AND WS-PREV-ACCOUNT = GR-ACCOUNT OF GWCORGRACCT                     
                NEXT SENTENCE                                                   
            ELSE                                                                
                MOVE WS-PREV-GROUP TO GROUP-NUMBER OF GWCORGRACCT               
                MOVE WS-PREV-ACCOUNT TO GR-ACCOUNT OF GWCORGRACCT               
      *%        OBTAIN CALC GWCORGRACCT.                                        
IOS             MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                     
IOS             MOVE 2 TO FCCSPL-DML-SEQ-NO                                     
IOS             MOVE +6  TO FCCSPL-ADDRESS-COUNT                                
MAN02           CALL GWFADDR                                                    
MAN02                USING FCCSPL-ADDRESS-AREA                                  
MAN02                      FCCSPL-SELECT-USING-PRIM-KEY                         
MAN02                      FCCSPLIO-GWCORGRACCT                                 
MAN02                      FCCSPL-GWCORGRACCT                                   
MAN02                      GWCORGRACCT                                          
MAN02                      FCCSPL-OBTAIN                                        
MAN02                      FCCSPL-NOKEEP                                        
IOS             END-CALL                                                        
FXXTOK          CALL GWFSPLB1                                                   
IOS                  USING DUMMY-PARM-1                                         
IOS                        DUMMY-PARM-2                                         
IOS                        DBLINK-SUBSCHEMA-CONTROL                             
IOS                        DBLINK-RECORD-SET-KEYS                               
IOS                        DBLINK-CURSOR-CODES                                  
IOS             END-CALL                                                        
IOS             PERFORM 799-SQL-STATUS                                          
IOS                THRU 799-SQL-STATUS-EXIT.                                    
                                                                                
            IF  WS-PREV-AGENT = AGENT-NUMBER OF GWCORAGENT                      
                NEXT SENTENCE                                                   
            ELSE                                                                
                MOVE WS-PREV-AGENT TO AGENT-NUMBER OF GWCORAGENT                
      *%        OBTAIN CALC GWCORAGENT.                                         
IOS             MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                     
IOS             MOVE 3 TO FCCSPL-DML-SEQ-NO                                     
IOS             MOVE +6  TO FCCSPL-ADDRESS-COUNT                                
MAN02           CALL GWFADDR                                                    
MAN02                USING FCCSPL-ADDRESS-AREA                                  
MAN02                      FCCSPL-SELECT-USING-PRIM-KEY                         
MAN02                      FCCSPLIO-GWCORAGENT                                  
MAN02                      FCCSPL-GWCORAGENT                                    
MAN02                      GWCORAGENT                                           
MAN02                      FCCSPL-OBTAIN                                        
MAN02                      FCCSPL-NOKEEP                                        
IOS             END-CALL                                                        
FXXTOK          CALL GWFSPLB1                                                   
IOS                  USING DUMMY-PARM-1                                         
IOS                        DUMMY-PARM-2                                         
IOS                        DBLINK-SUBSCHEMA-CONTROL                             
IOS                        DBLINK-RECORD-SET-KEYS                               
IOS                        DBLINK-CURSOR-CODES                                  
IOS             END-CALL                                                        
IOS             PERFORM 799-SQL-STATUS                                          
IOS                THRU 799-SQL-STATUS-EXIT.                                    
                                                                                
            IF  WS-PREV-GFO = GFO-NUMBER OF GWCORGFO                            
                NEXT SENTENCE                                                   
            ELSE                                                                
                MOVE WS-PREV-GFO TO GFO-NUMBER OF GWCORGFO                      
      *%        OBTAIN CALC GWCORGFO                                            
IOS             MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                     
IOS             MOVE 4 TO FCCSPL-DML-SEQ-NO                                     
IOS             MOVE +6  TO FCCSPL-ADDRESS-COUNT                                
MAN02           CALL GWFADDR                                                    
MAN02                USING FCCSPL-ADDRESS-AREA                                  
MAN02                      FCCSPL-SELECT-USING-PRIM-KEY                         
MAN02                      FCCSPLIO-GWCORGFO                                    
MAN02                      FCCSPL-GWCORGFO                                      
MAN02                      GWCORGFO                                             
MAN02                      FCCSPL-OBTAIN                                        
MAN02                      FCCSPL-NOKEEP                                        
IOS             END-CALL                                                        
FXXTOK          CALL GWFSPLB1                                                   
IOS                  USING DUMMY-PARM-1                                         
IOS                        DUMMY-PARM-2                                         
IOS                        DBLINK-SUBSCHEMA-CONTROL                             
IOS                        DBLINK-RECORD-SET-KEYS                               
IOS                        DBLINK-CURSOR-CODES                                  
IOS             END-CALL                                                        
IOS             IF NOT DB-REC-NOT-FOUND                                         
IOS                PERFORM 799-SQL-STATUS-02                                    
IOS                   THRU 799-SQL-STATUS-02-EXIT                               
IOS             ELSE                                                            
      *%            STORE GWCORGFO.                                             
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 5 TO FCCSPL-DML-SEQ-NO                                  
IOS                MOVE +4  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-INSERT                                     
MAN02                         FCCSPLIO-GWCORGFO                                 
MAN02                         FCCSPL-GWCORGFO                                   
MAN02                         GWCORGFO                                          
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT.                                 
                                                                                
           MOVE GNAP-GROUP TO GROUP-NUMBER OF GWCORCOMP.                        
           MOVE GNAP-ACCOUNT TO GR-ACCOUNT OF GWCORCOMP.                        
           MOVE NEXT-RECON-DATE OF GWCORGRACCT                                  
               TO COMP-EFF-DATE OF GWCORCOMP.                                   
           MOVE GNAP-AGENT-CODE TO AGENT-NUMBER OF GWCORCOMP.                   
           MOVE GNAP-GFO-OFFICE TO GFO-NUMBER OF GWCORCOMP.                     
           MOVE GNAP-GFO-REP TO GROUP-REP OF GWCORCOMP.                         
           MOVE WS-ALIS-RUN-DATE TO COMP-PROCESS-DATE OF GWCORCOMP.             
           MOVE '#' TO COV-TYPE OF GWCORCOMP.                                   
           MOVE 'N' TO COMP-TYPE OF GWCORCOMP.                                  
           MOVE GNAP-AMOUNT TO COMP-AMT OF GWCORCOMP.                           
           MOVE 100 TO AGENT-SPLIT OF GWCORCOMP.                                
           MOVE ZERO TO PREM-AMT OF GWCORCOMP.                                  
      *%   STORE GWCORCOMP.                                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 GWCORCOMP                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   CONNECT GWCORCOMP TO GFO-COMP.                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +5  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-CREATE-RELATIONSHIP                                
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GFO-COMP                                           
MAN02                 GWCORCOMP                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      /                                                                         
       600-ACTION-REPORT.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  FORMAT ACTION REPORT                                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  WS-PREV-GROUP = ZERO                                             
               GO TO 699-EXIT.                                                  
                                                                                
           IF  ERROR-GFO                                                        
               MOVE WS-PREV-GROUP TO ACTION-GROUP                               
               MOVE WS-PREV-ACCOUNT TO ACTION-ACCOUNT                           
               MOVE WS-PREV-AGENT TO ACTION-AGENT                               
               MOVE WS-PREV-GFO TO ACTION-GFO                                   
               MOVE 'N' TO ACTION-TYPE                                          
               MOVE 'P' TO ACTION-DISP                                          
               MOVE COMP-REASON OF GWCORCOMP TO ACTION-REASON                   
               MOVE WS-RECON-AMT TO ACTION-AMT                                  
               MOVE ACTION-MSG-1 TO ACTION-MSG                                  
           ELSE                                                                 
           IF  ERROR-DISP                                                       
               MOVE EXT-NAP-GROUP-NUMBER-N TO ACTION-GROUP                      
               MOVE EXT-NAP-GROUP-ACCOUNT TO ACTION-ACCOUNT                     
               MOVE EXT-NAP-AGENT-NUMBER TO ACTION-AGENT                        
               MOVE EXT-NAP-GFO-NUMBER TO ACTION-GFO                            
               MOVE EXT-NAP-COMP-TYPE TO ACTION-TYPE                            
               MOVE EXT-NAP-COMP-DISP TO ACTION-DISP                            
               MOVE EXT-NAP-COMP-REASON TO ACTION-REASON                        
               MOVE EXT-NAP-COMP-AMT TO ACTION-AMT                              
               MOVE ACTION-MSG-2 TO ACTION-MSG                                  
           ELSE                                                                 
               MOVE ZERO   TO ACTION-GROUP                                      
               MOVE ZERO   TO ACTION-ACCOUNT                                    
               MOVE ZERO   TO ACTION-AGENT                                      
               MOVE ZERO   TO ACTION-GFO                                        
               MOVE SPACES TO ACTION-TYPE                                       
               MOVE SPACES TO ACTION-DISP                                       
               MOVE SPACES TO ACTION-REASON                                     
               MOVE ZERO   TO ACTION-AMT                                        
               MOVE ACTION-MSG-3 TO ACTION-MSG.                                 
                                                                                
           MOVE ACTION-DETAIL TO ACTION-LINE.                                   
           PERFORM 700-WRITE-REPORT.                                            
                                                                                
       699-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       700-WRITE-REPORT.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   -  WRITE ACTION REPORT                                     *          
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLSA-SYSNNN                                    
                                 DLSA-RET-CODE                                  
                                 ACTION-LINE                                    
                                 DLSA-REC-SIZE                                  
                                 DLSA-BLK-SIZE                                  
                                 DLSA-FORMAT                                    
                                 DLSA-REC-COUNT.                                
                                                                                
           IF  DLSA-RET-CODE = +0                                               
                            OR +4                                               
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS021' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       WTL-TO-OPERATOR.                                                         
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           CALL 'WTL' USING WTL-MESSAGE-AREA                                    
                            WTL-FLAG                                            
                            WTL-REPLY                                           
                            WTL-REPLY-AREA.                                     
       WTL-TO-OPERATOR-EXIT.                                                    
           EXIT.                                                                
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
