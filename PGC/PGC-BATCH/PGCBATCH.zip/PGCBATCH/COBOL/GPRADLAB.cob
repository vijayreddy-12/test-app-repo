       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRADLAB.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS.                                                                 
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  START                          *         
      *****************************************************************         
      *                                                               *         
      *  AUG/89  M DRURY  - ADD TWO NEW FIELDS TO ERROR FILE                    
      *                   - CHANGE ERROR RECORD TO COPY BOOK  ERRREC            
      *                   - CHANGE TAPE-RECORD TO  COPY BOOK  GADDRLAB          
      *                                                                         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  END                            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *                                                               *         
      *                                                               *         
      *DATE-WRITTEN.  MODIFIED MAY 1984.                                        
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77   FILLER                           PIC X(50)   VALUE                  
            '***** START OF WORKING STORAGE FOR          *****'.                
       01  FORM-LABEL      VALUE '41'              PIC XX.                      
       01  PRINT-SYS017              PIC X(06) VALUE 'SYS017'.                  
       01  PRINT-SYS017-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
                                                                                
       01  SUBSCRIPTS.                                                          
           05  SUB1        COMP SYNC   VALUE +0    PIC S9(4).                   
           05  SUB2        COMP SYNC   VALUE +0    PIC S9(4).                   
                                                                                
       01  TRAILER-000-AREA.                                                    
GNE     COPY  WMGENTR7 REPLACING                                                
                                             ==01  WMGENTR.== BY ====.          
                                                                                
       01  TRAILER-030-AREA REDEFINES TRAILER-000-AREA.                         
        COPY  WMBNATR7                                                          
                                                            REPLACING           
                                             ==01  WMBNATR7.== BY ====.         
                                                                                
                                                                                
       01  TRLR-AREA REDEFINES TRAILER-030-AREA.                                
           03  TRLR-ID                             PIC X(3).                    
                                                                                
       01  NA-EXP.                                                              
           03  NA-LINE     OCCURS  6.                                           
               05  NA-LN                           PIC X(30).                   
               05  NA-DEL                          PIC X.                       
                                                                                
      *                                                                         
      *    CHANGE TO COPY BOOK FOR ERROR FILE         MARCUS.                   
      *                                                                         
GNE        COPY GERRREC7.                                                       
                                                                                
GNE    01  GACCDMAS-PARMS.                                                      
GNE        03  GACCDMAS-1.                                                      
GNE            05  GACCDMAS-FUNC-CODE     PIC S9(4)  VALUE +2 COMP.             
GNE            05  GACCDMAS-GRP-INFO.                                           
GNE                07  GACCDMAS-GROUP     PIC S9(7)  VALUE +0  COMP-3.          
GNE                07  GACCDMAS-ACCT      PIC XXX    VALUE LOW-VALUES.          
GNE            05  FILLER                 PIC X(9)   VALUE SPACES.              
GNE        03  GACCDMAS-ERR               PIC X(3)   VALUE SPACES.              
GNE                                                                             
GNE        COPY GMASTER7.                                                       
       01  PRINT-AREA          VALUE SPACES.                                    
           05  PR-GROUP                    PIC 9(7).                            
           05  PR-ACCT                     PIC XXX.                             
           05  PR-LINES    OCCURS  6.                                           
               07  PR-NA                           PIC X(30).                   
               05  NA-DEL                          PIC X.                       
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
GNE        05  GACBMAS7                  PIC X(8)  VALUE 'GACBMAS7'.            
       LINKAGE SECTION.                                                         
      *                                                                         
      * CHANGE TAPE-REC FROM HARD CODED TO COPY BOOK   MARCUS.                  
      *                                                                         
      *01  TAPE-REC.                                                            
      *    03  FILLER                              PIC X(4).                    
      *    03  T-REC-TYPE                          PIC X.                       
      *    03  T-FORM                              PIC X.                       
      *    03  T-GRP-OFF                           PIC X(5).                    
      *    03  T-GROUP         COMP-3              PIC S9(5).                   
      *    03  T-ACCT                              PIC XXX.                     
GNE        COPY GADDRLA7.                                                       
                                                                                
       01  MISC-AREA.                                                           
           03  FILLER                              PIC X(16).                   
           03  R-INFO.                                                          
               05  R-REC-TYPE                      PIC X.                       
GNE            05  R-GROUP                         PIC X(7).                    
GNE        03  FILLER                              PIC X(08).                   
                                                                                
       01  PRINT-PARAMETERS.                                                    
        COPY  GPRPRINT  REPLACING                                               
                                            ==01  GPRPRINT.== BY ====.          
                                                                                
       01  TAPE-PARAMETERS.                                                     
        COPY  GPRTPARM  REPLACING                                               
                                            ==01  GPRTPARM.== BY ====.          
                                                                                
       01  REPORT-ACCUMULATORS.                                                 
        COPY  GPRACCUM  REPLACING                                               
                                            ==01  GPRACCUM.== BY ====.          
                                                                                
       PROCEDURE DIVISION USING LABEL-REC                                       
                                MISC-AREA                                       
                                PRINT-PARAMETERS                                
                                TAPE-PARAMETERS                                 
                                REPORT-ACCUMULATORS.                            
       GPRADLAB-STARTUP.                                                        
      *                                                                         
      *  SET UP THE ERROR RECORD RECORD TYPE              MARCUS.               
      *                                                                         
           MOVE '4'     TO  E-REC-TYPE.                                         
           IF  R-GROUP   EQUAL TO  HIGH-VALUES                                  
               GO  TO  NEW-LABELS.                                              
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-LABEL.                                    
                                                                                
       NEW-LABELS.                                                              
           PERFORM   GET-MAST  THRU  GM-OUT.                                    
           IF  R-GROUP   EQUAL TO  HIGH-VALUES                                  
               GO  TO  NEW-LABELS.                                              
           ADD +1 TO ACCUM-LABELS.                                              
           PERFORM   PRINT-LABELS.                                              
           GO  TO  NEW-LABELS.                                                  
                                                                                
       GET-MAST.                                                                
                                                                                
           MOVE  '000'         TO  TRLR-ID.                                     
           PERFORM GET-TRLR.                                                    
           IF E-CODE     NOT  EQUAL TO    SPACES                                
              MOVE ' ' TO W-GGICOUNTRY                                          
              GO  TO  ERR-RTN.                                                  
           IF W-GGICOUNTRY NOT EQUAL '0'                                        
              MOVE '1' TO W-GGICOUNTRY.                                         
           MOVE LAB-GROUP     TO  PR-GROUP.                                     
           MOVE LAB-ACCT      TO  PR-ACCT.                                      
                                                                                
           MOVE  '030'         TO  TRLR-ID.                                     
           PERFORM   GET-TRLR.                                                  
           IF  E-CODE     NOT EQUAL TO   SPACES                                 
               MOVE ' ' TO W-GGICOUNTRY                                         
               GO  TO  ERR-RTN.                                                 
GNE   *    CALL  GZNAEXP7    USING   TRLR-AREA                                  
GNE   *                                NA-EXP                                   
GNE   *                                E-CODE.                                  
GNE        MOVE LAB-GROUP     TO  GACCDMAS-GROUP.                               
GNE        MOVE LAB-ACCT      TO  GACCDMAS-ACCT.                                
GNE        CALL GACBMAS7 USING GACCDMAS-1                                       
GNE                              GACCDMAS-ERR                                   
GNE                              GMASTER7.                                      
GNE                                                                             
GNE        MOVE GBNBILL-NAME-ADDR TO NA-EXP.                                    
           IF  E-CODE     NOT EQUAL TO   SPACES                                 
               MOVE ' ' TO W-GGICOUNTRY                                         
               GO  TO  ERR-RTN.                                                 
           PERFORM   MOVE-NA                                                    
                   VARYING  SUB1  FROM  +1  BY  +1                              
                       UNTIL  SUB1  GREATER THAN  +6.                           
                                                                                
       NEXT-REC.                                                                
           PERFORM   READ-TAPE.                                                 
                                                                                
       GM-OUT.                                                                  
           EXIT.                                                                
                                                                                
      *                                                                         
      *                     MISCELLANEOUS SUBROUTINES                           
      *                                                                         
       READ-TAPE.                                                               
           CALL  'DLSREAD' USING TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 LABEL-REC                                      
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
           IF  TAPE-RETURN NOT EQUAL TO  ZEROS                                  
                 OR  LAB-REC-TYPE NOT EQUAL TO '4'                              
             IF  R-GROUP NOT EQUAL TO  HIGH-VALUES                              
               ADD +1 TO ACCUM-LABELS                                           
               PERFORM   PRINT-LABELS                                           
                   VARYING  SUB1  FROM  +1  BY  +1                              
                       UNTIL   SUB1  GREATER THAN  +6                           
                 GO  TO  RETURN-RTN                                             
                                         ELSE                                   
               GO  TO  RETURN-RTN.                                              
                                                                                
       GET-TRLR.                                                                
GNE        CALL  GZACCMT7    USING   LAB-GROUP                                  
GNE                                    TRLR-AREA                                
GNE                                    E-CODE.                                  
                                                                                
       ERR-RTN.                                                                 
           MOVE  LAB-GROUP     TO  E-GROUP.                                     
           MOVE  LAB-ACCT      TO  E-ACCT.                                      
      *                                                                         
      * SET UP THE TWO NEW FIELDS ON THE ERROR REC.        MARCUS               
      *                                                                         
           MOVE  LAB-PROD-CODE   TO    E-PROD-CD.                               
           MOVE  LAB-GRP-OFF     TO    E-OFFICE.                                
           MOVE  W-GGICOUNTRY    TO    E-COUNTRY.                               
           CALL  'DLSWRITE'      USING TAPE-SYS011                              
                                       TAPE-RETURN                              
                                       ERR-REC                                  
                                       TAPE-SYS011-RECSIZE                      
                                       TAPE-SYS011-BLKSIZE                      
                                       TAPE-SYS011-FORMAT                       
                                       TAPE-SYS011-COUNT.                       
           MOVE  SPACES          TO    E-CODE.                                  
           PERFORM   READ-TAPE.                                                 
           GO  TO  GET-MAST.                                                    
                                                                                
       PRINT-LABELS.                                                            
           CALL 'DLSWRITE' USING PRINT-SYS017                                   
                                 PRINT-RETURN                                   
                                 PRINT-AREA                                     
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS017-COUNT.                            
                                                                                
           MOVE  SPACES        TO  PRINT-AREA.                                  
                                                                                
       MOVE-NA.                                                                 
           MOVE  NA-LN (SUB1)    TO  PR-NA (SUB1).                              
                                                                                
       RETURN-RTN.                                                              
           GOBACK.                                                              
