       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. GPRSOAR4.                                                    
      *This program has been examined/renovated for Year 2000 compliance.       
      *DATE-WRITTEN.  FEB-90                                                    
      *DATE-COMPILED.                                                           
      *****************************************************************         
      *                  REPORT FOR GFO                                         
      *                     REPORT-NUMBER 4.                                    
      *                     SORT ORDER   GFO   , GROUP.                         
      *                                                                         
      *                                                                         
      *          SHOWS ALL GROUPS FOR WHICH A LAPSE NOTICE HAS BEEN             
      *          PRODUCED AND CLAIMS HAVE BEEN SUSPENDED.                       
      *          THIS MODULE INTERIGATES REPORT TYPE "H" AND IF TYPE            
      *          "B" CALLS GROUP OFFICE OVERDUE PREMIUM REPORT                  
      *          MODULE.                                                        
      *                                                                         
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *  FEB-90   MIKE BURTON -- CREATION.                            *         
      *                                                               *         
      *  JUN/98   J ELKINS - CHANGE SORT ORDER OF REPORT TO           *         
      *                      GFO, ACCT MGR, GROUP/ACCT                *         
      *                    - TOTALS AND PAGE BREAK BY ACCT MGR        *         
      *                    - ADD PRODUCER'S NAME TO DETAIL LINES      *         
      *                      USING GFMAGENT                           *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *                                                               *         
      *                                                               *         
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  BRANCH-GFO-FIELD.                                                    
           05   BRANCH-GFO           PIC XX.                                    
           05   FILLER               PIC X(3).                                  
                                                                                
       01  FIRST-TIME                PIC X.                                     
                                                                                
       01  PRINT-SYS036              PIC X(06) VALUE 'SYS036'.                  
       01  PRINT-SYS036-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
                                                                                
       01  SUMMARY-TOTAL-SW          PIC X.                                     
       01  PRINT-HEADER-PAGE-SW      PIC X.                                     
       01  FILLER  COMP.                                                        
               05  WS-LINE-COUNT VALUE +0           PIC S9(4).                  
               05  WS-LNE-CNT    VALUE +0           PIC S9(4).                  
       01  FILLER.                                                              
           03  WS-PAGE-NUMBER    VALUE +0    COMP-3 PIC S9(5).                  
           03  WS-STORE-GFO      VALUE ZEROS        PIC X(5).                   
           03  WS-STORE-REP      VALUE ZEROS        PIC 9(5).                   
           03  WS-QDATE-AC       VALUE 'AC'         PIC X(2).                   
           03  WS-NEW            VALUE 'N'          PIC X(1).                   
           03  WS-NEW-MSGE                          PIC X(20)                   
               VALUE 'NEW/NOT SUSP        '.                                    
           03  WS-HOLD-DATA                        PIC X(133).                  
           03  WS-HOLD-DATA2                       PIC X(133).                  
           03  FORM-STANDARD-ONCE VALUE '91'       PIC X(2).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *            ACCOUNT REP NUMBER AND TOTALS                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-CURR-STATUS.                                                  
               05  WS-CURR-REP                      PIC 9(5).                   
               05  WSRT-PREM-AMT   COMP-3           PIC S9(7)V99.               
               05  WSRT-CURR-PREM  COMP-3           PIC S9(7)V99.               
               05  WSRT-TOT-PREM   COMP-3           PIC S9(7)V99.               
      *----------------------------------------------------------------*        
      *                                                                *        
      *            GFO NUMBER AND TOTALS                               *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-GFO-STATUS.                                                   
               05  WS-CURR-GFO                     PIC X(5).                    
               05  WSGT-PREM-AMT   COMP-3          PIC S9(7)V99.                
               05  WSGT-CURR-PREM  COMP-3          PIC S9(7)V99.                
               05  WSGT-TOT-PREM   COMP-3          PIC S9(7)V99.                
           03  WS-TABLE-STATUS OCCURS 40 TIMES     PIC X(20).                   
       01  WS-VARIABLES.                                                        
           03  SYNCED-VARIABLES  COMP.                                          
MAN07          05  WS-CURR-SUB   VALUE +1          PIC S9(4) COMP.              
MAN07          05  WS-MAX-SUB    VALUE +40         PIC S9(4) COMP.              
               05  WS-CURR-TOT   VALUE +1          PIC S9(4).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  END OF REPORT TOTALS                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-ENDTOT-PREM    VALUE +0  COMP-3  PIC S9(7)V99.                
           03  WS-ENDTOT-CURR    VALUE +0  COMP-3  PIC S9(7)V99.                
           03  WS-ENDTOT-TOT     VALUE +0  COMP-3  PIC S9(7)V99.                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                     REPORT HEADINGS                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-HEAD1.                                                        
               05  FILLER        VALUE 'GPRSOAR4'    PIC X(8).                  
               05  FILLER        VALUE SPACES        PIC X(39).                 
               05  FILLER                            PIC X(32)  VALUE           
           'LAPSE NOTICES MAILED - ALPHAPLUS'.                                  
               05  FILLER        VALUE SPACES        PIC X(13).                 
               05  FILLER        VALUE 'REPORT DATE' PIC X(12).                 
               05  WS-HD1-DATE                       PIC X(7).                  
               05  FILLER        VALUE SPACES        PIC X(9).                  
               05  FILLER        VALUE 'PAGE '       PIC X(5).                  
               05  WS-HD1-PAGE   VALUE ZEROS         PIC ZZZZ9.                 
           03  WS-HEAD2.                                                        
               05  FILLER        VALUE SPACES        PIC X(23).                 
               05  FILLER                            PIC X(79)  VALUE           
           'THE FOLLOWING GROUP ACCOUNTS ARE NOW IN ARREARS AND COVERAGE        
      -    ' HAS BEEN SUSPENDED'.                                               
           03  WS-HEAD2A.                                                       
               05  FILLER        VALUE 'OFFICE '     PIC X(7).                  
               05  WS-HD2A-OFFICE                    PIC X(5).                  
               05  FILLER                            PIC X(21) VALUE            
           '     ACCOUNT MANAGER '.                                             
               05  WS-HD2A-REP                       PIC 9(5).                  
               05  FILLER        VALUE SPACES        PIC X(2).                  
               05  WS-HD2A-REP-NAME                  PIC X(20).                 
           03  WS-HEAD3.                                                        
               05  FILLER        VALUE SPACES        PIC X(1).                  
 GNE           05  FILLER                            PIC X(86)  VALUE           
 GNE   'GROUP     ACC PRODUCER  NAME               GROUP  NAME                  
 GNE  -'OVERDUE       PREMIUM '.                                                
               05  FILLER                            PIC X(41)  VALUE           
           '      CURRENT         TOTAL   CLAIMS SUSP'.                         
           03  WS-HEAD-3-SUM-PAGE  REDEFINES WS-HEAD3.                          
               05  FILLER                            PIC X.                     
               05  WS-HEAD3-COL-1                    PIC X(5).                  
               05  FILLER                            PIC X(117).                
           03  WS-HEAD4.                                                        
 GNE           05  FILLER                            PIC X(89)  VALUE           
 GNE       ' NUMBER     NO                                                      
 GNE  -    '     DATE DUE       AMOUNT'.                                        
               05  FILLER                            PIC X(39)  VALUE           
           'PREMIUM DUE   PREMIUM DUE   EFFECT DATE'.                           
           03  WS-HEAD-4-SUM-PAGE  REDEFINES WS-HEAD4.                          
               05  FILLER                            PIC X.                     
               05  WS-HEAD4-COL-1                    PIC X(6).                  
               05  FILLER                            PIC X(116).                
           03  WS-HEAD5.                                                        
               05  FILLER                            PIC X(17)  VALUE           
                   SPACES.                                                      
               05  FILLER                            PIC X(09)  VALUE           
                   'GFO    - '.                                                 
               05  WS-HD5-GFO    VALUE SPACES        PIC X(06).                 
               05  FILLER                            PIC X(40)  VALUE           
           '  FOR INFORMATION ONLY'.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   DETAIL LINE STRUCTURE                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-DETAIL1.                                                      
               05  FILLER                            PIC X(1).                  
GNE            05  WSD-GROUP                         PIC Z(7).                  
               05  FILLER                            PIC X(3).                  
               05  WSD-ACCT                          PIC X(3).                  
               05  FILLER                            PIC X(1).                  
               05  WSD-PRODUCER                      PIC X(6).                  
               05  FILLER                            PIC X(1).                  
               05  WSD-PRODUCER-NAME                 PIC X(17).                 
               05  FILLER                            PIC X(1).                  
               05  WSD-GRPNAME                       PIC X(23).                 
               05  FILLER                            PIC X(2).                  
               05  WSD-OVDU-DATE                     PIC X(7).                  
               05  FILLER                            PIC X(2).                  
               05  WSD-PREM-AMT                      PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WSD-CURR-PREM                     PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WSD-TOT-PREM                      PIC Z,ZZZ,ZZZ.99-.         
               05  WSD-CLAIM.                                                   
                   07  FILLER                        PIC X(4).                  
                   07  WS-CLMSUS-DATE                PIC X(7).                  
                   07  FILLER                        PIC X(9).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  TOTAL LINE STRUCTURE                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-TOTAL1.                                                       
               05  WS-COMPANY-HD.                                               
                   07  FILLER                        PIC X(1).                  
                   07  WS-TOT-GRP   VALUE SPACES     PIC X(5).                  
                   07  FILLER                        PIC X(3).                  
                   07  WS-TOT-HD                     PIC X(7).                  
               05  FILLER                            PIC X(58).                 
               05  WS-TOT-PREM-AMT                   PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WS-TOT-CURR-PREM                  PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WS-TOT-TOT-PREM                   PIC Z,ZZZ,ZZZ.99-.         
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   REPORT END LITERIALS                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-COMPANY-MSGE                       PIC X(14)                  
               VALUE 'COMPANY  TOTAL'.                                          
           03  WS-TOTAL-MSGE   VALUE '  TOTAL'         PIC X(7).                
      *                                                                         
       01  GNUMONIC-WORK-AREA.                                                  
           05  GNUM-TABLE      VALUE +34 COMP SYNC   PIC S9(4).                 
           05  GNUM-REP                              PIC X(5).                  
           05  GNUM-RETURN.                                                     
               10  GNUM-RETURN-1-5                   PIC X(5).                  
               10  FILLER                            PIC X(15).                 
      *                                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   GFMAGENT PARAMETERS (USES ZACCVSAM           *        
      *                                        FROM GFMAACVS)          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  GFMAGENT-PARMS.                                                      
           05  GFMAGENT-FUNCTION    VALUE SPACES     PIC X(6).                  
           05  GFMAGENT-ERROR       VALUE SPACES     PIC X(5).                  
           05  GFMAGENT-KEY.                                                    
               10  GFMAGENT-CODE    VALUE ZERO       PIC S9(7) COMP-3.          
               10  GFMAGENT-ACCOUNT VALUE SPACES     PIC X(1).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   AGENT NAME FILE                              *        
      *                                                                *        
      *----------------------------------------------------------------*        
         COPY EAGNFILE.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 BUILDING NAME TRAILER  030                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
                                                                                
       COPY GMBNATR.                                                            
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *               WORK AREA TO EXPAND GROUP NAME                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WS-NMADDR.                                                           
           03  WS-NAME-ADDR OCCURS 6 TIMES.                                     
               05  WS-NA-LN                          PIC X(30).                 
               05  FILLER                            PIC X(1).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *          WORK DISK USED FOR SECOND COPY OF REPORT              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WS-WORK-DISK.                                                        
           03  WS-WKD-LENGTH   VALUE +137 COMP SYNC  PIC S9(4).                 
           03  FILLER          VALUE LOW-VALUE       PIC X(2).                  
           03  WS-WKD-DATA.                                                     
               05  WS-WKD-CC                         PIC X(1).                  
               05  WS-WKD-AREA.                                                 
                   07  FILLER                        PIC X(1).                  
                   07  WS-WKD-OVFLW-GFO              PIC X(5).                  
                   07  FILLER                        PIC X(126).                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     WORK DISK USED FOR ERROR OCCURRING GPRINTAL PROCESSING     *        
      *                                                                *        
      *    CHANGE TO A COPY BOOK FOR THE ERROR RECORD.     MARCUS.     *        
      *----------------------------------------------------------------*        
                                                                                
GNE        COPY GERRREC7.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      FROM GIPSY PRINT FILE GROUP OFFICE ARREAR RECORD          *        
      *                                                                *        
      *----------------------------------------------------------------*        
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
       LINKAGE SECTION.                                                         
       01  ARR-RECORD.                                                          
GNE                    COPY GGFOARR7.                                           
      *----------------------------------------------------------------*        
      *                                                                *        
      *               FROM GPRINTAL DRIVER MODULE                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LSMISC-AREA.                                                         
           03  FILLER                                PIC X(4).                  
           03  LSM-HIDATE                            PIC X(4).                  
           03  LSM-STATDATE                          PIC X(4).                  
           03  LSM-PREMDATE                          PIC X(4).                  
           03  LSM-RESTART.                                                     
               05  LSR-RECTYPE                       PIC X(1).                  
               05  LSR-REPTYPE                       PIC X(1).                  
               05  LSR-GRPOFF                        PIC X(5).                  
               05  FILLER                            PIC X(7).                  
           03  FILLER                                PIC X(4).                  
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         PRINT PARAMETER COPY BOOK FOR SYS022 TO SYS029         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRPRINT.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         TAPE PARAMETER COPY BOOK FOR SYS011 AND SYS014         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRTPARM.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             REPORT ACCUMULATOR COPY BOOK                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRACCUM.                                                          
                                                                                
       PROCEDURE DIVISION USING ARR-RECORD                                      
                                LSMISC-AREA                                     
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   INITIALIZE ROUTINE                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *    DISPLAY '----------> GPRSOAR4 <---------'.                           
      *    READY TRACE.                                                         
           IF   ARR-TYPE      =    'H'                                          
            AND ARR-REPORT    =    'A'                                          
               GO TO INIT-ROUTINE.                                              
       UB-MODULE-CALL.                                                          
           CALL 'GPRSOOPR' USING ARR-RECORD                                     
                                 LSMISC-AREA                                    
                                 GPRPRINT                                       
                                 GPRTPARM                                       
                                 GPRACCUM.                                      
           GO TO END-OPERATIONS.                                                
       INIT-ROUTINE.                                                            
           MOVE 'Y' TO FIRST-TIME.                                              
           MOVE 'N' TO SUMMARY-TOTAL-SW.                                        
           MOVE 'Y' TO PRINT-HEADER-PAGE-SW.                                    
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-STANDARD-ONCE.                            
           CALL 'ZLINECT' USING WS-LINE-COUNT.                                  
           SUBTRACT +5 FROM WS-LINE-COUNT.                                      
           MOVE WS-LINE-COUNT  TO WS-LNE-CNT.                                   
           MOVE ZEROS          TO WS-STORE-GFO.                                 
           PERFORM ZERO-COUNTERS-BGN THRU                                       
                   ZERO-COUNTERS-END.                                           
           CALL 'QDATE' USING WS-QDATE-AC                                       
                              LSM-HIDATE                                        
                              WS-HD1-DATE.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *       PROCESS TAPE RECORD READ FROM GIPSY PRINT FILE           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       REPORT4-PROCESSING.                                                      
           IF   ARR-TYPE     NOT  =    'H'                                      
               GO TO END-OF-REPORT4.                                            
           IF   ARR-REPORT   NOT  =    'A'                                      
               GO TO END-OF-REPORT4.                                            
           IF   ARR-REPORT-NUMBER NOT  =  '4'                                   
               GO TO END-OF-REPORT4.                                            
                                                                                
      *    THIS REPORT IS TO INCLUDE ALL ALPHA CASES AND                        
      *    AGENTS                                                               
                                                                                
           IF ARR-PCODE = '1'                                                   
              NEXT SENTENCE                                                     
           ELSE                                                                 
              GO TO READ-RECORD.                                                
      *       IF (ARR-SRT-PD-AGENT < 90000 OR                                   
      *        ( ARR-SRT-PD-AGENT > 299999 AND                                  
      *          ARR-SRT-PD-AGENT < 900000 ))                                   
      * AGENT                                                                   
      *          GO TO READ-RECORD                                              
      *        ELSE                                                             
      * BROKER                                                                  
      *        MOVE ARR-SRT-PD-GFO TO BRANCH-GFO-FIELD                          
      *        IF BRANCH-GFO = '10'                                             
      *           GO TO READ-RECORD                                             
      *        ELSE                                                             
      *           NEXT SENTENCE.                                                
                                                                                
           IF FIRST-TIME = 'Y'                                                  
              MOVE 'N'            TO FIRST-TIME                                 
              MOVE ARR-SRT-PD-REP TO WS-CURR-REP                                
              MOVE ARR-SRT-PD-GFO TO WS-CURR-GFO.                               
                                                                                
           MOVE SPACES           TO WS-DETAIL1.                                 
           MOVE ARR-SRT-PD-GROUP TO WSD-GROUP.                                  
           MOVE ARR-SRT-PD-ACCT  TO WSD-ACCT.                                   
           MOVE ARR-AGENT        TO WSD-PRODUCER.                               
      *                                                                         
      * READ AGENT FILE FOR AGENT NAME USING ARR-AGENT FROM                     
      * GFO ARREARS RECORD                                                      
      *                                                                         
           MOVE ARR-AGENT        TO GFMAGENT-CODE.                              
           MOVE '0'              TO GFMAGENT-ACCOUNT.                           
           MOVE 'GETRAN'         TO GFMAGENT-FUNCTION.                          
           CALL 'GFMAGENT'   USING  GFMAGENT-FUNCTION                           
                                    GFMAGENT-ERROR                              
                                    AGENT-NAME-FILE                             
                                    GFMAGENT-KEY.                               
           IF GFMAGENT-ERROR EQUAL LOW-VALUES                                   
               MOVE AGT-NAME TO WSD-PRODUCER-NAME                               
           ELSE                                                                 
               MOVE SPACES   TO WSD-PRODUCER-NAME.                              
           CALL 'QDATE' USING WS-QDATE-AC                                       
                              ARR-OVERDATE                                      
                              WSD-OVDU-DATE.                                    
           MOVE ARR-OVERPREM     TO WSD-PREM-AMT.                               
           MOVE ARR-CURRPREM     TO WSD-CURR-PREM.                              
           MOVE ARR-TOTLPREM     TO WSD-TOT-PREM.                               
           IF  ARR-GRPIND IS EQUAL TO WS-NEW THEN                               
               MOVE WS-NEW-MSGE    TO WSD-CLAIM                                 
           ELSE                                                                 
               CALL 'QDATE' USING WS-QDATE-AC                                   
                                  ARR-SUSPDATE                                  
                                  WS-CLMSUS-DATE.                               
      *----------------------------------------------------------------*        
      *                                                                *        
      *      OBTAIN GROUP NAME FROM GIPSY MASTER TRAILER 030           *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE ARR-SRT-PD-GROUP TO E-GROUP.                                    
           MOVE ARR-SRT-PD-ACCT TO E-ACCT.                                      
      *----------------------------------------------------------------*        
      *    SET UP THE NEW FIELDS ON THE ERROR RECORD.      MARCUS.     *        
      *----------------------------------------------------------------*        
           MOVE ARR-GRPOFF      TO E-OFFICE                                     
           MOVE ARR-PCODE       TO E-PROD-CD.                                   
           MOVE '030' TO GBNTRIDENT.                                            
           MOVE SPACES TO E-CODE.                                               
GNE        CALL GZACCMT7 USING E-NORM                                           
GNE                              GMBNATR                                        
GNE                              E-CODE.                                        
           IF  E-CODE IS NOT EQUAL TO SPACES                                    
           OR  GBNTRIDENT IS EQUAL TO SPACES THEN                               
               PERFORM ERR-ROUTINE-BGN THRU                                     
                       ERR-ROUTINE-END                                          
               GO TO LINE-CHECK.                                                
GNE        CALL GZNAEXP7 USING GMBNATR                                          
GNE                              WS-NMADDR                                      
GNE                              E-CODE.                                        
           IF  E-CODE IS NOT EQUAL TO SPACES THEN                               
               PERFORM ERR-ROUTINE-BGN THRU                                     
                       ERR-ROUTINE-END                                          
               GO TO LINE-CHECK.                                                
           MOVE WS-NA-LN (1) TO WSD-GRPNAME.                                    
       LINE-CHECK.                                                              
           IF  WS-LNE-CNT IS NOT EQUAL TO WS-LINE-COUNT                         
           AND ARR-SRT-PD-GFO IS EQUAL TO WS-STORE-GFO THEN                     
      *        MOVE SPACES TO WSD-GRPO                                          
               MOVE SPACES TO WS-WKD-CC                                         
           ELSE                                                                 
               MOVE '0' TO WS-WKD-CC.                                           
           MOVE WS-DETAIL1 TO WS-WKD-AREA.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *    ACCOUNT REP AND GFO CONTROL BREAK                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  WS-STORE-GFO IS NOT EQUAL TO ZEROS                               
               IF ARR-SRT-PD-REP NOT EQUAL TO WS-CURR-REP THEN                  
                   PERFORM REP-BREAK-BGN THRU                                   
                           REP-BREAK-END                                        
                   IF ARR-SRT-PD-GFO NOT EQUAL TO WS-CURR-GFO THEN              
                       PERFORM STORE-GFO-TOTAL-BGN THRU                         
                               STORE-GFO-TOTAL-END                              
                       MOVE ARR-SRT-PD-GFO TO WS-CURR-GFO                       
                       MOVE 'Y' TO PRINT-HEADER-PAGE-SW.                        
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           PERFORM ACCUM-TOTALS-BGN THRU                                        
                   ACCUM-TOTALS-END.                                            
       READ-RECORD.                                                             
           CALL 'DLSREAD' USING  TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 ARR-RECORD                                     
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO END-OF-REPORT4.                                            
           GO TO REPORT4-PROCESSING.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 PRODUCES SUMMARY SHEET                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OF-REPORT4.                                                          
           PERFORM REP-BREAK-BGN THRU                                           
                   REP-BREAK-END.                                               
           PERFORM STORE-GFO-TOTAL-BGN THRU                                     
                   STORE-GFO-TOTAL-END.                                         
           SUBTRACT +1 FROM WS-CURR-TOT.                                        
           MOVE +1 TO WS-CURR-SUB.                                              
      * DO NOT PRINT THE GFO/REP HEADING LINE ON SUMMARY PAGE                   
           MOVE 'Y' TO SUMMARY-TOTAL-SW.                                        
      * INITIALIZE PAGE NUMBER                                                  
           MOVE 0 TO WS-PAGE-NUMBER.                                            
      * CHANGE FIRST COLUMN HEADING TO SAY GFO FOR TOTAL PAGE                   
           MOVE SPACES TO WS-HEAD3-COL-1.                                       
           MOVE 'GFO' TO WS-HEAD4-COL-1.                                        
       SUMMARY-LOOP.                                                            
           IF  WS-CURR-SUB IS GREATER THAN WS-CURR-TOT THEN                     
               GO TO SUMMARY-END.                                               
           MOVE WS-TABLE-STATUS (WS-CURR-SUB) TO WS-GFO-STATUS.                 
           IF  WS-GFO-STATUS IS EQUAL TO HIGH-VALUES THEN                       
               GO TO SUMMARY-END.                                               
           MOVE SPACES TO WS-TOTAL1.                                            
           MOVE WS-CURR-GFO  TO WS-TOT-GRP.                                     
           MOVE WSGT-PREM-AMT TO WS-TOT-PREM-AMT.                               
           MOVE WSGT-CURR-PREM TO WS-TOT-CURR-PREM.                             
           MOVE WSGT-TOT-PREM TO WS-TOT-TOT-PREM.                               
           MOVE WS-TOTAL1 TO WS-WKD-AREA.                                       
           MOVE '0' TO WS-WKD-CC.                                               
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           ADD WSGT-PREM-AMT TO WS-ENDTOT-PREM.                                 
           ADD WSGT-CURR-PREM TO WS-ENDTOT-CURR.                                
           ADD WSGT-TOT-PREM TO WS-ENDTOT-TOT.                                  
           ADD +1 TO WS-CURR-SUB.                                               
           GO TO SUMMARY-LOOP.                                                  
       SUMMARY-END.                                                             
           MOVE SPACES TO WS-TOTAL1.                                            
           MOVE WS-COMPANY-MSGE TO WS-COMPANY-HD.                               
           MOVE WS-ENDTOT-PREM TO WS-TOT-PREM-AMT.                              
           MOVE WS-ENDTOT-CURR TO WS-TOT-CURR-PREM.                             
           MOVE WS-ENDTOT-TOT TO WS-TOT-TOT-PREM.                               
           MOVE WS-TOTAL1 TO WS-WKD-AREA.                                       
           MOVE '-' TO WS-WKD-CC.                                               
           MOVE ZEROS TO WS-LNE-CNT.                                            
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           GO TO END-OPERATIONS.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             ROUTINE USED IN NORMAL PROCESSING                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-ROUTINE-BGN.                                                       
           IF  WS-WKD-CC IS EQUAL TO '1' THEN                                   
               MOVE +1 TO WS-LNE-CNT                                            
           ELSE                                                                 
               IF  WS-WKD-CC IS EQUAL TO ' ' THEN                               
                   ADD +1 TO WS-LNE-CNT                                         
                ELSE                                                            
                   IF  WS-WKD-CC IS EQUAL '0' THEN                              
                       ADD +2 TO WS-LNE-CNT                                     
                   ELSE                                                         
                       IF  WS-WKD-CC IS EQUAL TO '-' THEN                       
                           ADD +3 TO WS-LNE-CNT.                                
           IF  WS-LNE-CNT GREATER WS-LINE-COUNT THEN                            
               MOVE WS-WKD-DATA TO WS-HOLD-DATA                                 
               PERFORM HEADER-ROUTINE-BGN THRU                                  
                       HEADER-ROUTINE-END                                       
               PERFORM TITLE-ROUTINE-BGN THRU                                   
                       TITLE-ROUTINE-END                                        
               MOVE WS-HOLD-DATA TO WS-WKD-DATA                                 
               MOVE '0' TO WS-WKD-CC                                            
               MOVE WS-CURR-GFO TO WS-STORE-GFO                                 
      *        MOVE WS-CURR-GFO TO  WS-WKD-OVFLW-GFO                            
               MOVE WS-CURR-REP TO WS-STORE-REP                                 
               GO TO PRINT-ROUTINE-BGN.                                         
           CALL 'DLSWRITE' USING PRINT-SYS036,                                  
                                 PRINT-RETURN,                                  
                                 WS-WKD-DATA,                                   
                                 PRINT-RECSIZE,                                 
                                 PRINT-BLKSIZE,                                 
                                 PRINT-FORMAT,                                  
                                 PRINT-SYS036-COUNT.                            
       PRINT-ROUTINE-END.                                                       
           EXIT.                                                                
       ACCUM-TOTALS-BGN.                                                        
           MOVE ARR-SRT-PD-REP TO WS-CURR-REP.                                  
           ADD ARR-OVERPREM TO WSRT-PREM-AMT.                                   
           ADD ARR-CURRPREM TO WSRT-CURR-PREM.                                  
           ADD ARR-TOTLPREM TO WSRT-TOT-PREM.                                   
           MOVE ARR-SRT-PD-GFO TO WS-CURR-GFO.                                  
           ADD ARR-OVERPREM TO WSGT-PREM-AMT.                                   
           ADD ARR-CURRPREM TO WSGT-CURR-PREM.                                  
           ADD ARR-TOTLPREM TO WSGT-TOT-PREM.                                   
       ACCUM-TOTALS-END.                                                        
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             PRINT ACCOUNT REP TOTAL LINE                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       REP-BREAK-BGN.                                                           
           MOVE WS-WKD-DATA TO WS-HOLD-DATA2.                                   
           MOVE SPACES TO WS-TOTAL1.                                            
           MOVE '-' TO WS-WKD-CC.                                               
      *    MOVE WS-CURR-GFO TO WS-TOT-GRP.                                      
           MOVE WS-TOTAL-MSGE TO WS-TOT-HD.                                     
           MOVE WSRT-PREM-AMT TO WS-TOT-PREM-AMT.                               
           MOVE WSRT-CURR-PREM TO WS-TOT-CURR-PREM.                             
           MOVE WSRT-TOT-PREM TO WS-TOT-TOT-PREM.                               
           MOVE WS-TOTAL1 TO WS-WKD-AREA.                                       
           MOVE ZEROS TO WS-LNE-CNT.                                            
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE ZEROS TO WSRT-PREM-AMT                                          
                         WSRT-CURR-PREM                                         
                         WSRT-TOT-PREM.                                         
           MOVE WS-LINE-COUNT TO WS-LNE-CNT.                                    
           MOVE WS-HOLD-DATA2 TO WS-WKD-DATA.                                   
           MOVE '0' TO WS-WKD-CC.                                               
      *    IF   ARR-TYPE          =    'H'                                      
      *     AND ARR-REPORT        =    'A'                                      
      *        MOVE ARR-SRT-PD-GFO TO WS-CURR-GFO.                              
       REP-BREAK-END.                                                           
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *               STORE GROUP TOTAL FIGURES                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       STORE-GFO-TOTAL-BGN.                                                     
           IF  WS-CURR-SUB IS GREATER THAN WS-MAX-SUB THEN                      
               MOVE HIGH-VALUES TO WS-TABLE-STATUS (WS-MAX-SUB)                 
           ELSE                                                                 
               MOVE WS-GFO-STATUS TO WS-TABLE-STATUS (WS-CURR-SUB)              
               ADD +1 TO WS-CURR-SUB WS-CURR-TOT.                               
           MOVE ZEROS TO WS-CURR-GFO                                            
                         WSGT-PREM-AMT                                          
                         WSGT-CURR-PREM                                         
                         WSGT-TOT-PREM.                                         
       STORE-GFO-TOTAL-END.                                                     
           EXIT.                                                                
       HEADER-ROUTINE-BGN.                                                      
           IF PRINT-HEADER-PAGE-SW = 'Y'                                        
              MOVE ARR-SRT-PD-GFO TO WS-HD5-GFO                                 
              MOVE 0              TO WS-PAGE-NUMBER                             
              MOVE WS-HEAD5       TO WS-WKD-AREA                                
              MOVE '1'            TO WS-WKD-CC                                  
              PERFORM PRINT-ROUTINE-BGN THRU                                    
                      PRINT-ROUTINE-END                                         
              MOVE SPACES         TO WS-WKD-CC                                  
                                  WS-WKD-AREA                                   
              PERFORM PRINT-ROUTINE-BGN THRU                                    
                      PRINT-ROUTINE-END                                         
              MOVE 'N' TO PRINT-HEADER-PAGE-SW.                                 
       HEADER-ROUTINE-END.                                                      
           EXIT.                                                                
       TITLE-ROUTINE-BGN.                                                       
           ADD +1              TO ACCUM-LAPSE-MAIL.                             
           MOVE '1'            TO WS-WKD-CC.                                    
           ADD +1              TO WS-PAGE-NUMBER.                               
           MOVE WS-PAGE-NUMBER TO WS-HD1-PAGE.                                  
           MOVE WS-HEAD1       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES         TO WS-WKD-CC.                                    
           MOVE WS-HEAD2       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           IF SUMMARY-TOTAL-SW = 'N'                                            
              MOVE ARR-SRT-PD-REP TO GNUM-REP                                   
              CALL 'GNUMTABL'     USING  GNUM-TABLE                             
                                         GNUM-REP                               
                                         GNUM-RETURN                            
              IF (GNUM-RETURN-1-5 EQUAL GNUM-REP)                               
                 MOVE SPACES TO GNUM-RETURN.                                    
           IF SUMMARY-TOTAL-SW = 'N'                                            
              MOVE ZERO           TO WS-WKD-CC                                  
              MOVE ARR-SRT-PD-GFO TO WS-HD2A-OFFICE                             
              MOVE ARR-SRT-PD-REP TO WS-HD2A-REP                                
              MOVE GNUM-RETURN    TO WS-HD2A-REP-NAME                           
              MOVE WS-HEAD2A      TO WS-WKD-AREA                                
              PERFORM PRINT-ROUTINE-BGN THRU                                    
                   PRINT-ROUTINE-END.                                           
           MOVE ZERO           TO WS-WKD-CC.                                    
           MOVE WS-HEAD3       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES         TO WS-WKD-CC.                                    
           MOVE WS-HEAD4       TO WS-WKD-AREA.                                  
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
       TITLE-ROUTINE-END.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         REINITIALIZE GROUP OFFICE TABLE TO ZEROS.              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ZERO-COUNTERS-BGN.                                                       
           MOVE +1 TO WS-CURR-SUB.                                              
           MOVE ZEROS TO WS-CURR-GFO                                            
                         WSGT-PREM-AMT                                          
                         WSGT-CURR-PREM                                         
                         WSGT-TOT-PREM.                                         
           MOVE ZEROS TO WS-CURR-REP                                            
                         WSRT-PREM-AMT                                          
                         WSRT-CURR-PREM                                         
                         WSRT-TOT-PREM.                                         
       ZERO-LOOP.                                                               
           MOVE WS-GFO-STATUS TO WS-TABLE-STATUS (WS-CURR-SUB).                 
           IF  WS-CURR-SUB IS NOT LESS WS-MAX-SUB THEN                          
               MOVE +1 TO WS-CURR-SUB                                           
               GO TO ZERO-COUNTERS-END.                                         
           ADD +1 TO WS-CURR-SUB.                                               
           GO TO ZERO-LOOP.                                                     
       ZERO-COUNTERS-END.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *            WRITE OUT AN ERROR RECORD ON SYS011                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ERR-ROUTINE-BGN.                                                         
           CALL 'DLSWRITE' USING  TAPE-SYS011                                   
                                  TAPE-RETURN                                   
                                  ERR-REC                                       
                                  TAPE-SYS011-RECSIZE                           
                                  TAPE-SYS011-BLKSIZE                           
                                  TAPE-SYS011-FORMAT                            
                                  TAPE-SYS011-COUNT.                            
           MOVE SPACES TO E-CODE.                                               
       ERR-ROUTINE-END.                                                         
           EXIT.                                                                
       END-OPERATIONS.                                                          
           IF   ARR-TYPE          =    'H'                                      
            AND ARR-REPORT        =    'B'                                      
             AND TAPE-RETURN IS EQUAL TO ZEROS THEN                             
               GO TO UB-MODULE-CALL.                                            
           MULTIPLY 2 BY ACCUM-LAPSE-MAIL.                                      
           MULTIPLY 2 BY ACCUM-OVERDUE.                                         
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
