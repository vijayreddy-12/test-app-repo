       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRSOOPR.                                                   
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *REMARKS.  GROUP OFFICE OVERDUE PREMIUM REPORT USED BY                    
      *          MANAGEMENT IN THE CONTROL AND HANDLING OF                      
      *          OVERDUE PREMIUMS.                                              
      *DATE-WRITTEN.  MODIFIED MAY 1984                                         
      *DATE-WRITTEN.  MODIFIED DECEMBER 1987                                    
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *   MODIFIED BY BRENT G. WILKE                                  *         
      *     REPORT IS NOW TO CREATE  FOUR (4) DIFFERENT REPORTS.      *         
      *     DISCRIPTION               ABBREV.     TABLE    SYSTEM     *         
      *     SELF-ADMIN --------------->> SA         1      SYS037     *         
      *     TERMINATED GROUPS -------->> TG         2      SYS061     *         
      *     HEAD OFFICE CLAIMS SUSP -->> HCS        3      SYS062     *         
      *     HEAD OFFICE INFORCE ------>> HOI        4      SYS063     *         
      *     EACH REPORT WILL BE UNIQUE.                               *         
      *     MAXIMUM GROUP OFFICES ALLOWED IN THIS                     *         
      *                              PRINTOUT IS 40 (FORTY).          *         
      *****************************************************************         
      *                   GIPSY-REL-1  START                          *         
      *****************************************************************         
      *                                                               *         
      *  SEP/89  M DRURY  - ADD THE EXTRA 20 BYTES TO LINKAGE SECT.   *         
      *                     RECOMPILED FOR NEW COPYBOOKS              *         
      *                                                               *         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  END                            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *                                                               *         
      *                                                               *         
      *  FEB/90  M DRURY  - CHANGE THE TABLE MENTIONED ABOVE TO BE    *         
      *                     100.                                      *         
      *                     CHANGE THE NUMBER OF COPIES TO 1          *         
      *                     OLD    FORM-STANDARD-TWICE  VALUE '92'    *         
      *                     NEW    FORM-STANDARD-ONCE   VALUE '91'    *         
      *                                                               *         
      *                                                               *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
      ******************************************************************        
      ***********************                ***************************        
      *********************   DATA  DIVISION  **************************        
      **********************                 ***************************        
      ******************************************************************        
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  FILLER.                                                              
           03  FILLER                              PIC X(38)  VALUE             
               '*** WORKING STORAGE FOR GPRSOOPR *****'.                        
           03  FORM-STANDARD-ONCE   VALUE '91'     PIC X(2).                    
                                                                                
       01  PRINT-SYS037              PIC X(06) VALUE 'SYS037'.                  
       01  PRINT-SYS037-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
                                                                                
      *                                                                         
      *  SYNCRONIZED MUST USE A 01 LEVEL.                                       
      *                                                                         
       01  FILLER  COMP.                                                        
           05  WS-PAGE-SIZE         VALUE +0       PIC S9(4).                   
           05  WS-WKF-BYTES         VALUE +137     PIC S9(4).                   
       01  FILLER.                                                              
           03  WS-HOLD-CURR-GRP     VALUE ZEROS    PIC X(5).                    
           03  WS-DATE.                                                         
               05  WS-YEAR       COMP-3            PIC S9(3).                   
               05  WS-DAY        COMP-3            PIC S9(3).                   
           03  WS-DAY                              PIC S999.                    
           03  WS-YEAR                             PIC S999.                    
           03  FILLER  COMP-3 OCCURS 4 TIMES.                                   
               05  WS-PAGE-NUMBER                  PIC S9(5).                   
               05  WS-WKF-COUNT                    PIC S9(7).                   
               05  WS-LINE-COUNT                   PIC S9(4).                   
           03  FILLER  OCCURS 4 TIMES.                                          
               05  WS-HOLD-AREA1                   PIC X(133).                  
               05  WS-HOLD-AREA2                   PIC X(133).                  
           03  WS-STORED-GRP                       PIC X(5).                    
           03  WS-CURDT             VALUE SPACES   PIC X(8).                    
           03  WS-ZDTAC             VALUE 'AC'     PIC X(2).                    
           03  EIGHTY-EIGHTY-LEVELS.                                            
               05  EE-BILL-TYPE                    PIC X.                       
                   88  SELF-ADMIN                  VALUE 'B'.                   
               05  EE-ACCT-STATUS                  PIC XX.                      
                   88  TERM-GROUP                  VALUE '20'                   
                                                         '23'                   
                                                         '24'                   
                                                         '25'                   
                                                         '26'.                  
                   88  HEAD-SUSP                   VALUE '01'                   
                                                         '03'.                  
                   88  HEAD-INFORCE                VALUE '00'                   
                                                         '02'                   
                                                         '05'                   
                                                         '10'.                  
               05  EE-SUMMARY                      PIC XXX.                     
                   88  SUMMARY                     VALUE 'YES'.                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *              NO OF GROUP OFFICES AND TOTALS                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-CURR-STATUS OCCURS 4 TIMES.                                   
               05  WS-CURR-GRP                     PIC X(5).                    
               05  WST-30DAYS                      PIC S9(7)V99 COMP-3.         
               05  WST-60DAYS                      PIC S9(7)V99 COMP-3.         
               05  WST-90DAYS                      PIC S9(7)V99 COMP-3.         
               05  WST-120DAYS                     PIC S9(7)V99 COMP-3.         
               05  WST-TOTOVDUE                    PIC S9(9)V99 COMP-3.         
      *                                                                *        
      *----------------------------------------------------------------*        
      *      FEB/90 MARCUS   WAS OCCURS 40                             *        
      *----------------------------------------------------------------*        
      *                                                                *        
           03  WS-TALLY-CURR-STATUS OCCURS 100 TIMES.                           
               05  WSTAL-CURR-GRP                  PIC X(5).                    
               05  WSTAL-30DAYS                    PIC S9(7)V99 COMP-3.         
               05  WSTAL-60DAYS                    PIC S9(7)V99 COMP-3.         
               05  WSTAL-90DAYS                    PIC S9(7)V99 COMP-3.         
               05  WSTAL-120DAYS                   PIC S9(7)V99 COMP-3.         
               05  WSTAL-TOTOVDUE                  PIC S9(9)V99 COMP-3.         
      *----------------------------------------------------------------*        
      *                                                                *        
      *                       SUMMARY TOTALS                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WSST-TOTALS COMP-3.                                              
               05  WSST-30DAYS      VALUE +0       PIC S9(7)V99.                
               05  WSST-60DAYS      VALUE +0       PIC S9(7)V99.                
               05  WSST-90DAYS      VALUE +0       PIC S9(7)V99.                
               05  WSST-120DAYS     VALUE +0       PIC S9(7)V99.                
               05  WSST-TOTOVDUE    VALUE +0       PIC S9(9)V99.                
      *                                                                *        
      *  SYNCRONIZED MUST USE A 01 LEVEL.                              *        
      *                                                                *        
       01  FILLER COMP.                                                         
MAN07      05  WS-CURR-SUB          VALUE +1       PIC S9(4) COMP.              
      *                                                                *        
      *----------------------------------------------------------------*        
      *      FEB/90 MARCUS  WS-MAX-SUB           WAS VALUE  40         *        
      *----------------------------------------------------------------*        
      *                                                                *        
MAN07      05  WS-MAX-SUB           VALUE +100     PIC S9(4) COMP.              
           05  WS-CURR-TOT          VALUE +1       PIC S9(4).                   
MAN07      05  WS-REPORT-SUB        VALUE +0       PIC S9(4) COMP.              
           05  HOLD-REPORT-SUB      VALUE +0       PIC S9(4).                   
           05  WS-MAX-REPORT        VALUE +4       PIC S9(4).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 REPORT HEADING CONSTANTS                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  FILLER.                                                              
           03  WS-HEAD1.                                                        
               05  FILLER        VALUE 'GPRSOOPR'  PIC X(8).                    
               05  FILLER        VALUE SPACES      PIC X(10).                   
               05  FILLER                          PIC X(44)  VALUE             
           'GROUP  OFFICE  OVERDUE  PREMIUM  REPORT  -  '.                      
               05  WS-HD1-NAME      VALUE SPACES   PIC X(25).                   
               05  FILLER           VALUE SPACES   PIC X(7).                    
               05  FILLER                          PIC X(12)  VALUE             
               'REPORT DATE '.                                                  
               05  WS-HD1-DATE                     PIC X(7).                    
               05  FILLER       VALUE SPACES       PIC X(5).                    
               05  FILLER       VALUE 'PAGE '      PIC X(5).                    
               05  WS-HD1-PAGE-NUMBER VALUE ZEROS  PIC ZZZZ9.                   
               05  FILLER       VALUE SPACES       PIC X(5).                    
           03  WS-HEAD2.                                                        
 GNE           05  FILLER                          PIC X(58)  VALUE             
 GNE       'GROUP  GROUP   ACCT IDENT  BILL  ARREARS    30 DAYS'.               
 GNE           05  FILLER                          PIC X(51)  VALUE             
           '60 DAYS      90 DAYS     120 DAYS         TOTAL'.                   
               05  FILLER                          PIC X(23)  VALUE             
           'ACCOUNT  EFFECT ARREARS'.                                           
           03  WS-HEAD3.                                                        
 GNE           05  FILLER                          PIC X(84)  VALUE             
 GNE       ' OFF    NO      NO         TYPE   TYPE'.                            
               05  FILLER                          PIC X(48)  VALUE             
           'AND OVER        OVERDUE   STATUS    DATE  ACTION'.                  
           03  WS-TOTAL-MSGE   VALUE 'TOTAL   '    PIC X(8).                    
           03  WS-COMPANY-MSGE                     PIC X(13)  VALUE             
               'TOTAL COMPANY'.                                                 
      *-------------------------------*                                         
      *     TITLE NAME CONSTANTS      *                                         
      *-------------------------------*                                         
           03  WS-HD1-NAME-CONSTANTS.                                           
               05  WS-NAME-SA                      PIC X(25)  VALUE             
               'SELF - ADMINISTRATION    '.                                     
               05  WS-NAME-TG                      PIC X(25)  VALUE             
               'TERMINATED GROUPS        '.                                     
               05  WS-NAME-HCS                     PIC X(25)  VALUE             
               'HEAD OFFICE - CLAIMS SUSP'.                                     
               05  WS-NAME-HCI                     PIC X(25)  VALUE             
               'HEAD OFFICE - INFORCE    '.                                     
               05  WS-NAME-TOTAL                   PIC X(25)  VALUE             
               'MANULIFE   GFO TOTALS    '.                                     
           03  WS-HEAD-NAME OCCURS 4 TIMES         PIC X(25).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    GNUMTABL PARAMETERS                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *                                                                         
      *  SYNCRONIZED MUST USE A 01 LEVEL.                                       
      *                                                                         
       01  TABLE-NUMBERS  COMP.                                                 
           05   ACTYP-TAB            VALUE +3      PIC S9(4).                   
           05   ACSTS-TAB            VALUE +12     PIC S9(4).                   
           05   ARSTS-TAB            VALUE +10     PIC S9(4).                   
           05   ARIND-TAB            VALUE +9      PIC S9(4).                   
       01  FILLER.                                                              
           03  TAB-BACK              VALUE SPACES  PIC X(15).                   
           03  WS-BILL-TYP           VALUE SPACES  PIC X(6).                    
           03  WS-ARR-TYP            VALUE SPACES  PIC X(7).                    
           03  WS-ARR-ACT            VALUE SPACES  PIC X(7).                    
           03  WS-ACCT-STAT          VALUE SPACES  PIC X(7).                    
           03  WS-EFF-DATE           VALUE SPACES  PIC X(7).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *             EXTRA PRINT PARAMETERS FOR DLSWRITE                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WS-PRINT-PARMS.                                                      
           03  PRINT-SYSTEM         PIC X(6)  VALUE SPACES.                     
           03  PRINT-COUNT          PIC S9(7) VALUE +0      COMP-3.             
           03  PRINT-SYS061         PIC X(6)  VALUE 'SYS061'.                   
           03  PRINT-SYS062         PIC X(6)  VALUE 'SYS062'.                   
           03  PRINT-SYS063         PIC X(6)  VALUE 'SYS063'.                   
           03  PRINT-SYS061-COUNT   PIC S9(7) VALUE +0      COMP-3.             
           03  PRINT-SYS062-COUNT   PIC S9(7) VALUE +0      COMP-3.             
           03  PRINT-SYS063-COUNT   PIC S9(7) VALUE +0      COMP-3.             
           03  HOLD-PRINT-SYSTEM    PIC X(6)  VALUE SPACES.                     
           03  HOLD-PRINT-COUNT     PIC S9(7) VALUE +0      COMP-3.             
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    REPORT PRINT AREA                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *  SYNCRONIZED MUST USE A 01 LEVEL.                              *        
                                                                                
       01  WS-WKF-LENGTH              COMP         PIC S9(4).                   
       01  WS-WORK-FILE.                                                        
           03  FILLER                              PIC X(2).                    
           03  WS-WKF-AREA.                                                     
               05  WS-WKF-CC                       PIC X(1).                    
               05  WS-DETAIL-LINE.                                              
  GNE *            07  FILLER                      PIC X(1).                    
                   07  WSDL-GRP-OFF                PIC X(5).                    
                   07  FILLER                      PIC X(2).                    
  GNE              07  WSDL-GROUP                  PIC Z(7).                    
                   07  FILLER                      PIC X(1).                    
                   07  WSDL-ACCT                   PIC X(3).                    
                   07  FILLER                      PIC X(2).                    
                   07  WSDL-IDENT                  PIC X(5).                    
                   07  FILLER                      PIC X(1).                    
                   07  WSDL-BILL-TYP               PIC X(6).                    
                   07  FILLER                      PIC X(1).                    
                   07  WSDL-ARR-TYP                PIC X(7).                    
                   07  WSDL-30DAY                  PIC --,---,--9.99.           
                   07  WSDL-60DAY                  PIC --,---,--9.99.           
                   07  WSDL-90DAY                  PIC --,---,--9.99.           
                   07  WSDL-120DAY                 PIC --,---,--9.99.           
                   07  WSDL-TOTOVDU                PIC ----,---,--9.99.         
                   07  FILLER                      PIC X(1).                    
                   07  WSDL-ACCT-STAT              PIC X(8).                    
                   07  FILLER                      PIC X(1).                    
                   07  WSDL-EFF-DATE               PIC X(7).                    
                   07  FILLER                      PIC X(1).                    
                   07  WSDL-ARR-ACT                PIC X(7).                    
                   07  FILLER                      PIC X(3).                    
               05  FILLER REDEFINES WS-DETAIL-LINE.                             
  GNE *            07  FILLER                      PIC X(1).                    
                   07  WSTL-COMPANY-MSGE.                                       
                       09  WSTL-GRP-OFF            PIC X(5).                    
                       09  FILLER                  PIC X(2).                    
                       09  WSTL-TOTAL-MSGE         PIC X(8).                    
                                                                                
      ******************************************************************        
      *                                                                *        
      *              AREAS PASSED BETWEEN MODULES                      *        
      *                                                                *        
      ******************************************************************        
       LINKAGE SECTION.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *              PRINT FILE INPUT RECORD AREA                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LSTAPE-RECORD.                                                       
GNE         COPY GGFOOVE7.                                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *                       SCRATCH PAD AREA                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LSMISC-AREA.                                                         
           03  FILLER                              PIC X(4).                    
           03  LSM-HIDATE                          PIC X(4).                    
           03  FILLER                              PIC X(24).                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             PRINT PARAMETERS FOR SYS037                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRPRINT.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             TAPE PARAMETERS FOR SYS014                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRTPARM.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             REPORT ACCUMULATORS FOR SYSTEMS                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRACCUM.                                                          
                                                                                
      ******************************************************************        
      *******************                    ***************************        
      ******************  PROCEDURE DIVISION  **************************        
      *******************                    ***************************        
      ******************************************************************        
       PROCEDURE DIVISION USING LSTAPE-RECORD                                   
                                LSMISC-AREA                                     
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
      ******************************************************************        
      *                                                                *        
      *                   INITIALIZE ROUTINE                           *        
      *                                                                *        
      ******************************************************************        
      *    DISPLAY  '====>  GPRSOOPR   <====='.                                 
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-STANDARD-ONCE.                            
           CALL 'ZLINECT' USING WS-PAGE-SIZE.                                   
           SUBTRACT +3 FROM WS-PAGE-SIZE.                                       
           CALL 'QDATE' USING WS-ZDTAC                                          
                              LSM-HIDATE                                        
                              WS-HD1-DATE.                                      
           PERFORM INIT-SETUP THRU END-INIT-SETUP                               
                   UNTIL WS-REPORT-SUB IS NOT LESS THAN WS-MAX-REPORT.          
           MOVE +0 TO WS-REPORT-SUB                                             
                      WSTAL-30DAYS   (WS-CURR-SUB)                              
                      WSTAL-60DAYS   (WS-CURR-SUB)                              
                      WSTAL-90DAYS   (WS-CURR-SUB)                              
                      WSTAL-120DAYS  (WS-CURR-SUB)                              
                      WSTAL-TOTOVDUE (WS-CURR-SUB).                             
           MOVE WS-NAME-SA     TO WS-HEAD-NAME (+1).                            
           MOVE WS-NAME-TG     TO WS-HEAD-NAME (+2).                            
           MOVE WS-NAME-HCS    TO WS-HEAD-NAME (+3).                            
           MOVE WS-NAME-HCI    TO WS-HEAD-NAME (+4).                            
           MOVE OVR-TYPE TO EE-BILL-TYPE.                                       
           MOVE OVR-ACCSTAT   TO EE-ACCT-STATUS.                                
           MOVE OVR-GRPOFF   TO WS-CURR-GRP (+1)                                
                                WS-CURR-GRP (+2)                                
                                WS-CURR-GRP (+3)                                
                                WS-CURR-GRP (+4)                                
                                WSTAL-CURR-GRP (WS-CURR-SUB).                   
      ******************************************************************        
      *                                                                *        
      *             PROCESS PRINT FILE INPUT RECORD                    *        
      *                                                                *        
      ******************************************************************        
       REPORT1-PROCESSING.                                                      
           IF  OVR-RECTYPE              =  'H'                                  
            AND OVR-REPORT              =  'B'                                  
                NEXT SENTENCE                                                   
           ELSE                                                                 
               GO TO END-OF-REPORT1.                                            
           IF SELF-ADMIN                                                        
              MOVE +1 TO WS-REPORT-SUB                                          
              MOVE PRINT-SYS037       TO PRINT-SYSTEM                           
              MOVE PRINT-SYS037-COUNT TO PRINT-COUNT                            
           ELSE                                                                 
              IF TERM-GROUP                                                     
                 MOVE +2 TO WS-REPORT-SUB                                       
                 MOVE PRINT-SYS061       TO PRINT-SYSTEM                        
                 MOVE PRINT-SYS061-COUNT TO PRINT-COUNT                         
              ELSE                                                              
                 IF HEAD-SUSP                                                   
                    MOVE +3 TO WS-REPORT-SUB                                    
                    MOVE PRINT-SYS062       TO PRINT-SYSTEM                     
                    MOVE PRINT-SYS062-COUNT TO PRINT-COUNT                      
                 ELSE                                                           
                   IF HEAD-INFORCE                                              
                      MOVE +4 TO WS-REPORT-SUB                                  
                      MOVE PRINT-SYS063       TO PRINT-SYSTEM                   
                      MOVE PRINT-SYS063-COUNT TO PRINT-COUNT                    
                   ELSE                                                         
                      GO TO CALL-DLSREAD.                                       
           PERFORM COMMON-PROCESS-BGN THRU                                      
                   COMMON-PROCESS-END.                                          
       CALL-DLSREAD.                                                            
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                LSTAPE-RECORD                                   
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
           MOVE OVR-TYPE TO EE-BILL-TYPE.                                       
           MOVE OVR-ACCSTAT   TO EE-ACCT-STATUS.                                
           IF  TAPE-RETURN IS NOT EQUAL ZEROS THEN                              
               GO TO END-OF-REPORT1.                                            
           GO TO REPORT1-PROCESSING.                                            
      ******************************************************************        
      *                                                                *        
      *                 PRODUCE SUMMARY SHEET                          *        
      *                                                                *        
      ******************************************************************        
       END-OF-REPORT1.                                                          
           MOVE 'YES'         TO EE-SUMMARY.                                    
           MOVE +1            TO WS-REPORT-SUB.                                 
           PERFORM GROUP-BREAK-BGN THRU                                         
                   GROUP-BREAK-END.                                             
           SUBTRACT +1 FROM WS-CURR-TOT.                                        
           MOVE +1 TO WS-CURR-SUB.                                              
       SUMMARY-LOOP.                                                            
           IF  WS-CURR-SUB IS GREATER THAN WS-CURR-TOT THEN                     
               GO TO SUMMARY-END.                                               
           IF  WS-TALLY-CURR-STATUS (WS-MAX-SUB) IS EQUAL TO                    
                                    HIGH-VALUES THEN                            
               GO TO SUMMARY-END.                                               
           MOVE SPACES        TO WS-WKF-AREA.                                   
           MOVE WSTAL-CURR-GRP (WS-CURR-SUB)  TO                                
                WSTL-GRP-OFF.                                                   
           MOVE WSTAL-30DAYS (WS-CURR-SUB)   TO                                 
                WSDL-30DAY.                                                     
           MOVE WSTAL-60DAYS (WS-CURR-SUB)   TO                                 
                WSDL-60DAY.                                                     
           MOVE WSTAL-90DAYS (WS-CURR-SUB)   TO                                 
                WSDL-90DAY.                                                     
           MOVE WSTAL-120DAYS (WS-CURR-SUB)  TO                                 
                WSDL-120DAY.                                                    
           MOVE WSTAL-TOTOVDUE (WS-CURR-SUB) TO                                 
                WSDL-TOTOVDU.                                                   
           MOVE '0' TO WS-WKF-CC.                                               
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           ADD +1 TO WS-CURR-SUB.                                               
           GO TO SUMMARY-LOOP.                                                  
       SUMMARY-END.                                                             
           MOVE SPACES TO WS-WKF-AREA.                                          
           MOVE WS-COMPANY-MSGE TO WSTL-COMPANY-MSGE.                           
           MOVE WSST-30DAYS TO WSDL-30DAY.                                      
           MOVE WSST-60DAYS TO WSDL-60DAY.                                      
           MOVE WSST-90DAYS TO WSDL-90DAY.                                      
           MOVE WSST-120DAYS TO WSDL-120DAY.                                    
           MOVE WSST-TOTOVDUE TO WSDL-TOTOVDU.                                  
           MOVE '-' TO WS-WKF-CC.                                               
           MOVE +0  TO WS-LINE-COUNT (WS-REPORT-SUB).                           
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           GO TO END-OPERATIONS.                                                
      ******************************************************************        
      ********                                                         *        
      ********      ROUTINES USED IN NORMAL PROCESSING                 *        
      ********                                                         *        
      ******************************************************************        
      *----------------------------------------------------------------*        
      *                                                                *        
      *        COMMON PROCESS FOR ALL RECORDS READ                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COMMON-PROCESS-BGN.                                                      
               MOVE SPACES TO WS-WKF-AREA.                                      
               PERFORM DO-CALLS THRU END-DO-CALLS.                              
               MOVE WS-BILL-TYP      TO                                         
                    WSDL-BILL-TYP.                                              
               MOVE WS-ARR-TYP       TO                                         
                    WSDL-ARR-TYP.                                               
               MOVE WS-ARR-ACT       TO                                         
                    WSDL-ARR-ACT.                                               
               MOVE WS-ACCT-STAT     TO                                         
                    WSDL-ACCT-STAT.                                             
               MOVE WS-EFF-DATE      TO                                         
                    WSDL-EFF-DATE.                                              
               MOVE OVR-GRPOFF       TO                                         
                    WSDL-GRP-OFF.                                               
               MOVE OVR-GROUP        TO                                         
                    WSDL-GROUP.                                                 
               MOVE OVR-ACCT         TO                                         
                    WSDL-ACCT.                                                  
               MOVE OVR-IDENT        TO                                         
                    WSDL-IDENT.                                                 
               MOVE OVR-PREM30       TO                                         
                    WSDL-30DAY.                                                 
               MOVE OVR-PREM60       TO                                         
                    WSDL-60DAY.                                                 
               MOVE OVR-PREM90       TO                                         
                    WSDL-90DAY.                                                 
               MOVE OVR-PREM120      TO                                         
                    WSDL-120DAY.                                                
               MOVE OVR-PREMTOTL     TO                                         
                    WSDL-TOTOVDU.                                               
      *    LINE-CHECK.                                                          
               IF  WS-LINE-COUNT (WS-REPORT-SUB) IS NOT EQUAL TO                
                   WS-PAGE-SIZE                                                 
               AND OVR-GRPOFF IS EQUAL TO WS-STORED-GRP THEN                    
                     MOVE SPACES TO WSDL-GRP-OFF                                
                     MOVE SPACES TO WS-WKF-CC                                   
               ELSE                                                             
                     MOVE '0' TO WS-WKF-CC.                                     
      *----------------------------------------------------------------*        
      *                                                                *        
      *              GROUP OFFICE CONTROL BREAK                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
               IF  WS-STORED-GRP IS NOT EQUAL ZEROS                             
               AND OVR-GRPOFF IS NOT EQUAL TO WS-STORED-GRP THEN                
                   MOVE WS-REPORT-SUB TO HOLD-REPORT-SUB                        
                   MOVE PRINT-SYSTEM  TO HOLD-PRINT-SYSTEM                      
                   MOVE PRINT-COUNT   TO HOLD-PRINT-COUNT                       
                   MOVE +1            TO WS-REPORT-SUB                          
                   PERFORM GROUP-BREAK-BGN THRU                                 
                           GROUP-BREAK-END                                      
                   MOVE HOLD-PRINT-SYSTEM  TO PRINT-SYSTEM                      
                   MOVE HOLD-PRINT-COUNT   TO PRINT-COUNT                       
                   MOVE HOLD-REPORT-SUB    TO WS-REPORT-SUB.                    
               PERFORM PRINT-ROUTINE-BGN THRU                                   
                       PRINT-ROUTINE-END.                                       
               MOVE OVR-GRPOFF TO WS-CURR-GRP (WS-REPORT-SUB)                   
                                   WSTAL-CURR-GRP (WS-CURR-SUB).                
               ADD  OVR-PREM30       TO                                         
                    WST-30DAYS     (WS-REPORT-SUB)                              
                    WSTAL-30DAYS   (WS-CURR-SUB)                                
                    WSST-30DAYS.                                                
               ADD  OVR-PREM60       TO                                         
                    WST-60DAYS     (WS-REPORT-SUB)                              
                    WSTAL-60DAYS   (WS-CURR-SUB)                                
                    WSST-60DAYS.                                                
               ADD  OVR-PREM90       TO                                         
                    WST-90DAYS     (WS-REPORT-SUB)                              
                    WSTAL-90DAYS   (WS-CURR-SUB)                                
                    WSST-90DAYS.                                                
               ADD  OVR-PREM120      TO                                         
                    WST-120DAYS    (WS-REPORT-SUB)                              
                    WSTAL-120DAYS  (WS-CURR-SUB)                                
                    WSST-120DAYS.                                               
               ADD  OVR-PREMTOTL     TO                                         
                    WST-TOTOVDUE   (WS-REPORT-SUB)                              
                    WSTAL-TOTOVDUE (WS-CURR-SUB)                                
                    WSST-TOTOVDUE.                                              
       COMMON-PROCESS-END.                                                      
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      TABLE CALLS FOR COMMON PROCESS RUN ON ALL RECORDS         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       DO-CALLS.                                                                
               CALL 'QDATE' USING WS-ZDTAC                                      
                                  OVR-EFFDATE                                   
                                  WS-EFF-DATE.                                  
               IF WS-EFF-DATE = '*******'                                       
                   MOVE SPACES TO WS-EFF-DATE.                                  
      *------------------------------------------------*                        
      *     MNEMONIC TABLE FOR BILL TYPE (CONTRACT)    *                        
      *------------------------------------------------*                        
      *    CONTRACT-CONVERT.                                                    
               CALL 'GNUMTABL' USING ACTYP-TAB                                  
                                     OVR-TYPE                                   
                                     TAB-BACK.                                  
               MOVE TAB-BACK TO WS-BILL-TYP.                                    
      *------------------------------------------------*                        
      *      MNEMONIC TABLE FOR ARREARS INDICATOR      *                        
      *------------------------------------------------*                        
      *    ARR-IND-CONVERT.                                                     
               CALL 'GNUMTABL' USING ARIND-TAB                                  
                                     OVR-ARRSTAT                                
                                     TAB-BACK.                                  
               MOVE TAB-BACK TO WS-ARR-TYP.                                     
      *------------------------------------------------*                        
      *      MNEMONIC TABLE FOR ARREARS STATUS         *                        
      *------------------------------------------------*                        
      *    ARR-STAT-CONVERT.                                                    
               CALL 'GNUMTABL' USING ARSTS-TAB                                  
                                     OVR-ARRSTAT                                
                                     TAB-BACK.                                  
               MOVE TAB-BACK TO WS-ARR-ACT.                                     
      *------------------------------------------------*                        
      *      MNEMONIC TABLE FOR ACCOUNT STATUS         *                        
      *------------------------------------------------*                        
      *    ACCT-STAT-CONVERT.                                                   
               CALL 'GNUMTABL' USING ACSTS-TAB                                  
                                     OVR-ACCSTAT                                
                                     TAB-BACK.                                  
               MOVE TAB-BACK TO WS-ACCT-STAT.                                   
       END-DO-CALLS.                                                            
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              PRINT ROUTINE FOR EACH SYSTEM                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-ROUTINE-BGN.                                                       
           IF  WS-WKF-CC IS EQUAL TO '1' THEN                                   
               MOVE +1 TO WS-LINE-COUNT (WS-REPORT-SUB)                         
           ELSE                                                                 
               IF  WS-WKF-CC IS EQUAL TO SPACES THEN                            
                   ADD +1 TO WS-LINE-COUNT (WS-REPORT-SUB)                      
                ELSE                                                            
                   IF  WS-WKF-CC IS EQUAL TO '0' THEN                           
                       ADD +2 TO WS-LINE-COUNT (WS-REPORT-SUB)                  
                   ELSE                                                         
                       IF  WS-WKF-CC                                            
                           IS EQUAL TO '-' THEN                                 
                              ADD +3 TO WS-LINE-COUNT (WS-REPORT-SUB).          
           IF  WS-LINE-COUNT (WS-REPORT-SUB) IS GREATER THAN                    
               WS-PAGE-SIZE AND SUMMARY                                         
                   MOVE WSTL-GRP-OFF TO                                         
                        WS-HOLD-CURR-GRP.                                       
           IF  WS-LINE-COUNT (WS-REPORT-SUB) IS GREATER THAN                    
               WS-PAGE-SIZE THEN                                                
               MOVE WS-WKF-AREA TO                                              
                    WS-HOLD-AREA1 (WS-REPORT-SUB)                               
               ADD +1 TO WS-PAGE-NUMBER (WS-REPORT-SUB)                         
               MOVE WS-PAGE-NUMBER (WS-REPORT-SUB) TO                           
                    WS-HD1-PAGE-NUMBER                                          
               PERFORM TITLE-ROUTINE-BGN THRU                                   
                       TITLE-ROUTINE-END                                        
                MOVE WS-HOLD-AREA1 (WS-REPORT-SUB) TO                           
                    WS-WKF-AREA                                                 
               MOVE '0' TO WS-WKF-CC                                            
               MOVE WS-CURR-GRP (WS-REPORT-SUB)                                 
                                 TO WS-STORED-GRP                               
                                    WSDL-GRP-OFF                                
               IF SUMMARY                                                       
                  MOVE WS-HOLD-CURR-GRP TO WSTL-GRP-OFF                         
                  GO TO PRINT-ROUTINE-BGN                                       
               ELSE                                                             
                  GO TO PRINT-ROUTINE-BGN.                                      
           PERFORM CALL-DLSWRITE-BGN THRU                                       
                   CALL-DLSWRITE-END.                                           
           MOVE SPACES TO WS-WKF-AREA.                                          
       PRINT-ROUTINE-END.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              DLSWRITE ROUTNE FOR EACH SYSTEM                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       CALL-DLSWRITE-BGN.                                                       
           CALL 'DLSWRITE' USING PRINT-SYSTEM                                   
                                 PRINT-RETURN                                   
                                 WS-WKF-AREA                                    
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-COUNT.                                   
       CALL-DLSWRITE-END.                                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *              MAJOR BREAK GROUP OFFICE ROUTINE                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       GROUP-BREAK-BGN.                                                         
           MOVE WS-WKF-AREA TO                                                  
                WS-HOLD-AREA2 (WS-REPORT-SUB).                                  
           MOVE SPACES TO WS-WKF-AREA.                                          
           MOVE '-' TO WS-WKF-CC.                                               
           MOVE WS-CURR-GRP (WS-REPORT-SUB)  TO                                 
                WSTL-GRP-OFF.                                                   
           MOVE WS-TOTAL-MSGE TO WSTL-TOTAL-MSGE.                               
           MOVE WST-30DAYS (WS-REPORT-SUB)   TO                                 
                WSDL-30DAY.                                                     
           MOVE WST-60DAYS (WS-REPORT-SUB)   TO                                 
                WSDL-60DAY.                                                     
           MOVE WST-90DAYS (WS-REPORT-SUB)   TO                                 
                WSDL-90DAY.                                                     
           MOVE WST-120DAYS (WS-REPORT-SUB)  TO                                 
                WSDL-120DAY.                                                    
           MOVE WST-TOTOVDUE (WS-REPORT-SUB) TO                                 
                WSDL-TOTOVDU.                                                   
           MOVE +0  TO WS-LINE-COUNT (WS-REPORT-SUB).                           
           IF WS-REPORT-SUB = +1                                                
              MOVE PRINT-SYS037       TO PRINT-SYSTEM                           
              MOVE PRINT-SYS037-COUNT TO PRINT-COUNT                            
           ELSE                                                                 
              IF WS-REPORT-SUB = +2                                             
                 MOVE PRINT-SYS061       TO PRINT-SYSTEM                        
                 MOVE PRINT-SYS061-COUNT TO PRINT-COUNT                         
              ELSE                                                              
                 IF WS-REPORT-SUB = +3                                          
                    MOVE PRINT-SYS062       TO PRINT-SYSTEM                     
                    MOVE PRINT-SYS062-COUNT TO PRINT-COUNT                      
                 ELSE                                                           
                    IF WS-REPORT-SUB = +4                                       
                       MOVE PRINT-SYS063       TO PRINT-SYSTEM                  
                       MOVE PRINT-SYS063-COUNT TO PRINT-COUNT.                  
           IF WST-TOTOVDUE (WS-REPORT-SUB) IS GREATER THAN +0                   
              PERFORM PRINT-ROUTINE-BGN THRU                                    
                      PRINT-ROUTINE-END.                                        
           MOVE ZEROS TO WS-CURR-GRP  (WS-REPORT-SUB).                          
           MOVE +0    TO WST-30DAYS   (WS-REPORT-SUB)                           
                         WST-60DAYS   (WS-REPORT-SUB)                           
                         WST-90DAYS   (WS-REPORT-SUB)                           
                         WST-120DAYS  (WS-REPORT-SUB)                           
                         WST-TOTOVDUE (WS-REPORT-SUB).                          
           MOVE WS-PAGE-SIZE TO WS-LINE-COUNT (WS-REPORT-SUB).                  
           ADD  +1           TO WS-LINE-COUNT (WS-REPORT-SUB).                  
           MOVE WS-HOLD-AREA2 (WS-REPORT-SUB) TO                                
                WS-WKF-AREA.                                                    
           MOVE '0' TO WS-WKF-CC.                                               
           IF  OVR-RECTYPE              =  'H'                                  
            AND OVR-REPORT              =  'B'                                  
               MOVE OVR-GRPOFF TO WS-CURR-GRP (WS-REPORT-SUB).                  
           IF  WS-REPORT-SUB IS LESS THAN WS-MAX-REPORT THEN                    
               ADD +1 TO WS-REPORT-SUB                                          
               GO TO GROUP-BREAK-BGN                                            
           ELSE                                                                 
               NEXT SENTENCE.                                                   
           IF  WS-CURR-SUB IS GREATER THAN WS-MAX-SUB                           
               MOVE HIGH-VALUES TO WS-TALLY-CURR-STATUS (WS-MAX-SUB)            
           ELSE                                                                 
               ADD +1 TO WS-CURR-SUB WS-CURR-TOT                                
               MOVE ZEROS  TO  WSTAL-CURR-GRP (WS-CURR-SUB)                     
               MOVE +0     TO  WSTAL-30DAYS   (WS-CURR-SUB)                     
                               WSTAL-60DAYS   (WS-CURR-SUB)                     
                               WSTAL-90DAYS   (WS-CURR-SUB)                     
                               WSTAL-120DAYS  (WS-CURR-SUB)                     
                               WSTAL-TOTOVDUE (WS-CURR-SUB).                    
       GROUP-BREAK-END.                                                         
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              COMMON TITLE ROUTINE FOR EACH SYSTEM              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       TITLE-ROUTINE-BGN.                                                       
           ADD +1 TO ACCUM-OVERDUE.                                             
           MOVE '1' TO WS-WKF-CC.                                               
           MOVE WS-HEAD-NAME (WS-REPORT-SUB) TO WS-HD1-NAME.                    
           IF SUMMARY                                                           
                      MOVE WS-NAME-TOTAL     TO WS-HD1-NAME.                    
           MOVE WS-HEAD1 TO WS-DETAIL-LINE.                                     
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE '-'  TO WS-WKF-CC.                                              
           MOVE WS-HEAD2 TO WS-DETAIL-LINE.                                     
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES TO WS-WKF-CC.                                            
           MOVE WS-HEAD3 TO WS-DETAIL-LINE.                                     
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
       TITLE-ROUTINE-END.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *              INIT SETUP FOR TOTALS AND HOLD AREAS              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       INIT-SETUP.                                                              
           ADD +1 TO WS-REPORT-SUB.                                             
           MOVE SPACES TO WS-HOLD-AREA1 (WS-REPORT-SUB).                        
           MOVE SPACES TO WS-HOLD-AREA2 (WS-REPORT-SUB).                        
           MOVE ZEROS TO WS-CURR-GRP    (WS-REPORT-SUB)                         
                         WS-STORED-GRP.                                         
           MOVE +0    TO WST-30DAYS     (WS-REPORT-SUB)                         
                         WST-60DAYS     (WS-REPORT-SUB)                         
                         WST-90DAYS     (WS-REPORT-SUB)                         
                         WST-120DAYS    (WS-REPORT-SUB)                         
                         WST-TOTOVDUE   (WS-REPORT-SUB)                         
                         WS-LINE-COUNT  (WS-REPORT-SUB)                         
                         WS-PAGE-NUMBER (WS-REPORT-SUB).                        
           MOVE WS-PAGE-SIZE TO WS-LINE-COUNT (WS-REPORT-SUB).                  
           ADD  +1           TO WS-LINE-COUNT (WS-REPORT-SUB).                  
           MOVE 'NO '        TO EE-SUMMARY.                                     
       END-INIT-SETUP.                                                          
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *        END OPERATIONS CLOSE SYSTEMS AND EXIT PROGRAM           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OPERATIONS.                                                          
           MOVE +4                 TO PRINT-RETURN.                             
           MOVE PRINT-SYS061       TO PRINT-SYSTEM.                             
           MOVE PRINT-SYS061-COUNT TO PRINT-COUNT.                              
           PERFORM  CALL-DLSWRITE-BGN THRU                                      
                    CALL-DLSWRITE-END.                                          
           MOVE PRINT-SYS062       TO PRINT-SYSTEM.                             
           MOVE PRINT-SYS062-COUNT TO PRINT-COUNT.                              
           PERFORM  CALL-DLSWRITE-BGN THRU                                      
                    CALL-DLSWRITE-END.                                          
           MOVE PRINT-SYS063       TO PRINT-SYSTEM.                             
           MOVE PRINT-SYS063-COUNT TO PRINT-COUNT.                              
           PERFORM  CALL-DLSWRITE-BGN THRU                                      
                    CALL-DLSWRITE-END.                                          
           MOVE +0                 TO PRINT-RETURN.                             
           GO TO EXIT-PROGRAM.                                                  
       EXIT-PROGRAM.                                                            
           EXIT PROGRAM.                                                        
