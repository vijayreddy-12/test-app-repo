       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.   GZNAEXP7.                                                  
       AUTHOR.       LIVINGSTONE INBARAJ.                                       
       DATE-WRITTEN. FEB 2013.                                                  
      *****************************************************************         
      *****************************************************************         
      *  NAME AND ADDRESS EXPAND ROUTINE                              *         
      *                                                               *         
      * THIS IS A REPLACEMENT FOR GZNAEXP7 WHICH IS AN ENTRY POINT    *         
      * UNDER ASSEMBLER MODULE GZNAEXC7                               *         
      *                                                               *         
      * SINCE THE MASTER NAME & ADDRESS IS NOW EXPANDED, THERE IS NO  *         
      * NEED FOR AN EXPANSION ROUTINE. THIS PROGRAM EXISTS ONLY TO    *         
      * FACILITATE THE MIGRATION OF PROGRAMS THAT USED TO USE THE OLD *         
      * ASSEMBLER GIPSY DETAIL I/O PROGRAM TO THE NEW VERSION         *         
      * THAT RETURNS ALREADY EXPANDED MASTER NAME & ADDRESS.          *         
      *                                                               *         
      * MAINTENANCE HISTORY                                           *         
      * -------------------                                           *         
      *                                                               *         
      * DATE       AUTHOR    DESCRIPTION                              *         
      *                                                               *         
      *****************************************************************         
                                                                   SKIP1        
       ENVIRONMENT DIVISION.                                                    
                                                                   SKIP1        
       CONFIGURATION SECTION.                                                   
                                                                   EJECT        
       DATA DIVISION.                                                           
                                                                   SKIP1        
       WORKING-STORAGE SECTION.                                                 
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01 LS-MASTER-NAME-ADDRESS.                                               
          05 LS-NA-TRIDENT                  PIC X(03).                          
          05 LS-NA-LENGTH                   PIC S9(5)  COMP-3.                  
          05 LS-NA-POST-CODE                PIC X(06).                          
          05 LS-NA-FILLER                   PIC X(20).                          
          05 LS-NA-NAME-ADDR                PIC X(186).                         
                                                                                
       01 LS-NAME-EXPAND-AREA.                                                  
          05 LS-NAME-AND-DEL OCCURS 6 TIMES.                                    
             10 LS-NAMEX                    PIC X(30).                          
             10 LS-DEL                      PIC X(01).                          
                                                                                
       01 LS-EXCO-ERROR                     PIC X(03)  VALUE SPACES.            
                                                                                
       PROCEDURE DIVISION USING LS-MASTER-NAME-ADDRESS                          
                                LS-NAME-EXPAND-AREA                             
                                LS-EXCO-ERROR.                                  
                                                                                
           MOVE SPACES TO LS-EXCO-ERROR.                                        
           MOVE LS-NA-NAME-ADDR TO LS-NAME-EXPAND-AREA.                         
                                                                                
           GOBACK.                                                              
                                                                                
