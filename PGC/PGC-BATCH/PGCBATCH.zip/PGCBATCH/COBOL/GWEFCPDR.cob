       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    GWEFCPDR.                                                 
      *AUTHOR.        GVRAO.                                                    
      *DATE-WRITTEN.  SEPTEMBER 1999.                                           
      *----------------------------------------------------------------         
      *  SYSTEM    : EFT                                                        
      *                                                                         
      *  LANGUAGE  : COBOL II                                                   
      *                                                                         
      *    THIS MODULE ACCEPTS A REQUEST FOR PAD, WITH THE INFORMATION          
      * REQUIRED TO READ THE EFT BANK INFO RECORD, AND DETERMINE IT THE         
      * INFORMATION IS VALID, AND IN FORCE, AND SET THE RETURN STATUS.          
      *    THIS LOGIC CAN RUN IN BATCH AND CICS ENVIRONMENTS, BUT ONLY          
      * BATCH CALLS SHOULD BE CREATING OUTPUT.  ALSO CALLS TO DATE              
      * ROUTINES ARE MADE IN CPY/CPYC MEMBER                                    
      *                                                                         
      *                                                                         
      *  INPUTS: DLSI17  APPLICATION SPECIFIC CONTROL FILE                      
      *          VSDSI60 BANK INFORMATION FILE                                  
      *                                                                         
      * OUTPUTS: DLSO23  APPLICATION SPECIFIC CONTROL FILE                      
      *          DLS022  EFT REQUEST FILE                                       
      *                                                                         
      *--HISTORY LOG--------------------------------------------------          
      * SEQ  DATE    DESIGNER    DESCRIPTION                                    
      * 001 SEP 1999 G.V.RAO    CREATED                                         
BM002 * 002 NOV 1999 MELANSON - CALCULATE DUEDATE FOR INQUIRY CALL              
BM002 *                       - USE CALENDAR 'A'                                
BM002 *                       - NO MORE 'COMPLETE' STATUS                       
BM003 * 003 FEB 2000 MELANSON - HANDLE PURGED BANK INFO, AS NOT FOUND           
BM004 * 004 MAR 2000 MELANSON - INITIALIZE UN-REQUIRED FIELDS                   
      * 005 15MAR2008 IBM GR    ENTERPRISE COMPILER UPGRADE                     
      *                         PROJECT - BUNDLE 5                              
      *----------------------------------------------------------------         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       INPUT-OUTPUT SECTION.                                                    
       FILE-CONTROL.                                                            
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  FILLER               PIC  X(38) VALUE                                
               '**-- WORKING STORAGE STARTS HERE  --**'.                        
                                                                                
      * DATE ROUTINE WORK FIELDS                                                
       01  GAC-DATE-PARMS.         COPY GARDATEP.                               
                                                                                
       01 WS-LAG-START-DATE.                                                    
          05 WS-LAG-YYYY        PIC  9(04).                                     
          05 WS-LAG-MM          PIC  9(02).                                     
          05 WS-LAG-DD          PIC  9(02).                                     
                                                                                
       01 WS-SYSTEM-DATE        PIC  X(08).                                     
                                                                                
       01 WS-WORK-DATE2.                                                        
          05 WS-WORK-YYYY       PIC  9(04).                                     
          05 WS-WORK-MM         PIC  9(02).                                     
          05 WS-WORK-DD         PIC  9(02).                                     
                                                                                
       01 WS-SYSTEM-TIME.                                                       
          05 WS-SYSTEM-TIME-6   PIC   9(06).                                    
          05 FILLER             PIC   X(02).                                    
                                                                                
       01 WS-TOTAL-TRL-AMT      PIC  S9(10)V99 VALUE ZEROES.                    
       01 WS-TOTAL-REC-CNT      PIC  9(09)     VALUE ZEROES.                    
       01 WS-HIGH-DATE          PIC  9(08)     VALUE 99999999.                  
       01 WS-ADJ-DAYS           PIC S9(03).                                     
       01 WS-ADJ-MONTHS         PIC S9(03).                                     
       01 WS-ADJ-YEARS          PIC S9(03).                                     
                                                                                
       01 WS-SWITCHES.                                                          
          05 WS-RECORD-WRT-SW   PIC  X(01)    VALUE 'N'.                        
             88 HDR-REC-NOT-WRITTEN           VALUE 'N'.                        
             88 HDR-REC-WRITTEN               VALUE 'Y'.                        
          05 WS-FIRST-UPDT-SW   PIC  X(01)    VALUE 'Y'.                        
             88 NOT-FIRST-UPDATE              VALUE 'N'.                        
             88 FIRST-UPDATE                  VALUE 'Y'.                        
                                                                                
       01 GWEFCBNK              PIC  X(08)    VALUE 'GWEFCBNK'.                 
       01 GC2DATE               PIC  X(08)    VALUE 'GC2DATE'.                  
BM002  01 CGC2DATE              PIC  X(08)    VALUE 'CGC2DATE'.                 
       01 GAEDATSR              PIC  X(08)    VALUE 'GAEDATSR'.                 
       01 GAEDATSR-VERB         PIC  X(16).                                     
                                                                                
                                                                                
       01 GAEDATSR-FILE-CNTL.                                                   
          05 CNTL-INFO-IN-LR                                                    
             VALUE 'CARD-DATA-017     CNTL FILE IN     ' PIC X(35).             
          05 CNTL-INFO-OUT-LR                                                   
             VALUE 'PRINT-DATA-030    CNTL FILE OUT    ' PIC X(35).             
          05 REQS-INFO-LR                                                       
             VALUE 'PRINT-DATA-031    REQUEST FILE INFO' PIC X(35).             
                                                                                
      * STANDARD VERBS FOR DATA SERVICE                                         
       01  DATA-SERVICE-VERBS. COPY GARDSVRB.                                   
                                                                                
      * REQUEST HEADER AND TRAILER COPY BOOK                                    
       01  REQ-HDR-TRL-INFO.   COPY GWEFIRQF.                                   
                                                                                
      * STANDARD SERVICE FOR "GAEDATSR" CALL                                    
       01  ICBM.               COPY ICBM.                                       
                                                                                
      * CONTROL FILE COPY BOOK                                                  
       01  EFT-CONTROL-INFO.       COPY GWEFICTL.                               
                                                                                
      * BANK INFO COPY BOOK                                                     
       01  EFT-BANK-INFO.      COPY GWEFRBNK.                                   
                                                                                
      * HISTORY COPYBOOK                                                        
       01  HIST-FILE-INFO.         COPY GWEFRHST.                               
                                                                                
      * EFT MAIN I/O MODULE LINKAGE PROTOCOL                                    
       01  IOM-REQUEST-PARMS.      COPY GWEFLIOM.                               
                                                                                
       01  FILLER               PIC  X(38) VALUE                                
               '**-- WORKING STORAGE ENDS HERE    --**'.                        
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  PAD-REQUEST.         COPY GWEFLPDR.                                  
                                                                                
                                                                                
       PROCEDURE DIVISION USING PAD-REQUEST.                                    
                                                                                
       000-MAIN-PARA.                                                           
                                                                                
           PERFORM 100-INITIALIZATION       THRU 100-EXIT.                      
           PERFORM 200-PROCESS-EFT-REQUEST  THRU 200-EXIT.                      
                                                                                
           GOBACK.                                                              
                                                                                
       100-INITIALIZATION.                                                      
           MOVE  'EA1E'               TO VDATE-REQUEST-AREA.                    
           PERFORM  998-GET-DATE-TIME       THRU 998-EXIT.                      
           MOVE VDATE1-YYYYMMDD       TO WS-SYSTEM-DATE.                        
           MOVE 'GWEFCPDR'            TO ICBM-PROGRAM-NAME.                     
                                                                                
       100-EXIT.            EXIT.                                               
                                                                                
       200-PROCESS-EFT-REQUEST.                                                 
           IF REQ-DONE                                                          
              IF HDR-REC-NOT-WRITTEN                                            
                 PERFORM 220-PROCESS-HEADER      THRU 220-EXIT                  
              END-IF                                                            
              PERFORM 500-WRITE-CONTROL-FILE         THRU 500-EXIT              
              MOVE OBTAIN-NEXT        TO GAEDATSR-VERB                          
              PERFORM 800-READ-CONTROL-FILE          THRU 800-EXIT              
              IF NOT CTRL-PAD-LOAD                                              
                   SET REQ-PAD-LOGIC-ABORTED  TO TRUE                           
                   MOVE    'CTL 2 '     TO REQ-BATCH-ID                         
                   GOBACK                                                       
              END-IF                                                            
              PERFORM 500-WRITE-CONTROL-FILE         THRU 500-EXIT              
              PERFORM 400-WRITE-TRAILER-REC          THRU 400-EXIT              
           ELSE                                                                 
              IF REQ-EFF-DATE-IN > ZEROS                                        
                 MOVE REQ-EFF-DATE-IN  TO   BNK-IOM-EFF-DATE                    
              ELSE                                                              
                 MOVE WS-SYSTEM-DATE   TO   BNK-IOM-EFF-DATE                    
              END-IF                                                            
                                                                                
              PERFORM 600-READ-BANK-INFO-FILE       THRU 600-EXIT               
                                                                                
              EVALUATE  TRUE                                                    
              WHEN EFT-IOM-NOT-FOUND                                            
                 MOVE ZEROS              TO   BNK-IOM-EFF-DATE                  
                 PERFORM 600-READ-BANK-INFO-FILE    THRU 600-EXIT               
                 IF EFT-IOM-STATUS-OK                                           
                     SET REQ-PAD-IN-FUTURE   TO TRUE                            
                 ELSE                                                           
                     SET REQ-PAD-NOT-FOUND   TO TRUE                            
                 END-IF                                                         
BM003         WHEN BNK-PURGED                                                   
BM003            CONTINUE                                                       
              WHEN  REQ-INQUIRY                                                 
BM002            PERFORM 210-DETERMINE-DUE-DATE     THRU 210-EXIT               
BM002            MOVE SPACES  TO REQ-BATCH-ID                                   
              WHEN  BNK-TERMINATED                                              
                 MOVE SPACES  TO REQ-BATCH-ID                                   
              WHEN  REQ-AUDIT-ONLY                                              
                 PERFORM 210-DETERMINE-DUE-DATE     THRU 210-EXIT               
                 IF FIRST-UPDATE                                                
                    PERFORM 220-PROCESS-HEADER      THRU 220-EXIT               
                 END-IF                                                         
                 PERFORM 700-WRITE-REQUEST-OUTPUT   THRU 700-EXIT               
              WHEN  REQ-UPDATE                                                  
                 PERFORM 210-DETERMINE-DUE-DATE     THRU 210-EXIT               
                 IF FIRST-UPDATE                                                
                    PERFORM 220-PROCESS-HEADER      THRU 220-EXIT               
                 END-IF                                                         
                 PERFORM 700-WRITE-REQUEST-OUTPUT   THRU 700-EXIT               
              WHEN OTHER                                                        
                 SET REQ-PAD-LOGIC-ABORTED  TO TRUE                             
                 MOVE    '200   '     TO REQ-BATCH-ID                           
                 MOVE REQ-REASON-CODE TO REQ-BATCH-ID(6:1)                      
                 GOBACK                                                         
              END-EVALUATE                                                      
           END-IF.                                                              
       200-EXIT.            EXIT.                                               
                                                                                
BM002 *----------------------------------------------------------               
BM002 * - IF THE INQUIRY CALL IS FOR A COPY BILL, THE REQ-EFF-DATE-IN           
BM002 *   CONTAINS THE DATE THE ORIGINAL WAS PROCESSED.  THIS SHOULD,           
BM002 *   RESULT IN CALCULATING THE SAME DUE DATE AS THE ORIGINAL BILL          
BM002 *   IN REFERENCE TO THAT DATE, NOT IN REFERENCE TO TODAY                  
BM002 *          (WHICH IS THE NORMAL FLOW)                                     
BM002 *----------------------------------------------------------               
       210-DETERMINE-DUE-DATE.                                                  
           MOVE ZEROES TO WS-ADJ-DAYS.                                          
           MOVE ZEROES TO WS-ADJ-MONTHS.                                        
           MOVE ZEROES TO WS-ADJ-YEARS.                                         
           EVALUATE TRUE                                                        
BM002      WHEN REQ-INQUIRY AND REQ-EFF-DATE-IN > ZEROES                        
BM002         MOVE  REQ-EFF-DATE-IN      TO WS-LAG-START-DATE                   
              PERFORM 215-CALC-LAG-TIME   THRU 215-EXIT                         
           WHEN REQ-EFF-DATE-IN > ZEROES                                        
              MOVE  REQ-EFF-DATE-IN      TO REQ-EFF-DATE-OUT                    
           WHEN OTHER                                                           
              MOVE  WS-SYSTEM-DATE       TO WS-LAG-START-DATE                   
              PERFORM 215-CALC-LAG-TIME   THRU 215-EXIT                         
              MOVE REQ-EFF-DATE-OUT      TO BNK-IOM-EFF-DATE                    
              PERFORM 600-READ-BANK-INFO-FILE  THRU 600-EXIT                    
              IF NOT EFT-IOM-STATUS-OK                                          
                  SET REQ-PAD-LOGIC-ABORTED  TO TRUE                            
                  MOVE    '210   '    TO REQ-BATCH-ID                           
                  MOVE EFT-IOM-STATUS TO REQ-BATCH-ID(5:2)                      
                  GOBACK                                                        
              END-IF                                                            
           END-EVALUATE.                                                        
       210-EXIT.            EXIT.                                               
                                                                                
       215-CALC-LAG-TIME.                                                       
           EVALUATE TRUE                                                        
           WHEN BNK-LAG-NONE                                                    
                MOVE WS-LAG-START-DATE   TO  REQ-EFF-DATE-OUT                   
           WHEN BNK-LAG-CALENDER                                                
                MOVE BNK-LAG-PERIOD      TO WS-ADJ-DAYS                         
                PERFORM 900-ADD-LAG-DAYS      THRU 900-EXIT                     
           WHEN BNK-LAG-MONTH-DAY                                               
               IF WS-LAG-DD < BNK-LAG-PERIOD                                    
                   MOVE WS-LAG-START-DATE   TO WS-WORK-DATE2                    
                   MOVE BNK-LAG-PERIOD      TO WS-WORK-DD                       
                   MOVE WS-WORK-DATE2       TO REQ-EFF-DATE-OUT                 
               ELSE                                                             
                   MOVE +1                   TO WS-ADJ-MONTHS                   
                   PERFORM 900-ADD-LAG-DAYS THRU 900-EXIT                       
                   MOVE REQ-EFF-DATE-OUT     TO WS-WORK-DATE2                   
                   MOVE BNK-LAG-PERIOD       TO WS-WORK-DD                      
                   MOVE WS-WORK-DATE2        TO REQ-EFF-DATE-OUT                
               END-IF                                                           
           END-EVALUATE.                                                        
       215-EXIT.            EXIT.                                               
                                                                                
       220-PROCESS-HEADER.                                                      
           MOVE OBTAIN-FIRST TO GAEDATSR-VERB.                                  
           PERFORM 800-READ-CONTROL-FILE             THRU 800-EXIT.             
           IF CTRL-PAD-REQUEST                                                  
               MOVE OBTAIN-NEXT    TO GAEDATSR-VERB                             
               PERFORM 950-BUILD-HEADER-INFO   THRU 950-EXIT                    
               PERFORM 300-WRITE-HEADER-REC    THRU 300-EXIT                    
           ELSE                                                                 
               SET REQ-PAD-LOGIC-ABORTED  TO TRUE                               
               MOVE    'CTL 1 '     TO REQ-BATCH-ID                             
               GOBACK                                                           
           END-IF.                                                              
           SET NOT-FIRST-UPDATE TO  TRUE.                                       
       220-EXIT.            EXIT.                                               
                                                                                
       300-WRITE-HEADER-REC.                                                    
           MOVE REQS-INFO-LR     TO  LOGICAL-RECORD-NAME.                       
           SET EFTREQ-HEADER     TO  TRUE.                                      
           MOVE SPACES           TO  EFTREQ-HEADER-FILLER.                      
           CALL GAEDATSR   USING     STORE-LR                                   
                                     REQ-HDR-TRL-INFO                           
                                     ICBM.                                      
           EVALUATE TRUE                                                        
           WHEN LR-STATUS-OK                                                    
               CONTINUE                                                         
           WHEN OTHER                                                           
               SET REQ-PAD-LOGIC-ABORTED  TO TRUE                               
               MOVE    'HD    '    TO REQ-BATCH-ID                              
               MOVE PROGRAM-LINKAGE-STATUS TO REQ-BATCH-ID(3:4)                 
               GOBACK                                                           
           END-EVALUATE.                                                        
           SET HDR-REC-WRITTEN  TO   TRUE.                                      
       300-EXIT.            EXIT.                                               
                                                                                
       400-WRITE-TRAILER-REC.                                                   
           MOVE REQS-INFO-LR      TO LOGICAL-RECORD-NAME.                       
           SET  EFTREQ-TRAILER    TO TRUE                                       
           MOVE WS-TOTAL-TRL-AMT  TO EFTREQ-TOTAL-AMOUNT                        
           MOVE WS-TOTAL-REC-CNT  TO EFTREQ-TOTAL-RECORDS                       
           MOVE SPACES            TO EFTREQ-TRAILER-FILLER.                     
           CALL GAEDATSR     USING     STORE-LR                                 
                                     REQ-HDR-TRL-INFO                           
                                     ICBM.                                      
           EVALUATE TRUE                                                        
           WHEN LR-STATUS-OK                                                    
                CONTINUE                                                        
           WHEN OTHER                                                           
               SET REQ-PAD-LOGIC-ABORTED  TO TRUE                               
               MOVE    'TR    '    TO REQ-BATCH-ID                              
               MOVE PROGRAM-LINKAGE-STATUS TO REQ-BATCH-ID(3:4)                 
               GOBACK                                                           
           END-EVALUATE.                                                        
       400-EXIT.            EXIT.                                               
                                                                                
       500-WRITE-CONTROL-FILE.                                                  
           MOVE CNTL-INFO-OUT-LR TO  LOGICAL-RECORD-NAME.                       
           CALL GAEDATSR     USING     STORE-LR                                 
                                     EFT-CONTROL-INFO                           
                                     ICBM.                                      
           EVALUATE TRUE                                                        
           WHEN LR-STATUS-OK                                                    
                CONTINUE                                                        
           WHEN OTHER                                                           
               SET REQ-PAD-LOGIC-ABORTED  TO TRUE                               
               MOVE    'CW    '    TO REQ-BATCH-ID                              
               MOVE PROGRAM-LINKAGE-STATUS TO REQ-BATCH-ID(3:4)                 
               GOBACK                                                           
           END-EVALUATE.                                                        
       500-EXIT.            EXIT.                                               
                                                                                
       600-READ-BANK-INFO-FILE.                                                 
           SET EFT-IOM-MAIN          TO   TRUE.                                 
           SET EFT-IOM-READ-KEYED    TO   TRUE.                                 
           MOVE  REQ-RECORD-TYPE     TO   EFT-IOM-RECORD-TYPE.                  
           MOVE  REQ-KEY-TYPE        TO   EFT-IOM-KEY-TYPE.                     
           MOVE  REQ-KEY-DATA        TO   EFT-IOM-KEY-DATA.                     
BM004      MOVE  ZERO                TO   BNK-IOM-MNT-DATE                      
BM004                                     BNK-IOM-MNT-SEQ.                      
           PERFORM 999-CALL-GWEFCBNK  THRU 999-EXIT.                            
           EVALUATE TRUE                                                        
           WHEN EFT-IOM-STATUS-OK                                               
               MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO                        
               EVALUATE TRUE                                                    
                  WHEN BNK-ACTIVE                                               
                       SET REQ-PAD-IN-EFFECT TO TRUE                            
                  WHEN BNK-SUSPENDED                                            
                       SET REQ-PAD-SUSPENDED TO TRUE                            
                  WHEN BNK-TERMINATED                                           
                       SET REQ-PAD-TERMINATED TO TRUE                           
BM003             WHEN BNK-PURGED                                               
BM003                  SET REQ-PAD-NOT-FOUND  TO TRUE                           
               END-EVALUATE                                                     
           WHEN EFT-IOM-NOT-FOUND                                               
               CONTINUE                                                         
           WHEN OTHER                                                           
               SET REQ-PAD-LOGIC-ABORTED  TO TRUE                               
               MOVE    '600   '    TO REQ-BATCH-ID                              
               MOVE EFT-IOM-STATUS TO REQ-BATCH-ID(5:2)                         
               GOBACK                                                           
           END-EVALUATE.                                                        
       600-EXIT.            EXIT.                                               
                                                                                
       700-WRITE-REQUEST-OUTPUT.                                                
           ADD 1                  TO  WS-TOTAL-REC-CNT.                         
           ADD REQ-AMOUNT         TO  WS-TOTAL-TRL-AMT.                         
           EVALUATE TRUE                                                        
           WHEN  REQ-AUDIT-ONLY                                                 
              MOVE 'C'            TO  HST-STATUS-CURR-ALT1                      
                                      HST-STATUS                                
BM002 *       SET REQ-PAD-COMPLETED   TO TRUE                                   
           WHEN  BNK-ACTIVE                                                     
              MOVE 'R'            TO  HST-STATUS-CURR-ALT1                      
                                      HST-STATUS                                
           WHEN  OTHER                                                          
              MOVE 'S'            TO  HST-STATUS-CURR-ALT1                      
                                      HST-STATUS                                
           END-EVALUATE.                                                        
           MOVE BNK-RECORD-TYPE   TO  HST-RECORD-TYPE.                          
           MOVE BNK-KEY-TYPE      TO  HST-KEY-TYPE.                             
           MOVE BNK-KEY-DATA      TO  HST-KEY-DATA.                             
           MOVE EFTREQ-BATCH-ID   TO  REQ-BATCH-ID                              
                                      HST-BATCH-ID.                             
           MOVE REQ-ENTRY-ID      TO  HST-ENTRY-ID.                             
           MOVE 98                TO  HST-MNT-SEQ-COMPLEMENT                    
                                      HST-MNT-SEQ-COMPLEMENT-ALT2.              
           MOVE WS-SYSTEM-DATE    TO  HST-MNT-DATE.                             
           MOVE WS-SYSTEM-TIME    TO  HST-MNT-TIME.                             
           SET  HST-CURR-STATUS   TO  TRUE.                                     
           MOVE HST-REC-ID        TO  HST-REC-ID-ALT2.                          
           MOVE 0000              TO  HST-FILE-SEQ.                             
           MOVE REQ-EFF-DATE-OUT  TO  HST-DUE-DATE.                             
           MOVE REQ-AMOUNT        TO  HST-AMOUNT.                               
           SET HST-SYSTEM-REQUEST TO  TRUE.                                     
           MOVE SPACES            TO  HST-COMMENT-TEXT.                         
           MOVE 'PAD REQ '        TO  HST-MAINTAINER-ID.                        
           MOVE SPACES            TO  HST-APPROVER-ID.                          
           MOVE BNK-CUSTOMER-NAME TO  HST-CUSTOMER-NAME.                        
           MOVE BNK-DEBIT         TO  HST-DEBIT.                                
           MOVE BNK-CREDIT        TO  HST-CREDIT.                               
           MOVE BNK-RETURN        TO  HST-RETURN.                               
                                                                                
           MOVE REQS-INFO-LR     TO  LOGICAL-RECORD-NAME.                       
           MOVE 'GWEFCPDR'       TO  ICBM-PROGRAM-NAME.                         
           CALL GAEDATSR     USING     STORE-LR                                 
                                     HIST-FILE-INFO                             
                                     ICBM.                                      
           EVALUATE TRUE                                                        
               WHEN LR-STATUS-OK                                                
                    CONTINUE                                                    
               WHEN OTHER                                                       
                 SET REQ-PAD-LOGIC-ABORTED   TO TRUE                            
                 MOVE    'WR    '            TO REQ-BATCH-ID                    
                 MOVE PROGRAM-LINKAGE-STATUS TO REQ-BATCH-ID(3:4)               
                 GOBACK                                                         
           END-EVALUATE.                                                        
       700-EXIT.              EXIT.                                             
                                                                                
       800-READ-CONTROL-FILE.                                                   
           MOVE CNTL-INFO-IN-LR  TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR     USING    GAEDATSR-VERB                             
                                    EFT-CONTROL-INFO                            
                                    ICBM.                                       
           EVALUATE TRUE                                                        
           WHEN LR-STATUS-OK                                                    
               CONTINUE                                                         
           WHEN OTHER                                                           
               SET REQ-PAD-LOGIC-ABORTED  TO TRUE                               
               MOVE    'CT    '    TO REQ-BATCH-ID                              
               MOVE PROGRAM-LINKAGE-STATUS TO REQ-BATCH-ID(3:4)                 
               GOBACK                                                           
           END-EVALUATE.                                                        
                                                                                
                                                                                
       800-EXIT.            EXIT.                                               
                                                                                
       900-ADD-LAG-DAYS.                                                        
      *CONVERTING YYYYMMDD TO ALIS-DATE1 FORMAT                                 
                                                                                
BM002          MOVE  'BA1E'           TO  VDATE-REQUEST-AREA.                   
               MOVE WS-LAG-START-DATE TO  VDATE1-YYYYMMDD.                      
BM002          PERFORM 997-CALL-DATE-ROUTINE  THRU 997-EXIT.                    
                                                                                
      *ADJUSTING THE BNK-LAG-PERIOD IN ALIS-DATE FORMAT                         
                                                                                
BM002          MOVE  '4A1E'           TO  VDATE-REQUEST-AREA.                   
               MOVE WS-ADJ-DAYS       TO  VDATE-ADJUST-DAYS.                    
               MOVE WS-ADJ-MONTHS     TO  VDATE-ADJUST-MONTHS.                  
               MOVE WS-ADJ-YEARS      TO  VDATE-ADJUST-YEARS.                   
BM002          PERFORM 997-CALL-DATE-ROUTINE  THRU 997-EXIT.                    
               MOVE VDATE-ALIS-DATE2  TO  VDATE-ALIS-DATE1.                     
                                                                                
      *CONVERTING ALIS-DATE FORMAT TO YYYYMMDD FORMAT                           
                                                                                
BM002          MOVE  '2A1E'           TO  VDATE-REQUEST-AREA.                   
BM002          PERFORM 997-CALL-DATE-ROUTINE  THRU 997-EXIT.                    
               MOVE VDATE1-YYYYMMDD   TO  REQ-EFF-DATE-OUT.                     
       900-EXIT.            EXIT.                                               
                                                                                
       950-BUILD-HEADER-INFO.                                                   
                MOVE 'GP'                   TO CTRL-SOURCE-ID.                  
                ADD      1                  TO CTRL-SOURCE-SEQ.                 
                MOVE CTRL-BATCH-ID          TO EFTREQ-BATCH-ID.                 
                MOVE CTRL-PREV-DATE         TO EFTREQ-PREV-DATE.                
                MOVE CTRL-PREV-SEQ          TO EFTREQ-PREV-SEQ.                 
                MOVE WS-SYSTEM-DATE         TO EFTREQ-CURR-DATE.                
                IF WS-SYSTEM-DATE = CTRL-PREV-DATE                              
                   ADD  1  TO CTRL-PREV-SEQ GIVING EFTREQ-CURR-SEQ              
                ELSE                                                            
                   MOVE 1  TO                      EFTREQ-CURR-SEQ              
                END-IF                                                          
                MOVE  EFTREQ-CURR-SEQ  TO CTRL-PREV-SEQ.                        
                MOVE  EFTREQ-CURR-DATE TO CTRL-PREV-DATE.                       
       950-EXIT.            EXIT.                                               
                                                                                
      *---------------------------------------------                            
      *  CALL DATE ROUTINES                                                     
      *  LOGIC TO GET TODAYS DATE                                               
      *  CALL TO GWEFCBNK (EFT BANK INFO I/O)                                   
      *---------------------------------------------                            
           COPY GWEFCPDC.                                                       
                                                                                
                                                                                
      *--------------------------------------------                             
      *    GWEFCPDR ENDS HERE                                                   
      *--------------------------------------------                             
