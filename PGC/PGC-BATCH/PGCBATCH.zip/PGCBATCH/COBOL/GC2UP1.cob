       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2UP1.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *This program has been examined/renovated for Year 2000 compliance.       
      ******************************************************************        
      *REMARKS.                                                                 
      *    UPDATE THE COMMISSION HISTORY DATA BASE - DAILY.                     
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *  INPUT:     'GCOMXTR7' COMMISSION HISTORY EXTRACT FILE        *         
      *             'GPRMXTR7' PREMIUM HISTORY EXTRACT FILE           *         
      *             COMMISSION HISTORY DATABASE                       *         
      *                                                               *         
      *             COMMISSION HISTORY UPDATE - ACTION REPORT         *         
      *             COMMISSION HISTORY DATABASE                       *         
      *                                                               *         
      *  FREQUENCY: DAILY OR ON REQUEST                               *         
      *                                                               *         
      *  NOTE:      THIS PROGRAM SHOULD BE RUN EACH TIME THE GYPSY    *         
      *             UPDATE (GFILEMAN) PRODUCES THE ABOVE FILES        *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *               PROGRAM MAINTENANCE LOG                         *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *  DATE:    BY:         PROBLEM DESCRIPTION:                    *         
      * 06/24/86  F GAGNE   - SUMMARY REPORT                          *         
      *                       - PRINT RUN DATE                        *         
      *                       - PRINT FILE DATE                       *         
      *                     - INCLUDE I/O MODULE TO CREATE GROUP AND  *         
      *                       GRACCT RECORDS.                         *         
      * 07/08/86  L HAMPTON - TO REFLECT SUBSCHEMA CHANGES TO         *         
      *                       GWCORCNTL                               *         
      *                                                               *         
      * 10/01/86  L HAMPTON - TO SET LAST-RECON-DATE TO ACCT-EFF-DATE *         
      *                       MINUS 1 DAY                             *         
      * FEB12/87  L HAMPTON - PUT IN CONTROL TOTALS                   *         
      * MAR12/87  L HAMPTON - DISPLAY SIGN OF CONTROL TOTALS          *         
      * AUG06/87  L HAMPTON - CHANGED SUBSCHEMA TO SSGWCO02 FROM 03   *         
      * NOV25/87  L HAMPTON - PUT IN MSG IF PAY BASIS DOESN'T EXIST   *         
      *                                                               *         
      * NOV01/90  M PRANGE  - WANT TO USE PSMNXT-RNEW-DATE INSTEAD    *         
      *                       GGINEXT-ANNIVERSARY IN GWCOCADG CALLS.  *         
      *                                                               *         
      * AUG28/92  A NIKELSKI- ACCUM ALL SALES CREDITS EARNED TO       *         
      *                       'GWCORACCUM'                            *         
      *                                                               *         
      * MM/DD/YY  X XXXXX   XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX            *         
      *                                                               *         
      *                                                               *         
      * OCT03/08  IBM       ENTERPRISE COMPILER UPGRADE               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCUP1          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2UP1 W-S STARTS HERE **'.                                  
      /                                                                         
       01  WS-PARAMETERS.                                                       
                                                                                
           05  WS-ERROR-CNT               VALUE +0        PIC S9(5).            
           05  WS-WARNING-CNT             VALUE +0        PIC S9(5).            
           05  WS-REC-PROCESSED           VALUE +0        PIC S9(5).            
           05  QDATE-FORMATA              VALUE 'AC'      PIC XX.               
           05  QDATE-FORMATB              VALUE 'BC'      PIC XX.               
           05  WS-TOTAL-COMM-EARN    VALUE ZERO   COMP-3  PIC S9(9)V99.         
           05  WS-TOTAL-COMM-PAID    VALUE ZERO   COMP-3  PIC S9(9)V99.         
           05  WS-TOTAL-SCR-EARN     VALUE ZERO   COMP-3  PIC S9(9)V99.         
           05  WS-TOTAL-SCR-PAID     VALUE ZERO   COMP-3  PIC S9(9)V99.         
           05  WS-TOTAL-NAP-EARN     VALUE ZERO   COMP-3  PIC S9(9)V99.         
           05  WS-TOTAL-NAP-PAID     VALUE ZERO   COMP-3  PIC S9(9)V99.         
           05  WS-TOTAL-SERV-PAID    VALUE ZERO   COMP-3  PIC S9(9)V99.         
                                                                                
           05  WS-ACCT-EFF-DATE.                                                
               10  WS-ACCT-EFF-YEAR       VALUE +0 COMP-3 PIC S9(3).            
               10  WS-ACCT-EFF-DAY        VALUE +0 COMP-3 PIC S9(3).            
                                                                                
           05  WS-NEXT-RECON-DATE.                                              
               10  WS-NEXT-RECON-YEAR     VALUE +0 COMP-3 PIC S9(3).            
               10  WS-NEXT-RECON-DAY      VALUE +0 COMP-3 PIC S9(3).            
                                                                                
           05  DLSREAD-PARMS.                                                   
               10  READ-SYS010            VALUE 'SYS010'  PIC X(6).             
               10  READ-RET-CODE   COMP-3 VALUE +0        PIC S9.               
               10  READ-RECSIZE           VALUE 77        PIC 9(5).             
               10  READ-BLKSIZE           VALUE 77        PIC 9(5).             
               10  READ-FORMAT            VALUE 'FB'      PIC X(2).             
               10  READ-REC-CNT    COMP-3 VALUE +0        PIC S9(7).            
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         COMMISSION HISTORY UPDATE - ACTION REPORT             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  ACTION-REPORT-AREA.                                                  
                                                                                
           05  DLSW-ACTION-RPT.                                                 
               10  ACTION-SYS021           VALUE 'SYS021'  PIC X(6).            
               10  ACTION-RET-CODE  COMP-3 VALUE +0        PIC S9.              
               10  ACTION-LINE             VALUE SPACES    PIC X(133).          
               10  ACTION-RECSIZE          VALUE 133       PIC 9(5).            
               10  ACTION-BLKSIZE          VALUE 3990      PIC 9(5).            
               10  ACTION-FORMAT           VALUE 'FB'      PIC X(2).            
               10  ACTION-COUNT     COMP-3 VALUE +0        PIC S9(7).           
                                                                                
           05  ACTION-SW                   PIC X           VALUE '0'.           
               88  NO-ACTION                               VALUE '0'.           
               88  PREM-GR-ACTION                          VALUE '1'.           
               88  PREM-ACCT-ACTION                        VALUE '2'.           
               88  COMM-GR-ACTION                          VALUE '3'.           
               88  COMM-ACCT-ACTION                        VALUE '4'.           
               88  COMM-COV-INVALID                        VALUE '5'.           
               88  NO-INPUT                                VALUE '6'.           
               88  EFF-DATE-INVALID                        VALUE '7'.           
               88  NO-AGENT-PAY-BASIS                      VALUE '8'.           
                                                                                
           05  ACTION-HEADINGS.                                                 
               10  ACTION-HDG-1.                                                
                   15  FILLER              PIC X(13)      VALUE                 
                                                        '1 GWCOCUP1-1'.         
                   15  FILLER              PIC X(30)      VALUE SPACES.         
                   15  FILLER              PIC X(55)      VALUE                 
                                        'MANUFACTURERS LIFE OF CANADA'.         
                   15  FILLER              PIC X(14)      VALUE                 
                                               'FILE DATE :  '.                 
                   15  ACTION-FILE-DATE    PIC X(7)       VALUE SPACES.         
                                                                                
               10  ACTION-HDG-2.                                                
                   15  FILLER              PIC X(43)      VALUE SPACES.         
                   15  FILLER              PIC X(58)      VALUE                 
                           'COMMISSION HISTORY UPDATE - ACTION REPORT'.         
                   15  FILLER              PIC X(18)      VALUE SPACES.         
                                                                                
           05  ACTION-LINES.                                                    
               10  ACTION-LINE-1.                                               
                   15  ACTION-CC-1         PIC X         VALUE '0'.             
                   15  FILLER              PIC X(7)      VALUE 'GROUP='.        
REN                15  ACTION-GROUP-NUMBER-1    PIC X(7) VALUE SPACES.          
                   15  FILLER              PIC X(60)     VALUE                  
                 ' NEW GROUP RECORD HAS BEEN ADDED WITH PREMIUM INFO'.          
                                                                                
               10  ACTION-LINE-2.                                               
                   15  ACTION-CC-2         PIC X          VALUE '0'.            
                   15  FILLER              PIC X(52)      VALUE                 
                 'NEW ACCOUNT RECORD HAS BEEN ADDED WITH PREMIUM INFO'.         
                   15  FILLER              PIC X(52)      VALUE                 
                '- ENSURE THAT RECONCILIATION DATES ARE VALID - ENTER'.         
                   15  FILLER              PIC X(28)      VALUE                 
                                        ' CORRECTION ON-LINE      ***'.         
                                                                                
               10  ACTION-LINE-3.                                               
                   15  ACTION-CC-3         PIC X         VALUE '0'.             
                   15  FILLER              PIC X(7)      VALUE 'GROUP='.        
REN                15  ACTION-GROUP-NUMBER-3 PIC X(7)    VALUE SPACES.          
                   15  FILLER              PIC X(60)     VALUE                  
               ' NEW GROUP RECORD HAS BEEN ADDED WITH COMMISSION INFO'.         
                                                                                
               10  ACTION-LINE-4.                                               
                   15  ACTION-CC-4         PIC X          VALUE '0'.            
                   15  FILLER              PIC X(52)      VALUE                 
                 'NEW ACCOUNT RECORD WAS ADDED WITH COMMISSION INFO'.           
                   15  FILLER              PIC X(52)      VALUE                 
                '- ENSURE THAT RECONCILIATION DATES ARE VALID - ENTER'.         
                   15  FILLER              PIC X(28)      VALUE                 
                                        ' CORRECTION ON-LINE      ***'.         
                                                                                
               10  ACTION-LINE-6.                                               
                   15  ACTION-CC-6         PIC X          VALUE '0'.            
                   15  ACTION-REC-PROCESSED PIC ZZZZ9     VALUE ZERO.           
                   15  FILLER              PIC X(40)      VALUE                 
                       ' RECORDS WERE SUCCESSFULLY PROCESSED '.                 
                                                                                
               10  ACTION-LINE-7.                                               
                   15  ACTION-CC-7         PIC X          VALUE '0'.            
                   15  FILLER              PIC X(56)      VALUE                 
            'FOLLOWING COMPENSATION INFO HAS BEEN ADDED TO DATABASE '.          
                   15  FILLER              PIC X(58)      VALUE                 
            'WITH AN INVALID COVERAGE TYPE - ENTER CORRECTION  ON-LINE'.        
                   15  FILLER              PIC X(18)      VALUE                 
                                                    '    *** ERROR ***'.        
                                                                                
               10  ACTION-LINE-8.                                               
                   15  ACTION-CC-8   PIC X      VALUE ' '.                      
                   15  FILLER        PIC X(10)  VALUE ' GROUP='.                
REN                15  ACTION-COV-GROUP         PIC 9(7).                       
                   15  FILLER        PIC X(10)  VALUE ' ACCOUNT='.              
                   15  ACTION-COV-ACCOUNT       PIC XXX.                        
                   15  FILLER        PIC X(10)  VALUE ' DUE-DATE='.             
                   15  ACTION-COV-DATE          PIC X(7).                       
                   15  FILLER        PIC X(10)  VALUE ' COV-TYPE='.             
                   15  ACTION-COV-TYPE          PIC X.                          
                                                                                
               10  ACTION-LINE-10.                                              
                   15  ACTION-CC-10  PIC X   VALUE ' '.                         
                   15  FILLER     PIC X(7)   VALUE 'GROUP='.                    
REN                15  ACTION-ADD-GROUP      PIC 9(7).                          
                   15  FILLER     PIC X(10)  VALUE ' ACCOUNT='.                 
                   15  ACTION-ADD-ACCOUNT    PIC XXX.                           
                   15  FILLER     PIC X(18)  VALUE ' ACCT EFFECTIVE ='.         
                   15  ACTION-ADD-ACCT-EFFECTIVE  PIC X(7).                     
                   15  FILLER     PIC X(18)  VALUE ' LAST-RECON-DATE='.         
                   15  ACTION-ADD-LAST-DATE  PIC X(7).                          
                   15  FILLER     PIC X(16)  VALUE ' NEXT RENEWAL='.            
                   15  ACTION-ADD-RENEWAL         PIC X(7).                     
                   15  FILLER     PIC X(18)  VALUE ' NEXT-RECON-DATE='.         
                   15  ACTION-ADD-NEXT-DATE  PIC X(7).                          
                                                                                
               10  ACTION-LINE-11.                                              
                   15  ACTION-CC-11        PIC X      VALUE '0'.                
                   15  FILLER              PIC X(132) VALUE                     
                               ' NO INPUT READ DATABASE UNCHANGED'.             
                                                                                
               10  ACTION-LINE-12.                                              
                   15  ACTION-CC-12        PIC X      VALUE '0'.                
                   15  ACTION-ERR-CNT      PIC ZZZZ9  VALUE ZERO.               
                   15  FILLER              PIC X(127) VALUE                     
                ' ERRORS WERE DETECTED DURING PROGRAM EXECUTION'.               
                                                                                
               10  ACTION-LINE-13.                                              
                   15  ACTION-CC-13  PIC X   VALUE '0'.                         
REN                15  ACTION-GROUP-13       PIC X(7).                          
                   15  FILLER                PIC X VALUE SPACES.                
                   15  ACTION-ACCOUNT-13     PIC XXX.                           
                   15  FILLER                PIC X(52) VALUE                    
                  ' COMP-EFF-DATE PRIOR TO LAST RECONCILIATION DATE.  '.        
                   15  FILLER     PIC X(18) VALUE 'COMP EFFECTIVE = '.          
                   15  ACTION-COMP-EFF-13         PIC X(7).                     
                   15  FILLER     PIC X(23)  VALUE                              
                   ' LAST RECONCILIATION = '.                                   
                   15  ACTION-LAST-RECON-13  PIC X(7).                          
                   15  FILLED     PIC X(16) VALUE '   ** WARNING **'.           
                                                                                
               10  ACTION-LINE-14.                                              
                   15  ACTION-CC-14        PIC X      VALUE '0'.                
                   15  ACTION-WARNING-CNT  PIC ZZZZ9  VALUE ZERO.               
                   15  FILLER              PIC X(127) VALUE                     
                ' WARNINGS WERE DETECTED DURING PROGRAM EXECUTION'.             
                                                                                
               10  ACTION-LINE-15.                                              
                   15  ACTION-CC-15  PIC X   VALUE '0'.                         
REN                15  ACTION-GROUP-15       PIC X(7).                          
                   15  FILLER                PIC X VALUE SPACES.                
                   15  ACTION-ACCOUNT-15     PIC XXX.                           
                   15  FILLER                PIC X(07) VALUE                    
                  ' AGENT '.                                                    
                   15  ACTION-AGENT-15       PIC 9(6).                          
                   15  FILLER                PIC X(54) VALUE                    
               ' HAS NO PAY BASIS RECORDED.  ALL RECORDS PROCESSED ON '.        
                   15  ACTION-COMP-PROC-15         PIC X(7).                    
                   15  FILLER     PIC X(34)  VALUE                              
                   ' WERE PROCESSED USING THE DEFAULT.'.                        
                   15  FILLER     PIC X(15) VALUE '   ** ACTION **'.            
                                                                                
               10  ACTION-LINE-16.                                              
                   15  ACTION-CC-16        PIC X      VALUE ' '.                
                   15  FILLER              PIC X(51)  VALUE                     
                ' NOTE: RENEWAL DATE SHOWN USED GGINEXT-ANNIVERSARY '.          
                   15  FILLER              PIC X(76)  VALUE                     
                ' BECAUSE PSMNXT-RNEW-DATE DID NOT YET EXIST       '.           
                                                                                
           05  CONTROL-HEADINGS.                                                
               10  CONTROL-HDG-1.                                               
                   15  FILLER              PIC X(13)      VALUE                 
                                                        '1 GWCOCUP1-1'.         
                   15  FILLER              PIC X(30)      VALUE SPACES.         
                   15  FILLER              PIC X(55)      VALUE                 
                                        'MANUFACTURERS LIFE OF CANADA'.         
                   15  FILLER              PIC X(14)      VALUE                 
                                               'FILE DATE :  '.                 
                   15  CONTROL-FILE-DATE   PIC X(7)       VALUE SPACES.         
                                                                                
               10  CONTROL-HDG-2.                                               
                   15  FILLER              PIC X(43)      VALUE SPACES.         
                   15  FILLER              PIC X(58)      VALUE                 
                           'COMMISSION HISTORY UPDATE - CONTROL REPORT'.        
                   15  FILLER              PIC X(18)      VALUE SPACES.         
                                                                                
           05  CONTROL-LINE-1.                                                  
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(31)      VALUE                     
                   'TOTAL COMMISSION PAID      : $ '.                           
               10  CONTROL-COMM-PAID        PIC ZZZ,ZZZ,ZZ9.99-.                
           05  CONTROL-LINE-2.                                                  
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(31)      VALUE                     
                   'TOTAL COMMISSION EARNED    : $ '.                           
               10  CONTROL-COMM-EARN        PIC ZZZ,ZZZ,ZZ9.99-.                
           05  CONTROL-LINE-3.                                                  
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(31)      VALUE                     
                   'TOTAL SALES CREDITS PAID   : $ '.                           
               10  CONTROL-SCR-PAID        PIC ZZZ,ZZZ,ZZ9.99-.                 
           05  CONTROL-LINE-4.                                                  
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(31)      VALUE                     
                   'TOTAL SALES CREDITS EARNED : $ '.                           
               10  CONTROL-SCR-EARN        PIC ZZZ,ZZZ,ZZ9.99-.                 
           05  CONTROL-LINE-5.                                                  
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(31)      VALUE                     
                   'TOTAL NAP PAID             : $ '.                           
               10  CONTROL-NAP-PAID        PIC ZZZ,ZZZ,ZZ9.99-.                 
           05  CONTROL-LINE-6.                                                  
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(31)      VALUE                     
                   'TOTAL NAP EARNED           : $ '.                           
               10  CONTROL-NAP-EARN        PIC ZZZ,ZZZ,ZZ9.99-.                 
           05  CONTROL-LINE-7.                                                  
               10  FILLER              PIC X         VALUE '0'.                 
               10  FILLER              PIC X(31)      VALUE                     
                   'TOTAL SERVICE FEES PAID    : $ '.                           
               10  CONTROL-SERV-PAID       PIC ZZZ,ZZZ,ZZ9.99-.                 
                                                                                
      /                                                                         
       01  INPUT-AREA.                                                          
REN        05  INPUT-GROUP-NUMBER                        PIC 9(7).              
           05  INPUT-GROUP-ACCOUNT                       PIC XXX.               
           05  INPUT-REC-TYPE                            PIC X.                 
           05  FILLER                                    PIC X(68).             
      /                                                                         
       COPY GCOMDAT7.                                                           
      /                                                                         
       COPY GCOMXTR7.                                                           
      /                                                                         
       COPY GPRMXTR7.                                                           
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - CONTROL RECORD DESCRIPTION                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCNTL                                                               
CPYNME     COPY GCICNTL.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP RECORD DESCRIPTION                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - COMPENSATION RECORD DESCRIPTION           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - AGENT RECORD DESCRIPTION                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GFO RECORD DESCRIPTION                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGFO                                                                
CPYNME     COPY GCIGFO.                                                         
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - ACCUM RECORD DESCRIPTION                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORACCUM                                                              
CPYNME     COPY GCIACCUM.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT WORK RECORD                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORADG-WORK-RECORD                                                    
CPYNME     COPY GCRADGW.                                                        
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           '** GWCORCUP1 W-S ENDS HERE **'.                                     
      /                                                                         
      * GWCORPAYBASIS                                                           
CPYNME     COPY GCIPAYB.                                                        
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GC2ADG                       PIC X(8)  VALUE 'GC2ADG'.           
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2UP1'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       000-MAINLINE.                                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                PROGRAM MAINLINE                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 100-INITIALIZE.                                              
           PERFORM 200-PROCESS-RECORDS THRU 299-EXIT                            
               UNTIL READ-RET-CODE IS GREATER THAN +0.                          
           PERFORM 300-END-OF-JOB.                                              
           STOP RUN.                                                            
      /                                                                         
       100-INITIALIZE.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREAS TO BE ACCESSED                             *         
      *     READ FIRST INPUT RECORD                                   *         
      *     PRINT REPORT HEADING                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
FXXTOK     MOVE 'GC2UP1' TO PROGRAM-NAME.                                       
      *%   BIND RUN-UNIT.                                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND GWCORCNTL.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGROUP.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGRACCT.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORCOMP.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGFO.                                                       
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORAGENT.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORACCUM.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           PERFORM 900-READ-EXTRACT.                                            
           MOVE INPUT-AREA TO GCOMDATE.                                         
                                                                                
           IF  READ-RET-CODE = ZERO AND                                         
               GDAT-REC-TYPE = 'D'                                              
               MOVE 1 TO WS-REC-PROCESSED                                       
           ELSE                                                                 
               DISPLAY 'NO DATE RECORD ON INPUT FILE - FORCED TO ABEND'         
                   UPON CONSOLE                                                 
               ADD 1 TO WS-ERROR-CNT                                            
               MOVE 'DATE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
MAN02      CALL QDATEQ2 USING QDATE-FORMATA                                     
MAN02                         GDAT-RUN-DATE                                     
MAN02                         ACTION-FILE-DATE.                                 
           MOVE ACTION-FILE-DATE TO CONTROL-FILE-DATE.                          
           PERFORM 600-ACTION-REPORT.                                           
                                                                                
      *%   OBTAIN FIRST GWCORCNTL WITHIN GW-COMP-AREA1.                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 12 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           IF  GDAT-RUN-DATE GREATER THAN LAST-GIPSY-DAILY-RUN-DATE             
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'INVALID INPUT FILE - FORCED TO ABEND'                   
                   UPON CONSOLE                                                 
               ADD 1 TO WS-ERROR-CNT                                            
               MOVE 'DATE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
           PERFORM 900-READ-EXTRACT.                                            
                                                                                
           IF  READ-RET-CODE = ZERO                                             
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  READ-RET-CODE = +4                                           
                   MOVE '6' TO ACTION-SW                                        
                   PERFORM 600-ACTION-REPORT                                    
               ELSE                                                             
                   ADD 1 TO WS-ERROR-CNT                                        
                   MOVE 'READ' TO ERROR-STATUS                                  
      *%           PERFORM IDMS-STATUS.                                         
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT.                                 
                                                                                
           MOVE ZERO TO WS-TOTAL-COMM-PAID                                      
                        WS-TOTAL-COMM-EARN                                      
                        WS-TOTAL-SCR-PAID                                       
                        WS-TOTAL-SCR-EARN                                       
                        WS-TOTAL-NAP-PAID                                       
                        WS-TOTAL-NAP-EARN                                       
                        WS-TOTAL-SERV-PAID.                                     
       100-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       200-PROCESS-RECORDS.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     DETERMINE WHICH ROUTINE TO EXECUTE DEPENDING ON THE       *         
      *     RECORD TYPE TO BE PROCESSED                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  INPUT-REC-TYPE EQUAL 'P'                                         
               PERFORM 400-PROCESS-PREMIUM THRU 409-EXIT                        
           ELSE                                                                 
               IF  INPUT-REC-TYPE = 'C'                                         
                   PERFORM 500-PROCESS-COMPENSATION THRU 509-EXIT               
               ELSE                                                             
                   DISPLAY 'INPUT REC-TYPE INVALID - FORCED TO ABEND'           
                       UPON CONSOLE                                             
                   ADD 1 TO WS-ERROR-CNT                                        
                   MOVE 'RTYP' TO ERROR-STATUS                                  
      *%           PERFORM IDMS-STATUS.                                         
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT.                                 
                                                                                
           ADD 1 TO WS-REC-PROCESSED.                                           
           PERFORM 900-READ-EXTRACT.                                            
           IF  READ-RET-CODE = ZERO OR +4                                       
               NEXT SENTENCE                                                    
           ELSE                                                                 
               ADD 1 TO WS-ERROR-CNT                                            
               MOVE 'READ' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
       299-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       300-END-OF-JOB.                                                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     -  CLOSE DATABASE                                         *         
      *     -  CHECK THAT ALL RECORDS HAVE BEEN READ AND PROCESSED    *         
      *     -  PRINT TRAILER-LINE(S) ON REPORT                        *         
      *     -  CLOSE REPORT FILE                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE WS-REC-PROCESSED TO ACTION-REC-PROCESSED.                       
           MOVE ACTION-LINE-6 TO ACTION-LINE.                                   
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           IF  WS-REC-PROCESSED = READ-REC-CNT                                  
               NEXT SENTENCE                                                    
           ELSE                                                                 
               ADD 1 TO WS-ERROR-CNT.                                           
                                                                                
           MOVE WS-ERROR-CNT TO ACTION-ERR-CNT.                                 
           MOVE ACTION-LINE-12 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-WARNING-CNT TO ACTION-WARNING-CNT.                           
           MOVE ACTION-LINE-14 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE '-* * * END OF REPORT * * *' TO ACTION-LINE.                    
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE CONTROL-HDG-1 TO ACTION-LINE.                                   
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE CONTROL-HDG-2 TO ACTION-LINE.                                   
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-TOTAL-COMM-PAID TO CONTROL-COMM-PAID.                        
           MOVE CONTROL-LINE-1 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-TOTAL-COMM-EARN TO CONTROL-COMM-EARN.                        
           MOVE CONTROL-LINE-2 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-TOTAL-SCR-PAID TO CONTROL-SCR-PAID.                          
           MOVE CONTROL-LINE-3 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-TOTAL-SCR-EARN TO CONTROL-SCR-EARN.                          
           MOVE CONTROL-LINE-4 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-TOTAL-NAP-PAID TO CONTROL-NAP-PAID.                          
           MOVE CONTROL-LINE-5 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-TOTAL-NAP-EARN TO CONTROL-NAP-EARN.                          
           MOVE CONTROL-LINE-6 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE WS-TOTAL-SERV-PAID TO CONTROL-SERV-PAID.                        
           MOVE CONTROL-LINE-7 TO ACTION-LINE.                                  
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE '-* * * END OF REPORT * * *' TO ACTION-LINE.                    
           PERFORM 910-WRITE-ACTION.                                            
                                                                                
           MOVE +4 TO ACTION-RET-CODE.                                          
           CALL 'DLSWRITE' USING ACTION-SYS021                                  
                                 ACTION-RET-CODE                                
                                 ACTION-LINE                                    
                                 ACTION-RECSIZE                                 
                                 ACTION-BLKSIZE                                 
                                 ACTION-FORMAT                                  
                                 ACTION-COUNT.                                  
           IF ACTION-RET-CODE = +4                                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               ADD 1 TO WS-ERROR-CNT                                            
               MOVE 'CLSE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
      *%   FIND CURRENT GWCORCNTL.                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-FIND                                               
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           MOVE GDAT-RUN-DATE TO LAST-GIPSY-DAILY-RUN-DATE.                     
      *%   MODIFY GWCORCNTL.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      /                                                                         
       400-PROCESS-PREMIUM.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    -  MOVE INPUT TO PREMIUM RECORD DESCRIPTION                *         
      *    -  GET GROUP OWNER                                         *         
      *          IF NOT FOUND                                         *         
      *             CREATE GROUP RECORD                               *         
      *             CREATE ACCT MEMBER                                *         
      *             PRODUCE ACTION REPORT.                            *         
      *    -  GET ACCT OWNER                                          *         
      *          IF NOT FOUND                                         *         
      *             CREATE ACCT RECORD                                *         
      *             PRODUCE ACTION REPORT.                            *         
      *    -  GET ACCUM RECORD                                        *         
      *           MATCH ON DATES                                      *         
      *           IF NOT FOUND                                        *         
      *              CREATE ACCUM RECORD                              *         
      *           ELSE                                                *         
      *              UPDATE ACCUM RECORD.                             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE INPUT-AREA TO GPRMXTR7.                                         
                                                                                
           IF  GPXT-GROUP-NUMBER = GROUP-NUMBER OF GWCORGROUP                   
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE GPXT-GROUP-NUMBER TO GROUP-NUMBER OF GWCORGROUP             
      *%       OBTAIN CALC GWCORGROUP                                           
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 7 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +6  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-SELECT-USING-PRIM-KEY                          
MAN02                     FCCSPLIO-GWCORGROUP                                   
MAN02                     FCCSPL-GWCORGROUP                                     
MAN02                     GWCORGROUP                                            
MAN02                     FCCSPL-OBTAIN                                         
MAN02                     FCCSPL-NOKEEP                                         
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            IF NOT DB-REC-NOT-FOUND                                          
IOS               PERFORM 799-SQL-STATUS-02                                     
IOS                  THRU 799-SQL-STATUS-02-EXIT                                
IOS            ELSE                                                             
                   MOVE GPXT-ACCT-EFFECTIVE-DATE TO WS-ACCT-EFF-DATE            
                   MOVE GPXT-NEXT-RECON-DATE     TO WS-NEXT-RECON-DATE          
                   PERFORM 700-CREATE-OWNERS                                    
                   PERFORM 600-ACTION-REPORT.                                   
                                                                                
           IF  GPXT-GROUP-ACCOUNT = GROUP-ACCOUNT OF GWCORGRACCT                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE GPXT-GROUP-ACCOUNT TO GROUP-ACCOUNT OF GWCORGRACCT          
      *%       OBTAIN CALC GWCORGRACCT                                          
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 8 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +6  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-SELECT-USING-PRIM-KEY                          
MAN02                     FCCSPLIO-GWCORGRACCT                                  
MAN02                     FCCSPL-GWCORGRACCT                                    
MAN02                     GWCORGRACCT                                           
MAN02                     FCCSPL-OBTAIN                                         
MAN02                     FCCSPL-NOKEEP                                         
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            IF NOT DB-REC-NOT-FOUND                                          
IOS               PERFORM 799-SQL-STATUS-02                                     
IOS                  THRU 799-SQL-STATUS-02-EXIT                                
IOS            ELSE                                                             
                   MOVE GPXT-ACCT-EFFECTIVE-DATE TO WS-ACCT-EFF-DATE            
                   MOVE GPXT-NEXT-RECON-DATE     TO WS-NEXT-RECON-DATE          
                   PERFORM 700-CREATE-OWNERS                                    
                   PERFORM 600-ACTION-REPORT.                                   
                                                                                
      *%   OBTAIN FIRST GWCORACCUM WITHIN GRACCT-ACCUM                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           PERFORM 410-GET-ACCUM                                                
               UNTIL GPXT-PREM-DUE-DATE = PREM-DUE-DATE OF GWCORACCUM           
               OR    DB-END-OF-SET.                                             
                                                                                
           IF  DB-END-OF-SET                                                    
               MOVE GPXT-PREM-DUE-DATE TO PREM-DUE-DATE OF GWCORACCUM           
               MOVE GPXT-PREM-AMT TO PREM-AMT-PAID OF GWCORACCUM                
               MOVE ZERO TO COMM-AMT-EARNED OF GWCORACCUM                       
               MOVE ZERO TO SALES-CREDITS-AMT-EARNED OF GWCORACCUM              
      *%       STORE GWCORACCUM                                                 
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 10 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORACCUM                                   
MAN02                     FCCSPL-GWCORACCUM                                     
MAN02                     GWCORACCUM                                            
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
           ELSE                                                                 
               ADD GPXT-PREM-AMT TO PREM-AMT-PAID OF GWCORACCUM                 
      *%       MODIFY GWCORACCUM.                                               
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 11 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-UPDATE                                         
MAN02                     FCCSPLIO-GWCORACCUM                                   
MAN02                     FCCSPL-GWCORACCUM                                     
MAN02                     GWCORACCUM                                            
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
       409-EXIT.                                                                
           EXIT.                                                                
                                                                                
       410-GET-ACCUM.                                                           
                                                                                
      *%   OBTAIN NEXT GWCORACCUM WITHIN GRACCT-ACCUM                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 12 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                   NEXT SENTENCE.                                               
      /                                                                         
       500-PROCESS-COMPENSATION.                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    -  MOVE INPUT TO COMMISSION HISTORY RECORD DESCRIPTION.    *         
      *    -  GET GROUP OWNER                                         *         
      *          IF NOT FOUND                                         *         
      *             CREATE GROUP RECORD                               *         
      *             CREATE ACCT OWNER                                 *         
      *             PRODUCE ACTION REPORT.                            *         
      *    -  GET ACCT OWNER                                          *         
      *          IF NOT FOUND                                         *         
      *             CREATE ACCT RECORD                                *         
      *             PRODUCE ACTION REPORT.                            *         
      *    -  MOVE INPUT DATA TO COMP RECORD DESCRIPTION.             *         
      *    -  GET AGENT OWNER RECORD                                  *         
      *           IF NOT FOUND                                        *         
      *              CREATE AGENT RECORD.                             *         
      *    -  STORE COMP RECORD.                                      *         
      *    -  GET GFO OWNER RECORD                                    *         
      *          IF NOT FOUND                                         *         
      *             CREATE GFO RECORD.                                *         
      *    -  CONNECT COMP RECORD TO GFO OWNER RECORD.                *         
      *                                                               *         
      *    IF COV-TYPE INVALID                                        *         
      *       PRINT MESSAGE ON ACTION REPORT.                         *         
      *    -  IF  COMMISSION IS EARNED OR                             *         
      *           (IE: COMP-TYPE = 'C' AND COMP-DISP = 'E')           *         
      *           SALES CREDIT IS EARNED                              *         
      *           (IE: COMP-TYPE = 'S' AND COMP-DISP = 'E')           *         
      *           GET ACCUM RECORD                                    *         
      *               MATCH ON DATES                                  *         
      *               IF NOT FOUND                                    *         
      *                  CREATE ACCUM RECORD                          *         
      *               ELSE                                            *         
      *                  UPDATE ACCUM RECORD.                         *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE INPUT-AREA TO GCOMXTRT.                                         
                                                                                
           IF  GCXT-GROUP-NUMBER = GROUP-NUMBER OF GWCORGROUP                   
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE GCXT-GROUP-NUMBER TO GROUP-NUMBER OF GWCORGROUP             
      *%       OBTAIN CALC GWCORGROUP                                           
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 13 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +6  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-SELECT-USING-PRIM-KEY                          
MAN02                     FCCSPLIO-GWCORGROUP                                   
MAN02                     FCCSPL-GWCORGROUP                                     
MAN02                     GWCORGROUP                                            
MAN02                     FCCSPL-OBTAIN                                         
MAN02                     FCCSPL-NOKEEP                                         
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            IF NOT DB-REC-NOT-FOUND                                          
IOS               PERFORM 799-SQL-STATUS-02                                     
IOS                  THRU 799-SQL-STATUS-02-EXIT                                
IOS            ELSE                                                             
                   MOVE GCXT-ACCT-EFFECTIVE-DATE TO WS-ACCT-EFF-DATE            
                   MOVE GCXT-NEXT-RECON-DATE     TO WS-NEXT-RECON-DATE          
                   PERFORM 700-CREATE-OWNERS                                    
                   MOVE '3' TO ACTION-SW                                        
                   PERFORM 600-ACTION-REPORT.                                   
                                                                                
           IF  GCXT-GROUP-ACCOUNT = GROUP-ACCOUNT OF GWCORGRACCT                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE GCXT-GROUP-ACCOUNT TO GROUP-ACCOUNT OF GWCORGRACCT          
      *%       OBTAIN CALC GWCORGRACCT                                          
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 14 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +6  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-SELECT-USING-PRIM-KEY                          
MAN02                     FCCSPLIO-GWCORGRACCT                                  
MAN02                     FCCSPL-GWCORGRACCT                                    
MAN02                     GWCORGRACCT                                           
MAN02                     FCCSPL-OBTAIN                                         
MAN02                     FCCSPL-NOKEEP                                         
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            IF NOT DB-REC-NOT-FOUND                                          
IOS               PERFORM 799-SQL-STATUS-02                                     
IOS                  THRU 799-SQL-STATUS-02-EXIT                                
IOS            ELSE                                                             
                   MOVE GCXT-ACCT-EFFECTIVE-DATE TO WS-ACCT-EFF-DATE            
                   MOVE GCXT-NEXT-RECON-DATE     TO WS-NEXT-RECON-DATE          
                   PERFORM 700-CREATE-OWNERS                                    
                   MOVE '4' TO ACTION-SW                                        
                   PERFORM 600-ACTION-REPORT.                                   
                                                                                
           MOVE GCXT-GROUP-ACCOUNT TO GROUP-ACCOUNT OF GWCORCOMP.               
           MOVE GCXT-COMP-EFF-DATE TO COMP-EFF-DATE OF GWCORCOMP.               
           MOVE GCXT-AGENT-NUMBER TO AGENT-NUMBER OF GWCORCOMP.                 
           MOVE GCXT-GFO-NUMBER TO GFO-NUMBER OF GWCORCOMP.                     
           MOVE GCXT-GROUP-REP TO GROUP-REP OF GWCORCOMP.                       
           MOVE GCXT-COMP-PROCESS-DATE TO COMP-PROCESS-DATE                     
               OF GWCORCOMP.                                                    
           MOVE GCXT-COV-TYPE TO COV-TYPE OF GWCORCOMP.                         
           MOVE GCXT-COMP-TYPE TO COMP-TYPE OF GWCORCOMP.                       
           MOVE GCXT-COMP-AMT TO COMP-AMT OF GWCORCOMP.                         
           MOVE GCXT-COMP-REASON TO COMP-REASON OF GWCORCOMP.                   
           MOVE GCXT-RECON-IND TO RECON-IND OF GWCORCOMP.                       
           MOVE GCXT-COMP-DISP TO COMP-DISP OF GWCORCOMP.                       
           MOVE GCXT-AGENT-SPLIT TO AGENT-SPLIT OF GWCORCOMP.                   
           MOVE GCXT-PREM-AMT TO PREM-AMT OF GWCORCOMP.                         
                                                                                
           IF  GCXT-AGENT-NUMBER = AGENT-NUMBER OF GWCORAGENT                   
               NEXT SENTENCE                                                    
           ELSE                                                                 
               PERFORM 520-GET-AGENT THRU 520-EXIT.                             
                                                                                
      *%   STORE GWCORCOMP.                                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 15 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 GWCORCOMP                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           IF COMP-TYPE OF GWCORCOMP EQUAL TO 'C'                               
               IF COMP-DISP OF GWCORCOMP EQUAL TO 'P'                           
                   ADD COMP-AMT OF GWCORCOMP TO                                 
                       WS-TOTAL-COMM-PAID                                       
               ELSE                                                             
                   ADD COMP-AMT OF GWCORCOMP TO                                 
                       WS-TOTAL-COMM-EARN                                       
           ELSE                                                                 
               IF COMP-TYPE OF GWCORCOMP EQUAL TO 'S'                           
                   IF COMP-DISP OF GWCORCOMP EQUAL TO 'P'                       
                       ADD COMP-AMT OF GWCORCOMP TO                             
                           WS-TOTAL-SCR-PAID                                    
                   ELSE                                                         
                       ADD COMP-AMT OF GWCORCOMP TO                             
                           WS-TOTAL-SCR-EARN                                    
               ELSE                                                             
                   IF COMP-TYPE OF GWCORCOMP EQUAL TO 'N'                       
                       IF COMP-DISP OF GWCORCOMP EQUAL TO 'P'                   
                           ADD COMP-AMT OF GWCORCOMP TO                         
                               WS-TOTAL-NAP-PAID                                
                       ELSE                                                     
                           ADD COMP-AMT OF GWCORCOMP TO                         
                               WS-TOTAL-NAP-EARN                                
                   ELSE                                                         
                       IF COMP-TYPE OF GWCORCOMP EQUAL TO 'F'                   
                           ADD COMP-AMT OF GWCORCOMP TO                         
                               WS-TOTAL-SERV-PAID.                              
                                                                                
           IF LAST-RECON-DATE GREATER THAN GDAT-RUN-DATE                        
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF COMP-EFF-DATE GREATER THAN LAST-RECON-DATE                    
                   NEXT SENTENCE                                                
               ELSE                                                             
                   MOVE '7' TO ACTION-SW                                        
                   PERFORM 600-ACTION-REPORT                                    
                   ADD 1 TO WS-WARNING-CNT.                                     
                                                                                
           IF  GCXT-GFO-NUMBER = SPACES                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  GCXT-GFO-NUMBER = GFO-NUMBER OF GWCORGFO                     
                   NEXT SENTENCE                                                
               ELSE                                                             
                   MOVE GCXT-GFO-NUMBER TO GFO-NUMBER OF GWCORGFO               
      *%           OBTAIN CALC GWCORGFO                                         
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 16 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +6  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-SELECT-USING-PRIM-KEY                      
MAN02                         FCCSPLIO-GWCORGFO                                 
MAN02                         FCCSPL-GWCORGFO                                   
MAN02                         GWCORGFO                                          
MAN02                         FCCSPL-OBTAIN                                     
MAN02                         FCCSPL-NOKEEP                                     
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                IF NOT DB-REC-NOT-FOUND                                      
IOS                   PERFORM 799-SQL-STATUS-02                                 
IOS                      THRU 799-SQL-STATUS-02-EXIT                            
IOS                ELSE                                                         
      *%               STORE GWCORGFO.                                          
IOS                MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                  
IOS                MOVE 17 TO FCCSPL-DML-SEQ-NO                                 
IOS                MOVE +4  TO FCCSPL-ADDRESS-COUNT                             
MAN02              CALL GWFADDR                                                 
MAN02                   USING FCCSPL-ADDRESS-AREA                               
MAN02                         FCCSPL-INSERT                                     
MAN02                         FCCSPLIO-GWCORGFO                                 
MAN02                         FCCSPL-GWCORGFO                                   
MAN02                         GWCORGFO                                          
IOS                END-CALL                                                     
FXXTOK             CALL GWFSPLB1                                                
IOS                     USING DUMMY-PARM-1                                      
IOS                           DUMMY-PARM-2                                      
IOS                           DBLINK-SUBSCHEMA-CONTROL                          
IOS                           DBLINK-RECORD-SET-KEYS                            
IOS                           DBLINK-CURSOR-CODES                               
IOS                END-CALL                                                     
IOS                PERFORM 799-SQL-STATUS                                       
IOS                   THRU 799-SQL-STATUS-EXIT.                                 
                                                                                
           IF  GCXT-GFO-NUMBER = SPACES                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
      *%       CONNECT GWCORCOMP TO GFO-COMP.                                   
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 18 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +5  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-CREATE-RELATIONSHIP                            
MAN02                     FCCSPLIO-GWCORCOMP                                    
MAN02                     FCCSPL-GWCORCOMP                                      
MAN02                     FCCSPL-GFO-COMP                                       
MAN02                     GWCORCOMP                                             
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
           IF  GCXT-COV-TYPE = '#' OR 'L' OR 'T' OR 'O'                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE '5' TO ACTION-SW                                            
               PERFORM 600-ACTION-REPORT                                        
               ADD 1 TO WS-ERROR-CNT.                                           
                                                                                
           IF (GCXT-COMP-TYPE = 'C'  OR                                         
               GCXT-COMP-TYPE = 'S') AND                                        
               GCXT-COMP-DISP = 'E'                                             
      *%       OBTAIN FIRST GWCORACCUM WITHIN GRACCT-ACCUM                      
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 19 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +7  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-FETCH-FIRST                                    
MAN02                     FCCSPLIO-GWCORACCUM                                   
MAN02                     FCCSPL-GWCORACCUM                                     
MAN02                     FCCSPL-GRACCT-ACCUM                                   
MAN02                     GWCORACCUM                                            
MAN02                     FCCSPL-OBTAIN                                         
MAN02                     FCCSPL-NOKEEP                                         
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            IF NOT DB-END-OF-SET                                             
IOS               PERFORM 799-SQL-STATUS-02                                     
IOS                  THRU 799-SQL-STATUS-02-EXIT                                
IOS            ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               GO TO 509-EXIT.                                                  
                                                                                
           PERFORM 510-GET-ACCUM                                                
               UNTIL GCXT-COMP-EFF-DATE = PREM-DUE-DATE OF GWCORACCUM           
               OR    DB-END-OF-SET.                                             
                                                                                
           IF  DB-END-OF-SET                                                    
               MOVE GCXT-COMP-EFF-DATE TO PREM-DUE-DATE OF GWCORACCUM           
               MOVE ZERO TO PREM-AMT-PAID OF GWCORACCUM                         
               IF GCXT-COMP-TYPE = 'C'                                          
                  MOVE ZERO TO COMM-AMT-EARNED OF GWCORACCUM                    
                  MOVE ZERO TO SALES-CREDITS-AMT-EARNED OF GWCORACCUM           
                  MOVE GCXT-COMP-AMT TO COMM-AMT-EARNED OF GWCORACCUM           
      *%          STORE GWCORACCUM                                              
IOS               MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                   
IOS               MOVE 20 TO FCCSPL-DML-SEQ-NO                                  
IOS               MOVE +4  TO FCCSPL-ADDRESS-COUNT                              
MAN02             CALL GWFADDR                                                  
MAN02                  USING FCCSPL-ADDRESS-AREA                                
MAN02                        FCCSPL-INSERT                                      
MAN02                        FCCSPLIO-GWCORACCUM                                
MAN02                        FCCSPL-GWCORACCUM                                  
MAN02                        GWCORACCUM                                         
IOS               END-CALL                                                      
FXXTOK            CALL GWFSPLB1                                                 
IOS                    USING DUMMY-PARM-1                                       
IOS                          DUMMY-PARM-2                                       
IOS                          DBLINK-SUBSCHEMA-CONTROL                           
IOS                          DBLINK-RECORD-SET-KEYS                             
IOS                          DBLINK-CURSOR-CODES                                
IOS               END-CALL                                                      
IOS               PERFORM 799-SQL-STATUS                                        
IOS                  THRU 799-SQL-STATUS-EXIT                                   
               ELSE                                                             
                  MOVE ZERO TO COMM-AMT-EARNED OF GWCORACCUM                    
                  MOVE ZERO TO SALES-CREDITS-AMT-EARNED OF GWCORACCUM           
                  MOVE GCXT-COMP-AMT TO SALES-CREDITS-AMT-EARNED                
                                     OF GWCORACCUM                              
      *%          STORE GWCORACCUM                                              
IOS               MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                   
IOS               MOVE 21 TO FCCSPL-DML-SEQ-NO                                  
IOS               MOVE +4  TO FCCSPL-ADDRESS-COUNT                              
MAN02             CALL GWFADDR                                                  
MAN02                  USING FCCSPL-ADDRESS-AREA                                
MAN02                        FCCSPL-INSERT                                      
MAN02                        FCCSPLIO-GWCORACCUM                                
MAN02                        FCCSPL-GWCORACCUM                                  
MAN02                        GWCORACCUM                                         
IOS               END-CALL                                                      
FXXTOK            CALL GWFSPLB1                                                 
IOS                    USING DUMMY-PARM-1                                       
IOS                          DUMMY-PARM-2                                       
IOS                          DBLINK-SUBSCHEMA-CONTROL                           
IOS                          DBLINK-RECORD-SET-KEYS                             
IOS                          DBLINK-CURSOR-CODES                                
IOS               END-CALL                                                      
IOS               PERFORM 799-SQL-STATUS                                        
IOS                  THRU 799-SQL-STATUS-EXIT                                   
           ELSE                                                                 
               IF GCXT-COMP-TYPE = 'C'                                          
                  ADD GCXT-COMP-AMT TO COMM-AMT-EARNED OF GWCORACCUM            
      *%          MODIFY GWCORACCUM                                             
IOS               MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                   
IOS               MOVE 22 TO FCCSPL-DML-SEQ-NO                                  
IOS               MOVE +4  TO FCCSPL-ADDRESS-COUNT                              
MAN02             CALL GWFADDR                                                  
MAN02                  USING FCCSPL-ADDRESS-AREA                                
MAN02                        FCCSPL-UPDATE                                      
MAN02                        FCCSPLIO-GWCORACCUM                                
MAN02                        FCCSPL-GWCORACCUM                                  
MAN02                        GWCORACCUM                                         
IOS               END-CALL                                                      
FXXTOK            CALL GWFSPLB1                                                 
IOS                    USING DUMMY-PARM-1                                       
IOS                          DUMMY-PARM-2                                       
IOS                          DBLINK-SUBSCHEMA-CONTROL                           
IOS                          DBLINK-RECORD-SET-KEYS                             
IOS                          DBLINK-CURSOR-CODES                                
IOS               END-CALL                                                      
IOS               PERFORM 799-SQL-STATUS                                        
IOS                  THRU 799-SQL-STATUS-EXIT                                   
               ELSE                                                             
                  ADD GCXT-COMP-AMT TO SALES-CREDITS-AMT-EARNED                 
                                     OF GWCORACCUM                              
      *%          MODIFY GWCORACCUM.                                            
IOS               MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                   
IOS               MOVE 23 TO FCCSPL-DML-SEQ-NO                                  
IOS               MOVE +4  TO FCCSPL-ADDRESS-COUNT                              
MAN02             CALL GWFADDR                                                  
MAN02                  USING FCCSPL-ADDRESS-AREA                                
MAN02                        FCCSPL-UPDATE                                      
MAN02                        FCCSPLIO-GWCORACCUM                                
MAN02                        FCCSPL-GWCORACCUM                                  
MAN02                        GWCORACCUM                                         
IOS               END-CALL                                                      
FXXTOK            CALL GWFSPLB1                                                 
IOS                    USING DUMMY-PARM-1                                       
IOS                          DUMMY-PARM-2                                       
IOS                          DBLINK-SUBSCHEMA-CONTROL                           
IOS                          DBLINK-RECORD-SET-KEYS                             
IOS                          DBLINK-CURSOR-CODES                                
IOS               END-CALL                                                      
IOS               PERFORM 799-SQL-STATUS                                        
IOS                  THRU 799-SQL-STATUS-EXIT.                                  
                                                                                
       509-EXIT.                                                                
           EXIT.                                                                
                                                                                
       510-GET-ACCUM.                                                           
                                                                                
      *%   OBTAIN NEXT GWCORACCUM WITHIN GRACCT-ACCUM                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 24 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                   NEXT SENTENCE.                                               
       520-GET-AGENT.                                                           
                                                                                
           MOVE GCXT-AGENT-NUMBER TO AGENT-NUMBER OF GWCORAGENT.                
      *%   OBTAIN CALC GWCORAGENT                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 25 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
      *%       STORE GWCORAGENT.                                                
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 26 TO FCCSPL-DML-SEQ-NO                                     
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORAGENT                                   
MAN02                     FCCSPL-GWCORAGENT                                     
MAN02                     GWCORAGENT                                            
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
      *%   IF AGENT-PAYBASIS EMPTY                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 27 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +5  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-IF-DEPENDENTS-EXIST                                
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-GWCORPAYBASIS                                      
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF ERROR-STATUS = ZEROS                                              
               MOVE '8' TO ACTION-SW                                            
               PERFORM 600-ACTION-REPORT.                                       
                                                                                
       520-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       600-ACTION-REPORT.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   IF  ACTION-SW HAS A VALUE OF:                               *         
      *    0 = NO ACTIONION     -  PRINT HEADINGS                     *         
      *    1   - PREM GR-AACCT    -  NEW GROUP RECORD ADDED           *         
      *    1/2 - PREM-ACCT        -  NEW ACCT RECORD ADDED            *         
      *    3   - COMM-GR-ACCT     -  NEW GROUP RECORD ADDED           *         
      *    3/4 - COMM-ACCT        -  NEW ACCT RECORD ADDED            *         
      *    5   - COMM-COV-INVALID -  COV-TYPE NOT '#' 'L' 'T' OR 'O'  *         
      *    6   - NO-INPUT         -  EOF ON FIRST ATTEMP TO READ      *         
      *    8   - NO-AGENT-PAY-BASIS - NO GWCORPAYBASIS RECORD         *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  NO-ACTION                                                        
               MOVE ACTION-HDG-1 TO ACTION-LINE                                 
               PERFORM 910-WRITE-ACTION                                         
               MOVE ACTION-HDG-2 TO ACTION-LINE                                 
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  PREM-GR-ACTION                                                   
               MOVE GPXT-GROUP-NUMBER TO ACTION-GROUP-NUMBER-1                  
               MOVE ACTION-LINE-1 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION                                         
               MOVE '2' TO ACTION-SW.                                           
                                                                                
           IF  PREM-ACCT-ACTION                                                 
               MOVE ACTION-LINE-2 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION                                         
               MOVE GPXT-GROUP-NUMBER TO ACTION-ADD-GROUP                       
               MOVE GPXT-GR-ACCOUNT TO ACTION-ADD-ACCOUNT                       
               MOVE GWCOEADG-W-NEXT-RECON-DATE-EXT TO                           
                    ACTION-ADD-NEXT-DATE                                        
               MOVE GWCOEADG-W-LAST-RECON-DATE-EXT TO                           
                    ACTION-ADD-LAST-DATE                                        
               MOVE GWCOEADG-W-ACCT-EFF-DATE-EXT TO                             
                    ACTION-ADD-ACCT-EFFECTIVE                                   
               MOVE GWCOEADG-W-NEXT-RENEW-DATE-EXT TO                           
                    ACTION-ADD-RENEWAL                                          
               MOVE ACTION-LINE-10 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION                                         
               IF  GPXT-NEXT-RECON-IND = 'A'                                    
                   MOVE ACTION-LINE-16 TO ACTION-LINE                           
                   PERFORM 910-WRITE-ACTION.                                    
                                                                                
           IF  COMM-GR-ACTION                                                   
               MOVE GCXT-GROUP-NUMBER TO ACTION-GROUP-NUMBER-3                  
               MOVE ACTION-LINE-3 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION                                         
               MOVE '4' TO ACTION-SW.                                           
                                                                                
           IF  COMM-ACCT-ACTION                                                 
               MOVE ACTION-LINE-4 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION                                         
               MOVE GCXT-GROUP-NUMBER TO ACTION-ADD-GROUP                       
               MOVE GCXT-GR-ACCOUNT TO ACTION-ADD-ACCOUNT                       
               MOVE GWCOEADG-W-NEXT-RECON-DATE-EXT TO                           
                    ACTION-ADD-NEXT-DATE                                        
               MOVE GWCOEADG-W-LAST-RECON-DATE-EXT TO                           
                    ACTION-ADD-LAST-DATE                                        
               MOVE GWCOEADG-W-ACCT-EFF-DATE-EXT TO                             
                    ACTION-ADD-ACCT-EFFECTIVE                                   
               MOVE GWCOEADG-W-NEXT-RENEW-DATE-EXT TO                           
                    ACTION-ADD-RENEWAL                                          
               MOVE ACTION-LINE-10 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION                                         
               IF  GCXT-NEXT-RECON-IND = 'A'                                    
                   MOVE ACTION-LINE-16 TO ACTION-LINE                           
                   PERFORM 910-WRITE-ACTION.                                    
                                                                                
           IF  COMM-COV-INVALID                                                 
               MOVE ACTION-LINE-7 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION                                         
               MOVE GCXT-GROUP-NUMBER TO ACTION-COV-GROUP                       
               MOVE GCXT-GR-ACCOUNT TO ACTION-COV-ACCOUNT                       
MAN02          CALL QDATEQ2 USING QDATE-FORMATA                                 
MAN02                             GCXT-COMP-EFF-DATE                            
MAN02                             ACTION-COV-DATE                               
               MOVE GCXT-COV-TYPE TO ACTION-COV-TYPE                            
               MOVE ACTION-LINE-8 TO ACTION-LINE                                
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NO-INPUT                                                         
               MOVE ACTION-LINE-11 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  EFF-DATE-INVALID                                                 
               MOVE GCXT-GROUP-NUMBER TO ACTION-GROUP-13                        
               MOVE GCXT-GR-ACCOUNT TO ACTION-ACCOUNT-13                        
MAN02          CALL QDATEQ2 USING QDATE-FORMATA                                 
MAN02                             COMP-EFF-DATE                                 
MAN02                             ACTION-COMP-EFF-13                            
MAN02          CALL QDATEQ2 USING QDATE-FORMATA                                 
MAN02                             LAST-RECON-DATE                               
MAN02                             ACTION-LAST-RECON-13                          
               MOVE ACTION-LINE-13 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           IF  NO-AGENT-PAY-BASIS                                               
               MOVE GCXT-GROUP-NUMBER TO ACTION-GROUP-15                        
               MOVE GCXT-GR-ACCOUNT TO ACTION-ACCOUNT-15                        
               MOVE GCXT-AGENT-NUMBER TO ACTION-AGENT-15                        
MAN02          CALL QDATEQ2 USING QDATE-FORMATA                                 
MAN02                             COMP-PROCESS-DATE                             
MAN02                             ACTION-COMP-PROC-15                           
               MOVE ACTION-LINE-15 TO ACTION-LINE                               
               PERFORM 910-WRITE-ACTION.                                        
                                                                                
           MOVE '0' TO ACTION-SW.                                               
                                                                                
       600-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *       FOLLOWING ROUTINE CALLS I/O MODULE TO CREATE OWNER(S)   *         
      *           GROUP AND/OR GRACCT RECORD.                         *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       700-CREATE-OWNERS.                                                       
                                                                                
           MOVE SPACES TO GWCORADG-WORK-RECORD.                                 
           MOVE INPUT-GROUP-NUMBER TO GWCOEADG-W-GROUP-NUMBER                   
           MOVE INPUT-GROUP-ACCOUNT TO GWCOEADG-W-GR-ACCOUNT.                   
           MOVE WS-ACCT-EFF-DATE TO GWCOEADG-W-ACCT-EFF-DATE.                   
           MOVE WS-NEXT-RECON-DATE TO GWCOEADG-W-NEXT-RENEW-DATE.               
                                                                                
MAN02      CALL GC2ADG     USING DBLINK-SUBSCHEMA-CONTROL                       
MAN02                            DBLINK-RECORD-SET-KEYS                         
MAN02                            DBLINK-CURSOR-CODES                            
MAN02                            GWCORGROUP                                     
MAN02                            GWCORGRACCT                                    
MAN02                            GWCORADG-WORK-RECORD.                          
                                                                                
FXXTOK     MOVE 'GC2UP1' TO PROGRAM-NAME.                                       
           MOVE GWCOEADG-W-ACTION-SWITCH TO ACTION-SW.                          
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *       FOLLOWING ROUTINES PERFORM READS-WRITES OF I-O FILES    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       900-READ-EXTRACT.                                                        
                                                                                
           CALL 'DLSREAD' USING READ-SYS010                                     
                                READ-RET-CODE                                   
                                INPUT-AREA                                      
                                READ-RECSIZE                                    
                                READ-BLKSIZE                                    
                                READ-FORMAT                                     
                                READ-REC-CNT.                                   
                                                                                
           IF READ-RET-CODE GREATER THAN +4                                     
               MOVE 'READ' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
       910-WRITE-ACTION.                                                        
                                                                                
           CALL 'DLSWRITE' USING ACTION-SYS021                                  
                                 ACTION-RET-CODE                                
                                 ACTION-LINE                                    
                                 ACTION-RECSIZE                                 
                                 ACTION-BLKSIZE                                 
                                 ACTION-FORMAT                                  
                                 ACTION-COUNT.                                  
           IF ACTION-RET-CODE = ZERO                                            
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'WRTE' TO ERROR-STATUS                                      
      *%       PERFORM IDMS-STATUS.                                             
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
