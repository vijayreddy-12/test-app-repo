       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  ZCURRDAT.                                                   
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  WS-CURR-DATE1.                                                       
           05 WS-CURR-DATE1-MM VALUE SPACES       PIC XX.                       
           05 FILLER           VALUE SPACE        PIC X.                        
           05 WS-CURR-DATE1-DD VALUE SPACES       PIC XX.                       
           05 FILLER           VALUE SPACE        PIC X.                        
           05 WS-CURR-DATE1-YY VALUE SPACES       PIC XX.                       
       01  WS-CURR-DATE2.                                                       
           05 WS-CURR-DATE2-DD VALUE SPACES       PIC XX.                       
           05 FILLER           VALUE SPACE        PIC X.                        
           05 WS-CURR-DATE2-MM VALUE SPACES       PIC XX.                       
           05 FILLER           VALUE SPACE        PIC X.                        
           05 WS-CURR-DATE2-YY VALUE SPACES       PIC XX.                       
       LINKAGE SECTION.                                                         
       77  DOS-FORMAT-DATE                        PIC X(8).                     
       PROCEDURE DIVISION USING DOS-FORMAT-DATE.                                
           IF WS-CURR-DATE2 EQUAL SPACES                                        
               MOVE CURRENT-DATE TO WS-CURR-DATE1                               
               MOVE WS-CURR-DATE1 TO WS-CURR-DATE2                              
               MOVE WS-CURR-DATE1-DD TO WS-CURR-DATE2-DD                        
               MOVE WS-CURR-DATE1-MM TO WS-CURR-DATE2-MM                        
               MOVE WS-CURR-DATE1-YY TO WS-CURR-DATE2-YY.                       
           MOVE WS-CURR-DATE2 TO DOS-FORMAT-DATE.                               
           GOBACK.                                                              
