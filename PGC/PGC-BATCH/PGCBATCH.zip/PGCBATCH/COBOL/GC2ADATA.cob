       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. GC2ADATA.                                                    
      *AUTHOR.   J. SASSO.                                                      
      *****************************************************************         
      *                                                                         
      * DESCRIPTION:                                                            
      *     THIS MODULE IS TO GENERATE AN EXTRACT WITH NEGATIVES                
      *     IN FRONT OF THE DATA FOR USE BY EASYTRIEVE                          
      *                                                                         
      * HISTORY:                                                                
      *     JUL.22.2002 - JACKIE SASSO (CREATION)                               
      *                                                                         
      *     OCT.03.2008 - IBM - ENTERPRISE COMPILER UPGRADE                     
      *****************************************************************         
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES ALPHDATA          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
               '** GC2ADATA W-S STARTS HERE **'.                                
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GAEDATSR                   PIC X(8)    VALUE 'GAEDATSR'.         
                                                                                
       01  WS-VERB                        PIC X(16)   VALUE SPACES.             
                                                                                
       01  ERROR-MESSAGE.                                                       
           05  ERROR-MSG               PIC X(23)      VALUE SPACES.             
           05  ERR-STATUS              PIC X(4)       VALUE SPACES.             
                                                                                
       01  EXT-ERROR                   PIC X          VALUE 'N'.                
                                                                                
       01  INPUT-RECORD.                                                        
REN        05  I-GROUP              PIC X(7)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-ACCT               PIC XXX        VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-GROUP-NAME         PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-ACCT-EFF-DATE      PIC X(9)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-AGENT-CODE         PIC 9(6)       VALUE ZEROES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-AGENT-NAME         PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-BRANCH-CODE        PIC X(5)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-BRANCH-NAME        PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  I-TOT-COMM-PD-FY     PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  I-TOT-COMM-PD-RN     PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  I-TOT-SALS-CDT-FY    PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  I-TOT-SALS-CDT-RN    PIC S9(7)V99   VALUE ZEROES.                
           05  FILLER               PIC XX          VALUE SPACES.               
           05  I-PROCESS-MMM        PIC XXX         VALUE SPACES.               
           05  FILLER               PIC X           VALUE '/'.                  
           05  I-PROCESS-YYYY       PIC X(4)        VALUE SPACES.               
                                                                                
       01  OUTPUT-RECORD.                                                       
REN        05  O-GROUP              PIC X(7)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-ACCT               PIC XXX        VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-GROUP-NAME         PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-ACCT-EFF-DATE      PIC X(9)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-AGENT-CODE         PIC 9(6)       VALUE ZEROES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-AGENT-NAME         PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-BRANCH-CODE        PIC X(5)       VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-BRANCH-NAME        PIC X(30)      VALUE SPACES.                
           05  FILLER               PIC XX         VALUE SPACES.                
           05  O-TOT-COMM-PD-FY     PIC -,---,--9.99  VALUE ZEROES.             
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-TOT-COMM-PD-RN     PIC -,---,--9.99  VALUE ZEROES.             
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-TOT-SALS-CDT-FY    PIC -,---,--9.99  VALUE ZEROES.             
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-TOT-SALS-CDT-RN    PIC -,---,--9.99  VALUE ZEROES.             
           05  FILLER               PIC XX          VALUE SPACES.               
           05  O-PROCESS-MMM        PIC XXX         VALUE SPACES.               
           05  FILLER               PIC X           VALUE '/'.                  
           05  O-PROCESS-YYYY       PIC X(4)        VALUE SPACES.               
                                                                                
      *----------------------------------------------------------------         
      *          DATASERVER RECORDS                                   *         
      *----------------------------------------------------------------         
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
       01  WS-ENDS.                                                             
           05  FILLER               PIC  X(32)        VALUE                     
               '** GC2ADATA W-S ENDS HERE   **'.                                
      /                                                                         
      ******************************************************************        
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
         SKIP3.                                                                 
      ******************************************************************        
       000-MAINLINE.                                                            
                                                                                
           DISPLAY 'START OF GC2ADATA PROGRAM'.                                 
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
           MOVE 'N' TO EXT-ERROR.                                               
           MOVE OBTAIN-FIRST TO WS-VERB.                                        
           MOVE 'GC2ADATA' TO ICBM-PROGRAM-NAME.                                
           MOVE LOW-VALUES TO LINKAGE-CONTROL.                                  
                                                                                
           PERFORM 100-READ-EXTRACT THRU 100-X.                                 
                                                                                
           IF EXT-ERROR = 'Y'                                                   
              GO TO 000-MAINLINE-X.                                             
                                                                                
           PERFORM 200-PROCESS THRU 200-X                                       
              UNTIL LR-NOT-FOUND.                                               
                                                                                
      *--------------------------------------------------------------           
      *   END OF PROGRAM LOGIC                                                  
      *--------------------------------------------------------------           
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  OUTPUT-RECORD                                 
                                  ICBM.                                         
           DISPLAY 'END OF GC2ADATA PROGRAM'.                                   
                                                                                
       000-MAINLINE-X.                                                          
           STOP RUN.                                                            
                                                                                
      *-----------------------------------------------------------------        
       100-READ-EXTRACT.                                                        
                                                                                
           MOVE 'CARD-DATA-010' TO LOGICAL-RECORD-NAME.                         
                                                                                
           CALL GAEDATSR USING WS-VERB                                          
                               INPUT-RECORD                                     
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK                                                  
              AND NOT LR-NOT-FOUND                                              
              DISPLAY 'STATUS: ' ICBM,                                          
                  '    DATA = ', INPUT-RECORD                                   
              MOVE 'ERROR READING DATA FROM EXTRACT: ' TO ERROR-MSG             
              MOVE LINKAGE-STATUS TO ERR-STATUS                                 
              PERFORM 950-WRITE-ERROR THRU 950-WRITE-ERROR-X                    
              MOVE 'Y' TO EXT-ERROR                                             
              GO TO 100-X.                                                      
                                                                                
           MOVE OBTAIN-NEXT TO WS-VERB.                                         
                                                                                
       100-X.                                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
       200-PROCESS.                                                             
                                                                                
      *  MOVE VALUE IN INPUT-RECORD TO OUTPUT RECORD                            
           MOVE I-GROUP           TO O-GROUP                                    
           MOVE I-ACCT            TO O-ACCT                                     
           MOVE I-GROUP-NAME      TO O-GROUP-NAME                               
           MOVE I-ACCT-EFF-DATE   TO O-ACCT-EFF-DATE                            
           MOVE I-AGENT-CODE      TO O-AGENT-CODE                               
           MOVE I-AGENT-NAME      TO O-AGENT-NAME                               
           MOVE I-BRANCH-CODE     TO O-BRANCH-CODE                              
           MOVE I-BRANCH-NAME     TO O-BRANCH-NAME                              
           MOVE I-TOT-COMM-PD-FY  TO O-TOT-COMM-PD-FY                           
           MOVE I-TOT-COMM-PD-RN  TO O-TOT-COMM-PD-RN                           
           MOVE I-TOT-SALS-CDT-FY TO O-TOT-SALS-CDT-FY                          
           MOVE I-TOT-SALS-CDT-RN TO O-TOT-SALS-CDT-RN                          
           MOVE I-PROCESS-MMM     TO O-PROCESS-MMM                              
           MOVE I-PROCESS-YYYY    TO O-PROCESS-YYYY                             
                                                                                
           PERFORM 300-WRITE THRU 300-X.                                        
           PERFORM 100-READ-EXTRACT THRU 100-X.                                 
                                                                                
       200-X.                                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
       300-WRITE.                                                               
                                                                                
           MOVE 'PRINT-DATA-020' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR     USING  STORE-LR                                    
                                    OUTPUT-RECORD                               
                                    ICBM.                                       
                                                                                
      *    DISPLAY OUTPUT-RECORD.                                               
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                        
           END-IF.                                                              
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
                                                                                
       300-X.                                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
       950-WRITE-ERROR.                                                         
                                                                                
           MOVE 'PRINT-DATA-021' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR USING STORE-LR                                         
                               ERROR-MESSAGE                                    
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                        
           END-IF.                                                              
                                                                                
       950-WRITE-ERROR-X.                                                       
           EXIT.                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          END OF SOURCE                                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
