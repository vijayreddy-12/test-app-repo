       ID DIVISION.                                                             
GNE                                                                             
       PROGRAM-ID. GSPTRAN4.                                                    
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      *REMARKS.  THIS MODULE IS CALLED BY GSPTRAN1 TO FORMAT GROUP              
      *            MASTER TRAILERS 100 THRU 150 FOR THE TRANS REG.              
      *          REVISED FOR QUEBEC TAX,  C. PETERSON                           
      ******************************************************************        
      * JUN/93 M. PRANGE                                                        
      *      - CHANGES TO PRINT NEW TAX TRLR (TRLR 150).                        
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77  SEGMENT-SUB  COMP SYNC   PIC S9(4).                                  
       77  TAX-SUB1     COMP SYNC   PIC S9(4).                                  
       77  TAX-SUB2     COMP SYNC   PIC S9(4).                                  
       77  DATE-TYPE           PIC XX VALUE 'AC'.                               
       77  WDATE-P             PIC X(4).                                        
       77  WDATE-C             PIC X(7).                                        
       77  TEST-SUB            PIC S999 COMP-3.                                 
       77  SEG-REM             PIC S9   COMP-3.                                 
                                                                                
GNE    01  GTRLGTH7                      PIC X(8) VALUE 'GTRLGTH7'.             
       01  GTRLGTH-PARAMETERS.                                                  
           03  GTRLGTH-RETURN-AREA.                                             
               05  FILLER                PIC X(10).                             
               05  GTRLGTH-NUM-SEG       PIC S9(4) COMP.                        
               05  FILLER                PIC X(6).                              
           03  GTRLGTH-RETURN-CODE       PIC X SYNC.                            
                                                                                
       01  REPORT-HEADINGS.                                                     
           03  TRLR-100-HEADING-1.                                              
               05  FILLER      PIC X(6)  VALUE SPACES.                          
               05  FILLER      PIC X(10) VALUE 'START'.                         
               05  FILLER      PIC X(8)  VALUE 'STOP'.                          
               05  FILLER      PIC X(12) VALUE 'FRST YR'.                       
               05  FILLER      PIC X(12) VALUE 'FRST YR'.                       
               05  FILLER      PIC X(10) VALUE 'FRST YR'.                       
               05  FILLER      PIC X(11) VALUE 'ORIGINAL'.                      
               05  FILLER      PIC X(9)  VALUE 'REMAINING'.                     
           03  TRLR-100-HEADING-2.                                              
               05  FILLER      PIC X(7)  VALUE 'CODE'.                          
               05  FILLER      PIC X(9)  VALUE 'DATE'.                          
               05  FILLER      PIC X(8)  VALUE 'DATE'.                          
               05  FILLER      PIC X(12) VALUE 'PREM LIFE'.                     
               05  FILLER      PIC X(12) VALUE 'PREM LTD'.                      
               05  FILLER      PIC X(10) VALUE 'PREM A S'.                      
               05  FILLER      PIC X(11) VALUE 'FLAT AMT'.                      
               05  FILLER      PIC X(8)  VALUE 'FLAT AMT'.                      
           03  TRLR-110-HEADING-1.                                              
               05  FILLER      PIC X(9)  VALUE ' AGENT'.                        
               05  FILLER      PIC X(4)  VALUE 'BR'.                            
               05  FILLER      PIC X(5)  VALUE 'PAY'.                           
               05  FILLER      PIC X(6)  VALUE 'ANCOM'.                         
               05  FILLER      PIC X(10) VALUE 'ANCOM'.                         
               05  FILLER      PIC X(13) VALUE 'ANCOM'.                         
               05  FILLER      PIC X(13) VALUE 'ANCOM'.                         
               05  FILLER      PIC X(19) VALUE 'RENEWAL COMMSSIONS'.            
           03  TRLR-110-HEADING-2.                                              
               05  FILLER      PIC X(13) VALUE ' CODE'.                         
               05  FILLER      PIC X(5)  VALUE 'TYPE'.                          
               05  FILLER      PIC X(6)  VALUE 'COUNT'.                         
               05  FILLER      PIC X(9)  VALUE '% DEF'.                         
               05  FILLER      PIC X(13) VALUE 'AN PAID'.                       
               05  FILLER      PIC X(14) VALUE 'AN EARN'.                       
               05  FILLER      PIC X(11) VALUE 'PAID'.                          
               05  FILLER      PIC X(6)  VALUE 'EARNED'.                        
           03  TRLR-110-HEADING-3.                                              
               05  FILLER      PIC X(30) VALUE '      SALES CREDIT'.            
               05  FILLER      PIC X(10) VALUE 'CASE COUNT'.                    
           03  TRLR-110-HEADING-4.                                              
               05  FILLER      PIC X(14) VALUE '   PAID'.                       
               05  FILLER      PIC X(13) VALUE 'EARNED'.                        
               05  FILLER      PIC X(11) VALUE 'PAID'.                          
               05  FILLER      PIC X(6)  VALUE 'EARNED'.                        
           03  TRLR-110-HEADING-5.                                              
               05  FILLER      PIC X(12) VALUE 'NAP 1 PAID'.                    
               05  FILLER      PIC X(12) VALUE 'NAP 1 EARN'.                    
               05  FILLER      PIC X(12) VALUE 'NAP 2 PAID'.                    
               05  FILLER      PIC X(12) VALUE 'NAP 2 EARN'.                    
           03  TRLR-110-SUB-HEADING-1.                                          
               05  FILLER      PIC X(5)  VALUE 'COM'.                           
               05  FILLER      PIC X(8)  VALUE 'START'.                         
               05  FILLER      PIC X(8)  VALUE 'STOP'.                          
               05  FILLER      PIC X(32) VALUE SPACES.                          
               05  FILLER      PIC X(7)  VALUE 'SCALE'.                         
               05  FILLER      PIC X(5)  VALUE 'LTD'.                           
               05  FILLER      PIC X(5)  VALUE 'FLAT'.                          
               05  FILLER      PIC X(9)  VALUE 'LTD FLAT'.                      
               05  FILLER      PIC X(5)  VALUE 'POINT'.                         
           03  TRLR-110-SUB-HEADING-2.                                          
               05  FILLER      PIC X(5)  VALUE 'IND'.                           
               05  FILLER      PIC X(8)  VALUE 'DATE'.                          
               05  FILLER      PIC X(15) VALUE 'DATE'.                          
               05  FILLER      PIC X(8)  VALUE 'LIFE'.                          
               05  FILLER      PIC X(7)  VALUE 'LTD'.                           
               05  FILLER      PIC X(16) VALUE 'AS'.                            
               05  FILLER      PIC X(6)  VALUE 'SCALE'.                         
               05  FILLER      PIC X(7)  VALUE 'RATE'.                          
               05  FILLER      PIC X(4)  VALUE 'RATE'.                          
           03  TRLR-120-HEADING-1.                                              
               05  FILLER      PIC X(6)  VALUE 'SPNO'.                          
               05  FILLER      PIC X(8)  VALUE 'START'.                         
               05  FILLER      PIC X(4)  VALUE 'STOP'.                          
           03  TRLR-120-HEADING-2.                                              
               05  FILLER      PIC X(6)  VALUE 'CODE'.                          
               05  FILLER      PIC X(8)  VALUE 'DATE'.                          
               05  FILLER      PIC X(13) VALUE 'DATE'.                          
               05  FILLER      PIC X(11) VALUE 'INFORMATION'.                   
           03  TRLR-125-HEADING-1.                                              
               05  FILLER      PIC X(9)  VALUE '  EFF'.                         
               05  FILLER      PIC X(4)  VALUE 'PROC'.                          
           03  TRLR-125-HEADING-2.                                              
               05  FILLER      PIC X(9)  VALUE ' DATE'.                         
               05  FILLER      PIC X(13) VALUE 'DATE'.                          
               05  FILLER      PIC X(6)  VALUE 'REASON'.                        
           03  TRLR-130-HEADING-1.                                              
               05  FILLER      PIC X(9)  VALUE '  EFF'.                         
               05  FILLER      PIC X(8)  VALUE 'PROC'.                          
               05  FILLER      PIC X(7)  VALUE 'PURGE'.                         
               05  FILLER      PIC X(6)  VALUE 'TERM'.                          
               05  FILLER      PIC X(7)  VALUE 'REIN'.                          
               05  FILLER      PIC X(4)  VALUE 'REIN'.                          
           03  TRLR-130-HEADING-2.                                              
               05  FILLER      PIC X(9)  VALUE ' DATE'.                         
               05  FILLER      PIC X(8)  VALUE 'DATE'.                          
               05  FILLER      PIC X(7)  VALUE 'DATE'.                          
               05  FILLER      PIC X(6)  VALUE 'CODE'.                          
               05  FILLER      PIC X(7)  VALUE 'DATE'.                          
               05  FILLER      PIC X(4)  VALUE 'CODE'.                          
           03  TRLR-140-HEADING-1.                                              
               05  FILLER      PIC X(20) VALUE '    CLASSES'.                   
               05  FILLER      PIC X(15) VALUE 'COVERAGE CODES'.                
           03  TRLR-150-HEAD1.                                                  
               05  FILLER             PIC X(11) VALUE SPACES.                   
               05  FILLER             PIC X(27) VALUE                           
                   'OUTSTANDING TAX INFORMATION'.                               
           03  TRLR-150-HEAD2.                                                  
               05  FILLER             PIC X(11) VALUE 'TAX CNT    '.            
               05  FILLER             PIC X(11) VALUE 'TAX CODE   '.            
               05  FILLER             PIC X(11) VALUE 'BILLED TAX '.            
           03  TRLR-150-HIST-HEAD1.                                             
               05  FILLER             PIC X(33) VALUE                           
                   '  DUE     #    TAX               '.                         
           03  TRLR-150-HIST-HEAD2.                                             
               05  FILLER             PIC X(33) VALUE                           
                   '  DATE  TAXES  CODE   BILLED TAX '.                         
       01  WORK-PRAREA.                                                         
           03  WPRLINE-125.                                                     
                   07  P-GAMEFFECTIVE-DATE         PIC X(7).                    
                   07          FILLER  PIC X.                                   
                   07  P-GAMPROCESSED-DATE         PIC X(7).                    
                   07          FILLER  PIC X.                                   
                   07  P-GAMREASON                 PIC X(20).                   
           03  WPRAREA-140.                                                     
               05  WPRLINE-140.                                                 
                   07  P-CLASS-1               PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-CLASS-2               PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-CLASS-3               PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-CLASS-4               PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-CLASS-5               PIC XX.                          
                   07          FILLER  PIC XX.                                  
                   07  P-COVCODE-1             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-2             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-3             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-4             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-5             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-6             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-7             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-8             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-9             PIC XX.                          
                   07          FILLER  PIC X.                                   
                   07  P-COVCODE-10            PIC XX.                          
           03  WPRAREA-150.                                                     
               05  WPRLINE-150-OUTST.                                           
                   07  FILLER                  PIC X(1).                        
                   07  P-150-OUTST-TAX-CNT     PIC ZZ9.                         
                   07  FILLER                  PIC X(9).                        
                   07  P-150-OUTST-TAX-CODE    PIC X(2).                        
                   07  FILLER                  PIC X(5).                        
                   07  P-150-OUTST-TAX-AMT     PIC Z,ZZZ,ZZ9.99-.               
               05  WPRLINE-150-HIST.                                            
                   07  P-150-HIST-DUE-DATE     PIC X(7).                        
                   07  FILLER                  PIC X(1).                        
                   07  P-150-HIST-TAX-CNT      PIC ZZ9.                         
                   07  FILLER                  PIC X(5).                        
                   07  P-150-HIST-TAX-CODE     PIC X(2).                        
                   07  FILLER                  PIC X(2).                        
                   07  P-150-HIST-TAX-AMT      PIC Z,ZZZ,ZZ9.99-.               
       01  WORK-CLASSES.                                                        
           03  P-CLASS-1       PIC XX.                                          
           03  P-CLASS-2       PIC XX.                                          
           03  P-CLASS-3       PIC XX.                                          
           03  P-CLASS-4       PIC XX.                                          
           03  P-CLASS-5       PIC XX.                                          
       01  WORK-COVCODES.                                                       
           03  P-COVCODE-1     PIC XX.                                          
           03  P-COVCODE-2     PIC XX.                                          
           03  P-COVCODE-3     PIC XX.                                          
           03  P-COVCODE-4     PIC XX.                                          
           03  P-COVCODE-5     PIC XX.                                          
           03  P-COVCODE-6     PIC XX.                                          
           03  P-COVCODE-7     PIC XX.                                          
           03  P-COVCODE-8     PIC XX.                                          
           03  P-COVCODE-9     PIC XX.                                          
           03  P-COVCODE-10    PIC XX.                                          
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       77  LINE-COUNT      COMP SYNC   PIC S9(4).                               
                                                                                
       01  PRINT-LINES.                                                         
           03  PRINT-LINES-ALL-TRAILERS            PIC X(23205).                
           03  PR-LINES-110-A REDEFINES PRINT-LINES-ALL-TRAILERS.               
               05  PRLINE-110-HEAD1                PIC X(91).                   
               05  PRLINE-110-HEAD2                PIC X(91).                   
               05  PR-LINE-110A.                                                
                   07  P-GAGAGENT-CODE             PIC 9(6).                    
                   07  FILLER                      PIC X.                       
                   07  P-GAGAGENT-BRANCH           PIC X(5).                    
                   07  FILLER                      PIC XX.                      
                   07  P-GAGPAYMENT-TYPE           PIC X.                       
                   07  FILLER                      PIC X(5).                    
                   07  P-GAGCANN-COUNTER           PIC X.                       
                   07  FILLER                      PIC XX.                      
                   07  P-GAGPERCENT-DEFER          PIC ZZZZ9.99.                
                   07  FILLER                      PIC X.                       
                   07  P-GAGANNUALIZED-PAID        PIC Z(6)9.99-.               
                   07  FILLER                      PIC X(2).                    
                   07  P-GAGANNUALIZED-EARN        PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGRENEW-COMM-PD          PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGRENEW-COMM-EARN        PIC Z(6)9.99-.               
                   07  FILLER                      PIC X(11).                   
               05  PRLINE-110-HEAD3                PIC X(91).                   
               05  PRLINE-110-HEAD4                PIC X(91).                   
               05  PR-LINE-110B.                                                
                   07  P-GAGSALES-CRED-PD          PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGSALES-CRED-EARN        PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGCASE-CNT-PD            PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGCASE-CNT-EARN          PIC Z(6)9.99-.               
                   07  FILLER                      PIC X(44).                   
               05  PRLINE-110-HEAD5                PIC X(91).                   
               05  PR-LINE-110C.                                                
                   07  P-GAGNAP-PAID1              PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGNAP-EARNED1            PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGNAP-PAID2              PIC Z(6)9.99-.               
                   07  FILLER                      PIC X.                       
                   07  P-GAGNAP-EARNED2            PIC Z(6)9.99-.               
                   07  FILLER                      PIC X(44).                   
               05  PRLINE-110-SUBHEAD1             PIC X(91).                   
               05  PRLINE-110-SUBHEAD2             PIC X(91).                   
               05  PR-LINES-110-SUBLINES OCCURS 5 TIMES.                        
                   07  P-GAGAGENTS-INF-SECTION-1.                               
                       09      FILLER              PIC X.                       
                       09  P-GAGCOMM-IND           PIC X.                       
                       09      FILLER  PIC XX.                                  
                       09  P-GAGSTART-DATE             PIC X(7).                
                       09      FILLER  PIC X.                                   
                       09  P-GAGSTOP-DATE              PIC X(7).                
                       09      FILLER  PIC X.                                   
                       09  P-GAG-FIRST-LIT             PIC X(7).                
                       09  P-GAGFIRST-YEAR.                                     
                           11  P-GAGFRST-LIFE          PIC Z(3).99.             
                           11  FILLER  PIC X.                                   
                           11  P-GAGFRST-LTD           PIC Z(3).99.             
                           11  FILLER  PIC X.                                   
                           11  P-GAGFRST-A-S           PIC Z(3).99.             
                           11  FILLER  PIC X(7).                                
                       09  P-GAGSCALE              PIC X(3).                    
                       09  FILLER                  PIC X(3).                    
                       09  P-GAGLTD-SCALE          PIC X(3).                    
                       09  FILLER                  PIC X.                       
                       09  P-GAGFLAT-RATE          PIC ZZZ.99.                  
                       09  FILLER                  PIC X.                       
                       09  P-GAGLTD-FLAT-RATE      PIC ZZZ.99.                  
                       09  FILLER                  PIC X(4).                    
                       09  P-GAGPOINT              PIC X.                       
                       09  FILLER                  PIC X(9).                    
                   07  P-GAGAGENTS-INF-SECTION-2.                               
                       09  FILLER                      PIC X(20).               
                       09  P-GAG-REN-LIT               PIC X(7).                
                       09  P-GAGRENEWAL.                                        
                           11  P-GAGREN-LIFE           PIC Z(3).99.             
                           11  FILLER  PIC X.                                   
                           11  P-GAGREN-LTD            PIC Z(3).99.             
                           11  FILLER  PIC X.                                   
                           11  P-GAGREN-A-S            PIC Z(3).99.             
                           11  FILLER  PIC X(7).                                
                       09  FILLER                  PIC X(37).                   
           03  PR-LINES-100 REDEFINES PRINT-LINES-ALL-TRAILERS.                 
               05  PRLINE-100-HEAD1                PIC X(91).                   
               05  PRLINE-100-HEAD2                PIC X(91).                   
               05  PRLINE-100-DATA OCCURS 10 TIMES.                             
                   07          FILLER  PIC XX.                                  
                   07  P-GPSCODE               PIC X.                           
                   07          FILLER  PIC XX.                                  
                   07  P-GPSTART-DATE          PIC X(7).                        
                   07          FILLER  PIC XX.                                  
                   07  P-GPSSTOP-DATE          PIC X(7).                        
                   07          FILLER  PIC XXX.                                 
                   07  P-GPSFIRST-YEAR.                                         
                       09  P-GPSFRST-LIFE      PIC ZZ,ZZZ.99.                   
                       09      FILLER  PIC XX.                                  
                       09  P-GPSFRST-LTD       PIC ZZ,ZZZ.99.                   
                       09      FILLER  PIC XX.                                  
                       09  P-GPSFRST-A-S       PIC ZZ,ZZZ.99.                   
                       09      FILLER  PIC XXX.                                 
                       09  P-GPSORIGINAL       PIC ZZ,ZZZ.99.                   
                       09      FILLER  PIC XX.                                  
                       09  P-GPSREMAINING      PIC ZZ,ZZZ.99.                   
                       09      FILLER  PIC X(13).                               
           03  PRLINES-120  REDEFINES PRINT-LINES-ALL-TRAILERS.                 
               05  PRLINE-120-HEAD-DATA OCCURS 3 TIMES.                         
                   07          FILLER  PIC X.                                   
                   07  P-GSNCODE                   PIC XX.                      
                   07          FILLER  PIC XX.                                  
                   07  P-GSNSTART-DATE                 PIC X(7).                
                   07          FILLER  PIC X.                                   
                   07  P-GSNSTOP-DATE                  PIC X(7).                
                   07          FILLER  PIC X.                                   
                   07  P-GSNINFO                       PIC X(25).               
                   07          FILLER  PIC X(45).                               
           03  PRLINES-125  REDEFINES PRINT-LINES-ALL-TRAILERS.                 
               05  PRLINE-125-HEAD1.                                            
                   07  PRLINE-125-HEAD1-A          PIC X(45).                   
                   07  PRLINE-125-HEAD1-B          PIC X(46).                   
               05  PRLINE-125-HEAD2.                                            
                   07  PRLINE-125-HEAD2-A          PIC X(45).                   
                   07  PRLINE-125-HEAD2-B          PIC X(46).                   
           03  PRLINE-125-DATA REDEFINES PRINT-LINES-ALL-TRAILERS.              
               05  PRLINE-125     OCCURS 10 TIMES.                              
                   07  PRLINE-125-A                PIC X(45).                   
                   07  PRLINE-125-B                PIC X(46).                   
           03  PRLINES-130  REDEFINES PRINT-LINES-ALL-TRAILERS.                 
               05  PRLINE-130-HEAD1                    PIC X(91).               
               05  PRLINE-130-HEAD2                    PIC X(91).               
               05  PRLINE-130  OCCURS 5 TIMES.                                  
                   07  P-GTMEFFECTIVE-DATE             PIC X(7).                
                   07          FILLER  PIC X.                                   
                   07  P-GTMPROCESSED-DATE             PIC X(7).                
                   07          FILLER  PIC X.                                   
                   07  P-GTMPURGE-DATE                 PIC X(7).                
                   07          FILLER  PIC XX.                                  
                   07  P-GTMCODE                       PIC XX.                  
                   07          FILLER  PIC XX.                                  
                   07  P-GTMREIN-DATE                  PIC X(7).                
                   07          FILLER  PIC XX.                                  
                   07  P-GTMREIN-CODE                  PIC XX.                  
                   07          FILLER  PIC X(51).                               
           03  PRLINES-140  REDEFINES PRINT-LINES-ALL-TRAILERS.                 
               05  PRLINE-140-HEAD                     PIC X(91).               
               05  PRLINE-140   OCCURS 10 TIMES.                                
                   07  PRLINE-140-DATA                 PIC X(91).               
           03  PRLINES-150-OCCURS REDEFINES PRINT-LINES-ALL-TRAILERS.           
               05  PRLINE-150   OCCURS 255 TIMES       PIC X(91).               
                                                                                
       01  W-GPSPREMIUM-SPLIT.                                                  
                               COPY WMPRMTR REPLACING                           
                                             ==01  WMPRMTR.== BY ====.          
       01  W-GAGAGENTS-INFO.                                                    
                               COPY WMAGTTR REPLACING                           
                                             ==01  WMAGTTR.== BY ====.          
       01  W-GSNSPECIAL-NOTES.                                                  
                               COPY WMNOTTR REPLACING                           
                                             ==01  WMNOTTR.== BY ====.          
       01  SPEC-NOTE-COUNT     COMP PIC S9(4).                                  
       01  W-GAMAMENDMENTS.                                                     
                               COPY WMAMTTR REPLACING                           
                                             ==01  WMAMTTR.== BY ====.          
       01  W-GTMTERMINATION.                                                    
                               COPY WMTERTR REPLACING                           
                                             ==01  WMTERTR.== BY ====.          
       01  W-GICIDENT-CERT.                                                     
                               COPY WMIDCTR REPLACING                           
                                             ==01  WMIDCTR.== BY ====.          
       01  WMTAXTR.                                                             
                               COPY WMTAXTR REPLACING                           
                                             ==01  WMTAXTR.== BY ====.          
                                                                                
       PROCEDURE DIVISION.                                                      
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 100.  DEPENDING          
      *    ON THE CODE, MOVE EITHER THE PERCENTAGE FIELDS OR THE                
      *    ORIGINAL AND REMAINING FIELDS.                                       
      ******************************************************************        
           ENTRY 'GSPTTR10' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GPSPREMIUM-SPLIT.                           
           MOVE 2 TO LINE-COUNT.                                                
           MOVE SPACES TO PR-LINES-100.                                         
           MOVE TRLR-100-HEADING-1 TO PRLINE-100-HEAD1.                         
           MOVE TRLR-100-HEADING-2 TO PRLINE-100-HEAD2.                         
GNE        CALL GTRLGTH7 USING W-GPSTRIDENT                                     
                                GTRLGTH-RETURN-AREA                             
                                GTRLGTH-RETURN-CODE.                            
           PERFORM MOVE-TR100-A THRU MOVE-TR100-EXIT                            
               VARYING SEGMENT-SUB FROM 1 BY 1                                  
                   UNTIL SEGMENT-SUB GREATER THAN GTRLGTH-NUM-SEG               
                         OR W-GPSPREM-INFO (SEGMENT-SUB) EQUAL TO SPACES        
           GO TO TRAN4-EXIT.                                                    
       MOVE-TR100-A.                                                            
           MOVE W-GPSCODE (SEGMENT-SUB) TO P-GPSCODE (SEGMENT-SUB)              
           MOVE W-GPSTART-DATE (SEGMENT-SUB) TO WDATE-P.                        
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GPSTART-DATE (SEGMENT-SUB).                        
           IF W-GPSCODE (SEGMENT-SUB) EQUAL 'P'                                 
              MOVE W-GPSFRST-LIFE (SEGMENT-SUB)                                 
                                        TO P-GPSFRST-LIFE (SEGMENT-SUB)         
              MOVE W-GPSFRST-LTD (SEGMENT-SUB)                                  
                                          TO P-GPSFRST-LTD (SEGMENT-SUB)        
              MOVE W-GPSFRST-A-S (SEGMENT-SUB)                                  
                                          TO P-GPSFRST-A-S (SEGMENT-SUB)        
              MOVE W-GPSSTOP-DATE (SEGMENT-SUB) TO WDATE-P                      
              PERFORM CONV-DATE                                                 
              MOVE WDATE-C TO P-GPSSTOP-DATE (SEGMENT-SUB)                      
           ELSE                                                                 
              MOVE W-GPSORIGINAL (SEGMENT-SUB)                                  
                                          TO P-GPSORIGINAL (SEGMENT-SUB)        
              MOVE W-GPSREMAINING (SEGMENT-SUB)                                 
                                   TO P-GPSREMAINING (SEGMENT-SUB).             
           ADD 1 TO LINE-COUNT.                                                 
       MOVE-TR100-EXIT.                                                         
           EXIT.                                                                
       END-TR100.                                                               
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 110. SET UP THE          
      *    HEADINGS AND BASE INFORMATION.  THEN SET UP THE ROOT LINES -         
      *    TWO FOR EACH HISTORY SEGMENT.                                        
      ******************************************************************        
           ENTRY 'GSPTTR11' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GAGAGENTS-INFO.                             
           MOVE +10 TO LINE-COUNT.                                              
           MOVE SPACE TO PR-LINES-110-A.                                        
           MOVE TRLR-110-HEADING-1 TO PRLINE-110-HEAD1.                         
           MOVE TRLR-110-HEADING-2 TO PRLINE-110-HEAD2.                         
           MOVE TRLR-110-HEADING-3 TO PRLINE-110-HEAD3.                         
           MOVE TRLR-110-HEADING-4 TO PRLINE-110-HEAD4.                         
           MOVE TRLR-110-HEADING-5 TO PRLINE-110-HEAD5.                         
           MOVE W-GAGAGENT-CODE TO P-GAGAGENT-CODE.                             
           MOVE W-GAGAGENT-BRANCH TO P-GAGAGENT-BRANCH.                         
           MOVE W-GAGPAYMENT-TYPE TO P-GAGPAYMENT-TYPE.                         
           MOVE W-GAGCANN-COUNTER TO P-GAGCANN-COUNTER.                         
           MOVE W-GAGPERCENT-DEFER TO P-GAGPERCENT-DEFER.                       
           MOVE W-GAGANNUALIZED-PAID TO P-GAGANNUALIZED-PAID.                   
           MOVE W-GAGANNUALIZED-EARN TO P-GAGANNUALIZED-EARN.                   
           MOVE W-GAGRENEW-COMM-PD   TO P-GAGRENEW-COMM-PD.                     
           MOVE W-GAGRENEW-COMM-EARN TO P-GAGRENEW-COMM-EARN.                   
           MOVE W-GAGSALES-CRED-PD   TO P-GAGSALES-CRED-PD.                     
           MOVE W-GAGSALES-CRED-EARN TO P-GAGSALES-CRED-EARN.                   
           MOVE W-GAGCASE-CNT-PD     TO P-GAGCASE-CNT-PD.                       
           MOVE W-GAGCASE-CNT-EARN   TO P-GAGCASE-CNT-EARN.                     
           MOVE W-GAGNAP-PAID1       TO P-GAGNAP-PAID1.                         
           MOVE W-GAGNAP-EARNED1     TO P-GAGNAP-EARNED1.                       
           MOVE W-GAGNAP-PAID2       TO P-GAGNAP-PAID2.                         
           MOVE W-GAGNAP-EARNED2     TO P-GAGNAP-EARNED2.                       
GNE        CALL GTRLGTH7 USING W-GAGTRIDENT                                     
                                GTRLGTH-RETURN-AREA                             
                                GTRLGTH-RETURN-CODE.                            
           MOVE TRLR-110-SUB-HEADING-1                                          
                             TO PRLINE-110-SUBHEAD1.                            
           MOVE TRLR-110-SUB-HEADING-2                                          
                             TO PRLINE-110-SUBHEAD2.                            
           PERFORM MOVE-TR110 THRU MOVE-TR110-EXIT                              
               VARYING SEGMENT-SUB FROM 1 BY 1                                  
                   UNTIL SEGMENT-SUB GREATER THAN GTRLGTH-NUM-SEG               
                         OR W-GAGCOMM-IND (SEGMENT-SUB)                         
                            EQUAL TO SPACES.                                    
           GO TO TRAN4-EXIT.                                                    
       MOVE-TR110.                                                              
           ADD +2 TO LINE-COUNT.                                                
           MOVE W-GAGSTART-DATE (SEGMENT-SUB) TO WDATE-P.                       
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GAGSTART-DATE (SEGMENT-SUB).                       
           MOVE W-GAGSTOP-DATE  (SEGMENT-SUB) TO WDATE-P.                       
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GAGSTOP-DATE (SEGMENT-SUB).                        
           MOVE 'FIRST-' TO P-GAG-FIRST-LIT (SEGMENT-SUB).                      
           MOVE 'RENEW-' TO P-GAG-REN-LIT (SEGMENT-SUB).                        
           MOVE W-GAGCOMM-IND (SEGMENT-SUB) TO                                  
                                            P-GAGCOMM-IND (SEGMENT-SUB)         
           MOVE W-GAGFRST-LIFE (SEGMENT-SUB) TO                                 
                               P-GAGFRST-LIFE (SEGMENT-SUB).                    
           MOVE W-GAGFRST-LTD (SEGMENT-SUB) TO                                  
                               P-GAGFRST-LTD (SEGMENT-SUB).                     
           MOVE W-GAGFRST-A-S (SEGMENT-SUB) TO                                  
                               P-GAGFRST-A-S (SEGMENT-SUB).                     
           MOVE W-GAGREN-LIFE (SEGMENT-SUB) TO                                  
                               P-GAGREN-LIFE (SEGMENT-SUB).                     
           MOVE W-GAGREN-LTD (SEGMENT-SUB) TO                                   
                               P-GAGREN-LTD (SEGMENT-SUB).                      
           MOVE W-GAGREN-A-S (SEGMENT-SUB) TO                                   
                               P-GAGREN-A-S (SEGMENT-SUB).                      
           MOVE W-GAGSCALE (SEGMENT-SUB) TO                                     
                               P-GAGSCALE (SEGMENT-SUB).                        
           MOVE W-GAGLTD-SCALE (SEGMENT-SUB) TO                                 
                               P-GAGLTD-SCALE (SEGMENT-SUB).                    
           MOVE W-GAGFLAT-RATE (SEGMENT-SUB) TO                                 
                               P-GAGFLAT-RATE (SEGMENT-SUB).                    
           MOVE W-GAGLTD-FLAT-RATE (SEGMENT-SUB) TO                             
                               P-GAGLTD-FLAT-RATE (SEGMENT-SUB).                
           MOVE W-GAGPOINT (SEGMENT-SUB) TO                                     
                               P-GAGPOINT (SEGMENT-SUB).                        
       MOVE-TR110-EXIT.                                                         
           EXIT.                                                                
       END-TR110.                                                               
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 120. HEADINGS ARE        
      *    ONLY PUT OUT IF SPEC-NOTE-COUNT IS ONE.  THIS COUNT CAN BE 1         
      *    TO 10 SIGNIFYING WHICH OCCURRENCE OF THE SPECIAL NOTES TRLR          
      *    IS PASSED.                                                           
      ******************************************************************        
           ENTRY 'GSPTTR12' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GSNSPECIAL-NOTES, SPEC-NOTE-COUNT.          
           MOVE SPACES TO PRLINES-120.                                          
           IF SPEC-NOTE-COUNT EQUAL +1                                          
              MOVE TRLR-120-HEADING-1 TO PRLINE-120-HEAD-DATA (1)               
              MOVE TRLR-120-HEADING-2 TO PRLINE-120-HEAD-DATA (2)               
              MOVE +2 TO LINE-COUNT                                             
           ELSE                                                                 
              MOVE +0 TO LINE-COUNT.                                            
           ADD 1 TO LINE-COUNT.                                                 
           MOVE W-GSNCODE TO P-GSNCODE (LINE-COUNT).                            
           MOVE W-GSNSTART-DATE TO WDATE-P.                                     
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GSNSTART-DATE (LINE-COUNT).                        
           MOVE W-GSNSTOP-DATE  TO WDATE-P.                                     
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GSNSTOP-DATE (LINE-COUNT).                         
           MOVE W-GSNINFO TO P-GSNINFO (LINE-COUNT).                            
           GO TO TRAN4-EXIT.                                                    
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 125. EACH PRINT          
      *    LINE CAN CONTAIN 2 AMENDMENT SEGMENTS.                               
      ******************************************************************        
           ENTRY 'GSPTTRAM' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GAMAMENDMENTS.                              
GNE        CALL GTRLGTH7 USING W-GAMTRIDENT                                     
                                GTRLGTH-RETURN-AREA                             
                                GTRLGTH-RETURN-CODE.                            
           MOVE 2 TO LINE-COUNT.                                                
           MOVE SPACES TO PRLINE-125-DATA                                       
           MOVE TRLR-125-HEADING-1 TO PRLINE-125-HEAD1-A                        
           MOVE TRLR-125-HEADING-2 TO PRLINE-125-HEAD2-A.                       
           PERFORM MOVE-TR125-A THRU MOVE-TR125-EXIT                            
               VARYING SEGMENT-SUB FROM 1 BY 1                                  
                   UNTIL SEGMENT-SUB GREATER THAN GTRLGTH-NUM-SEG               
                         OR W-GAMAMENDMENT-HISTORY (SEGMENT-SUB)                
                            EQUAL TO SPACES.                                    
           GO TO TRAN4-EXIT.                                                    
       MOVE-TR125-A.                                                            
           MOVE SPACES TO WPRLINE-125.                                          
           MOVE W-GAMEFFECTIVE-DATE (SEGMENT-SUB) TO WDATE-P.                   
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GAMEFFECTIVE-DATE.                                 
           MOVE W-GAMPROCESSED-DATE (SEGMENT-SUB) TO WDATE-P.                   
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GAMPROCESSED-DATE.                                 
           MOVE W-GAMREASON (SEGMENT-SUB) TO P-GAMREASON.                       
       MOVE-TR125-B.                                                            
           DIVIDE SEGMENT-SUB BY 2 GIVING TEST-SUB REMAINDER SEG-REM.           
           IF SEG-REM EQUAL +0                                                  
              MOVE WPRLINE-125 TO PRLINE-125-B (LINE-COUNT)                     
           ELSE                                                                 
              ADD 1 TO LINE-COUNT                                               
              MOVE WPRLINE-125 TO PRLINE-125-A (LINE-COUNT).                    
           IF   SEGMENT-SUB EQUAL +2                                            
                MOVE TRLR-125-HEADING-1 TO PRLINE-125-HEAD1-B                   
                MOVE TRLR-125-HEADING-2 TO PRLINE-125-HEAD2-B.                  
       MOVE-TR125-EXIT.                                                         
           EXIT.                                                                
       END-TR125.                                                               
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 130. FOR EACH            
      *    TERMINATION HISTORY SEGMENT A DATA LINE IS PRODUCED.                 
      ******************************************************************        
           ENTRY 'GSPTTR13' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GTMTERMINATION.                             
GNE        CALL GTRLGTH7 USING W-GTMTRIDENT                                     
                                GTRLGTH-RETURN-AREA                             
                                GTRLGTH-RETURN-CODE.                            
           MOVE 2 TO LINE-COUNT.                                                
           MOVE SPACES TO PRLINES-130.                                          
           MOVE TRLR-130-HEADING-1 TO PRLINE-130-HEAD1.                         
           MOVE TRLR-130-HEADING-2 TO PRLINE-130-HEAD2.                         
           PERFORM MOVE-TR130-A THRU MOVE-TR130-EXIT                            
               VARYING SEGMENT-SUB FROM 1 BY 1                                  
                   UNTIL SEGMENT-SUB GREATER THAN GTRLGTH-NUM-SEG               
                         OR W-GTMTERMINATION-HISTORY (SEGMENT-SUB)              
                            EQUAL TO SPACES.                                    
           GO TO TRAN4-EXIT.                                                    
       MOVE-TR130-A.                                                            
           MOVE W-GTMEFFECTIVE-DATE (SEGMENT-SUB) TO WDATE-P.                   
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GTMEFFECTIVE-DATE (SEGMENT-SUB).                   
           MOVE W-GTMPROCESSED-DATE (SEGMENT-SUB) TO WDATE-P.                   
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GTMPROCESSED-DATE (SEGMENT-SUB).                   
           MOVE W-GTMPURGE-DATE (SEGMENT-SUB)     TO WDATE-P.                   
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GTMPURGE-DATE (SEGMENT-SUB).                       
           MOVE W-GTMCODE (SEGMENT-SUB) TO P-GTMCODE (SEGMENT-SUB).             
           MOVE W-GTMREIN-DATE (SEGMENT-SUB) TO WDATE-P.                        
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C TO P-GTMREIN-DATE (SEGMENT-SUB).                        
           MOVE W-GTMREIN-CODE (SEGMENT-SUB) TO                                 
                                P-GTMREIN-CODE (SEGMENT-SUB).                   
           ADD +1 TO LINE-COUNT.                                                
       MOVE-TR130-EXIT.                                                         
           EXIT.                                                                
       END-TR130.                                                               
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 140. FOR EACH            
      *    COVERAGE INFORMATION SEGMENT A DATA LINE IS PRODUCED.                
      ******************************************************************        
           ENTRY 'GSPTTR14' USING LINE-COUNT, PRINT-LINES,                      
                                  W-GICIDENT-CERT.                              
GNE        CALL GTRLGTH7 USING W-GICTRIDENT                                     
                                GTRLGTH-RETURN-AREA                             
                                GTRLGTH-RETURN-CODE.                            
           MOVE 1 TO LINE-COUNT.                                                
           MOVE TRLR-140-HEADING-1 TO PRLINE-140-HEAD.                          
           PERFORM MOVE-TR140-A THRU MOVE-TR140-EXIT                            
               VARYING SEGMENT-SUB FROM 1 BY 1                                  
                   UNTIL SEGMENT-SUB GREATER THAN GTRLGTH-NUM-SEG               
                         OR W-GICCOVERAGE-INFO (SEGMENT-SUB)                    
                            EQUAL TO SPACES.                                    
           GO TO TRAN4-EXIT.                                                    
       MOVE-TR140-A.                                                            
           MOVE SPACES TO WPRLINE-140.                                          
           MOVE W-GICCLASSES        (SEGMENT-SUB) TO WORK-CLASSES.              
           MOVE W-GICCOVERAGE-CODES (SEGMENT-SUB) TO WORK-COVCODES.             
           MOVE CORR WORK-CLASSES  TO WPRLINE-140.                              
           MOVE CORR WORK-COVCODES TO WPRLINE-140.                              
           ADD 1 TO LINE-COUNT.                                                 
           MOVE SPACES TO PRLINE-140-DATA (SEGMENT-SUB).                        
           MOVE WPRLINE-140 TO PRLINE-140-DATA (SEGMENT-SUB).                   
       MOVE-TR140-EXIT.                                                         
           EXIT.                                                                
       END-TR140.                                                               
                                                                                
      ******************************************************************        
      *    THIS SECTION FORMATS THE OUTPUT FOR TRAILER 150.                     
      *    THE HEADINGS ARE PUT OUT FOR THE OUTSTANDING INFORMATION AND         
      *    THE HEADINGS FOR HISTORY INFORMATION.  THE HISTORY LINES ARE         
      *    THEN SET UP IN THE ORDER THEY APPEAR, WITH THE TAX DETAILS           
      *    FOR EACH RESPECTIVE HISTORY TRAILER.                                 
      ******************************************************************        
           ENTRY 'GSPTTR15' USING LINE-COUNT                                    
                                  PRINT-LINES                                   
                                  WMTAXTR.                                      
                                                                                
           MOVE SPACES                TO PRLINES-150-OCCURS.                    
           MOVE TRLR-150-HEAD1        TO PRLINE-150 (+1).                       
           MOVE TRLR-150-HEAD2        TO PRLINE-150 (+2).                       
           MOVE +2                    TO LINE-COUNT.                            
                                                                                
           MOVE SPACES                TO WPRLINE-150-OUTST.                     
           MOVE W-GTX-OUTST-CNT       TO P-150-OUTST-TAX-CNT.                   
           IF  W-GTX-OUTST-CNT = +0                                             
               ADD  +1                TO LINE-COUNT                             
               MOVE WPRLINE-150-OUTST TO PRLINE-150 (LINE-COUNT)                
               MOVE SPACES            TO WPRLINE-150-OUTST                      
           ELSE                                                                 
               PERFORM MOVE-TR150-OUTST THRU                                    
                       MOVE-TR150-OUTST-EXIT VARYING                            
                       TAX-SUB1 FROM +1 BY +1 UNTIL                             
                       TAX-SUB1 > W-GTX-OUTST-CNT.                              
                                                                                
           ADD  +1                    TO LINE-COUNT.                            
           MOVE TRLR-150-HIST-HEAD1   TO PRLINE-150 (LINE-COUNT).               
           ADD  +1                    TO LINE-COUNT.                            
           MOVE TRLR-150-HIST-HEAD2   TO PRLINE-150 (LINE-COUNT).               
                                                                                
           IF  W-GTX-HIST-CNT = +0                                              
               ADD  +1                TO LINE-COUNT                             
               MOVE SPACES            TO PRLINE-150 (LINE-COUNT)                
               GO TO TRAN4-EXIT.                                                
                                                                                
           PERFORM MOVE-TR150-HIST THRU                                         
                   MOVE-TR150-HIST-EXIT VARYING                                 
                   TAX-SUB1 FROM +1 BY +1 UNTIL                                 
                   TAX-SUB1 > W-GTX-HIST-CNT.                                   
           GO TO TRAN4-EXIT.                                                    
                                                                                
       MOVE-TR150-OUTST.                                                        
      ****************************************************************          
      *    LOAD UP THE OUTSTANDING PORTION OF THE TAX TRLR.                     
      ****************************************************************          
           MOVE W-GTX-OUTST-TAX-CODE (TAX-SUB1)                                 
                                      TO P-150-OUTST-TAX-CODE.                  
           MOVE W-GTX-OUTST-TAX-AMT  (TAX-SUB1)                                 
                                      TO P-150-OUTST-TAX-AMT.                   
                                                                                
           ADD  +1                    TO LINE-COUNT.                            
           MOVE WPRLINE-150-OUTST     TO PRLINE-150 (LINE-COUNT).               
           MOVE SPACES                TO WPRLINE-150-OUTST.                     
       MOVE-TR150-OUTST-EXIT.                                                   
           EXIT.                                                                
                                                                                
       MOVE-TR150-HIST.                                                         
      ****************************************************************          
      *    LOAD UP THE TAX INFO FOR THIS HISTORY SEGMENT.                       
      ****************************************************************          
           MOVE SPACES                TO WPRLINE-150-HIST.                      
                                                                                
           MOVE W-GTX-HIST-DUE-DATE (TAX-SUB1)                                  
                                      TO WDATE-P.                               
           PERFORM CONV-DATE.                                                   
           MOVE WDATE-C               TO P-150-HIST-DUE-DATE.                   
           MOVE W-GTX-HIST-TAX-CNT (TAX-SUB1)                                   
                                      TO P-150-HIST-TAX-CNT.                    
           IF  W-GTX-HIST-TAX-CNT (TAX-SUB1) = +0                               
               ADD  +1                TO LINE-COUNT                             
               MOVE WPRLINE-150-HIST  TO PRLINE-150 (LINE-COUNT)                
               MOVE SPACES            TO WPRLINE-150-HIST                       
               GO TO MOVE-TR150-HIST-EXIT.                                      
                                                                                
           PERFORM MOVE-TR150-HIST-TAXES THRU                                   
                   MOVE-TR150-HIST-TAXES-EXIT VARYING                           
                   TAX-SUB2 FROM +1 BY +1 UNTIL                                 
                   TAX-SUB2 > W-GTX-HIST-TAX-CNT (TAX-SUB1).                    
       MOVE-TR150-HIST-EXIT.                                                    
           EXIT.                                                                
                                                                                
       MOVE-TR150-HIST-TAXES.                                                   
      ****************************************************************          
      *    LOAD UP THE TAX INFO FOR THIS TAX SEGMENT                            
      ****************************************************************          
           MOVE W-GTX-HIST-TAX-CODE (TAX-SUB1 TAX-SUB2)                         
                                      TO P-150-HIST-TAX-CODE.                   
           MOVE W-GTX-HIST-TAX-AMT  (TAX-SUB1 TAX-SUB2)                         
                                      TO P-150-HIST-TAX-AMT.                    
                                                                                
           ADD  +1                    TO LINE-COUNT.                            
           MOVE WPRLINE-150-HIST      TO PRLINE-150 (LINE-COUNT).               
           MOVE SPACES                TO WPRLINE-150-HIST.                      
       MOVE-TR150-HIST-TAXES-EXIT.                                              
           EXIT.                                                                
       END-TR150.                                                               
                                                                                
       CONV-DATE.                                                               
           CALL 'QDATE' USING DATE-TYPE, WDATE-P, WDATE-C.                      
       TRAN4-EXIT.                                                              
           GOBACK.                                                              
                                                                                
MAN07 *9999-DUMP-ROUTINE.                                                       
MAN07 ******************************************************************        
MAN07 *    SERIOUS ERROR OCCURRED.                                              
MAN07 *    DISPLAY SOME CONSOLE MESSAGES, TAKE A DUMP THEN ABEND.               
MAN07 *    COPYBOOK GWRDUMP IS REQUIRED                                         
MAN07 ******************************************************************        
MAN07 *                                                                         
MAN07 *    MOVE WS-PROGRAM-ID TO GWRDUMP-PROGRAM-NAME.                          
MAN07 *    CALL GWCDUMP    USING ICBM                                           
MAN07 *                          GWRDUMP.                                       
MAN07 *                                                                         
MAN07 *9999-EXIT.                                                               
MAN07 *    EXIT.                                                                
