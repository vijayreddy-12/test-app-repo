       IDENTIFICATION DIVISION.                                                 
GNE                                                                             
FXXTOK PROGRAM-ID.  GC2NAPPR.                                                   
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *REMARKS.     CLONE OF PROGRAM GPRNAPPR                                   
      *             THIS PROGRAM PRINTS THE NET ANNUALIZED PREMIUMS             
      *             (NAP) REPORT.                                               
      *             IT ALSO CREATES A NAP RELEASE REPORT FOR TERMINATED         
      *             GROUPS.                                                     
      *--------                                                                 
      *CHANGES.                                                                 
      *--------                                                                 
      *                                                                         
      *  JULY 2005 REGINA KNAUD  - VOCOMM VCM/GIPSY:                            
      *                            CLONE GPRNAPPR FOR VO COMMISSIONS            
      *                                                               *         
      *  OCT  2008  IBM      ENTERPRISE COMPILER UPGRADE               *        
      *                                                                         
      *DATE-WRITTEN. JULY 2005.                                                 
      *DATE-COMPILED.                                                           
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWNAPPR           
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN  SCGWCO01.                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  FILLER                                  PIC X(31)  VALUE             
FXXTOK     'GC2NAPPR WORKING STORAGE BEGINS'.                                   
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  WS-DYNAMIC-PROGRAMS-CALLED.                                          
GNE        05  VOGPWRA7                   PIC X(8)    VALUE 'VOGPWRA7'.         
           05  GC2DATE                    PIC X(8)    VALUE 'GC2DATE'.          
                                                                                
       01  WORKING-AREA.                                                        
           03  WS-GROUP-NUM-7.                                                  
GNE   *        05  WS-ZEROES           PIC X(2) VALUE ZEROES.                   
GNE            05  WS-GROUP-NUM-5      PIC 9(7).                                
           03  WS-COMP-AMT             PIC ZZZ,ZZZ,ZZ9.99-.                     
           03  WS-COMP-TYPE                  PIC X    VALUE 'N'.                
           03  WS-COMP-REASON-F              PIC X    VALUE 'F'.                
           03  WS-COMP-DISP-P                PIC X    VALUE 'P'.                
GNE        03  WS-DISP-GROUP                 PIC 9(7) VALUE 0.                  
           03  FIRST-GROUP             VALUE 'N'       PIC X.                   
           03  RECORD-OK-77            VALUE 'Y'       PIC X.                   
           03  PROCESS-REPORT-77       VALUE 'N'       PIC X.                   
           03  EOF-PROCESSING-77       VALUE 'N'       PIC X.                   
           03  NAP-VALUE               VALUE 0         PIC 999.                 
           03  BILLING-SEG             VALUE +0   COMP-3 PIC S9(3).             
           03  PAGE-SIZE               VALUE +0   COMP PIC S9(4).               
           03  LINE-COUNT-1            VALUE +999 COMP PIC S9(4).               
           03  LINE-COUNT-2            VALUE +999 COMP PIC S9(4).               
           03  PAGE-COUNT-1            VALUE +0 COMP-3 PIC S9(3).               
           03  NUMBER-OF-LIVES         VALUE +0 COMP-3 PIC S9(3).               
           03  PAGE-COUNT-2            VALUE +0 COMP-3 PIC S9(3).               
           03  QDATE-FUNC-AC           VALUE 'AC'      PIC X(2).                
           03  QDATE-FUNC-BC           VALUE 'BC'      PIC X(2).                
           03  FORM-P1                 VALUE 'P1'      PIC X(2).                
           03  GMASEXPD-ERROR          VALUE SPACES    PIC X(3).                
           03  TERM-SUB                VALUE +0 COMP SYNC PIC S9(4).            
           03  WS-SUB-TOTAL-1          VALUE +0        PIC S9(7)V99.            
           03  WS-SUB-TOTAL-CHG        VALUE +0        PIC S9(7)V99.            
           03  WS-SUB-TOTAL-RC         VALUE +0        PIC S9(7)V99.            
           03  WS-SUB-TOTAL-FY         VALUE +0        PIC S9(7)V99.            
           03  WS-PREV-REP1            VALUE SPACES    PIC X(20).               
REN        03  WS-PREV-GROUP1          VALUE 0         PIC 9(7).                
           03  WS-PREV-GFO2            VALUE 0         PIC 9(5).                
           03  WS-PREV-REP2            VALUE SPACES    PIC X(20).               
REN        03  WS-PREV-GROUP2          VALUE 0         PIC 9(7).                
           03  PREV-AGENT              VALUE 0         PIC 9(6).                
           03  WORK-CHARGE             VALUE +0        PIC S9(7)V99.            
           03  WORK-CHARGE-X REDEFINES WORK-CHARGE.                             
               05  FILLER              PIC S9(7).                               
               05  WORK-DECIMAL        PIC V99.                                 
           03  WORK-EFF-DATE-ALIS    COMP-3.                                    
               05  WORK-EFF-DATE-YEAR  VALUE +0        PIC S9(3).               
               05  WORK-EFF-DATE-DAY   VALUE +0        PIC S9(3).               
           03  WORK-DATE-ALIS        COMP-3.                                    
               05  WORK-DATE-YEAR      VALUE +0        PIC S9(3).               
               05  WORK-DATE-DAY       VALUE +0        PIC S9(3).               
           03  WS-RECON-DATE         COMP-3.                                    
               05  WS-RECON-YEAR       VALUE +0        PIC S9(3).               
               05  WS-RECON-DAY        VALUE +0        PIC S9(3).               
           03  WS-TERM-DATE     COMP-3.                                         
               05  WS-TERM-YEAR        VALUE +0        PIC S9(3).               
               05  WS-TERM-DAY         VALUE +0        PIC S9(3).               
           03  WS-DISP-DATE.                                                    
               05  WS-DISP-YEAR        VALUE  0        PIC 9(3).                
               05  WS-DISP-DAY         VALUE  0        PIC 9(3).                
           03  WORK-DATE-MONTHS        VALUE +0 COMP-3 PIC S9(2)V9.             
           03  WS-MONTHS               VALUE +0 COMP-3 PIC S9(3).               
           03  WS-NAP-MONTHS           VALUE +0 COMP-3 PIC S9(3).               
           03  WORK-DATE-YEARS         VALUE +0 COMP-3 PIC S9(4).               
           03  WORK-100                VALUE +100      PIC S9(3).               
           03  WORK-50                 VALUE +50       PIC S9(3).               
           03  WORK-TERM.                                                       
               05  WT-100-CHECK        VALUE +17 COMP SYNC PIC S9(4).           
               05  WT-050-CHECK-MIN    VALUE +16 COMP SYNC PIC S9(4).           
               05  WT-050-CHECK-MAX    VALUE +29 COMP SYNC PIC S9(4).           
           03  TRAILER-IDENTS.                                                  
               05  STAT-IDENT          VALUE '010'     PIC X(3).                
               05  TERM-IDENT          VALUE '130'     PIC X(3).                
           03  QDATE-B-FORMAT.                                                  
               05  QDATE-B-DAY         VALUE ZEROS     PIC 9(2).                
           03  WORK-FOGL.                                                       
               05  WORK-FOGL-999999                    PIC 9(6).                
               05  WORK-FOGL-9                         PIC 9.                   
               05  WORK-FOGL-999                       PIC 9(3).                
                                                                                
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
      *                                                                         
       01  PREMIUM-COPYBOOK.                                                    
           05  NEW-GROUP-NUMBER.                                                
REN            10  N-GROUP-NUMBER    PIC 9(7).                                  
               10  N-GROUP-ACCT      PIC X(3).                                  
           05  ACCT-EFF-DATE         COMP-3.                                    
               10  ACCT-YEAR         PIC S9(3)    VALUE +0.                     
               10  ACCT-DAY          PIC S9(3)    VALUE +0.                     
           05  TERM-DATE             COMP-3.                                    
               10  TERM-YEAR         PIC S9(3)    VALUE +0.                     
               10  TERM-DAY          PIC S9(3)    VALUE +0.                     
           05  COMP-TYPE             PIC X        VALUE ' '.                    
      *                                                                         
                                                                                
       01  GNUMONIC-WORK-AREA.                                                  
           05  GNUM-TABLE          VALUE +34 COMP SYNC PIC S9(4).               
           05  GNUM-REP                                PIC X(5).                
           05  GNUM-RETURN.                                                     
               10  GNUM-RETURN-1-5                     PIC X(5).                
               10  FILLER                              PIC X(15).               
      *                                                                         
       01  NUM-AGT                 VALUE +0  COMP SYNC PIC S9(4).               
       01  NUMBER-OF-AGENTS        VALUE +0  COMP SYNC PIC S9(4).               
       01  AGT-SUB                 VALUE +0  COMP SYNC PIC S9(4).               
       01  AGT-CHECK               VALUE 'N' PIC X.                             
       01  AGENT-TABLE.                                                         
           05  FILLER     OCCURS 4 TIMES.                                       
               10 AGENT-NUM            PIC 9(6).                                
               10 FY-PREM-AMT        PIC S9(7)V99 COMP-3.                       
               10 R-C-AMT            PIC S9(7)V99 COMP-3.                       
               10 C-B-AMT            PIC S9(7)V999.                             
               10 C-B-PERCENT REDEFINES C-B-AMT.                                
                  15  C-B-PART1         PIC S9(7).                              
                  15  C-B-PART2         PIC V999.                               
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  VOGPWRAP-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      * GMASTER                                                                 
GNE        COPY GMASTER7.                                                       
      * VOCOMM VCM/GIPSY                                                        
           03  FILLER             PIC X(30).                                    
                                                                                
       01  PREVIOUS-CONTROL-KEY.                                                
           03  PREVIOUS-GFO-OFFICE                 PIC X(5).                    
           03  PREVIOUS-GFO-REP                    PIC X(5).                    
           03  PREVIOUS-GROUP                      PIC X(7).                    
                                                                                
       01  PR1-HEADING-LINE-1.                                                  
           03  FILLER             VALUE '1'        PIC X(1).                    
FXXTOK     03  FILLER             VALUE 'GC2NAPPR' PIC X(8).                    
           03  FILLER             VALUE SPACES     PIC X(47).                   
           03  FILLER                              PIC X(18) VALUE              
               'NAP RELEASE REPORT'.                                            
           03  FILLER             VALUE SPACES     PIC X(23).                   
           03  FILLER             VALUE 'DATE: '   PIC X(6).                    
           03  PR1-RUNDATE                         PIC X(7).                    
           03  FILLER             VALUE SPACES     PIC X(10).                   
           03  FILLER             VALUE 'PAGE: '   PIC X(6).                    
           03  PR1-PAGE                            PIC ZZZ9.                    
           03  FILLER             VALUE SPACES     PIC X(3).                    
                                                                                
       01  PR1-HEADING-LINE-2.                                                  
           03  FILLER             VALUE '0'        PIC X(1).                    
           03  FILLER                              PIC X(40)  VALUE             
               ' GFO   --- GFO REP NAME ---    GROUP    '.                      
           03  FILLER                              PIC X(40)  VALUE             
               '-----    GROUP NAME      -----  PROD PRE'.                      
           03  FILLER                              PIC X(40)  VALUE             
               'MIUM  -- ANN ---   AGENT   NUMBER  EFFEC'.                      
           03  FILLER                              PIC X(12)  VALUE             
               'TIVE CHGBACK'.                                                  
                                                                                
       01  PR1-HEADING-LINE-3.                                                  
           03  FILLER             VALUE ' '        PIC X(1).                    
           03  FILLER                              PIC X(40)  VALUE             
               'CODE                          ACCOUNT   '.                      
           03  FILLER                              PIC X(40)  VALUE             
               '                                TYPE  TY'.                      
           03  FILLER                              PIC X(40)  VALUE             
               'PE    PREMIUM     CODE   OF LIVES     DA'.                      
           03  FILLER                              PIC X(12)  VALUE             
               'TE   PERCENT'.                                                  
                                                                                
       01  EOF-REPORT                              PIC X(30) VALUE              
           '-  ***  END OF NAP REPORT  ***'.                                    
                                                                                
       01  NOTHING-TO-REPORT                       PIC X(30) VALUE              
           '-  ***  NOTHING TO REPORT ***'.                                     
                                                                                
       01  PR1-DATA-LINE.                                                       
           05  PR1-CC              VALUE SPACES    PIC X.                       
           05  PR1-DATA.                                                        
               10  PR1-GFO-CODE    VALUE SPACES    PIC X(5).                    
               10  FILLER          VALUE SPACES    PIC X(2).                    
               10  PR1-REP-NAME    VALUE SPACES    PIC X(20).                   
REN            10  FILLER          VALUE SPACES    PIC X(1).                    
REN            10  PR1-GROUP       VALUE SPACES    PIC X(7).                    
               10  PR1-DASH        VALUE SPACES    PIC X(1).                    
               10  PR1-ACCOUNT     VALUE SPACES    PIC X(3).                    
REN            10  FILLER          VALUE SPACES    PIC X(1).                    
               10  PR1-GROUP-NAME  VALUE SPACES    PIC X(30).                   
               10  FILLER          VALUE SPACES    PIC X(3).                    
               10  PR1-PROD-TYPE   VALUE SPACES    PIC X(2).                    
               10  FILLER          VALUE SPACES    PIC X(4).                    
               10  PR1-PREMIUM-TYPE VALUE SPACES   PIC X(2).                    
               10  FILLER          VALUE SPACES    PIC X(4).                    
               10  PR1-ANN-PREMIUM VALUE ZEROS     PIC Z,ZZZ,ZZ9-.              
               10  FILLER          VALUE SPACES    PIC X(2).                    
               10  PR1-AGENT-CODE  VALUE SPACES    PIC X(6).                    
               10  FILLER          VALUE SPACES    PIC X(3).                    
               10  PR1-NUM-LIVES   VALUE ZEROS     PIC ZZZZZZ9.                 
               10  FILLER          VALUE SPACES    PIC X(2).                    
               10  PR1-EFFECT-DATE.                                             
                   15  PR1-EFFECT-DAY              PIC 99.                      
                   15  PR1-EFFECT-MONTH            PIC XXX.                     
                   15  PR1-EFFECT-YEAR             PIC 99.                      
               10  FILLER          VALUE SPACES    PIC X(4).                    
               10  PR1-CHGBACK-PER.                                             
                   15  PR1-CHGBACK VALUE ZEROS     PIC ZZZ.                     
                   15  PR1-PERCENT VALUE SPACES    PIC X.                       
REN   *        10  FILLER          VALUE SPACES    PIC X(2).                    
                                                                                
       01  PRINT-LINE            VALUE SPACES      PIC X(133).                  
                                                                                
       01  SUB-TOTAL-1.                                                         
           05  SB-CC             VALUE SPACES      PIC X.                       
           05  FILLER            VALUE SPACES      PIC X(7).                    
           05  FILLER            VALUE 'SUB TOTAL' PIC X(20).                   
           05  FILLER            VALUE SPACES      PIC X(57).                   
           05  SB-ANN-PREMIUM    VALUE ZEROS       PIC ZZ,ZZZ,ZZ9-.             
                                                                                
       01  PR2-HEADING-LINE-1.                                                  
           03  FILLER             VALUE '1'        PIC X(1).                    
FXXTOK     03  FILLER             VALUE 'GC2NAPPR' PIC X(8).                    
           03  FILLER             VALUE SPACES     PIC X(32).                   
           03  FILLER                              PIC X(38) VALUE              
               'NAP RELEASE REPORT - TERMINATED GROUPS'.                        
           03  FILLER             VALUE SPACES     PIC X(17).                   
           03  FILLER             VALUE 'DATE: '   PIC X(6).                    
           03  PR2-RUNDATE                         PIC X(7).                    
           03  FILLER             VALUE SPACES     PIC X(10).                   
           03  FILLER             VALUE 'PAGE: '   PIC X(6).                    
           03  PR2-PAGE                            PIC ZZZ9.                    
           03  FILLER             VALUE SPACES     PIC X(3).                    
                                                                                
       01  PR2-HEADING-LINE-2.                                                  
           03  FILLER             VALUE '0'        PIC X(1).                    
           03  FILLER                              PIC X(35)  VALUE             
               ' GFO  --- GFO REP NAME ---  GROUP  '.                           
           03  FILLER                              PIC X(39)  VALUE             
               '-----    GROUP NAME      ----- EFF     '.                       
           03  FILLER                              PIC X(46)  VALUE             
               'AGENT  NAP  NUMBER    PROD   FY            R.C'.                
           03  FILLER                              PIC X(12)  VALUE             
               '.    CHGBACK'.                                                  
                                                                                
       01  PR2-HEADING-LINE-3.                                                  
           03  FILLER             VALUE ' '        PIC X(1).                    
           03  FILLER                              PIC X(35)  VALUE             
               'CODE                               '.                           
           03  FILLER                              PIC X(39)  VALUE             
               '                               DATE    '.                       
           03  FILLER                              PIC X(46)  VALUE             
               'CODE   %    OF LIVES  CODE   PREMIUM          '.                
           03  FILLER                              PIC X(12)  VALUE             
               SPACES.                                                          
                                                                                
       01  PR2-DATA-LINE.                                                       
           05  PR2-CC              VALUE SPACES    PIC X.                       
           05  PR2-DATA.                                                        
               10  PR2-GFO-CODE    VALUE SPACES    PIC X(5).                    
               10  FILLER          VALUE SPACES    PIC X(1).                    
               10  PR2-REP-NAME    VALUE SPACES    PIC X(20).                   
               10  FILLER          VALUE SPACES    PIC X(1).                    
REN            10  PR2-GROUP       VALUE SPACES    PIC X(7).                    
               10  FILLER          VALUE SPACES    PIC X(1).                    
               10  PR2-GROUP-NAME  VALUE SPACES    PIC X(30).                   
               10  FILLER          VALUE SPACES    PIC X(1).                    
               10  PR2-EFFECT-DATE.                                             
                   15  PR2-EFFECT-DAY              PIC 99.                      
                   15  PR2-EFFECT-MONTH            PIC XXX.                     
                   15  PR2-EFFECT-YEAR             PIC 99.                      
               10  FILLER          VALUE SPACES    PIC X(1).                    
               10  PR2-AGENT-CODE  VALUE SPACES    PIC X(6).                    
               10  FILLER          VALUE SPACES    PIC X(1).                    
               10  PR2-NAP         VALUE ZEROS     PIC ZZZ.                     
               10  PR2-NAP-PER     VALUE SPACES    PIC X.                       
               10  FILLER          VALUE SPACES    PIC X(2).                    
               10  PR2-NUM-LIVES   VALUE ZEROS     PIC ZZZZZZ9.                 
               10  FILLER          VALUE SPACES    PIC X(2).                    
               10  PR2-PROD-TYPE   VALUE SPACES    PIC X(2).                    
REN            10  FILLER          VALUE SPACES    PIC X(1).                    
      *        10  PR2-FY-PREMIUM  VALUE ZEROS     PIC Z,ZZZ,ZZ9-.              
      *        10  FILLER          VALUE SPACES    PIC X(1).                    
      *        10  PR2-R-C         VALUE ZEROS     PIC Z,ZZZ,ZZ9-.              
      *        10  FILLER          VALUE SPACES    PIC X(1).                    
      *        10  PR2-CHGBACK     VALUE ZEROS     PIC Z,ZZZ,ZZ9-.              
                                                                                
       01  SUB-TOTAL-2.                                                         
           05  SB-CC-2             VALUE SPACES    PIC X.                       
           05  FILLER              VALUE SPACES    PIC X(06).                   
           05  FILLER          VALUE 'SUB TOTAL '  PIC X(92).                   
      *    05  SB-FY-PREMIUM       VALUE ZEROS     PIC ZZ,ZZZ,ZZ9-.             
      *    05  SB-R-C              VALUE ZEROS     PIC ZZ,ZZZ,ZZ9-.             
      *    05  SB-CHGBACK          VALUE ZEROS     PIC ZZ,ZZZ,ZZ9-.             
                                                                                
       01  PR1-PRINT-LINE.                                                      
           03  PRINT1-CC                           PIC X.                       
           03  FILLER                              PIC X(132).                  
                                                                                
       01  PR2-PRINT-LINE.                                                      
           03  PRINT2-CC                           PIC X.                       
           03  FILLER                              PIC X(132).                  
                                                                                
       01  SAVE-PRINT-LINE                         PIC X(133).                  
      *                                                                         
       01  DLSWRITE-PARMS80.                                                    
           03  PRINT-SYS020                   PIC X(6)  VALUE 'SYS020'.         
           03  PRINT-RTN80      COMP-3        PIC S9    VALUE +0.               
           03  PRINT-RECSIZE80                PIC 9(5)  VALUE 00133.            
           03  PRINT-BLKSIZE80                PIC 9(5)  VALUE 01330.            
           03  PRINT-FORMAT80                 PIC XX    VALUE 'FB'.             
           03  PRINT-SYS020-COUNT             PIC S9(9) VALUE +0.               
      *                                                                         
       01  DLSWRITE-PARMS81.                                                    
           03  PRINT-SYS021                   PIC X(6)  VALUE 'SYS021'.         
           03  PRINT-RTN81      COMP-3        PIC S9    VALUE +0.               
           03  PRINT-RECSIZE81                PIC 9(5)  VALUE 00133.            
           03  PRINT-BLKSIZE81                PIC 9(5)  VALUE 01330.            
           03  PRINT-FORMAT81                 PIC XX    VALUE 'FB'.             
           03  PRINT-SYS021-COUNT             PIC S9(9) VALUE +0.               
      *                                                                         
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *           
      * * * * * * * * DATABASE SUBSCHEMA DESCRIPTION* * * * * * * * *           
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *           
                                                                                
       01  FILLER               PIC X(32) VALUE                                 
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *           
      * * * * * * * *DATABASE RECORDS * * * * * * * * * * * * * * * *           
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *           
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
                                                                                
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA                                              
FLT30                              END-EXEC.                                    
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
      * GNAPREC                                                                 
CPYNME     COPY GNAPREC7.                                                       
                                                                                
      *  RESTART INFORMATION PASSED TO THIS PROGRAM                             
                                                                                
       01  MISC-AREA.                                                           
           03  FILLER                              PIC X(4).                    
           03  ST-HIDATE                           PIC X(4).                    
           03  FILLER                              PIC X(24).                   
                                                                                
      *  PRINT PARMETERS COPY BOOK                                              
                                                                                
        COPY GPRPRINT.                                                          
                                                                                
      *01  PR1-PARAM-DATA.                                                      
           03  PR1-HEAD-PARAM                      PIC X(50).                   
           03  PR1-DATE-PARAM                      PIC X(12).                   
           03  PR1-PAGE-NUMBER             COMP-3  PIC S9(5).                   
                                                                                
      *  TAPE PARMETERS COPY BOOK FOR SYS011 AND SYS014                         
                                                                                
        COPY GPRTPARM.                                                          
                                                                                
      *  REPORT ACCUMULATOR COPY BOOK                                           
                                                                                
        COPY GPRACCUM.                                                          
                                                                                
       PROCEDURE DIVISION USING GNAPREC                                         
                                MISC-AREA                                       
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
FXXTOK     MOVE 'GC2NAPPR'         TO FCCSPL-CURR-PGM.                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
      *INITIALIZE.                                                              
      ******************************************************************        
      *                                                                *        
      *                   INITIALIZE VARIABLES                         *        
      *                                                                *        
      ******************************************************************        
                                                                                
       INITIALIZATION.                                                          
MAN02      CALL 'ZLINECT'  USING PAGE-SIZE.                                     
MAN02      CALL QDATEQ2    USING QDATE-FUNC-AC                                  
MAN02                            ST-HIDATE                                      
MAN02                            PR1-RUNDATE.                                   
           MOVE PR1-RUNDATE      TO PR2-RUNDATE.                                
                                                                                
      *    PRODUCE A NAP REPORT EVEN IF NO NAPS ARE GENERATED                   
           IF GNAP-RECORD-TYPE NOT EQUAL 'P'                                    
              MOVE +999              TO LINE-COUNT-1                            
              MOVE NOTHING-TO-REPORT TO PR1-PRINT-LINE                          
              PERFORM PRINT-LINE-1 THRU PRINT-LINE-1-EXIT                       
              PERFORM CLOSE-DLSWRITE-80 THRU CLOSE-DLSWRITE-80-EXIT             
              MOVE +999              TO LINE-COUNT-2                            
              MOVE NOTHING-TO-REPORT TO PR2-PRINT-LINE                          
              PERFORM PRINT-LINE-2 THRU PRINT-LINE-2-EXIT                       
              PERFORM CLOSE-DLSWRITE-81 THRU CLOSE-DLSWRITE-81-EXIT             
              GO                     TO END-OF-JOB.                             
                                                                                
           PERFORM INIT-TABLE        THRU INIT-TABLE-X                          
                                     VARYING AGT-SUB                            
                                     FROM +1                                    
                                     BY +1                                      
                                     UNTIL AGT-SUB > +4.                        
                                                                                
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-P1.                                       
           MOVE +999       TO LINE-COUNT-1                                      
                              LINE-COUNT-2.                                     
           MOVE GNAP-GFO-OFFICE TO PREVIOUS-GFO-OFFICE.                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREA TO BE ACCESSED                              *         
      *     FIND THE GROUP NUMBER ON GWCORGROUP                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2NAPPR' TO PROGRAM-NAME.                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           MOVE +0              TO WS-SUB-TOTAL-1                               
                                   WS-SUB-TOTAL-CHG                             
                                   WS-SUB-TOTAL-FY                              
                                   WS-SUB-TOTAL-RC.                             
                                                                                
           MOVE 'Y'             TO FIRST-GROUP.                                 
           MOVE GNAP-REP-NAME   TO WS-PREV-REP1.                                
           MOVE GNAP-GROUP      TO WS-PREV-GROUP1.                              
                                                                                
       INITIALIZATION-EXIT.                                                     
           EXIT.                                                                
                                                                                
       PROCESS-RECORD.                                                          
           DISPLAY 'PROCESSING ..' GGIGROUP-NUMBER ' ' GGIACCOUNT               
           PERFORM PROCESS-REPORT-1 THRU PROCESS-REPORT-1-X.                    
                                                                                
           MOVE 'N'                      TO PROCESS-REPORT-77.                  
      *                                                                         
      *    IF GGIPRODUCT-CODE     > '1'                                         
      *                                                                         
              IF GGIACCOUNT-STATUS   > '19'                                     
                 PERFORM FIND-TERM-LENGTH      THRU FIND-TERM-LENGTH-X          
                 IF PROCESS-REPORT-77 = 'Y'                                     
                    PERFORM CHECK-REP-2        THRU CHECK-REP-2-X               
                    IF  GNAP-REP-NAME   NOT EQUAL WS-PREV-REP2 OR               
                        GNAP-GROUP      NOT EQUAL WS-PREV-GROUP2 OR             
                        GNAP-GFO-OFFICE NOT EQUAL WS-PREV-GFO2                  
                        PERFORM REP-2-PAGE-BRK                                  
                                         THRU REP-2-PAGE-BRK-X                  
                        PERFORM REP-2-PROCESS                                   
                                         THRU REP-2-PROCESS-X                   
                    ELSE                                                        
                        PERFORM REP-2-PROCESS                                   
                                         THRU REP-2-PROCESS-X.                  
                                                                                
           PERFORM READ-RECORD THRU READ-RECORD-EXIT.                           
                                                                                
           IF (TAPE-RETURN EQUAL ZEROES AND GNAP-RECORD-TYPE EQUAL 'P')         
               GO TO PROCESS-RECORD.                                            
                                                                                
           PERFORM PRINT-FINAL-TOTAL THRU PRINT-FINAL-TOTAL-X.                  
                                                                                
       FINISH-JOB.                                                              
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
       END-OF-JOB.                                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'CLOSE FILES'      TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
GNE        CALL  VOGPWRA7    USING  VOGPWRAP-PROTOCOL                           
GNE                                 VOGPW-DATA-RECORD.                          
                                                                                
           GOBACK.                                                              
                                                                                
       INIT-TABLE.                                                              
           MOVE 0    TO  AGENT-NUM    (AGT-SUB)                                 
           MOVE +0   TO  FY-PREM-AMT  (AGT-SUB)                                 
                         R-C-AMT      (AGT-SUB)                                 
                         C-B-AMT      (AGT-SUB).                                
                                                                                
       INIT-TABLE-X.                                                            
           EXIT.                                                                
                                                                                
       PROCESS-REPORT-1.                                                        
           IF (GNAP-GFO-OFFICE NOT EQUAL PREVIOUS-GFO-OFFICE)                   
               PERFORM GFO-CONTROL-BREAK THRU GFO-CONTROL-BREAK-X.              
                                                                                
           IF  GNAP-REP-NAME   NOT EQUAL WS-PREV-REP1 OR                        
               GNAP-GROUP      NOT EQUAL WS-PREV-GROUP1                         
               PERFORM REP-1-PAGE-BRK THRU REP-1-PAGE-BRK-X.                    
                                                                                
           PERFORM REP-1-PROCESS THRU REP-1-PROCESS-X.                          
                                                                                
       PROCESS-REPORT-1-X.                                                      
           EXIT.                                                                
                                                                                
       FIND-TERM-LENGTH.                                                        
      *                                                                         
      *    PROCESS REPORT ONLY IF TERMINATED WITHING 24 MONTHS OF               
      *       ACCOUNT EFFECTIVE DATE                                            
      *                                                                         
           IF FIRST-GROUP = 'Y'                                                 
              MOVE GNAP-REP-NAME    TO WS-PREV-REP2                             
              MOVE GNAP-GROUP       TO WS-PREV-GROUP2                           
              MOVE GNAP-GFO-OFFICE  TO WS-PREV-GFO2                             
              MOVE 'N'              TO FIRST-GROUP.                             
      *                                                                         
           COMPUTE WORK-DATE-YEARS ROUNDED =                                    
                   WS-TERM-YEAR  - GGI-ACCT-EFF-YEAR.                           
                                                                                
           IF WORK-DATE-YEARS  IS GREATER THAN +3                               
              GO TO FIND-TERM-LENGTH-X.                                         
                                                                                
           MOVE GGI-ACCT-EFFECTIVE   TO VDATE-ALIS-DATE1.                       
           MOVE WS-TERM-DATE         TO VDATE-ALIS-DATE2.                       
           MOVE '3B2'                TO VDATE-REQUEST-AREA.                     
           MOVE +0                   TO VDATE-ADJUST-MONTHS.                    
           CALL  GC2DATE  USING GAC-DATE-PARAMETERS.                            
           IF VDATE-RET-FAIL                                                    
              DISPLAY '**********************************************'          
              DISPLAY 'ERROR CALLING GC2DATE ' VDATE-RET-CODE ' GROUP '         
                GGIGROUP-NUMBER ' ACCT ' GGIACCOUNT                             
              DISPLAY '**********************************************'          
              MOVE +999              TO WS-MONTHS                               
           ELSE                                                                 
              MOVE VDATE-ADJUST-MONTHS TO WS-MONTHS.                            
                                                                                
           IF WS-MONTHS < 27                                                    
              MOVE 'Y'                 TO PROCESS-REPORT-77                     
              MOVE '%'                 TO PR2-NAP-PER                           
              IF WS-MONTHS < 17                                                 
                 MOVE 100              TO PR2-NAP                               
                                          NAP-VALUE                             
              ELSE                                                              
                MOVE 50                TO PR2-NAP                               
                                          NAP-VALUE.                            
                                                                                
       FIND-TERM-LENGTH-X.                                                      
           EXIT.                                                                
                                                                                
       GFO-CONTROL-BREAK.                                                       
           PERFORM REP-1-PAGE-BRK         THRU REP-1-PAGE-BRK-X.                
           MOVE +70 TO LINE-COUNT-1.                                            
                                                                                
       GFO-CONTROL-BREAK-X.                                                     
           EXIT.                                                                
                                                                                
       REP-1-PAGE-BRK.                                                          
      *                                                                         
      *    IF GGIPRODUCT-CODE   = '1' OR                                        
      *                                                                         
           IF GGIACCOUNT-STATUS > '19'                                          
              GO TO REP-1-PAGE-BRK-X.                                           
           MOVE WS-SUB-TOTAL-1      TO SB-ANN-PREMIUM.                          
           MOVE SUB-TOTAL-1         TO PRINT-LINE.                              
           PERFORM WRITE-SUB-TOT-22 THRU WRITE-SUB-TOT-22-EXIT.                 
           MOVE SPACES              TO PRINT-LINE.                              
           PERFORM WRITE-SUB-TOT-22 THRU WRITE-SUB-TOT-22-EXIT.                 
           ADD +2                   TO LINE-COUNT-1.                            
           MOVE +0                  TO WS-SUB-TOTAL-1                           
                                                                                
           MOVE GNAP-REP-NAME       TO WS-PREV-REP1.                            
           MOVE GNAP-GROUP          TO WS-PREV-GROUP1.                          
                                                                                
       REP-1-PAGE-BRK-X.                                                        
           EXIT.                                                                
                                                                                
       REP-2-PAGE-BRK.                                                          
      *    MOVE WS-SUB-TOTAL-CHG    TO SB-CHGBACK.                              
      *    MOVE WS-SUB-TOTAL-RC     TO SB-R-C.                                  
      *    MOVE WS-SUB-TOTAL-FY     TO SB-FY-PREMIUM.                           
      *    MOVE SUB-TOTAL-2         TO PRINT-LINE.                              
      *    PERFORM WRITE-SUB-TOT-23 THRU WRITE-SUB-TOT-23-EXIT.                 
           MOVE SPACES              TO PRINT-LINE.                              
           PERFORM WRITE-SUB-TOT-23 THRU WRITE-SUB-TOT-23-EXIT.                 
           ADD +2                   TO LINE-COUNT-2.                            
      *    MOVE +0                  TO WS-SUB-TOTAL-CHG                         
      *                                WS-SUB-TOTAL-FY                          
      *                                WS-SUB-TOTAL-RC.                         
                                                                                
           MOVE GNAP-GFO-OFFICE     TO WS-PREV-GFO2.                            
           MOVE GNAP-REP-NAME       TO WS-PREV-REP2.                            
           MOVE GNAP-GROUP          TO WS-PREV-GROUP2.                          
                                                                                
       REP-2-PAGE-BRK-X.                                                        
           EXIT.                                                                
                                                                                
       REP-1-PROCESS.                                                           
           ADD  GNAP-AMOUNT      TO WS-SUB-TOTAL-1.                             
           MOVE GNAP-GFO-OFFICE  TO PREVIOUS-GFO-OFFICE.                        
           MOVE SPACES           TO PR1-CC.                                     
           MOVE GNAP-GFO-OFFICE  TO PR1-GFO-CODE.                               
           MOVE GNAP-GROUP       TO PR1-GROUP.                                  
           MOVE '-'              TO PR1-DASH.                                   
           MOVE GNAP-ACCOUNT     TO PR1-ACCOUNT.                                
                                                                                
           MOVE GNAP-GROUP-NAME  TO PR1-GROUP-NAME.                             
           MOVE ZEROS            TO PR1-CHGBACK.                                
           MOVE SPACES           TO PR1-PERCENT.                                
           PERFORM READ-GMASTER THRU                                            
                   READ-GMASTER-X.                                              
           PERFORM GMASTER-MOVE THRU GMASTER-EXIT.                              
      *                                                                         
      *    IF GGIPRODUCT-CODE   = '1' OR                                        
      *                                                                         
           IF GGIACCOUNT-STATUS > '19'                                          
              SUBTRACT GNAP-AMOUNT  FROM WS-SUB-TOTAL-1                         
              GO TO REP-1-PROCESS-X.                                            
      *                                                                         
      *    IF LIVES IS ZERO AND GROUP IS PENDING UNDERWRITING OR                
      *       PENDING ISSUE OR A SELF-ADMIN GROUP - RETRIEVE NUMBER             
      *       OF LIVES FROM GWCORCOMP ON DATABASE                               
      *                                                                         
                                                                                
           IF  NUMBER-OF-LIVES = +0                                             
              IF GGIACCOUNT-STATUS = '05' OR '10' OR                            
                 GGIBILLING-TYPE =  'SA'                                        
                 PERFORM FIND-LIVES THRU FIND-LIVES-EXIT.                       
      *                                                                         
           IF GGIPRODUCT-CODE = '1'                                             
                 MOVE 'A ' TO PR1-PROD-TYPE.                                    
      *                                                                         
           IF GGIPRODUCT-CODE = '2'                                             
              IF GGIADMIN-AREA   = '2'                                          
                 MOVE 'O ' TO PR1-PROD-TYPE                                     
              ELSE                                                              
                 IF GGIADMIN-AREA   = '3'                                       
                    MOVE 'CO' TO PR1-PROD-TYPE                                  
                 ELSE                                                           
                    MOVE 'O'  TO PR1-PROD-TYPE.                                 
      *                                                                         
           IF GGIPRODUCT-CODE > '2'                                             
              IF GGIADMIN-AREA   = '2'                                          
                 MOVE 'S ' TO PR1-PROD-TYPE                                     
              ELSE                                                              
                 IF GGIADMIN-AREA   = '3'                                       
                    MOVE 'CS' TO PR1-PROD-TYPE                                  
                 ELSE                                                           
                    MOVE 'S ' TO PR1-PROD-TYPE.                                 
                                                                                
           MOVE GNAP-PREM-TYPE   TO PR1-PREMIUM-TYPE.                           
           MOVE GNAP-AMOUNT      TO PR1-ANN-PREMIUM.                            
           MOVE GNAP-AGENT-CODE  TO PR1-AGENT-CODE.                             
                                                                                
           PERFORM GET-AGENT-NAME1 THRU GET-AGENT-NAME1-EXIT.                   
                                                                                
           MOVE PR1-DATA-LINE TO PR1-PRINT-LINE.                                
           PERFORM PRINT-LINE-1 THRU PRINT-LINE-1-EXIT.                         
                                                                                
       REP-1-PROCESS-X.                                                         
           EXIT.                                                                
                                                                                
       FIND-LIVES.                                                              
           MOVE 'Y'                 TO RECORD-OK-77.                            
MUNCAN     MOVE GGIGROUP-NUMBER    TO WS-GROUP-NUM-5.                           
MUNCAN     MOVE WS-GROUP-NUM-7     TO GROUP-NUMBER  OF GWCORGRACCT.             
      *    MOVE GGIGROUP-NUMBER    TO GROUP-NUMBER  OF GWCORGRACCT.             
           MOVE GGIACCOUNT          TO GR-ACCOUNT    OF GWCORGRACCT.            
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE 'N'          TO RECORD-OK-77.                            
                                                                                
           IF RECORD-OK-77 = 'Y'                                                
              MOVE COMP-LIVES OF GWCORGRACCT TO PR1-NUM-LIVES.                  
                                                                                
       FIND-LIVES-EXIT.                                                         
           EXIT.                                                                
                                                                                
       CHECK-REP-2.                                                             
           MOVE GGI-ACCT-EFFECTIVE   TO ACCT-EFF-DATE                           
                                        WS-RECON-DATE.                          
           IF GGI-ACCT-EFF-DAY > +0 AND                                         
              GGI-ACCT-EFF-DAY < +32                                            
              MOVE +365              TO WS-RECON-DAY                            
           ELSE                                                                 
              SUBTRACT +1            FROM WS-RECON-DAY                          
              ADD +1                 TO   WS-RECON-YEAR.                        
                                                                                
           MOVE 'N'                 TO EOF-PROCESSING-77.                       
MUNCAN     MOVE GGIGROUP-NUMBER    TO WS-GROUP-NUM-5.                           
MUNCAN     MOVE WS-GROUP-NUM-7     TO GROUP-NUMBER  OF GWCORGRACCT.             
      *    MOVE GGIGROUP-NUMBER    TO GROUP-NUMBER  OF GWCORGRACCT.             
           MOVE GGIACCOUNT         TO GR-ACCOUNT    OF GWCORGRACCT.             
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE 'Y'          TO EOF-PROCESSING-77.                       
                                                                                
      *%   OBTAIN FIRST WITHIN GRACCT-COMP                                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE 'Y'          TO EOF-PROCESSING-77.                       
                                                                                
           MOVE +1               TO AGT-SUB                                     
                                    NUM-AGT                                     
                                    NUMBER-OF-AGENTS.                           
                                                                                
           MOVE 'N'              TO AGT-CHECK.                                  
                                                                                
           PERFORM PROCESS-COMPS  THRU PROCESS-COMPS-EXIT                       
                                       UNTIL EOF-PROCESSING-77 = 'Y'.           
                                                                                
       CHECK-REP-2-X.                                                           
           EXIT.                                                                
                                                                                
       REP-2-PROCESS.                                                           
           MOVE GNAP-GFO-OFFICE  TO PREVIOUS-GFO-OFFICE.                        
           MOVE SPACES           TO PR2-CC.                                     
           MOVE GNAP-GFO-OFFICE  TO PR2-GFO-CODE.                               
           MOVE GNAP-GROUP       TO PR2-GROUP.                                  
           MOVE GNAP-GROUP-NAME  TO PR2-GROUP-NAME.                             
MAN02      CALL QDATEQ2 USING QDATE-FUNC-AC                                     
MAN02                         GGICONTRACT-ISSUE                                 
MAN02                         PR2-EFFECT-DATE.                                  
      *                                                                         
           IF GGIPRODUCT-CODE = '1'                                             
              MOVE 'A ' TO PR2-PROD-TYPE.                                       
      *                                                                         
           IF GGIPRODUCT-CODE = '2'                                             
              IF GGIADMIN-AREA   = '2'                                          
                 MOVE 'O ' TO PR2-PROD-TYPE                                     
              ELSE                                                              
                 IF GGIADMIN-AREA   = '3'                                       
                    MOVE 'CO' TO PR2-PROD-TYPE                                  
                 ELSE                                                           
                    MOVE 'O'  TO PR2-PROD-TYPE.                                 
      *                                                                         
           IF GGIPRODUCT-CODE > '2'                                             
              IF GGIADMIN-AREA   = '2'                                          
                 MOVE 'S ' TO PR2-PROD-TYPE                                     
              ELSE                                                              
                 IF GGIADMIN-AREA   = '3'                                       
                    MOVE 'CS' TO PR2-PROD-TYPE                                  
                 ELSE                                                           
                    MOVE 'S ' TO PR2-PROD-TYPE.                                 
                                                                                
           IF GBINO-HIST-SEG > +1                                               
              SUBTRACT +1 FROM GBINO-HIST-SEG GIVING BILLING-SEG                
           ELSE                                                                 
              MOVE +1     TO BILLING-SEG.                                       
           MOVE GBICERT-HOLDERS (BILLING-SEG) TO PR2-NUM-LIVES.                 
           PERFORM MOVE-DATA     THRU MOVE-DATA-X                               
                                 VARYING AGT-SUB                                
                                 FROM +1                                        
                                 BY +1                                          
                                 UNTIL AGT-SUB > NUMBER-OF-AGENTS.              
                                                                                
           PERFORM INIT-TABLE        THRU INIT-TABLE-X                          
                                     VARYING AGT-SUB                            
                                     FROM +1                                    
                                     BY +1                                      
                                     UNTIL AGT-SUB > +4.                        
                                                                                
       REP-2-PROCESS-X.                                                         
           EXIT.                                                                
                                                                                
       MOVE-DATA.                                                               
           IF  LINE-COUNT-2 GREATER THAN PAGE-SIZE                              
               MOVE GNAP-GFO-OFFICE  TO PR2-GFO-CODE                            
               MOVE GNAP-REP-NAME    TO PR2-REP-NAME                            
               MOVE GNAP-GROUP       TO PR2-GROUP                               
               MOVE GNAP-GROUP-NAME  TO PR2-GROUP-NAME                          
MAN02          CALL QDATEQ2 USING QDATE-FUNC-AC                                 
MAN02                             GGICONTRACT-ISSUE                             
MAN02                             PR2-EFFECT-DATE                               
           ELSE                                                                 
              IF  AGT-SUB > 1                                                   
                  MOVE SPACES           TO PR2-GFO-CODE                         
                                           PR2-REP-NAME                         
                                           PR2-GROUP                            
                                           PR2-GROUP-NAME                       
                                           PR2-EFFECT-DATE.                     
           MOVE AGENT-NUM    (AGT-SUB) TO PR2-AGENT-CODE.                       
      *    IF C-B-PART2 (AGT-SUB) < .500                                        
      *       MOVE 0                   TO C-B-PART2 (AGT-SUB)                   
      *    ELSE                                                                 
      *       MOVE 0                   TO C-B-PART2 (AGT-SUB)                   
      *       ADD +1                   TO C-B-PART1 (AGT-SUB).                  
      *                                                                         
      *    MOVE C-B-AMT      (AGT-SUB) TO PR2-CHGBACK.                          
      *    ADD C-B-AMT       (AGT-SUB) TO WS-SUB-TOTAL-CHG.                     
                                                                                
           PERFORM GET-AGENT-NAME2 THRU GET-AGENT-NAME2-EXIT.                   
           MOVE PR2-DATA-LINE          TO PR2-PRINT-LINE.                       
           PERFORM PRINT-LINE-2        THRU PRINT-LINE-2-EXIT.                  
                                                                                
       MOVE-DATA-X.                                                             
           EXIT.                                                                
                                                                                
       GMASTER-MOVE.                                                            
MAN02      CALL QDATEQ2 USING QDATE-FUNC-AC                                     
MAN02                         GGICONTRACT-ISSUE                                 
MAN02                         PR1-EFFECT-DATE.                                  
           IF GSTTRIDENT EQUAL TO STAT-IDENT                                    
              MOVE GSTPART     TO PR1-NUM-LIVES                                 
                                  NUMBER-OF-LIVES                               
           ELSE                                                                 
              MOVE +0          TO PR1-NUM-LIVES                                 
                                  NUMBER-OF-LIVES.                              
           MOVE GGI-ACCT-EFFECTIVE TO WORK-EFF-DATE-ALIS.                       
           MOVE +5             TO TERM-SUB.                                     
       TERM-CHECK.                                                              
           IF GTMTRIDENT EQUAL TO TERM-IDENT                                    
              IF GTMEFFECTIVE-YEAR (TERM-SUB) IS NUMERIC                        
      * ADDED                                                                   
                 IF GTMREINSTATEMENT-INFO (TERM-SUB) NOT = SPACES               
                    MOVE GTMEFFECTIVE-DATE (TERM-SUB) TO WS-TERM-DATE           
                    IF GTMEFFECTIVE-DATE (TERM-SUB) IS LESS                     
                       THAN GGI-ACCT-EFFECTIVE                                  
                       PERFORM TERM-DATE-CHECK THRU TERM-DATE-EXIT              
                       GO TO GMASTER-EXIT                                       
                    ELSE                                                        
                       NEXT SENTENCE                                            
                 ELSE                                                           
                    NEXT SENTENCE                                               
              ELSE                                                              
                 NEXT SENTENCE                                                  
           ELSE                                                                 
              NEXT SENTENCE.                                                    
           IF TERM-SUB IS GREATER THAN +1                                       
              SUBTRACT +1 FROM TERM-SUB                                         
              GO TO TERM-CHECK                                                  
           ELSE                                                                 
              MOVE ZEROS            TO PR1-CHGBACK                              
                                       NAP-VALUE.                               
              MOVE SPACES           TO PR1-PERCENT.                             
       GMASTER-EXIT.                                                            
           EXIT.                                                                
                                                                                
       TERM-DATE-CHECK.                                                         
           COMPUTE WORK-DATE-MONTHS ROUNDED =                                   
                   GTMEFFECTIVE-YEAR (TERM-SUB) -                               
                   GGI-ACCT-EFF-YEAR.                                           
           IF WORK-DATE-MONTHS IS GREATER THAN +5                               
               MOVE ZEROS  TO PR1-CHGBACK                                       
                              NAP-VALUE                                         
               MOVE SPACES TO PR1-PERCENT                                       
               GO TO TERM-DATE-EXIT                                             
           ELSE                                                                 
              MOVE +0 TO WORK-DATE-MONTHS.                                      
           IF GGI-ACCT-EFF-DAY LESS THAN GTMEFFECTIVE-DAY (TERM-SUB)            
              ADD +365 TO WORK-EFF-DATE-DAY                                     
              SUBTRACT +1 FROM WORK-EFF-DATE-YEAR.                              
           COMPUTE WORK-DATE-YEAR = GTMEFFECTIVE-YEAR (TERM-SUB) -              
                    WORK-EFF-DATE-YEAR.                                         
           COMPUTE WORK-DATE-DAY  = GTMEFFECTIVE-DAY (TERM-SUB) -               
                    WORK-EFF-DATE-DAY.                                          
           COMPUTE WORK-DATE-MONTHS ROUNDED =                                   
                   (WORK-DATE-YEAR * 12)   +                                    
                   (WORK-DATE-DAY / 30).                                        
           COMPUTE WORK-DATE-MONTHS ROUNDED = WORK-DATE-MONTHS * +1.            
           IF WORK-DATE-MONTHS LESS THAN WT-100-CHECK                           
              MOVE WORK-100 TO PR1-CHGBACK                                      
                               NAP-VALUE                                        
              MOVE '%'      TO PR1-PERCENT                                      
           ELSE                                                                 
               IF  WORK-DATE-MONTHS LESS    THAN WT-050-CHECK-MAX               
               AND WORK-DATE-MONTHS GREATER THAN WT-050-CHECK-MIN               
                  MOVE WORK-50  TO PR1-CHGBACK                                  
                                   NAP-VALUE                                    
                  MOVE '%'      TO PR1-PERCENT                                  
               ELSE                                                             
                  MOVE ZEROS    TO PR1-CHGBACK                                  
                                   NAP-VALUE                                    
                  MOVE SPACES   TO PR1-PERCENT.                                 
       TERM-DATE-EXIT.                                                          
           EXIT.                                                                
                                                                                
       PROCESS-COMPS.                                                           
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     READ IN THE COMPENSATION RECORDS                          *         
      *     IF END OF SET EXIT MODULE                                 *         
      *     SELECT THE PAID NAP  RECORDS ONLY                         *         
      *     COMP-TYPE = 'N' AND COMP-REASON = 'F'                     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *    ACCUMULATE FIRST YEAR NAPS                                           
           IF COMP-TYPE   OF GWCORCOMP   = WS-COMP-TYPE     AND                 
              COMP-REASON OF GWCORCOMP   = WS-COMP-REASON-F AND                 
              COMP-EFF-DATE OF GWCORCOMP = ACCT-EFF-DATE                        
              IF AGT-CHECK = 'N'                                                
                 MOVE AGENT-NUMBER OF GWCORCOMP TO PREV-AGENT                   
                                                   AGENT-NUM (1)                
                 MOVE 'Y'                       TO AGT-CHECK.                   
                                                                                
      *    ACCUMULATE RECONCILATION NAPS                                        
           IF COMP-TYPE   OF GWCORCOMP   = WS-COMP-TYPE     AND                 
              COMP-REASON OF GWCORCOMP   = WS-COMP-REASON-F AND                 
              COMP-EFF-DATE OF GWCORCOMP = WS-RECON-DATE                        
              IF AGT-CHECK = 'N'                                                
                 MOVE AGENT-NUMBER OF GWCORCOMP TO PREV-AGENT                   
                                                   AGENT-NUM (1)                
                 MOVE 'Y'                       TO AGT-CHECK.                   
                                                                                
      *%   OBTAIN NEXT WITHIN GRACCT-COMP                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               MOVE 'Y'                 TO EOF-PROCESSING-77.                   
                                                                                
       PROCESS-COMPS-EXIT.                                                      
           EXIT.                                                                
                                                                                
       FIND-CUR-AGT.                                                            
            IF AGENT-NUMBER OF GWCORCOMP = AGENT-NUM (1)                        
               MOVE +1                     TO NUM-AGT                           
            ELSE                                                                
               IF AGENT-NUM (2) = 0                                             
                  MOVE AGENT-NUMBER OF GWCORCOMP TO AGENT-NUM (2)               
                  MOVE +2                        TO NUMBER-OF-AGENTS            
                  MOVE +2                        TO NUM-AGT                     
               ELSE                                                             
                  IF AGENT-NUMBER OF GWCORCOMP = AGENT-NUM (2)                  
                     MOVE +2                     TO NUM-AGT                     
                  ELSE                                                          
                     IF AGENT-NUM (3) = 0                                       
                        MOVE AGENT-NUMBER OF GWCORCOMP TO AGENT-NUM (3)         
                        MOVE +3                     TO NUMBER-OF-AGENTS         
                        MOVE +3                     TO NUM-AGT                  
                     ELSE                                                       
                        IF AGENT-NUMBER OF GWCORCOMP = AGENT-NUM (3)            
                           MOVE +3                     TO NUM-AGT               
                        ELSE                                                    
                           IF AGENT-NUM (4) = 0                                 
                              MOVE AGENT-NUMBER OF GWCORCOMP                    
                                                    TO AGENT-NUM (4)            
                              MOVE +4               TO NUMBER-OF-AGENTS         
                              MOVE +4               TO NUM-AGT                  
                           ELSE                                                 
                              MOVE +4                  TO NUM-AGT.              
                                                                                
       FIND-CUR-AGT-X.                                                          
           EXIT.                                                                
                                                                                
       GET-AGENT-NAME1.                                                         
                                                                                
MUNCAN     MOVE GGIGROUP-NUMBER    TO WS-GROUP-NUM-5.                           
MUNCAN     MOVE WS-GROUP-NUM-7     TO GROUP-NUMBER  OF GWCORGRACCT.             
      *    MOVE GGIGROUP-NUMBER    TO GROUP-NUMBER  OF GWCORGRACCT.             
           MOVE GGIACCOUNT         TO GR-ACCOUNT    OF GWCORGRACCT.             
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE GGIGROUP-NUMBER TO WS-DISP-GROUP                         
                  DISPLAY '******************************************'          
                  DISPLAY 'GROUP/ACCT NOT ON COMMISSIONS - NAP REPORT'          
                          WS-DISP-GROUP GGIACCOUNT                              
                  DISPLAY '******************************************'          
                  MOVE GNAP-REP-NAME TO PR1-REP-NAME                            
                  GO TO GET-AGENT-NAME1-EXIT.                                   
                                                                                
      *%   OBTAIN FIRST WITHIN GRACCT-COMP                                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE GGIGROUP-NUMBER TO WS-DISP-GROUP                         
                  DISPLAY '******************************************'          
                  DISPLAY '1ST RECORD NOT FOUND ON COMMISSIONS-NAP REP'         
                          WS-DISP-GROUP GGIACCOUNT                              
                  DISPLAY '******************************************'          
                  MOVE GNAP-REP-NAME TO PR1-REP-NAME                            
                  GO TO GET-AGENT-NAME1-EXIT.                                   
                                                                                
       CHECK-AGENT-NAME1.                                                       
                                                                                
           IF COMP-REASON     OF GWCORCOMP  =  WS-COMP-REASON-F AND             
              COMP-TYPE       OF GWCORCOMP  =  WS-COMP-TYPE     AND             
              COMP-DISP       OF GWCORCOMP  =  WS-COMP-DISP-P   AND             
              COMP-AMT        OF GWCORCOMP  >  +0                               
              MOVE GROUP-REP  OF GWCORCOMP  TO GNUM-REP                         
           ELSE                                                                 
              GO TO GET-NEXT-AGENT-NAME1.                                       
                                                                                
           CALL 'GNUMTABL'    USING  GNUM-TABLE                                 
                                     GNUM-REP                                   
                                     GNUM-RETURN.                               
                                                                                
           IF (GNUM-RETURN-1-5 EQUAL GNUM-REP)                                  
              MOVE SPACES TO GNUM-RETURN.                                       
                                                                                
           MOVE GNUM-RETURN TO PR1-REP-NAME.                                    
           GO TO GET-AGENT-NAME1-EXIT.                                          
                                                                                
       GET-NEXT-AGENT-NAME1.                                                    
                                                                                
      *%   OBTAIN NEXT WITHIN GRACCT-COMP                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 11 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               MOVE GGIGROUP-NUMBER TO WS-DISP-GROUP                            
               DISPLAY '******************************************'             
               DISPLAY 'GROUP/ACCT NOT ON COMMISSIONS - NAP REPORT'             
                        WS-DISP-GROUP GGIACCOUNT                                
               DISPLAY '******************************************'             
               MOVE GNAP-REP-NAME TO PR1-REP-NAME                               
               GO TO GET-AGENT-NAME1-EXIT.                                      
                                                                                
           GO TO CHECK-AGENT-NAME1.                                             
                                                                                
       GET-AGENT-NAME1-EXIT.                                                    
           EXIT.                                                                
                                                                                
       GET-AGENT-NAME2.                                                         
                                                                                
MUNCAN     MOVE GGIGROUP-NUMBER    TO WS-GROUP-NUM-5.                           
MUNCAN     MOVE WS-GROUP-NUM-7     TO GROUP-NUMBER  OF GWCORGRACCT.             
      *    MOVE GGIGROUP-NUMBER    TO GROUP-NUMBER  OF GWCORGRACCT.             
           MOVE GGIACCOUNT         TO GR-ACCOUNT    OF GWCORGRACCT.             
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 12 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE GGIGROUP-NUMBER TO WS-DISP-GROUP                         
                  DISPLAY '******************************************'          
                  DISPLAY 'GROUP/ACCT NOT ON COMMISSIONS - TERM REPORT'         
                          WS-DISP-GROUP GGIACCOUNT                              
                  DISPLAY '******************************************'          
                  MOVE GNAP-REP-NAME TO PR1-REP-NAME                            
                  GO TO GET-AGENT-NAME1-EXIT.                                   
                                                                                
      *%   OBTAIN FIRST WITHIN GRACCT-COMP                                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 13 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  DISPLAY '******************************************'          
                  MOVE GGIGROUP-NUMBER TO WS-DISP-GROUP                         
                  DISPLAY '1ST REC NOT ON COMMISSIONS - TERM REPORT'            
                          WS-DISP-GROUP GGIACCOUNT                              
                  DISPLAY '******************************************'          
                  MOVE GNAP-REP-NAME TO PR2-REP-NAME                            
                  GO TO GET-AGENT-NAME1-EXIT.                                   
                                                                                
       CHECK-AGENT-NAME2.                                                       
                                                                                
           IF COMP-REASON     OF GWCORCOMP  =  WS-COMP-REASON-F AND             
              COMP-TYPE       OF GWCORCOMP  =  WS-COMP-TYPE     AND             
              COMP-DISP       OF GWCORCOMP  =  WS-COMP-DISP-P   AND             
              COMP-AMT        OF GWCORCOMP  >  +0                               
              MOVE GROUP-REP  OF GWCORCOMP  TO GNUM-REP                         
           ELSE                                                                 
              GO TO GET-NEXT-AGENT-NAME2.                                       
                                                                                
           CALL 'GNUMTABL'    USING  GNUM-TABLE                                 
                                     GNUM-REP                                   
                                     GNUM-RETURN.                               
                                                                                
           IF (GNUM-RETURN-1-5 EQUAL GNUM-REP)                                  
              MOVE SPACES TO GNUM-RETURN.                                       
                                                                                
           MOVE GNUM-RETURN TO PR2-REP-NAME.                                    
           GO TO GET-AGENT-NAME2-EXIT.                                          
                                                                                
       GET-NEXT-AGENT-NAME2.                                                    
                                                                                
      *%   OBTAIN NEXT WITHIN GRACCT-COMP                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 14 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               MOVE GGIGROUP-NUMBER TO WS-DISP-GROUP                            
               DISPLAY 'GROUP/ACCT NOT ON COMMISSIONS - TERM REPORT'            
                       WS-DISP-GROUP GGIACCOUNT                                 
               MOVE GNAP-REP-NAME TO PR2-REP-NAME                               
               GO TO GET-AGENT-NAME2-EXIT.                                      
                                                                                
           GO TO CHECK-AGENT-NAME2.                                             
                                                                                
       GET-AGENT-NAME2-EXIT.                                                    
           EXIT.                                                                
                                                                                
       PRINT-FINAL-TOTAL.                                                       
           IF LINE-COUNT-1 = +999                                               
              MOVE NOTHING-TO-REPORT TO PR1-PRINT-LINE                          
           ELSE                                                                 
              PERFORM REP-1-PAGE-BRK THRU REP-1-PAGE-BRK-X                      
              MOVE EOF-REPORT        TO PR1-PRINT-LINE.                         
           PERFORM PRINT-LINE-1      THRU PRINT-LINE-1-EXIT.                    
           PERFORM CLOSE-DLSWRITE-80 THRU CLOSE-DLSWRITE-80-EXIT.               
                                                                                
           IF LINE-COUNT-2 = +999                                               
              MOVE NOTHING-TO-REPORT TO PR2-PRINT-LINE                          
           ELSE                                                                 
              PERFORM REP-2-PAGE-BRK THRU REP-2-PAGE-BRK-X                      
              MOVE EOF-REPORT        TO PR2-PRINT-LINE.                         
           PERFORM PRINT-LINE-2      THRU PRINT-LINE-2-EXIT.                    
           PERFORM CLOSE-DLSWRITE-81 THRU CLOSE-DLSWRITE-81-EXIT.               
       PRINT-FINAL-TOTAL-X.                                                     
           EXIT.                                                                
                                                                                
       PRINT-HEADINGS-1.                                                        
           ADD +1              TO ACCUM-NAP.                                    
           ADD +1              TO PAGE-COUNT-1.                                 
           MOVE PR1-PRINT-LINE TO SAVE-PRINT-LINE.                              
                                                                                
           MOVE PAGE-COUNT-1         TO PR1-PAGE.                               
           MOVE PR1-HEADING-LINE-1   TO PR1-PRINT-LINE.                         
           PERFORM WRITE-LINE-1      THRU WRITE-LINE-1-EXIT.                    
                                                                                
           MOVE PR1-HEADING-LINE-2 TO PR1-PRINT-LINE.                           
           PERFORM WRITE-LINE-1    THRU WRITE-LINE-1-EXIT.                      
                                                                                
           MOVE PR1-HEADING-LINE-3 TO PR1-PRINT-LINE.                           
           PERFORM WRITE-LINE-1    THRU WRITE-LINE-1-EXIT.                      
                                                                                
           MOVE +4              TO LINE-COUNT-1.                                
           MOVE SAVE-PRINT-LINE TO PR1-PRINT-LINE.                              
           MOVE '0'             TO PRINT1-CC.                                   
                                                                                
       PRINT-HEADINGS-1-EXIT.                                                   
           EXIT.                                                                
                                                                                
       PRINT-HEADINGS-2.                                                        
           ADD +1              TO PAGE-COUNT-2.                                 
           MOVE PR2-PRINT-LINE TO SAVE-PRINT-LINE.                              
                                                                                
           MOVE PAGE-COUNT-2       TO PR2-PAGE.                                 
           MOVE PR2-HEADING-LINE-1 TO PR2-PRINT-LINE.                           
           PERFORM WRITE-LINE-2    THRU WRITE-LINE-2-EXIT.                      
                                                                                
           MOVE PR2-HEADING-LINE-2 TO PR2-PRINT-LINE.                           
           PERFORM WRITE-LINE-2    THRU WRITE-LINE-2-EXIT.                      
                                                                                
           MOVE PR2-HEADING-LINE-3 TO PR2-PRINT-LINE.                           
           PERFORM WRITE-LINE-2    THRU WRITE-LINE-2-EXIT.                      
                                                                                
           MOVE +4                 TO LINE-COUNT-2.                             
           MOVE SAVE-PRINT-LINE    TO PR2-PRINT-LINE.                           
           MOVE '0'                TO PRINT2-CC.                                
                                                                                
       PRINT-HEADINGS-2-EXIT.                                                   
           EXIT.                                                                
                                                                                
       PRINT-LINE-1.                                                            
           IF  LINE-COUNT-1 GREATER THAN PAGE-SIZE                              
               PERFORM PRINT-HEADINGS-1 THRU PRINT-HEADINGS-1-EXIT.             
                                                                                
           IF  PRINT1-CC EQUAL SPACES                                           
               ADD +1 TO LINE-COUNT-1                                           
           ELSE                                                                 
               IF  PRINT1-CC EQUAL '0'                                          
                   ADD +2 TO LINE-COUNT-1                                       
               ELSE                                                             
                   IF  PRINT1-CC EQUAL '-'                                      
                       ADD +3 TO LINE-COUNT-1.                                  
                                                                                
           PERFORM WRITE-LINE-1 THRU WRITE-LINE-1-EXIT.                         
           MOVE SPACES TO PR1-DATA.                                             
                                                                                
       PRINT-LINE-1-EXIT.                                                       
           EXIT.                                                                
                                                                                
       PRINT-LINE-2.                                                            
           IF  LINE-COUNT-2 GREATER THAN PAGE-SIZE                              
               PERFORM PRINT-HEADINGS-2 THRU PRINT-HEADINGS-2-EXIT.             
                                                                                
           IF  PRINT2-CC EQUAL SPACES                                           
               ADD +1 TO LINE-COUNT-2                                           
           ELSE                                                                 
               IF  PRINT2-CC EQUAL '0'                                          
                   ADD +2 TO LINE-COUNT-2                                       
               ELSE                                                             
                   IF  PRINT2-CC EQUAL '-'                                      
                       ADD +3 TO LINE-COUNT-2.                                  
                                                                                
           PERFORM WRITE-LINE-2 THRU WRITE-LINE-2-EXIT.                         
           MOVE SPACES          TO PRINT-LINE.                                  
                                                                                
       PRINT-LINE-2-EXIT.                                                       
           EXIT.                                                                
                                                                                
       WRITE-LINE-1.                                                            
           CALL 'DLSWRITE' USING PRINT-SYS020    PRINT-RTN80                    
                                 PR1-PRINT-LINE  PRINT-RECSIZE80                
                                 PRINT-BLKSIZE80 PRINT-FORMAT80                 
                                 PRINT-SYS020-COUNT.                            
       WRITE-LINE-1-EXIT.                                                       
           EXIT.                                                                
                                                                                
       WRITE-SUB-TOT-22.                                                        
           CALL 'DLSWRITE' USING PRINT-SYS020    PRINT-RTN80                    
                                 PRINT-LINE      PRINT-RECSIZE80                
                                 PRINT-BLKSIZE80 PRINT-FORMAT80                 
                                 PRINT-SYS020-COUNT.                            
       WRITE-SUB-TOT-22-EXIT.                                                   
           EXIT.                                                                
      *                                                                         
       CLOSE-DLSWRITE-80.                                                       
           MOVE +4 TO PRINT-RTN80.                                              
           CALL 'DLSWRITE' USING PRINT-SYS020    PRINT-RTN80                    
                                 PR1-PRINT-LINE  PRINT-RECSIZE80                
                                 PRINT-BLKSIZE80 PRINT-FORMAT80                 
                                 PRINT-SYS020-COUNT.                            
       CLOSE-DLSWRITE-80-EXIT.                                                  
           EXIT.                                                                
                                                                                
       WRITE-SUB-TOT-23.                                                        
           CALL 'DLSWRITE' USING PRINT-SYS021    PRINT-RTN81                    
                                 PRINT-LINE      PRINT-RECSIZE81                
                                 PRINT-BLKSIZE81 PRINT-FORMAT81                 
                                 PRINT-SYS021-COUNT.                            
       WRITE-SUB-TOT-23-EXIT.                                                   
           EXIT.                                                                
                                                                                
       WRITE-LINE-2.                                                            
           CALL 'DLSWRITE' USING PRINT-SYS021    PRINT-RTN81                    
                                 PR2-PRINT-LINE  PRINT-RECSIZE81                
                                 PRINT-BLKSIZE81 PRINT-FORMAT81                 
                                 PRINT-SYS021-COUNT.                            
       WRITE-LINE-2-EXIT.                                                       
           EXIT.                                                                
                                                                                
       CLOSE-DLSWRITE-81.                                                       
           MOVE +4 TO PRINT-RTN81.                                              
           CALL 'DLSWRITE' USING PRINT-SYS021    PRINT-RTN81                    
                                 PR2-PRINT-LINE  PRINT-RECSIZE81                
                                 PRINT-BLKSIZE81 PRINT-FORMAT81                 
                                 PRINT-SYS021-COUNT.                            
       CLOSE-DLSWRITE-81-EXIT.                                                  
           EXIT.                                                                
                                                                                
       READ-RECORD.                                                             
                                                                                
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                GNAPREC                                         
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
       READ-RECORD-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *                                                                         
       READ-GMASTER.                                                            
      * VOCOMM VCM/GIPSY                                                        
      *    *----------------------------------------------------------*         
      *    * READ VCM OR GIPSY MASTER FOR IT                                    
      *    *----------------------------------------------------------*         
      *  READ KEYED (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'READ KEYED'       TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE GNAP-GROUP         TO VGWI-GROUP.                               
           MOVE GNAP-ACCOUNT       TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
GNE        CALL  VOGPWRA7    USING  VOGPWRAP-PROTOCOL                           
GNE                                 VOGPW-DATA-RECORD.                          
           IF  VGWO-RET-CODE = '00'                                             
GNE            MOVE VOGPW-DATA-RECORD TO GMASTER7                               
           ELSE                                                                 
              DISPLAY '**********************************************'          
              DISPLAY 'ERROR CALLING VOGPWRAP ' VGWO-RET-CODE ' GROUP '         
                GNAP-GROUP ' ACCT ' GNAP-ACCOUNT                                
              DISPLAY '**********************************************'.         
                                                                                
       READ-GMASTER-X.                                                          
           EXIT.                                                                
      *                                                                         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH                                            
CPYNME                               END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
