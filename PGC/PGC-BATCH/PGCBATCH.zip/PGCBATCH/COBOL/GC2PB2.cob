       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2PB2.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
      *    THIS PROGRAM DETERMINES WHETHER AN AGENT IS ANNUALIZED OR            
      *    NON-ANNUALIZED FOR A GIVEN GROUP ON A GIVEN EFFECTIVE DATE.          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *  HISTORY:                                                     *         
      *                                                               *         
      *  18NOV87  L HAMPTON     CREATION                              *         
      *  26FEB88  L HAMPTON     CHANGED TO SET UP DEFAULT BY AGENT OR *         
      *                         BROKER                                *         
      *                                                               *         
      *  NOV/90   M DRURY       RECOMPILE TO PICK UP NEW VERSION      *         
      *                         OF GWCORGRACCT RECORD CHANGED IN REL3 *         
      *                                                                         
      *  OCT/08   IBM                                                           
      *                         ENTERPRISE COMPILER UPGRADE                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCPB2          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-FIELDS.                                                           
           05  FILLER                       PIC X(32) VALUE                     
FXXTOK         '** GC2PB2 W-S STARTS HERE **'.                                  
           05  WS-LOW-DATE.                                                     
               10  FILLER                   PIC S9(3) COMP-3 VALUE +000.        
               10  FILLER                   PIC S9(3) COMP-3 VALUE +000.        
           05  WS-POL-YR-EFF-DATE.                                              
               10  WS-POL-YR-EFF-YEAR       PIC S9(3) COMP-3.                   
               10  WS-POL-YR-EFF-DAY        PIC S9(3) COMP-3.                   
           05  WS-PAY-BASIS-EFF-DATE.                                           
               10  FILLER                   PIC S9(3) COMP-3.                   
               10  FILLER                   PIC S9(3) COMP-3.                   
      *%   COPY IDMS SUBSCHEMA-NAMES.                                           
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
FXXTOK                                '** GC2PB2 W-S ENDS HERE **'.             
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  AGTNAME                          PIC X(8)  VALUE 'AGTNAME'.          
MAN02  01  DATA-SERVICE-VERB.                                                   
MAN02      COPY GARDSVRB.                                                       
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GAEDATSR                     PIC X(8)  VALUE 'GAEDATSR'.         
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CTRL.                                            
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
                                                                                
      * GWCORPAYBASIS                                                           
CPYNME     COPY GCIPAYB.                                                        
                                                                                
MAN02 *%   COPY IDMS GWGCRAGT.                                                  
MAN02  COPY EAGNFILE.                                                           
      /                                                                         
      * GWCORGPB-RECORD                                                         
CPYNME     COPY GCRGPB.                                                         
MAN02  01  ICBM.                                                                
MAN02      COPY ICBM.                                                           
      /                                                                         
       PROCEDURE DIVISION USING DBLINK-SUBSCHEMA-CONTROL                        
                                DBLINK-RECORD-SET-KEYS                          
                                DBLINK-CURSOR-CODES                             
                                GWCORGRACCT                                     
                                GWCORAGENT                                      
                                GWCORPAYBASIS                                   
FXXTOK                          AGENT-NAME-FILE                                 
                                GWCORGPB-RECORD                                 
                                ICBM.                                           
                                                                                
FXXTOK     MOVE 'GC2PB2'        TO FCCSPL-CURR-PGM                              
                                   ICBM-PROGRAM-NAME.                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       MAINLINE.                                                                
                                                                                
*******    COPY IDMS GET-AGENT-PAYMENT-BASIS.                                   
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00006400
      * THIS IS A COMMON ROUTINE.  YOU MUST RE-COMPILE ALL PROGRAMS   * 00006500
      * USING IT.                                                     * 00006600
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00006800
                                                                        00006900
       100-MAINLINE.                                                    00006902
                                                                        00006903
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00006910
      * DETERMINE THE EFFECTIVE DATE OF THE POLICY YEAR IN WHICH      * 00006920
      * THIS TRANSACTION IS EFFECTIVE.                                * 00006930
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00006940
                                                                        00006950
           MOVE ZERO TO GWCOEGPB-RETURN-CODE.                           00006960
                                                                        00006970
           IF RENEWAL-EFFECTIVE-DATE EQUAL TO WS-LOW-DATE               00007000
           THEN                                                         00007100
               MOVE GWCOEGPB-ACCT-EFF-DATE TO WS-POL-YR-EFF-DATE        00007200
           ELSE                                                         00007300
               MOVE RENEWAL-EFFECTIVE-DATE TO WS-POL-YR-EFF-DATE        00007400
               MOVE GWCOEGPB-TRANS-EFF-YEAR TO WS-POL-YR-EFF-YEAR.      00007500
                                                                        00007600
           IF GWCOEGPB-TRANS-EFF-DATE LESS THAN WS-POL-YR-EFF-DATE      00007700
           THEN                                                         00007800
               SUBTRACT +1 FROM WS-POL-YR-EFF-YEAR.                     00007900
                                                                        00008000
           IF WS-POL-YR-EFF-DATE LESS THAN GWCOEGPB-ACCT-EFF-DATE       00008100
           THEN                                                         00008200
               MOVE GWCOEGPB-ACCT-EFF-DATE TO WS-POL-YR-EFF-DATE.       00008300
                                                                        00008400
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00009300
      *  GET AGENT PAYMENT STATUS EFFECTIVE ON THE LATER OF THE       * 00009400
      *  AGENT START DATE OR THE POLICY YEAR EFFECTIVE DATE.          * 00009500
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 00009600
                                                                        00009700
           IF GWCOEGPB-AGENT-START-DATE GREATER THAN                    00010800
              WS-POL-YR-EFF-DATE                                        00010900
           THEN                                                         00011000
               MOVE GWCOEGPB-AGENT-START-DATE TO                        00011100
                    WS-PAY-BASIS-EFF-DATE                               00011200
           ELSE                                                         00011300
               MOVE WS-POL-YR-EFF-DATE TO WS-PAY-BASIS-EFF-DATE.        00011400
                                                                        00011500
           MOVE GWCOEGPB-AGENT-CODE TO AGENT-NUMBER.                    00011510
      *%   OBTAIN CALC GWCORAGENT                                       00011520
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  PERFORM 150-SET-UP-DEFAULT THRU 150-EXIT                      
                  GO TO 100-SET-UP-PAY-BASIS.                           00011560
                                                                        00011570
      *%   OBTAIN FIRST GWCORPAYBASIS WITHIN AGENT-PAYBASIS             00011600
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                        00011830
                                                                        00011900
           PERFORM 200-SEARCH-FOR-PAY-BASIS THRU 200-EXIT               00012000
               UNTIL DB-END-OF-SET                                      00012200
               OR PAY-BASIS-EFF-DATE NOT GREATER THAN                   00012300
                  WS-PAY-BASIS-EFF-DATE.                                00012400
                                                                        00012401
           IF DB-END-OF-SET                                             00012410
           THEN                                                         00012420
               PERFORM 150-SET-UP-DEFAULT THRU 150-EXIT.                        
                                                                        00012500
       100-SET-UP-PAY-BASIS.                                            00012510
                                                                        00012520
           IF PAY-BASIS-IND EQUAL TO 'F'                                00012600
           THEN                                                         00012700
               MOVE 'A' TO GWCOEGPB-AGENT-PAY-BASIS-FY                  00012800
               MOVE 'N' TO GWCOEGPB-AGENT-PAY-BASIS-RN                  00012810
           ELSE                                                         00012900
               IF PAY-BASIS-IND EQUAL TO 'Y'                            00013000
               THEN                                                     00013100
                   MOVE 'A' TO GWCOEGPB-AGENT-PAY-BASIS-FY              00013110
                   MOVE 'A' TO GWCOEGPB-AGENT-PAY-BASIS-RN              00013120
               ELSE                                                     00013800
                   MOVE 'N' TO GWCOEGPB-AGENT-PAY-BASIS-FY              00013810
                   MOVE 'N' TO GWCOEGPB-AGENT-PAY-BASIS-RN.             00013820
                                                                        00013900
           GO TO 300-EOJ-ROUTINE.                                       00013920
                                                                        00013930
       100-EXIT.                                                        00013940
           EXIT.                                                        00013950
      /                                                                 00014200
       150-SET-UP-DEFAULT.                                              00014300
                                                                        00014400
           MOVE GWCOEGPB-AGENT-NUMBER TO AGT-CODE.                      00011510
           MOVE ZERO TO AGT-ACCOUNT.                                            
MAN02 *%   OBTAIN CALC GWGCRAGT                                         00011520
MAN02      PERFORM 9006-OBTAIN-AGTNAME                                          
MAN02         THRU 9006-OBTAIN-AGTNAME-EXIT                                     
MAN02          IF DB-REC-NOT-FOUND                                              
                  MOVE ZERO TO AGT-MLI-CONTRACT-CLASS.                  00011540
                                                                        00011570
           IF AGT-MLI-CONTRACT-CLASS EQUAL TO +1 OR +61                 00011540
           THEN                                                                 
               MOVE 'F' TO PAY-BASIS-IND                                00011540
           ELSE                                                                 
               MOVE 'Y' TO PAY-BASIS-IND.                               00011540
                                                                        00014800
           MOVE +4  TO GWCOEGPB-RETURN-CODE.                            00011550
                                                                        00014800
       150-EXIT.                                                        00014900
           EXIT.                                                        00015000
                                                                        00015100
      /                                                                 00014200
       200-SEARCH-FOR-PAY-BASIS.                                        00014300
                                                                        00014400
      *%   OBTAIN NEXT GWCORPAYBASIS WITHIN AGENT-PAYBASIS              00014500
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                        00014700
                                                                        00014800
       200-EXIT.                                                        00014900
           EXIT.                                                        00015000
                                                                        00015100
*******  MSEND                                                                  
                                                                                
      /                                                                         
       300-EOJ-ROUTINE.                                                         
                                                                                
           GOBACK.                                                              
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
MAN02                                                                           
MAN02  9006-OBTAIN-AGTNAME.                                                     
MAN02      MOVE AGTNAME TO LOGICAL-RECORD-NAME.                                 
MAN02      CALL GAEDATSR USING OBTAIN-KEYED                                     
MAN02                          AGENT-NAME-FILE                                  
MAN02                          ICBM.                                            
           DISPLAY 'PROGRAM-LINKAGE-STATUS: ' PROGRAM-LINKAGE-STATUS.           
MAN02      IF KEYED-LR-NOT-FOUND                                                
MAN02          MOVE '0326' TO ERROR-STATUS                                      
MAN02      ELSE                                                                 
MAN02          MOVE ZEROS TO ERROR-STATUS                                       
MAN02      END-IF.                                                              
MAN02  9006-OBTAIN-AGTNAME-EXIT.                                                
MAN02      EXIT.                                                                
