       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VOAGX.                                                 
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *AUTHOR.        RLKNAUD.                                                  
      *DATE-WRITTEN.  JUNE 2005.                                                
      *                                                                         
      ******************************************************************        
      *                                                                         
      *   COMMISSIONS SYSTEM                                                    
      *   HUB VO COMMISSIONS PROJECT                                            
      *                                                                         
      *   HUB:  AGENT FILE AND PAY BASIS DATA EXTRACT/MERGE                     
      *         (VOCOMM AGT PAYBASIS)                                           
      *                                                                         
      *   THIS PROGRAM READS THE COMMISSIONS DATABASE AND CREATES               
      *   A PAYBASIS EXTRACT FILE.                                              
      *                                                                         
      *   CALLING PROGRAM:  NONE                                                
      *                                                                         
      *   CALLED PROGRAM :  DLSWRITE                                            
      *                                                                         
      *   COPYBOOKS:                                                            
      *       PAYBXTR                                                           
      *       SUBSCHEMA-CONTROL                                                 
      *       GWCORAGENT                                                        
      *       GWCORPAYBASIS                                                     
      *                                                                         
      *   INPUT  - COMMISSIONS DATABASE                                         
      *             RECORDS: GWCORAGENT                                         
      *                      GWCORPAYBASIS                                      
      *                                                                         
      *   OUTPUT - A FILE OF EXTRACTED COMMISSIONS PAY BASIS DATA.              
      *                                                                         
      *   DESCRIPTION:                                                          
      *     USE THE GWCORAGENT RECORD AS THE DRIVER.                            
      *     READ GWCORAGENT UNTIL ALL GWCORAGENT RECORDS HAVE BEEN READ.        
      *     FOR EACH GWCORAGENT, READ ALL THE GWCORPAYBASIS RECORDS             
      *     THAT BELONG TO IT.                                                  
      *     FOR EACH GWCORPAYBASIS RECORD, CHECK IF THE                         
      *     PAY-BASIS-EFF-DATE IS THE SAME AS THE PAY-BASIS-END-DATE.           
      *     IF THE PAY-BASIS-EFF-DATE IS THE SAME AS THE                        
      *     PAY-BASIS-END-DATE, SKIP THIS RECORD.                               
      *     IF THE PAY-BASIS-EFF-DATE IS NOT THE SAME AS THE                    
      *     PAY-BASIS-END-DATE (I.E., PAY-BASIS-EFF-DATE <                      
      *     PAY-BASIS-END-DATE), WRITE AN OUTPUT EXTRACT RECORD                 
      *     IN THE PAYBXTR FILE.                                                
      *                                                                         
      ******************************************************************        
      *                                                                         
      *                                                                         
      *                   C H A N G E   L O G                                   
      *_________________________________________________________________        
      *                                                                         
      *   10/03/2008 - ECU - UPGRADED IN ENTERPRISE COMPILER                    
      *                                                                         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVOAGTX          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
      *                                                                         
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *FILE SECTION.                                                            
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
      *                                                                         
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-DATA.                                                             
FXXTOK     05  WS-PROGRAM-ID             PIC X(08)  VALUE 'GC2VOAGX'.           
           05  SNAPAID                   PIC X(08)  VALUE 'SNAPAID'.            
           05  WS-GWCORAGENT-EOF         PIC X.                                 
           05  WS-GWCORPAYBASIS-EOF      PIC X.                                 
           05  WS-AGENT-NUMBERX          PIC X(6).                              
           05  WS-AGENT-NUMBER  REDEFINES WS-AGENT-NUMBERX                      
                                         PIC 9(6).                              
                                                                                
       01  DLSWRITE-PARAMETERS.                                                 
           05  DLSW-SYS020      PIC X(6)          VALUE 'SYS020'.               
           05  DLSW-RET-CODE    PIC S9    COMP-3.                               
           05  DLSW-REC-SIZE    PIC 9(5)          VALUE 80.                     
           05  DLSW-BLK-SIZE    PIC 9(5)          VALUE 27920.                  
           05  DLSW-REC-FMT     PIC XX            VALUE 'FB'.                   
           05  DLSW-REC-CNT     PIC S9(7) COMP-3  VALUE +0.                     
                                                                                
      *---------------------------------------------------------------*         
      *    OUTPUT                                                               
      *---------------------------------------------------------------*         
                                                                                
      *01  PAYBASIS-EXTRACT.                                                    
           COPY PAYBXTR.                                                        
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *          DATABASE -  RECORD DESCRIPTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORAGENT                      '.                                  
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORPAYBASIS                   '.                                  
      * GWCORPAYBASIS                                                           
CPYNME     COPY GCIPAYB.                                                        
                                                                                
       01  WS-ENDS.                                                             
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2VOAGX W-S ENDS HERE   **'.                                
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2VOAGX'         TO FCCSPL-CURR-PGM.                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
      *****************************************************************         
      *                 PROGRAM MAIN                                  *         
      *****************************************************************         
                                                                                
       0000-MAIN.                                                               
FXXTOK     DISPLAY 'START OF GC2VOAGX PROGRAM'.                                 
                                                                                
FXXTOK     MOVE 'GC2VOAGX' TO PROGRAM-NAME.                                     
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2VOAGX' TO PROGRAM-NAME.                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   READY GW-COMP-AREA1    USAGE-MODE IS RETRIEVAL.                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           PERFORM 1000-INITIALIZATION                                          
              THRU 1000-EXIT.                                                   
                                                                                
           PERFORM 2000-PROCESS-GWCORAGENT THRU 2000-EXIT                       
                   UNTIL WS-GWCORAGENT-EOF = 'Y'.                               
                                                                                
           MOVE +4                     TO DLSW-RET-CODE.                        
           CALL 'DLSWRITE'                USING DLSW-SYS020                     
                                                DLSW-RET-CODE                   
                                                PAYBASIS-EXTRACT                
                                                DLSW-REC-SIZE                   
                                                DLSW-BLK-SIZE                   
                                                DLSW-REC-FMT                    
                                                DLSW-REC-CNT.                   
                                                                                
FXXTOK     DISPLAY 'END OF GC2VOAGX PROGRAM'.                                   
           STOP RUN.                                                            
                                                                                
       0000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *-------------------------------------------------                        
       1000-INITIALIZATION.                                                     
      *-------------------------------------------------                        
           MOVE 'N'                 TO WS-GWCORAGENT-EOF.                       
      *%   OBTAIN FIRST GWCORAGENT WITHIN GW-COMP-AREA1                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 DISPLAY 'ERROR - EOF READING FIRST AGENT RECORD'               
                 MOVE 'Y' TO WS-GWCORAGENT-EOF.                                 
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       2000-PROCESS-GWCORAGENT.                                                 
      *-----------------------------------------------------------------        
           MOVE 'N' TO WS-GWCORPAYBASIS-EOF.                                    
      *%   OBTAIN FIRST GWCORPAYBASIS WITHIN AGENT-PAYBASIS                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE 'Y' TO WS-GWCORPAYBASIS-EOF.                             
                                                                                
           PERFORM 2100-PROCESS-GWCORPAYBASIS THRU 2100-EXIT                    
                   UNTIL WS-GWCORPAYBASIS-EOF = 'Y'.                            
                                                                                
      *%   OBTAIN NEXT  GWCORAGENT WITHIN GW-COMP-AREA1                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                 MOVE 'Y' TO WS-GWCORAGENT-EOF.                                 
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       2100-PROCESS-GWCORPAYBASIS.                                              
      *-----------------------------------------------------------------        
           IF PAY-BASIS-EFF-DATE = PAY-BASIS-END-DATE                           
              NEXT SENTENCE                                                     
           ELSE                                                                 
              PERFORM 3000-WRITE-PAYBXTR THRU 3000-EXIT                         
           END-IF.                                                              
                                                                                
      *%   OBTAIN NEXT GWCORPAYBASIS WITHIN AGENT-PAYBASIS                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  MOVE 'Y' TO WS-GWCORPAYBASIS-EOF.                             
                                                                                
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *-----------------------------------------------------------------        
       3000-WRITE-PAYBXTR.                                                      
      *-----------------------------------------------------------------        
           MOVE SPACES TO PAYBASIS-EXTRACT.                                     
           MOVE AGENT-NUMBER           TO WS-AGENT-NUMBERX.                     
           MOVE WS-AGENT-NUMBER        TO PBXT-AGENT-CODE.                      
           MOVE PAY-BASIS-EFF-YEAR     TO PBXT-EFF-YEAR.                        
           MOVE PAY-BASIS-EFF-DAY      TO PBXT-EFF-DAY.                         
           MOVE PAY-BASIS-IND          TO PBXT-PAY-BASIS-IND.                   
                                                                                
           CALL 'DLSWRITE'                USING DLSW-SYS020                     
                                                DLSW-RET-CODE                   
                                                PAYBASIS-EXTRACT                
                                                DLSW-REC-SIZE                   
                                                DLSW-BLK-SIZE                   
                                                DLSW-REC-FMT                    
                                                DLSW-REC-CNT.                   
                                                                                
       3000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *=================================================================        
      *                                                                         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
      *****************************                                             
      *   END OF LISTING GWVOAGTX *                                             
      *****************************                                             
