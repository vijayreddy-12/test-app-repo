                                                                                
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2DAT.                                                      
      *AUTHOR.   J SASSO.                                                       
      *****************************************************************         
      *                                                                         
      *=================================================================        
      * SOURCE CODE FOR THIS PROGRAM LIVES IN LIBRARY TYPE CIIB24               
      *=================================================================        
      *                                                                         
      * DESCRIPTION:                                                            
      *     THIS MODULE IS TO GENERATE AN EXTRACT FOR TOTALS                    
      *                                                                         
      * HISTORY:                                                                
      *     OCT.02.2002 - JACKIE SASSO (CREATION)                               
      *                                                                         
      *     OCT.03.2008 - IBM - ENTERPRISE COMPILER UPGRADE                     
      *     MAR.04.2013 - KAVITHA     - TL 188979                               
      *****************************************************************         
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCDAT          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-START.                                                            
           05  FILLER                  PIC  X(32)     VALUE                     
FXXTOK         '** GC2DAT W-S STARTS HERE **'.                                  
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  GWCDUMP                 PIC X(8)       VALUE 'GWCDUMP'.          
           05  GAEDATSR                PIC X(8)       VALUE 'GAEDATSR'.         
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
       01  WS-VERB                     PIC X(16)      VALUE SPACES.             
                                                                                
       01  WTL-SUB                   PIC S9(4)      VALUE +0   COMP.            
                                                                                
       01  WS-END-BYTE-X             PIC X(1)       VALUE SPACES.               
                                                                                
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH   PIC S9(3)      VALUE +133  COMP-3.         
               10  WTL-MESS-CC       PIC X(1)       VALUE SPACES.               
               10  WTL-MESS-TEXT     PIC X(132)     VALUE SPACES.               
           05  WTL-FLAG              PIC X(1)       VALUE 'B'.                  
           05  WTL-REPLY             PIC X(3)       VALUE 'NO '.                
           05  WTL-REPLY-AREA        PIC X(80)      VALUE SPACES.               
                                                                                
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                 PIC X(80)      VALUE                       
FXXTOK         'GC2DAT - PROGRAM BEING ABNORMALLY TERMINATED        '.          
                                                                                
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY OCCURS 1 TIMES.                                
               10  WTL-MESSAGE       PIC X(80).                                 
                                                                                
       01  WS-TOTAL-PREM            PIC S9(9)V99   VALUE ZEROES.                
                                                                                
       01  WS-TOTAL-COMP            PIC S9(9)V99   VALUE ZEROES.                
                                                                                
       01  WS-RECORD-COUNT          PIC 9(11)      VALUE ZEROES.                
                                                                                
       01  INPUT-RECORD.                                                        
           05  I-SYS-CODE           PIC 99         VALUE ZEROES.                
           05  I-GROUP              PIC S9(15)     VALUE ZEROES.                
           05  I-AGENT-CODE         PIC S9(6)      VALUE ZEROES.                
           05  I-BRANCH-CODE        PIC S9(5)      VALUE ZEROES.                
           05  I-LINE-OF-BUSINESS   PIC S9(2)      VALUE ZEROES.                
           05  I-PROD-CODE          PIC S9(10)     VALUE ZEROES.                
           05  I-AGENT-SHARE        PIC S9(3)V99   VALUE ZEROES.                
           05  I-CASE-COUNT         PIC S9(11)     VALUE ZEROES.                
           05  I-PREM-AMT           PIC S9(9)V99   VALUE ZEROES.                
           05  I-PREM-PD-XS         PIC S9(7)V99   VALUE ZEROES.                
           05  I-COMP-AMT           PIC S9(7)V99   VALUE ZEROES.                
           05  I-LTD                PIC X          VALUE 'U'.                   
           05  I-POLICYHOLDER       PIC X(25)      VALUE SPACES.                
           05  FILLER               PIC X(24)      VALUE SPACES.                
                                                                                
       01  OUTPUT-RECORD.                                                       
           05  O-REC-TYPE           PIC X          VALUE 'T'.                   
           05  O-REC-COUNT          PIC 9(9)       VALUE ZEROES.                
           05  O-TOT-PREM-PAID      PIC S9(9)V99   VALUE ZEROES.                
           05  O-TOT-PREM-PAID-XS   PIC S9(9)V99   VALUE ZEROES.                
           05  O-TOT-COMM-PAID      PIC S9(9)V99   VALUE ZEROES.                
           05  FILLER               PIC X(92)      VALUE SPACES.                
                                                                                
      *----------------------------------------------------------------         
      *          DATASERVER RECORDS                                   *         
      *----------------------------------------------------------------         
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
       01  WS-ENDS.                                                             
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2DAT W-S ENDS HERE   **'.                                  
                                                                                
      ******************************************************************        
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
                                                                                
      ******************************************************************        
       000-MAINLINE.                                                            
                                                                                
FXXTOK     DISPLAY 'START OF GC2DAT PROGRAM'.                                   
                                                                                
           MOVE OBTAIN-FIRST TO WS-VERB.                                        
FXXTOK     MOVE 'GC2DAT' TO ICBM-PROGRAM-NAME.                                  
           MOVE LOW-VALUES TO LINKAGE-CONTROL.                                  
                                                                                
           PERFORM 100-READ-EXTRACT THRU 100-X.                                 
                                                                                
           PERFORM 200-PROCESS THRU 200-X                                       
              UNTIL LR-NOT-FOUND.                                               
                                                                                
           MOVE WS-TOTAL-PREM   TO O-TOT-PREM-PAID.                             
           MOVE WS-TOTAL-COMP   TO O-TOT-COMM-PAID.                             
           MOVE WS-RECORD-COUNT TO O-REC-COUNT.                                 
           MOVE 'T'             TO O-REC-TYPE.                                  
           MOVE ZEROES          TO O-TOT-PREM-PAID-XS.                          
                                                                                
           PERFORM 300-WRITE THRU 300-X.                                        
                                                                                
      *--------------------------------------------------------------           
      *   END OF PROGRAM LOGIC                                                  
      *--------------------------------------------------------------           
           MOVE SPACES      TO    LOGICAL-RECORD-NAME.                          
           CALL GAEDATSR    USING FINISH-LR                                     
                                  OUTPUT-RECORD                                 
                                  ICBM.                                         
FXXTOK     DISPLAY 'END OF GC2DAT PROGRAM'.                                     
                                                                                
       000-MAINLINE-X.                                                          
           STOP RUN.                                                            
                                                                                
      *-----------------------------------------------------------------        
       100-READ-EXTRACT.                                                        
                                                                                
           MOVE 'CARD-DATA-010' TO LOGICAL-RECORD-NAME.                         
                                                                                
           CALL GAEDATSR USING WS-VERB                                          
                               INPUT-RECORD                                     
                               ICBM.                                            
                                                                                
           IF NOT LR-STATUS-OK AND NOT LR-NOT-FOUND                             
              DISPLAY 'STATUS: ' ICBM,                                          
                  '    DATA = ', INPUT-RECORD                                   
              MOVE +1 TO WTL-SUB                                                
              GO TO 9999-ABANDON-SHIP.                                          
                                                                                
           MOVE OBTAIN-NEXT TO WS-VERB.                                         
                                                                                
       100-X.                                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
       200-PROCESS.                                                             
                                                                                
      *  CALCULATE RECORD COUNT AND EXTRACT TOTALS                              
           ADD +1 TO WS-RECORD-COUNT.                                           
           ADD I-PREM-AMT TO WS-TOTAL-PREM.                                     
           ADD I-COMP-AMT TO WS-TOTAL-COMP.                                     
                                                                                
           PERFORM 100-READ-EXTRACT THRU 100-X.                                 
                                                                                
       200-X.                                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
       300-WRITE.                                                               
                                                                                
           MOVE 'PRINT-DATA-020' TO LOGICAL-RECORD-NAME.                        
                                                                                
           CALL GAEDATSR     USING  STORE-LR                                    
                                    OUTPUT-RECORD                               
                                    ICBM.                                       
                                                                                
           DISPLAY OUTPUT-RECORD.                                               
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                        
           END-IF.                                                              
                                                                                
           INITIALIZE OUTPUT-RECORD.                                            
                                                                                
       300-X.                                                                   
           EXIT.                                                                
      *-----------------------------------------------------------------        
                                                                                
       9999-ABANDON-SHIP.                                                       
                                                                                
           MOVE WTL-MESSAGE (WTL-SUB)     TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
           MOVE WTL-MESSAGE (+1)          TO WTL-MESS-TEXT.                     
           CALL 'WTL' USING  WTL-MESSAGES                                       
                             WTL-FLAG                                           
                             WTL-REPLY                                          
                             WTL-REPLY-AREA.                                    
           CALL GWCDUMP USING ICBM                                              
                              GWRDUMP.                                          
      *-----------------------------------------------------------------        
