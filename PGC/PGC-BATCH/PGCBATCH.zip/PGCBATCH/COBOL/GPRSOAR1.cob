       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. GPRSOAR1.                                                    
      *This program has been examined/renovated for Year 2000 compliance.       
      *DATE-WRITTEN.  SEP-89                                                    
      *DATE-COMPILED.                                                           
      *REMARKS.                                                                 
      *                  REPORT FOR HEAD-OFFICE.                                
      *                     REPORT-NUMBER 1.                                    
      *                     SORT ORDER   GROUP,ACCOUNT.                         
      *                                                                         
      *                                                                         
      *          SHOWS ALL GROUPS FOR WHICH A LAPSE NOTICE HAS BEEN             
      *          PRODUCED AND CLAIMS HAVE BEEN SUSPENDED.                       
      *          THIS MODULE INTERIGATES REPORT TYPE "H" AND IF TYPE            
      *          "B" CALLS GROUP OFFICE OVERDUE PREMIUM REPORT                  
      *          MODULE.                                                        
      *                                                                         
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *  SEP-89   MARCUS DRURY   --  CREATION.                        *         
      *                                                               *         
      *  JAN/90   MARCUS DRURY   -  ADD LOGIC TO SHOW IF REPORT IS    *         
      *                             FOR 'ALPHA' OR OMEGA/CSP'         *         
      *                             ADD A PRINT FLD TO TITLE LINE.    *         
      *  JUN/98   J ELKINS       -  ADD ACCOUNT MANAGER TO THE DETAIL *         
      *                             LINE OF THE REPORT FOR THE        *         
      *                             ALPHA/RGO CHANGES                 *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *                                                               *         
      *                                                               *         
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77  FILLER                                   PIC X(50) VALUE             
           '***** START OF WORKING STORAGE FOR GPRSOAR1 *****'.                 
       77  FIRST-SW               VALUE 0           PIC 9.                      
       77  HOLD-PCODE             VALUE 'A'         PIC X.                      
       01  FILLER  COMP.                                                        
               05  WS-LINE-COUNT VALUE +0           PIC S9(4).                  
               05  WS-LNE-CNT    VALUE +99          PIC S9(4).                  
       01  FILLER.                                                              
           03  WS-PAGE-NUMBER    VALUE +0    COMP-3 PIC S9(5).                  
           03  WS-QDATE-AC       VALUE 'AC'         PIC X(2).                   
           03  WS-NEW            VALUE 'N'          PIC X(1).                   
           03  WS-NEW-MSGE                          PIC X(20)                   
               VALUE 'NEW/NOT SUSP        '.                                    
           03  WS-HOLD-DATA                        PIC X(133).                  
           03  FORM-STANDARD-ONCE  VALUE '91'      PIC X(2).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *            NO OF GROUP OFFICES AND TOTALS                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-TOT-LAPSE-NOTICES   VALUE +0     PIC S9(7).                   
           03  WS-CURR-STATUS.                                                  
               05  WST-PREM-AMT   COMP-3           PIC S9(7)V99.                
               05  WST-CURR-PREM  COMP-3           PIC S9(7)V99.                
               05  WST-TOT-PREM   COMP-3           PIC S9(7)V99.                
                                                                                
       01  PRINT-SYS033           PIC X(06) VALUE 'SYS033'.                     
       01  PRINT-SYS033-COUNT     PIC S9(7)  COMP-3  VALUE +0.                  
                                                                                
       01  WS-VARIABLES.                                                        
      *----------------------------------------------------------------*        
      *                                                                *        
      *                     REPORT HEADINGS                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-HEAD1.                                                        
               05  FILLER        VALUE 'GPRSOARR'    PIC X(8).                  
               05  FILLER        VALUE SPACES        PIC X(10).                 
               05  WS-HD1-PCODE  VALUE SPACES        PIC X(09).                 
               05  FILLER        VALUE SPACES        PIC X(13).                 
               05  FILLER                            PIC X(45)  VALUE           
           'HEAD OFFICE  - REPORT OF LAPSE NOTICES MAILED'.                     
               05  FILLER        VALUE SPACES        PIC X(7).                  
               05  FILLER        VALUE 'REPORT DATE' PIC X(12).                 
               05  WS-HD1-DATE                       PIC X(7).                  
               05  FILLER        VALUE SPACES        PIC X(9).                  
               05  FILLER        VALUE 'PAGE '       PIC X(5).                  
               05  WS-HD1-PAGE   VALUE ZEROS         PIC ZZZZ9.                 
           03  WS-HEAD2.                                                        
               05  FILLER        VALUE SPACES        PIC X(23).                 
               05  FILLER                            PIC X(79)  VALUE           
           'THE FOLLOWING GROUP ACCOUNTS ARE NOW IN ARREARS AND COVERAGE        
      -    ' HAS BEEN SUSPENDED'.                                               
           03  WS-HEAD3.                                                        
               05  FILLER        VALUE SPACES        PIC X(1).                  
               05  FILLER                            PIC X(89)  VALUE           
GNE     'OFFICE  GROUP     ACCT  BR       GROUP  NAME          ACCOUNT          
GNE   - ' OVERDUE      PREMIUM   '.                                             
               05  FILLER                            PIC X(38)  VALUE           
           'CURRENT         TOTAL      CLAIMS SUSP'.                            
           03  WS-HEAD4.                                                        
GNE            05  FILLER                            PIC X(88)  VALUE           
GNE     '         NUMBER     NO                                 MANAGER         
      - '  DATE DUE     AMOUNT    '.                                            
               05  FILLER                            PIC X(40)  VALUE           
           'PREMIUM DUE    PREMIUM DUE   EFFECT DATE'.                          
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   DETAIL LINE STRUCTURE                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-DETAIL1.                                                      
               05  FILLER                            PIC X(1).                  
               05  WSD-GRPO                          PIC X(5).                  
               05  FILLER                            PIC X(3).                  
GNE            05  WSD-GROUP                         PIC 9(7).                  
               05  FILLER                            PIC X(3).                  
               05  WSD-ACCT                          PIC X(3).                  
               05  FILLER                            PIC X(1).                  
               05  WSD-BRAN                          PIC X(5).                  
               05  FILLER                            PIC X(1).                  
               05  WSD-GRPNAME                       PIC X(24).                 
               05  FILLER                            PIC X(2).                  
               05  WSD-REP                           PIC 9(5).                  
               05  FILLER                            PIC X(5).                  
               05  WSD-OVDU-DATE                     PIC X(7).                  
               05  FILLER                            PIC X(2).                  
               05  WSD-PREM-AMT                      PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WSD-CURR-PREM                     PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WSD-TOT-PREM                      PIC Z,ZZZ,ZZZ.99-.         
               05  WSD-CLAIM.                                                   
                   07  FILLER                        PIC X(4).                  
                   07  WS-CLMSUS-DATE                PIC X(7).                  
                   07  FILLER                        PIC X(9).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  TOTAL LINE STRUCTURE                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-TOTAL1.                                                       
               05  WS-COMPANY-HD.                                               
                   07  FILLER                        PIC X(1).                  
                   07  WS-TOT-GRP                    PIC X(5).                  
                   07  FILLER                        PIC X(3).                  
                   07  WS-TOT-HD                     PIC X(7).                  
               05  FILLER                            PIC X(58).                 
               05  WS-TOT-PREM-AMT                   PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WS-TOT-CURR-PREM                  PIC Z,ZZZ,ZZZ.99-.         
               05  FILLER                            PIC X(1).                  
               05  WS-TOT-TOT-PREM                   PIC Z,ZZZ,ZZZ.99-.         
           03  WS-TOTAL2.                                                       
               05  FILLER                            PIC X(28)                  
                   VALUE '# OF LAPSE NOTICES MAILED   '.                        
               05  O-TOT-LAPSE-NOTICES               PIC Z,ZZZ,ZZ9.             
               05  FILLER           VALUE SPACES     PIC X(99).                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   REPORT END LITERIALS                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  WS-COMPANY-MSGE                       PIC X(14)                  
               VALUE 'COMPANY  TOTAL'.                                          
           03  WS-TOTAL-MSGE   VALUE '  TOTAL'         PIC X(7).                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 BUILDING NAME TRAILER  030                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *01  GMBNATR.                                                             
       COPY GMBNATR.                                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *               WORK AREA TO EXPAND GROUP NAME                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WS-NMADDR.                                                           
           03  WS-NAME-ADDR OCCURS 6 TIMES.                                     
               05  WS-NA-LN                          PIC X(30).                 
               05  FILLER                            PIC X(1).                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *          WORK DISK USED FOR SECOND COPY OF REPORT              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  WS-WORK-DISK.                                                        
           03  WS-WKD-LENGTH   VALUE +137 COMP SYNC  PIC S9(4).                 
           03  FILLER          VALUE LOW-VALUE       PIC X(2).                  
           03  WS-WKD-DATA.                                                     
               05  WS-WKD-CC                         PIC X(1).                  
               05  WS-WKD-AREA.                                                 
                   07  FILLER                        PIC X(132).                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     WORK DISK USED FOR ERROR OCCURRING GPRINTAL PROCESSING     *        
      *                                                                *        
      *----------------------------------------------------------------*        
GNE        COPY GERRREC7.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      FROM GIPSY PRINT FILE GROUP OFFICE ARREAR RECORD          *        
      *                                                                *        
      *----------------------------------------------------------------*        
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
       LINKAGE SECTION.                                                         
       01  ARR-RECORD.                                                          
GNE          COPY GGFOARR7.                                                     
       01  OVR-RECORD   REDEFINES ARR-RECORD.                                   
GNE          COPY GGFOOVE7.                                                     
      *----------------------------------------------------------------*        
      *                                                                *        
      *               FROM GPRINTAL DRIVER MODULE                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LSMISC-AREA.                                                         
           03  FILLER                                PIC X(4).                  
           03  LSM-HIDATE                            PIC X(4).                  
           03  LSM-STATDATE                          PIC X(4).                  
           03  LSM-PREMDATE                          PIC X(4).                  
           03  LSM-RESTART.                                                     
               05  LSR-RECTYPE                       PIC X(1).                  
               05  LSR-REPTYPE                       PIC X(1).                  
               05  LSR-GRPOFF                        PIC X(5).                  
               05  FILLER                            PIC X(7).                  
           03  FILLER                                PIC X(4).                  
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         PRINT PARAMETER COPY BOOK FOR SYS022 TO SYS029         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRPRINT.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         TAPE PARAMETER COPY BOOK FOR SYS011 AND SYS014         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRTPARM.                                                          
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             REPORT ACCUMULATOR COPY BOOK                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY  GPRACCUM.                                                          
                                                                                
       PROCEDURE DIVISION USING ARR-RECORD                                      
                                LSMISC-AREA                                     
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   INITIALIZE ROUTINE                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *    DISPLAY  '====>  GPRSOAR1   <====='.                                 
      *    READY TRACE.                                                         
           IF FIRST-SW                =      0                                  
               MOVE  1                TO     FIRST-SW                           
               MOVE  ARR-SRT-HO-PCODE TO     HOLD-PCODE.                        
                                                                                
           IF   ARR-TYPE              =      'H'                                
            AND ARR-REPORT            =      'A'                                
               GO TO INIT-ROUTINE.                                              
       UB-MODULE-CALL.                                                          
           CALL 'GPRSOOPR' USING OVR-RECORD                                     
                                 LSMISC-AREA                                    
                                 GPRPRINT                                       
                                 GPRTPARM                                       
                                 GPRACCUM.                                      
           GO TO END-OPERATIONS.                                                
       INIT-ROUTINE.                                                            
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-STANDARD-ONCE.                            
           CALL 'ZLINECT' USING WS-LINE-COUNT.                                  
           SUBTRACT +7 FROM WS-LINE-COUNT.                                      
           MOVE ZEROS TO WST-PREM-AMT                                           
                         WST-CURR-PREM                                          
                         WST-TOT-PREM.                                          
           CALL 'QDATE' USING WS-QDATE-AC                                       
                              LSM-HIDATE                                        
                              WS-HD1-DATE.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *       PROCESS TAPE RECORD READ FROM GIPSY PRINT FILE           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       REPORT1-PROCESSING.                                                      
           IF   ARR-SRT-HO-PCODE      =      HOLD-PCODE                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE  ARR-SRT-HO-PCODE TO     HOLD-PCODE                         
               PERFORM TITLE-ROUTINE-BGN THRU                                   
                       TITLE-ROUTINE-END.                                       
                                                                                
           IF   ARR-TYPE     NOT  =    'H'                                      
               GO TO END-OF-REPORT1.                                            
           IF   ARR-REPORT   NOT  =    'A'                                      
               GO TO END-OF-REPORT1.                                            
           IF   ARR-REPORT-NUMBER NOT = 1                                       
               GO TO END-OF-REPORT1.                                            
           MOVE SPACES TO WS-DETAIL1.                                           
           MOVE '0'    TO WS-WKD-CC.                                            
           MOVE ARR-GROUP TO WSD-GROUP.                                         
           MOVE ARR-ACCOUNT TO WSD-ACCT.                                        
           MOVE ARR-REP     TO WSD-REP.                                         
           CALL 'QDATE' USING WS-QDATE-AC                                       
                              ARR-OVERDATE                                      
                              WSD-OVDU-DATE.                                    
           MOVE ARR-OVERPREM TO WSD-PREM-AMT.                                   
           MOVE ARR-CURRPREM TO WSD-CURR-PREM.                                  
           MOVE ARR-TOTLPREM TO WSD-TOT-PREM.                                   
           MOVE ARR-GRPOFF   TO WSD-GRPO.                                       
           MOVE ARR-BRANCH   TO WSD-BRAN.                                       
           IF  ARR-GRPIND IS EQUAL TO WS-NEW THEN                               
               MOVE WS-NEW-MSGE TO WSD-CLAIM                                    
           ELSE                                                                 
               CALL 'QDATE' USING WS-QDATE-AC                                   
                                  ARR-SUSPDATE                                  
                                  WS-CLMSUS-DATE.                               
      *----------------------------------------------------------------*        
      *                                                                *        
      *      OBTAIN GROUP NAME FROM GIPSY MASTER TRAILER 030           *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE ARR-GROUP   TO E-GROUP.                                         
           MOVE ARR-ACCOUNT TO E-ACCT.                                          
           MOVE ARR-PCODE   TO E-PROD-CD.                                       
           MOVE '030' TO GBNTRIDENT.                                            
           MOVE SPACES TO E-CODE.                                               
GNE        CALL GZACCMT7 USING E-NORM                                           
GNE                              GMBNATR                                        
GNE                              E-CODE.                                        
           IF  E-CODE IS NOT EQUAL TO SPACES                                    
           OR  GBNTRIDENT IS EQUAL TO SPACES THEN                               
               PERFORM ERR-ROUTINE-BGN THRU                                     
                       ERR-ROUTINE-END                                          
               GO TO CONT-PROCESSING.                                           
GNE        CALL GZNAEXP7 USING GMBNATR                                          
GNE                              WS-NMADDR                                      
GNE                              E-CODE.                                        
           IF  E-CODE IS NOT EQUAL TO SPACES THEN                               
               PERFORM ERR-ROUTINE-BGN THRU                                     
                       ERR-ROUTINE-END                                          
               GO TO CONT-PROCESSING.                                           
           MOVE WS-NA-LN (1) TO WSD-GRPNAME.                                    
           MOVE WS-DETAIL1 TO WS-WKD-AREA.                                      
       CONT-PROCESSING.                                                         
      *    DISPLAY WS-DETAIL1 ' DETAIL ' WS-WKD-AREA ' WKD '.                   
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           PERFORM ACCUM-TOTALS-BGN THRU                                        
                   ACCUM-TOTALS-END.                                            
           CALL 'DLSREAD' USING  TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 ARR-RECORD                                     
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                           
               GO TO END-OF-REPORT1.                                            
           GO TO REPORT1-PROCESSING.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 PRODUCES SUMMARY TOTALS                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OF-REPORT1.                                                          
           MOVE SPACES TO WS-TOTAL1.                                            
           MOVE WS-COMPANY-MSGE TO WS-COMPANY-HD.                               
           MOVE WST-PREM-AMT TO WS-TOT-PREM-AMT.                                
           MOVE WST-CURR-PREM TO WS-TOT-CURR-PREM.                              
           MOVE WST-TOT-PREM TO WS-TOT-TOT-PREM.                                
           MOVE WS-TOTAL1 TO WS-WKD-AREA.                                       
           MOVE '-' TO WS-WKD-CC.                                               
           MOVE ZEROS TO WS-LNE-CNT.                                            
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE WS-TOT-LAPSE-NOTICES TO O-TOT-LAPSE-NOTICES.                    
           MOVE WS-TOTAL2 TO WS-WKD-AREA.                                       
           MOVE '-' TO WS-WKD-CC.                                               
           MOVE ZEROS TO WS-LNE-CNT.                                            
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           GO TO END-OPERATIONS.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             ROUTINE USED IN NORMAL PROCESSING                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-ROUTINE-BGN.                                                       
           IF  WS-WKD-CC IS EQUAL TO '1' THEN                                   
               MOVE +1 TO WS-LNE-CNT                                            
           ELSE                                                                 
               IF  WS-WKD-CC IS EQUAL TO ' ' THEN                               
                   ADD +1 TO WS-LNE-CNT                                         
                ELSE                                                            
                   IF  WS-WKD-CC IS EQUAL '0' THEN                              
                       ADD +2 TO WS-LNE-CNT                                     
                   ELSE                                                         
                       IF  WS-WKD-CC IS EQUAL TO '-' THEN                       
                           ADD +3 TO WS-LNE-CNT.                                
           IF  WS-LNE-CNT GREATER WS-LINE-COUNT THEN                            
               MOVE WS-WKD-DATA TO WS-HOLD-DATA                                 
               PERFORM TITLE-ROUTINE-BGN THRU                                   
                       TITLE-ROUTINE-END                                        
               MOVE WS-HOLD-DATA TO WS-WKD-DATA                                 
               MOVE '0' TO WS-WKD-CC                                            
               GO TO PRINT-ROUTINE-BGN.                                         
           CALL 'DLSWRITE' USING PRINT-SYS033,                                  
                                 PRINT-RETURN,                                  
                                 WS-WKD-DATA,                                   
                                 PRINT-RECSIZE,                                 
                                 PRINT-BLKSIZE,                                 
                                 PRINT-FORMAT,                                  
                                 PRINT-SYS033-COUNT.                            
       PRINT-ROUTINE-END.                                                       
           EXIT.                                                                
       ACCUM-TOTALS-BGN.                                                        
           ADD ARR-OVERPREM TO WST-PREM-AMT.                                    
           ADD ARR-CURRPREM TO WST-CURR-PREM.                                   
           ADD ARR-TOTLPREM TO WST-TOT-PREM.                                    
           ADD +1      TO WS-TOT-LAPSE-NOTICES.                                 
       ACCUM-TOTALS-END.                                                        
           EXIT.                                                                
       TITLE-ROUTINE-BGN.                                                       
           IF   HOLD-PCODE            =      'A'                                
               MOVE '  ALPHA  '       TO WS-HD1-PCODE                           
           ELSE                                                                 
               MOVE 'OMEGA/CSP'       TO WS-HD1-PCODE.                          
                                                                                
           ADD +1 TO ACCUM-LAPSE-MAIL.                                          
           ADD +1 TO WS-PAGE-NUMBER.                                            
           MOVE '1' TO WS-WKD-CC.                                               
           MOVE WS-PAGE-NUMBER TO WS-HD1-PAGE.                                  
           MOVE WS-HEAD1 TO WS-WKD-AREA.                                        
           MOVE ZERO     TO WS-LNE-CNT.                                         
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES TO WS-WKD-CC.                                            
           MOVE WS-HEAD2 TO WS-WKD-AREA.                                        
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE ZERO TO WS-WKD-CC.                                              
           MOVE WS-HEAD3 TO WS-WKD-AREA.                                        
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
           MOVE SPACES TO WS-WKD-CC.                                            
           MOVE WS-HEAD4 TO WS-WKD-AREA.                                        
           PERFORM PRINT-ROUTINE-BGN THRU                                       
                   PRINT-ROUTINE-END.                                           
       TITLE-ROUTINE-END.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *            WRITE OUT AN ERROR RECORD ON SYS011                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       ERR-ROUTINE-BGN.                                                         
           CALL 'DLSWRITE' USING  TAPE-SYS011                                   
                                  TAPE-RETURN                                   
                                  ERR-REC                                       
                                  TAPE-SYS011-RECSIZE                           
                                  TAPE-SYS011-BLKSIZE                           
                                  TAPE-SYS011-FORMAT                            
                                  TAPE-SYS011-COUNT.                            
           MOVE SPACES TO E-CODE.                                               
       ERR-ROUTINE-END.                                                         
           EXIT.                                                                
       END-OPERATIONS.                                                          
           IF   ARR-TYPE             =    'H'                                   
            AND ARR-REPORT-NUMBER    =    '1'                                   
             AND ARR-REPORT          =    'B'                                   
              AND TAPE-RETURN        =    ZEROS                                 
               GO TO UB-MODULE-CALL.                                            
           MULTIPLY 2 BY ACCUM-LAPSE-MAIL.                                      
           MULTIPLY 2 BY ACCUM-OVERDUE.                                         
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
