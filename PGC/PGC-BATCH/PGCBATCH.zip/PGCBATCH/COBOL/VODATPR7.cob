       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    VODATPR7.                                                 
      *AUTHOR.        F. DAZA.                                                  
      *DATE-WRITTEN.  APR 2005.                                                 
      *DATE-COMPILED.                                                           
      *============================================================*            
      *    VO DATA PROVIDER FOR VO MASTER                                       
      *------------------------------------------------------------*            
      *    APR/05 F DAZA      - CREATED                                         
      *    JUL/08 IBM GR      - UPGRADED IN ECU PROJECT                         
      *    NOV/10 IDMSDB2     - IDMS TO DB2 CONVERSION PROJECT                  
      *                       - CREATED FOR 7-DIGIT GIPSY GROUP NUMBER          
      *                                                                         
      *------------------------------------------------------------*            
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                 PIC X(16) VALUE 'VODATPR7 START=>'.         
                                                                                
       01  WS-FIELDS.                                                           
           05  WS-INITIALIZED-FLAG      PIC X(01)    VALUE 'N'.                 
               88  WS-INITIALIZED             VALUE 'Y'.                        
               88  WS-NOT-INITIALIZED         VALUE 'N'.                        
           05  WS-FILE-OPEN-FLAG        PIC X(01)    VALUE 'C'.                 
               88  WS-FILE-OPEN               VALUE 'O'.                        
               88  WS-FILE-CLOSED             VALUE 'C'.                        
           05  WS-READING-FLAG          PIC X(01)    VALUE 'D'.                 
               88  WS-READING-STARTED         VALUE 'S'.                        
               88  WS-READING-DONE            VALUE 'D'.                        
           05  WS-READ-NEXT-FLAG        PIC X(01)    VALUE 'E'.                 
               88  WS-READ-NEXT-IN-PROGRESS   VALUE 'P'.                        
               88  WS-READ-NEXT-ENDED         VALUE 'E'.                        
           05  WS-PREV-VODPCIO-INPUT    PIC X(50)    VALUE SPACES.              
           05  WS-ACTION                PIC X(16).                              
           05  VOMASTER-LR                                                      
@              VALUE 'VO-CNTRCT-MST-RO' PIC X(16).                              
                                                                                
       01  WS-VO-MASTER.                                                        
         03  WS-VOM-GAEDATSR-INFO.                                              
           05  WS-VOM-LENGTH            PIC S9(04) COMP SYNC.                   
           05  WS-VOM-FILLER            PIC X(02) VALUE SPACES.                 
         03  WS-VOM-RECORD.                                                     
           05  WS-VOM-POLICY-NUM        PIC S9(7) COMP-3.                       
           05  WS-VOM-CLASS-NUM         PIC X(05).                              
           05  WS-VOM-IDENT             PIC X(01).                              
           05  WS-VOM-COV-LOC-CODE      PIC X(01).                              
@          05  WS-VOM-OTHER             PIC X(11389).                           
                                                                                
       01  CALLED-PROGRAMS.                                                     
           05  GAEDATSR                 PIC X(08)    VALUE 'GAEDATSR'.          
           05  VOMAPPE7                 PIC X(08)    VALUE 'VOMAPPE7'.          
                                                                                
       01  VOMAPCIO.                                                            
           COPY VOMAPCIO.                                                       
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
                                                                                
       01  GARDSVRB.                                                            
           COPY GARDSVRB.                                                       
                                                                                
       01  WS-END                   PIC X(16) VALUE '<===END VODATPR7'.         
      *---------------------------------------------------------------          
       LINKAGE SECTION.                                                         
       01  VODATPR7-PROTOCOL.           COPY VODPCIO.                           
                                                                                
       PROCEDURE DIVISION USING VODATPR7-PROTOCOL.                              
                                                                                
       MAINLINE.                                                                
      *============================================================*            
      *  MAINLINE ROUTINE                                                       
      *------------------------------------------------------------*            
           IF WS-NOT-INITIALIZED THEN                                           
              PERFORM 1000-INITIALIZATION                                       
              SET WS-INITIALIZED TO TRUE                                        
           END-IF                                                               
                                                                                
           INITIALIZE VODPCIO-OUTPUT                                            
                                                                                
           SET VODPO-RET-OK TO TRUE                                             
           PERFORM 1050-VALIDATE-PARMS                                          
           IF VODPO-RET-OK THEN                                                 
               PERFORM 2000-PROCESS-REQUEST                                     
           END-IF                                                               
                                                                                
           MOVE VODPCIO-INPUT TO WS-PREV-VODPCIO-INPUT.                         
       MAINLINE-EXIT.                                                           
           GOBACK.                                                              
                                                                                
       1000-INITIALIZATION.                                                     
      *============================================================*            
      *  INITIALIZE AS NECESSARY                                                
      *------------------------------------------------------------*            
           MOVE 'VODATPR7'              TO ICBM-PROGRAM-NAME                    
                                                                                
           MOVE LOW-VALUES TO LINKAGE-CONTROL.                                  
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       1050-VALIDATE-PARMS.                                                     
      *============================================================*            
      *  VALIDATE PARMS                                                         
      *------------------------------------------------------------*            
           IF VODPI-OPEN-FILE                                                   
           OR VODPI-CLOSE-FILE                                                  
           OR VODPI-END-READ-NEXT THEN                                          
             CONTINUE                                                           
           ELSE                                                                 
             EVALUATE TRUE                                                      
               WHEN VODPI-GROUP NOT NUMERIC                                     
                    MOVE 11 TO VODPO-RET-CODE                                   
                    MOVE 'INVALID GROUP NUMBER PROVIDED'                        
                      TO VODPO-RET-MESSAGE                                      
                                                                                
               WHEN NOT (VODPI-COV-COVDB OR VODPI-COV-NONCOV)                   
                AND NOT (VODPI-COV-ANY)                                         
                    MOVE 15 TO VODPO-RET-CODE                                   
                    MOVE 'INVALID COVERAGE TYPE FOR VO'                         
                      TO VODPO-RET-MESSAGE                                      
                                                                                
               WHEN VODPI-READ-NEXT-WG                                          
                AND VODPI-ACCOUNT > SPACES                                      
                    MOVE 18 TO VODPO-RET-CODE                                   
                    MOVE 'READ NEXT W/G DOES NOT SUPPORT ACCOUNT'               
                      TO VODPO-RET-MESSAGE                                      
                                                                                
               WHEN VODPI-READ-NEXT                                             
                AND (VODPI-GROUP > 0 OR VODPI-ACCOUNT > SPACES)                 
                    MOVE 19 TO VODPO-RET-CODE                                   
                    MOVE 'READ NEXT DOES NOT SUPPORT GROUP/ACCOUNT'             
                      TO VODPO-RET-MESSAGE                                      
             END-EVALUATE                                                       
           END-IF.                                                              
       1050-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2000-PROCESS-REQUEST.                                                    
      *============================================================*            
      *  PROCESS REQUEST - OPEN FILES IF NECESSARY                              
      *------------------------------------------------------------*            
                                                                                
           IF  WS-FILE-CLOSED                                                   
           AND NOT VODPI-CLOSE-FILE THEN                                        
               PERFORM 2100-OPEN-FILE                                           
               SET WS-FILE-OPEN TO TRUE                                         
           END-IF                                                               
                                                                                
           IF  VODPCIO-INPUT NOT = WS-PREV-VODPCIO-INPUT                        
           AND WS-READ-NEXT-IN-PROGRESS THEN                                    
               SET WS-READ-NEXT-ENDED TO TRUE                                   
           END-IF                                                               
                                                                                
           IF  VODPO-RET-OK THEN                                                
               EVALUATE TRUE                                                    
                   WHEN VODPI-OPEN-FILE                                         
                                        CONTINUE                                
                   WHEN VODPI-READ-KEYED                                        
                                        PERFORM 2110-READ-KEYED                 
                   WHEN VODPI-READ-NEXT-WG                                      
                                        PERFORM 2120-READ-NEXT-WG               
                   WHEN VODPI-READ-NEXT                                         
                                        PERFORM 2130-READ-NEXT                  
                   WHEN VODPI-END-READ-NEXT                                     
                                        PERFORM 2140-END-READ-NEXT              
                   WHEN VODPI-CLOSE-FILE                                        
                                        PERFORM 2190-CLOSE-FILE                 
                   WHEN OTHER                                                   
                        MOVE 30 TO VODPO-RET-CODE                               
                        MOVE 'INVALID REQUEST!' TO VODPO-RET-MESSAGE            
               END-EVALUATE                                                     
           END-IF.                                                              
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
                                                                                
       2100-OPEN-FILE.                                                          
      *============================================================*            
      * OPEN VO MASTER FILE                                                     
      *------------------------------------------------------------*            
      *   NOTHING TO DO, FILES OPEN AUTOMATICALLY ON FIRST READ                 
           CONTINUE.                                                            
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2110-READ-KEYED.                                                         
      *============================================================*            
      * DO A KEY READ.                                                          
      *------------------------------------------------------------*            
           INITIALIZE WS-VO-MASTER                                              
           MOVE VODPI-GROUP   TO WS-VOM-POLICY-NUM                              
           MOVE VODPI-ACCOUNT TO WS-VOM-CLASS-NUM                               
                                                                                
           MOVE VOMASTER-LR   TO LOGICAL-RECORD-NAME                            
           CALL GAEDATSR                 USING  OBTAIN-KEYED                    
                                                WS-VO-MASTER                    
                                                ICBM                            
           IF LR-STATUS-OK THEN                                                 
               PERFORM 2200-DO-MAPPING                                          
           ELSE                                                                 
               MOVE 31 TO VODPO-RET-CODE                                        
               STRING LINKAGE-STATUS ': RECORD NOT FOUND'                       
                 DELIMITED BY SIZE INTO VODPO-RET-MESSAGE                       
           END-IF.                                                              
                                                                                
       2110-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2120-READ-NEXT-WG.                                                       
      *============================================================*            
      * DO A READ NEXT WITHIN THE PROVIDED GROUP                                
      *------------------------------------------------------------*            
                                                                                
           INITIALIZE WS-VO-MASTER                                              
           MOVE VODPI-GROUP   TO WS-VOM-POLICY-NUM                              
           MOVE SPACES        TO WS-VOM-CLASS-NUM                               
                                                                                
           IF WS-READ-NEXT-IN-PROGRESS THEN                                     
               MOVE OBTAIN-NEXT  TO WS-ACTION                                   
           ELSE                                                                 
               MOVE OBTAIN-GE    TO WS-ACTION                                   
           END-IF                                                               
                                                                                
           MOVE VOMASTER-LR   TO LOGICAL-RECORD-NAME                            
           CALL GAEDATSR                 USING  WS-ACTION                       
                                                WS-VO-MASTER                    
                                                ICBM                            
                                                                                
           IF  LR-STATUS-OK                                                     
           AND WS-VOM-POLICY-NUM = VODPI-GROUP THEN                             
               SET WS-READ-NEXT-IN-PROGRESS TO TRUE                             
               PERFORM 2200-DO-MAPPING                                          
           ELSE                                                                 
               SET WS-READ-NEXT-ENDED TO TRUE                                   
               MOVE 01 TO VODPO-RET-CODE                                        
               STRING LINKAGE-STATUS ': END OF GROUP REACHED'                   
                  DELIMITED BY SIZE INTO VODPO-RET-MESSAGE                      
               IF NOT LR-STATUS-OK THEN                                         
      *>>          WE MUST HAVE REACHED EOF, CLOSE THE FILE SO                  
      *>>          THAT WE DON'T ERROR OUT ON SUBSEQUENT READS                  
                   MOVE VOMASTER-LR   TO LOGICAL-RECORD-NAME                    
                   CALL GAEDATSR                 USING  FINISH-LR               
                                                        WS-VO-MASTER            
                                                        ICBM                    
                   SET WS-FILE-CLOSED TO TRUE                                   
               END-IF                                                           
           END-IF.                                                              
       2120-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2130-READ-NEXT.                                                          
      *============================================================*            
      * DO A READ NEXT WITHIN THE FILE, MATCH COV TYPE IF SPECIFIED             
      *------------------------------------------------------------*            
                                                                                
           INITIALIZE WS-VO-MASTER                                              
                                                                                
           IF WS-READ-NEXT-IN-PROGRESS THEN                                     
               MOVE OBTAIN-NEXT  TO WS-ACTION                                   
           ELSE                                                                 
               MOVE OBTAIN-FIRST TO WS-ACTION                                   
           END-IF                                                               
                                                                                
           MOVE VOMASTER-LR      TO LOGICAL-RECORD-NAME                         
                                                                                
           SET WS-READING-STARTED TO TRUE                                       
           PERFORM UNTIL WS-READING-DONE                                        
               CALL GAEDATSR                 USING  WS-ACTION                   
                                                    WS-VO-MASTER                
                                                    ICBM                        
               IF (NOT LR-STATUS-OK)                                            
               OR (VODPI-COV-ANY)                                               
               OR (VODPI-COV-COVDB  AND (WS-VOM-COV-LOC-CODE = 1))              
               OR (VODPI-COV-NONCOV AND (WS-VOM-COV-LOC-CODE = 2))              
                   SET WS-READING-DONE TO TRUE                                  
               ELSE                                                             
                   MOVE OBTAIN-NEXT  TO WS-ACTION                               
               END-IF                                                           
           END-PERFORM                                                          
                                                                                
           IF LR-STATUS-OK THEN                                                 
               SET WS-READ-NEXT-IN-PROGRESS TO TRUE                             
               PERFORM 2200-DO-MAPPING                                          
           ELSE                                                                 
               SET WS-READ-NEXT-ENDED       TO TRUE                             
               MOVE 01 TO VODPO-RET-CODE                                        
               STRING LINKAGE-STATUS ': NO MORE RECORDS/EOF REACHED'            
                  DELIMITED BY SIZE INTO VODPO-RET-MESSAGE                      
      *>>          EOF REACHED, CLOSE THE FILE SO                               
      *>>          THAT WE DON'T ERROR OUT ON SUBSEQUENT READS                  
                   MOVE VOMASTER-LR   TO LOGICAL-RECORD-NAME                    
                   CALL GAEDATSR                 USING  FINISH-LR               
                                                        WS-VO-MASTER            
                                                        ICBM                    
                   SET WS-FILE-CLOSED TO TRUE                                   
           END-IF.                                                              
                                                                                
       2130-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2140-END-READ-NEXT.                                                      
      *============================================================*            
      *  END CURRENT READ NEXT                                                  
      *------------------------------------------------------------*            
           MOVE VOMASTER-LR   TO LOGICAL-RECORD-NAME                            
           CALL GAEDATSR                 USING  FINISH-LR                       
                                                WS-VO-MASTER                    
                                                ICBM                            
           IF LR-STATUS-OK THEN                                                 
               SET WS-FILE-CLOSED TO TRUE                                       
           ELSE                                                                 
               MOVE 09 TO VODPO-RET-CODE                                        
               STRING LINKAGE-STATUS ': FAILED TO END READ NEXT'                
                 DELIMITED BY SIZE INTO VODPO-RET-MESSAGE                       
           END-IF                                                               
                                                                                
           SET WS-FILE-CLOSED TO TRUE.                                          
       2140-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2190-CLOSE-FILE.                                                         
      *============================================================*            
      *  CLOSE THE VO MASTER FILE  (USE FINISH-LR CAUSE CLOSE-ALL               
      *                             RETURNS A 9903)                             
      *------------------------------------------------------------*            
           IF WS-FILE-OPEN THEN                                                 
               MOVE VOMASTER-LR   TO LOGICAL-RECORD-NAME                        
               CALL GAEDATSR                 USING  FINISH-LR                   
                                                    WS-VO-MASTER                
                                                    ICBM                        
               IF LR-STATUS-OK THEN                                             
                   CONTINUE                                                     
               ELSE                                                             
                   MOVE 09 TO VODPO-RET-CODE                                    
                   STRING LINKAGE-STATUS ': FAILED TO CLOSE VO MASTER'          
                     DELIMITED BY SIZE INTO VODPO-RET-MESSAGE                   
               END-IF                                                           
           ELSE                                                                 
               CONTINUE                                                         
           END-IF                                                               
                                                                                
           SET WS-FILE-CLOSED TO TRUE.                                          
       2190-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2200-DO-MAPPING.                                                         
      *============================================================*            
      *  CALL 'THE VOMAPPE7 PROGRAM                                             
      *============================================================*            
           MOVE WS-VOM-POLICY-NUM         TO VODPO-GROUP                        
           MOVE WS-VOM-CLASS-NUM          TO VODPO-ACCOUNT                      
           EVALUATE WS-VOM-COV-LOC-CODE                                         
               WHEN '1'                                                         
                   SET VODPO-COV-COVDB    TO TRUE                               
               WHEN '2'                                                         
                   SET VODPO-COV-NONCOV   TO TRUE                               
               WHEN OTHER                                                       
                   MOVE SPACES            TO VODPO-COVERAGE-TYPE                
           END-EVALUATE                                                         
                                                                                
           MOVE WS-VOM-RECORD             TO VOMI-VO-RECORD                     
           MOVE VODPI-LR-NAME             TO VOMI-LR-NAME                       
           CALL VOMAPPE7               USING VOMAPCIO                           
                                                                                
           MOVE VOMO-MAPPED-RECORD        TO VODPO-MAPPED-RECORD                
           MOVE VOMO-RET-CODE             TO VODPO-RET-CODE                     
           MOVE VOMO-RET-MESSAGE          TO VODPO-RET-MESSAGE.                 
       2200-EXIT.                                                               
           EXIT.                                                                
                                                                                
