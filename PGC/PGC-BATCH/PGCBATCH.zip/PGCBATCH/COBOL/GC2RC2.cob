       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2RC2.                                                      
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *REMARKS.                                                                 
      *    THIS PROGRAM CREATES THE RECONCILIATION STATEMENTS FROM THE          
      *        COMMISSION RECONCILIATION EXTRACT FILE AND RECONCILES            
      *        COMMISSION AND SALES CREDIT RECORDS.                             
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *           
      *  HISTORY:                                                               
      *                                                                         
      *  01JUL86  F. GAGNE      CREATION                                        
      *  22DEC86  L. HAMPTON    ADD AMENDMENT BONUS AMOUNT TO THE               
      *                         COMMISSION SPLIT AMOUNT COLUMN ON               
      *                         STATEMENT                                       
      *  18JAN87  L. HAMPTON    PUT CURRENT DATE ON STATEMENT.                  
      *                         INDICATE BY '-' WHERE THE STATEMENT             
      *                         IS TO BE MAILED ( BRANCH OR GFO).               
      *                         FIX WORDING OF ERROR MESSAGES.                  
      *                         PRINT NUMBER OF STATEMENTS PRODUCED.            
      *  20JUL87  S. WAGLER     EDIT CONTROL DATE ON FILE TO RUN DATE.          
      *           L. HAMPTON    EDIT INDICATORS ON CONTROL RECORD.              
      *                         CHANGE PROCESS DATE ON COMP RECORDS             
      *                         TO RUN DATE AS OPPOSED TO CURRENT DATE          
      *  10AUB87  L HAMPTON     TO ADD GCRL CODE 121                            
      *  16AUG89  A SCHLEICHER  IF BROKER SOLD AN ALPHA CASE SENT TO            
      *                         BRANCH NOT GFO                                  
      *    DEC89  M BURTON      RECOMPILED TO PICK UP NEW VERSION OF            
      *                         GNUMONIC                                        
      *  11JUN90  A SCHLEICHER  CHANGED COMMISSION RELEASE RECORD TO            
      *                         ADD & CHANGE FIELDS AS TO AGENCY                
      *                         SPECIFICATIONS                                  
      *                         CHANGED COPYBOOK GCOMRLSE                       
      *                                                                         
      *    SEP90  M PRANGE     -USE ACTUAL AGENT % FROM GIPSY MASTER            
      *                         IN AGENT-SPLIT FIELD INSTEAD OF                 
      *                         HARDCODING 100%.                                
      *                        -COMMENTED OUT LOGIC THAT FUDGED THE             
      *                         VALUE IN PSMPOLICY-YEAR.                        
      *                                                                         
      *    OCT90  A NIKELSKI   -CHANGED COMMISSION RELEASE RECORD               
      *                         GCRL-CODE (1)                                   
      *                        -USE ACTUAL AGENT % FROM GIPSY MASTER            
      *                         IN GCRL-SHARE FIELD INSTEAD OF                  
      *                         HARDCODING 100%.                                
      *                       - USE BRANCH / GFO NUMBER ON RECON.               
      *                         STATEMENT INSTEAD OF NAME                       
      *                                                                         
      *    DEC90  I BUCKNELL  - MAKE INTERMEDIATE CALC FIELD                    
      *                         WS-SPLIT-RATE ONE DECIMAL POSITION              
      *                         LARGER TO AVOID ROUNDING ERROR*                 
      *                                                                         
      *                                                                         
      *    DEC/91 M PRANGE                                                      
      *         - AMENDMENT RECOVERY LOGIC NOT WORKING CORRECTLY.               
      *           GWCORCOMP RECORDS CREATED ARE CORRECT BUT COMM                
      *           RELEASE RECORDS ARE NOT.                                      
      *                                                                         
      *    APR/92 M PRANGE                                                      
      *         - MISSED SOME FIELD CHANGES IN DEC/91 FIX - OOPS.               
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                  SALE CREDIT RELEASE                          *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    MAY/92 A NIKELSKI                                          *         
      *         - LOGIC ADDED FOR RENEWAL YEAR SALE CREDITS & CHANGED *         
      *           RECONCILIATION STATEMENT TO REFLECT RENEWAL YEAR    *         
      *           SALE CREDITS                                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    JUL 93 A NIKELSKI                                          *         
      *         - PRODUCTION FIX, MOVE DATE FIELD OVER 1 SPACE ON     *         
      *           THE FRENCH HEADING LINE, SO THE PRINT CONTROL       *         
      *           CHARACTER IS NOT WRITTEN OVER.                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    OCT/97 D'WIZ SYSTEMS                           B. PUCAN    *         
      *           MODIFY FOR Y2K COMPLIANCE.                          *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 13JUN98 - ALPHA-CC PROJECT. G. WRIGHT                          *        
      *                       COMMISSION FEED ALWAYS TO HAVE RGO IN    *        
      *                       GCRL-BRANCH FIELD (REMOVE FOGL CODE      *        
      *                       OVERRIDES TO THIS)                       *        
      * ---------------------------------------------------------------*        
      * OCT00 - T12114 - ADD PAGE NUMBER TO REPORT                              
      * ---------------------------------------------------------------*        
      * OCT02 - T22958 - ADD AGENT'S MAILING ADDRESS PAGE                       
      *                  SO STATEMENTS CAN BE DIRECT MAILED                     
      * ---------------------------------------------------------------*        
      *    JUL/2005  R. KNAUD.                                                  
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)                  
      *                  CHANGE THE GMASTER IDMS READ TO:                       
      *                      USE VOGPWRA7 TO READ THE VCM AND                   
      *                      GIPSY MASTER FILES.                                
      *         - HUB:  COMM PSMASTER ROUTER (VOCOMM VOPSM/PSM)                 
      *                  CHANGE THE PSMASTER IDMS READ TO:                      
      *                  READ THE VO PSMASTER FIRST (USING GAEDATSR)            
      *                  AND IF THE REQUIRED RECORD IS NOT THERE,               
      *                  READ THE PSMASTER (USING GACCDMA7).                    
      *                                                                         
      *    OCT/2008  IBM GR                                                     
      *         - UPGRADED IN ENTERPRISE COMPILER PROJECT                       
      *                                                                         
      ******************************************************************        
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCRC2          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO02 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2RC2 W-S STARTS HERE **'.                                  
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      * GMASTER                                                                 
CPYNME     COPY GMASTER7.                                                       
           03  FILLER                     PIC X(30).                            
                                                                                
       01  WS-DYNAMIC-PROGRAM-CALLS.                                            
           05  VOGPWRA7                   PIC X(8)    VALUE 'VOGPWRA7'.         
           05  GC2DATE                    PIC X(8)    VALUE 'GC2DATE'.          
                                                                                
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------                           
      *  VO PS MASTER                                                           
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
             ' **** VO PS MASTER  ****    '.                                    
           COPY VOPSMAST.                                                       
      *----------------------------------------------                           
      *  PSMASTER                                                               
      *----------------------------------------------                           
       01  FILLLER                PIC X(32) VALUE                               
FXXTOK       ' **** PSMASTE7  ****    '.                                        
      * PSMASTE7                                                                
CPYNME     COPY PSMASTE7.                                                       
                                                                                
       01  WS-FY-RN-FLAG             VALUE SPACES     PIC X(2).                 
       01  WS-FY-LIFE-PCT     COMP-3 VALUE +0         PIC S9(3)V9(2).           
       01  WS-FY-LTD-PCT      COMP-3 VALUE +0         PIC S9(3)V9(2).           
       01  WS-FY-A-S-PCT      COMP-3 VALUE +0         PIC S9(3)V9(2).           
       01  WS-RN-LIFE-PCT     COMP-3 VALUE +0         PIC S9(3)V9(2).           
       01  WS-RN-LTD-PCT      COMP-3 VALUE +0         PIC S9(3)V9(2).           
       01  WS-RN-A-S-PCT      COMP-3 VALUE +0         PIC S9(3)V9(2).           
                                                                                
      /                                                                         
       01  INIT-CR-RECORD.                                                      
REN        05  FILLER               VALUE +316 COMP   PIC S9(4).                
           05  FILLER               VALUE LOW-VALUES  PIC XX.                   
           05  FILLER               VALUE SPACES      PIC X.                    
           05  FILLER.                                                          
REN            10  FILLER           VALUE +0 COMP-3   PIC S9(7).                
               10  FILLER           VALUE SPACES      PIC X(3).                 
               10  FILLER           VALUE +0 COMP-3   PIC S9(6).                
           05  FILLER               VALUE +0 COMP-3   PIC S9(3).                
           05  FILLER               VALUE +0 COMP-3   PIC S9(15).               
           05  FILLER               VALUE SPACES      PIC X(4).                 
           05  FILLER               VALUE +0 COMP-3   PIC S9(3).                
           05  FILLER               VALUE +0          PIC S9(2).                
           05  FILLER               VALUE +0          PIC S9.                   
           05  FILLER               VALUE +0 COMP-3   PIC S9(9).                
           05  FILLER               VALUE +0 COMP-3   PIC S9(5).                
           05  FILLER               VALUE +0 COMP-3   PIC S9(2).                
           05  FILLER               VALUE +0 COMP-3   PIC S9(2).                
           05  FILLER               VALUE +0          PIC S9.                   
           05  FILLER.                                                          
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
           05  FILLER               VALUE SPACES      PIC X(25).                
           05  FILLER               VALUE +0 COMP-3   PIC S9(3).                
           05  FILLER               VALUE +0 COMP-3   PIC S9(2).                
           05  FILLER.                                                          
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
           05  FILLER               VALUE +0 COMP-3   PIC S9.                   
           05  FILLER               VALUE +0 COMP-3   PIC S9(5).                
           05  FILLER               VALUE +0          PIC S9(2).                
           05  FILLER               VALUE +0          PIC S9(2).                
           05  FILLER               VALUE +0 COMP-3   PIC S9.                   
           05  FILLER               VALUE +0 COMP-3   PIC S9.                   
           05  FILLER               VALUE SPACES      PIC X(3).                 
           05  FILLER.                                                          
               10  FILLER           VALUE  0 COMP-3   PIC 9.                    
               10  FILLER           VALUE  0 COMP-3   PIC 9(2).                 
           05  FILLER.                                                          
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
               10  FILLER           VALUE 0           PIC 99.                   
           05  FILLER               VALUE 0           PIC 9(10).                
           05  FILLER               VALUE ZERO        PIC 9(16).                
           05  FILLER               VALUE SPACES      PIC X(5).                 
           05  FILLER               VALUE 'G'         PIC X.                    
           05  FILLER          COMP-3.                                          
               10  FILLER           VALUE +0          PIC S9(6).                
               10  FILLER               VALUE +0      PIC S9(3).                
               10  FILLER               VALUE  0      PIC 9(3).                 
               10  FILLER           VALUE +0          PIC S9(3).                
               10  FILLER           VALUE +0          PIC S9(3)V99.             
               10  FILLER           VALUE +0          PIC S9(5).                
               10  FILLER           VALUE +0          PIC S9(3).                
               10  FILLER           VALUE +0          PIC S9(5).                
           05  FILLER.                                                          
               10  FILLER           VALUE 10          PIC 99.                   
               10  FILLER.                                                      
                   15  FILLER           VALUE 0       PIC 99.                   
                   15  FILLER           VALUE 0       PIC 99.                   
                   15  FILLER           VALUE 0       PIC 99.                   
                   15  FILLER           VALUE 0       PIC 99.                   
               10  FILLER               VALUE 0 COMP-3 PIC 9(5).                
               10  FILLER               VALUE 0        PIC 9.                   
           05  FILLER.                                                          
               10  FILLER               VALUE 0        PIC 99.                  
               10  FILLER               VALUE 0 COMP-3 PIC 9(5).                
               10  FILLER.                                                      
                   15  FILLER           VALUE 0        PIC 99.                  
                   15  FILLER           VALUE 0        PIC 99.                  
                   15  FILLER           VALUE 0        PIC 99.                  
                   15  FILLER           VALUE 0        PIC 99.                  
               10  FILLER.                                                      
                   15  FILLER           VALUE 0        PIC 99.                  
                   15  FILLER           VALUE 0        PIC 99.                  
                   15  FILLER           VALUE 0        PIC 99.                  
                   15  FILLER           VALUE 0        PIC 99.                  
           05  FILLER                   VALUE SPACES   PIC X(31).               
           05  FILLER.                                                          
               10  FILLER             COMP-3 OCCURS 10 TIMES.                   
                   15  TEMP-1                          PIC S9(3).               
                   15  TEMP-2                          PIC S9(11).              
       01  FILLER                                      PIC X(100).              
                                                                                
       01  WS-SUB                       VALUE +0   PIC S9(3) COMP-3.            
       01  WS-SUB2                      VALUE +0   PIC S9(3) COMP-3.            
       01  WS-SUB3                      VALUE +0   PIC S9(3) COMP-3.            
       01  AGT-SUB1                     VALUE +0   PIC S9(4) COMP.              
       01  AGT-SUB2                     VALUE +0   PIC S9(4) COMP.              
       01  ADDR-SUB                     VALUE +0   PIC S9(4) COMP.              
                                                                                
       01  WS-PERCENT                              PIC S9(6)V9(5).              
       01  WS-PERCENT-01 REDEFINES WS-PERCENT.                                  
           05  FILLER                             PIC S9(6)V.                   
           05  WS-PER-1                           PIC 9.                        
           05  WS-PER-2                           PIC 9.                        
           05  WS-PER-3                           PIC 9.                        
           05  WS-PER-4                           PIC 9.                        
           05  WS-PER-5                           PIC 9.                        
                                                                                
       01  WS-ACTION-REPORT.                                                    
                                                                                
           05  ACTION-HDG-1.                                                    
               10  ACTION-CC-1             PIC X        VALUE '1'.              
FXXTOK         10  FILLER                  PIC X(45)   VALUE 'GC2RC2'.          
               10  FILLER                  PIC X(45)    VALUE                   
                             'COMMISSION RECONCILIATION - ERROR REPORT'.        
               10  FILLER                  PIC X(10)   VALUE 'RUN DATE'.        
               10  ACTION-RUN-DATE         PIC X(7)     VALUE SPACES.           
               10  FILLER                  PIC X(10)    VALUE SPACES.           
               10  FILLER                  PIC X(5)     VALUE SPACES.           
               10  FILLER                  PIC X(5)     VALUE SPACES.           
               10  FILLER                  PIC X(5)     VALUE SPACES.           
                                                                                
           05  ACTION-HDG-2.                                                    
               10  ACTION-CC-2             PIC X        VALUE '-'.              
               10  FILLER                  PIC X(8)     VALUE 'GROUP'.          
               10  FILLER                  PIC X(10)    VALUE 'ACCOUNT'.        
               10  FILLER                  PIC X(9)     VALUE 'EFFECT'.         
               10  FILLER                  PIC X(9)     VALUE 'AGENT'.          
               10  FILLER                  PIC X(7)     VALUE 'COMP'.           
               10  FILLER                  PIC X(7)     VALUE 'COMP'.           
               10  FILLER                  PIC X(9)     VALUE 'COMP'.           
               10  FILLER                  PIC X(17)    VALUE 'COV'.            
               10  FILLER                  PIC X(36)    VALUE                   
                                                       'DESCRIPTION'.           
               10  FILLER                  PIC X(20)    VALUE                   
                                                   'ACTION REQUIRED'.           
                                                                                
           05  ACTION-HDG-3.                                                    
               10  ACTION-CC-3             PIC X        VALUE SPACE.            
               10  FILLER                  PIC XX       VALUE SPACES.           
               10  FILLER                  PIC X(17)    VALUE '#'.              
               10  FILLER                  PIC X(10)    VALUE 'DATE'.           
               10  FILLER                  PIC X(7)     VALUE '#'.              
               10  FILLER                  PIC X(7)     VALUE 'TYPE'.           
               10  FILLER                  PIC X(7)     VALUE 'DISP'.           
               10  FILLER                  PIC X(9)     VALUE 'REASON'.         
               10  FILLER                  PIC X(72)    VALUE 'TYPE'.           
                                                                                
           05  ACTION-LINE.                                                     
               10  ACTION-CC-4             PIC X        VALUE '0'.              
REN            10  ERROR-GROUP             PIC 9(7)     VALUE ZERO.             
REN            10  FILLER                  PIC X(2)     VALUE SPACES.           
               10  ERROR-ACCOUNT           PIC XXX      VALUE SPACES.           
               10  FILLER                  PIC X(4)     VALUE SPACES.   YEAR2000
               10  ERROR-DATE              PIC X(9)     VALUE SPACES.   YEAR2000
               10  FILLER                  PIC X        VALUE SPACES.   YEAR2000
               10  ERROR-AGENT             PIC 9(6)     VALUE ZERO.             
               10  FILLER                  PIC X(4)     VALUE SPACES.           
               10  ERROR-COMP-TYPE         PIC X        VALUE SPACE.            
               10  FILLER                  PIC X(6)     VALUE SPACES.           
               10  ERROR-COMP-DISP         PIC X        VALUE SPACE.            
               10  FILLER                  PIC X(6)     VALUE SPACES.           
               10  ERROR-COMP-REASON       PIC X        VALUE SPACE.            
               10  FILLER                  PIC X(5)     VALUE SPACES.           
               10  ERROR-COV-TYPE          PIC X        VALUE SPACE.            
               10  FILLER                  PIC X(5)     VALUE SPACES.           
               10  ERROR-MSG               PIC X(45)    VALUE SPACES.           
               10  ACTION-REQUEST          PIC X(25)    VALUE                   
                                           'ENTER CORRECTION ON-LINE'.          
           05  TOTAL-LINE.                                                      
               10  FILLER                  PIC X         VALUE '-'.             
               10  FILLER                  PIC X(32)    VALUE                   
                                     'NUMBER OF STATEMENTS PRODUCED :'.         
               10  TOTAL-STATEMENTS        PIC ZZ9.                             
                                                                                
           05  END-LINE.                                                        
               10  END-CC                  PIC X         VALUE '-'.             
               10  FILLER                  PIC X(132)    VALUE                  
                                       '*** END OF REPORT ***'.                 
                                                                                
           05  ERROR-MESSAGES.                                                  
               10  ERR-MSG-1               PIC X(45)   VALUE                    
                                     'UNABLE TO HANDLE THIS RECORD'.            
               10  ERR-MSG-2               PIC X(45)   VALUE                    
                                               'INVALID COVERAGE TYPE'.         
               10  ERR-MSG-3               PIC X(45)   VALUE                    
                                                 'INVALID DISPOSITION'.         
               10  ERR-MSG-4               PIC X(45)   VALUE                    
                                     'COMM-SCR-RECON-IND NOT EQ YES'.           
                                                                                
       01  DLS-PARMS.                                                           
           05  ACTION-PRINT-PARMS.                                              
               10  DLSA-SYSNNN      PIC X(6)          VALUE 'SYS022'.           
               10  DLSA-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSA-RECORD      PIC X(133)        VALUE SPACES.             
               10  DLSA-REC-SIZE    PIC 9(5)          VALUE 133.                
               10  DLSA-BLK-SIZE    PIC 9(5)          VALUE 3990.               
               10  DLSA-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSA-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
           05  RUNDATE-READ-PARMS.                                              
               10  DLSR-SYSNNN      PIC X(6)          VALUE 'SYS019'.           
               10  DLSR-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSR-REC-SIZE    PIC 9(5)          VALUE 80.                 
               10  DLSR-BLK-SIZE    PIC 9(5)          VALUE 80.                 
               10  DLSR-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSR-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
           05  READ-HEADING-PARMS.                                              
               10  DLSH-SYSNNN      PIC X(6)          VALUE 'SYS015'.           
               10  DLSH-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSH-REC-SIZE    PIC 9(5)          VALUE 133.                
               10  DLSH-BLK-SIZE    PIC 9(5)          VALUE 23408.              
               10  DLSH-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSH-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
           05  READ-EXTRACT-PARMS.                                              
               10  DLSC-SYSNNN      PIC X(6)          VALUE 'SYS010'.           
               10  DLSC-RET-CODE    PIC S9    COMP-3  VALUE ZERO.               
               10  DLSC-REC-SIZE    PIC 9(5)          VALUE 55.                 
               10  DLSC-BLK-SIZE    PIC 9(5)          VALUE 5500.               
               10  DLSC-FORMAT      PIC XX            VALUE 'FB'.               
               10  DLSC-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
           05  STMT-PRINT-ENGLISH.                                              
               10  DLSWE-SYSNNN      PIC X(6)          VALUE 'SYS021'.          
               10  DLSWE-RET-CODE    PIC S9    COMP-3  VALUE ZERO.              
               10  DLSWE-REC-SIZE    PIC 9(5)          VALUE 133.               
               10  DLSWE-BLK-SIZE    PIC 9(5)          VALUE 3990.              
               10  DLSWE-FORMAT      PIC XX            VALUE 'FB'.              
               10  DLSWE-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.              
                                                                                
           05  STMT-PRINT-FRENCH.                                               
               10  DLSWF-SYSNNN      PIC X(6)          VALUE 'SYS023'.          
               10  DLSWF-RET-CODE    PIC S9    COMP-3  VALUE ZERO.              
               10  DLSWF-REC-SIZE    PIC 9(5)          VALUE 133.               
               10  DLSWF-BLK-SIZE    PIC 9(5)          VALUE 3990.              
               10  DLSWF-FORMAT      PIC XX            VALUE 'FB'.              
               10  DLSWF-REC-COUNT   PIC S9(7) COMP-3  VALUE ZERO.              
                                                                                
       01  PRINT-LINE               PIC X(133)        VALUE SPACES.             
                                                                                
       01  ADDRESS-LINE-01.                                                     
           05  FILLER              PIC X(1) VALUE '1'.                          
           05  FILLER              PIC X(123).                                  
           05  A1-AGENT            PIC 9(6) VALUE 0.                            
           05  FILLER              PIC X(3).                                    
                                                                                
       01  ADDRESS-LINES.                                                       
           05  FILLER               PIC X      VALUE SPACES.                    
           05  FILLER               PIC X(5)   VALUE SPACES.                    
           05  ADDRESS-DETAIL       PIC X(127) VALUE SPACES.                    
                                                                                
       01  DEFAULT-ADDRESS-LINES.                                               
           05  FILLER                                PIC X(133)                 
                   VALUE '      CHERYL D. WILSON'.                              
           05  FILLER                                PIC X(133)                 
                   VALUE '      COMMISSIONS AND COLLECTIONS'.                   
           05  FILLER                                PIC X(133)                 
                   VALUE '      GB-B'.                                          
           05  FILLER                                PIC X(133)                 
                   VALUE '      380 WEBER STREET NORTH'.                        
           05  FILLER                                PIC X(133)                 
                   VALUE '      WATERLOO, ON  N2J 3J3'.                         
                                                                                
       01  FILLER   REDEFINES DEFAULT-ADDRESS-LINES.                            
           05  DEFAULT-ADDRESS-DETAIL PIC X(133) OCCURS 5 TIMES.                
                                                                                
       01  ENGLISH-REPORT.                                                      
           05  ENGLISH-HEADING      PIC X(133) OCCURS 21 TIMES.                 
                                                                                
       01  FRENCH-REPORT.                                                       
           05  FRENCH-HEADING       PIC X(133) OCCURS 22 TIMES.                 
                                                                                
       01  HEADING-LINE             PIC X(133).                                 
                                                                                
       01  HEADING-01.                                                          
           05  FILLER              PIC X(1).                                    
           05  H1-DATE             PIC X(9).                            YEAR2000
           05  FILLER              PIC X(117).                                  
           05  H1-PAGE             PIC 9(4) VALUE 0.                            
           05  FILLER              PIC X(3).                                    
                                                                                
       01  HEADING-04.                                                          
           05  FILLER              PIC X(1).                                    
           05  H4-AGENT-NAME-LIT   PIC X(11).                                   
           05  FILLER              PIC X(9).                                    
           05  H4-AGENT-NAME       PIC X(30).                                   
           05  FILLER              PIC X(28).                                   
           05  H4-AGENT-CODE-LIT   PIC X(11).                                   
           05  FILLER              PIC X(7).                                    
           05  H4-AGENT-NUMBER     PIC X(6).                                    
                                                                                
       01  HEADING-05.                                                          
           05  FILLER              PIC X(21).                                   
           05  H5-GROUP-NAME       PIC X(30).                                   
           05  FILLER              PIC X(46).                                   
REN        05  H5-GROUP            PIC X(7).                                    
           05  H5-ACCOUNT          PIC X(3).                                    
                                                                                
       01  HEADING-06.                                                          
           05  FILLER              PIC X(21).                                   
           05  H6-EFFECT-DATE      PIC X(9).                            YEAR2000
           05  FILLER              PIC X(49).                                   
           05  H6-LIFE-A-S-LIT     PIC X(18).                                   
           05  H6-LIFE-A-S-SCALE   PIC X(7).                                    
           05  FILLER REDEFINES H6-LIFE-A-S-SCALE.                              
               10  H6-LIFE-A-S-RATE  PIC ZZ9.99.                                
               10  H6-LIFE-A-S-PSIGN PIC X.                                     
                                                                                
       01  HEADING-07.                                                          
           05  FILLER              PIC X(7).                                    
           05  H7-FROM-DATE.                                                    
               10  H7-FROM-MTH     PIC XXX.                                     
               10  FILLER          PIC X.                                       
               10  H7-FROM-YR      PIC 9999.                                    
           05  FILLER              PIC X(4).                            YEAR2000
           05  H7-TO-DATE.                                                      
               10  H7-TO-MTH       PIC XXX.                                     
               10  FILLER          PIC X.                                       
               10  H7-TO-YR        PIC 9999.                            YEAR2000
           05  FILLER              PIC X(52).                                   
           05  H7-LTD-LIT          PIC X(18).                                   
           05  H7-LTD-SCALE        PIC X(7).                                    
           05  FILLER REDEFINES H7-LTD-SCALE.                                   
               10  H7-LTD-RATE   PIC ZZ9.99.                                    
               10  H7-LTD-PSIGN  PIC X.                                         
                                                                                
       01  HEADING-08.                                                          
           05  FILLER              PIC X(7).                                    
           05  H8-CURRENCY         PIC X(3).                                    
           05  FILLER              PIC X(66).                                   
           05  H8-BR-MAIL-IND      PIC X(3).                                    
           05  FILLER              PIC X(18).                                   
           05  H8-SERVICE-BRANCH   PIC X(5).                                    
                                                                                
       01  HEADING-09.                                                          
           05  FILLER              PIC X(76).                                   
           05  H9-GFO-MAIL-IND     PIC X(3).                                    
           05  FILLER              PIC X(18).                                   
           05  H9-SERVICING-GFO    PIC X(5).                                    
                                                                                
       01  HEADING-10.                                                          
           05  FILLER              PIC X(125).                                  
           05  H10-VARIABLE        PIC X(7).                                    
                                                                                
       01  HEADING-11.                                                          
           05  FILLER              PIC X(128).                                  
           05  H11-VARIABLE        PIC X(4).                                    
                                                                                
       01  HEADING-12.                                                          
           05  FILLER              PIC X(128).                                  
           05  H12-VARIABLE        PIC X(4).                                    
                                                                                
       01  DASH-LINE.                                                           
           05  FILLER              PIC X(121).                                  
           05  DASH-VARIABLE       PIC X(13)     VALUE SPACES.                  
                                                                                
       01  TOTAL-01.                                                            
           05  T1-DESC             PIC X(10).                                   
           05  T1-PREM-PAID        PIC ZZ,ZZZ,ZZ9.99-.                          
           05  FILLER              PIC X(2).                                    
           05  T1-COMM-EARNED      PIC Z,ZZZ,ZZ9.99-.                           
           05  FILLER              PIC X(2).                                    
           05  T1-S-C-EARNED       PIC Z,ZZZ,ZZ9.99-.                           
           05  FILLER              PIC X(11).                                   
           05  T1-COMM-SPLIT-AMT   PIC Z,ZZZ,ZZ9.99-.                           
           05  FILLER              PIC X(3).                                    
           05  T1-S-C-SPLIT-AMT    PIC Z,ZZZ,ZZ9.99-.                           
      *    05  FILLER              PIC X(1).                                    
           05  T1-COMM-PAID        PIC Z,ZZZ,ZZ9.99-.                           
           05  FILLER              PIC X(2).                                    
           05  T1-S-C-PAID         PIC Z,ZZZ,ZZ9-.                              
           05  FILLER              PIC X(1).                                    
           05  T1-FEES-PAID        PIC ZZZZ,ZZZ.ZZ-  VALUE ZERO.                
           05  T1-FEES-PAID-X REDEFINES T1-FEES-PAID    PIC X(12).              
                                                                                
       01  TOTAL-02.                                                            
           05  FILLER               PIC X(37).                                  
           05  T2-ALL-RECON-AMTS    PIC ZZZ,ZZZ,ZZ9.99- VALUE ZERO.             
                                                                                
       01  TOTAL-03.                                                            
           05  FILLER               PIC X(42).                                  
           05  T3-S-C-RECON-AMTS    PIC Z,ZZZ,ZZ9- VALUE ZERO.                  
                                                                                
       01  HEADING-F01.                                                         
           05  FILLER              PIC X(1).                                    
           05  H1-DATE-F           PIC X(9).                            YEAR2000
           05  FILLER              PIC X(117).                                  
           05  H1-PAGE-F           PIC 9(4) VALUE 0.                            
           05  FILLER              PIC X(3).                                    
                                                                                
       01  HEADING-F04.                                                         
           05  FILLER              PIC X(01).                                   
           05  H4-AGENT-NAME-LIT-F PIC X(14).                                   
           05  FILLER              PIC X(03).                                   
           05  H4-AGENT-NAME-F     PIC X(30).                                   
           05  FILLER              PIC X(40).                                   
           05  H4-AGENT-CODE-LIT-F PIC X(19).                                   
           05  H4-AGENT-NUMBER-F   PIC X(6).                                    
                                                                                
       01  HEADING-F05.                                                         
           05  FILLER              PIC X(18).                                   
           05  H5-GROUP-NAME-F     PIC X(30).                                   
           05  FILLER              PIC X(59).                                   
REN        05  H5-GROUP-F          PIC X(7).                                    
           05  H5-ACCOUNT-F        PIC XXX.                                     
                                                                                
       01  HEADING-F06.                                                         
           05  FILLER              PIC X(18).                                   
           05  H6-EFFECT-DATE-F    PIC X(9).                            YEAR2000
           05  FILLER              PIC X(61).                                   
           05  H6-LIFE-A-S-LIT-F   PIC X(19).                                   
           05  H6-LIFE-A-S-SCALE-F PIC X(7).                                    
           05  FILLER REDEFINES H6-LIFE-A-S-SCALE-F.                            
               10  H6-LIFE-A-S-RATE-F      PIC ZZ9.99.                          
               10  H6-LIFE-A-S-PSIGN-F     PIC X.                               
                                                                                
       01  HEADING-F07.                                                         
           05  FILLER              PIC X(4).                                    
           05  H7-FROM-DATE-F.                                                  
               10  H7-FROM-MTH-F   PIC XXX.                                     
               10  FILLER          PIC X.                                       
               10  H7-FROM-YR-F    PIC 9999.                                    
           05  FILLER              PIC X(2).                            YEAR2000
           05  H7-TO-DATE-F.                                                    
               10  H7-TO-MTH-F     PIC XXX.                                     
               10  FILLER          PIC X.                                       
               10  H7-TO-YR-F      PIC 9999.                            YEAR2000
           05  FILLER              PIC X(66).                                   
           05  H7-LTD-LIT-F        PIC X(19).                                   
           05  H7-LTD-SCALE-F      PIC X(7).                                    
           05  FILLER REDEFINES H7-LTD-SCALE-F.                                 
                   15  H7-LTD-RATE-F      PIC ZZ9.99.                           
                   15  H7-LTD-PSIGN-F     PIC X.                                
                                                                                
       01  HEADING-F08.                                                         
           05  FILLER              PIC X(11).                                   
           05  H8-CURRENCY-F       PIC XXX.                                     
           05  FILLER              PIC X(69).                                   
           05  H8-BR-MAIL-IND-F    PIC X(3).                                    
           05  FILLER              PIC X(21).                                   
           05  H8-SERVICE-BRANCH-F PIC X(05) VALUE SPACES.                      
                                                                                
       01  HEADING-F09.                                                         
           05  FILLER              PIC X(81).                                   
           05  H9-GFO-MAIL-IND-F   PIC X(3).                                    
           05  FILLER              PIC X(23).                                   
           05  H9-SERVICING-GFO-F  PIC X(05) VALUE SPACES.                      
      /                                                                         
       01  HEADING-F10.                                                         
           05  FILLER              PIC X(123).                                  
           05  H10-VARIABLE-F      PIC X(8).                                    
                                                                                
       01  HEADING-F11.                                                         
           05  FILLER              PIC X(124).                                  
           05  H11-VARIABLE-F      PIC X(7).                                    
                                                                                
       01  HEADING-F12.                                                         
           05  FILLER              PIC X(126).                                  
           05  H12-VARIABLE-F      PIC X(5).                                    
                                                                                
       01  TOTAL-F02.                                                           
           05  FILLER               PIC X(50).                                  
           05  T2-ALL-RECON-AMTS-F  PIC ZZZ,ZZZ,ZZ9.99- VALUE ZERO.             
                                                                                
       01  TOTAL-F03.                                                           
           05  FILLER               PIC X(55).                                  
           05  T3-S-C-RECON-AMTS-F  PIC Z,ZZZ,ZZ9- VALUE ZERO.                  
                                                                                
       01  DETAIL-01.                                                           
           05  D1-CC             PIC X               VALUE '0'.                 
           05  D1-MTH            PIC XXX             VALUE SPACES.              
           05  FILLER            PIC X               VALUE SPACE.               
           05  D1-YR             PIC 9999            VALUE ZERO.                
           05  FILLER            PIC X(2)            VALUE SPACES.              
           05  D1-PREM-PAID      PIC Z,ZZZ,ZZ9.99-   VALUE ZERO.                
           05  FILLER            PIC X(4)            VALUE SPACES.              
           05  D1-COMM-EARNED    PIC ZZZ,ZZ9.99-     VALUE ZERO.                
           05  FILLER            PIC X(4)            VALUE SPACES.              
           05  D1-SC-EARNED      PIC ZZZ,ZZ9.99-     VALUE ZERO.                
           05  FILLER            PIC X(4)            VALUE SPACES.              
           05  D1-SPLIT-PERCENT PIC ZZ9.99           VALUE ZERO.                
           05  D1-SPLIT-SIGN     PIC X               VALUE '%'.                 
           05  FILLER            PIC X(2)            VALUE SPACES.              
           05  D1-SPLIT-AMT      PIC ZZZ,ZZ9.99-     VALUE ZERO.                
           05  D1-STAR-1         PIC X               VALUE SPACES.              
           05  FILLER            PIC X(4)            VALUE SPACES.              
           05  D1-SPLIT-AMT-SC   PIC ZZZ,ZZ9.99-     VALUE ZERO.                
           05  D1-STAR-2         PIC X               VALUE SPACE.               
           05  FILLER            PIC X(1)            VALUE SPACES.              
           05  D1-COMM-PAID-AMT PIC ZZZ,ZZ9.99-      VALUE ZERO.                
           05  D1-STAR-3         PIC X               VALUE SPACE.               
           05  FILLER            PIC XXX             VALUE SPACES.              
           05  D1-SC-PAID-AMT    PIC ZZZ,ZZ9-        VALUE ZERO.                
           05  D1-STAR-4         PIC X               VALUE SPACE.               
           05  FILLER            PIC X(1)            VALUE SPACES.              
           05  D1-FEES-PAID      PIC ZZZ,ZZZ.ZZ-     VALUE ZERO.                
           05  D1-FEES-PAID-X REDEFINES D1-FEES-PAID       PIC X(11).           
       01  WS-ENDS                            PIC  X(32)  VALUE                 
                                      '** GWCOCRCX W-S ENDS HERE **'.           
      /                                                                         
       01  SPECIAL-LINES.                                                       
           05  AMEND-LINE.                                                      
               10  AMD-CC        PIC X               VALUE '0'.                 
               10  AMEND-MTH     PIC XXX             VALUE SPACES.              
               10  FILLER        PIC X               VALUE SPACE.               
               10  AMEND-YR      PIC 99              VALUE ZERO.                
               10  FILLER        PIC X(94)           VALUE SPACES.              
               10  AMEND-AMT     PIC ZZZZZZ,ZZ9.99-  VALUE ZERO.                
               10  FILLER        PIC XX              VALUE '**'.                
               10  FILLER        PIC X(17)           VALUE SPACES.              
                                                                                
      /                                                                         
       01  WS-PARAMETERS.                                                       
                                                                                
           05  FILLER                     PIC X(32)       VALUE                 
                                                      'W-S PARAMETERS'.         
           05  WS-PREV-KEY.                                                     
REN            10  WS-PREV-GROUP          PIC X(7)        VALUE SPACES.         
               10  WS-PREV-ACCOUNT        PIC XXX         VALUE SPACES.         
               10  WS-PREV-AGENT          PIC 9(6)        VALUE ZERO.           
               10  WS-PREV-EFF-DATE       PIC X(4)        VALUE SPACES.         
                                                                                
           05  NEW-ACCOUNT-IND            PIC X           VALUE SPACE.          
               88  NEW-ACCOUNT-READ                       VALUE 'Y'.            
           05  NEW-AGENT-IND              PIC X           VALUE SPACE.          
               88  NEW-AGENT-READ                         VALUE 'Y'.            
           05  WS-COV-TYPE                PIC X           VALUE SPACE.          
           05  WS-COMP-TYPE               PIC X           VALUE SPACE.          
           05  WS-COMP-DISP               PIC X           VALUE SPACE.          
           05  WS-RECON-IND               PIC X           VALUE SPACE.          
           05  WS-COMP-REASON             PIC X           VALUE SPACE.          
           05  WS-CONT-PROC-FLAG          PIC X           VALUE 'Y'.            
           05  LANGUAGE-IND               PIC X           VALUE 'N'.            
               88  ENGLISH                                VALUE 'E'.            
               88  FRENCH                                 VALUE 'F'.            
           05  SAVE-LANGUAGE-IND               PIC X.                           
                                                                                
           05  GNUM-TABLE       COMP      PIC S9(4)       VALUE +02.            
           05  CURR-RETURN.                                                     
               10  RETURN-CURRENCY        PIC XXX         VALUE SPACES.         
               10  FILLER REDEFINES RETURN-CURRENCY.                            
                   15  RETURN-CURRENCY-1     PIC X.                             
                   15  FILLER                PIC XX.                            
               10  FILLER                 PIC X(47)       VALUE SPACES.         
                                                                                
           05  ERROR-SWITCH               VALUE '0'       PIC X.                
           05  EOF-SWITCH                 VALUE 'N'       PIC X.                
               88  EOF-ON-EXTRACT         VALUE 'Y'.                            
           05  ONE-STAR-SWITCH            VALUE 'N'       PIC X.                
               88  ONE-STAR-PRINTED       VALUE 'Y'.                            
           05  AGENT-SWITCH               VALUE 'N'       PIC X.                
               88  AGENT-INFO-FOUND       VALUE 'Y'.                            
           05  FEES-SWITCH                VALUE 'N'       PIC X.                
               88  FEES-WERE-PAID         VALUE 'Y'.                            
           05  SCALE-SWITCH               VALUE 'N'       PIC X.                
               88  SCALE-FOUND            VALUE 'Y'.                            
           05  RATE-SWITCH                VALUE 'N'       PIC X.                
               88  RATE-FOUND             VALUE 'Y'.                            
           05  WS-ACCUM-SWITCH            VALUE 'N'       PIC X.                
               88  ALL-ACCUMS-FOUND       VALUE 'Y'.                            
           05  WS-AGENT-BRANCH                            PIC X(5).             
           05  TRL-SUB                    VALUE +0        PIC S9.               
           05  AGT-SUB                    VALUE +0        PIC S9.               
           05  QDATE-FORMATAD             VALUE 'AD'      PIC XX.       YEAR2000
           05  QDATE-FORMATAB             VALUE 'AB'      PIC XX.               
           05  QDATE-FORMATCA             VALUE 'CA'      PIC XX.               
           05  QDATE-FORMATAF             VALUE 'AF'      PIC XX.       YEAR2000
           05  GPSY-RETURN-CODE           VALUE SPACES    PIC XXX.              
           05  NAME-RETURN-CODE           VALUE SPACES    PIC XXX.              
           05  WS-NUMBER-OF-STATEMENTS    VALUE ZERO      PIC S9(3).            
      /                                                                         
           05  WS-TOTALS                COMP-3.                                 
               10  WS-PREM-PAID                 PIC S9(9)V99 VALUE ZERO.        
               10  WS-COMM-EARNED               PIC S9(9)V99 VALUE ZERO.        
               10  WS-SC-EARNED                 PIC S9(9)V99 VALUE ZERO.        
               10  WS-AGENT-EARNED-AMT          PIC S9(9)V99 VALUE ZERO.        
               10  WS-SPLIT-AMT                 PIC S9(9)V99 VALUE ZERO.        
               10  WS-ADVANCED-AMT              PIC S9(9)V99 VALUE ZERO.        
               10  WS-RECON-AMT                 PIC S9(9)V99 VALUE ZERO.        
               10  WS-SPLIT-AMT-SC              PIC S9(9)V99 VALUE ZERO.        
               10  WS-ADVANCED-AMT-SC           PIC S9(9)V99 VALUE ZERO.        
               10  WS-RECON-AMT-SC              PIC S9(9)    VALUE ZERO.        
               10  WS-FEES-PAID                 PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-PREM-PAID             PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-COMM-EARNED           PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-S-C-EARNED            PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-SPLIT-AMT             PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-S-C-SPLIT-AMT         PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-COMM-PAID             PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-S-C-PAID              PIC S9(9)    VALUE ZERO.        
               10  WS-TOT-RECON-AMT             PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-FEES-PAID             PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-REG-RECON-AMT         PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-REG-RECON-AMT-S-C     PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-ALL-RECON-AMTS        PIC S9(9)V99 VALUE ZERO.        
               10  WS-TOT-ALL-RECON-AMTS-S-C    PIC S9(9)    VALUE ZERO.        
               10  TOT-SC-PAID-LIFE-FY          PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-PAID-LTD-FY           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-PAID-A-S-FY           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-PAID-LIFE-RN          PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-PAID-LTD-RN           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-PAID-A-S-RN           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-EARN-LIFE-FY          PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-EARN-LTD-FY           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-EARN-A-S-FY           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-EARN-LIFE-RN          PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-EARN-LTD-RN           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-EARN-A-S-RN           PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-AMEND-RECOV-LIFE-FY   PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-AMEND-RECOV-LTD-FY    PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-AMEND-RECOV-A-S-FY    PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-AMEND-RECOV-LIFE-RN   PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-AMEND-RECOV-LTD-RN    PIC S9(9)V99 VALUE ZERO.        
               10  TOT-SC-AMEND-RECOV-A-S-RN    PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-PAID-LIFE-FY        PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-PAID-LTD-FY         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-PAID-A-S-FY         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-PAID-LIFE-RN        PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-PAID-LTD-RN         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-PAID-A-S-RN         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-EARN-LIFE-FY        PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-EARN-LTD-FY         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-EARN-A-S-FY         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-EARN-LIFE-RN        PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-EARN-LTD-RN         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-EARN-A-S-RN         PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-AMEND-RECOV-LIFE-FY PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-AMEND-RECOV-LTD-FY  PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-AMEND-RECOV-A-S-FY  PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-AMEND-RECOV-LIFE-RN PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-AMEND-RECOV-LTD-RN  PIC S9(9)V99 VALUE ZERO.        
               10  TOT-COMM-AMEND-RECOV-A-S-RN  PIC S9(9)V99 VALUE ZERO.        
                                                                                
           05  WORK-AMOUNTS                         COMP-3.                     
               10  WS-SPLIT-RATE                PIC S9V9999  VALUE ZERO.        
               10  WS-SPLIT-PERCENT             PIC S999V99  VALUE ZERO.        
               10  AMEND-RECOV-AMT              PIC S9(9)V99 VALUE ZERO.        
               10  RECON-SC-LIFE-FY             PIC S9(9)V99 VALUE ZERO.        
               10  RECON-SC-LTD-FY              PIC S9(9)V99 VALUE ZERO.        
               10  RECON-SC-A-S-FY              PIC S9(9)V99 VALUE ZERO.        
               10  RECON-SC-LIFE-RN             PIC S9(9)V99 VALUE ZERO.        
               10  RECON-SC-LTD-RN              PIC S9(9)V99 VALUE ZERO.        
               10  RECON-SC-A-S-RN              PIC S9(9)V99 VALUE ZERO.        
               10  RECON-COMM-LIFE-FY           PIC S9(9)V99 VALUE ZERO.        
               10  RECON-COMM-LTD-FY            PIC S9(9)V99 VALUE ZERO.        
               10  RECON-COMM-A-S-FY            PIC S9(9)V99 VALUE ZERO.        
               10  RECON-COMM-LIFE-RN           PIC S9(9)V99 VALUE ZERO.        
               10  RECON-COMM-LTD-RN            PIC S9(9)V99 VALUE ZERO.        
               10  RECON-COMM-A-S-RN            PIC S9(9)V99 VALUE ZERO.        
      /                                                                         
           05  WS-PSMPOLICY-YEAR                COMP-3    PIC S9(3).            
                                                                                
           05  WS-PSMNXT-RNEW-DATE.                                             
      * VOCOMM VOPSM/PSM                                                        
               10  WS-PSMNXT-RNEW-YEAR          COMP-3    PIC S999.             
               10  WS-PSMNXT-RNEW-DAY           COMP-3    PIC S999.             
                                                                                
           05  WS-ALIS-RUN-DATE.                                                
               10  FILLER                       COMP-3    PIC S999.             
               10  FILLER                       COMP-3    PIC S999.             
                                                                                
           05  TEMP-ACCOUNT.                                                    
               10  FILLER                              PIC X VALUE '-'.         
               10  TEMP-ACCT                           PIC XXX.                 
                                                                                
           05  WS-START-DATE.                                                   
               10  WS-START-YEAR                COMP-3    PIC S999.             
               10  WS-START-DAY                 COMP-3    PIC S999.             
                                                                                
           05  WS-DTL-DATE.                                                     
               10  WS-DTL-DAY                             PIC 99.               
               10  WS-DTL-MTH                             PIC XXX.              
               10  WS-DTL-YR                              PIC 9999.     YEAR2000
                                                                                
           05  WS-PREM-DUE-DATE-EXT.                                            
               10  WS-PREM-DUE-YR-EXT                     PIC 9(4).     YEAR2000
               10  WS-PREM-DUE-MTH-EXT                    PIC 99.       YEAR2000
               10  WS-PREM-DUE-DAY-EXT                    PIC 99.       YEAR2000
                                                                                
           05  WS-COMM-EFF-DATE-EXT.                                            
               10  WS-COMM-EFF-YR-EXT                     PIC 9(4).     YEAR2000
               10  WS-COMM-EFF-MTH-EXT                    PIC 99.       YEAR2000
               10  WS-COMM-EFF-DAY-EXT                    PIC 99.       YEAR2000
                                                                                
           05  WS-FOGL-CODE         PIC 9(10).                                  
           05  FILLER          REDEFINES WS-FOGL-CODE.                          
               10  WS-FOGL-BYTE     PIC 9 OCCURS 10 TIMES.                      
                                                                                
       01  NAME-EXPAND-AREA.                                                    
           05  NAME-AND-DEL         OCCURS 6 TIMES.                             
               10  GROUP-NAME       PIC X(30).                                  
               10  FILLER           PIC X.                                      
                                                                                
       01  DATE-PARAMETERS.                                                     
                                 COPY GARDATEP.                                 
      /                                                                         
       COPY GWCORRCD.                                                           
                                                                                
       COPY GWCORRRD.                                                           
      /                                                                         
       COPY GWCORC71.                                                           
      /                                                                         
      *01  GCOMRLSE                                                             
       COPY GCOMRLS7.                                                           
      /                                                                         
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------------                     
      *          DATASERVER RECORDS                                             
      *----------------------------------------------------                     
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
       01  LOGICAL-RECORD-NAMES.                                                
           COPY HCSLRNAM.                                                       
                                                                                
      * VOCOMM VOPSM/PSM                                                        
      *----------------------------------------------------                     
      *          GAEDATSR DYNAMIC CALL PROGRAM                                  
      *----------------------------------------------------                     
       01  GAEDATSR                 PIC X(8) VALUE 'GAEDATSR'.                  
      *----------------------------------------------------                     
      *          GIPSY ACCESS MODULE PARMS                                      
      *----------------------------------------------------                     
       01  GACCDMA7-PS-PARMS.                                                   
           05  GACCDMA7-PS-FUNC      PIC S9(4)    COMP   VALUE +18.             
REN        05  GACCDMA7-PS-GROUP     PIC S9(7)    COMP-3.                       
           05  GACCDMA7-PS-ACCT      PIC X(3).                                  
           05  GACCDMA7-PS-CERT      PIC S9(9)    COMP-3.                       
           05  GACCDMA7-PS-WORK      PIC X(9).                                  
       01  GACCDMA7-PS-RETURN        PIC X(3).                                  
           88  GACCDMA7-PS-RET-OK                 VALUE '   '.                  
           88  GACCDMA7-PS-EOF                    VALUE 'R01'.                  
           88  GACCDMA7-PS-NOT-FOUND              VALUE 'R01'.                  
           88  GACCDMA7-PS-DISK-ERROR             VALUE 'R03'.                  
           88  GACCDMA7-PS-FUNC-INVALID           VALUE 'R09'.                  
                                                                                
      *                    ZACCVSAM PARAMATERS                        *         
      *---------------------------------------------------------------*         
      *   AGENT ADDRESS FILE (FROM AGI)                                         
      *---------------------------------------------------------------*         
       01  ZACCVSAM-AGTADDR.                                                    
           05  PARAM1-AGTADDR.                                                  
               10  DDNAME-AGTADDR          PIC X(7)    VALUE 'VSDSI30'.         
               10  ACCTYPE-AGTADDR         PIC X(5)    VALUE 'KEYED'.           
               10  RECTYPE-AGTADDR         PIC X       VALUE 'F'.               
               10  FUNCTION-AGTADDR        PIC X(6)    VALUE 'GETRAN'.          
               10  ERRCODE-AGTADDR.                                             
                   15  ERRCODE-AGTADDR-1   PIC X(3).                            
                   15  ERRCODE-AGTADDR-EOF PIC X(2).                            
               10  READCT-AGTADDR          PIC S9(7) VALUE +0 COMP-3.           
               10  WRITECT-AGTADDR         PIC S9(7) VALUE +0 COMP-3.           
               10  UPDATECT-AGTADDR        PIC S9(7) VALUE +0 COMP-3.           
               10  DELETECT-AGTADDR        PIC S9(7) VALUE +0 COMP-3.           
               10  RECLGTH-AGTADDR         PIC S9(4)          COMP.             
             05  PARAM2-AGTADDR.                                                
                 10  PARAM2-AGENT-CODE     PIC X(6)  VALUE SPACES.              
                                                                                
      *---------------------------------------------------------------*         
      *01  AGENT-ADDRESS-RECORD.                                                
           COPY AGTADDR.                                                        
      *---------------------------------------------------------------*         
                                                                                
      *---------------------------------------------------------------*         
      *   AGENT ADDRESS FILE (FROM AFFIRM)                                      
      *---------------------------------------------------------------*         
       01  ZACCVSAM-SRPRODVS.                                                   
           05  PARAM1-PRODVS.                                                   
               10  DDNAME-PRODVS          PIC X(7)    VALUE 'VSDSI31'.          
               10  ACCTYPE-PRODVS         PIC X(5)    VALUE 'KEYED'.            
               10  RECTYPE-PRODVS         PIC X       VALUE 'F'.                
               10  FUNCTION-PRODVS        PIC X(6)    VALUE 'GETRAN'.           
               10  ERRCODE-PRODVS.                                              
                   15  ERRCODE-PRODVS-1   PIC X(3).                             
                   15  ERRCODE-PRODVS-EOF PIC X(2).                             
               10  READCT-PRODVS          PIC S9(7) VALUE +0 COMP-3.            
               10  WRITECT-PRODVS         PIC S9(7) VALUE +0 COMP-3.            
               10  UPDATECT-PRODVS        PIC S9(7) VALUE +0 COMP-3.            
               10  DELETECT-PRODVS        PIC S9(7) VALUE +0 COMP-3.            
               10  RECLGTH-PRODVS         PIC S9(4)          COMP.              
             05  PARAM2-PRODVS.                                                 
                 10  PARAM2-PRODVS-AGENT  PIC X(6)  VALUE SPACES.               
                                                                                
      *---------------------------------------------------------------*         
      *01  SRPRODVS-RECORD.                                                     
           COPY SRPRODVS.                                                       
      *---------------------------------------------------------------*         
                                                                                
      *01  AGENT-NAME-FILE                                                      
       COPY  EAGNFILE.                                                          
                                                                                
       01  GFMAGENT-PARMS.                                                      
           05  GFMAGENT-FUNCTION      PIC X(6)         VALUE SPACES.            
           05  GFMAGENT-ERROR         PIC X(5)         VALUE SPACES.            
           05  GFMAGENT-KEY.                                                    
               10  GFMAGENT-CODE      PIC S9(7) COMP-3 VALUE ZERO.              
               10  GFMAGENT-ACCOUNT   PIC X            VALUE SPACE.             
                                                                                
      *-----------------------------------------------------------------        
      *   CHECK FOR BAD ADDRESS ON THE AGTADR FILE                              
      *-----------------------------------------------------------------        
       01  ADDRESS-VALIDITY-TESTS.                                              
           05  ADDRESS1-CHECK         PIC X(25).                                
               88  INVALID-ADDRESS1-FOUND                                       
                    VALUE 'ADDRESS UNKNOWN          ',                          
                          'UNKNOWN ADDRESS          ',                          
                          'NO ADDRESS ON FILE       '.                          
                                                                                
           05  ADDRESS2-CHECK         PIC X(25).                                
               88  INVALID-ADDRESS2-FOUND                                       
                    VALUE 'ADDRESS UNKNOWN          ',                          
                          'UNKNOWN ADDRESS          ',                          
                          'NO ADDRESS ON FILE       '.                          
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   MESSAGES USED FOR THE ERROR LOGIC USING THE CALL TO WTL     *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
       01  WTL-AREA.                                                            
           05  WTL-FLAG               PIC X            VALUE 'B'.               
           05  WTL-REPLY-YES          PIC XXX          VALUE 'YES'.             
           05  WTL-REPLY-NO           PIC XXX          VALUE 'NO '.             
           05  WTL-REPLY              PIC XXX          VALUE SPACES.            
           05  WTL-REPLY-AREA         PIC X(10)        VALUE SPACES.            
       01  WTL-MESSAGE-AREA.                                                    
           05  FILLER          COMP-3 PIC S9(3)        VALUE +121.              
           05  FILLER                 PIC X            VALUE SPACES.            
           05  WTL-MESSAGE            PIC X(120)       VALUE SPACES.            
                                                                                
       01  WTL-ERROR-MESSAGES.                                                  
           05  ERR-MESS1.                                                       
               10  FILLER             PIC X(40)        VALUE                    
                   '*** INVALID RUNDATE FORMAT             '.                   
           05  ERR-MESS2.                                                       
               10  FILLER             PIC X(50)        VALUE                    
                   '*** FILE CONTROL DATE DOES NOT MATCH RUNDATE'.              
           05  ERR-MESS3.                                                       
               10  FILLER             PIC X(50)        VALUE                    
                   '*** SEVERE ERROR - CHECK RESTART JCL'.                      
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *         DATABASE - CONTROL RECORD DESCRIPTION                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCNTL                                                               
CPYNME     COPY GCICNTL.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GROUP-ACCOUNT RECORD DESCRIPTION          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GRACCT-ACCUM RECORD DESCRIPTION           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORACCUM                                                              
CPYNME     COPY GCIACCUM.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - COMPENSATION RECORD DESCRIPTION           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - AGENT RECORD DESCRIPTION                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - GFO RECORD-DESCRIPTION                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORGFO                                                                
CPYNME     COPY GCIGFO.                                                         
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          DATABASE - TRANSACTIONS RECORD DESCRIPTION           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * GWCORTRANS                                                              
CPYNME     COPY GCITRAN.                                                        
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          FIELD-OFFICE RECORD DESCRIPTION                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
MAN02 *%   COPY IDMS FIELD-OFFICE.                                              
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *          GIPSY - RECORDS                                      *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
FXXTOK                                '** GC2RC2 W-S ENDS HERE **'.             
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO02'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
                                                                                
       01  FDOF-PARMS.                                                          
           05  FDOF-PARM1.                                                      
               10  FDOF-DDNAME       PIC X(7)       VALUE 'VSDSI89'.            
               10  FDOF-ACCTTYPE     PIC X(5)       VALUE 'KEYED'.              
               10  FDOF-RECTYPE      PIC X(1)       VALUE 'V'.                  
               10  FDOF-FUNCTION     PIC X(6)       VALUE 'GETRAN'.             
               10  FDOF-ERRCODE      PIC X(5)       VALUE SPACES.               
               10  FDOF-READCT       PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-WRITECT      PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-UPDATECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-DELETECT     PIC S9(7)      VALUE +0    COMP-3.         
               10  FDOF-RECLGTH      PIC S9(4)      VALUE +0    COMP.           
           05  FDOF-PARM2.                                                      
               10  FDOF-BRANCH       PIC X(5)       VALUE SPACES.               
                                                                                
MAN02  COPY FDOFFILE.                                                           
                                                                                
       01  FDOFFILE                         PIC X(16) VALUE 'FDOFFILE'.         
                                                                                
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2RC2'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       MAINLINE.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                PROGRAM MAINLINE                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 000-INITIALIZE THRU 099-EXIT.                                
           IF WS-CONT-PROC-FLAG = 'Y'                                           
               PERFORM 200-PROCESS-GROUP-ACCOUNTS THRU 209-EXIT                 
                   UNTIL EOF-ON-EXTRACT.                                        
           PERFORM 100-END-OF-JOB.                                              
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'CLOSE FILES'      TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 210-READ-VCM-GIPSY THRU 210-READ-VCM-GIPSY-EXIT.             
                                                                                
           MOVE +1                       TO GACCDMA7-PS-FUNC.                   
           CALL 'GACCDMA7'            USING GACCDMA7-PS-PARMS                   
                                            GACCDMA7-PS-RETURN                  
                                            PSMASTE7.                           
                                                                                
      * VOCOMM VOPSM/PSM                                                        
           MOVE SPACES TO LOGICAL-RECORD-NAME.                                  
           CALL GAEDATSR    USING FINISH-LR                                     
                                  LOGICAL-RECORD-NAME                           
                                  ICBM.                                         
                                                                                
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       000-INITIALIZE.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     BIND DB RECORDS                                           *         
      *     READY DB AREA TO BE ACCESSED                              *         
      *     GET RUN DATE                                              *         
      *     GET FILE CONTROL DATE                                     *         
      *     EDIT FILE CONTROL DATE TO RUN DATE                        *         
      *     GET CONTROL RECORD AND EDIT CONTROL INDICATORS.           *         
      *     MODIFY CONTROL RECORD TO INDICATE THAT THIS STEP HAS RUN. *         
      *     PRINT HEADINGS ON ERROR REPORT                            *         
      *     PRINT ERROR REPORT HEADINGS                               *         
      *     READ FIRST INPUT EXTRACT RECORD.                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * VOCOMM VOPSM/PSM                                                        
FXXTOK     MOVE 'GC2RC2'   TO ICBM-PROGRAM-NAME.                                
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
                                                                                
FXXTOK     MOVE 'GC2RC2' TO PROGRAM-NAME.                                       
      *%   BIND RUN-UNIT.                                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND GWCORCNTL.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGRACCT.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORCOMP.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORACCUM.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORGFO.                                                       
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORAGENT.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORTRANS.                                                     
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND FIELD-OFFICE.                                                   
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA3 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-FDOFILE-AREA USAGE-MODE IS RETRIEVAL.                       
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES             TO VGWI-SOURCE-SYSTEM.                       
           MOVE 'OPEN FILES'       TO VGWI-REQUEST.                             
           MOVE SPACES             TO VGWI-COVERAGE-TYPE.                       
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           MOVE 'GIPSY EXPANDED'   TO VGWI-LR-NAME.                             
           PERFORM 210-READ-VCM-GIPSY THRU 210-READ-VCM-GIPSY-EXIT.             
                                                                                
           MOVE +0                    TO WS-SUB2.                               
           PERFORM 7000-FIND-HEADINGS THRU 7000-EXIT                            
                                      UNTIL DLSH-RET-CODE = 4.                  
           PERFORM 7010-MOVE-HEADINGS THRU 7010-EXIT.                           
           MOVE 0   TO H1-PAGE.                                                 
           MOVE 0   TO H1-PAGE-F.                                               
           PERFORM 8010-READ-RUNDATE  THRU 8010-EXIT.                           
MAN02      CALL QDATEQ2 USING QDATE-FORMATCA                                    
MAN02                         PROGRAM-RUN-DATE                                  
MAN02                         WS-ALIS-RUN-DATE.                                 
           IF WS-ALIS-RUN-DATE = '****'                                         
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS1    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           PERFORM 300-READ-EXTRACT THRU 300-EXIT.                              
           MOVE EXT-RECON-COMM-RECORD TO FILE-CONTROL-DATE-RECORD.              
           PERFORM INIT-FIELDS THRU INIT-FIELDS-EXIT                            
                               VARYING WS-SUB                                   
                               FROM +1                                          
                               BY +1                                            
                               UNTIL WS-SUB > +10.                              
           MOVE INIT-CR-RECORD TO GCOMRLSE.                                     
                                                                                
           IF FILE-CONTROL-DATE EQUAL WS-ALIS-RUN-DATE                          
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS2    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
      *%   OBTAIN FIRST GWCORCNTL WITHIN GW-COMP-AREA1.                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 15 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORCNTL                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           IF COMM-SCR-RECON-IND    = 'N' AND                                   
              NAP-RECON-IND         = 'N' AND                                   
              RECON-DATE-UPDATE-IND = 'N'                                       
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE SPACES       TO WTL-MESSAGE                                 
               MOVE ERR-MESS3    TO WTL-MESSAGE                                 
               MOVE WTL-REPLY-NO TO WTL-REPLY                                   
               PERFORM WTL-TO-OPERATOR THRU WTL-TO-OPERATOR-EXIT                
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
           MOVE 'Y' TO COMM-SCR-RECON-IND.                                      
      *%   MODIFY GWCORCNTL.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 16 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORCNTL                                        
MAN02                 FCCSPL-GWCORCNTL                                          
MAN02                 GWCORCNTL                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           MOVE 'Y' TO WS-CONT-PROC-FLAG.                                       
           MOVE WS-ALIS-RUN-DATE TO COMP-PROCESS-DATE.                          
           MOVE PROGRAM-RUN-DATE TO H1-DATE                                     
                                    ACTION-RUN-DATE.                            
MAN02      CALL QDATEQ2 USING QDATE-FORMATAF                                    
MAN02                         WS-ALIS-RUN-DATE                                  
MAN02                         H1-DATE-F.                                        
           MOVE ACTION-HDG-1 TO DLSA-RECORD                                     
           PERFORM 1200-PRINT-MESSAGE.                                          
           MOVE ACTION-HDG-2 TO DLSA-RECORD                                     
           PERFORM 1200-PRINT-MESSAGE.                                          
           MOVE ACTION-HDG-3 TO DLSA-RECORD                                     
           PERFORM 1200-PRINT-MESSAGE.                                          
                                                                                
           PERFORM 300-READ-EXTRACT THRU 300-EXIT.                              
                                                                                
       099-EXIT.                                                                
           EXIT.                                                                
       100-END-OF-JOB.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    PRINT LAST DETAIL LINE                                     *         
      *    RECONCILE LAST ACCOUNT                                     *         
      *    PRINT LAST TOTAL LINES                                     *         
      *    CLOSE PRINT FILES                                          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE WS-NUMBER-OF-STATEMENTS TO TOTAL-STATEMENTS.                    
           MOVE TOTAL-LINE TO DLSA-RECORD.                                      
           PERFORM 1200-PRINT-MESSAGE.                                          
           MOVE END-LINE TO DLSA-RECORD.                                        
           PERFORM 1200-PRINT-MESSAGE.                                          
           MOVE 4 TO DLSA-RET-CODE                                              
                     DLSR-RET-CODE                                              
                     DLSWE-RET-CODE                                             
                     DLSWF-RET-CODE.                                            
           PERFORM 8010-READ-RUNDATE THRU 8010-EXIT.                            
           PERFORM 1000-PRINT-A-LINE.                                           
           PERFORM 1200-PRINT-MESSAGE.                                          
      /                                                                         
       200-PROCESS-GROUP-ACCOUNTS.                                              
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     INVOKE GET-GROUP RECORD                                   *         
      *     INVOKE FORMAT GROUP-HEADINGS                              *         
      *     INVOKE INVOKE PROCESS-AGENT                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'N' TO NEW-ACCOUNT-IND.                                         
           PERFORM 220-GET-GROUP-RECORDS.                                       
           PERFORM 240-FORMAT-GROUP-HEADINGS.                                   
           MOVE EXT-COMM-SORT-KEY TO WS-PREV-KEY.                               
           PERFORM 250-PROCESS-AGENTS                                           
               UNTIL NEW-ACCOUNT-READ OR EOF-ON-EXTRACT.                        
       209-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------                     
      * VOCOMM VCM/GIPSY                                                        
       210-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       210-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
       220-GET-GROUP-RECORDS.                                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    GET GRACCT RECORD                                          *         
      *    GET GIPSY MASTER RECORD                                    *         
      *    EXPAND GIPSY MASTER                                        *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE EXT-COMM-GROUP-NUMBER TO GROUP-NUMBER OF GWCORGRACCT.           
           MOVE EXT-COMM-GROUP-ACCOUNT TO GR-ACCOUNT OF GWCORGRACCT.            
      *%   OBTAIN CALC GWCORGRACCT.                                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      * VOCOMM VOPSM/PSM                                                        
           MOVE LOW-VALUES               TO VOPSMASTER-RECORD.                  
           MOVE EXT-COMM-GROUP-NUMBER-N  TO VOPSM-GROUP-NUMBER.                 
           MOVE LR-VO-PSMASTER-R         TO LOGICAL-RECORD-NAME.                
           CALL GAEDATSR              USING OBTAIN-KEYED                        
                                            VOPSMASTER-RECORD                   
                                            ICBM.                               
           IF LR-STATUS-OK                                                      
              MOVE 'B' TO VDATE-REQ-SERVICE                                     
              MOVE 'B' TO VDATE-REQ-BASIS                                       
              MOVE '1' TO VDATE-REQ-DETAIL                                      
              MOVE 'E' TO VDATE-REQ-LANGUAGE                                    
              MOVE VOPSM-NXT-RNEW-YEAR  TO VDATE1-YYYY                          
              MOVE VOPSM-NXT-RNEW-MONTH TO VDATE1-MM                            
              MOVE VOPSM-NXT-RNEW-DAY   TO VDATE1-DD                            
              CALL GC2DATE USING DATE-PARAMETERS                                
                                                                                
              MOVE VOPSM-POLICY-YEAR    TO WS-PSMPOLICY-YEAR                    
              MOVE VDATE-ALIS-YEAR1     TO WS-PSMNXT-RNEW-YEAR                  
              MOVE VDATE-ALIS-DAY1      TO WS-PSMNXT-RNEW-DAY                   
           ELSE                                                                 
FXXTOK        MOVE LOW-VALUES               TO PSMASTE7                         
              MOVE EXT-COMM-GROUP-NUMBER-N  TO GACCDMA7-PS-GROUP                
              MOVE HIGH-VALUES              TO GACCDMA7-PS-ACCT                 
              CALL 'GACCDMA7'            USING GACCDMA7-PS-PARMS                
                                               GACCDMA7-PS-RETURN               
FXXTOK                                         PSMASTE7                         
                                                                                
              MOVE PSMPOLICY-YEAR       TO WS-PSMPOLICY-YEAR                    
              MOVE PSMNXT-RNEW-YR       TO WS-PSMNXT-RNEW-YEAR                  
              MOVE PSMNXT-RNEW-DAY      TO WS-PSMNXT-RNEW-DAY.                  
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ KEYED (VCM/GIPSY FILES)                                           
           MOVE SPACES TO VOGPWRAP-OUTPUT                                       
                          VOGPW-DATA-RECORD.                                    
           MOVE SPACES                    TO VGWI-SOURCE-SYSTEM.                
           MOVE 'READ KEYED'              TO VGWI-REQUEST.                      
           MOVE SPACES                    TO VGWI-COVERAGE-TYPE.                
           MOVE EXT-COMM-GROUP-NUMBER-N   TO VGWI-GROUP.                        
           MOVE EXT-COMM-GROUP-ACCOUNT    TO VGWI-ACCOUNT.                      
           MOVE 'GIPSY EXPANDED'          TO VGWI-LR-NAME.                      
           PERFORM 210-READ-VCM-GIPSY THRU 210-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-OK                                                       
FXXTOK        MOVE VOGPW-DATA-RECORD TO GMASTER7                                
           ELSE                                                                 
              IF VGWO-RET-SEVERE-ERROR                                          
FXXTOK           GO TO 799-SQL-STATUS.                                          
                                                                                
      ******************************************************************        
      *  SEP/90 M. PRANGE.                                                      
      *       - COMMENTED OUT THIS LOGIC WHICH FUDGED THE VALUE FROM            
      *         PSMPOLICY-YEAR.                                                 
      ******************************************************************        
      *    IF WS-PSMNXT-RNEW-DATE LESS THAN GGINEXT-ANNIVERSARY                 
      *        NEXT SENTENCE                                                    
      *    ELSE                                                                 
      *        SUBTRACT +1 FROM WS-PSMPOLICY-YEAR.                              
      ******************************************************************        
      /                                                                         
       240-FORMAT-GROUP-HEADINGS.                                               
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    EXPAND GROUP NAME                                          *         
      *    IDENTIFY LANGUAGE OF CORRESPONDANCE                        *         
      *    GET SERVICING BRANCH                                       *         
      *    GET SERVICING GFO                                          *         
      *    GET CURRENCY                                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE EXT-COMM-GROUP-NUMBER TO H5-GROUP                               
                                         H5-GROUP-F.                            
           MOVE EXT-COMM-GROUP-ACCOUNT TO H5-ACCOUNT                            
                                          H5-ACCOUNT-F.                         
                                                                                
           CALL 'GZNAEXP7' USING GBNBILLING-NAME-ADDRESS                        
                                 NAME-EXPAND-AREA                               
                                 NAME-RETURN-CODE.                              
                                                                                
           MOVE GROUP-NAME (1) TO GCRL-BILLING-NAME                             
                                  H5-GROUP-NAME                                 
                                  H5-GROUP-NAME-F.                              
                                                                                
           IF  GGILANGUAGE = 'F'                                                
               MOVE 'F' TO LANGUAGE-IND                                         
           ELSE                                                                 
               MOVE 'E' TO LANGUAGE-IND.                                        
                                                                                
           MOVE SPACES TO H6-EFFECT-DATE.                                       
           MOVE SPACES TO H6-EFFECT-DATE-F.                                     
                                                                                
           IF  FRENCH                                                           
MAN02          CALL QDATEQ2 USING QDATE-FORMATAF                                
MAN02                             GGI-ACCT-EFFECTIVE                            
MAN02                             H6-EFFECT-DATE-F                              
           ELSE                                                                 
MAN02          CALL QDATEQ2 USING QDATE-FORMATAD                                
MAN02                             GGI-ACCT-EFFECTIVE                            
MAN02                             H6-EFFECT-DATE.                               
                                                                                
      ******************************************************                    
      * NOV 90 - A NIKELSKI                                *                    
      ******************************************************                    
           MOVE GGIBRANCH       TO H8-SERVICE-BRANCH                            
                                   H8-SERVICE-BRANCH-F.                         
           MOVE GGIGROUP-OFFICE TO H9-SERVICING-GFO                             
                                   H9-SERVICING-GFO-F.                          
                                                                                
           IF  LAST-RECON-DAY = 365                                             
               MOVE 1 TO WS-START-DAY                                           
               ADD 1 LAST-RECON-YEAR                                            
                   GIVING WS-START-YEAR                                         
           ELSE                                                                 
               ADD 1 LAST-RECON-DAY                                             
                   GIVING WS-START-DAY                                          
               MOVE LAST-RECON-YEAR TO WS-START-YEAR.                           
                                                                                
           MOVE SPACES TO WS-DTL-DATE.                                          
           IF  FRENCH                                                           
MAN02          CALL QDATEQ2 USING QDATE-FORMATAF                                
MAN02                             WS-START-DATE                                 
MAN02                             WS-DTL-DATE                                   
               MOVE WS-DTL-MTH TO H7-FROM-MTH-F                                 
               MOVE WS-DTL-YR TO H7-FROM-YR-F                                   
MAN02          CALL QDATEQ2 USING QDATE-FORMATAF                                
MAN02                             NEXT-RECON-DATE                               
MAN02                             WS-DTL-DATE                                   
               MOVE WS-DTL-MTH TO H7-TO-MTH-F                                   
               MOVE WS-DTL-YR TO H7-TO-YR-F                                     
           ELSE                                                                 
MAN02          CALL QDATEQ2 USING QDATE-FORMATAD                                
MAN02                             WS-START-DATE                                 
MAN02                             WS-DTL-DATE                                   
               MOVE WS-DTL-MTH TO H7-FROM-MTH                                   
               MOVE WS-DTL-YR TO H7-FROM-YR                                     
MAN02          CALL QDATEQ2 USING QDATE-FORMATAD                                
MAN02                             NEXT-RECON-DATE                               
MAN02                             WS-DTL-DATE                                   
               MOVE WS-DTL-MTH TO H7-TO-MTH                                     
               MOVE WS-DTL-YR TO H7-TO-YR.                                      
                                                                                
           MOVE SPACES TO CURR-RETURN.                                          
           CALL 'GNUMTABL' USING GNUM-TABLE                                     
                                 GGICURRENCY                                    
                                 CURR-RETURN.                                   
                                                                                
           IF  RETURN-CURRENCY-1 = GGICURRENCY                                  
               MOVE SPACES TO H8-CURRENCY                                       
                              H8-CURRENCY-F                                     
           ELSE                                                                 
               MOVE RETURN-CURRENCY TO H8-CURRENCY                              
                                       H8-CURRENCY-F.                           
                                                                                
      /                                                                         
       250-PROCESS-AGENTS.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    INVOKE FORMAT AGENT HEADINGS                               *         
      *    INVOKE PRINT AGENT HEADINGS                                *         
      *    INVOKE INITIALIZE AGENT ACCUMULATORS                       *         
      *    INVOKE PROCESS COMPS                                       *         
      *    INVOKE GET AGENT SPLITS                                    *         
      *    INVOKE PRINT DETAIL LINE                                   *         
      *    INVOKE RECONCILE AGENT ACCOUNT                             *         
      *    INVOKE PRINT TOTALS.                                       *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'N' TO NEW-AGENT-IND.                                           
           PERFORM 260-FORMAT-AGENT-HEADINGS THRU 260-EXIT.                     
                                                                                
           IF LANGUAGE-IND = SAVE-LANGUAGE-IND                                  
           AND EXT-COMM-AGENT-NUMBER = A1-AGENT                                 
              NEXT SENTENCE                                                     
           ELSE                                                                 
              PERFORM 263-FORMAT-AGENT-HEADINGS THRU 263-EXIT.                  
                                                                                
           PERFORM 280-PRINT-HEADINGS.                                          
           PERFORM 290-INITIALIZE-FIELDS.                                       
           PERFORM 300-PROCESS-COMPS THRU 300-EXIT                              
               UNTIL NEW-AGENT-READ OR EOF-ON-EXTRACT.                          
                                                                                
           PERFORM 400-GET-AGENT-SPLITS THRU                                    
                   400-GET-AGENT-SPLITS-EXIT.                                   
                                                                                
           PERFORM 670-PRINT-DETAILS THRU 679-EXIT.                             
           PERFORM 700-RECONCILE-FY-SALES-CREDITS.                              
           PERFORM 710-RECONCILE-RN-SALES-CREDITS.                              
           PERFORM 720-RECONCILE-FY-COMMISSIONS.                                
           PERFORM 730-RECONCILE-RN-COMMISSIONS.                                
           PERFORM 690-PRINT-TOTALS THRU 690-EXIT.                              
                                                                                
       260-FORMAT-AGENT-HEADINGS.                                               
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    INVOKE SEARCH AGENT TRAILERS                               *         
      *    GET AGENT NAME                                             *         
      *    INVOKE GET AGENT SCALES                                    *         
      *    INVOKE GET AGENT SERVICE FEES INFO                         *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE EXT-COMM-AGENT-NUMBER TO H4-AGENT-NUMBER                        
                                         H4-AGENT-NUMBER-F.                     
                                                                                
           MOVE EXT-COMM-AGENT-NUMBER TO GFMAGENT-CODE.                         
           MOVE '0' TO GFMAGENT-ACCOUNT.                                        
           MOVE 'GETRAN' TO GFMAGENT-FUNCTION.                                  
MAN02      CALL 'GFMAGENT' USING GFMAGENT-FUNCTION                              
MAN02                            GFMAGENT-ERROR                                 
MAN02                            AGENT-NAME-FILE                                
MAN02                            GFMAGENT-KEY.                                  
           IF GFMAGENT-ERROR EQUAL TO LOW-VALUES                                
               MOVE AGT-NAME TO H4-AGENT-NAME                                   
                                H4-AGENT-NAME-F                                 
               IF AGT-MLI-CONTRACT-CLASS = (+1 OR +61)                          
                   MOVE 'BROKER NAME    : ' TO H4-AGENT-NAME-LIT                
                   MOVE 'NOM DU COURTIER: ' TO H4-AGENT-NAME-LIT-F              
                   MOVE 'BROKER CODE     : ' TO H4-AGENT-CODE-LIT               
                   MOVE 'CODE DU COURTIER: ' TO H4-AGENT-CODE-LIT-F             
                   MOVE SPACES TO H8-BR-MAIL-IND                                
                   MOVE SPACES TO H8-BR-MAIL-IND-F                              
                   MOVE '-' TO H9-GFO-MAIL-IND                                  
                   MOVE '-' TO H9-GFO-MAIL-IND-F                                
               ELSE                                                             
                   MOVE 'AGENT NAME     : ' TO H4-AGENT-NAME-LIT                
                   MOVE 'NOM DE L''AGENT : ' TO H4-AGENT-NAME-LIT-F             
                   MOVE 'AGENT CODE      : ' TO H4-AGENT-CODE-LIT               
                   MOVE 'CODE DE L''AGENT  :' TO H4-AGENT-CODE-LIT-F            
                   MOVE '-' TO H8-BR-MAIL-IND                                   
                   MOVE '-' TO H8-BR-MAIL-IND-F                                 
                   MOVE SPACES TO H9-GFO-MAIL-IND                               
                   MOVE SPACES TO H9-GFO-MAIL-IND-F                             
           ELSE                                                                 
               MOVE 'AGENT NAME     : ' TO H4-AGENT-NAME-LIT                    
               MOVE 'NOM DE L''AGENT : ' TO H4-AGENT-NAME-LIT-F                 
               MOVE 'AGENT CODE      : ' TO H4-AGENT-CODE-LIT                   
               MOVE 'CODE DE L''AGENT  :' TO H4-AGENT-CODE-LIT-F                
               MOVE SPACES TO H8-BR-MAIL-IND                                    
                              H8-BR-MAIL-IND-F                                  
                              H9-GFO-MAIL-IND                                   
                              H9-GFO-MAIL-IND-F                                 
                              H4-AGENT-NAME                                     
                              H4-AGENT-NAME-F.                                  
                                                                                
           MOVE 0 TO TRL-SUB.                                                   
           MOVE 'N' TO AGENT-SWITCH                                             
                       RATE-SWITCH                                              
                       SCALE-SWITCH                                             
                       FEES-SWITCH.                                             
           PERFORM 270-SEARCH-AGENT THRU 271-EXIT                               
               UNTIL AGENT-INFO-FOUND                                           
               OR    TRL-SUB GREATER THAN 3.                                    
                                                                                
           IF  AGENT-INFO-FOUND                                                 
               MOVE GAGAGENT-BRANCH (TRL-SUB) TO WS-AGENT-BRANCH                
           ELSE                                                                 
               MOVE SPACES   TO WS-AGENT-BRANCH.                                
                                                                                
           IF  AGENT-INFO-FOUND                                                 
               MOVE 0 TO AGT-SUB                                                
               PERFORM 275-SET-SERVICE-FEES-SW THRU 276-EXIT                    
                       UNTIL FEES-WERE-PAID                                     
                       OR    AGT-SUB GREATER THAN 4                             
               MOVE 0 TO AGT-SUB                                                
               PERFORM 277-SEARCH-TRAILER THRU 279-EXIT                         
                       UNTIL SCALE-FOUND                                        
                       OR    RATE-FOUND                                         
                       OR    AGT-SUB GREATER THAN 4.                            
           IF  SCALE-FOUND                                                      
               MOVE 'LIFE & A&S SCALE:' TO H6-LIFE-A-S-LIT                      
               MOVE 'LTD SCALE       :' TO H7-LTD-LIT                           
               MOVE 'BAREME VIE & A&M :' TO H6-LIFE-A-S-LIT-F                   
               MOVE 'BAREME ILD       :' TO H7-LTD-LIT-F                        
               MOVE GAGSCALE (TRL-SUB, AGT-SUB) TO H6-LIFE-A-S-SCALE            
                                                   H6-LIFE-A-S-SCALE-F          
               MOVE GAGLTD-SCALE (TRL-SUB, AGT-SUB) TO H7-LTD-SCALE             
                                                       H7-LTD-SCALE-F           
           ELSE                                                                 
           IF  RATE-FOUND                                                       
               MOVE 'LIFE & A&S RATE :' TO H6-LIFE-A-S-LIT                      
               MOVE 'LTD RATE        :' TO H7-LTD-LIT                           
               MOVE 'TAUX-VIE & A&M   :' TO H6-LIFE-A-S-LIT-F                   
               MOVE 'TAUX-ILD         :' TO H7-LTD-LIT-F                        
               MOVE GAGFLAT-RATE (TRL-SUB, AGT-SUB) TO                          
                    H6-LIFE-A-S-RATE                                            
                    H6-LIFE-A-S-RATE-F                                          
               MOVE GAGLTD-FLAT-RATE (TRL-SUB, AGT-SUB) TO                      
                    H7-LTD-RATE                                                 
                    H7-LTD-RATE-F                                               
               MOVE '%' TO H6-LIFE-A-S-PSIGN                                    
                           H7-LTD-PSIGN                                         
                           H6-LIFE-A-S-PSIGN-F                                  
                           H7-LTD-PSIGN-F                                       
           ELSE                                                                 
               MOVE 'LIFE & A&S SCALE:' TO H6-LIFE-A-S-LIT                      
               MOVE 'LTD SCALE       :' TO H7-LTD-LIT                           
               MOVE 'BAREME VIE & A&M :' TO H6-LIFE-A-S-LIT-F                   
               MOVE 'BAREME ILD       :' TO H7-LTD-LIT-F                        
               MOVE SPACES TO H6-LIFE-A-S-SCALE                                 
                              H6-LIFE-A-S-SCALE-F                               
                              H7-LTD-SCALE                                      
                              H7-LTD-SCALE-F.                                   
                                                                                
           IF  FEES-WERE-PAID                                                   
               MOVE 'SERVICE'  TO H10-VARIABLE                                  
               MOVE 'FEES'     TO H11-VARIABLE                                  
               MOVE 'PAID'     TO H12-VARIABLE                                  
               MOVE 'FRAIS DE' TO H10-VARIABLE-F                                
               MOVE 'SERVICE'  TO H11-VARIABLE-F                                
               MOVE 'PAYES'    TO H12-VARIABLE-F                                
           ELSE                                                                 
               MOVE SPACES TO H10-VARIABLE                                      
                              H11-VARIABLE                                      
                              H12-VARIABLE                                      
                              H10-VARIABLE-F                                    
                              H11-VARIABLE-F                                    
                              H12-VARIABLE-F.                                   
       260-EXIT.                                                                
           EXIT.                                                                
                                                                                
       263-FORMAT-AGENT-HEADINGS.                                               
                                                                                
      *-----------------------------------------------------------------        
      *   POSITION PRINTER AT THE STARTING POINT FOR THE ADDRESS PAGE           
      *-----------------------------------------------------------------        
           MOVE EXT-COMM-AGENT-NUMBER TO A1-AGENT.                              
           MOVE LANGUAGE-IND TO SAVE-LANGUAGE-IND.                              
           MOVE ADDRESS-LINE-01 TO PRINT-LINE.                                  
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
           MOVE '-' TO PRINT-LINE                                               
           PERFORM 1000-PRINT-A-LINE 13 TIMES.                                  
                                                                                
      *-----------------------------------------------------------------        
      *  RESET PAGE COUNTERS                                                    
      *-----------------------------------------------------------------        
           MOVE 0   TO H1-PAGE.                                                 
           MOVE 0   TO H1-PAGE-F.                                               
                                                                                
      *-----------------------------------------------------------------        
      * GET THE AGENT ADDRESS INFO                                              
      * 99998 IS A DUMMY AGENT -- USE DEFAULT ADDRESS                           
      *-----------------------------------------------------------------        
           IF EXT-COMM-AGENT-NUMBER  = '099998'                                 
              PERFORM 267-FORMAT-DEFAULT-ADDRESS                                
                 THRU 267-EXIT                                                  
                 VARYING ADDR-SUB FROM 1 BY 1                                   
                 UNTIL ADDR-SUB > 5                                             
              GO TO 263-EXIT.                                                   
                                                                                
           MOVE EXT-COMM-AGENT-NUMBER TO PARAM2-AGENT-CODE                      
           MOVE SPACES                TO ERRCODE-AGTADDR                        
                                                                                
           CALL 'ZACCVSAM'         USING PARAM1-AGTADDR                         
                                         PARAM2-AGTADDR                         
                                         AGENT-ADDRESS-RECORD.                  
                                                                                
      *-----------------------------------------------------------------        
      *  I CAN'T CHECK FOR A VALID ADDRESS, BUT I CAN CHECK FOR                 
      *  CERTAIN INVALID ADDRESS CHARACTER STRINGS                              
      *-----------------------------------------------------------------        
           MOVE AGENT-ADDRESS-LINE1 TO ADDRESS1-CHECK.                          
           MOVE AGENT-ADDRESS-LINE2 TO ADDRESS2-CHECK.                          
                                                                                
           IF  ERRCODE-AGTADDR NOT = SPACES                                     
           AND ERRCODE-AGTADDR NOT = LOW-VALUES                                 
           OR  ( INVALID-ADDRESS1-FOUND OR                                      
                 INVALID-ADDRESS2-FOUND)                                        
              PERFORM 266-GET-AGENT-ADDRESS2                                    
                 THRU 266-EXIT                                                  
           ELSE                                                                 
              PERFORM 265-FORMAT-ADDRESS-LINES THRU 265-EXIT.                   
                                                                                
       263-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------          
      *  FORMAT PRODUCERS ADDRESS LINES                                         
      *                                                                         
      *  FIRST POSITON THE OUTPUT FAR ENOUGH DOWN THE PAGE TO FIT               
      *  IN THE WINDOW ENVELOPE.                                                
      *  NEXT READING THE SRAGTADDR AREA FORMAT THE ADDRESSES                   
      *  TO CANADA POST STANDARDS.                                              
      *                                                                         
      *---------------------------------------------------------------          
       265-FORMAT-ADDRESS-LINES.                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           MOVE AGENT-NAME1 TO ADDRESS-DETAIL.                                  
           MOVE ADDRESS-LINES TO PRINT-LINE.                                    
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           IF AGENT-NAME2 NOT = SPACES                                          
              MOVE AGENT-NAME2 TO ADDRESS-DETAIL                                
              MOVE ADDRESS-LINES TO PRINT-LINE                                  
              PERFORM 1000-PRINT-A-LINE.                                        
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           IF AGENT-ADDRESS-LINE1 NOT = SPACES                                  
              MOVE AGENT-ADDRESS-LINE1 TO ADDRESS-DETAIL                        
              MOVE ADDRESS-LINES TO PRINT-LINE                                  
              PERFORM 1000-PRINT-A-LINE.                                        
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           IF AGENT-ADDRESS-LINE2 NOT = SPACES                                  
              MOVE AGENT-ADDRESS-LINE2 TO ADDRESS-DETAIL                        
              MOVE ADDRESS-LINES TO PRINT-LINE                                  
              PERFORM 1000-PRINT-A-LINE.                                        
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           IF AGENT-ADDRESS-LINE3 NOT = SPACES                                  
              STRING  AGENT-CITY          DELIMITED BY '  ',                    
                      ', '                DELIMITED BY SIZE                     
                      AGENT-POSTAL-SYMBOL DELIMITED BY SIZE                     
                      '  '                DELIMITED BY SIZE                     
                      AGENT-POSTAL-CODE1  DELIMITED BY SIZE                     
                      ' '                 DELIMITED BY SIZE                     
                      AGENT-POSTAL-CODE2  DELIMITED BY SIZE                     
                 INTO ADDRESS-DETAIL                                            
              MOVE ADDRESS-LINES TO PRINT-LINE                                  
              PERFORM 1000-PRINT-A-LINE.                                        
                                                                                
       265-EXIT.                                                                
           EXIT.                                                                
                                                                                
       266-GET-AGENT-ADDRESS2.                                                  
           MOVE EXT-COMM-AGENT-NUMBER TO PARAM2-PRODVS-AGENT.                   
           MOVE SPACES                TO ERRCODE-PRODVS                         
                                                                                
           CALL 'ZACCVSAM'         USING PARAM1-PRODVS                          
                                         PARAM2-PRODVS                          
                                         SRPRODVS-RECORD.                       
                                                                                
           IF  ERRCODE-PRODVS NOT =  (SPACES AND LOW-VALUES)                    
               PERFORM 267-FORMAT-DEFAULT-ADDRESS                               
                  THRU 267-EXIT                                                 
                  VARYING ADDR-SUB FROM 1 BY 1                                  
                  UNTIL ADDR-SUB > 5                                            
               GO TO 266-EXIT.                                                  
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           MOVE PRODVS-CONTACT-NAME(1) TO ADDRESS-DETAIL.                       
           MOVE ADDRESS-LINES TO PRINT-LINE.                                    
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           IF PRODVS-CONTACT-NAME (2) NOT = SPACES                              
              MOVE PRODVS-CONTACT-NAME (2) TO ADDRESS-DETAIL                    
              MOVE ADDRESS-LINES TO PRINT-LINE                                  
              PERFORM 1000-PRINT-A-LINE.                                        
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           MOVE PRODVS-STREET-ADDR (1) TO ADDRESS-DETAIL.                       
           MOVE ADDRESS-LINES TO PRINT-LINE.                                    
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           IF PRODVS-STREET-ADDR (2) NOT = SPACES                               
              MOVE PRODVS-STREET-ADDR (2) TO ADDRESS-DETAIL                     
              MOVE ADDRESS-LINES TO PRINT-LINE                                  
              PERFORM 1000-PRINT-A-LINE.                                        
                                                                                
           MOVE SPACES TO ADDRESS-DETAIL.                                       
           STRING  PRODVS-CITY         DELIMITED BY '  ',                       
                   ', '                DELIMITED BY SIZE                        
                   PRODVS-PROVINCE     DELIMITED BY SIZE                        
                   '  '                DELIMITED BY SIZE                        
                   PRODVS-POSTAL-CODE  DELIMITED BY SIZE                        
              INTO ADDRESS-DETAIL.                                              
                                                                                
           MOVE ADDRESS-LINES TO PRINT-LINE                                     
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
       266-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------          
      * SINCE PRODUCER/ AGENT NOT FOUND, USE THE DEFAULT ADDRESS                
      *---------------------------------------------------------------          
       267-FORMAT-DEFAULT-ADDRESS.                                              
                                                                                
           MOVE DEFAULT-ADDRESS-DETAIL (ADDR-SUB) TO PRINT-LINE.                
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
       267-EXIT.                                                                
           EXIT.                                                                
                                                                                
       270-SEARCH-AGENT.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     GET AGENT INFORMATION FROM GIPSY MASTER                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           ADD 1 TO TRL-SUB.                                                    
                                                                                
           IF  GAGAGENT-CODE (TRL-SUB) IS NUMERIC                               
           AND GAGAGENT-CODE (TRL-SUB) = EXT-COMM-AGENT-NUMBER                  
               MOVE 'Y' TO AGENT-SWITCH.                                        
                                                                                
       271-EXIT.                                                                
           EXIT.                                                                
                                                                                
       275-SET-SERVICE-FEES-SW.                                                 
                                                                                
           ADD 1 TO AGT-SUB.                                                    
                                                                                
           IF  GAGSTART-YEAR (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTART-DAY  (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTOP-YEAR  (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTOP-DAY   (TRL-SUB, AGT-SUB) IS NUMERIC                      
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 276-EXIT.                                                  
                                                                                
           IF  GAGCOMM-IND (TRL-SUB, AGT-SUB) = 'S'                             
               IF  GAGSTART-DATE (TRL-SUB, AGT-SUB)                             
                       IS LESS THAN NEXT-RECON-DATE                             
               AND GAGSTOP-DATE (TRL-SUB, AGT-SUB)                              
                       IS GREATER THAN LAST-RECON-DATE                          
                   MOVE 'Y' TO FEES-SWITCH                                      
               ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       276-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       277-SEARCH-TRAILER.                                                      
                                                                                
           ADD 1 TO AGT-SUB.                                                    
                                                                                
           IF  GAGSTART-YEAR (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTART-DAY  (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTOP-YEAR  (TRL-SUB, AGT-SUB) IS NUMERIC                      
           AND GAGSTOP-DAY   (TRL-SUB, AGT-SUB) IS NUMERIC                      
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 279-EXIT.                                                  
                                                                                
           IF  GAGCOMM-IND (TRL-SUB, AGT-SUB) = 'S'                             
               GO TO 279-EXIT.                                                  
                                                                                
           IF  GAGSTART-DATE (TRL-SUB, AGT-SUB)                                 
                   IS LESS THAN NEXT-RECON-DATE                                 
           AND GAGSTOP-DATE (TRL-SUB, AGT-SUB)                                  
                   IS GREATER THAN LAST-RECON-DATE                              
               IF GAGFLAT-RATE (TRL-SUB, AGT-SUB) GREATER THAN ZERO             
               OR GAGLTD-FLAT-RATE (TRL-SUB, AGT-SUB) GREATER THAN ZERO         
                   MOVE 'Y' TO RATE-SWITCH                                      
               ELSE                                                             
                   MOVE 'Y' TO SCALE-SWITCH                                     
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       279-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       280-PRINT-HEADINGS.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     PRINT STATEMENT HEADINGS                                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE +0                        TO WS-SUB2.                           
           ADD 1 TO H1-PAGE                                                     
                    H1-PAGE-F.                                                  
           IF  FRENCH                                                           
               MOVE HEADING-F01           TO FRENCH-HEADING (01)                
               MOVE HEADING-F04           TO FRENCH-HEADING (04)                
               MOVE HEADING-F05           TO FRENCH-HEADING (05)                
               MOVE HEADING-F06           TO FRENCH-HEADING (06)                
               MOVE HEADING-F07           TO FRENCH-HEADING (07)                
               MOVE HEADING-F08           TO FRENCH-HEADING (08)                
               MOVE HEADING-F09           TO FRENCH-HEADING (09)                
               MOVE HEADING-F10           TO FRENCH-HEADING (10)                
               MOVE HEADING-F11           TO FRENCH-HEADING (11)                
               MOVE HEADING-F12           TO FRENCH-HEADING (12)                
               PERFORM 285-PRINT-HEADINGS THRU 285-EXIT                         
                                          UNTIL WS-SUB2 >                       
                                          12                                    
           ELSE                                                                 
               MOVE HEADING-01            TO ENGLISH-HEADING (01)               
               MOVE HEADING-04            TO ENGLISH-HEADING (04)               
               MOVE HEADING-05            TO ENGLISH-HEADING (05)               
               MOVE HEADING-06            TO ENGLISH-HEADING (06)               
               MOVE HEADING-07            TO ENGLISH-HEADING (07)               
               MOVE HEADING-08            TO ENGLISH-HEADING (08)               
               MOVE HEADING-09            TO ENGLISH-HEADING (09)               
               MOVE HEADING-10            TO ENGLISH-HEADING (10)               
               MOVE HEADING-11            TO ENGLISH-HEADING (11)               
               MOVE HEADING-12            TO ENGLISH-HEADING (12)               
               PERFORM 285-PRINT-HEADINGS THRU 285-EXIT                         
                                          UNTIL WS-SUB2 >                       
                                          11.                                   
                                                                                
      /                                                                         
       285-PRINT-HEADINGS.                                                      
           ADD +1 TO WS-SUB2.                                                   
           IF FRENCH                                                            
              IF WS-SUB2 = +9                                                   
                 IF GGIPRODUCT-CODE = '1'                                       
                    MOVE FRENCH-HEADING  (WS-SUB2) TO PRINT-LINE                
                 ELSE                                                           
                    GO TO 285-EXIT                                              
              ELSE                                                              
                 MOVE FRENCH-HEADING     (WS-SUB2) TO PRINT-LINE                
           ELSE                                                                 
              IF WS-SUB2 = +9                                                   
                 IF GGIPRODUCT-CODE = '1'                                       
                    MOVE ENGLISH-HEADING  (WS-SUB2) TO PRINT-LINE               
                 ELSE                                                           
                    GO TO 285-EXIT                                              
              ELSE                                                              
                 MOVE ENGLISH-HEADING (WS-SUB2) TO PRINT-LINE.                  
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
       285-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       290-INITIALIZE-FIELDS.                                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     INITIALIZE AGENT-ACCOUNT ACCUMULATORS                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE ZERO TO WS-RECON-AMT                                            
                        WS-RECON-AMT-SC                                         
                        TOT-SC-PAID-LIFE-FY                                     
                        TOT-SC-PAID-LTD-FY                                      
                        TOT-SC-PAID-A-S-FY                                      
                        TOT-SC-PAID-LIFE-RN                                     
                        TOT-SC-PAID-LTD-RN                                      
                        TOT-SC-PAID-A-S-RN                                      
                        TOT-SC-EARN-LIFE-FY                                     
                        TOT-SC-EARN-LTD-FY                                      
                        TOT-SC-EARN-A-S-FY                                      
                        TOT-SC-EARN-LIFE-RN                                     
                        TOT-SC-EARN-LTD-RN                                      
                        TOT-SC-EARN-A-S-RN                                      
                        TOT-SC-AMEND-RECOV-LIFE-FY                              
                        TOT-SC-AMEND-RECOV-LTD-FY                               
                        TOT-SC-AMEND-RECOV-A-S-FY                               
                        TOT-SC-AMEND-RECOV-LIFE-RN                              
                        TOT-SC-AMEND-RECOV-LTD-RN                               
                        TOT-SC-AMEND-RECOV-A-S-RN                               
                        TOT-COMM-PAID-LIFE-FY                                   
                        TOT-COMM-PAID-LTD-FY                                    
                        TOT-COMM-PAID-A-S-FY                                    
                        TOT-COMM-PAID-LIFE-RN                                   
                        TOT-COMM-PAID-LTD-RN                                    
                        TOT-COMM-PAID-A-S-RN                                    
                        TOT-COMM-EARN-LIFE-FY                                   
                        TOT-COMM-EARN-LTD-FY                                    
                        TOT-COMM-EARN-A-S-FY                                    
                        TOT-COMM-EARN-LIFE-RN                                   
                        TOT-COMM-EARN-LTD-RN                                    
                        TOT-COMM-EARN-A-S-RN                                    
                        TOT-COMM-AMEND-RECOV-LIFE-FY                            
                        TOT-COMM-AMEND-RECOV-LTD-FY                             
                        TOT-COMM-AMEND-RECOV-A-S-FY                             
                        TOT-COMM-AMEND-RECOV-LIFE-RN                            
                        TOT-COMM-AMEND-RECOV-LTD-RN                             
                        TOT-COMM-AMEND-RECOV-A-S-RN                             
                        WS-TOT-REG-RECON-AMT-S-C                                
                        WS-TOT-REG-RECON-AMT.                                   
           MOVE ZERO TO WS-TOT-PREM-PAID                                        
                        WS-TOT-COMM-EARNED                                      
                        WS-TOT-SPLIT-AMT                                        
                        WS-TOT-COMM-PAID                                        
                        WS-TOT-S-C-EARNED                                       
                        WS-TOT-S-C-SPLIT-AMT                                    
                        WS-TOT-S-C-PAID                                         
                        WS-TOT-RECON-AMT                                        
                        WS-TOT-FEES-PAID                                        
                        WS-TOT-REG-RECON-AMT-S-C                                
                        WS-TOT-REG-RECON-AMT                                    
                        WS-TOT-ALL-RECON-AMTS-S-C                               
                        WS-TOT-ALL-RECON-AMTS.                                  
                                                                                
           MOVE SPACES TO ONE-STAR-SWITCH.                                      
                                                                                
           IF  FRENCH                                                           
MAN02          CALL QDATEQ2 USING QDATE-FORMATAF                                
MAN02                             EXT-COMM-EFF-DATE                             
MAN02                             WS-DTL-DATE                                   
           ELSE                                                                 
MAN02          CALL QDATEQ2 USING QDATE-FORMATAD                                
MAN02                             EXT-COMM-EFF-DATE                             
MAN02                             WS-DTL-DATE.                                  
                                                                                
           MOVE WS-DTL-MTH TO D1-MTH.                                           
           MOVE WS-DTL-YR  TO D1-YR.                                            
           MOVE EXT-COMM-EFF-DATE TO WS-PREV-EFF-DATE.                          
           PERFORM 680-GET-ACCUM-RECORD.                                        
      /                                                                         
       300-PROCESS-COMPS.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     INVOKE FY-SALES-CREDIT                                    *         
      *     INVOKE RN-SALES-CREDIT                                    *         
      *     INVOKE FY-AMEND-SALES-CREDIT                              *         
      *     INVOKE RN-AMEND-SALES-CREDIT                              *         
      *     INVOKE FY-COMMISSION                                      *         
      *     INVOKE RN-COMMISSION                                      *         
      *     INVOKE FY-AMEND-COMMISSION                                *         
      *     INVOKE RN-AMEND-COMMISSION                                *         
      *     INVOKE ERROR-REPORT                                       *         
      *     INVOKE STATEMENT DETAILS                                  *         
      *     READ NNEXT EXTRACT RECORD.                                *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  EXT-COMM-COMP-TYPE = 'S'                                         
               IF  EXT-COMM-COMP-REASON = 'F'                                   
                   PERFORM 310-FY-SALES-CREDIT                                  
               ELSE                                                             
               IF  EXT-COMM-COMP-REASON = 'R'                                   
                   PERFORM 315-RN-SALES-CREDIT                                  
               ELSE                                                             
                   IF  EXT-COMM-COMP-REASON = 'A'                               
                   AND EXT-COMM-COMP-DISP = 'P'                                 
                       PERFORM 320-FY-AMEND-SALES-CREDIT                        
                   ELSE                                                         
                       IF  EXT-COMM-COMP-REASON = 'B'                           
                       AND EXT-COMM-COMP-DISP = 'P'                             
                           PERFORM 350-RN-AMEND-SALES-CREDIT                    
                       ELSE                                                     
                           MOVE '1' TO ERROR-SWITCH                             
                           PERFORM 1100-ACTION-REPORT                           
           ELSE                                                                 
               IF  EXT-COMM-COMP-TYPE = 'C'                                     
                   IF  EXT-COMM-COMP-REASON = 'F'                               
                       PERFORM 330-FY-COMMISSION                                
                   ELSE                                                         
                       IF  EXT-COMM-COMP-REASON = 'R'                           
                           PERFORM 360-RN-COMMISSION                            
                       ELSE                                                     
                           IF  EXT-COMM-COMP-REASON = 'A'                       
                           AND EXT-COMM-COMP-DISP = 'P'                         
                               PERFORM 340-FY-AMEND-COMMISSION                  
                           ELSE                                                 
                               IF  EXT-COMM-COMP-REASON = 'B'                   
                               AND EXT-COMM-COMP-DISP = 'P'                     
                                   PERFORM 370-RN-AMEND-COMMISSION              
                               ELSE                                             
                                   MOVE '1' TO ERROR-SWITCH                     
                                   PERFORM 1100-ACTION-REPORT                   
               ELSE                                                             
                   NEXT SENTENCE.                                               
                                                                                
           IF  EXT-COMM-COMP-TYPE = 'F' OR 'C' OR 'S'                           
               PERFORM 600-STATEMENT-DETAILS THRU 609-EXIT.                     
           MOVE EXT-COMM-SORT-KEY TO WS-PREV-KEY.                               
                                                                                
       300-READ-EXTRACT.                                                        
                                                                                
           CALL 'DLSREAD' USING DLSC-SYSNNN                                     
                                DLSC-RET-CODE                                   
                                EXT-RECON-COMM-RECORD                           
                                DLSC-REC-SIZE                                   
                                DLSC-BLK-SIZE                                   
                                DLSC-FORMAT                                     
                                DLSC-REC-COUNT.                                 
                                                                                
           IF  DLSC-RET-CODE = 0                                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
              IF  DLSC-RET-CODE = 4                                             
                  MOVE 'Y' TO EOF-SWITCH                                        
              ELSE                                                              
                  DISPLAY 'ERROR WHILE READING INPUT - FORCED TO ABEND'         
                      UPON CONSOLE                                              
FXXTOK            GO TO 799-SQL-STATUS.                                         
                                                                                
           IF  EOF-ON-EXTRACT                                                   
               NEXT SENTENCE                                                    
           ELSE                                                                 
               IF  EXT-COMM-GROUP-NUMBER = WS-PREV-GROUP                        
               AND EXT-COMM-GROUP-ACCOUNT = WS-PREV-ACCOUNT                     
                   IF  EXT-COMM-AGENT-NUMBER = WS-PREV-AGENT                    
                       MOVE 'N' TO NEW-ACCOUNT-IND                              
                       MOVE 'N' TO NEW-AGENT-IND                                
                   ELSE                                                         
                       MOVE 'Y' TO NEW-AGENT-IND                                
               ELSE                                                             
                   MOVE 'Y' TO NEW-AGENT-IND                                    
                   MOVE 'Y' TO NEW-ACCOUNT-IND.                                 
                                                                                
        300-EXIT.                                                               
            EXIT.                                                               
      /                                                                         
       310-FY-SALES-CREDIT.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE SALES CREDIT PAID FIRST YEAR                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  EXT-COMM-COMP-DISP = 'P'                                         
               IF  EXT-COMM-COV-TYPE = 'T'                                      
                   ADD EXT-COMM-COMP-AMT TO TOT-SC-PAID-LIFE-FY                 
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'L'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-SC-PAID-LTD-FY              
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'O'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-SC-PAID-A-S-FY          
                       ELSE                                                     
                           MOVE '2' TO ERROR-SWITCH                             
                           PERFORM 1100-ACTION-REPORT                           
           ELSE                                                                 
               IF  EXT-COMM-COMP-DISP = 'E'                                     
                   IF  EXT-COMM-COV-TYPE = 'T'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-SC-EARN-LIFE-FY             
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'L'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-SC-EARN-LTD-FY          
                       ELSE                                                     
                           IF  EXT-COMM-COV-TYPE = 'O'                          
                               ADD EXT-COMM-COMP-AMT                            
                                   TO TOT-SC-EARN-A-S-FY                        
                           ELSE                                                 
                               MOVE '2' TO ERROR-SWITCH                         
                               PERFORM 1100-ACTION-REPORT                       
               ELSE                                                             
                   MOVE '3' TO ERROR-SWITCH                                     
                   PERFORM 1100-ACTION-REPORT.                                  
      /                                                                         
       315-RN-SALES-CREDIT.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE SALES CREDIT PAID RENEWAL YEAR                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  EXT-COMM-COMP-DISP = 'P'                                         
               IF  EXT-COMM-COV-TYPE = 'T'                                      
                   ADD EXT-COMM-COMP-AMT TO TOT-SC-PAID-LIFE-RN                 
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'L'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-SC-PAID-LTD-RN              
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'O'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-SC-PAID-A-S-RN          
                       ELSE                                                     
                           MOVE '2' TO ERROR-SWITCH                             
                           PERFORM 1100-ACTION-REPORT                           
           ELSE                                                                 
               IF  EXT-COMM-COMP-DISP = 'E'                                     
                   IF  EXT-COMM-COV-TYPE = 'T'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-SC-EARN-LIFE-RN             
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'L'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-SC-EARN-LTD-RN          
                       ELSE                                                     
                           IF  EXT-COMM-COV-TYPE = 'O'                          
                               ADD EXT-COMM-COMP-AMT                            
                                   TO TOT-SC-EARN-A-S-RN                        
                           ELSE                                                 
                               MOVE '2' TO ERROR-SWITCH                         
                               PERFORM 1100-ACTION-REPORT                       
               ELSE                                                             
                   MOVE '3' TO ERROR-SWITCH                                     
                   PERFORM 1100-ACTION-REPORT.                                  
      /                                                                         
       320-FY-AMEND-SALES-CREDIT.                                               
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE SALES CREDIT AMENDMENTS FIRST YEAR              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           COMPUTE AMEND-RECOV-AMT ROUNDED =                                    
               (EXT-COMM-COMP-AMT / 12)                                         
               * EXT-COMM-MONTHS * -1.                                          
                                                                                
           IF  EXT-COMM-COV-TYPE = 'T'                                          
               ADD AMEND-RECOV-AMT TO TOT-SC-AMEND-RECOV-LIFE-FY                
           ELSE                                                                 
               IF  EXT-COMM-COV-TYPE = 'L'                                      
                   ADD AMEND-RECOV-AMT TO TOT-SC-AMEND-RECOV-LTD-FY             
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'O'                                  
                       ADD AMEND-RECOV-AMT TO TOT-SC-AMEND-RECOV-A-S-FY         
                   ELSE                                                         
                       MOVE '2' TO ERROR-SWITCH                                 
                       PERFORM 1100-ACTION-REPORT.                              
      /                                                                         
       330-FY-COMMISSION.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE COMMISSION FIRST YEAR                           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  EXT-COMM-COMP-DISP = 'P'                                         
               IF  EXT-COMM-COV-TYPE = 'T'                                      
                   ADD EXT-COMM-COMP-AMT TO TOT-COMM-PAID-LIFE-FY               
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'L'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-COMM-PAID-LTD-FY            
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'O'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-COMM-PAID-A-S-FY        
                       ELSE                                                     
                           MOVE '2' TO ERROR-SWITCH                             
                           PERFORM 1100-ACTION-REPORT                           
           ELSE                                                                 
               IF  EXT-COMM-COMP-DISP = 'E'                                     
                   IF  EXT-COMM-COV-TYPE = 'T'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-COMM-EARN-LIFE-FY           
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'L'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-COMM-EARN-LTD-FY        
                       ELSE                                                     
                           IF  EXT-COMM-COV-TYPE = 'O'                          
                               ADD EXT-COMM-COMP-AMT                            
                                   TO TOT-COMM-EARN-A-S-FY                      
                           ELSE                                                 
                               MOVE '2' TO ERROR-SWITCH                         
                               PERFORM 1100-ACTION-REPORT                       
               ELSE                                                             
                   MOVE '3' TO ERROR-SWITCH                                     
                   PERFORM 1100-ACTION-REPORT.                                  
      /                                                                         
       340-FY-AMEND-COMMISSION.                                                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE COMMISSION AMENDMENTS                           *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           COMPUTE AMEND-RECOV-AMT ROUNDED =                                    
               (EXT-COMM-COMP-AMT / 12)                                         
               * EXT-COMM-MONTHS * -1.                                          
                                                                                
           IF  EXT-COMM-COV-TYPE = 'T'                                          
               ADD AMEND-RECOV-AMT TO TOT-COMM-AMEND-RECOV-LIFE-FY              
           ELSE                                                                 
               IF  EXT-COMM-COV-TYPE = 'L'                                      
                   ADD AMEND-RECOV-AMT TO TOT-COMM-AMEND-RECOV-LTD-FY           
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'O'                                  
                       ADD AMEND-RECOV-AMT                                      
                           TO TOT-COMM-AMEND-RECOV-A-S-FY                       
                   ELSE                                                         
                       MOVE '2' TO ERROR-SWITCH                                 
                       PERFORM 1100-ACTION-REPORT.                              
      /                                                                         
       350-RN-AMEND-SALES-CREDIT.                                               
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE SALES CREDIT AMENDMENTS AFTER FIRST YEAR        *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           COMPUTE AMEND-RECOV-AMT ROUNDED =                                    
               (EXT-COMM-COMP-AMT / 12)                                         
               * EXT-COMM-MONTHS * -1.                                          
                                                                                
           IF  EXT-COMM-COV-TYPE = 'T'                                          
               ADD AMEND-RECOV-AMT TO TOT-SC-AMEND-RECOV-LIFE-RN                
           ELSE                                                                 
               IF  EXT-COMM-COV-TYPE = 'L'                                      
                   ADD AMEND-RECOV-AMT TO TOT-SC-AMEND-RECOV-LTD-RN             
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'O'                                  
                       ADD AMEND-RECOV-AMT TO TOT-SC-AMEND-RECOV-A-S-RN         
                   ELSE                                                         
                       MOVE '2' TO ERROR-SWITCH                                 
                       PERFORM 1100-ACTION-REPORT.                              
      /                                                                         
       360-RN-COMMISSION.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE RENEWAL COMMISSIONS                             *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  EXT-COMM-COMP-DISP = 'P'                                         
               IF  EXT-COMM-COV-TYPE = 'T'                                      
                   ADD EXT-COMM-COMP-AMT TO TOT-COMM-PAID-LIFE-RN               
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'L'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-COMM-PAID-LTD-RN            
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'O'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-COMM-PAID-A-S-RN        
                       ELSE                                                     
                           MOVE '2' TO ERROR-SWITCH                             
                           PERFORM 1100-ACTION-REPORT                           
           ELSE                                                                 
               IF  EXT-COMM-COMP-DISP = 'E'                                     
                   IF  EXT-COMM-COV-TYPE = 'T'                                  
                       ADD EXT-COMM-COMP-AMT TO TOT-COMM-EARN-LIFE-RN           
                   ELSE                                                         
                       IF  EXT-COMM-COV-TYPE = 'L'                              
                           ADD EXT-COMM-COMP-AMT TO TOT-COMM-EARN-LTD-RN        
                       ELSE                                                     
                           IF  EXT-COMM-COV-TYPE = 'O'                          
                               ADD EXT-COMM-COMP-AMT                            
                                   TO TOT-COMM-EARN-A-S-RN                      
                           ELSE                                                 
                               MOVE '2' TO ERROR-SWITCH                         
                               PERFORM 1100-ACTION-REPORT                       
               ELSE                                                             
                   MOVE '3' TO ERROR-SWITCH                                     
                   PERFORM 1100-ACTION-REPORT.                                  
      /                                                                         
       370-RN-AMEND-COMMISSION.                                                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE RENEWAL COMMISSION AMENDMENTS                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           COMPUTE AMEND-RECOV-AMT ROUNDED =                                    
               (EXT-COMM-COMP-AMT / 12)                                         
               * EXT-COMM-MONTHS * -1.                                          
                                                                                
           IF  EXT-COMM-COV-TYPE = 'T'                                          
               ADD AMEND-RECOV-AMT TO TOT-COMM-AMEND-RECOV-LIFE-RN              
           ELSE                                                                 
               IF  EXT-COMM-COV-TYPE = 'L'                                      
                   ADD AMEND-RECOV-AMT TO TOT-COMM-AMEND-RECOV-LTD-RN           
               ELSE                                                             
                   IF  EXT-COMM-COV-TYPE = 'O'                                  
                       ADD AMEND-RECOV-AMT                                      
                           TO TOT-COMM-AMEND-RECOV-A-S-RN                       
                   ELSE                                                         
                       MOVE '2' TO ERROR-SWITCH                                 
                       PERFORM 1100-ACTION-REPORT.                              
      /                                                                         
       400-GET-AGENT-SPLITS.                                                    
      ******************************************************************        
      *   FIND COMMISSION %'S FOR CURRENT AGENT.                                
      ******************************************************************        
           MOVE +100.00              TO WS-FY-LIFE-PCT                          
                                        WS-FY-LTD-PCT                           
                                        WS-FY-A-S-PCT                           
                                        WS-RN-LIFE-PCT                          
                                        WS-RN-LTD-PCT                           
                                        WS-RN-A-S-PCT.                          
           PERFORM 410-FIND-AGENT-LOOP1 THRU                                    
                   410-FIND-AGENT-LOOP1-EXIT VARYING                            
                   AGT-SUB1 FROM +1 BY +1 UNTIL                                 
                   AGT-SUB1 > +4.                                               
       400-GET-AGENT-SPLITS-EXIT.                                               
           EXIT.                                                                
                                                                                
       410-FIND-AGENT-LOOP1.                                                    
      ******************************************************************        
      *    MATCH ON AGENT NUMBER.                                               
      ******************************************************************        
           IF  GAGAGENT-CODE (AGT-SUB1) NUMERIC  AND                            
               GAGAGENT-CODE (AGT-SUB1) = WS-PREV-AGENT                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 410-FIND-AGENT-LOOP1-EXIT.                                 
      *                                                                         
           PERFORM 420-FIND-AGENT-LOOP2 THRU                                    
                   420-FIND-AGENT-LOOP2-EXIT VARYING                            
                   AGT-SUB2 FROM +1 BY +1 UNTIL                                 
                   AGT-SUB2 > +5.                                               
       410-FIND-AGENT-LOOP1-EXIT.                                               
           EXIT.                                                                
                                                                                
       420-FIND-AGENT-LOOP2.                                                    
      ******************************************************************        
      *    IGNORE COMM-IND = 'S'.                                               
      *    MATCH DATE RANGE AND COVERAGE TYPE.                                  
      *    SAVE 1ST-YEAR AND RENEWAL AGENT SPLIT PERCENTAGES.                   
      ******************************************************************        
           IF  GAGSTART-YEAR (AGT-SUB1 AGT-SUB2) NUMERIC AND                    
               GAGSTART-DAY  (AGT-SUB1 AGT-SUB2) NUMERIC AND                    
               GAGSTOP-YEAR  (AGT-SUB1 AGT-SUB2) NUMERIC AND                    
               GAGSTOP-DAY   (AGT-SUB1 AGT-SUB2) NUMERIC                        
               NEXT SENTENCE                                                    
           ELSE                                                                 
               GO TO 420-FIND-AGENT-LOOP2-EXIT.                                 
           IF  GAGCOMM-IND (AGT-SUB1 AGT-SUB2) = 'S'                            
               GO TO 420-FIND-AGENT-LOOP2-EXIT.                                 
           IF  GAGSTART-DATE (AGT-SUB1 AGT-SUB2) >                              
               NEXT-RECON-DATE OF GWCORGRACCT                                   
               GO TO 420-FIND-AGENT-LOOP2-EXIT.                                 
           IF  GAGSTOP-DATE  (AGT-SUB1 AGT-SUB2) <                              
               NEXT-RECON-DATE OF GWCORGRACCT                                   
               GO TO 420-FIND-AGENT-LOOP2-EXIT.                                 
      *                                                                         
           IF  GAGFRST-LIFE (AGT-SUB1 AGT-SUB2) > +0.00                         
               MOVE GAGFRST-LIFE (AGT-SUB1 AGT-SUB2) TO WS-FY-LIFE-PCT.         
           IF  GAGFRST-LTD  (AGT-SUB1 AGT-SUB2) > +0.00                         
               MOVE GAGFRST-LTD  (AGT-SUB1 AGT-SUB2) TO WS-FY-LTD-PCT.          
           IF  GAGFRST-A-S  (AGT-SUB1 AGT-SUB2) > +0.00                         
               MOVE GAGFRST-A-S  (AGT-SUB1 AGT-SUB2) TO WS-FY-A-S-PCT.          
      *                                                                         
           IF  GAGREN-LIFE  (AGT-SUB1 AGT-SUB2) > +0.00                         
               MOVE GAGREN-LIFE  (AGT-SUB1 AGT-SUB2) TO WS-RN-LIFE-PCT.         
           IF  GAGREN-LTD   (AGT-SUB1 AGT-SUB2) > +0.00                         
               MOVE GAGREN-LTD   (AGT-SUB1 AGT-SUB2) TO WS-RN-LTD-PCT.          
           IF  GAGREN-A-S   (AGT-SUB1 AGT-SUB2) > +0.00                         
               MOVE GAGREN-A-S   (AGT-SUB1 AGT-SUB2) TO WS-RN-A-S-PCT.          
       420-FIND-AGENT-LOOP2-EXIT.                                               
           EXIT.                                                                
      /                                                                         
       600-STATEMENT-DETAILS.                                                   
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     EDIT COMP-EFF-DATE                                        *         
      *     INVOKE PRINT AMENDMENT LINE                               *         
      *     INVOKE ACCUMULATE DETAILS                                 *         
      *     INVOKE PRINT DETAIL-01                                    *         
      *     GET ACCUM RECORD                                          *         
      *                                                               *         
      *     NOTE: COMMISSION AND SALE CREDIT AMENDMENTS ARE ADDED TO  *         
      *           BOTH ADVANCED AND SPLIT AMOUNTS FOR ACCOUNTING      *         
      *           PURPOSES ONLY                                       *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  EXT-COMM-COMP-TYPE = 'F' OR 'C'                                  
               IF EXT-COMM-EFF-DATE GREATER THAN LAST-RECON-DATE                
                   NEXT SENTENCE                                                
               ELSE                                                             
                   PERFORM 650-AMENDMENT                                        
                   GO TO 609-EXIT.                                              
                                                                                
           MOVE SPACES TO WS-DTL-DATE.                                          
           IF  FRENCH                                                           
MAN02          CALL QDATEQ2 USING QDATE-FORMATAF                                
MAN02                             EXT-COMM-EFF-DATE                             
MAN02                             WS-DTL-DATE                                   
           ELSE                                                                 
MAN02          CALL QDATEQ2 USING QDATE-FORMATAD                                
MAN02                             EXT-COMM-EFF-DATE                             
MAN02                             WS-DTL-DATE.                                  
                                                                                
           IF  WS-DTL-MTH EQUAL TO D1-MTH                                       
           AND WS-DTL-YR EQUAL TO  D1-YR                                        
               PERFORM 660-ACCUMULATE-DETAILS                                   
           ELSE                                                                 
               PERFORM 670-PRINT-DETAILS THRU 679-EXIT                          
               MOVE WS-DTL-MTH TO D1-MTH                                        
               MOVE WS-DTL-YR  TO D1-YR                                         
               PERFORM 660-ACCUMULATE-DETAILS                                   
               PERFORM 680-GET-ACCUM-RECORD.                                    
                                                                                
       609-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       650-AMENDMENT.                                                           
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     FORMAT AMENDMENT LINE ON STATEMENT                        *         
      *     INVOKE PRINT STATEMENT LINE                               *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE SPACES TO WS-DTL-DATE.                                          
           IF  FRENCH                                                           
MAN02          CALL QDATEQ2 USING QDATE-FORMATAF                                
MAN02                             EXT-COMM-EFF-DATE                             
MAN02                             WS-DTL-DATE                                   
           ELSE                                                                 
MAN02          CALL QDATEQ2 USING QDATE-FORMATAD                                
MAN02                             EXT-COMM-EFF-DATE                             
MAN02                             WS-DTL-DATE.                                  
                                                                                
           MOVE WS-DTL-MTH TO AMEND-MTH.                                        
           MOVE WS-DTL-YR TO AMEND-YR.                                          
           MOVE AMEND-RECOV-AMT TO AMEND-AMT.                                   
           MOVE AMEND-LINE TO PRINT-LINE.                                       
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
           ADD AMEND-RECOV-AMT TO WS-TOT-RECON-AMT.                             
      /                                                                         
       660-ACCUMULATE-DETAILS.                                                  
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     ACCUMULATE DETAILS PER MONTH                              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     COMMISSION INFORMATION                                    *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           IF  EXT-COMM-COMP-TYPE = 'C'                                         
           AND EXT-COMM-COMP-DISP = 'E'                                         
               ADD EXT-COMM-COMP-AMT TO WS-SPLIT-AMT.                           
                                                                                
           IF  EXT-COMM-COMP-TYPE = 'C'                                         
           AND EXT-COMM-COMP-DISP = 'P'                                         
               ADD EXT-COMM-COMP-AMT TO WS-ADVANCED-AMT                         
               IF  EXT-COMM-COMP-REASON = 'A' OR 'B'                            
                   ADD EXT-COMM-COMP-AMT TO WS-SPLIT-AMT                        
                   MOVE '*' TO D1-STAR-1                                        
                   MOVE '*' TO D1-STAR-3                                        
                   MOVE 'Y' TO ONE-STAR-SWITCH                                  
                   IF  AMEND-RECOV-AMT = ZERO                                   
                       NEXT SENTENCE                                            
                   ELSE                                                         
                       ADD AMEND-RECOV-AMT TO WS-RECON-AMT.                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *     SALES CREDIT INFORMATION                                  *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    IF  EXT-COMM-COMP-TYPE = 'S'                                         
      *    AND EXT-COMM-COMP-DISP = 'E'                                         
      *        ADD EXT-COMM-COMP-AMT TO WS-SPLIT-AMT-SC.                        
                                                                                
           IF  EXT-COMM-COMP-TYPE = 'S'                                         
           AND EXT-COMM-COMP-DISP = 'P'                                         
               ADD EXT-COMM-COMP-AMT TO WS-ADVANCED-AMT-SC                      
               IF  EXT-COMM-COMP-REASON = 'A' OR 'B'                            
                   MOVE '*' TO D1-STAR-3                                        
                   MOVE '*' TO D1-STAR-4                                        
                   MOVE 'Y' TO ONE-STAR-SWITCH                                  
                   IF  AMEND-RECOV-AMT = ZERO                                   
                       NEXT SENTENCE                                            
                   ELSE                                                         
                                                                                
                       COMPUTE WS-RECON-AMT-SC ROUNDED =                        
                           AMEND-RECOV-AMT + WS-RECON-AMT-SC.                   
                                                                                
           IF  EXT-COMM-COMP-TYPE = 'F'                                         
               IF  EXT-COMM-COMP-DISP = 'P'                                     
                   ADD EXT-COMM-COMP-AMT TO WS-FEES-PAID                        
               ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
      /                                                                         
       670-PRINT-DETAILS.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *   PRINT DETAIL LINE ON STATEMENT                              *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  WS-COMM-EARNED = ZERO                                            
               MOVE +100 TO D1-SPLIT-PERCENT                                    
           ELSE                                                                 
               COMPUTE WS-SPLIT-RATE ROUNDED =                                  
                   WS-SPLIT-AMT / WS-COMM-EARNED                                
               COMPUTE WS-SPLIT-PERCENT ROUNDED = WS-SPLIT-RATE * 100           
               MOVE WS-SPLIT-PERCENT TO D1-SPLIT-PERCENT.                       
                                                                                
           IF WS-SC-EARNED = ZERO                                               
              MOVE ZERO        TO D1-SPLIT-AMT-SC                               
           ELSE                                                                 
              COMPUTE WS-SPLIT-AMT-SC =                                         
                      WS-SC-EARNED *                                            
                      (WS-SPLIT-PERCENT / 100).                                 
                                                                                
           MOVE WS-PREM-PAID   TO D1-PREM-PAID.                                 
           MOVE WS-COMM-EARNED TO D1-COMM-EARNED.                               
           MOVE WS-SC-EARNED   TO D1-SC-EARNED.                                 
                                                                                
           MOVE WS-SPLIT-AMT       TO D1-SPLIT-AMT.                             
           MOVE WS-ADVANCED-AMT    TO D1-COMM-PAID-AMT.                         
           MOVE WS-SPLIT-AMT-SC    TO D1-SPLIT-AMT-SC.                          
           MOVE WS-ADVANCED-AMT-SC TO D1-SC-PAID-AMT.                           
                                                                                
           IF  FEES-WERE-PAID                                                   
               MOVE WS-FEES-PAID TO D1-FEES-PAID                                
           ELSE                                                                 
               MOVE SPACES TO D1-FEES-PAID-X.                                   
                                                                                
           MOVE DETAIL-01 TO PRINT-LINE.                                        
           PERFORM 1000-PRINT-A-LINE.                                           
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    SAVE STATEMENT TOTALS FROM LINE ACCUMULATORS               *         
      *    CLEAR LINE ACCUMULATORS                                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           ADD WS-PREM-PAID        TO WS-TOT-PREM-PAID.                         
           ADD WS-COMM-EARNED      TO WS-TOT-COMM-EARNED.                       
           ADD WS-SC-EARNED        TO WS-TOT-S-C-EARNED.                        
           ADD WS-SPLIT-AMT        TO WS-TOT-SPLIT-AMT.                         
           ADD WS-SPLIT-AMT-SC     TO WS-TOT-S-C-SPLIT-AMT.                     
           ADD WS-ADVANCED-AMT     TO WS-TOT-COMM-PAID.                         
           ADD WS-ADVANCED-AMT-SC  TO WS-TOT-S-C-PAID.                          
           ADD WS-RECON-AMT        TO WS-TOT-RECON-AMT.                         
           ADD WS-RECON-AMT        TO WS-TOT-ALL-RECON-AMTS.                    
      *    ADD WS-RECON-AMT-SC     TO WS-TOT-ALL-RECON-AMTS-S-C.                
           ADD WS-FEES-PAID        TO WS-TOT-FEES-PAID.                         
                                                                                
           MOVE ZERO TO WS-PREM-PAID                                            
                        WS-COMM-EARNED                                          
                        WS-SC-EARNED                                            
                        WS-SPLIT-PERCENT                                        
                        WS-AGENT-EARNED-AMT                                     
                        WS-SPLIT-AMT                                            
                        WS-ADVANCED-AMT                                         
                        WS-RECON-AMT                                            
                        WS-SPLIT-AMT-SC                                         
                        WS-ADVANCED-AMT-SC                                      
                        WS-RECON-AMT-SC                                         
                        WS-FEES-PAID.                                           
                                                                                
           MOVE SPACES TO D1-STAR-1                                             
                          D1-STAR-2                                             
                          D1-STAR-3                                             
                          D1-STAR-4.                                            
                                                                                
       679-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       680-GET-ACCUM-RECORD.                                                    
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     INVOKE SEARCH ACCUM SET                                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE ZERO TO WS-PREM-PAID                                            
                        WS-COMM-EARNED                                          
                        WS-SC-EARNED.                                           
           MOVE 'N' TO WS-ACCUM-SWITCH.                                         
                                                                                
           MOVE '2B2E' TO DATE-PARAMETERS.                              YEAR2000
           MOVE EXT-COMM-EFF-DATE TO VDATE-ALIS-DATE1.                  YEAR2000
           CALL  GC2DATE  USING DATE-PARAMETERS.                        YEAR2000
           MOVE VDATE1-YYYYMMDD TO WS-COMM-EFF-DATE-EXT.                YEAR2000
                                                                                
      *%   OBTAIN FIRST GWCORACCUM WITHIN GRACCT-ACCUM                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           PERFORM 681-SEARCH-ACCUM                                             
               UNTIL ALL-ACCUMS-FOUND                                           
               OR  DB-END-OF-SET.                                               
                                                                                
       681-SEARCH-ACCUM.                                                        
                                                                                
           MOVE '2B2E' TO DATE-PARAMETERS.                              YEAR2000
           MOVE PREM-DUE-DATE TO VDATE-ALIS-DATE1.                      YEAR2000
           CALL  GC2DATE  USING DATE-PARAMETERS.                        YEAR2000
           MOVE VDATE1-YYYYMMDD TO WS-PREM-DUE-DATE-EXT.                YEAR2000
                                                                                
           IF  WS-PREM-DUE-YR-EXT  EQUAL TO WS-COMM-EFF-YR-EXT                  
           AND WS-PREM-DUE-MTH-EXT EQUAL TO WS-COMM-EFF-MTH-EXT                 
               ADD PREM-AMT-PAID            TO WS-PREM-PAID                     
               ADD COMM-AMT-EARNED          TO WS-COMM-EARNED                   
               ADD SALES-CREDITS-AMT-EARNED TO WS-SC-EARNED                     
           ELSE                                                                 
           IF  WS-PREM-DUE-YR-EXT  EQUAL TO WS-COMM-EFF-YR-EXT                  
           AND WS-PREM-DUE-MTH-EXT IS GREATER THAN WS-COMM-EFF-MTH-EXT          
               MOVE 'Y' TO WS-ACCUM-SWITCH                                      
           ELSE                                                                 
           IF  WS-PREM-DUE-YR-EXT  GREATER THAN WS-COMM-EFF-YR-EXT              
               MOVE 'Y' TO WS-ACCUM-SWITCH                                      
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
      *%   OBTAIN NEXT GWCORACCUM WITHIN GRACCT-ACCUM                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
      /                                                                         
       690-PRINT-TOTALS.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *    FORMAT TOTAL LINES ON STATEMENT                            *         
      *    INVOKE PRINT STATEMENT                                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF  FEES-WERE-PAID                                                   
               MOVE '-------------'      TO DASH-VARIABLE                       
           ELSE                                                                 
               MOVE SPACES               TO DASH-VARIABLE.                      
                                                                                
           MOVE DASH-LINE                TO PRINT-LINE.                         
           PERFORM 1000-PRINT-A-LINE.                                           
           IF FRENCH                                                            
              MOVE 'TOTAUX'              TO T1-DESC                             
           ELSE                                                                 
              MOVE 'TOTAL:'              TO T1-DESC.                            
           MOVE WS-TOT-PREM-PAID         TO T1-PREM-PAID.                       
           MOVE WS-TOT-COMM-EARNED       TO T1-COMM-EARNED.                     
           MOVE WS-TOT-SPLIT-AMT         TO T1-COMM-SPLIT-AMT.                  
           MOVE WS-TOT-COMM-PAID         TO T1-COMM-PAID.                       
           MOVE WS-TOT-S-C-EARNED        TO T1-S-C-EARNED.                      
           MOVE WS-TOT-S-C-SPLIT-AMT     TO T1-S-C-SPLIT-AMT.                   
           MOVE WS-TOT-S-C-PAID          TO T1-S-C-PAID.                        
                                                                                
           IF  FEES-WERE-PAID                                                   
               MOVE WS-TOT-FEES-PAID     TO T1-FEES-PAID                        
           ELSE                                                                 
               MOVE SPACES               TO T1-FEES-PAID-X.                     
                                                                                
           ADD WS-TOT-REG-RECON-AMT      TO WS-TOT-ALL-RECON-AMTS.              
           ADD WS-TOT-REG-RECON-AMT-S-C  TO WS-TOT-ALL-RECON-AMTS-S-C.          
                                                                                
           IF FRENCH                                                            
              MOVE ' TOTAUX:'            TO T1-DESC                             
              MOVE TOTAL-01              TO PRINT-LINE                          
              PERFORM 1000-PRINT-A-LINE                                         
              MOVE WS-TOT-ALL-RECON-AMTS TO T2-ALL-RECON-AMTS-F                 
              MOVE TOTAL-F02             TO PRINT-LINE                          
              PERFORM 1000-PRINT-A-LINE                                         
              MOVE WS-TOT-ALL-RECON-AMTS-S-C                                    
                                         TO T3-S-C-RECON-AMTS-F                 
              MOVE TOTAL-F03             TO PRINT-LINE                          
              PERFORM 1000-PRINT-A-LINE                                         
           ELSE                                                                 
              MOVE ' TOTAL :'            TO T1-DESC                             
              MOVE TOTAL-01              TO PRINT-LINE                          
              PERFORM 1000-PRINT-A-LINE                                         
              MOVE WS-TOT-ALL-RECON-AMTS TO T2-ALL-RECON-AMTS                   
              MOVE TOTAL-02              TO PRINT-LINE                          
              PERFORM 1000-PRINT-A-LINE                                         
              MOVE WS-TOT-ALL-RECON-AMTS-S-C                                    
                                         TO T3-S-C-RECON-AMTS                   
              MOVE TOTAL-03              TO PRINT-LINE                          
              PERFORM 1000-PRINT-A-LINE.                                        
                                                                                
           IF  ONE-STAR-PRINTED                                                 
               IF  FRENCH                                                       
                   MOVE FRENCH-HEADING (19) TO PRINT-LINE                       
                   PERFORM 1000-PRINT-A-LINE                                    
               ELSE                                                             
                   MOVE ENGLISH-HEADING (18) TO PRINT-LINE                      
                   PERFORM 1000-PRINT-A-LINE.                                   
                                                                                
           IF  FRENCH                                                           
               MOVE FRENCH-HEADING (20) TO PRINT-LINE                           
               PERFORM 1000-PRINT-A-LINE                                        
               MOVE FRENCH-HEADING (21) TO PRINT-LINE                           
               PERFORM 1000-PRINT-A-LINE                                        
           ELSE                                                                 
               MOVE ENGLISH-HEADING (19) TO PRINT-LINE                          
               PERFORM 1000-PRINT-A-LINE                                        
               MOVE ENGLISH-HEADING (20) TO PRINT-LINE                          
               PERFORM 1000-PRINT-A-LINE.                                       
                                                                                
           ADD +1 TO WS-NUMBER-OF-STATEMENTS.                                   
                                                                                
       690-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       700-RECONCILE-FY-SALES-CREDITS.                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE REGULAR RECONCILIATION AMOUNT                   *         
      *     INITIALIZE COMMISSION RELEASE RECORDS                     *         
      *     INITIALIZE COMMISSION HISTORY RECORDS                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'FY'                 TO WS-FY-RN-FLAG.                          
                                                                                
           MOVE 'S'                  TO WS-COMP-TYPE.                           
           MOVE 'P'                  TO WS-COMP-DISP.                           
           MOVE 'Y'                  TO WS-RECON-IND.                           
           MOVE 'F'                  TO WS-COMP-REASON.                         
           MOVE ZERO                 TO GCRL-PREMNO.                            
                                                                                
           SUBTRACT TOT-SC-PAID-LIFE-FY FROM TOT-SC-EARN-LIFE-FY                
               GIVING RECON-SC-LIFE-FY.                                         
                                                                                
           IF  RECON-SC-LIFE-FY = ZERO                                          
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'              TO WS-COV-TYPE                             
               MOVE RECON-SC-LIFE-FY TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           SUBTRACT TOT-SC-PAID-LTD-FY FROM TOT-SC-EARN-LTD-FY                  
               GIVING RECON-SC-LTD-FY.                                          
                                                                                
           IF  RECON-SC-LTD-FY = ZERO                                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'              TO WS-COV-TYPE                             
               MOVE RECON-SC-LTD-FY  TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           SUBTRACT TOT-SC-PAID-A-S-FY FROM TOT-SC-EARN-A-S-FY                  
               GIVING RECON-SC-A-S-FY.                                          
                                                                                
           IF  RECON-SC-A-S-FY = ZERO                                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'              TO WS-COV-TYPE                             
               MOVE RECON-SC-A-S-FY  TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
      *                                                                         
           MOVE 'S'                  TO WS-COMP-TYPE.                           
           MOVE 'P'                  TO WS-COMP-DISP.                           
           MOVE 'N'                  TO WS-RECON-IND.                           
           MOVE 'A'                  TO WS-COMP-REASON.                         
           MOVE ZERO                 TO GCRL-PREMNO.                            
                                                                                
           IF  TOT-SC-AMEND-RECOV-LIFE-FY = ZERO                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'              TO WS-COV-TYPE                             
               MOVE TOT-SC-AMEND-RECOV-LIFE-FY                                  
                                     TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           IF  TOT-SC-AMEND-RECOV-LTD-FY = ZERO                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'              TO WS-COV-TYPE                             
               MOVE TOT-SC-AMEND-RECOV-LTD-FY                                   
                                     TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           IF  TOT-SC-AMEND-RECOV-A-S-FY = ZERO                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'              TO WS-COV-TYPE                             
               MOVE TOT-SC-AMEND-RECOV-A-S-FY                                   
                                     TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
      /                                                                         
       710-RECONCILE-RN-SALES-CREDITS.                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE REGULAR RECONCILIATION AMOUNT                   *         
      *     INITIALIZE COMMISSION RELEASE RECORDS                     *         
      *     INITIALIZE COMMISSION HISTORY RECORDS                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'RN'                 TO WS-FY-RN-FLAG.                          
                                                                                
           MOVE 'S'                  TO WS-COMP-TYPE.                           
           MOVE 'P'                  TO WS-COMP-DISP.                           
           MOVE 'Y'                  TO WS-RECON-IND.                           
           MOVE 'R'                  TO WS-COMP-REASON.                         
           MOVE ZERO                 TO GCRL-PREMNO.                            
                                                                                
           SUBTRACT TOT-SC-PAID-LIFE-RN FROM TOT-SC-EARN-LIFE-RN                
               GIVING RECON-SC-LIFE-RN.                                         
                                                                                
           IF  RECON-SC-LIFE-RN = ZERO                                          
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'              TO WS-COV-TYPE                             
               MOVE RECON-SC-LIFE-RN TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           SUBTRACT TOT-SC-PAID-LTD-RN FROM TOT-SC-EARN-LTD-RN                  
               GIVING RECON-SC-LTD-RN.                                          
                                                                                
           IF  RECON-SC-LTD-RN = ZERO                                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'              TO WS-COV-TYPE                             
               MOVE RECON-SC-LTD-RN  TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           SUBTRACT TOT-SC-PAID-A-S-RN FROM TOT-SC-EARN-A-S-RN                  
               GIVING RECON-SC-A-S-RN.                                          
                                                                                
           IF  RECON-SC-A-S-RN = ZERO                                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'              TO WS-COV-TYPE                             
               MOVE RECON-SC-A-S-RN  TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           MOVE 'S'                  TO WS-COMP-TYPE.                           
           MOVE 'P'                  TO WS-COMP-DISP.                           
           MOVE 'N'                  TO WS-RECON-IND.                           
           MOVE 'B'                  TO WS-COMP-REASON.                         
           MOVE ZERO                 TO GCRL-PREMNO.                            
                                                                                
           IF  TOT-SC-AMEND-RECOV-LIFE-RN = ZERO                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'              TO WS-COV-TYPE                             
               MOVE TOT-SC-AMEND-RECOV-LIFE-RN                                  
                                     TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           IF  TOT-SC-AMEND-RECOV-LTD-RN = ZERO                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'              TO WS-COV-TYPE                             
               MOVE TOT-SC-AMEND-RECOV-LTD-RN                                   
                                     TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
                                                                                
           IF  TOT-SC-AMEND-RECOV-A-S-RN = ZERO                                 
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'              TO WS-COV-TYPE                             
               MOVE TOT-SC-AMEND-RECOV-A-S-RN                                   
                                     TO WS-RECON-AMT                            
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               ADD WS-RECON-AMT-SC TO WS-TOT-REG-RECON-AMT-S-C.                 
      /                                                                         
       720-RECONCILE-FY-COMMISSIONS.                                            
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE REGULAR RECONCILIATION AMOUNT                   *         
      *     INITIALIZE COMMISSION RELEASE RECORDS                     *         
      *     INITIALIZE COMMISSION HISTORY RECORDS                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'FY'                        TO WS-FY-RN-FLAG.                   
           MOVE 'C'                         TO WS-COMP-TYPE.                    
      *                                                                         
      *    LIFE                                                                 
      *                                                                         
           SUBTRACT TOT-COMM-PAID-LIFE-FY FROM TOT-COMM-EARN-LIFE-FY            
               GIVING RECON-COMM-LIFE-FY.                                       
           ADD RECON-COMM-LIFE-FY           TO WS-TOT-REG-RECON-AMT.            
                                                                                
           IF  RECON-COMM-LIFE-FY = ZERO                                        
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'                     TO WS-COV-TYPE                      
               MOVE RECON-COMM-LIFE-FY      TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'Y'                     TO WS-RECON-IND                     
               MOVE 'F'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
                                                                                
           IF  TOT-COMM-AMEND-RECOV-LIFE-FY = ZERO                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'                     TO WS-COV-TYPE                      
               MOVE TOT-COMM-AMEND-RECOV-LIFE-FY                                
                                            TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'N'                     TO WS-RECON-IND                     
               MOVE 'A'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               MOVE 'E'                     TO WS-COMP-DISP                     
               MOVE +1                      TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
      *                                                                         
      *    LTD                                                                  
      *                                                                         
           SUBTRACT TOT-COMM-PAID-LTD-FY FROM TOT-COMM-EARN-LTD-FY              
               GIVING RECON-COMM-LTD-FY.                                        
           ADD RECON-COMM-LTD-FY            TO WS-TOT-REG-RECON-AMT.            
                                                                                
           IF  RECON-COMM-LTD-FY = ZERO                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'                     TO WS-COV-TYPE                      
               MOVE RECON-COMM-LTD-FY       TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'Y'                     TO WS-RECON-IND                     
               MOVE 'F'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
                                                                                
           IF  TOT-COMM-AMEND-RECOV-LTD-FY = ZERO                               
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'                     TO WS-COV-TYPE                      
               MOVE TOT-COMM-AMEND-RECOV-LTD-FY                                 
                                            TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'N'                     TO WS-RECON-IND                     
               MOVE 'A'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               MOVE 'E'                     TO WS-COMP-DISP                     
               MOVE +1                      TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
      *                                                                         
      *    A-S                                                                  
      *                                                                         
           SUBTRACT TOT-COMM-PAID-A-S-FY FROM TOT-COMM-EARN-A-S-FY              
               GIVING RECON-COMM-A-S-FY.                                        
           ADD RECON-COMM-A-S-FY TO WS-TOT-REG-RECON-AMT.                       
                                                                                
           IF  RECON-COMM-A-S-FY = ZERO                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'                     TO WS-COV-TYPE                      
               MOVE RECON-COMM-A-S-FY       TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'Y'                     TO WS-RECON-IND                     
               MOVE 'F'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
                                                                                
           IF  TOT-COMM-AMEND-RECOV-A-S-FY = ZERO                               
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'                     TO WS-COV-TYPE                      
               MOVE TOT-COMM-AMEND-RECOV-A-S-FY                                 
                                            TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'N'                     TO WS-RECON-IND                     
               MOVE 'A'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               MOVE 'E'                     TO WS-COMP-DISP                     
               MOVE +1                      TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
      /                                                                         
       730-RECONCILE-RN-COMMISSIONS.                                            
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     SUMMARIZE REGULAR RECONCILIATION AMOUNT                   *         
      *     INITIALIZE COMMISSION RELEASE RECORDS                     *         
      *     INITIALIZE COMMISSION HISTORY RECORDS                     *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE 'RN'                        TO WS-FY-RN-FLAG.                   
           MOVE 'C'                         TO WS-COMP-TYPE.                    
      *                                                                         
      *    LIFE                                                                 
      *                                                                         
           SUBTRACT TOT-COMM-PAID-LIFE-RN FROM TOT-COMM-EARN-LIFE-RN            
               GIVING RECON-COMM-LIFE-RN.                                       
           ADD RECON-COMM-LIFE-RN           TO WS-TOT-REG-RECON-AMT.            
                                                                                
           IF  RECON-COMM-LIFE-RN = ZERO                                        
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'                     TO WS-COV-TYPE                      
               MOVE RECON-COMM-LIFE-RN      TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'Y'                     TO WS-RECON-IND                     
               MOVE 'R'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
                                                                                
           IF  TOT-COMM-AMEND-RECOV-LIFE-RN = ZERO                              
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'T'                     TO WS-COV-TYPE                      
               MOVE TOT-COMM-AMEND-RECOV-LIFE-RN                                
                                            TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'N'                     TO WS-RECON-IND                     
               MOVE 'B'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               MOVE 'E'                     TO WS-COMP-DISP                     
               MOVE +13                     TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
      *                                                                         
      *    LTD                                                                  
      *                                                                         
           SUBTRACT TOT-COMM-PAID-LTD-RN FROM TOT-COMM-EARN-LTD-RN              
               GIVING RECON-COMM-LTD-RN.                                        
           ADD RECON-COMM-LTD-RN            TO WS-TOT-REG-RECON-AMT.            
                                                                                
           IF  RECON-COMM-LTD-RN = ZERO                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'                     TO WS-COV-TYPE                      
               MOVE RECON-COMM-LTD-RN       TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'Y'                     TO WS-RECON-IND                     
               MOVE 'R'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
                                                                                
           IF  TOT-COMM-AMEND-RECOV-LTD-RN = ZERO                               
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'L'                     TO WS-COV-TYPE                      
               MOVE TOT-COMM-AMEND-RECOV-LTD-RN                                 
                                            TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'N'                     TO WS-RECON-IND                     
               MOVE 'B'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               MOVE 'E'                     TO WS-COMP-DISP                     
               MOVE +13                     TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
      *                                                                         
      *    A-S                                                                  
      *                                                                         
           SUBTRACT TOT-COMM-PAID-A-S-RN FROM TOT-COMM-EARN-A-S-RN              
               GIVING RECON-COMM-A-S-RN.                                        
           ADD RECON-COMM-A-S-RN            TO WS-TOT-REG-RECON-AMT.            
                                                                                
           IF  RECON-COMM-A-S-RN = ZERO                                         
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'                     TO WS-COV-TYPE                      
               MOVE RECON-COMM-A-S-RN       TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'Y'                     TO WS-RECON-IND                     
               MOVE 'R'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
                                                                                
           IF  TOT-COMM-AMEND-RECOV-A-S-RN = ZERO                               
               NEXT SENTENCE                                                    
           ELSE                                                                 
               MOVE 'O'                     TO WS-COV-TYPE                      
               MOVE TOT-COMM-AMEND-RECOV-A-S-RN                                 
                                            TO WS-RECON-AMT                     
               MOVE 'P'                     TO WS-COMP-DISP                     
               MOVE 'N'                     TO WS-RECON-IND                     
               MOVE 'B'                     TO WS-COMP-REASON                   
               MOVE ZERO                    TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT                    
               MOVE 'E'                     TO WS-COMP-DISP                     
               MOVE +13                     TO GCRL-PREMNO                      
               PERFORM 910-COMP-HISTORY-RECORD THRU 919-EXIT                    
               PERFORM 900-COMM-RELEASE-RECORD THRU 909-EXIT.                   
      /                                                                         
       900-COMM-RELEASE-RECORD.                                                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     WRITE COMMISSION RELEASE RECORDS ONTO THE DATA BASE       *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE 'W'                    TO GCRL-RECORD-TYPE.                     
           MOVE WS-PREV-GROUP          TO GCRL-KEY-GROUP.                       
           MOVE WS-PREV-ACCOUNT        TO GCRL-KEY-ACCOUNT.                     
           MOVE WS-PREV-AGENT          TO GCRL-KEY-AGENT.                       
           MOVE 1      TO GCRL-VLNO.                                            
           MOVE WS-PREV-GROUP          TO GCRL-GROUP.                           
                                                                                
           IF  GGICURRENCY = 1                                                  
               MOVE 01                 TO GCRL-CURRENCY                         
           ELSE                                                                 
               IF  GGICURRENCY = 2                                              
                   MOVE 02             TO GCRL-CURRENCY                         
               ELSE                                                             
                   IF  GGICURRENCY = 8                                          
                       MOVE 10         TO GCRL-CURRENCY                         
                   ELSE                                                         
                       IF  GGICURRENCY = 7                                      
                           MOVE 35     TO GCRL-CURRENCY                         
                       ELSE                                                     
                           IF  GGICURRENCY = 5                                  
                               MOVE 48 TO GCRL-CURRENCY.                        
                                                                                
           MOVE 12 TO GCRL-MODE.                                                
CHG        MOVE '2B1E' TO DATE-PARAMETERS.                              YEAR2000
           MOVE GGI-ACCT-EFFECTIVE TO VDATE-ALIS-DATE1.                 YEAR2000
CHG        CALL  GC2DATE  USING DATE-PARAMETERS.                        YEAR2000
CHG        MOVE VDATE1-YYYYMMDD TO GCRL-ACCT-EFFECTIVE-DATE.            YEAR2000
CHG                                                                             
           MOVE H5-GROUP-NAME TO GCRL-BILLING-NAME.                             
CHG                                                                             
CHG        MOVE NEXT-RECON-DATE OF GWCORGRACCT TO VDATE-ALIS-DATE1.     YEAR2000
CHG        CALL  GC2DATE  USING DATE-PARAMETERS.                        YEAR2000
CHG        MOVE VDATE1-YYYYMMDD TO GCRL-PREM-DUE-DATE.                  YEAR2000
                                                                                
           IF  WS-COV-TYPE = 'T'                                                
               MOVE GGIFOGL-CODE (1) TO WS-FOGL-CODE                            
           ELSE                                                                 
               IF  WS-COV-TYPE = 'L'                                            
                   MOVE GGIFOGL-CODE (3) TO WS-FOGL-CODE                        
               ELSE                                                             
                   IF  WS-COV-TYPE = 'O'                                        
                       MOVE GGIFOGL-CODE (5) TO WS-FOGL-CODE                    
                       MOVE 0 TO WS-FOGL-BYTE (3)                               
                       MOVE 7 TO WS-FOGL-BYTE (4).                              
                                                                                
           MOVE WS-FOGL-CODE TO GCRL-FOGL-CODE.                                 
                                                                                
           IF  WS-FOGL-BYTE (7) = '1' OR '2'                                    
               MOVE +990 TO GCRL-MAN                                            
           ELSE                                                                 
               MOVE +991 TO GCRL-MAN.                                           
                                                                                
           MOVE WS-PREV-ACCOUNT TO TEMP-ACCT.                                   
           MOVE TEMP-ACCOUNT    TO GCRL-SUB-ACCOUNT.                            
                                                                                
           MOVE GGIGROUP-OFFICE TO GCRL-BRANCH.                                 
           MOVE WS-PREV-AGENT   TO GCRL-AGENT-CODE.                             
                                                                                
      *    MOVE GGIGROUP-OFFICE TO FOF-BRANCH-NUMBER.                           
                                                                                
MAN02 *%   OBTAIN CALC FIELD-OFFICE                                             
MAN02      PERFORM 9005-OBTAIN-FIELD-OFFICE                                     
MAN02         THRU 9005-OBTAIN-FIELD-OFFICE-EXIT.                               
MAN02 *        IF  DB-REC-NOT-FOUND                                             
      *            MOVE ZERO TO FOF-MLI-MANAGER-CODE.                           
      *                                                                         
      *    MOVE FOF-MLI-MANAGER-CODE TO GCRL-MGR.                               
                                                                                
           IF  WS-FY-RN-FLAG = 'FY'                                             
               IF  WS-COV-TYPE = 'T'                                            
                   MOVE WS-FY-LIFE-PCT    TO GCRL-SHARE                         
               ELSE                                                             
               IF  WS-COV-TYPE = 'L'                                            
                   MOVE WS-FY-LTD-PCT     TO GCRL-SHARE                         
               ELSE                                                             
               IF  WS-COV-TYPE = 'O'                                            
                   MOVE WS-FY-A-S-PCT     TO GCRL-SHARE                         
               ELSE                                                             
                   MOVE +100.00           TO GCRL-SHARE                         
           ELSE                                                                 
           IF  WS-FY-RN-FLAG = 'RN'                                             
               IF  WS-COV-TYPE = 'T'                                            
                   MOVE WS-RN-LIFE-PCT    TO GCRL-SHARE                         
               ELSE                                                             
               IF  WS-COV-TYPE = 'L'                                            
                   MOVE WS-RN-LTD-PCT     TO GCRL-SHARE                         
               ELSE                                                             
               IF  WS-COV-TYPE = 'O'                                            
                   MOVE WS-RN-A-S-PCT     TO GCRL-SHARE                         
               ELSE                                                             
                   MOVE +100.00           TO GCRL-SHARE                         
           ELSE                                                                 
               MOVE +100.00               TO GCRL-SHARE.                        
                                                                                
           MOVE  10  TO GCRL-SOURCE.                                            
           MOVE 342  TO GCRL-CAUSE.                                             
                                                                                
           IF  WS-COMP-TYPE = 'C'                                               
               IF  WS-COMP-REASON = 'F' OR 'A'                                  
                   IF  WS-COMP-DISP = 'E'                                       
                       MOVE +118          TO GCRL-CODE (1)                      
                   ELSE                                                         
                       MOVE +113          TO GCRL-CODE (1)                      
               ELSE                                                             
                   IF  WS-COMP-DISP = 'E'                                       
                       MOVE +118          TO GCRL-CODE (1)                      
                   ELSE                                                         
                       IF  WS-PSMPOLICY-YEAR = +2                               
                           MOVE +121      TO GCRL-CODE (1)                      
                       ELSE                                                     
                           MOVE +131      TO GCRL-CODE (1)                      
           ELSE                                                                 
               IF  WS-COMP-TYPE = 'S'                                           
                   IF  WS-COMP-REASON = 'F' OR 'A'                              
                       MOVE +141          TO GCRL-CODE (1)                      
                   ELSE                                                         
                       MOVE +142          TO GCRL-CODE (1).                     
                                                                                
           MOVE +0              TO GCRL-CODE (2).                               
           MOVE +0              TO GCRL-CODE (3).                               
                                                                                
           IF  WS-COMP-TYPE = 'S'                                               
               COMPUTE WS-RECON-AMT-SC ROUNDED = WS-RECON-AMT * 1               
               MOVE WS-RECON-AMT-SC    TO GCRL-CRAMT (1)                        
           ELSE                                                                 
               MOVE WS-RECON-AMT       TO GCRL-CMAMT (1).                       
                                                                                
           IF COMP-TYPE OF GWCORCOMP = 'S' AND                                  
              WS-RECON-AMT-SC = ZERO                                            
              GO TO 909-EXIT.                                                   
                                                                                
           MOVE 'CR' TO TRANS-TYPE OF GWCORTRANS.                               
           MOVE GCOMRLSE                                                        
               TO TRANS-DETAILS OF GWCORTRANS.                                  
           MOVE -1 TO DIRECT-DBKEY.                                             
      *%   STORE GWCORTRANS.                                                    
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORTRANS                                       
MAN02                 FCCSPL-GWCORTRANS                                         
MAN02                 GWCORTRANS                                                
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       909-EXIT.                                                                
           EXIT.                                                                
                                                                                
       910-COMP-HISTORY-RECORD.                                                 
      ******************************************************************        
      *                                                                         
      *     WRITE COMMISSION HISTORY RECORDS ONTO THE DATA BASE                 
      *                                                                         
      ******************************************************************        
      *  SEP/90 M. PRANGE.                                                      
      *       - USE ACTUAL AGENT % FROM GIPSY MASTER IN AGENT-SPLIT             
      *         FIELD INSTEAD OF HARD-CODING 100%.                              
      ******************************************************************        
                                                                                
           MOVE WS-PREV-GROUP       TO GROUP-NUMBER      OF GWCORCOMP.          
           MOVE WS-PREV-ACCOUNT     TO GR-ACCOUNT        OF GWCORCOMP.          
           MOVE NEXT-RECON-DATE     TO COMP-EFF-DATE     OF GWCORCOMP.          
           MOVE WS-PREV-AGENT       TO AGENT-NUMBER      OF GWCORCOMP           
                                       AGENT-NUMBER      OF GWCORAGENT.         
           MOVE SPACES              TO GFO-NUMBER        OF GWCORCOMP.          
           MOVE ZERO                TO GROUP-REP         OF GWCORCOMP.          
           MOVE WS-ALIS-RUN-DATE    TO COMP-PROCESS-DATE OF GWCORCOMP.          
           MOVE WS-COV-TYPE         TO COV-TYPE          OF GWCORCOMP.          
           MOVE WS-COMP-TYPE        TO COMP-TYPE         OF GWCORCOMP.          
           MOVE WS-COMP-REASON      TO COMP-REASON       OF GWCORCOMP.          
           MOVE WS-RECON-IND        TO RECON-IND         OF GWCORCOMP.          
           MOVE WS-COMP-DISP        TO COMP-DISP         OF GWCORCOMP.          
           IF COMP-TYPE OF GWCORCOMP = 'S'                                      
               COMPUTE WS-RECON-AMT-SC ROUNDED = WS-RECON-AMT * 1               
               MOVE WS-RECON-AMT-SC TO COMP-AMT          OF GWCORCOMP           
           ELSE                                                                 
               MOVE WS-RECON-AMT    TO COMP-AMT          OF GWCORCOMP.          
                                                                                
           IF COMP-TYPE OF GWCORCOMP = 'S' AND                                  
              WS-RECON-AMT-SC = ZERO                                            
              GO TO 919-EXIT.                                                   
                                                                                
           IF  WS-FY-RN-FLAG = 'FY'                                             
               IF  COV-TYPE OF GWCORCOMP = 'T'                                  
                   MOVE WS-FY-LIFE-PCT    TO AGENT-SPLIT OF GWCORCOMP           
               ELSE                                                             
               IF  COV-TYPE OF GWCORCOMP = 'L'                                  
                   MOVE WS-FY-LTD-PCT     TO AGENT-SPLIT OF GWCORCOMP           
               ELSE                                                             
               IF  COV-TYPE OF GWCORCOMP = 'O'                                  
                   MOVE WS-FY-A-S-PCT     TO AGENT-SPLIT OF GWCORCOMP           
               ELSE                                                             
                   MOVE +100.00           TO AGENT-SPLIT OF GWCORCOMP           
           ELSE                                                                 
           IF  WS-FY-RN-FLAG = 'RN'                                             
               IF  COV-TYPE OF GWCORCOMP = 'T'                                  
                   MOVE WS-RN-LIFE-PCT    TO AGENT-SPLIT OF GWCORCOMP           
               ELSE                                                             
               IF  COV-TYPE OF GWCORCOMP = 'L'                                  
                   MOVE WS-RN-LTD-PCT     TO AGENT-SPLIT OF GWCORCOMP           
               ELSE                                                             
               IF  COV-TYPE OF GWCORCOMP = 'O'                                  
                   MOVE WS-RN-A-S-PCT     TO AGENT-SPLIT OF GWCORCOMP           
               ELSE                                                             
                   MOVE +100.00           TO AGENT-SPLIT OF GWCORCOMP           
           ELSE                                                                 
               MOVE +100.00               TO AGENT-SPLIT OF GWCORCOMP.          
                                                                                
           MOVE ZERO TO PREM-AMT OF GWCORCOMP.                                  
                                                                                
      *%   OBTAIN CALC GWCORAGENT.                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   STORE GWCORCOMP.                                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-INSERT                                             
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 GWCORCOMP                                                 
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
           IF  COMP-TYPE = 'C'                                                  
           AND COMP-DISP = 'E'                                                  
      *%       OBTAIN FIRST GWCORACCUM WITHIN GRACCT-ACCUM                      
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 7 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +7  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-FETCH-FIRST                                    
MAN02                     FCCSPLIO-GWCORACCUM                                   
MAN02                     FCCSPL-GWCORACCUM                                     
MAN02                     FCCSPL-GRACCT-ACCUM                                   
MAN02                     GWCORACCUM                                            
MAN02                     FCCSPL-OBTAIN                                         
MAN02                     FCCSPL-NOKEEP                                         
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            IF NOT DB-END-OF-SET                                             
IOS               PERFORM 799-SQL-STATUS-02                                     
IOS                  THRU 799-SQL-STATUS-02-EXIT                                
IOS            ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
               GO TO 919-EXIT.                                                  
                                                                                
           PERFORM 920-FIND-ACCUM                                               
               UNTIL PREM-DUE-DATE = COMP-EFF-DATE                              
               OR    DB-END-OF-SET.                                             
                                                                                
           IF  DB-END-OF-SET                                                    
               MOVE COMP-EFF-DATE TO PREM-DUE-DATE                              
               MOVE ZERO            TO PREM-AMT-PAID                            
               MOVE WS-RECON-AMT    TO COMM-AMT-EARNED                          
      *%       STORE GWCORACCUM                                                 
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 8 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-INSERT                                         
MAN02                     FCCSPLIO-GWCORACCUM                                   
MAN02                     FCCSPL-GWCORACCUM                                     
MAN02                     GWCORACCUM                                            
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT                                      
           ELSE                                                                 
               ADD WS-RECON-AMT TO COMM-AMT-EARNED                              
      *%       MODIFY GWCORACCUM.                                               
IOS            MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                      
IOS            MOVE 9 TO FCCSPL-DML-SEQ-NO                                      
IOS            MOVE +4  TO FCCSPL-ADDRESS-COUNT                                 
MAN02          CALL GWFADDR                                                     
MAN02               USING FCCSPL-ADDRESS-AREA                                   
MAN02                     FCCSPL-UPDATE                                         
MAN02                     FCCSPLIO-GWCORACCUM                                   
MAN02                     FCCSPL-GWCORACCUM                                     
MAN02                     GWCORACCUM                                            
IOS            END-CALL                                                         
FXXTOK         CALL GWFSPLB1                                                    
IOS                 USING DUMMY-PARM-1                                          
IOS                       DUMMY-PARM-2                                          
IOS                       DBLINK-SUBSCHEMA-CONTROL                              
IOS                       DBLINK-RECORD-SET-KEYS                                
IOS                       DBLINK-CURSOR-CODES                                   
IOS            END-CALL                                                         
IOS            PERFORM 799-SQL-STATUS                                           
IOS               THRU 799-SQL-STATUS-EXIT.                                     
                                                                                
       919-EXIT.                                                                
           EXIT.                                                                
                                                                                
       920-FIND-ACCUM.                                                          
                                                                                
      *%   OBTAIN NEXT GWCORACCUM WITHIN GRACCT-ACCUM                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
      /                                                                         
       1000-PRINT-A-LINE.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     PRINT A LINE ON RECONCILIATION STATEMENT                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           IF ENGLISH                                                           
               CALL 'DLSWRITE' USING DLSWE-SYSNNN                               
                                     DLSWE-RET-CODE                             
                                     PRINT-LINE                                 
                                     DLSWE-REC-SIZE                             
                                     DLSWE-BLK-SIZE                             
                                     DLSWE-FORMAT                               
                                     DLSWE-REC-COUNT                            
                                                                                
               IF DLSWE-RET-CODE = +0                                           
                                OR +4                                           
                   NEXT SENTENCE                                                
               ELSE                                                             
                   DISPLAY 'DLSWRITE FAILED - SYS021' UPON CONSOLE              
FXXTOK             GO TO 799-SQL-STATUS.                                        
                                                                                
           IF FRENCH                                                            
               CALL 'DLSWRITE' USING DLSWF-SYSNNN                               
                                     DLSWF-RET-CODE                             
                                     PRINT-LINE                                 
                                     DLSWF-REC-SIZE                             
                                     DLSWF-BLK-SIZE                             
                                     DLSWF-FORMAT                               
                                     DLSWF-REC-COUNT                            
                                                                                
               IF DLSWF-RET-CODE = +0                                           
                                OR +4                                           
                   NEXT SENTENCE                                                
               ELSE                                                             
                   DISPLAY 'DLSWRITE FAILED - SYS021' UPON CONSOLE              
FXXTOK             GO TO 799-SQL-STATUS.                                        
      /                                                                         
       1100-ACTION-REPORT.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     FORMAT ERROR-REPORT LINE                                  *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           MOVE EXT-COMM-GROUP-NUMBER TO ERROR-GROUP.                           
           MOVE EXT-COMM-GROUP-ACCOUNT TO ERROR-ACCOUNT.                        
MAN02      CALL QDATEQ2 USING QDATE-FORMATAD                                    
MAN02                         EXT-COMM-EFF-DATE                                 
MAN02                         ERROR-DATE.                                       
           MOVE EXT-COMM-AGENT-NUMBER TO ERROR-AGENT.                           
           MOVE EXT-COMM-COMP-TYPE TO ERROR-COMP-TYPE.                          
           MOVE EXT-COMM-COMP-DISP TO ERROR-COMP-DISP.                          
           MOVE EXT-COMM-COMP-REASON TO ERROR-COMP-REASON.                      
           MOVE EXT-COMM-COV-TYPE TO ERROR-COV-TYPE.                            
                                                                                
           IF  ERROR-SWITCH = '1'                                               
               MOVE ERR-MSG-1 TO ERROR-MSG.                                     
                                                                                
           IF  ERROR-SWITCH = '2'                                               
               MOVE ERR-MSG-2 TO ERROR-MSG.                                     
                                                                                
           IF  ERROR-SWITCH = '3'                                               
               MOVE ERR-MSG-3 TO ERROR-MSG.                                     
                                                                                
           IF  ERROR-SWITCH = '4'                                               
               MOVE ERR-MSG-4 TO ERROR-MSG                                      
               MOVE ZERO   TO ERROR-GROUP                                       
                              ERROR-AGENT                                       
               MOVE SPACES TO ERROR-ACCOUNT                                     
                              ERROR-DATE                                        
                              ERROR-COMP-TYPE                                   
                              ERROR-COMP-DISP                                   
                              ERROR-COMP-REASON                                 
                              ERROR-COV-TYPE.                                   
                                                                                
           MOVE ACTION-LINE TO DLSA-RECORD.                                     
           PERFORM 1200-PRINT-MESSAGE.                                          
           MOVE '0' TO ERROR-SWITCH.                                            
      /                                                                         
       1200-PRINT-MESSAGE.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     PRINT ERROR-REPORT LINE                                   *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           CALL 'DLSWRITE' USING DLSA-SYSNNN                                    
                                 DLSA-RET-CODE                                  
                                 DLSA-RECORD                                    
                                 DLSA-REC-SIZE                                  
                                 DLSA-BLK-SIZE                                  
                                 DLSA-FORMAT                                    
                                 DLSA-REC-COUNT.                                
                                                                                
           IF  DLSA-RET-CODE = +0                                               
                            OR +4                                               
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'DLSWRITE FAILED - SYS022' UPON CONSOLE                  
FXXTOK         GO TO 799-SQL-STATUS.                                            
      /                                                                         
       WTL-TO-OPERATOR.                                                         
           MOVE SPACES TO WTL-REPLY-AREA.                                       
           CALL 'WTL' USING WTL-MESSAGE-AREA                                    
                            WTL-FLAG                                            
                            WTL-REPLY                                           
                            WTL-REPLY-AREA.                                     
       WTL-TO-OPERATOR-EXIT.                                                    
           EXIT.                                                                
                                                                                
       INIT-FIELDS.                                                             
           MOVE +0          TO TEMP-1 (WS-SUB)                                  
                               TEMP-2 (WS-SUB).                                 
                                                                                
       INIT-FIELDS-EXIT.                                                        
           EXIT.                                                                
                                                                                
       7000-FIND-HEADINGS.                                                      
           ADD  +1              TO WS-SUB2.                                     
           MOVE +0              TO WS-SUB3.                                     
           PERFORM 8000-READ-HEADINGS THRU 8000-EXIT.                           
           IF WS-SUB2 < +21                                                     
              MOVE HEADING-LINE       TO ENGLISH-HEADING (WS-SUB2)              
           ELSE                                                                 
              SUBTRACT +20            FROM WS-SUB2 GIVING WS-SUB3               
              MOVE HEADING-LINE       TO FRENCH-HEADING  (WS-SUB3).             
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       7010-MOVE-HEADINGS.                                                      
           MOVE ENGLISH-HEADING (01) TO HEADING-01.                             
           MOVE ENGLISH-HEADING (04) TO HEADING-04.                             
           MOVE ENGLISH-HEADING (05) TO HEADING-05.                             
           MOVE ENGLISH-HEADING (06) TO HEADING-06.                             
           MOVE ENGLISH-HEADING (07) TO HEADING-07.                             
           MOVE ENGLISH-HEADING (08) TO HEADING-08.                             
           MOVE ENGLISH-HEADING (09) TO HEADING-09.                             
           MOVE ENGLISH-HEADING (10) TO HEADING-10.                             
           MOVE ENGLISH-HEADING (11) TO HEADING-11.                             
           MOVE ENGLISH-HEADING (12) TO HEADING-12.                             
           MOVE ENGLISH-HEADING (13) TO DASH-LINE.                              
           MOVE ENGLISH-HEADING (14) TO TOTAL-01.                               
           MOVE ENGLISH-HEADING (15) TO TOTAL-02.                               
           MOVE ENGLISH-HEADING (16) TO TOTAL-03.                               
                                                                                
           MOVE FRENCH-HEADING  (01) TO HEADING-F01.                            
           MOVE FRENCH-HEADING  (04) TO HEADING-F04.                            
           MOVE FRENCH-HEADING  (05) TO HEADING-F05.                            
           MOVE FRENCH-HEADING  (06) TO HEADING-F06.                            
           MOVE FRENCH-HEADING  (07) TO HEADING-F07.                            
           MOVE FRENCH-HEADING  (08) TO HEADING-F08.                            
           MOVE FRENCH-HEADING  (09) TO HEADING-F09.                            
           MOVE FRENCH-HEADING  (10) TO HEADING-F10.                            
           MOVE FRENCH-HEADING  (11) TO HEADING-F11.                            
           MOVE FRENCH-HEADING  (12) TO HEADING-F12.                            
           MOVE FRENCH-HEADING  (16) TO TOTAL-F02.                              
           MOVE FRENCH-HEADING  (17) TO TOTAL-F03.                              
                                                                                
       7010-EXIT.                                                               
           EXIT.                                                                
                                                                                
       8000-READ-HEADINGS.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     READ HEADINGS FROM PDS                                    *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           CALL 'DLSREAD' USING DLSH-SYSNNN                                     
                                DLSH-RET-CODE                                   
                                HEADING-LINE                                    
                                DLSH-REC-SIZE                                   
                                DLSH-BLK-SIZE                                   
                                DLSH-FORMAT                                     
                                DLSH-REC-COUNT.                                 
                                                                                
           IF  DLSH-RET-CODE = 4 OR 0                                           
               NEXT SENTENCE                                                    
           ELSE                                                                 
               DISPLAY 'ERROR WHILE READING HEADINGS - SYS015'                  
                   UPON CONSOLE                                                 
FXXTOK         GO TO 799-SQL-STATUS.                                            
                                                                                
       8000-EXIT.                                                               
           EXIT.                                                                
      /                                                                         
       8010-READ-RUNDATE.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *     READ RUNDATE FROM PARMLIB                                 *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           CALL 'DLSREAD' USING DLSR-SYSNNN                                     
                                DLSR-RET-CODE                                   
                                PROGRAM-RUN-DATE-RECORD                         
                                DLSR-REC-SIZE                                   
                                DLSR-BLK-SIZE                                   
                                DLSR-FORMAT                                     
                                DLSR-REC-COUNT.                                 
                                                                                
           IF  DLSR-RET-CODE = 0                                                
               NEXT SENTENCE                                                    
           ELSE                                                                 
              IF  DLSR-RET-CODE = 4                                             
                  MOVE 'Y' TO EOF-SWITCH                                        
              ELSE                                                              
                  DISPLAY 'ERROR WHILE READING RUNDATE - SYS019'                
                      UPON CONSOLE                                              
FXXTOK            GO TO 799-SQL-STATUS.                                         
       8010-EXIT.                                                               
           EXIT.                                                                
                                                                                
MAN02  9005-OBTAIN-FIELD-OFFICE.                                                
           MOVE GGIGROUP-OFFICE TO FDOF-PARM2.                                  
           MOVE 'GETRAN'        TO FDOF-FUNCTION.                               
                                                                                
           CALL 'ZACCVSAM'   USING FDOF-PARM1                                   
                                   FDOF-PARM2                                   
                                   FIELD-OFFICE-FILE.                           
                                                                                
           IF  FDOF-ERRCODE NOT = LOW-VALUES                                    
               MOVE ZERO                 TO GCRL-MGR                            
           ELSE                                                                 
               MOVE FOF-MLI-MANAGER-CODE TO GCRL-MGR                            
           END-IF.                                                              
                                                                                
MAN02 *    MOVE FDOFFILE TO LOGICAL-RECORD-NAME.                                
MAN02 *    CALL GAEDATSR USING OBTAIN-KEYED                                     
MAN02 *                        FIELD-OFFICE-FILE                                
MAN02 *                        ICBM.                                            
MAN02 *    IF KEYED-LR-NOT-FOUND                                                
MAN02 *        MOVE '0326' TO ERROR-STATUS                                      
MAN02 *    ELSE                                                                 
MAN02 *        MOVE ZEROS TO ERROR-STATUS                                       
MAN02 *    END-IF.                                                              
MAN02  9005-OBTAIN-FIELD-OFFICE-EXIT.                                           
MAN02      EXIT.                                                                
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
