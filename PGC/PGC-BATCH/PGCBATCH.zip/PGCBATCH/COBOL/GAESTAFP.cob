       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    GAESTAFP.                                                 
       AUTHOR. ZORAN PERISIC                                                    
        DATE-WRITTEN. 03/21/94.                                                 
        DATE-COMPILED.                                                          
      *****************************************************************         
      * PROGRAM CHECKS IF THE GROUP IS A STAFF-GROUP                            
      *****************************************************************         
      * 31MAY97 MCAUSDO ADD STAFF PLAN GROUPS 95541-2                           
      *         RECOMPILED TO GET CHANGED COPYBOOK "MSTAFPLN"                   
      *                                                                         
      *   JAN/2013  C MUNCAN- RECOMPILED TO PICK-UP NEW STAFF PLANS             
      *                       IN COPYBOOK MSTAFPLN FOR TASK LOG 183553          
      *                                                                         
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       CONFIGURATION SECTION.                                                   
                                                                                
         SOURCE-COMPUTER. IBM-370.                                              
         OBJECT-COMPUTER. IBM-370.                                              
                                                                                
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                    PIC X(37)                                
                      VALUE 'STAFFPLN WORKING STORAGE STARTS HERE*'.            
                                                                                
       01  MSTAFPLN.                                                            
            COPY MSTAFPLN.                                                      
                                                                                
                                                                                
       01  WS-END                       PIC X(23)                               
                         VALUE 'STAFFPLN WS ENDS HERE *'.                       
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  GAESECUR-PROT            SYNC.                                       
                                    COPY GARSECUR.                              
                                    COPY GARSECSP.                              
                                    COPY GARSECPR.                              
                                                                                
       PROCEDURE DIVISION USING GAESECUR-PROT.                                  
                                                                                
           MOVE 'N' TO GAESECSP-RESPONSE.                                       
                                                                                
           SET MSTAFPLN-IDX TO 1.                                               
                                                                                
           SEARCH MSTAFPLN-TABLE-ENTRY VARYING MSTAFPLN-IDX                     
                    AT END GO TO CHECK-STAFF-PLAN-EXIT                          
               WHEN GAESECSP-GROUP =                                            
                    MSTAFPLN-GROUP (MSTAFPLN-IDX)                               
                    MOVE 'Y' TO GAESECSP-RESPONSE.                              
                                                                                
        CHECK-STAFF-PLAN-EXIT.                                                  
                                                                                
            GOBACK.                                                             
                                                                                
