       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. HCSACLOG.                                                    
       AUTHOR.     G MOHR.                                                      
       DATE-WRITTEN. 25 MAR 1998.                                               
       DATE-COMPILED.                                                           
                                                                                
      ************************************************************              
      *                                                                         
      * SHORT DESCRIPTION:                                                      
      *                                                                         
      * UPDATE COPY LOGGING TABLES WITH THE INPUT COPY REQUESTS                 
      *                                                                         
      * LANGUAGE:    COBOL II                                                   
      *                                                                         
      * CALLED BY:   NONE                                                       
      *                                                                         
      * CALLS:       NONE                                                       
      *                                                                         
      * UTILITIES: NONE                                                         
      *                                                                         
      * INPUT       - COPY REQUEST FILE                                         
      *                                                                         
      * OUTPUT     NONE                                                         
      *                                                                         
      * COPYLIB     - PEN.GROUP.PROD.STANDARD.COPYLIB                           
      ************************************************************              
      ************************************************************              
      *                                                                         
      *   CHANGE LOG:                                                           
      *  ************                                                           
      *                                                                         
      *  DATE     PGMR      DESCRIPTION                                         
      *  ------   -------   --------------------------------------              
      *  MAR 2022 BRANDHA   INITIAL IMPLEMENTSATION                             
      ************************************************************              
       ENVIRONMENT DIVISION.                                                    
      *---------------------                                                    
       CONFIGURATION SECTION.                                                   
       SOURCE-COMPUTER.  IBM-370-165.                                           
       OBJECT-COMPUTER.  IBM-370-165.                                           
      *                                                                         
       INPUT-OUTPUT SECTION.                                                    
      *                                                                         
       FILE-CONTROL.                                                            
                                                                                
             SELECT EXTRACT-REQ ASSIGN TO EXTREQ.                               
             SELECT PARM-FILE   ASSIGN TO PARMIN.                               
      *============*                                                            
       DATA DIVISION.                                                           
      *============*                                                            
       FILE SECTION.                                                            
                                                                                
      ***----------------------------------------------------------             
      ***  INPUT EXTRACT FILE                                                   
      ***----------------------------------------------------------             
       FD  EXTRACT-REQ.                                                         
       01  REQUEST-REC.                                                         
           05  GROUPNO      PIC 9(7).                                           
           05  ACCT         PIC X(3).                                           
           05  FROMCERT     PIC X(10).                                          
           05  TOCERT       PIC X(10).                                          
           05  CANONLY      PIC X.                                              
           05  PROTECT      PIC X.                                              
           05  EXCEPTN      PIC X.                                              
           05  FILL         PIC X(47).                                          
      ***----------------------------------------------------------             
      ***  INPUT PARMS                                                          
      ***----------------------------------------------------------             
       FD  PARM-FILE.                                                           
       01  PARM-REC.                                                            
           05  APPLID       PIC X(10).                                          
           05  FROMREGN     PIC XX.                                             
           05  TOREGN       PIC XX.                                             
           05  FILL         PIC X(66).                                          
                                                                                
      /                                                                         
      *=======================*                                                 
       WORKING-STORAGE SECTION.                                                 
      *=======================*                                                 
                                                                                
       01  WS-START                   PIC X(32) VALUE                           
           'WORKING STORAGE STARTS- GW2ACLOG'.                                  
                                                                                
           EXEC SQL INCLUDE SQLCA    END-EXEC.                                  
           EXEC SQL INCLUDE ACPYRQST END-EXEC.                                  
           EXEC SQL INCLUDE ACPYDETL END-EXEC.                                  
                                                                                
       01  WS-AUDIT-LOG.                                                        
           05  WS-LOG-REQUEST-ID            PIC S9(9) USAGE COMP.               
           05  WS-LOG-SEQ-NO                PIC S9(9) USAGE COMP.               
       01  WS-WORKING-VALUES.                                                   
           05  WS-REQUEST-ID        PIC S9(9) USAGE COMP.                       
           05  WS-SQL-CODE          PIC ----------.                             
                                                                                
       01  WS-SWITCHES.                                                         
           05  PARM-EOF-IND            PIC X      VALUE 'N'.                    
               88  PARM-EOF                       VALUE 'Y'.                    
               88  NOT-PARM-EOF                   VALUE 'N'.                    
           05  EXT-EOF-IND             PIC X      VALUE 'N'.                    
               88  EXT-EOF                        VALUE 'Y'.                    
               88  NOT-EXT-EOF                    VALUE 'N'.                    
       01  WS-END                     PIC X(32) VALUE                           
           'WORKING STORAGE ENDS  - HCSPCU02'.                                  
      /                                                                         
       PROCEDURE DIVISION.                                                      
                                                                                
      ***--------------------------------------------------------------         
      *** OPEN FILES                                                            
      ***--------------------------------------------------------------         
           OPEN INPUT  EXTRACT-REQ.                                             
           OPEN INPUT  PARM-FILE.                                               
                                                                                
      ***--------------------------------------------------------------         
      *** READ AND VALIDATE PARMS                                               
      ***--------------------------------------------------------------         
           READ PARM-FILE AT END SET PARM-EOF TO TRUE.                          
           IF PARM-EOF                                                          
              DISPLAY 'PARMS MISSING'                                           
              GO TO A-100-CLOSE                                                 
           END-IF.                                                              
           MOVE APPLID    TO APPLICATION.                                       
           MOVE FROMREGN  TO FROM-REGION.                                       
           MOVE TOREGN    TO TO-REGION.                                         
           MOVE 0 TO WS-LOG-REQUEST-ID.                                         
           MOVE 0 TO WS-LOG-SEQ-NO.                                             
                                                                                
      ***--------------------------------------------------------------         
      *** INITIAL READ OF EXTRACT FILE                                          
      ***--------------------------------------------------------------         
           READ EXTRACT-REQ AT END SET EXT-EOF TO TRUE.                         
                                                                                
      ***--------------------------------------------------------------         
      *** IF A REQUEST WAS READ CREATE THE REQUEST RECORD ON THE TABLE          
      ***--------------------------------------------------------------         
           IF NOT-EXT-EOF                                                       
                                                                                
              MOVE SPACES TO REQUEST-COMMENT;                                   
                                                                                
              EXEC SQL                                                          
                   SELECT REQUEST_ID                                            
                    INTO :WS-REQUEST-ID                                         
                    FROM FINAL TABLE                                            
                     (INSERT INTO APPLICATION_COPY_REQUEST                      
                      (REQUEST_COMMENT)                                         
                      VALUES (:REQUEST-COMMENT))                                
              END-EXEC                                                          
                                                                                
              IF SQLCODE = 0                                                    
                 MOVE WS-REQUEST-ID TO WS-LOG-REQUEST-ID                        
                                                                                
              ELSE                                                              
                  MOVE SQLCODE TO WS-SQL-CODE                                   
                  DISPLAY 'FAILED WRITING COPY REQUEST TO AUDIT LOG'            
                  DISPLAY ' SQL RETURN CODE=' WS-SQL-CODE                       
                  GO TO A-100-CLOSE                                             
              END-IF                                                            
           ELSE                                                                 
             DISPLAY 'NO INPUT COPY REQUESTS'                                   
             GO TO A-100-CLOSE                                                  
           END-IF.                                                              
           PERFORM C-100-MAIN THRU C-100-EXIT                                   
                   UNTIL EXT-EOF.                                               
                                                                                
       A-100-CLOSE.                                                             
      ***--------------------------------------------------------------         
      *** CLOSE FILES                                                           
      ***--------------------------------------------------------------         
           CLOSE EXTRACT-REQ.                                                   
           CLOSE PARM-FILE.                                                     
           STOP RUN.                                                            
                                                                                
                                                                                
       C-100-MAIN.                                                              
                                                                                
           MOVE GROUPNO  TO CONTRACT.                                           
           MOVE ACCT     TO ACCOUNT.                                            
           MOVE FROMCERT TO START-CERT.                                         
           MOVE TOCERT   TO END-CERT.                                           
           MOVE CANONLY  TO CAN-ONLY-IND.                                       
           MOVE PROTECT  TO PROTECTED-IND.                                      
           MOVE EXCEPTN  TO EXCEPTION-IND.                                      
           ADD 1 TO WS-LOG-SEQ-NO.                                              
           MOVE WS-LOG-SEQ-NO TO DETAIL-SEQNO.                                  
      ***--------------------------------------------------------------         
      *** INERT THE REQUEST RECORD TO THE REQUEST DETAIL.                       
      ***--------------------------------------------------------------         
           EXEC SQL                                                             
                INSERT INTO APPLICATION_COPY_DETAIL                             
                (REQUEST_ID, DETAIL_SEQNO, APPLICATION,                         
                 CONTRACT, ACCOUNT, START_CERT,                                 
                 END_CERT, FROM_REGION, TO_REGION,                              
                 CAN_ONLY_IND,                                                  
                 PROTECTED_IND, EXCEPTION_IND)                                  
                VALUES                                                          
                (:WS-LOG-REQUEST-ID                                             
                ,:DETAIL-SEQNO                                                  
                ,:APPLICATION                                                   
                ,:CONTRACT                                                      
                ,:ACCOUNT                                                       
                ,:START-CERT                                                    
                ,:END-CERT                                                      
                ,:FROM-REGION                                                   
                ,:TO-REGION                                                     
                ,:CAN-ONLY-IND                                                  
                ,:PROTECTED-IND                                                 
                ,:EXCEPTION-IND)                                                
           END-EXEC.                                                            
                                                                                
           IF SQLCODE NOT EQUAL 0                                               
              MOVE SQLCODE TO WS-SQL-CODE                                       
              DISPLAY 'FAILED WRITING TO AUDIT LOG'                             
              DISPLAY ' REQUEST ID=' WS-LOG-REQUEST-ID                          
              DISPLAY ' SEQUENCE=' WS-LOG-SEQ-NO                                
              DISPLAY ' CONTRACT=' CONTRACT                                     
              DISPLAY ' FROM REGION=' FROM-REGION                               
              DISPLAY ' TO REGION=' TO-REGION                                   
              DISPLAY ' SQL RETURN CODE=' WS-SQL-CODE                           
           END-IF.                                                              
                                                                        00059000
      ***---------------------------------------------------------------        
      ***  READ THE NEXT EXTRACT INPUT RECORD                                   
      ***---------------------------------------------------------------        
                                                                                
           READ EXTRACT-REQ AT END SET EXT-EOF TO TRUE.                         
       C-100-EXIT.                                                              
      *-----------                                                              
           EXIT.                                                                
                                                                                
      ******************************************************************00056600
       2100-INSERT-ITEM-REC.                                                    
      ******************************************************************00056600
                                                                                
      ********************    END-OF-PROGRAM    ************************00056600
                                                                                
