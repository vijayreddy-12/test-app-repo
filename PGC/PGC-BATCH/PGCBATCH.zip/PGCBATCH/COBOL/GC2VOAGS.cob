       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VOAGS.                                                 
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  JUNE 2005.                                                
      *DATE-COMPILED.                                                           
      *****************************************************************         
      *                                                                         
      *   COMMISSIONS SYSTEM                                                    
      *   HUB VO COMMISSIONS PROJECT                                            
      *                                                                         
      *   HUB:  AGENT FILE AND PAY BASIS DATA EXTRACT/MERGE                     
      *         (VOCOMM AGT PAYBASIS)                                           
      *                                                                         
      *   THIS PROGRAM READS THE MERGED AGENT PAY BASIS FILE AND                
      *   THE SENT VO AGENTS FILE AND PRODUCES THE VO AGENT FILE.               
      *                                                                         
      *   CALLING PROGRAM:  NONE                                                
      *                                                                         
      *   CALLED PROGRAMS:  GAEDATSR                                            
      *                                                                         
      *   COPYBOOKS:                                                            
      *       AGTMRGE                                                           
      *       SVOAGTSN                                                          
      *       VOAGENT                                                           
      *       GARDSVRB                                                          
      *       HCSLRNAM                                                          
      *       ICBM                                                              
      *                                                                         
      *   INPUT  - MERGED AGENT PAY BASIS FILE (SORTED)                         
      *            SENT VO AGENTS FILE (SORTED)                                 
      *                                                                         
      *   OUTPUT - VO AGENT FILE                                                
      *                                                                         
      *   DESCRIPTION:                                                          
      *     GET THE JOB PARM.                                                   
      *     IF THE JOB PARM IS NOT 'ALL' AND IT IS NOT 'NEW',                   
      *        ABEND THE PROGRAM.                                               
      *     IF THE JOB PARM IS 'ALL', SET THE AGTSN-DATA TO                     
      *        HIGH-VALUES SO THAT PROCESSING WILL COPY ALL                     
      *        SAGTMRGE RECORDS INTO THE VOAGENT FILE.                          
      *     IF IT IS 'NEW', PROCESS ALL THE SAGTMRGE RECORDS:                   
      *        READ AND MATCH THE SAGTMRGE RECORDS WITH THE                     
      *        SVOAGTSN RECORDS USING SAGTMRGE AS THE DRIVER FILE.              
      *        MATCH ON THE WHOLE RECORD.                                       
      *        IF THE SAGTMRGE RECORD HAS A MATCHING SVOAGTSN RECORD,           
      *        IGNORE THESE SAGTMRGE AND SVOAGTSN RECORDS AND READ              
      *        THE NEXT RECORD FOR EACH FILE.                                   
      *        IF THE SAGTMRGE RECORD HAS NO MATCHING SVOAGTSN RECORD,          
      *        CREATE A VOAGENT RECORD USING THE SAGTMRGE RECORD;               
      *        THEN READ THE NEXT SAGTMRGE RECORD.                              
      *        IF THE SVOATGSN RECORD HAS NO MATCHING SAGTMRGE RECORD,          
      *        IGNORE THIS SVOAGTSN RECORD AND READ THE NEXT                    
      *        SVOAGTSN RECORD.                                                 
      *                                                                         
      ******************************************************************        
      *    MMM/CCYY   -    NAME            -   DESCRIPTION                      
      *    JUN 2005        REGINA KNAUD        INITIAL CREATION.                
      *                                                                         
      *    OCT 2008        IBM               ENTERPRISE COMPILER UPGRADE        
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVOAGTS          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       SOURCE-COMPUTER. IBM-370-165.                                            
       OBJECT-COMPUTER. IBM-370-165.                                            
                                                                                
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-VARIABLES.                                                        
           05  FILLER                      PIC X(32) VALUE                      
FXXTOK         '*** GC2VOAGS WORKING STORAGE ***'.                              
           05  WS-SAGTMRGE-EOF             PIC X.                               
           05  WS-SVOAGTSN-EOF             PIC X.                               
           05  WS-VOAGENT-REC-COUNT        PIC 9(9).                            
                                                                                
      *01  AGENT-MERGE-RECORD.                                                  
           COPY AGTMRGE.                                                        
                                                                                
      *01  AGENT-SENT-RECORD.                                                   
           COPY SVOAGTSN.                                                       
                                                                                
      *01  VO-AGENT-RECORD.                                                     
           COPY VOAGENT.                                                        
                                                                                
      *    VOAGTNXT(0) FILE                                                     
       01  VOAGENT-INBATCH.                                                     
           05  VOAGENT-INBATCH-NUMBER      PIC 9(7).                            
           05  FILLER                      PIC X(73).                           
                                                                                
      *    VOAGTNXT(+1) FILE                                                    
       01  VOAGENT-OUTBATCH.                                                    
           05  VOAGENT-OUTBATCH-NUMBER     PIC 9(7).                            
           05  FILLER                      PIC X(73) VALUE SPACES.              
                                                                                
      *----------------------------------------------------------------*        
      *    DATA SERVER ACTION VERBS                                             
      *----------------------------------------------------------------*        
       01  GAEDATSR-PARMS.                                                      
                                      COPY GARDSVRB.                            
                                                                                
       01  WS-GAEDATSR.                                                         
           05  GAEDATSR               PIC X(8) VALUE 'GAEDATSR'.                
           05  WS-GAEDATSR-VERB       PIC X(16).                                
                                                                                
      *----------------------------------------------------------------*        
      *    INTERFACE CONTROL BLOCK                                              
      *----------------------------------------------------------------*        
       01  ICBM.                                                                
                                      COPY ICBM.                                
                                                                                
      *----------------------------------------------------------------*        
      *    LOGICAL RECORD NAMES                                                 
      *----------------------------------------------------------------*        
       01  LOGICAL-RECORD-NAMES.                                                
                                      COPY HCSLRNAM.                            
              10  LR-SAGTMRGE-IN      PIC X(16) VALUE 'CARD-DATA-010'.          
              10  LR-SVOAGTSN-IN      PIC X(16) VALUE 'CARD-DATA-011'.          
              10  LR-BATCH-IN         PIC X(16) VALUE 'CARD-DATA-012'.          
              10  LR-VOAGENT-OUT      PIC X(16) VALUE 'PRINT-DATA-020'.         
              10  LR-BATCH-OUT        PIC X(16) VALUE 'PRINT-DATA-021'.         
                                                                                
      *------------------------------------------------------------             
      *    ABEND VARIABLES                                                      
      *-------------------------------------------------------------            
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X            PIC X(04).                             
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH       PIC S9(3) VALUE +133 COMP-3.           
               10  WTL-MESS-CC           PIC X(1)  VALUE SPACES.                
               10  WTL-MESS-TEXT         PIC X(132) VALUE SPACES.               
           05  WTL-FLAG                  PIC X(1)  VALUE 'B'.                   
           05  WTL-REPLY                 PIC X(3)  VALUE 'NO '.                 
           05  WTL-REPLY-AREA            PIC X(80) VALUE SPACES.                
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                     PIC X(80)                              
FXXTOK         VALUE 'GC2VOAGS - ** PROBLEM READING INBATCH REC**'.             
           05  WTL-2                     PIC X(80)                              
FXXTOK         VALUE 'GC2VOAGS - ** RUN PARM IS INVALID**'.                     
           05  WTL-3                     PIC X(80)                              
FXXTOK         VALUE 'GC2VOAGS - ** PROBLEM WRITING VOAGENT REC**'.             
           05  WTL-4                     PIC X(80)                              
FXXTOK         VALUE 'GC2VOAGS - ** PROBLEM WRITING OUTBATCH REC**'.            
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY         OCCURS 4 TIMES.                        
               10  WTL-MESSAGE           PIC X(80).                             
       01  WTL-SUB                       PIC S9(4) COMP.                        
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE '        '   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
       LINKAGE SECTION.                                                         
       01  GWVOAGTS-PARM.                                                       
           05  GWVOAGTS-PARM-LENGTH     PIC S9(04) COMP.                        
           05  GWVOAGTS-PARM-SELECTION  PIC X(3).                               
                                                                                
       PROCEDURE DIVISION USING GWVOAGTS-PARM.                                  
       0000-MAINLINE.                                                           
                                                                                
           PERFORM 1000-INIT THRU 1000-EXIT.                                    
                                                                                
           PERFORM 2000-PROCESS-SAGTMRGE THRU 2000-EXIT                         
                   UNTIL WS-SAGTMRGE-EOF = 'Y'.                                 
                                                                                
           PERFORM 9900-FINISH THRU 9900-EXIT.                                  
                                                                                
           STOP RUN.                                                            
                                                                                
       0000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       1000-INIT.                                                               
FXXTOK     MOVE 'GC2VOAGS'   TO ICBM-PROGRAM-NAME.                              
           MOVE LOW-VALUES   TO LINKAGE-CONTROL.                                
                                                                                
           INITIALIZE  WS-USER-ABEND-CODE.                                      
           MOVE 'N'    TO WS-SAGTMRGE-EOF.                                      
           MOVE 'N'    TO WS-SVOAGTSN-EOF.                                      
           MOVE 0      TO WS-VOAGENT-REC-COUNT.                                 
                                                                                
           DISPLAY 'JOB PARM = ' GWVOAGTS-PARM-SELECTION.                       
                                                                                
           MOVE LR-BATCH-IN         TO  LOGICAL-RECORD-NAME.                    
           CALL GAEDATSR         USING  OBTAIN-FIRST                            
                                        VOAGENT-INBATCH                         
                                        ICBM.                                   
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-SAGTMRGE-EOF                                       
              MOVE 'Y' TO WS-SVOAGTSN-EOF                                       
              MOVE +1  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND THRU                                       
                      9999-WTL-ABEND-EXIT                                       
           END-IF.                                                              
                                                                                
           MOVE OBTAIN-FIRST TO WS-GAEDATSR-VERB.                               
                                                                                
           PERFORM 2110-READ-SAGTMRGE THRU 2110-EXIT                            
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-SAGTMRGE-EOF                                       
           END-IF.                                                              
                                                                                
           PERFORM 2210-READ-SVOAGTSN THRU 2210-EXIT                            
           IF NOT LR-STATUS-OK                                                  
              MOVE HIGH-VALUES TO AGTSN-DATA                                    
              MOVE 'Y' TO WS-SVOAGTSN-EOF                                       
           END-IF.                                                              
                                                                                
           IF GWVOAGTS-PARM-SELECTION = 'NEW'                                   
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF GWVOAGTS-PARM-SELECTION = 'ALL'                                
                 MOVE HIGH-VALUES TO AGTSN-DATA                                 
                 MOVE 'Y' TO WS-SVOAGTSN-EOF                                    
              ELSE                                                              
                 DISPLAY 'JOB RUN PARM VALUE IS INVALID : '                     
                          GWVOAGTS-PARM-SELECTION                               
                 MOVE 'Y' TO WS-SAGTMRGE-EOF                                    
                 MOVE +2  TO WTL-SUB                                            
                 PERFORM 9999-WTL-ABEND THRU                                    
                         9999-WTL-ABEND-EXIT                                    
           END-IF.                                                              
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2000-PROCESS-SAGTMRGE.                                                   
           IF AGTMRG-DATA        = AGTSN-DATA                                   
                                                                                
              PERFORM 2100-GET-SAGTMRGE THRU 2100-EXIT                          
                                                                                
              PERFORM 2200-GET-SVOAGTSN THRU 2200-EXIT                          
                                                                                
           ELSE                                                                 
              IF AGTMRG-DATA        < AGTSN-DATA                                
                                                                                
                 MOVE SPACES TO VO-AGENT-RECORD                                 
                 ADD 1 TO WS-VOAGENT-REC-COUNT                                  
                 MOVE 'VOAGENT'          TO VOAGT-FILE-TYPE                     
                 MOVE '1'                TO VOAGT-RECORD-TYPE                   
                 MOVE AGTMRG-DATA        TO VOAGT-DTL                           
                                                                                
                 PERFORM 2300-PUT-VOAGENT THRU 2300-EXIT                        
                                                                                
                 PERFORM 2100-GET-SAGTMRGE THRU 2100-EXIT                       
                                                                                
              ELSE                                                              
                 PERFORM 2200-GET-SVOAGTSN THRU 2200-EXIT                       
                                                                                
              END-IF                                                            
           END-IF.                                                              
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2100-GET-SAGTMRGE.                                                       
           MOVE OBTAIN-NEXT      TO WS-GAEDATSR-VERB.                           
                                                                                
           PERFORM 2110-READ-SAGTMRGE THRU 2110-EXIT.                           
                                                                                
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-SAGTMRGE-EOF                                       
           END-IF.                                                              
                                                                                
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2110-READ-SAGTMRGE.                                                      
           MOVE LR-SAGTMRGE-IN   TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING WS-GAEDATSR-VERB                            
                                    AGENT-MERGE-RECORD                          
                                    ICBM.                                       
                                                                                
       2110-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2200-GET-SVOAGTSN.                                                       
           MOVE OBTAIN-NEXT      TO WS-GAEDATSR-VERB.                           
                                                                                
           PERFORM 2210-READ-SVOAGTSN THRU 2210-EXIT.                           
                                                                                
           IF NOT LR-STATUS-OK                                                  
              MOVE HIGH-VALUES TO AGTSN-DATA                                    
              MOVE 'Y'         TO WS-SVOAGTSN-EOF                               
           END-IF.                                                              
                                                                                
       2200-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2210-READ-SVOAGTSN.                                                      
           MOVE LR-SVOAGTSN-IN   TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING WS-GAEDATSR-VERB                            
                                    AGENT-SENT-RECORD                           
                                    ICBM.                                       
                                                                                
       2210-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2300-PUT-VOAGENT.                                                        
           PERFORM 2310-WRITE-VOAGENT THRU 2310-EXIT.                           
                                                                                
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-SAGTMRGE-EOF                                       
              MOVE 'Y' TO WS-SVOAGTSN-EOF                                       
              MOVE +3  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND THRU                                       
                      9999-WTL-ABEND-EXIT                                       
           END-IF.                                                              
                                                                                
       2300-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2310-WRITE-VOAGENT.                                                      
           MOVE LR-VOAGENT-OUT   TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING STORE-LR                                    
                                    VO-AGENT-RECORD                             
                                    ICBM.                                       
                                                                                
       2310-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *--------------------------------------------------------                 
      * WRITE THE BATCH NUMBER AND THE NUMBER OF RECORDS                        
      * IN THE VOAGENT FILE (NOTE: NUMBER OF RECORDS INCLUDES                   
      * THIS "BATCH NUMBER" RECORD);                                            
      * INCREMENT THE INBATCH TO PRODUCE THE OUTBATCH NUMBER;                   
      * CLOSE FILES THAT ARE OPEN...                                            
      *--------------------------------------------------------                 
       9900-FINISH.                                                             
           MOVE SPACES TO VO-AGENT-RECORD.                                      
           ADD 1 TO WS-VOAGENT-REC-COUNT.                                       
           MOVE 'VOAGENT'              TO VOAGT-FILE-TYPE.                      
           MOVE '0'                    TO VOAGT-RECORD-TYPE.                    
           MOVE VOAGENT-INBATCH-NUMBER TO VOAGT-FILE-NUMBER.                    
           MOVE WS-VOAGENT-REC-COUNT   TO VOAGT-REC-COUNT.                      
                                                                                
           PERFORM 2300-PUT-VOAGENT THRU 2300-EXIT.                             
                                                                                
           MOVE SPACES TO VOAGENT-OUTBATCH.                                     
           COMPUTE VOAGENT-OUTBATCH-NUMBER = VOAGENT-INBATCH-NUMBER             
                                           + 1.                                 
           MOVE LR-BATCH-OUT     TO LOGICAL-RECORD-NAME.                        
           CALL GAEDATSR      USING STORE-LR                                    
                                    VOAGENT-OUTBATCH                            
                                    ICBM.                                       
           IF NOT LR-STATUS-OK                                                  
              MOVE 'Y' TO WS-SAGTMRGE-EOF                                       
              MOVE 'Y' TO WS-SVOAGTSN-EOF                                       
              MOVE +4  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND THRU                                       
                      9999-WTL-ABEND-EXIT                                       
           END-IF.                                                              
                                                                                
           MOVE SPACES      TO LOGICAL-RECORD-NAME.                             
           CALL GAEDATSR USING FINISH-LR                                        
                               LOGICAL-RECORD-NAME                              
                               ICBM.                                            
                                                                                
       9900-EXIT.                                                               
           EXIT.                                                                
                                                                                
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL'    USING  WTL-MESSAGES                                    
                                WTL-FLAG                                        
                                WTL-REPLY                                       
                                WTL-REPLY-AREA.                                 
                                                                                
           CALL 'ILBOABN0'  USING  WS-COMP-CODE.                                
                                                                                
       9999-WTL-ABEND-EXIT.                                                     
           EXIT.                                                                
