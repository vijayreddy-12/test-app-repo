       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2PRGBK.                                                    
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *REMARKS.                                                                 
      *    THIS PROGRAM CREATES A FILE OF DATA BASE EXTRACT RECORDS             
      *    FOR SELECTED GROUP/ACCOUNTS.                                         
      *                                                                         
      *----------------------------------------------------------------         
      *  HISTORY:                                                               
      *                                                                         
      *  FEB/95   J BORSI       CREATED FROM GWCOCUNL                           
      *  FEB/03   BEAUBIB       CONVERT TO COBOL 2                              
      *                         BRING UP TO CURRENT STANDARD.IE GAEDATSR        
      *                                                                         
      *  OCT/08   IBM           ENTERPRISE COMPILER UPGRADE                     
      *----------------------------------------------------------------         
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES COPRGBKP          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS.                                                           
           05  FILLER                PIC X(32)        VALUE                     
FXXTOK         '** GC2PRGBK W-S STARTS HERE **'.                                
                                                                                
       01  DYNAMIC-PROGRAMS.                                                    
           05  GAEDATSR                PIC X(8)  VALUE 'GAEDATSR'.              
                                                                                
       01  DYNAMIC-STORAGE.                                                     
           05  SAVE-RETURN           PIC S9(8) COMP VALUE ZERO.                 
           05  WS-SUB                PIC S9(8) COMP VALUE ZERO.                 
           05  WS-VERB               PIC X(16)      VALUE SPACES.               
                                                                                
      *---------------------------------------------------------------*         
      * INPUT RECORD - FROM COPRGSEL                                  *         
      *---------------------------------------------------------------*         
       01  INPUT-RECORD.                                                        
           05  INPUT-PROGRAM-NAME      PIC X(8).                                
           05  FILLER                  PIC X(1).                                
           05  INPUT-GROUP-7.                                                   
               10 FILLER               PIC X(2).                                
               10 INPUT-GROUP-5        PIC 9(5).                                
           05  FILLER                  PIC X(64).                               
                                                                                
      *---------------------------------------------------------------*         
      * BACKUP DATABASE RECORDS                                       *         
      *---------------------------------------------------------------*         
       01  BACKUP-RECORD.                                                       
           05  BACKUP-LLB              PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(2) VALUE LOW-VALUES.               
           05  BACKUP-GROUP            PIC 9(7).                                
           05  BACKUP-RECORD-NAME      PIC X(16).                               
           05  BACKUP-AGENT            PIC X(6).                                
           05  BACKUP-DATA             PIC X(1600).                             
                                                                                
      *---------------------------------------------------------------*         
      * OUTPUT  - WITH RECORD COUNTS                                  *         
      *---------------------------------------------------------------*         
       01  OUTPUT-RECORD.                                                       
           03  OUTPUT-GROUP-NUMBER     PIC 9(7).                                
           03  OUTPUT-RECORDS          OCCURS 9 TIMES                           
                                       PIC S9(4) COMP.                          
                                                                                
       01  DBASE-RECORDS-INFO.                                                  
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORGROUP      '.          
           05  FILLER                  PIC S9(4) COMP VALUE +8.                 
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORADVPSM     '.          
           05  FILLER                  PIC S9(4) COMP VALUE +16.                
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORGRACCT     '.          
           05  FILLER                  PIC S9(4) COMP VALUE +32.                
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORRENEWAL    '.          
           05  FILLER                  PIC S9(4) COMP VALUE +8.                 
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORCASECNT    '.          
           05  FILLER                  PIC S9(4) COMP VALUE +16.                
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORCOMP       '.          
           05  FILLER                  PIC S9(4) COMP VALUE +80.                
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORACCUM      '.          
           05  FILLER                  PIC S9(4) COMP VALUE +24.                
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORAGENT      '.          
           05  FILLER                  PIC S9(4) COMP VALUE +8.                 
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
           05  FILLER                  PIC X(16)   VALUE                        
                                                   'GWCORPAYBASIS   '.          
           05  FILLER                  PIC S9(4) COMP VALUE +16.                
           05  FILLER                  PIC S9(4) COMP VALUE ZERO.               
                                                                                
       01  DBASE-RECORDS-TABLE         REDEFINES DBASE-RECORDS-INFO.            
           05  DBASE-RECORD-ENTRY      OCCURS 9 TIMES.                          
               09  DBASE-RECORD-NAME   PIC X(16).                               
               09  DBASE-RECORD-LENGTH PIC S9(4) COMP.                          
               09  DBASE-RECORDS       PIC S9(4) COMP.                          
                                                                                
       01  AGENT-TABLE.                                                         
           05  AGENT                 PIC X(6) OCCURS 10 TIMES.                  
                                                                                
       01  WS-FIELDS.                                                           
           05  AGENT-TABLE-ENTRY     PIC X(6).                                  
           05  SUB                   PIC S9(4) COMP-3 VALUE +0.                 
                                                                                
      *---------------------------------------------------------------*         
      *          DATASERVER RECORDS                                   *         
      *---------------------------------------------------------------*         
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
      *---------------------------------------------------------------*         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *---------------------------------------------------------------*         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      *---------------------------------------------------------------*         
      * COMMISSIONS DATABASE RECORDS                                  *         
      *---------------------------------------------------------------*         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGROUP                      '.                                  
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORADVPSM                     '.                                  
      * GWCORADVPSM                                                             
CPYNME     COPY GCIADVPS.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGRACCT                     '.                                  
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORRENEWAL                    '.                                  
      * GWCORRENEWAL                                                            
CPYNME     COPY GCIRNEWL.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCASECNT                    '.                                  
      * GWCORCASECNT                                                            
CPYNME     COPY GCICASEC.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORCOMP                       '.                                  
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORACCUM                      '.                                  
      * GWCORACCUM                                                              
CPYNME     COPY GCIACCUM.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORAGENT                      '.                                  
      * GWCORAGENT                                                              
CPYNME     COPY GCIAGENT.                                                       
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORPAYBASIS                   '.                                  
      * GWCORPAYBASIS                                                           
CPYNME     COPY GCIPAYB.                                                        
                                                                                
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           'WORKING STORAGE ENDS HERE'.                                         
                                                                                
      *---------------------------------------------------------------*         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2PRGBK'         TO FCCSPL-CURR-PGM.                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
      *%   COPY IDMS SUBSCHEMA-BINDS.                                           
FXXTOK     MOVE 'GC2PRGBK' TO PROGRAM-NAME.                                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA3 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           PERFORM 950-LOAD-COUNTS                                              
              THRU 950-LOAD-COUNTS-EXIT                                         
                   VARYING WS-SUB FROM 1 BY 1                                   
                   UNTIL WS-SUB > 9.                                            
                                                                                
           MOVE LOW-VALUES                TO LINKAGE-CONTROL.                   
FXXTOK     MOVE 'GC2PRGBK'                TO ICBM-PROGRAM-NAME.                 
           MOVE OBTAIN-FIRST TO WS-VERB.                                        
                                                                                
           PERFORM 100-READ-INPUT                                               
              THRU 100-EXIT.                                                    
                                                                                
           MOVE +1 TO WS-SUB.                                                   
                                                                                
           MOVE OBTAIN-NEXT TO WS-VERB.                                         
           PERFORM 100-PROCESS-INPUT THRU 100-EXIT                              
               UNTIL NOT LR-STATUS-OK                                           
                  OR SAVE-RETURN NOT = ZERO.                                    
                                                                                
           CALL GAEDATSR    USING FINISH-LR                                     
                                  OUTPUT-RECORD                                 
                                  ICBM.                                         
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           MOVE SAVE-RETURN TO RETURN-CODE.                                     
           STOP RUN.                                                            
                                                                                
      *---------------------------------------------------------------*         
       100-PROCESS-INPUT.                                                       
                                                                                
           MOVE SPACES TO AGENT-TABLE.                                          
                                                                                
REN        MOVE INPUT-GROUP-7 TO GROUP-NUMBER OF GWCORGROUP.                    
                                                                                
      *%   OBTAIN CALC GWCORGROUP                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                   GO TO 100-READ-INPUT.                                        
                                                                                
           MOVE +1 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE SPACES TO BACKUP-AGENT.                                         
           MOVE GWCORGROUP TO BACKUP-DATA.                                      
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN FIRST GWCORADVPSM WITHIN GROUP-ADVPSM                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORADVPSM                                      
MAN02                 FCCSPL-GWCORADVPSM                                        
MAN02                 FCCSPL-GROUP-ADVPSM                                       
MAN02                 GWCORADVPSM                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
           PERFORM 200-GET-ADVPSM-RECORDS                                       
              THRU 200-GET-ADVPSM-RECORDS-EXIT                                  
              UNTIL DB-END-OF-SET.                                              
                                                                                
      *%   OBTAIN FIRST GWCORGRACCT WITHIN GROUP-GRACCT                         
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GROUP-GRACCT                                       
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
           PERFORM 300-GET-GRACCT-RECORDS                                       
              THRU 300-GET-GRACCT-RECORDS-EXIT                                  
              UNTIL DB-END-OF-SET.                                              
                                                                                
      *    PERFORM 600-EXTRACT-AGENT-RECORDS                                    
      *       THRU 600-EXTRACT-AGENT-RECORDS-EXIT.                              
           PERFORM                                                              
              VARYING SUB FROM 1 BY 1                                           
                UNTIL SUB > 10                                                  
                   OR AGENT(SUB) = SPACES                                       
                                                                                
                   IF AGENT(SUB) NOT = SPACES                                   
                      MOVE AGENT(SUB) TO AGENT-NUMBER OF GWCORAGENT             
                      PERFORM 650-GET-GWCORAGENT                                
                         THRU 650-GET-GWCORAGENT-EXIT                           
                   END-IF                                                       
           END-PERFORM.                                                         
                                                                                
           PERFORM 800-BUILD-OUTPUT                                             
              THRU 800-BUILD-OUTPUT-EXIT.                                       
                                                                                
           PERFORM 910-WRITE-OUTPUT                                             
              THRU 910-WRITE-OUTPUT-EXIT.                                       
                                                                                
       100-READ-INPUT.                                                          
                                                                                
           INITIALIZE INPUT-RECORD.                                             
           MOVE 'CARD-DATA-010'      TO LOGICAL-RECORD-NAME.                    
                                                                                
           CALL GAEDATSR          USING  WS-VERB                                
                                         INPUT-RECORD                           
                                         ICBM.                                  
                                                                                
      *--------------------------------------------------------------           
      *   LR-NOT-FOUND ON AN OBTAIN NEXT MEANS WE GOT TO END OF FILE            
      *   ...THIS IS NOT AN ERROR....                                           
      *--------------------------------------------------------------           
            IF WS-VERB = OBTAIN-NEXT                                            
            AND LR-NOT-FOUND                                                    
                NEXT SENTENCE                                                   
            ELSE                                                                
                IF NOT LR-STATUS-OK                                             
                   DISPLAY '*** ERROR READING INPUT: ' ICBM                     
                ELSE                                                            
                   DISPLAY 'NOW PROCESSING: ' INPUT-RECORD                      
            END-IF.                                                             
                                                                                
       100-EXIT.                                                                
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       200-GET-ADVPSM-RECORDS.                                                  
                                                                                
           MOVE +2 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE SPACES TO BACKUP-AGENT.                                         
           MOVE GWCORADVPSM TO BACKUP-DATA.                                     
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN NEXT GWCORADVPSM WITHIN GROUP-ADVPSM                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORADVPSM                                      
MAN02                 FCCSPL-GWCORADVPSM                                        
MAN02                 FCCSPL-GROUP-ADVPSM                                       
MAN02                 GWCORADVPSM                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                                 NEXT SENTENCE.                                 
                                                                                
       200-GET-ADVPSM-RECORDS-EXIT.                                             
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       300-GET-GRACCT-RECORDS.                                                  
                                                                                
           MOVE +3 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE SPACES TO BACKUP-AGENT.                                         
           MOVE GWCORGRACCT TO BACKUP-DATA.                                     
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN FIRST GWCORRENEWAL WITHIN GRACCT-RENEWAL                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 FCCSPL-GRACCT-RENEWAL                                     
MAN02                 GWCORRENEWAL                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
           PERFORM 310-GET-RENEWAL-RECORDS                                      
              THRU 310-GET-RENEWAL-RECORDS-EXIT                                 
              UNTIL DB-END-OF-SET.                                              
                                                                                
      *%   OBTAIN FIRST GWCORCASECNT WITHIN GRACCT-CASECNT                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCASECNT                                     
MAN02                 FCCSPL-GWCORCASECNT                                       
MAN02                 FCCSPL-GRACCT-CASECNT                                     
MAN02                 GWCORCASECNT                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
           PERFORM 320-GET-CASECNT-RECORDS                                      
              THRU 320-GET-CASECNT-RECORDS-EXIT                                 
             UNTIL DB-END-OF-SET.                                               
                                                                                
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 3 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
           PERFORM 330-GET-COMP-RECORDS                                         
              THRU 330-GET-COMP-RECORDS-EXIT                                    
             UNTIL DB-END-OF-SET.                                               
                                                                                
      *%   OBTAIN FIRST GWCORACCUM WITHIN GRACCT-ACCUM                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 4 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
           PERFORM 340-GET-ACCUM-RECORDS                                        
              THRU 340-GET-ACCUM-RECORDS-EXIT                                   
             UNTIL DB-END-OF-SET.                                               
                                                                                
      *%   OBTAIN NEXT GWCORGRACCT WITHIN GROUP-GRACCT                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 FCCSPL-GROUP-GRACCT                                       
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
       300-GET-GRACCT-RECORDS-EXIT.                                             
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       310-GET-RENEWAL-RECORDS.                                                 
                                                                                
           MOVE +4 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE SPACES TO BACKUP-AGENT.                                         
           MOVE GWCORRENEWAL TO BACKUP-DATA.                                    
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN NEXT GWCORRENEWAL WITHIN GRACCT-RENEWAL                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 6 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORRENEWAL                                     
MAN02                 FCCSPL-GWCORRENEWAL                                       
MAN02                 FCCSPL-GRACCT-RENEWAL                                     
MAN02                 GWCORRENEWAL                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                                 NEXT SENTENCE.                                 
                                                                                
       310-GET-RENEWAL-RECORDS-EXIT.                                            
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       320-GET-CASECNT-RECORDS.                                                 
                                                                                
      *%   OBTAIN OWNER WITHIN AGENT-CASECNT.                                   
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-PARENT                                      
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-AGENT-CASECNT                                      
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           MOVE +5 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE AGENT-NUMBER OF GWCORAGENT TO BACKUP-AGENT.                     
           MOVE AGENT-NUMBER OF GWCORAGENT TO AGENT-TABLE-ENTRY.                
                                                                                
      *    PERFORM 500-UPDATE-AGENT-TABLE                                       
      *       THRU 500-UPDATE-AGENT-TABLE-EXIT.                                 
           PERFORM                                                              
              VARYING SUB FROM 1 BY 1                                           
                UNTIL SUB > 10                                                  
                   OR AGENT-TABLE-ENTRY = AGENT(SUB)                            
                                                                                
                   IF AGENT(SUB) = SPACES                                       
                      MOVE AGENT-TABLE-ENTRY TO AGENT(SUB)                      
                   END-IF                                                       
           END-PERFORM.                                                         
                                                                                
           MOVE GWCORCASECNT TO BACKUP-DATA.                                    
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN NEXT GWCORCASECNT WITHIN GRACCT-CASECNT                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCASECNT                                     
MAN02                 FCCSPL-GWCORCASECNT                                       
MAN02                 FCCSPL-GRACCT-CASECNT                                     
MAN02                 GWCORCASECNT                                              
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
       320-GET-CASECNT-RECORDS-EXIT.                                            
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       330-GET-COMP-RECORDS.                                                    
                                                                                
           MOVE +6 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE GWCORCOMP TO BACKUP-DATA.                                       
           MOVE AGENT-NUMBER OF GWCORCOMP TO BACKUP-AGENT.                      
           MOVE AGENT-NUMBER OF GWCORCOMP TO AGENT-TABLE-ENTRY.                 
                                                                                
      *    PERFORM 500-UPDATE-AGENT-TABLE                                       
      *       THRU 500-UPDATE-AGENT-TABLE-EXIT.                                 
           PERFORM                                                              
              VARYING SUB FROM 1 BY 1                                           
                UNTIL SUB > 10                                                  
                   OR AGENT-TABLE-ENTRY = AGENT(SUB)                            
                                                                                
                   IF AGENT(SUB) = SPACES                                       
                      MOVE AGENT-TABLE-ENTRY TO AGENT(SUB)                      
                   END-IF                                                       
           END-PERFORM.                                                         
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN NEXT GWCORCOMP WITHIN GRACCT-COMP                             
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
       330-GET-COMP-RECORDS-EXIT.                                               
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       340-GET-ACCUM-RECORDS.                                                   
                                                                                
           MOVE +7 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE GWCORACCUM TO BACKUP-DATA.                                      
           MOVE SPACES TO BACKUP-AGENT.                                         
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN NEXT GWCORACCUM WITHIN GRACCT-ACCUM                           
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORACCUM                                       
MAN02                 FCCSPL-GWCORACCUM                                         
MAN02                 FCCSPL-GRACCT-ACCUM                                       
MAN02                 GWCORACCUM                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                                 NEXT SENTENCE.                                 
                                                                                
       340-GET-ACCUM-RECORDS-EXIT.                                              
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       500-UPDATE-AGENT-TABLE.                                                  
                                                                                
           MOVE +0 TO SUB.                                                      
                                                                                
       500-UPDATE-LOOP.                                                         
                                                                                
           ADD +1 TO SUB.                                                       
           IF SUB > +10                                                         
              GO TO 500-UPDATE-AGENT-TABLE-EXIT.                                
           IF AGENT-TABLE-ENTRY = AGENT(SUB)                                    
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF AGENT(SUB) = SPACES                                            
                 MOVE AGENT-TABLE-ENTRY TO AGENT(SUB)                           
              ELSE                                                              
                 GO TO 500-UPDATE-LOOP.                                         
                                                                                
       500-UPDATE-AGENT-TABLE-EXIT.                                             
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       600-EXTRACT-AGENT-RECORDS.                                               
                                                                                
           MOVE +0 TO SUB.                                                      
                                                                                
       600-READ-LOOP.                                                           
                                                                                
           ADD +1 TO SUB.                                                       
           IF SUB > +10                                                         
              GO TO 600-EXTRACT-AGENT-RECORDS-EXIT.                             
                                                                                
           IF AGENT(SUB) NOT = SPACES                                           
              MOVE AGENT(SUB) TO AGENT-NUMBER OF GWCORAGENT                     
              PERFORM 650-GET-GWCORAGENT                                        
                 THRU 650-GET-GWCORAGENT-EXIT                                   
              GO TO 600-READ-LOOP.                                              
                                                                                
       600-EXTRACT-AGENT-RECORDS-EXIT.                                          
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       650-GET-GWCORAGENT.                                                      
                                                                                
      *%   OBTAIN CALC GWCORAGENT                                               
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 11 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORAGENT                                       
MAN02                 FCCSPL-GWCORAGENT                                         
MAN02                 GWCORAGENT                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                   GO TO 650-GET-GWCORAGENT-EXIT.                               
                                                                                
           MOVE +8 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE GWCORAGENT TO BACKUP-DATA.                                      
           MOVE AGENT-NUMBER OF GWCORAGENT TO BACKUP-AGENT.                     
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN FIRST GWCORPAYBASIS WITHIN AGENT-PAYBASIS                     
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 12 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
           PERFORM 660-GET-PAYBASIS-RECORDS                                     
              THRU 660-GET-PAYBASIS-RECORDS-EXIT                                
             UNTIL DB-END-OF-SET.                                               
                                                                                
       650-GET-GWCORAGENT-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       660-GET-PAYBASIS-RECORDS.                                                
                                                                                
           MOVE +9 TO WS-SUB.                                                   
           MOVE INPUT-GROUP-7 TO BACKUP-GROUP.                                  
           MOVE AGENT-NUMBER OF GWCORAGENT TO BACKUP-AGENT.                     
           MOVE GWCORPAYBASIS TO BACKUP-DATA.                                   
                                                                                
           PERFORM 900-WRITE-BACKUP                                             
              THRU 900-WRITE-BACKUP-EXIT.                                       
                                                                                
      *%   OBTAIN NEXT GWCORPAYBASIS WITHIN AGENT-PAYBASIS                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 13 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORPAYBASIS                                    
MAN02                 FCCSPL-GWCORPAYBASIS                                      
MAN02                 FCCSPL-AGENT-PAYBASIS                                     
MAN02                 GWCORPAYBASIS                                             
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                  NEXT SENTENCE.                                                
                                                                                
       660-GET-PAYBASIS-RECORDS-EXIT.                                           
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       800-BUILD-OUTPUT.                                                        
                                                                                
           MOVE INPUT-GROUP-7 TO OUTPUT-GROUP-NUMBER.                           
           MOVE +1 TO WS-SUB.                                                   
           PERFORM 950-LOAD-COUNTS                                              
              THRU 950-LOAD-COUNTS-EXIT                                         
                   VARYING WS-SUB FROM 1 BY 1                                   
                   UNTIL WS-SUB > 9.                                            
                                                                                
       800-BUILD-OUTPUT-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
      * SUBROUTINE - WRITE BACKUP RECORD                                        
      *---------------------------------------------------------------*         
       900-WRITE-BACKUP.                                                        
                                                                                
           MOVE DBASE-RECORD-NAME (WS-SUB)   TO BACKUP-RECORD-NAME.             
           MOVE DBASE-RECORD-LENGTH (WS-SUB) TO BACKUP-LLB.                     
           ADD  +33                          TO BACKUP-LLB.                     
                                                                                
           MOVE 'PRINT-DATA-070'      TO LOGICAL-RECORD-NAME.                   
                                                                                
           CALL GAEDATSR          USING  STORE-LR                               
                                         BACKUP-RECORD                          
                                         ICBM.                                  
                                                                                
           IF LR-STATUS-OK                                                      
              ADD +1 TO DBASE-RECORDS(WS-SUB)                                   
           ELSE                                                                 
              DISPLAY 'SEQUENTIAL DBASE FILE INVALID'                           
                      ' -  NOTHING PROCESSED'                                   
              MOVE PROGRAM-LINKAGE-STATUS TO SAVE-RETURN                        
              DISPLAY '*** ERROR WRITING BACKUP EXTRACT: ' ICBM                 
           END-IF.                                                              
                                                                                
            INITIALIZE BACKUP-RECORD.                                           
                                                                                
       900-WRITE-BACKUP-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
      * SUBROUTINE - OUTPUT RECORD                                              
      *---------------------------------------------------------------*         
       910-WRITE-OUTPUT.                                                        
                                                                                
           MOVE 'PRINT-DATA-021'      TO LOGICAL-RECORD-NAME.                   
                                                                                
           CALL GAEDATSR          USING  STORE-LR                               
                                         OUTPUT-RECORD                          
                                         ICBM.                                  
                                                                                
            IF NOT LR-STATUS-OK                                                 
               DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                       
            END-IF.                                                             
                                                                                
            INITIALIZE OUTPUT-RECORD.                                           
                                                                                
       910-WRITE-OUTPUT-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
       950-LOAD-COUNTS.                                                         
                                                                                
           MOVE DBASE-RECORDS(WS-SUB) TO OUTPUT-RECORDS(WS-SUB).                
           MOVE ZERO TO DBASE-RECORDS(WS-SUB).                                  
                                                                                
       950-LOAD-COUNTS-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
