       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2VODCR.                                                 
      *AUTHOR.        REGINA KNAUD.                                             
      *DATE-WRITTEN.  AUGUST 2005.                                              
      *DATE-COMPILED.                                                           
      *****************************************************************         
      *                                                                         
      *   COMMISSIONS SYSTEM                                                    
      *   HUB VO COMMISSIONS PROJECT                                            
      *                                                                         
      *   HUB:  VO AND MAINFRAME COMMISSIONS FEED MERGE                         
      *         (VOCOMM FEEDS MERGE)                                            
      *                                                                         
      *   THIS PROGRAM READS THE VO COMMISSION RELEASE FEED                     
      *   (VOCOMEXT) WHICH COMES FROM THE NIGHTLY VO COMMISSIONS                
      *   CALCULATION PROCESS.  THE VO COMMISSION RELEASE FEED                  
      *   WILL BE REFORMATTED INTO THE VO COMMISSION REFORMATTED                
      *   RELEASE FILE (VODACRF).                                               
      *                                                                         
      *   CALLING PROGRAM:  NONE                                                
      *                                                                         
      *   CALLED PROGRAMS:  GAEDATSR                                            
      *                     ZACCVSAM                                            
      *                                                                         
      *   COPYBOOKS:                                                            
      *       VOCRFEXT                                                          
      *       GCOMDACR                                                          
      *       FDOFFILE                                                          
      *       GARDSVRB                                                          
      *       HCSLRNAM                                                          
      *       ICBM                                                              
      *                                                                         
      *   INPUT  - VO COMMISSION RELEASE FEED (VOCRFEXT)                        
      *            COMMISSION RELEASE NEXT VERSION FILE (DACRFNUM)              
      *                                                                         
      *   OUTPUT - VO COMMISSION REFORMATTED RELEASE FILE (VODACRF)             
      *            COMMISSION RELEASE NEXT VERSION FILE (DACRFNUM)              
      *                                                                         
      *   DESCRIPTION:                                                          
      *     READ THE DACRFNUM(0) FILE TO GET THE EXPECTED FILE NUMBER.          
      *     READ THE FIRST RECORD FROM THE VOCRFEXT FILE.                       
      *        THE FIRST RECORD HAS RECORD TYPE 'A' AND WILL CONTAIN            
      *        THE FILE NUMBER.                                                 
      *     COMPARE THE FILE NUMBER VALUES FROM THE DACRFNUM(0) AND             
      *        VOCRFEXT FILES.  IF THEY ARE THE SAME, INCREMENT                 
      *        THE FILE NUMBER BY 1 AND CONTINUE PROCESSING ALL OF              
      *        OF THE VOCRFEXT RECORDS.  SET THE RETURN CODE TO 0.              
      *        IF THEY ARE NOT THE SAME, DO NOT INCREMENT THE FILE              
      *        NUMBER VALUE AND DO NOT PROCESS THE REST OF THE                  
      *        VOCRFEXT FILE; DO NOT ABEND THIS PROGRAM BUT SET                 
      *        THE RETURN CODE TO 4.                                            
      *        WRITE OUT MESSAGES IN THE VOCOMMSG FILE TO INDICATE              
      *        THAT THE OUTPUT VODACRF(+1) FILE FROM THIS PROCESSING            
      *        IS AN EMPTY FILE DUE TO A MISMATCH IN FILE VERSION               
      *        NUMBERS AND THAT THE FILE VERSION NUMBERS SHOULD BE              
      *        INVESTIGATED AND CORRECTED BEFORE THE NEXT CYCLE.                
      *        END THE PROCESSING.                                              
      *     PROCESSING THE REST OF THE THE VOCRFEXT FILE                        
      *     (RECORD TYPE D):                                                    
      *        REFORMAT THE 'D' RECORDS AND WRITE THEM OUT IN                   
      *        GCOMDACR FORMAT.                                                 
      *     WRITE OUT THE FILE NUMBER IN DACRFNUM(+1) FILE.                     
      *                                                                         
180947*        IF THE INPUT FILE IS EMPTY, DO NOT ABEND THIS PROGRAM.DO         
180947*        NOT INCREMENT THE FILE NUMBER IN DACRFNUM(+1) FILE.CREATE        
180947*        AN EMPTY VODACRF(+1) FILE.                                       
180947*                                                                         
180947*        IF THE INPUT FILE HAS MORE THAN ONE DAY'S RECORD,THE             
180947*        PROGRAM SHOULD NOT ABEND. EACH TIME AN A TYPE RECORD IS          
180947*        FOUND, THE FILE NUMBER WILL BE COMPARED WITH THE FILE            
180947*        NUMBER IN DACRFNUM(0) FILE. IF IT IS A MATCH, IT WILL BE         
180947*        INCREMENTED BY 1 IN DACRFNUM. THE FINAL NUMBER WILL BE           
180947*        WRITTEN TO THE DACRFNUM(+1) FILE FOR NEXT CYCLE'S                
180947*        PROCESSING.                                                      
180947*        ALL OTHER RECORDS WILL BE PROCESSED AND REFORMATTED AS           
180947*        PER THE PREVIOUS LOGIC AND WILL BE WRITTEN TO VODACRF(+1)        
180947*        FILE.                                                            
      ******************************************************************        
      *    MMM/CCYY   -    NAME            -   DESCRIPTION                      
      *    AUG 2005        REGINA KNAUD        INITIAL CREATION.                
      *    OCT 2008        IBM                 COMPILER UPGRADE.                
      *                                                                         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWVODACR          
180947* OCT2012 - T180947 - CHANGES FOR COMMISSION SYSTEMS TASK                 
      *****************************************************************         
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       SOURCE-COMPUTER. IBM-370-165.                                            
       OBJECT-COMPUTER. IBM-370-165.                                            
                                                                                
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-VARIABLES.                                                        
           05  FILLER                      PIC X(32) VALUE                      
FXXTOK         '*** GC2VODCR WORKING STORAGE ***'.                              
           05  WS-VOCRFEXT-EOF             PIC X.                               
           05  WS-GROUP-NUMBER-7           PIC X(7).                            
           05  WS-GROUP-NUMBER-NUM REDEFINES WS-GROUP-NUMBER-7                  
                                           PIC 9(7).                            
           05  WS-GROUP-NUMBER             PIC S9(7).                           
           05  WS-SUB-ACCOUNT.                                                  
               10  WS-SUB-ACCOUNT-1ST-CHAR PIC X VALUE '-'.                     
               10  WS-SUB-ACCOUNT-REM-CHAR PIC X(3).                            
           05  WS-AMOUNT-NINE              PIC 9(9).99.                         
           05  WS-AMT-NINE REDEFINES WS-AMOUNT-NINE.                            
               10  WS-AMT-NINE-1           PIC 9(9).                            
               10  WS-AMT-NINE-2           PIC X.                               
               10  WS-AMT-NINE-3           PIC 99.                              
           05  WS-AMOUNT-SIX               PIC 9(6).9(5).                       
           05  WS-AMT-SIX   REDEFINES WS-AMOUNT-SIX.                            
               10  WS-AMT-SIX-1            PIC 9(6).                            
               10  WS-AMT-SIX-2            PIC X.                               
               10  WS-AMT-SIX-3            PIC 9(5).                            
           05  WS-AMOUNT-THREE             PIC 9(3).99.                         
           05  WS-AMT-THREE REDEFINES WS-AMOUNT-THREE.                          
               10  WS-AMT-THREE-1          PIC 9(3).                            
               10  WS-AMT-THREE-2          PIC X.                               
               10  WS-AMT-THREE-3          PIC 99.                              
           05  WS-NINE-AMOUNT              PIC S9(9)V99.                        
           05  WS-SIX-AMOUNT               PIC S9(6)V9(5).                      
           05  WS-THREE-AMOUNT             PIC S9(3)V99.                        
180947*----------------------------------------------------------------*        
180947*    VARIABLE TO CHECK EMPTY VOCOMSRT FILE                                
180947*----------------------------------------------------------------*        
180947     05  WS-VOCRFEXT-EMPTY           PIC X.                               
                                                                                
      *01  VO-RLSE-EXTRACT.                                                     
           COPY VOCRFEXT.                                                       
                                                                                
      *01  GCOMDACR.                                                            
           COPY GCOMDACR.                                                       
                                                                                
      *    DACRFNUM(0) FILE                                                     
       01  DACRFNUM-IN-BATCH-NUM.                                               
           05  DACRFNUM-IN-BATCH-NUMBER    PIC 9(9).                            
           05  FILLER                      PIC X(71).                           
                                                                                
      *    DACRFNUM(+1) FILE                                                    
       01  DACRFNUM-OUT-BATCH-NUM.                                              
           05  DACRFNUM-OUT-BATCH-NUMBER   PIC 9(9).                            
           05  FILLER                      PIC X(71) VALUE SPACES.              
                                                                                
180947*----------------------------------------------------------------*        
180947*    VARIABLE TO STORE DACRFNUM(0) FILE NUMBER                            
180947*----------------------------------------------------------------*        
180947 01  WS-DACRFNUM-FIRST-BNUM.                                              
180947     05  WS-DACRFNUM-FIRST-BNUMBER   PIC 9(9).                            
180947     05  FILLER                      PIC X(71) VALUE SPACES.              
                                                                                
       01  VOCOMMSG-RECORDS.                                                    
           05  VOCOMMSG-REC1               PIC X(80) VALUE                      
           'VODACRF FILE FOR TONIGHT IS EMPTY DUE TO A MISMATCH IN'.            
           05  VOCOMMSG-REC2               PIC X(80) VALUE                      
           'FILE VERSION NUMBERS.  THIS SHOULD BE INVESTIGATED AND'.            
           05  VOCOMMSG-REC3               PIC X(80) VALUE                      
           'CORRECTED BEFORE THE NEXT CYCLE.                      '.            
                                                                                
      *----------------------------------------------------------------*        
      *    DATA SERVER ACTION VERBS                                             
      *----------------------------------------------------------------*        
       01  GAEDATSR-PARMS.                                                      
                                      COPY GARDSVRB.                            
                                                                                
       01  WS-GAEDATSR.                                                         
           05  GAEDATSR               PIC X(8) VALUE 'GAEDATSR'.                
           05  WS-GAEDATSR-VERB       PIC X(16).                                
                                                                                
      *----------------------------------------------------------------*        
      *    INTERFACE CONTROL BLOCK                                              
      *----------------------------------------------------------------*        
       01  ICBM.                                                                
                                      COPY ICBM.                                
                                                                                
      *----------------------------------------------------------------*        
      *    LOGICAL RECORD NAMES                                                 
      *----------------------------------------------------------------*        
       01  LOGICAL-RECORD-NAMES.                                                
                                      COPY HCSLRNAM.                            
              10  LR-VOCRFEXT-IN      PIC X(16) VALUE 'CARD-DATA-010'.          
              10  LR-IN-BATCH-NUM     PIC X(16) VALUE 'CARD-DATA-011'.          
              10  LR-VODACRF-OUT      PIC X(16) VALUE 'PRINT-DATA-071'.         
              10  LR-OUT-BATCH-NUM    PIC X(16) VALUE 'PRINT-DATA-021'.         
              10  LR-VOCOMMSG-OUT     PIC X(16) VALUE 'PRINT-DATA-022'.         
                                                                                
      *------------------------------------------------------------             
      *    FIELD OFFICE FILE  (FDOFFILE)                                        
      *-------------------------------------------------------------            
                                                                                
      *01  FIELD-OFFICE-FILE.                                                   
           COPY FDOFFILE.                                                       
                                                                                
       01  FDOFFILE-PARMS.                                                      
           05  FDOFFILE-PARM1.                                                  
               10  FDOFFILE-DDNAME      PIC X(7) VALUE 'VSDSI97'.               
               10  FDOFFILE-ACCTYPE     PIC X(5) VALUE 'KEYED'.                 
               10  FDOFFILE-RECTYPE     PIC X    VALUE 'V'.                     
               10  FDOFFILE-FUNCTION    PIC X(6) VALUE 'GETRAN'.                
               10  FDOFFILE-ERRCODE     PIC X(5).                               
               10  FDOFFILE-READCT      PIC S9(7) COMP-3 VALUE +0.              
               10  FDOFFILE-WRITECT     PIC S9(7) COMP-3 VALUE +0.              
               10  FDOFFILE-UPDATECT    PIC S9(7) COMP-3 VALUE +0.              
               10  FDOFFILE-DELETCT     PIC S9(7) COMP-3 VALUE +0.              
               10  FDOFFILE-RECLGTH     PIC S9(4) COMP.                         
           05  FDOFFILE-PARM2.                                                  
               10  FDOFFILE-BRANCH      PIC X(5).                               
                                                                                
      *------------------------------------------------------------             
      *    ABEND VARIABLES                                                      
      *-------------------------------------------------------------            
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X            PIC X(04).                             
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES.                                                    
               10  WTL-MESS-LENGTH       PIC S9(3) VALUE +133 COMP-3.           
               10  WTL-MESS-CC           PIC X(1)  VALUE SPACES.                
               10  WTL-MESS-TEXT         PIC X(132) VALUE SPACES.               
           05  WTL-FLAG                  PIC X(1)  VALUE 'B'.                   
           05  WTL-REPLY                 PIC X(3)  VALUE 'NO '.                 
           05  WTL-REPLY-AREA            PIC X(80) VALUE SPACES.                
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - VOCRFEXT MISSING THE FILE# (RECTYPE A)'.           
           05  WTL-2                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - PROBLEM INITIAL READ VOCRFEXT FILE'.               
           05  WTL-3                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - PROBLEM READING DACRFNUM(0) FILE'.                 
           05  WTL-4                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - VOCRFEXT CONTAINS INVALID RECORD TYPE'.            
           05  WTL-5                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - PROBLEM READING VOCRFEXT FILE'.                    
           05  WTL-6                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - PROBLEM WRITING VODACRF - GCOMDACR'.               
           05  WTL-7                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - PROBLEM WRITING DACRFNUM(+1) FILE'.                
           05  WTL-8                     PIC X(80)                              
FXXTOK     VALUE 'GC2VODCR - PROBLEM CLOSING FILES'.                            
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY         OCCURS  8 TIMES.                       
               10  WTL-MESSAGE           PIC X(80).                             
       01  WTL-SUB                       PIC S9(4) COMP.                        
                                                                                
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
       0000-MAINLINE.                                                           
                                                                                
           PERFORM 1000-INITIALIZATION      THRU 1000-EXIT.                     
           PERFORM 2000-PROCESS-VOCRFEXT    THRU 2000-EXIT                      
                   UNTIL WS-VOCRFEXT-EOF = 'Y'.                                 
           PERFORM 7000-WRITE-OUT-BATCH-NUM THRU 7000-EXIT.                     
           PERFORM 9000-FINISH              THRU 9000-EXIT.                     
                                                                                
           STOP RUN.                                                            
                                                                                
       0000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 1000-INITIALIZATION                                                     
      *     INITIALIZE VARIABLES.                                               
      *     READ THE FIRST INPUT VOCRFEXT RECORD (FIRST RECORD SHOULD           
      *          HAVE RECORD TYPE 'A' - CONTAINS THE FILE NUMBER).              
180947*     IF THE FILE IS EMPTY SET 'Y' TO WS-VOCRFEXT-EMPTY                   
      ******************************************************************        
       1000-INITIALIZATION.                                                     
FXXTOK     MOVE 'GC2VODCR'          TO ICBM-PROGRAM-NAME.                       
           MOVE  LOW-VALUES         TO LINKAGE-CONTROL.                         
                                                                                
           MOVE 'N'                 TO WS-VOCRFEXT-EOF.                         
180947     MOVE 'N'                 TO WS-VOCRFEXT-EMPTY.                       
                                                                                
           MOVE LR-VOCRFEXT-IN      TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-FIRST        TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       VO-RLSE-EXTRACT                          
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF VORLSE-REC-TYPE = 'A'                                          
                 PERFORM 1010-CHECK-IN-BATCH-NUM THRU 1010-EXIT                 
              ELSE                                                              
                 MOVE +1  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND THRU 9999-EXIT                          
           ELSE                                                                 
180947        IF LR-NOT-FOUND                                                   
180947           MOVE 'Y'                 TO WS-VOCRFEXT-EMPTY                  
180947           PERFORM 1010-CHECK-IN-BATCH-NUM THRU 1010-EXIT                 
180947        ELSE                                                              
                 MOVE +2  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
180947       END-IF                                                             
           END-IF.                                                              
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 1010-CHECK-IN-BATCH-NUM                                                 
      *     READ THE DACRFNUM FILE.                                             
      *     CHECK THE FILE NUMBER FROM THE DACRFNUM AND VOCRFEXT FILES.         
      *     IF THE FILE NUMBERS ARE THE SAME, INCREMENT THE DACRFNUM            
      *        FILE NUMBER BY 1 (FOR THE NEXT CYCLE'S PROCESSING) AND           
      *        PROCESS TILL THE END OF THE VOCRFEXT FILE.                       
      *     IF THE FILE NUMBERS ARE NOT THE SAME, DO NOT INCREMENT              
      *        THE DACRFNUM FILE NUMBER AND THEN END THE PROCESSING.            
      ******************************************************************        
       1010-CHECK-IN-BATCH-NUM.                                                 
           MOVE LR-IN-BATCH-NUM     TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-FIRST        TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       DACRFNUM-IN-BATCH-NUM                    
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF DACRFNUM-IN-BATCH-NUMBER = VORLSE-FILE-NUMBER                  
                  COMPUTE DACRFNUM-OUT-BATCH-NUMBER =                           
                          DACRFNUM-IN-BATCH-NUMBER  + 1                         
180947            MOVE DACRFNUM-IN-BATCH-NUMBER TO                              
180947                 WS-DACRFNUM-FIRST-BNUMBER                                
                  MOVE +00 TO RETURN-CODE                                       
              ELSE                                                              
                  COMPUTE DACRFNUM-OUT-BATCH-NUMBER =                           
                          DACRFNUM-IN-BATCH-NUMBER  + 0                         
                  MOVE LR-VOCOMMSG-OUT    TO LOGICAL-RECORD-NAME                
                  MOVE STORE-LR           TO WS-GAEDATSR-VERB                   
                  CALL GAEDATSR        USING WS-GAEDATSR-VERB                   
                                             VOCOMMSG-REC1                      
                                             ICBM                               
                  CALL GAEDATSR        USING WS-GAEDATSR-VERB                   
                                             VOCOMMSG-REC2                      
                                             ICBM                               
                  CALL GAEDATSR        USING WS-GAEDATSR-VERB                   
                                             VOCOMMSG-REC3                      
                                             ICBM                               
                  MOVE 'Y'                TO WS-VOCRFEXT-EOF                    
                  MOVE +04 TO RETURN-CODE                                       
              END-IF                                                            
           ELSE                                                                 
              MOVE +3  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND THRU 9999-EXIT                             
           END-IF.                                                              
                                                                                
       1010-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2000-PROCESS-VOCRFEXT                                                   
      ******************************************************************        
       2000-PROCESS-VOCRFEXT.                                                   
                                                                                
           MOVE LR-VOCRFEXT-IN      TO LOGICAL-RECORD-NAME.                     
           MOVE OBTAIN-NEXT         TO WS-GAEDATSR-VERB.                        
           CALL GAEDATSR         USING WS-GAEDATSR-VERB                         
                                       VO-RLSE-EXTRACT                          
                                       ICBM.                                    
           IF LR-STATUS-OK                                                      
              IF VORLSE-REC-TYPE = 'D'                                          
                 PERFORM 2100-REFORMAT-REC-TYPE-D THRU 2100-EXIT                
                 PERFORM 5000-WRITE-GCOMDACR THRU 5000-EXIT                     
              ELSE                                                              
180947           IF VORLSE-REC-TYPE = 'A'                                       
180947              MOVE DACRFNUM-OUT-BATCH-NUMBER TO                           
180947                   DACRFNUM-IN-BATCH-NUMBER                               
180947              IF DACRFNUM-IN-BATCH-NUMBER = VORLSE-FILE-NUMBER            
180947                 COMPUTE DACRFNUM-OUT-BATCH-NUMBER =                      
180947                         DACRFNUM-IN-BATCH-NUMBER  + 1                    
180947                 MOVE +00 TO RETURN-CODE                                  
180947              ELSE                                                        
180947                 COMPUTE DACRFNUM-OUT-BATCH-NUMBER =                      
180947                          DACRFNUM-IN-BATCH-NUMBER  + 0                   
180947                 MOVE LR-VOCOMMSG-OUT    TO LOGICAL-RECORD-NAME           
180947                 MOVE STORE-LR           TO WS-GAEDATSR-VERB              
180947                 CALL GAEDATSR        USING WS-GAEDATSR-VERB              
180947                                            VOCOMMSG-REC1                 
180947                                            ICBM                          
180947                 CALL GAEDATSR        USING WS-GAEDATSR-VERB              
180947                                            VOCOMMSG-REC2                 
180947                                            ICBM                          
180947                 CALL GAEDATSR        USING WS-GAEDATSR-VERB              
180947                                            VOCOMMSG-REC3                 
180947                                            ICBM                          
180947                 MOVE 'Y'                TO WS-VOCRFEXT-EOF               
180947                    MOVE WS-DACRFNUM-FIRST-BNUMBER TO                     
180947                            DACRFNUM-OUT-BATCH-NUMBER                     
180947                 MOVE +04 TO RETURN-CODE                                  
180947              END-IF                                                      
180947           ELSE                                                           
                    MOVE +4  TO WTL-SUB                                         
                    MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                 
                    PERFORM 9999-WTL-ABEND THRU 9999-EXIT                       
180947           END-IF                                                         
              END-IF                                                            
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'           TO WS-VOCRFEXT-EOF                          
              ELSE                                                              
                 MOVE +5  TO WTL-SUB                                            
                 MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                       
              END-IF                                                            
           END-IF.                                                              
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 2100-REFORMAT-REC-TYPE-D                                                
      ******************************************************************        
       2100-REFORMAT-REC-TYPE-D.                                                
           MOVE VORLSE-GROUP-NUMBER  TO WS-GROUP-NUMBER-7.                      
           MOVE WS-GROUP-NUMBER-NUM  TO WS-GROUP-NUMBER.                        
           MOVE WS-GROUP-NUMBER      TO GDACR-GROUP.                            
           MOVE VORLSE-GR-ACCOUNT    TO WS-SUB-ACCOUNT-REM-CHAR.                
           MOVE WS-SUB-ACCOUNT       TO GDACR-SUB-ACCOUNT                       
           MOVE VORLSE-AGENT-CODE    TO GDACR-AGENT-CODE.                       
           MOVE VORLSE-VLNO          TO GDACR-VLNO.                             
           MOVE 0                    TO GDACR-FUND.                             
           MOVE 0                    TO GDACR-LBUS.                             
           MOVE 0                    TO GDACR-PLAN-TYPE.                        
           MOVE 0                    TO GDACR-POLSPEX.                          
           MOVE VORLSE-BRANCH        TO GDACR-BRANCH.                           
           MOVE VORLSE-CURRENCY      TO GDACR-CURRENCY.                         
           MOVE 12                   TO GDACR-MODE.                             
           MOVE 0                    TO GDACR-BILCL.                            
           MOVE VORLSE-ACCT-EFFCC    TO GDACR-EFF-CC.                           
           MOVE VORLSE-ACCT-EFFYY    TO GDACR-EFF-YY.                           
           MOVE VORLSE-ACCT-EFFMM    TO GDACR-EFF-MM.                           
           IF VORLSE-ACCT-EFFMM = 02                                            
              AND                                                               
              VORLSE-ACCT-EFFDD = 29                                            
              MOVE 28 TO VORLSE-ACCT-EFFDD                                      
           END-IF.                                                              
           MOVE VORLSE-ACCT-EFFDD    TO GDACR-EFF-DD.                           
           MOVE VORLSE-BILLING-NAME  TO GDACR-BILLING-NAME.                     
           MOVE VORLSE-PREMNO        TO GDACR-PREMNO.                           
           MOVE 0                    TO GDACR-PRORATEMO.                        
           MOVE VORLSE-PREM-DUECC    TO GDACR-PREM-CC.                          
           MOVE VORLSE-PREM-DUEYY    TO GDACR-PREM-YY.                          
           MOVE VORLSE-PREM-DUEMM    TO GDACR-PREM-MM.                          
           IF VORLSE-PREM-DUEMM = 02                                            
              AND                                                               
              VORLSE-PREM-DUEDD = 29                                            
              MOVE 28 TO VORLSE-PREM-DUEDD                                      
           END-IF.                                                              
           MOVE VORLSE-PREM-DUEDD    TO GDACR-PREM-DD.                          
           MOVE 0                    TO GDACR-PMOD.                             
           MOVE VORLSE-MAN           TO GDACR-MAN.                              
           MOVE 0                    TO GDACR-SPCL.                             
           MOVE 0                    TO GDACR-UNDCL.                            
           MOVE 0                    TO GDACR-SEX.                              
           MOVE 0                    TO GDACR-CEDED.                            
           MOVE VORLSE-SCALE         TO GDACR-SCALE.                            
           MOVE 0                    TO GDACR-TRAN-BALYR.                       
           MOVE 0                    TO GDACR-TRAN-REASON.                      
           MOVE 0                    TO GDACR-TRAN-CC.                          
           MOVE 0                    TO GDACR-TRAN-YY.                          
           MOVE 0                    TO GDACR-TRAN-MM.                          
           MOVE 0                    TO GDACR-TRAN-DD.                          
           MOVE VORLSE-FOGL-CODE     TO GDACR-FOGL-CODE.                        
           MOVE 'G'                  TO GDACR-DIRCOMIND.                        
           MOVE 0                    TO GDACR-CONTRACT-TYPE.                    
           MOVE 0                    TO GDACR-CLASS.                            
           MOVE VORLSE-BRANCH-X      TO FDOFFILE-BRANCH.                        
           CALL 'ZACCVSAM'        USING FDOFFILE-PARM1                          
                                        FDOFFILE-PARM2                          
                                        FIELD-OFFICE-FILE.                      
           MOVE FOF-MLI-MANAGER-CODE TO GDACR-MGR.                              
           MOVE VORLSE-SHARE         TO WS-AMOUNT-THREE.                        
           IF VORLSE-SHARE-SGN = '-'                                            
              COMPUTE WS-THREE-AMOUNT = (WS-AMT-THREE-1 +                       
                                         (WS-AMT-THREE-3 / 100))                
                                        * (-1)                                  
           ELSE                                                                 
              COMPUTE WS-THREE-AMOUNT = (WS-AMT-THREE-1 +                       
                                        (WS-AMT-THREE-3 / 100))                 
           END-IF.                                                              
           MOVE WS-THREE-AMOUNT      TO GDACR-SHARE.                            
           MOVE 0                    TO GDACR-ASSIGNEE.                         
           MOVE 341                  TO GDACR-CAUSE.                            
           MOVE 0                    TO GDACR-PARTICULARS-CODE.                 
           MOVE 10                   TO GDACR-SOURCE.                           
           MOVE 0                    TO GDACR-REC-CENTURY.                      
           MOVE 0                    TO GDACR-REC-YEAR.                         
           MOVE 0                    TO GDACR-REC-MONTH.                        
           MOVE 0                    TO GDACR-REC-DAY.                          
           MOVE 0                    TO GDACR-AUDIT-NUMBER.                     
           MOVE 0                    TO GDACR-AUDIT-TYPE.                       
           MOVE 0                    TO GDACR-STATUS.                           
           MOVE 0                    TO GDACR-ERROR-CODE.                       
           MOVE 0                    TO GDACR-PROC-CC.                          
           MOVE 0                    TO GDACR-PROC-YY.                          
           MOVE 0                    TO GDACR-PROC-MM.                          
           MOVE 0                    TO GDACR-PROC-DD.                          
           MOVE 0                    TO GDACR-END-CC.                           
           MOVE 0                    TO GDACR-END-YY.                           
           MOVE 0                    TO GDACR-END-MM.                           
           MOVE 0                    TO GDACR-END-DD.                           
           MOVE VORLSE-CODE-1        TO GDACR-CODE(1).                          
           MOVE VORLSE-CMAMT-1       TO WS-AMOUNT-NINE.                         
           IF VORLSE-CMAMT-1-SGN = '-'                                          
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                         (WS-AMT-NINE-3 / 100))                 
                                        * (-1)                                  
           ELSE                                                                 
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
           END-IF.                                                              
           MOVE WS-NINE-AMOUNT       TO GDACR-CMAMT(1).                         
           MOVE VORLSE-CODE-2        TO GDACR-CODE(2).                          
           MOVE VORLSE-CMAMT-2       TO WS-AMOUNT-NINE.                         
           IF VORLSE-CMAMT-2-SGN = '-'                                          
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                         (WS-AMT-NINE-3 / 100))                 
                                        * (-1)                                  
           ELSE                                                                 
              COMPUTE WS-NINE-AMOUNT = (WS-AMT-NINE-1 +                         
                                        (WS-AMT-NINE-3 / 100))                  
           END-IF.                                                              
           MOVE WS-NINE-AMOUNT       TO GDACR-CMAMT(2).                         
           MOVE VORLSE-CODE-3        TO GDACR-CODE(3).                          
           MOVE VORLSE-CPAMT-3       TO WS-AMOUNT-SIX.                          
           IF VORLSE-CPAMT-3-SGN = '-'                                          
              COMPUTE WS-SIX-AMOUNT = (WS-AMT-SIX-1 +                           
                                         (WS-AMT-SIX-3 / 100000))               
                                        * (-1)                                  
           ELSE                                                                 
              COMPUTE WS-SIX-AMOUNT = (WS-AMT-SIX-1 +                           
                                        (WS-AMT-SIX-3 / 100000))                
           END-IF.                                                              
           MOVE WS-SIX-AMOUNT        TO GDACR-CPAMT(3).                         
           MOVE 0                    TO GDACR-CODE (4).                         
           MOVE 0                    TO GDACR-CRAMT(4).                         
           MOVE 0                    TO GDACR-CODE (5).                         
           MOVE 0                    TO GDACR-CRAMT(5).                         
           MOVE 0                    TO GDACR-CODE (6).                         
           MOVE 0                    TO GDACR-CRAMT(6).                         
           MOVE 0                    TO GDACR-CODE (7).                         
           MOVE 0                    TO GDACR-CRAMT(7).                         
           MOVE 0                    TO GDACR-CODE (8).                         
           MOVE 0                    TO GDACR-CRAMT(8).                         
           MOVE 0                    TO GDACR-CODE (9).                         
           MOVE 0                    TO GDACR-CRAMT(9).                         
           MOVE 0                    TO GDACR-CODE (10).                        
           MOVE 0                    TO GDACR-CRAMT(10).                        
                                                                                
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 5000-WRITE-GCOMDACR.                                                    
      ******************************************************************        
       5000-WRITE-GCOMDACR.                                                     
           MOVE LR-VODACRF-OUT        TO LOGICAL-RECORD-NAME.                   
           MOVE STORE-LR              TO WS-GAEDATSR-VERB.                      
           CALL GAEDATSR           USING WS-GAEDATSR-VERB                       
                                         GCOMDACR                               
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +6  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       5000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 7000-WRITE-OUT-BATCH-NUM                                                
      ******************************************************************        
       7000-WRITE-OUT-BATCH-NUM.                                                
           MOVE LR-OUT-BATCH-NUM      TO LOGICAL-RECORD-NAME.                   
           MOVE STORE-LR              TO WS-GAEDATSR-VERB.                      
           CALL GAEDATSR           USING WS-GAEDATSR-VERB                       
                                         DACRFNUM-OUT-BATCH-NUM                 
                                         ICBM.                                  
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +7  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       7000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9000-FINISH                                                             
      *     CLOSE THE FILES.                                                    
      ******************************************************************        
       9000-FINISH.                                                             
           MOVE SPACES      TO LOGICAL-RECORD-NAME.                             
           MOVE FINISH-LR   TO WS-GAEDATSR-VERB.                                
           CALL GAEDATSR USING WS-GAEDATSR-VERB                                 
                               LOGICAL-RECORD-NAME                              
                               ICBM.                                            
                                                                                
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE +8  TO WTL-SUB                                               
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
       9000-EXIT.                                                               
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9999-WTL-ABEND                                                          
      ******************************************************************        
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB) TO WTL-MESS-TEXT.                         
           CALL 'WTL'    USING  WTL-MESSAGES                                    
                                WTL-FLAG                                        
                                WTL-REPLY                                       
                                WTL-REPLY-AREA.                                 
                                                                                
           CALL 'ILBOABN0'  USING  WS-COMP-CODE.                                
                                                                                
       9999-EXIT.                                                               
           EXIT.                                                                
                                                                                
