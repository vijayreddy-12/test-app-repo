       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID. GPRSOARR.                                                    
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS.  SHOWS ALL GROUPS FOR WHICH A LAPSE NOTICE HAS BEEN             
      *          PRODUCED AND CLAIMS HAVE BEEN SUSPENDED.                       
      *          THIS MODULE INTERIGATES REPORT TYPE "H" AND IF TYPE            
      *          "B" CALLS GROUP OFFICE OVERDUE PREMIUM REPORT                  
      *          MODULE.                                                        
      *                                                                         
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  START                          *         
      *****************************************************************         
      *                                                               *         
      *  AUG/89  M DRURY  - ADD     NEW FIELDS TO INPUT               *         
      *                     -  REPORT NUMBER  (1)  -  1,2,3           *         
      *                     -  SORT FIELDS    (19) -  DIFF FOR EACH   *         
      *                     -  PRODUCT CODE   (1)  - GGIPRODUCT-CODE  *         
      *                   - REQ # 242 (ALPHA+).                       *         
      *                                                               *         
      *     NOTE =====>  THE FILE USED IN THIS PROGRAM COMES FORM     *         
      *                  GFMINTM5.                                    *         
      *                                                               *         
      *  SEP/89 A SCHLEICHER - CHANGED MAINLINE TO CALL VARIOUS       *         
      *                        REPORTS DEPENDING ON REPORT NUMBER     *         
      *                                                               *         
      *  NOV/89 I BUCKNELL   - FIX ENDLESS LOOP ENCOUNTERED WHILE     *         
      *                        TESTING.  FIX TEST WHICH EXAMS RECORD  *         
      *                        TYPE AND DECIDES IF/WHO TO CALL NEXT   *         
      *                                                               *         
      *  FEB/90 M BURTON     - ADD IN A CALL TO A NEW REPORT NUMBER   *         
      *                        4 - CALL GPRSOAR4 --> BRANCH REPORT    *         
      *                                                               *         
      *  JUN/98 J ELKINS     - RECOMPILE TO INCLUDE COPYBOOK CHANGES  *         
      *                        TO GGFOARRS                            *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      *****************************************************************         
      *                   GIPSY-REL-1  END                            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *                                                               *         
      *                                                               *         
      *DATE-WRITTEN.  MODIFIED MAY 1984.                                        
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  END-PROGRAM                              PIC X.                      
           88   END-PROGRAM-88   VALUE 'Y'.                                     
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      FROM GIPSY PRINT FILE GROUP OFFICE ARREAR RECORD          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       LINKAGE SECTION.                                                         
       01  ARR-RECORD.                                                          
GNE        COPY GGFOARR7.                                                       
       01  OVR-RECORD  REDEFINES ARR-RECORD.                                    
GNE        COPY GGFOOVE7.                                                       
       01  FILLER      PIC X(5372).                                             
      *----------------------------------------------------------------*        
      *                                                                *        
      *      FROM GPRINTAL DRIVER MODULE                               *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LSMISC-AREA.                                                         
           03  FILLER                                PIC X(4).                  
           03  LSM-HIDATE                            PIC X(4).                  
           03  LSM-STATDATE                          PIC X(4).                  
           03  LSM-PREMDATE                          PIC X(4).                  
           03  LSM-RESTART.                                                     
               05  LSR-RECTYPE                       PIC X(1).                  
               05  LSR-REPTYPE                       PIC X(1).                  
               05  LSR-GRPOFF                        PIC X(5).                  
               05  FILLER                            PIC X(7).                  
           03  FILLER                                PIC X(4).                  
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         PRINT PARAMETER COPY BOOK FOR SYS022 TO SYS029         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY GPRPRINT.                                                           
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         TAPE PARAMETER COPY BOOK FOR SYS011 AND SYS014         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY GPRTPARM.                                                           
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *             REPORT ACCUMULATOR COPY BOOK                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY GPRACCUM.                                                           
                                                                                
       PROCEDURE DIVISION USING ARR-RECORD                                      
                                LSMISC-AREA                                     
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
      **********************************************************                
      *    DISPLAY  '====>  GPRSOARR   <====='.                                 
      *    READY TRACE.                                                         
       000-MAINLINE.                                                            
           PERFORM A100-INIT.                                                   
           PERFORM A200-MAINLINE UNTIL END-PROGRAM-88.                          
           PERFORM A300-WRAPUP.                                                 
                                                                                
       A100-INIT.                                                               
           IF ARR-TYPE = 'H' AND                                                
              ARR-REPORT = 'A'                                                  
              MOVE 'N' TO END-PROGRAM                                           
           ELSE                                                                 
      *                                                               *         
      *****************************************************************         
      *                                                               *         
      *        CHANGED THE FIRST REC IN USING STMT.                   *         
      *        WAS   ARR-RECORD.        MARCUS SEP/89                 *         
      *****************************************************************         
      *                                                               *         
              CALL 'GPRSOOPR' USING OVR-RECORD                                  
                                    LSMISC-AREA                                 
                                    GPRPRINT                                    
                                    GPRTPARM                                    
                                    GPRACCUM                                    
              MULTIPLY 2 BY ACCUM-LAPSE-MAIL                                    
              MULTIPLY 2 BY ACCUM-OVERDUE                                       
             CALL 'DLSREAD' USING  TAPE-SYS014                                  
                                   TAPE-RETURN                                  
                                   ARR-RECORD                                   
                                   TAPE-SYS014-RECSIZE                          
                                   TAPE-SYS014-BLKSIZE                          
                                   TAPE-SYS014-FORMAT                           
                                  TAPE-SYS014-COUNT.                            
             IF  TAPE-RETURN IS NOT EQUAL TO ZEROS THEN                         
              MOVE 'Y' TO END-PROGRAM.                                          
                                                                                
       A200-MAINLINE.                                                           
      ***************************************************************           
      * GIPSY RELEASE 1, NOV89, I. BUCKNELL                                     
      *    INCLUDE 'A' PORTION OF TEST BELOW--PGMS WERE LOOPING                 
      *    AFTER PROGRESSING TO A 'HB3' RECORD.                                 
      ***************************************************************           
           IF ARR-TYPE NOT = 'H' OR                                             
              ARR-REPORT NOT = 'A'                                              
              MOVE 'Y'  TO END-PROGRAM                                          
           ELSE                                                                 
              IF ARR-REPORT-NUMBER = 1                                          
                 CALL 'GPRSOAR1' USING ARR-RECORD                               
                                       LSMISC-AREA                              
                                       GPRPRINT                                 
                                       GPRTPARM                                 
                                       GPRACCUM                                 
              ELSE                                                              
                 IF ARR-REPORT-NUMBER = 2                                       
                    CALL 'GPRSOAR2' USING ARR-RECORD                            
                                          LSMISC-AREA                           
                                          GPRPRINT                              
                                          GPRTPARM                              
                                          GPRACCUM                              
              ELSE                                                              
                 IF ARR-REPORT-NUMBER = 3                                       
                    CALL 'GPRSOAR3' USING ARR-RECORD                            
                                          LSMISC-AREA                           
                                          GPRPRINT                              
                                          GPRTPARM                              
                                          GPRACCUM                              
              ELSE                                                              
                 IF ARR-REPORT-NUMBER = 4                                       
                    CALL 'GPRSOAR4' USING ARR-RECORD                            
                                          LSMISC-AREA                           
                                          GPRPRINT                              
                                          GPRTPARM                              
                                          GPRACCUM.                             
                                                                                
       A300-WRAPUP.                                                             
           EXIT PROGRAM.                                                        
