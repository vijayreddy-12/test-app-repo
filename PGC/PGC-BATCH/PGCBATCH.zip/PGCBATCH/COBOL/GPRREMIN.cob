       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRREMIN.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS.  THIS PROGRAM IS USED TO PRINT REMINDER MESSAGE REPORT          
      *          REMINDER MESSAGES ARE CODED AND WRITTEN DIRECTLY TO            
      *          THE MOVEMENT FILE IN GFMREBEN.  REMINDER MESSAGE PRINT         
      *          RECORDS ARE REMOVED FROM THE MOVEMENT FILE BY GSPLIRT          
      *          WHEN THERE CODED DATE IS REACHED.                              
      *DATE-WRITTEN.  MODIFIED MAY 1984.                                        
      *SEPTEMBER 2008   ENTERPRISE COMPILER UPGRADE                             
      *DATE-COMPILED.                                                           
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  PAGE-SIZE              PIC S9(4) COMP   SYNC VALUE +0.               
       01  LINE-COUNT             PIC S9(4) COMP   SYNC VALUE +0.               
       01  PAGE-NUMBER            PIC S9(5) COMP-3 SYNC VALUE +0.               
       01  PREV-TO                PIC X(5)            VALUE LOW-VALUES.         
       01  ST-HIDATE              PIC X(7).                                     
       01  FORM-STANDARD          PIC X(2)            VALUE '91'.               
       01  QDATE-PARM             PIC X(2)            VALUE 'AC'.               
       01  CURR-TO.                                                             
           03  C-DEPT             PIC X(2).                                     
           03  C-CLRK             PIC X(3).                                     
                                                                                
       01  PRINT-SYS034              PIC X(06) VALUE 'SYS034'.                  
       01  PRINT-SYS034-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   TITLE PAGE LAYOUT                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TITLES.                                                              
           03  TITLE1.                                                          
               05  FILLER              PIC X(8)   VALUE 'GPRREMIN'.             
               05  FILLER              PIC X(14)  VALUE SPACES.                 
               05  FILLER              PIC X(33)                                
                   VALUE 'R E M I N D E R     L I S T I N G'.                   
               05  FILLER              PIC X(14)  VALUE SPACES.                 
               05  FILLER              PIC X(5)   VALUE 'PAGE '.                
               05  TITLE1-PAGE-NUMBER  PIC ZZZZ9  VALUE ZEROS.                  
               05  FILLER              PIC X(52)  VALUE SPACES.                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 LINE 1 OF THE COLUMN LAYOUT                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  TITLE2.                                                          
GNE            05  FILLER              PIC X(42)                                
GNE                VALUE '   T O    GROUP   ACCT  CERTIFICATE   FROM'.          
               05  FILLER              PIC X(40)                                
                   VALUE '     ACTION    DATE        M E S S A G E'.            
               05  FILLER              PIC X(52)  VALUE SPACES.                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 LINE 2 OF THE COLUMN LAYOUT                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
           03  TITLE3.                                                          
GNE            05  FILLER              PIC X(42)                                
GNE                VALUE 'DEPT CLK                  NUMBER    DEPT C'.          
               05  FILLER              PIC X(20)                                
                   VALUE 'LK    DATE   ENTERED'.                                
               05  FILLER              PIC X(72)  VALUE SPACES.                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *          PRINT LINE LAYOUT INCLUDING CARRIAGE CONTROL          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-LINE.                                                          
           03  CC                      PIC X(1).                                
           03  PR-LINE.                                                         
               05  FILLER              PIC X(1).                                
               05  T-DEPT-TO           PIC X(2).                                
               05  FILLER              PIC X(2).                                
               05  T-CLRK-TO           PIC X(3).                                
               05  FILLER              PIC X(2).                                
GNE            05  T-GROUP             PIC Z(7).                                
               05  FILLER              PIC X(2).                                
               05  T-ACCT              PIC X(3).                                
               05  FILLER              PIC X(2).                                
               05  T-CERT              PIC Z(9).                                
               05  FILLER              PIC X(4).                                
               05  T-DEPT-FR           PIC X(2).                                
               05  FILLER              PIC X(2).                                
               05  T-CLRK-FR           PIC X(3).                                
               05  FILLER              PIC X(2).                                
               05  P-ACTION            PIC X(7).                                
               05  FILLER              PIC X(2).                                
               05  P-ENT               PIC X(7).                                
               05  FILLER              PIC X(2).                                
               05  T-MESS              PIC X(45).                               
               05  P-MESS REDEFINES T-MESS.                                     
                   07  FILLER          PIC X(8).                                
                   07  P-HIDATE        PIC X(7).                                
GNE            05  FILLER              PIC X(23).                               
       LINKAGE SECTION.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  REMINDER RECORD LAYOUT                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-REC.                                                            
           03  FILLER                  PIC X(4).                                
           03  T-REC-TYPE              PIC X(1).                                
           03  T-DEPT-TO               PIC X(2).                                
           03  T-CLRK-TO               PIC X(3).                                
GNE        03  T-GROUP                 PIC S9(7)  COMP-3.                       
           03  T-ACCT                  PIC X(3).                                
           03  T-CERT                  PIC S9(9)  COMP-3.                       
           03  T-DEPT-FR               PIC X(2).                                
           03  T-CLRK-FR               PIC X(3).                                
           03  T-ACTION                PIC X(4).                                
           03  T-ENT                   PIC X(4).                                
           03  T-MESS                  PIC X(45).                               
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    RESTART INFORMATION                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  MISC-AREA.                                                           
           03  FILLER                  PIC X(4).                                
           03  HI-DATE                 PIC X(4).                                
           03  FILLER                  PIC X(24).                               
      *----------------------------------------------------------------*        
      *                                                                *        
      *        PRINT PARAMTERS COPY BOOK FOR SYS022 TO SYS029          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-PARAMETERS.                                                    
                             COPY 'GPRPRINT' REPLACING                          
                                            ==01  GPRPRINT.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *        TAPE PARAMTERS COPY BOOK FOR SYS011 AND SYS014          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-PARAMETERS.                                                     
                            COPY 'GPRTPARM' REPLACING                           
                                            ==01  GPRTPARM.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *               REPORT ACCUMULATOR COPY BOOK                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-ACCUMULATORS.                                                 
                                COPY 'GPRACCUM' REPLACING                       
                                            ==01  GPRACCUM.== BY ====.          
                                                                                
       PROCEDURE DIVISION USING TAPE-REC                                        
                                MISC-AREA                                       
                                PRINT-PARAMETERS                                
                                TAPE-PARAMETERS                                 
                                REPORT-ACCUMULATORS.                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *     INITIALIZE PRINT LINE AND GET THE MAXIMUM PAGE SIZE        *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE SPACES TO PR-LINE.                                              
           CALL 'ZLINECT' USING PAGE-SIZE.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *     CHANGE THE DATE PASSED IN THE RESTART PARAMETERS FROM      *        
      *     A PACKED DATE TO A CHARACTER FORMATED DATE                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
           CALL 'QDATE' USING QDATE-PARM                                        
                              HI-DATE                                           
                              ST-HIDATE.                                        
      *----------------------------------------------------------------*        
      *                                                                *        
      *     CALL THE PROTRAM THAT WILL SEGMENT THE OUTPUT ON SYS022    *        
      *     AND PRODUCE A POWER LIST CARD TO SET THE FORMS TYPE        *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-STANDARD.                                 
       SUMMARY.                                                                 
           MOVE T-DEPT-TO OF TAPE-REC TO C-DEPT                                 
           MOVE T-CLRK-TO OF TAPE-REC TO C-CLRK.                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *    IF THE PREVIOUS RECORD INFORMATION IS NOT EQUAL TO THE      *        
      *    CURRENT RECORD INFORMATION OR THE LINE COUNT IS GREATER     *        
      *    THAN THE MAXIMUM PAGE SIZE MOVE TO A NEW PAGE AND PRINT     *        
      *    THE TITLES.  THE MOVE THE INFORMATION FROM THE INPUT        *        
      *    RECORD TO THE PRINT BUFFER.                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  PREV-TO IS NOT EQUAL TO CURR-TO                                  
               OR LINE-COUNT IS GREATER THAN PAGE-SIZE THEN                     
               PERFORM TITLE-ROUTINE THRU                                       
                       TITLE-ROUTINE-EXIT.                                      
           MOVE CORRESPONDING TAPE-REC TO PR-LINE.                              
      *----------------------------------------------------------------*        
      *                                                                *        
      *   CHANGE VARIOUS DATE FROM PACKED FORMAT TO CHARACTER FORMAT   *        
      *                                                                *        
      *----------------------------------------------------------------*        
           CALL 'QDATE' USING QDATE-PARM                                        
                              T-ACTION                                          
                              P-ACTION.                                         
           CALL 'QDATE' USING QDATE-PARM                                        
                              T-ENT                                             
                              P-ENT.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *           WRITE OUT THE PRINT LINE ON SYS022                   *        
      *           AND SAVE THE CURRENT RECORD INFORMATION              *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM PRINT-ROUTINE THRU                                           
                   PRINT-ROUTINE-EXIT.                                          
           MOVE CURR-TO TO PREV-TO.                                             
      *----------------------------------------------------------------*        
      *                                                                *        
      *           READ A RECORD FORM THE INPUT FILE                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                TAPE-REC                                        
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
      *----------------------------------------------------------------*        
      *                                                                *        
      *       IF THE RETURN CODE IS NOT ZERO OR THE RECORD TYPE        *        
      *       IS NOT EQUAL TO "R" THE WE ARE FINISHED.  IF THE         *        
      *       RETURN CODE IS ZERO OR THE RECORD TYPE IS "R" THE        *        
      *       WE HAVE MORE RECORD TO PROCESS.                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS                                
               OR T-REC-TYPE IS NOT EQUAL TO 'R' THEN                           
               GO TO END-OF-JOB                                                 
           ELSE                                                                 
               GO TO SUMMARY.                                                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *    IF YOU HAVE GOT THIS FAR YOUR FINISHED WITH THIS PROGRAM    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     WHEN THIS ROUTINE IS PERFORMED THE REPORT ACCUMULATORS     *        
      *     ARE INCREASED AND THE PAGE COUNT IS INCREASED AND ALL      *        
      *     PAGE HEADINGS AND TITLES ARE WRITTEN OUT AND THE LINE      *        
      *     COUNT SET.                                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
       TITLE-ROUTINE.                                                           
           ADD +1 TO ACCUM-REMIND.                                              
           ADD +1 TO PAGE-NUMBER.                                               
           MOVE PAGE-NUMBER TO TITLE1-PAGE-NUMBER.                              
           MOVE '1' TO CC.                                                      
           MOVE TITLE1 TO PR-LINE.                                              
           PERFORM  PRINT-ROUTINE THRU                                          
                    PRINT-ROUTINE-EXIT.                                         
           MOVE TITLE2 TO PR-LINE.                                              
           PERFORM  PRINT-ROUTINE THRU                                          
                    PRINT-ROUTINE-EXIT.                                         
           MOVE TITLE3 TO PR-LINE.                                              
           MOVE SPACES TO CC.                                                   
           PERFORM  PRINT-ROUTINE THRU                                          
                    PRINT-ROUTINE-EXIT.                                         
           MOVE +6 TO LINE-COUNT.                                               
       TITLE-ROUTINE-EXIT.                                                      
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     WHEN THIS ROUTINE IS PERFORMED A RECORD IS WRITTEN OUT     *        
      *     ON SYS022 AND THE PRINT BUFFER CLEARED AND THE CARRIAGE    *        
      *     CONTROL SET TO DOUBLE SPACE.                               *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-ROUTINE.                                                           
           CALL 'DLSWRITE' USING PRINT-SYS034                                   
                                 PRINT-RETURN                                   
                                 PRINT-LINE                                     
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS034-COUNT.                            
           MOVE '0' TO  CC.                                                     
           MOVE SPACES TO PR-LINE.                                              
           ADD +2 TO LINE-COUNT.                                                
       PRINT-ROUTINE-EXIT.                                                      
           EXIT.                                                                
