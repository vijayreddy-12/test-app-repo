       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    VOGPWRA7.                                                 
      *AUTHOR.        F. DAZA.                                                  
      *DATE-WRITTEN.  APR 2005.                                                 
      *DATE-COMPILED.                                                           
      *============================================================*            
      *    WRAPPER FOR VO MASTER AND GIPSY MASTER DATA REQUEST.                 
      *------------------------------------------------------------*            
      *    APR/05 F DAZA      - CREATED                                         
      *    AUG/06 F MUELLER   - RE-STRUCTURED TO HANDLE DUMMY GROUP             
      *                         AND FIX ISSUES WITH READ NEXT W/G               
      *    JUL/08 IBM GR      - UPGRADED IN ECU PROJECT                         
      *    NOV/10 IDMSDB2     - IDMS TO DB2 CONVERSION PROJECT                  
      *                       - CREATED FOR 7-DIGIT GIPSY GROUP NUMBER          
      *    MAY/13 L INBARAJ                                                     
      *       - GROUP NUMBER EXPANSION PROJECT - 7-DIGIT COMPLIANT              
      *------------------------------------------------------------*            
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
                                                                                
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                 PIC X(16) VALUE 'VOGPWRA7 START=>'.         
                                                                                
       01  WS-FIELDS.                                                           
           05  WS-INITIALIZED-SW        PIC X(01)  VALUE 'N'.                   
               88  WS-INITIALIZED       VALUE 'Y'.                              
               88  WS-NOT-INITIALIZED   VALUE 'N'.                              
           05  WS-FILES-OPEN-SW         PIC X(01)  VALUE 'N'.                   
               88  WS-FILES-OPEN        VALUE 'Y'.                              
               88  WS-FILES-NOT-OPEN    VALUE 'N'.                              
           05  WS-VO-RECORD-FLAG        PIC X(01)  VALUE 'N'.                   
               88  WS-VO-REC-FOUND      VALUE 'Y'.                              
               88  WS-VO-REC-NOT-FOUND  VALUE 'N'.                              
           05  WS-GIPSY-RECORD-FLAG     PIC X(01)  VALUE 'N'.                   
               88  WS-GIPSY-REC-FOUND     VALUE 'Y'.                            
               88  WS-GIPSY-REC-NOT-FOUND VALUE 'N'.                            
           05  WS-SOURCE-SYSTEM         PIC X(01)  VALUE ' '.                   
               88  WS-SOURCE-VO         VALUE 'V'.                              
               88  WS-SOURCE-GIPSY      VALUE 'G'.                              
               88  WS-SOURCE-UNKNOWN    VALUE ' '.                              
           05  WS-SELECT-SOURCE         PIC X(01)  VALUE 'N'.                   
               88  WS-SELECT-VO         VALUE 'V'.                              
               88  WS-SELECT-GIPSY      VALUE 'G'.                              
               88  WS-SELECT-NONE       VALUE 'N'.                              
           05  WS-CURR-KEY.                                                     
               10  WS-CURR-GROUP        PIC 9(07).                              
               10  WS-CURR-ACCT         PIC X(05).                              
           05  WS-CURR-VO-KEY.                                                  
               10  WS-CURR-VO-GROUP     PIC 9(07).                              
               10  WS-CURR-VO-ACCT      PIC X(05).                              
           05  WS-CURR-GPSY-KEY.                                                
               10  WS-CURR-GPSY-GROUP   PIC 9(07).                              
               10  WS-CURR-GPSY-ACCT    PIC X(05).                              
           05  WS-PREV-REQUEST          PIC X(50).                              
                                                                                
       01  CALLED-PROGRAMS.                                                     
           05  VODATPR7                 PIC X(08)    VALUE 'VODATPR7'.          
           05  GACBMAS7                 PIC X(08)    VALUE 'GACBMAS7'.          
                                                                                
      *    GACBMAS7 PARAMETERS                                                  
       01  FILLER                       PIC X(19) VALUE                         
           'GACBMAS7-PARAMETERS'.                                               
                                                                                
       01  GACBMAS7-PARAMETER-1.                                                
           03  GACBMAS7-FUNCTION    COMP   PIC S9(4) VALUE ZERO.                
           03  GACBMAS7-SEARCH-ARGUMENT.                                        
               05 GACBMAS7-GROUP    COMP-3 PIC S9(7) VALUE ZERO.                
               05 GACBMAS7-ACCT            PIC X(3)  VALUE LOW-VALUES.          
               05 FILLER            COMP-3 PIC S9(9) VALUE ZERO.                
               05 GACBMAS7-WORK-AREA       PIC X(9)  VALUE LOW-VALUES.          
                                                                                
       01  GACBMAS7-PARAMETER-2.                                                
           03  GACBMAS7-ERROR-CODE         PIC X(3)  VALUE SPACES.              
               88 GACBMAS7-NO-MORE-RECS       VALUE 'R01'.                      
               88 GACBMAS7-DISK-ERROR         VALUE 'R03'.                      
               88 GACBMAS7-INVALID-FUNC-CODE  VALUE 'R09'.                      
               88 GACBMAS7-NORMAL-END         VALUE SPACES.                     
                                                                                
      /                                                                         
       01  FILLER                       PIC X(10)  VALUE '*GMASTER7*'.          
           COPY GMASTER7.                                                       
                                                                                
       01  FILLER                       PIC X(09)  VALUE '*VODPCIO*'.           
       01  VODPCIO.                                                             
           COPY VODPCIO.                                                        
                                                                                
       01  WS-END                   PIC X(16) VALUE '<===END VOGPWRA7'.         
      *---------------------------------------------------------------          
       LINKAGE SECTION.                                                         
       01  VOGPWRA7-PROTOCOL.           COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
       PROCEDURE DIVISION USING VOGPWRA7-PROTOCOL                               
                                VOGPW-DATA-RECORD.                              
                                                                                
       MAINLINE.                                                                
      *============================================================*            
      *  MAINLINE ROUTINE                                                       
      *------------------------------------------------------------*            
           IF WS-NOT-INITIALIZED THEN                                           
              MOVE SPACES TO WS-PREV-REQUEST                                    
              SET WS-INITIALIZED TO TRUE                                        
           END-IF.                                                              
                                                                                
           INITIALIZE VOGPWRAP-OUTPUT.                                          
           MOVE LOW-VALUES TO VOGPW-DATA-RECORD.                                
                                                                                
           SET VGWO-RET-OK TO TRUE.                                             
                                                                                
           IF VGWI-VALID-SOURCE THEN                                            
               PERFORM 1050-VALIDATE-PARMS                                      
               IF VGWO-RET-OK THEN                                              
                  PERFORM 2000-PROCESS-REQUEST                                  
               END-IF                                                           
           ELSE                                                                 
               MOVE 10 TO VGWO-RET-CODE                                         
               MOVE 'INVALID SOURCE SYSTEM REQUESTED'                           
                 TO VGWO-RET-MESSAGE                                            
           END-IF.                                                              
                                                                                
           MOVE VOGPWRAP-INPUT TO WS-PREV-REQUEST.                              
                                                                                
       MAINLINE-EXIT.                                                           
           GOBACK.                                                              
                                                                                
       1050-VALIDATE-PARMS.                                                     
      *============================================================*            
      *  VALIDATE PARMS                                                         
      *------------------------------------------------------------*            
                                                                                
           IF VGWI-OPEN-FILES                                                   
           OR VGWI-CLOSE-FILES                                                  
           OR VGWI-END-READ-NEXT                                                
             CONTINUE                                                           
           ELSE                                                                 
             EVALUATE TRUE                                                      
               WHEN VGWI-GROUP NOT NUMERIC                                      
                    MOVE 11 TO VGWO-RET-CODE                                    
                    MOVE 'INVALID GROUP NUMBER PROVIDED'                        
                      TO VGWO-RET-MESSAGE                                       
                                                                                
               WHEN VGWI-SOURCE-GIPSY                                           
                AND NOT (VGWI-COV-COVDB OR VGWI-COV-ANY)                        
                    MOVE 13 TO VGWO-RET-CODE                                    
                    MOVE 'INVALID COVERAGE TYPE FOR GIPSY'                      
                      TO VGWO-RET-MESSAGE                                       
                                                                                
               WHEN VGWI-SOURCE-GIPSY                                           
                AND NOT (VGWI-LR-GIPSY-EXP OR VGWI-LR-DEFAULT)                  
                    MOVE 14 TO VGWO-RET-CODE                                    
                    MOVE 'UNSUPPORTED LR-NAME FOR GIPSY'                        
                      TO VGWO-RET-MESSAGE                                       
                                                                                
               WHEN NOT (VGWI-COV-COVDB OR VGWI-COV-NONCOV)                     
                AND NOT (VGWI-COV-ANY)                                          
                    MOVE 15 TO VGWO-RET-CODE                                    
                    MOVE 'INVALID COVERAGE TYPE'                                
                      TO VGWO-RET-MESSAGE                                       
                                                                                
               WHEN VGWI-SOURCE-UNKNOWN                                         
                AND NOT (VGWI-LR-GIPSY-EXP OR VGWI-LR-DEFAULT)                  
                    MOVE 17 TO VGWO-RET-CODE                                    
                    MOVE 'INVALID LR-NAME FOR UNKNOWN SOURCE SYSTEM'            
                      TO VGWO-RET-MESSAGE                                       
                                                                                
               WHEN VGWI-READ-NEXT-WG                                           
                AND VGWI-ACCOUNT > SPACES                                       
                    MOVE 18 TO VGWO-RET-CODE                                    
                    MOVE 'READ NEXT W/G DOES NOT SUPPORT ACCOUNT'               
                      TO VGWO-RET-MESSAGE                                       
                                                                                
               WHEN VGWI-READ-NEXT                                              
                AND (VGWI-GROUP > 0 OR VGWI-ACCOUNT > SPACES)                   
                    MOVE 19 TO VGWO-RET-CODE                                    
                    MOVE 'READ NEXT DOES NOT SUPPORT GROUP/ACCOUNT'             
                      TO VGWO-RET-MESSAGE                                       
             END-EVALUATE                                                       
           END-IF.                                                              
                                                                                
       1050-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2000-PROCESS-REQUEST.                                                    
      *============================================================*            
      *  PROCESS REQUEST - OPEN FILES IF NECESSARY                              
      *------------------------------------------------------------*            
                                                                                
           IF  WS-FILES-NOT-OPEN THEN                                           
               PERFORM 2100-OPEN-FILES THRU 2100-EXIT                           
               SET WS-FILES-OPEN TO TRUE                                        
           END-IF.                                                              
                                                                                
           IF VOGPWRAP-INPUT NOT = WS-PREV-REQUEST THEN                         
              INITIALIZE WS-CURR-KEY                                            
                         WS-CURR-VO-KEY                                         
                         WS-CURR-GPSY-KEY                                       
              MOVE VGWI-SOURCE-SYSTEM TO WS-SOURCE-SYSTEM                       
              MOVE LOW-VALUES         TO GACBMAS7-WORK-AREA                     
           END-IF.                                                              
                                                                                
           IF  VGWO-RET-OK THEN                                                 
               EVALUATE TRUE                                                    
                   WHEN VGWI-OPEN-FILES                                         
                        CONTINUE                                                
                   WHEN VGWI-READ-KEYED                                         
                        PERFORM 2110-READ-KEYED    THRU 2110-EXIT               
                                                                                
                   WHEN VGWI-READ-NEXT-WG                                       
                        PERFORM 2120-READ-NEXT-WG  THRU 2120-EXIT               
                                                                                
                   WHEN VGWI-READ-NEXT                                          
                        PERFORM 2130-READ-NEXT     THRU 2130-EXIT               
                                                                                
                   WHEN VGWI-END-READ-NEXT                                      
                        PERFORM 2140-END-READ-NEXT THRU 2140-EXIT               
                                                                                
                   WHEN VGWI-CLOSE-FILES                                        
                        PERFORM 2190-CLOSE-FILES   THRU 2190-EXIT               
                                                                                
                   WHEN OTHER                                                   
                        MOVE 30 TO VGWO-RET-CODE                                
                        MOVE 'INVALID REQUEST!' TO VGWO-RET-MESSAGE             
               END-EVALUATE                                                     
           END-IF.                                                              
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
                                                                                
                                                                                
       2100-OPEN-FILES.                                                         
      *============================================================*            
      * OPEN FILES FOR ALL SOURCE SYSTEMS                                       
      *------------------------------------------------------------*            
      *      GACBMAS7 AUTOMATICALLY OPENS FILE IF FILE IS CLOSED                
      *      VODATPR7 MAY NEED TO BE CALLED                                     
      *------------------------------------------------------------*            
           CONTINUE.                                                            
       2100-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2110-READ-KEYED.                                                         
      *============================================================*            
      * DO A KEY READ. IF SOURCE SYSTEM UNKNOWN TRY VO FIRST                    
      *------------------------------------------------------------*            
                                                                                
           IF WS-SOURCE-VO                                                      
           OR WS-SOURCE-UNKNOWN THEN                                            
              INITIALIZE VODPCIO                                                
              SET  VODPI-READ-KEYED   TO TRUE                                   
              MOVE VGWI-COVERAGE-TYPE TO VODPI-COVERAGE-TYPE                    
              MOVE VGWI-GROUP         TO VODPI-GROUP                            
              MOVE VGWI-ACCOUNT       TO VODPI-ACCOUNT                          
              MOVE VGWI-LR-NAME       TO VODPI-LR-NAME                          
              CALL VODATPR7        USING VODPCIO                                
              IF NOT VODPO-RET-OK THEN                                          
                 IF WS-SOURCE-VO THEN                                           
                    MOVE VODPO-RET-CODE    TO VGWO-RET-CODE                     
                    MOVE VODPO-RET-MESSAGE TO VGWO-RET-MESSAGE                  
                 ELSE                                                           
                    CONTINUE                                                    
                 END-IF                                                         
              ELSE                                                              
                 SET WS-SOURCE-VO     TO TRUE                                   
                 PERFORM 3010-MOVE-VO-DATA THRU 3010-EXIT                       
              END-IF                                                            
           END-IF.                                                              
                                                                                
           IF WS-SOURCE-GIPSY                                                   
           OR WS-SOURCE-UNKNOWN THEN                                            
              MOVE  +2             TO GACBMAS7-FUNCTION                         
              MOVE  VGWI-GROUP     TO GACBMAS7-GROUP                            
              MOVE  VGWI-ACCOUNT   TO GACBMAS7-ACCT                             
              MOVE  LOW-VALUES     TO GACBMAS7-WORK-AREA                        
              PERFORM 3000-CALL-GACBMAS7 THRU 3000-EXIT                         
                                                                                
              IF NOT GACBMAS7-NORMAL-END THEN                                   
                 MOVE 31           TO VGWO-RET-CODE                             
                 STRING GACBMAS7-ERROR-CODE ': RECORD NOT FOUND'                
                    DELIMITED BY SIZE INTO VGWO-RET-MESSAGE                     
              ELSE                                                              
                 PERFORM 3020-MOVE-GIPSY-DATA THRU 3020-EXIT                    
              END-IF                                                            
           END-IF.                                                              
       2110-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2120-READ-NEXT-WG.                                                       
      *============================================================*            
      * DO A READ NEXT WITHIN THE PROVIDED GROUP                                
      *------------------------------------------------------------*            
                                                                                
           SET WS-VO-REC-NOT-FOUND   TO TRUE.                                   
           IF (WS-SOURCE-VO OR WS-SOURCE-UNKNOWN)                               
           AND (WS-CURR-VO-KEY < HIGH-VALUES) THEN                              
                                                                                
              IF WS-CURR-VO-KEY <= WS-CURR-KEY THEN                             
                  INITIALIZE VODPCIO                                            
                  SET  VODPI-READ-NEXT-WG TO TRUE                               
                  MOVE VGWI-COVERAGE-TYPE TO VODPI-COVERAGE-TYPE                
                  MOVE VGWI-GROUP         TO VODPI-GROUP                        
                  MOVE VGWI-ACCOUNT       TO VODPI-ACCOUNT                      
                  MOVE VGWI-LR-NAME       TO VODPI-LR-NAME                      
                                                                                
                  CALL VODATPR7        USING VODPCIO                            
               END-IF                                                           
                                                                                
               IF VODPO-RET-OK THEN                                             
                  SET WS-VO-REC-FOUND     TO TRUE                               
                  MOVE VODPO-GROUP        TO WS-CURR-VO-GROUP                   
                  MOVE VODPO-ACCOUNT      TO WS-CURR-VO-ACCT                    
                  SET WS-SOURCE-VO        TO TRUE                               
               ELSE                                                             
                  MOVE HIGH-VALUES        TO WS-CURR-VO-KEY                     
               END-IF                                                           
           END-IF.                                                              
                                                                                
           SET WS-GIPSY-REC-NOT-FOUND TO TRUE.                                  
           IF  (WS-SOURCE-GIPSY OR WS-SOURCE-UNKNOWN)                           
           AND (VGWI-COV-COVDB  OR VGWI-COV-ANY)                                
           AND (WS-CURR-GPSY-KEY < HIGH-VALUES) THEN                            
                                                                                
              IF  WS-CURR-GPSY-KEY <= WS-CURR-KEY THEN                          
                  MOVE  +3                TO GACBMAS7-FUNCTION                  
                  MOVE  VGWI-GROUP        TO GACBMAS7-GROUP                     
                  MOVE  LOW-VALUES        TO GACBMAS7-ACCT                      
                  PERFORM 3000-CALL-GACBMAS7 THRU 3000-EXIT                     
              END-IF                                                            
                                                                                
              IF GACBMAS7-NORMAL-END THEN                                       
                  SET WS-GIPSY-REC-FOUND  TO TRUE                               
                  MOVE GGIGROUP-NUMBER    TO WS-CURR-GPSY-GROUP                 
                  MOVE GGIACCOUNT         TO WS-CURR-GPSY-ACCT                  
                  SET WS-SOURCE-GIPSY     TO TRUE                               
              ELSE                                                              
                  MOVE HIGH-VALUES        TO WS-CURR-GPSY-KEY                   
              END-IF                                                            
           END-IF.                                                              
                                                                                
           EVALUATE TRUE                                                        
              WHEN WS-VO-REC-FOUND                                              
                 PERFORM 3010-MOVE-VO-DATA THRU 3010-EXIT                       
                 MOVE WS-CURR-VO-KEY         TO WS-CURR-KEY                     
              WHEN WS-GIPSY-REC-FOUND                                           
                 PERFORM 3020-MOVE-GIPSY-DATA THRU 3020-EXIT                    
                 MOVE WS-CURR-GPSY-KEY       TO WS-CURR-KEY                     
              WHEN OTHER                                                        
                 MOVE HIGH-VALUES            TO WS-CURR-KEY                     
                 MOVE 01                     TO VGWO-RET-CODE                   
                 MOVE 'END OF GROUP REACHED'                                    
                                             TO VGWO-RET-MESSAGE                
           END-EVALUATE.                                                        
                                                                                
       2120-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2130-READ-NEXT.                                                          
      *============================================================*            
      * DO A READ NEXT WITHIN THE FILE, MATCH COV TYPE IF SPECIFIED             
      *------------------------------------------------------------*            
                                                                                
           SET WS-VO-REC-NOT-FOUND        TO TRUE.                              
           IF (VGWI-SOURCE-VO OR VGWI-SOURCE-UNKNOWN)                           
           AND (WS-CURR-VO-KEY < HIGH-VALUES) THEN                              
                                                                                
              IF WS-CURR-VO-KEY <= WS-CURR-KEY THEN                             
                  INITIALIZE VODPCIO                                            
                  SET  VODPI-READ-NEXT    TO TRUE                               
                  MOVE VGWI-COVERAGE-TYPE TO VODPI-COVERAGE-TYPE                
                  MOVE VGWI-GROUP         TO VODPI-GROUP                        
                  MOVE VGWI-ACCOUNT       TO VODPI-ACCOUNT                      
                  MOVE VGWI-LR-NAME       TO VODPI-LR-NAME                      
                  CALL VODATPR7        USING VODPCIO                            
              END-IF                                                            
                                                                                
              IF VODPO-RET-OK THEN                                              
                  SET WS-VO-REC-FOUND     TO TRUE                               
                  MOVE VODPO-GROUP        TO WS-CURR-VO-GROUP                   
                  MOVE VODPO-ACCOUNT      TO WS-CURR-VO-ACCT                    
              ELSE                                                              
                  MOVE HIGH-VALUES        TO WS-CURR-VO-KEY                     
              END-IF                                                            
           END-IF.                                                              
                                                                                
           SET WS-GIPSY-REC-NOT-FOUND     TO TRUE.                              
           IF  (VGWI-SOURCE-GIPSY OR VGWI-SOURCE-UNKNOWN)                       
           AND (VGWI-COV-COVDB    OR VGWI-COV-ANY)                              
           AND (WS-CURR-GPSY-KEY < HIGH-VALUES) THEN                            
              IF  WS-CURR-GPSY-KEY <= WS-CURR-KEY                               
                  PERFORM 2135-READ-NEXT-GIPSY THRU 2135-EXIT                   
              END-IF                                                            
              IF GACBMAS7-NORMAL-END THEN                                       
                  SET WS-GIPSY-REC-FOUND  TO TRUE                               
                  MOVE GGIGROUP-NUMBER    TO WS-CURR-GPSY-GROUP                 
                  MOVE GGIACCOUNT         TO WS-CURR-GPSY-ACCT                  
              ELSE                                                              
                  MOVE HIGH-VALUES        TO WS-CURR-GPSY-KEY                   
              END-IF                                                            
           END-IF.                                                              
                                                                                
           EVALUATE TRUE                                                        
              WHEN WS-VO-REC-FOUND AND WS-GIPSY-REC-FOUND                       
                 IF VODPO-GROUP <= GGIGROUP-NUMBER THEN                         
                    SET WS-SELECT-VO      TO TRUE                               
                    IF VODPO-GROUP = GGIGROUP-NUMBER THEN                       
                        PERFORM 2131-SKIP-GROUP-IN-GIPSY THRU 2131-EXIT         
                    END-IF                                                      
                 ELSE                                                           
                    SET WS-SELECT-GIPSY   TO TRUE                               
                 END-IF                                                         
              WHEN WS-VO-REC-FOUND                                              
                 SET WS-SELECT-VO         TO TRUE                               
              WHEN WS-GIPSY-REC-FOUND                                           
                 SET WS-SELECT-GIPSY      TO TRUE                               
              WHEN OTHER                                                        
                 SET WS-SELECT-NONE       TO TRUE                               
           END-EVALUATE.                                                        
                                                                                
           EVALUATE TRUE                                                        
              WHEN WS-SELECT-VO                                                 
                 PERFORM 3010-MOVE-VO-DATA THRU 3010-EXIT                       
                 MOVE WS-CURR-VO-KEY       TO WS-CURR-KEY                       
              WHEN WS-SELECT-GIPSY                                              
                 PERFORM 3020-MOVE-GIPSY-DATA THRU 3020-EXIT                    
                 MOVE WS-CURR-GPSY-KEY     TO WS-CURR-KEY                       
              WHEN OTHER                                                        
                 MOVE HIGH-VALUES          TO WS-CURR-KEY                       
                 MOVE 01                   TO VGWO-RET-CODE                     
                 MOVE 'EOF: NO FURTHER RECORDS ON READ NEXT'                    
                                           TO VGWO-RET-MESSAGE                  
           END-EVALUATE.                                                        
                                                                                
       2130-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2131-SKIP-GROUP-IN-GIPSY.                                                
                                                                                
           PERFORM UNTIL WS-CURR-GPSY-KEY   = HIGH-VALUES                       
                      OR WS-CURR-GPSY-GROUP > WS-CURR-VO-GROUP                  
                                                                                
              PERFORM 2135-READ-NEXT-GIPSY THRU 2135-EXIT                       
                                                                                
              IF GACBMAS7-NORMAL-END THEN                                       
                  MOVE GGIGROUP-NUMBER TO WS-CURR-GPSY-GROUP                    
                  MOVE GGIACCOUNT      TO WS-CURR-GPSY-ACCT                     
              ELSE                                                              
                  MOVE HIGH-VALUES     TO WS-CURR-GPSY-KEY                      
              END-IF                                                            
                                                                                
           END-PERFORM.                                                         
                                                                                
       2131-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2135-READ-NEXT-GIPSY.                                                    
           MOVE  +6                TO GACBMAS7-FUNCTION.                        
           MOVE  ZEROES            TO GACBMAS7-GROUP.                           
           MOVE  SPACES            TO GACBMAS7-ACCT.                            
           PERFORM 3000-CALL-GACBMAS7 THRU 3000-EXIT.                           
                                                                                
       2135-EXIT.                                                               
           EXIT.                                                                
                                                                                
                                                                                
       2140-END-READ-NEXT.                                                      
      *============================================================*            
      *  CLOSE GIPSY MASTER AND DO END READ ON VO MASTER                        
      *------------------------------------------------------------*            
                                                                                
           MOVE  +1                TO GACBMAS7-FUNCTION.                        
           MOVE  ZEROES            TO GACBMAS7-GROUP.                           
           MOVE  SPACES            TO GACBMAS7-ACCT.                            
           PERFORM 3000-CALL-GACBMAS7 THRU 3000-EXIT.                           
                                                                                
           INITIALIZE VODPCIO.                                                  
           SET  VODPI-END-READ-NEXT TO TRUE.                                    
           CALL VODATPR7         USING VODPCIO.                                 
                                                                                
           IF (VODPO-RET-OK AND GACBMAS7-NORMAL-END) THEN                       
               SET VGWO-RET-OK   TO TRUE                                        
           ELSE                                                                 
               MOVE '09' TO VGWO-RET-CODE                                       
               STRING VODPO-RET-CODE '-' GACBMAS7-ERROR-CODE                    
                      ': ERROR ON END READ NEXT'                                
                 DELIMITED BY SIZE INTO VGWO-RET-MESSAGE                        
           END-IF.                                                              
           SET WS-FILES-NOT-OPEN TO TRUE.                                       
                                                                                
       2140-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2190-CLOSE-FILES.                                                        
      *============================================================*            
      *  CLOSE GIPSY MASTER AND VO MASTER FILES                                 
      *------------------------------------------------------------*            
                                                                                
           MOVE  +1              TO GACBMAS7-FUNCTION.                          
           MOVE  ZEROES          TO GACBMAS7-GROUP.                             
           MOVE  SPACES          TO GACBMAS7-ACCT.                              
           PERFORM 3000-CALL-GACBMAS7 THRU 3000-EXIT.                           
                                                                                
           INITIALIZE VODPCIO.                                                  
           SET  VODPI-CLOSE-FILE TO TRUE.                                       
           CALL VODATPR7      USING VODPCIO.                                    
                                                                                
           IF (VODPO-RET-OK AND GACBMAS7-NORMAL-END) THEN                       
               SET VGWO-RET-OK   TO TRUE                                        
           ELSE                                                                 
               MOVE '09'         TO VGWO-RET-CODE                               
               STRING VODPO-RET-CODE '-' GACBMAS7-ERROR-CODE                    
                      ': ERROR CLOSING FILES'                                   
                 DELIMITED BY SIZE INTO VGWO-RET-MESSAGE                        
           END-IF.                                                              
                                                                                
           SET WS-FILES-NOT-OPEN TO TRUE.                                       
       2190-EXIT.                                                               
           EXIT.                                                                
                                                                                
       3000-CALL-GACBMAS7.                                                      
           MOVE  SPACES            TO GACBMAS7-ERROR-CODE.                      
           MOVE  LOW-VALUES        TO GMASTER7.                                 
                                                                                
           CALL  GACBMAS7       USING GACBMAS7-PARAMETER-1                      
                                      GACBMAS7-PARAMETER-2                      
                                      GMASTER7.                                 
                                                                                
       3000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       3010-MOVE-VO-DATA.                                                       
      *============================================================*            
      *  MOVE VO DATA TO AREA IN LINKAGE SECTION                                
      *------------------------------------------------------------*            
           SET   VGWO-RET-OK         TO TRUE.                                   
           MOVE  VODPO-GROUP         TO VGWO-GROUP.                             
           MOVE  VODPO-ACCOUNT       TO VGWO-ACCOUNT.                           
           MOVE  'V'                 TO VGWO-SOURCE-SYSTEM.                     
           MOVE  VODPO-COVERAGE-TYPE TO VGWO-COVERAGE-TYPE.                     
           MOVE  VODPO-MAPPED-RECORD TO VOGPW-DATA-RECORD.                      
       3010-EXIT.                                                               
           EXIT.                                                                
                                                                                
       3020-MOVE-GIPSY-DATA.                                                    
      *============================================================*            
      *  MOVE GIPSY DATA TO AREA IN LINKAGE SECTION                             
      *------------------------------------------------------------*            
           SET   VGWO-RET-OK         TO TRUE.                                   
           MOVE  GGIGROUP-NUMBER     TO VGWO-GROUP.                             
           MOVE  GGIACCOUNT          TO VGWO-ACCOUNT.                           
           MOVE  'G'                 TO VGWO-SOURCE-SYSTEM.                     
           MOVE  'COV'               TO VGWO-COVERAGE-TYPE.                     
           MOVE  GMASTER7            TO VOGPW-DATA-RECORD.                      
       3020-EXIT.                                                               
           EXIT.                                                                
