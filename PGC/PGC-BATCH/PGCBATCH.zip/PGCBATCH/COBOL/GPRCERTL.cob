       CBL DATA(24)                                                             
       ID DIVISION.                                                             
       PROGRAM-ID.   GPRCERTL.                                                  
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      *REMARKS.  PRINTS GROUP CERTIFICATE HOLDERS LISTING.                      
      *****************************************************************         
      *                         HISTORY                               *         
      *****************************************************************         
      *                                                               *         
      * JUN 86 - TVN.                                                 *         
      *        - REVISED FOR DIVISIONAL BILLING JUNE 86. TVN.         *         
      *                                                               *         
      * DEC 88 - BD.                                                  *         
      *        - REMOVED GPRSGMNT CALL AND REPLACED WITH DLSWITE      *         
      *          SYS064 (FRENCH CERTS.) AND SYS065 (ENGLISH CERTS.)   *         
      *                                                               *         
      *****************************************************************         
      *                   GIPSY-REL-1  START                          *         
      *****************************************************************         
      * AUG 89 M PRANGE                                               *         
      *        - ALIGN SOME TITLE LINES CORRECTLY.                    *         
      *        - ADD PROD-CODE AND OFFICE TO INPUT AND ERROR OUTPUT   *         
      *        - CHANGES MADE FOR NEW ROUNDING METHOD.                *         
      *        - INCREASED COVERAGE COLUMNS FROM 7 TO 9.              *         
      *                                                               *         
      *  SEP/89 M DRURY    -CHANGED THE ERROR FILE (SYS011) TO A      *         
      *                      COPY BOOK.                               *         
      *                    - ADD A CLOSE-FLAG IND TO ENSURE THAT      *         
      *                      DSL064 AND DLS065 ARE CLOSED             *         
      *                       (SEE PRINTAL FOR ALL THE DETAILS)       *         
      * DEC/90 M PRANGE                                               *         
      *      - INCREASED "SAVE-LINE" FROM 132 TO 165 TO FIX LINE      *         
      *        TRUNCATION PROBLEMS.                                   *         
      *                                                               *         
      * APR/92 M PRANGE                                               *         
      *      - INCREASE 'OUT-PAGE' FIELD SIZE FROM 2 DIGITS TO 3.     *         
      *      - CHANGE 'EDIT-VOL' FIELD FROM ZZ,ZZZ,ZZZ TO ZZZZZ,ZZZ   *         
      *        TO GET AN EXTRA SIGNIFICANT DIGIT. THERE WAS NO ROOM   *         
      *        ON THE REPORT TO EXPAND THIS FIELD.                    *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      *****************************************************************         
      *                   GIPSY-REL-1  END                            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77   FILLER                           PIC X(50)   VALUE                  
            '***** START OF WORKING STORAGE FOR GPRCERTL *****'.                
       77  QDATE-PARM                              PIC XX.                      
       77  DUMP-PARTITION          VALUE '2'       PIC X.                       
       77  ST-DATE                                 PIC X(9).                    
       77  LINE-CT     COMP SYNC   VALUE +0        PIC S9(4).                   
       77  MY-LINE-CT  COMP SYNC   VALUE +0        PIC S9(4).                   
       77  START-SW                                PIC X.                       
       77  FOF-SUB     COMP                        PIC S9(4).                   
                                                                                
       01  MISCELLANEOUS-WORK-AREA.                                             
           03  LANG-SUB                            PIC S9(3) COMP-3.            
           03  GGICOV-SUB                          PIC S9(3) COMP-3.            
           03  GGICOL-SUB                          PIC S9(3) COMP-3.            
           03  GGICOL-CTR                          PIC S9(3) COMP-3.            
           03  GGI-TITLE-SUB                       PIC S9(3) COMP-3.            
           03  CHECK-SUB                           PIC S9(3) COMP-3.            
           03  PREM-SUB                            PIC S9(3) COMP-3.            
           03  COL-SUB                             PIC S9(3) COMP-3.            
           03  TITLE-SUB                           PIC S9(3) COMP-3.            
           03  STATS-SUB                           PIC S9(3) COMP-3.            
           03  CERT-SUB                            PIC S9(3) COMP-3.            
           03  WK-BIRTHDATE.                                                    
               05  FILLER                          PIC XX.                      
               05  WK-MMMYY                        PIC X(7).                    
           03  DEPENDENT-IND.                                                   
               05  DEP-LIFE-IND                    PIC X.                       
               05  DEP-EHC-IND                     PIC X.                       
               05  DEP-DEN-IND                     PIC X.                       
           03  EDIT-GRP-OFFICE                     PIC X(5).                    
           03  EDIT-GRP-OFF REDEFINES EDIT-GRP-OFFICE.                          
               05  EDIT-GRP-OFF-1                  PIC X.                       
               05  EDIT-GRP-OFF-2                  PIC X.                       
               05  EDIT-GRP-OFF-3                  PIC X.                       
               05  EDIT-GRP-OFF-4                  PIC X.                       
               05  EDIT-GRP-OFF-5                  PIC X.                       
           03  STORE-OFFICE-NM-NUM.                                             
               05  STORE-OFF-NM-NUM OCCURS 30 TIMES                             
                                    INDEXED BY OFFICE-SUB  PIC X.               
           03  EDIT-VOL                            PIC ZZZZZ,ZZZ.               
           03  EDIT-PREM                           PIC ZZ,ZZZ.ZZ.               
           03  PREM-ROUNDED               COMP-3   PIC S9(5)V9(2).              
           03  EHC-CODE-MIN               COMP-3   PIC S9(3).                   
           03  EHC-CODE-MAX               COMP-3   PIC S9(3).                   
           03  DEN-CODE-MIN               COMP-3   PIC S9(3).                   
           03  DEN-CODE-MAX               COMP-3   PIC S9(3).                   
           03  SAVE-LINE                           PIC X(165).                  
           03  ACCUM-PAGE-KEY.                                                  
               05  FILLER                       PIC X.                          
               05  NEW-PAGE-FORM                PIC X.                          
GNE            05  NEW-PAGE-GROUP               PIC S9(7) COMP-3.               
               05  NEW-PAGE-ACCT                PIC XXX.                        
                                                                                
       01  GNUMTABL-PARMS.                                                      
           03  GNUM-TABLE-NO           COMP     PIC S9(4) VALUE +22.            
           03  GNUM-EHC-KEY                     PIC X(3)  VALUE '019'.          
           03  GNUM-DEN-KEY                     PIC X(3)  VALUE '099'.          
           03  GNUM-RETURN.                                                     
               05  FILLER                       PIC X(8).                       
               05  COV-CODE-MIN                 PIC 999.                        
               05  FILLER                       PIC X(4).                       
               05  COV-CODE-MAX                 PIC 999.                        
                                                                                
      *01  GMGENTR.                                                             
           COPY GMGENTR7.                                                       
                                                                                
      *01  GMSTSTR.                                                             
           COPY GMSTSTR.                                                        
                                                                                
      *01  GMBILTR.                                                             
           COPY GMBILTR.                                                        
                                                                                
GNE    01  LT-GRPACCT.                                                          
GNE        05   LT-GROUP          PIC S9(07) COMP-3.                            
GNE        05   LT-ACCT           PIC  X(03).                                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *       GIPSY MASTER VSAM FILE INFORMATION                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
GNE    01  MASTER-VSAM-000.                                                     
           05 WS-TRAILER-000-IDENT          PIC X(3).                           
           05 WS-TRAILER-000-REC            PIC X(16280).                       
                                                                                
GNE    01  MASTER-VSAM-010.                                                     
           05 WS-TRAILER-010-IDENT          PIC X(3).                           
           05 WS-TRAILER-010-REC            PIC X(16280).                       
                                                                                
GNE    01  MASTER-VSAM-030.                                                     
           05 WS-TRAILER-030-IDENT          PIC X(3).                           
           05 WS-TRAILER-030-REC            PIC X(16280).                       
                                                                                
       01  NAME-EXPAND-AREA.                                                    
           03  EXPANDED-LINES      OCCURS  6.                                   
               05  NAME-LINE                       PIC X(30).                   
               05  NAME-DELIMETER                  PIC X.                       
                                                                                
      ******************************************************************        
      *    TABLE AREA STORE                                                     
      *    EACH COVERAGE CODE IN GENERAL INFORMATION TRLR HAS THE               
      *    ASSOCIATED COLUMNS IN WHICH IT IS REQUIRED.                          
      ******************************************************************        
       01  TITLE-TABLE-BY-COV-CODE.                                             
           03  TITLE-NUM-CODES                     PIC S9(3) COMP-3.            
           03  TITLE-COV-CODES OCCURS 38 TIMES.                                 
               05  TITLE-COV-CODE                  PIC S9(3) COMP-3.            
               05  NUM-COLS                        PIC S9(1) COMP-3.            
               05  COLS-OF-COV-CODE OCCURS 9 TIMES PIC S9(1) COMP-3.            
                                                                                
      ******************************************************************        
      *    ACCUMULATORS FOR 1) DETAIL LINES                                     
      *                     2) GRP/ACCOUNT/FORM TOTAL LINES                     
      ******************************************************************        
       01  ACCUMULATORS.                                                        
           03  COLUMN-ACCUM-DETAIL    COMP-3.                                   
               05  COL-ACCUM OCCURS 10 TIMES       PIC S9(8)V999.               
           03  COL-ACCUM-R REDEFINES COLUMN-ACCUM-DETAIL.                       
               05  FILLER             COMP-3       PIC S9(8)V999.               
               05  COL-ACCUM-TO-ZERO               PIC X(54).                   
           03  GRP-ACCT-COLUMN-ACCUM COMP-3.                                    
               05  GRP-ACCT-COL-ACCUM OCCURS 10 TIMES  PIC S9(8)V999.           
           03  GRP-ACCT-COL-ACCUM-R REDEFINES GRP-ACCT-COLUMN-ACCUM.            
               05  FILLER             COMP-3       PIC S9(8)V999.               
               05  GRP-ACCT-COL-ACCUM-TO-ZERO      PIC X(54).                   
           03  PAGE-NO                             PIC S999 COMP-3.             
                                                                                
       01  PREV-KEY.                                                            
           03  PREV-SEG1.                                                       
               05  P-REC-TYPE                      PIC X.                       
               05  P-FORM                          PIC X.                       
           03  PREV-PRODUCT                        PIC X.                       
           03  PREV-GRP-OFF                        PIC X(5).                    
GNE        03  PREV-GROUP      COMP-3              PIC S9(7).                   
           03  PREV-ACCT                           PIC XXX.                     
                                                                                
      *01  ERR-REC.                                                             
      *    03  E-REC-TYPE      VALUE '5'           PIC X.                       
      *    03  E-GROUP                   COMP-3    PIC S9(5).                   
      *    03  E-ACCT                              PIC XXX.                     
      *    03  FILLER                              PIC X.                       
      *    03  E-CERT          VALUE +0  COMP-3    PIC S9(9).                   
      *    03  E-CODE                              PIC XXX.                     
      *    03  E-COUNTRY                           PIC X.                       
      *    03  FILLER          VALUE SPACES        PIC X(4).                    
      *                                                                         
      *   CHANGED ERROR FILE TO A COPY BOOK   MARCUS.                           
      *                                                                         
GNE        COPY  GERRREC7.                                                      
                                                                                
       01  STORE-RESTART.                                                       
           03  SAVE-RESTART.                                                    
               05  SAVE-RESTART-1.                                              
                   07  SR-REC-TYPE                     PIC X.                   
                   07  SR-FORM                         PIC X.                   
GNE            05  SR-GROUP        COMP-3              PIC S9(7).               
               05  SR-ACCT                             PIC XXX.                 
GNE        03  FILLER                                  PIC  X.                  
                                                                                
      ******************************************************************        
      *    PARAMETERS USED BY WTL TO DISPLAY ERROR MESSAGES                     
      ******************************************************************        
                                                                                
       01  WTL-PARAMETERS.                                                      
           03  WTL-FLAG     VALUE 'B'          PIC X.                           
           03  WTL-REPLY-CODE   VALUE 'NO '    PIC X(3).                        
           03  WTL-REPLY-AREA                  PIC X(120).                      
           03  WTL-MESSAGE-AREA1.                                               
               05  FILLER  COMP-3   VALUE +38  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE1.                                                
                   07  FILLER                  PIC X(37) VALUE                  
                   '*** PHASE - GPRINTAL, MODULE GPRCERTL'.                     
           03  WTL-MESSAGE-AREA2.                                               
               05  FILLER  COMP-3   VALUE +33  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE2.                                                
                   07  FILLER                  PIC X(32) VALUE                  
                   '*** MASTER RECORD DOES NOT EXIST'.                          
           03  WTL-MESSAGE-AREA3.                                               
               05  FILLER  COMP-3   VALUE +23  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE3.                                                
                   07  FILLER                  PIC X(19) VALUE                  
                   '*** RETURN CODE IS '.                                       
                   07  WTL-RET-CODE            PIC XXX.                         
           03  WTL-MESSAGE-AREA4.                                               
               05  FILLER  COMP-3   VALUE +28  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE4.                                                
                   07  FILLER                  PIC X(17) VALUE                  
                   '*** GROUP/ACCT -'.                                          
GNE                07  WTL-GROUP               PIC 9(7).                        
                   07  FILLER                  PIC X VALUE '/'.                 
                   07  WTL-ACCT                PIC XXX.                         
                   07  FILLER                  PIC X VALUE '/'.                 
           03  WTL-MESSAGE-AREA5.                                               
               05  FILLER  COMP-3   VALUE +41  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE5.                                                
                   07  FILLER                  PIC X(40) VALUE                  
                   '*** OPERATOR ACTION : CALL GROUP SUPPORT'.                  
           03  WTL-MESSAGE-AREA6.                                               
               05  FILLER  COMP-3   VALUE +38  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE6.                                                
                   07  FILLER                  PIC X(37) VALUE                  
                   '*** DO NOT CONTINUE WITH GROUP ADMIN.'.                     
           03  WTL-MESSAGE-AREA7.                                               
               05  FILLER  COMP-3   VALUE +21  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE7.                                                
                   07  FILLER                  PIC X(20) VALUE                  
                   '*** REPLY: HIT ENTER'.                                      
           03  WTL-MESSAGE-AREA8.                                               
               05  FILLER  COMP-3   VALUE +24  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE8.                                                
                   07  FILLER                  PIC X(23) VALUE                  
                   '*** PROGRAM IS ABENDING'.                                   
                                                                                
      ******************************************************************        
      *    FIELD OFFICE FILE PARMS                                              
      ******************************************************************        
       01  FIELD-OFFICE-FILE-PARMS.                                             
           05  FOF-PARM1.                                                       
               10  FOF-DDNAME           PIC X(7) VALUE 'VSDSI31'.               
               10  FOF-ACCTYPE          PIC X(5) VALUE 'KEYED'.                 
               10  FOF-RECTYPE          PIC X    VALUE 'V'.                     
               10  FOF-FUNCTION         PIC X(6) VALUE 'GETRAN'.                
               10  FOF-ERRCODE          PIC X(5).                               
               10  FOF-READCT           PIC S9(7) COMP-3 VALUE +0.              
               10  FOF-WRITECT          PIC S9(7) COMP-3 VALUE +0.              
               10  FOF-UPDATECT         PIC S9(7) COMP-3 VALUE +0.              
               10  FOF-DELETCT          PIC S9(7) COMP-3 VALUE +0.              
               10  FOF-RECLGTH          PIC S9(4) COMP.                         
           05  FOF-PARM2.                                                       
               10  FOF-GRP-OFFICE            PIC X(5).                          
                                                                                
      *01  FIELD-OFFICE-FILE.                                                   
           COPY FDOFFILE.                                                       
       01  FILLER REDEFINES FIELD-OFFICE-FILE.                                  
           05  FILLER                        PIC X(57).                         
           05  FOF-BN-CHECK.                                                    
               10  FOF-BNCK OCCURS 25 TIMES  PIC X.                             
           05  FILLER                        PIC X(529).                        
                                                                                
       01  LIT-AREAS.                                                           
           03  DASH-LINE                    PIC X(151) VALUE ALL '-'.           
           03  REPORT-LIT-ENGLISH-FRENCH.                                       
               05  FILLER                   PIC X(40) VALUE                     
               'LISTING OF GROUP CERTIFICATE HOLDERS FOR'.                      
               05  FILLER                   PIC X(40) VALUE                     
               '   LISTE DES DETENTEURS DE CERTIFICAT'.                         
               05  FILLER                   PIC X(6)  VALUE 'NUMBER'.           
               05  FILLER                   PIC X(6)  VALUE 'NUMERO'.           
               05  FILLER                   PIC X(6)  VALUE 'OFFICE'.           
               05  FILLER                   PIC X(6)  VALUE 'BUREAU'.           
               05  FILLER                   PIC X(13) VALUE                     
                   'DATE PREPARED'.                                             
               05  FILLER                   PIC X(13) VALUE                     
                   '   PREPARE LE'.                                             
               05  FILLER                   PIC X(4)  VALUE 'NAME'.             
               05  FILLER                   PIC X(4)  VALUE 'NOM '.             
               05  FILLER                   PIC X(5)  VALUE 'BIRTH'.            
               05  FILLER                   PIC X(5)  VALUE 'NE(E)'.            
               05  FILLER                   PIC X(5)  VALUE ' DATE'.            
               05  FILLER                   PIC X(5)  VALUE ' LE  '.            
               05  FILLER                   PIC X(9)  VALUE '     CERT'.        
               05  FILLER                   PIC X(9)  VALUE '   NO. DU'.        
               05  FILLER                   PIC X(10) VALUE                     
                   '    NUMBER'.                                                
               05  FILLER                   PIC X(10) VALUE                     
                   '     CERT.'.                                                
               05  FILLER                   PIC X(2)  VALUE 'CL'.               
               05  FILLER                   PIC X(2)  VALUE 'CT'.               
               05  FILLER                   PIC X(7)  VALUE '  DEP'.            
               05  FILLER                   PIC X(7)  VALUE 'P.A.CH.'.          
               05  FILLER                   PIC X     VALUE 'L'.                
               05  FILLER                   PIC X     VALUE 'V'.                
               05  FILLER                   PIC X     VALUE 'H'.                
               05  FILLER                   PIC X     VALUE 'M'.                
               05  FILLER                   PIC X     VALUE 'D'.                
               05  FILLER                   PIC X     VALUE 'D'.                
               05  FILLER                   PIC X(9)  VALUE '    TOTAL'.        
               05  FILLER                   PIC X(9)  VALUE '    PRIME'.        
               05  FILLER                   PIC X(9)  VALUE '  PREMIUM'.        
               05  FILLER                   PIC X(9)  VALUE '   TOTALE'.        
               05  FILLER                   PIC X(5)  VALUE 'TOTAL'.            
               05  FILLER                   PIC X(5)  VALUE 'TOTAL'.            
               05  FILLER                   PIC X(21) VALUE                     
                   '     LIVES INSURED = '.                                     
               05  FILLER                   PIC X(21) VALUE                     
                   'PERSONNES ASSUREES = '.                                     
               05  EXPLAIN-ABBREV-LIT-ENG-1.                                    
                   07  FILLER               PIC X(48) VALUE                     
                       'X INDICATES DEPENDENT COVERAGE FOR'.                    
               05  EXPLAIN-ABREV-LIT-FR-1.                                      
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X     VALUE 'X'.                
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(45) VALUE                     
                       ' DESIGNE LES PERSONNES A CHARGE COUVERTES PAR'.         
               05  EXPLAIN-ABREV-LIT-ENG-2.                                     
                   07  FILLER               PIC X(26) VALUE                     
                       'L - LIFE'.                                              
               05  EXPLAIN-ABREV-LIT-FR-2.                                      
                   07  FILLER               PIC X(5)  VALUE 'V - L'.            
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(20) VALUE                     
                       'ASSURANCE SUR LA VIE'.                                  
               05  EXPLAIN-ABREV-LIT-ENG-3.                                     
                   07  FILLER               PIC X(46) VALUE                     
                       'H - EXTENDED HEALTH CARE'.                              
               05  EXPLAIN-ABREV-LIT-FR-3.                                      
                   07  FILLER               PIC X(5)  VALUE 'M - L'.            
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(40) VALUE                     
                       'ASSURANCE COMPL. DES FRAIS DE SOINS MED.'.              
               05  EXPLAIN-ABREV-LIT-ENG-4.                                     
                   07  FILLER               PIC X(35) VALUE                     
                       'D - DENTAL'.                                            
               05  EXPLAIN-ABREV-LIT-FR-4.                                      
                   07  FILLER               PIC X(5)  VALUE 'D - L'.            
                   07  FILLER               PIC X     VALUE QUOTE.              
                   07  FILLER               PIC X(29) VALUE                     
                       'ASSURANCE DES FRAIS DENTAIRES'.                         
           03  REPORT-LIT-ENG-FR-REDEFINES REDEFINES                            
                                           REPORT-LIT-ENGLISH-FRENCH.           
               05  REPORT-TITLE      OCCURS 2 TIMES PIC X(40).                  
               05  GROUP-NO-LIT      OCCURS 2 TIMES PIC X(6).                   
               05  GROUP-OFF-LIT     OCCURS 2 TIMES PIC X(6).                   
               05  DATE-PREP-LIT     OCCURS 2 TIMES PIC X(13).                  
               05  NAME-LIT          OCCURS 2 TIMES PIC X(4).                   
               05  BIRTH-LIT1        OCCURS 2 TIMES PIC X(5).                   
               05  BIRTH-LIT2        OCCURS 2 TIMES PIC X(5).                   
               05  CERT-LIT-LINE1    OCCURS 2 TIMES PIC X(9).                   
               05  CERT-LIT-LINE2    OCCURS 2 TIMES PIC X(10).                  
               05  CLASS-LIT         OCCURS 2 TIMES PIC X(2).                   
               05  DEPENDENT-LIT     OCCURS 2 TIMES PIC X(7).                   
               05  DEP-LIT-LIFE      OCCURS 2 TIMES PIC X.                      
               05  DEP-LIT-EHC       OCCURS 2 TIMES PIC X.                      
               05  DEP-LIT-DEN       OCCURS 2 TIMES PIC X.                      
               05  TOTAL-COL-LINE1   OCCURS 2 TIMES PIC X(9).                   
               05  TOTAL-COL-LINE2   OCCURS 2 TIMES PIC X(9).                   
               05  TOTAL-GROUP-SUM   OCCURS 2 TIMES PIC X(5).                   
               05  LIVES-INSURED-LIT OCCURS 2 TIMES PIC X(21).                  
               05  EXPL-ABREV-LIT-1  OCCURS 2 TIMES PIC X(48).                  
               05  EXPL-ABREV-LIT-2  OCCURS 2 TIMES PIC X(26).                  
               05  EXPL-ABREV-LIT-3  OCCURS 2 TIMES PIC X(46).                  
               05  EXPL-ABREV-LIT-4  OCCURS 2 TIMES PIC X(35).                  
                                                                                
      ******************************************************************        
      *    STORE THE COLUMN HEADINGS LINES, SO THAT THEY DO NOT HAVE TO         
      *    BE REBUILT FOR EACH PAGE.                                            
      ******************************************************************        
       01  TITLE-LINES.                                                         
           03  TITLE-LINE1.                                                     
               05  FILLER                    PIC X(27) VALUE SPACES.            
               05  T1-BIRTH-LIT1             PIC X(8).                          
               05  T1-CERT-LIT1              PIC X(9).                          
               05  FILLER                    PIC X(3)  VALUE SPACES.            
               05  T1-DEP-LIT                PIC X(7).                          
               05  FILLER                    PIC X(1)  VALUE SPACES.            
               05  T1-COL-LIT1 OCCURS 10 TIMES PIC X(10).                       
           03  TITLE-LINE2.                                                     
               05  FILLER                    PIC X     VALUE SPACES.            
               05  T2-NAME-LIT               PIC X(26).                         
               05  T2-BIRTH-LIT2             PIC X(7).                          
               05  T2-CERT-LIT2              PIC X(11).                         
               05  T2-CLASS-LIT              PIC X(3).                          
               05  T2-DEP-LIFE-LIT           PIC XX.                            
               05  T2-DEP-EHC-LIT            PIC XX.                            
               05  T2-DEP-DEN-LIT            PIC XX.                            
               05  FILLER                    PIC X(1)  VALUE SPACES.            
               05  T2-COL-LIT2 OCCURS 10 TIMES PIC X(10).                       
                                                                                
       01  PRINT-LINE.                                                          
           03  CC                            PIC X.                             
           03  PR-LINE1.                                                        
               05  FILLER                    PIC X(104).                        
               05  PAGE-LIT                  PIC X(5).                          
               05  OUT-PAGE                  PIC ZZ9.                           
               05  FILLER                    PIC X(52).                         
           03  PR-LINE2 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(41).                         
               05  P-TITLE                   PIC X(40).                         
           03  PR-LINE3 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(46).                         
               05  P-GROUP-NAME              PIC X(30).                         
           03  PR-LINE4 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(24).                         
               05  P-GRP-NUM-OFF-LIT         PIC X(8).                          
               05  P-GRP-OFFICE              PIC X(31).                         
               05  P-GRP-ACCT REDEFINES P-GRP-OFFICE.                           
GNE                07  P-GROUP               PIC 9(7).                          
                   07  FILLER                PIC X.                             
                   07  P-ACCT                PIC XXX.                           
               05  FILLER                    PIC X(23).                         
               05  P-PREP-DATE-LIT           PIC X(15).                         
               05  P-PREP-DATE               PIC X(9).                          
           03  PR-LINE5 REDEFINES PR-LINE1.                                     
               05  P-NAME                    PIC X(26).                         
               05  FILLER                    PIC X.                             
               05  P-BDATE                   PIC X(7).                          
               05  FILLER                    PIC X.                             
               05  P-CERT                    PIC Z(9).                          
               05  FILLER                    PIC X.                             
               05  P-CLASS                   PIC XX.                            
               05  FILLER                    PIC X.                             
               05  P-DEP-LIFE                PIC X.                             
               05  FILLER                    PIC X.                             
               05  P-DEP-EHC                 PIC X.                             
               05  FILLER                    PIC X.                             
               05  P-DEP-DEN                 PIC X.                             
               05  FILLER                    PIC X.                             
               05  P-COL-DATA OCCURS 10 TIMES PIC X(10).                        
           03  PR-LINE6 REDEFINES PR-LINE1.                                     
               05  P-TOTAL-LIT               PIC X(6).                          
               05  FILLER                    PIC X(8).                          
               05  P-LIVES-INS-LIT           PIC X(21).                         
               05  P-LIVES-INS               PIC ZZZ,ZZ9.                       
           03  PR-LINE7 REDEFINES PR-LINE1.                                     
               05  FILLER                    PIC X(24).                         
               05  PR-ABBREV-LIT1.                                              
                   07  FILLER                PIC X(3).                          
                   07  PR-ABBREV-LIT2        PIC X(46).                         
           03  PR-LINE8 REDEFINES PR-LINE1.                                     
               05  PR-X-1                    PIC X(46).                         
               05  PR-X-LIT                  PIC X(40).                         
               05  FILLER                    PIC X(45).                         
               05  PR-X-2                    PIC X(1).                          
                                                                                
       01  DLSWRITE-PARMS64.                                                    
           03  PRINT-SYS064              PIC X(6)  VALUE 'SYS064'.              
           03  PRINT-RTN64     COMP-3    PIC S9    VALUE +0.                    
           03  PRINT-RECSIZE64           PIC 9(5)  VALUE 00165.                 
           03  PRINT-BLKSIZE64           PIC 9(5)  VALUE 01650.                 
           03  PRINT-FORMAT64            PIC XX    VALUE 'FB'.                  
           03  PRINT-SYS064-COUNT        PIC S9(9) VALUE +0.                    
                                                                                
       01  DLSWRITE-PARMS65.                                                    
           03  PRINT-SYS065              PIC X(6)  VALUE 'SYS065'.              
           03  PRINT-RTN65     COMP-3    PIC S9    VALUE +0.                    
           03  PRINT-RECSIZE65           PIC 9(5)  VALUE 00165.                 
           03  PRINT-BLKSIZE65           PIC 9(5)  VALUE 01650.                 
           03  PRINT-FORMAT65            PIC XX    VALUE 'FB'.                  
           03  PRINT-SYS065-COUNT        PIC S9(9) VALUE +0.                    
                                                                                
       01  GGIBIT6X-FUNCTION                       PIC X(1).                    
                                                                                
       01  GGIBIT6X-CHAR-CNT                       PIC S9(4) COMP.              
                                                                                
      *01  GGI6BITX.                                                            
           COPY GGI6BITX.                                                       
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
MAN07      05  GWCDUMP                      PIC X(8)  VALUE 'GWCDUMP'.          
MAN07  COPY GWRDUMP.                                                            
MAN07  01  ICBM.                                                                
MAN07  COPY ICBM.                                                               
       LINKAGE SECTION.                                                         
       01  TAPE-REC.                                                            
           03  FILLER                              PIC X(4).                    
           03  CURR-KEY.                                                        
               05  CURR-SEG1.                                                   
                   07  T-REC-TYPE                  PIC X.                       
                   07  T-FORM                      PIC X.                       
               05  T-PRODUCT                       PIC X.                       
               05  T-GRP-OFF                       PIC X(5).                    
GNE            05  T-GROUP     COMP-3              PIC S9(7).                   
               05  T-ACCT                          PIC XXX.                     
           03  T-DIVISION      COMP-3              PIC S9(3).                   
           03  T-ORD                               PIC X.                       
           03  T-CERT-NAME-N.                                                   
               05  T-CERT-N    COMP-3              PIC S9(9).                   
               05  T-NAME-N                        PIC X(25).                   
           03  T-NAME-CERT-A   REDEFINES   T-CERT-NAME-N.                       
               05  T-NAME-A                        PIC X(25).                   
               05  T-CERT-A    COMP-3              PIC S9(9).                   
           03  T-CLS                               PIC XX.                      
           03  T-BIRTHDATE                         PIC X(4).                    
           03  T-COVERAGE-INFO.                                                 
               05  T-NO-OF-COV-CODES    COMP-3     PIC S9(3).                   
               05  T-COVERAGE-DATA OCCURS 38 TIMES.                             
                   07  T-COV-CODE                  PIC S9(3) COMP-3.            
                   07  T-VOLUME                    PIC S9(7) COMP-3.            
                   07  T-SEL-IND                   PIC XX.                      
                   07  T-PREM                      PIC S9(6)V999 COMP-3.        
               05  FILLER                          PIC X(25).                   
                                                                                
       01  MISC-AREA.                                                           
           03  FILLER                              PIC X(4).                    
           03  HI-DATE                             PIC X(4).                    
           03  STAT-DATE                           PIC X(4).                    
           03  FILLER                              PIC X(4).                    
           03  R-RESTART.                                                       
               05  R-REC-TYPE                      PIC X.                       
               05  R-FORM                          PIC X.                       
GNE            05  R-GROUP                         PIC 9(7).                    
               05  R-ACCT                          PIC XXX.                     
GNE        03  FILLER              PIC X(4).                                    
                                                                                
      *01  GPRPRINT.                                                            
           COPY GPRPRINT.                                                       
                                                                                
      *01  GPRTPARM.                                                            
           COPY GPRTPARM.                                                       
                                                                                
      *01  GPRACCUM.                                                            
           COPY GPRACCUM.                                                       
                                                                                
       01  GO-TO-SW                PIC S9      COMP-3.                          
                                                                                
       01  CLOSE-FILE-SW           PIC X.                                       
                                                                                
       PROCEDURE DIVISION      USING   TAPE-REC                                 
                                       MISC-AREA                                
                                       GPRPRINT                                 
                                       GPRTPARM                                 
                                       GPRACCUM                                 
                                       GO-TO-SW                                 
                                       CLOSE-FILE-SW.                           
                                                                                
      ******************************************************************        
      *    INITIALIZATION                                                       
      *    - SET UP PRINT-LINE, PREV KEY                                        
      *    - CALL GNUMTABL TO GET THE LOW AND HIGH COV CODES FOR EHC AND        
      *      DENTAL                                                             
      *    - STORE THE RESTART INFO. IF REQUIRED                                
      *    - SET THE START SW ON IF REACHED RECORD TO START PROCESSING          
      ******************************************************************        
       GPRCERTL-STARTUP.                                                        
           IF CLOSE-FILE-SW         =  'Y'                                      
               GO TO CLOSE-FILES.                                               
      *                                                                         
      *   SET UP THE ERROR FILE RECORD TYPE.      MARCUS.                       
      *                                                                         
           MOVE  '5'    TO  E-REC-TYPE                                          
                                                                                
           MOVE SPACES TO PRINT-LINE.                                           
           MOVE  LOW-VALUES    TO  PREV-KEY.                                    
           CALL 'GNUMTABL' USING  GNUM-TABLE-NO                                 
                                  GNUM-EHC-KEY                                  
                                  GNUM-RETURN.                                  
           MOVE COV-CODE-MIN TO EHC-CODE-MIN.                                   
           MOVE COV-CODE-MAX TO EHC-CODE-MAX.                                   
           CALL 'GNUMTABL' USING  GNUM-TABLE-NO                                 
                                  GNUM-DEN-KEY                                  
                                  GNUM-RETURN.                                  
           MOVE COV-CODE-MIN TO DEN-CODE-MIN.                                   
           MOVE COV-CODE-MAX TO DEN-CODE-MAX.                                   
           IF  R-REC-TYPE  NOT EQUAL TO  '5'                                    
           OR  R-FORM  EQUAL TO  HIGH-VALUES                                    
               MOVE  R-RESTART    TO  STORE-RESTART                             
               GO  TO  INIT-1.                                                  
           IF  R-GROUP  NOT NUMERIC                                             
               MOVE  ZEROS  TO  R-GROUP.                                        
           MOVE  R-REC-TYPE   TO  SR-REC-TYPE.                                  
           MOVE  R-FORM       TO  SR-FORM.                                      
           MOVE  R-GROUP      TO  SR-GROUP.                                     
           MOVE  R-ACCT     TO  SR-ACCT.                                        
                                                                                
       INIT-1.                                                                  
           IF  R-FORM NOT EQUAL SPACES                                          
               IF  GO-TO-SW EQUAL +4                                            
                   IF  T-FORM GREATER THAN R-FORM                               
                       GO TO GETBACK.                                           
           IF  CURR-SEG1  NOT  LESS THAN  SAVE-RESTART-1                        
               MOVE  '1'     TO  START-SW                                       
           ELSE                                                                 
                 MOVE  '0'    TO  START-SW.                                     
           GO  TO  REINIT-FORM.                                                 
                                                                                
       SUMMARY.                                                                 
      ******************************************************************        
      *  - ACCUMULATE TOTALS FOR GRP/ACCT/FORM                                  
      *  - IF CURRENT RECORD HAS THE SAME KEY AS LAST RECORD PROCESSED          
      *    GO TO NORM-PROC ROUTINE.                                             
      *  - IF NOT - THIS SIGNIFIES CHANGE IN KEY.  PRINT THE TOTAL LINE         
      *           - BRANCH TO THE APPROPRIATE REINIT, DEPENDING UPON            
      *             HOW MUCH OF THE KEY CHANGED                                 
      ******************************************************************        
           MOVE +0 TO COL-SUB.                                                  
       SUMM-ACCUM-TOTAL.                                                        
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB NOT GREATER THAN PREM-SUB                                 
              ADD COL-ACCUM (COL-SUB) TO GRP-ACCT-COL-ACCUM (COL-SUB)           
              GO TO SUMM-ACCUM-TOTAL.                                           
           IF  CURR-KEY  EQUAL TO   PREV-KEY                                    
               GO  TO  NORM-PROC.                                               
           PERFORM  END-GRP  THRU  END-GRP-EXIT.                                
           IF  CURR-SEG1   EQUAL TO  PREV-SEG1                                  
               GO  TO  REINIT-PAGE.                                             
           IF  SR-FORM NOT EQUAL SPACES                                         
               IF  GO-TO-SW EQUAL +4                                            
                   IF  T-FORM GREATER THAN SR-FORM                              
                       GO TO GETBACK.                                           
           IF  T-REC-TYPE   EQUAL TO   P-REC-TYPE                               
               GO  TO  REINIT-FORM.                                             
                                                                                
       CLOSE-FILES.                                                             
                                                                                
           MOVE +4 TO PRINT-RTN65.                                              
           MOVE 1 TO LANG-SUB.                                                  
           PERFORM DLSWRITE-RTN.                                                
                                                                                
           MOVE +4 TO PRINT-RTN64.                                              
           MOVE 2 TO LANG-SUB.                                                  
           PERFORM DLSWRITE-RTN.                                                
                                                                                
       GETBACK.                                                                 
           GOBACK.                                                              
                                                                                
      ******************************************************************        
      *    CHANGE IN FORM CODE                                                  
      *    - CALL GPRSGMNT IF THE FORM CHANGES - US AND ENGLISH ARE             
      *      PRINTED ON THE SAME FORM BUT PAGE TOTALS ARE ACCUMULATED           
      *      SEPARATELY.                                                        
      *    - INITIALIZE THE PREPARED DATE                                       
      ******************************************************************        
       REINIT-FORM.                                                             
           IF  START-SW   EQUAL TO '0'                                          
               GO  TO  REINIT-FORM2.                                            
           IF  (P-FORM  EQUAL TO  '1' OR '2' OR '4')                            
           AND (T-FORM  EQUAL TO   '2' OR '4' OR '5')                           
               GO  TO  REINIT-PAGE.                                             
      *    CALL 'GPRSGMNT' USING PRINT-SYS022, CURR-SEG1.                       
      *    PERFORM PRINT-LINEUP-PAGES THRU PRINT-LINEUP-PAGES-EXIT.             
                                                                                
       REINIT-FORM2.                                                            
           IF  T-FORM    EQUAL TO    '3' OR '6'                                 
               MOVE  'AF'      TO  QDATE-PARM                                   
             ELSE                                                               
                   MOVE  'AD'  TO  QDATE-PARM.                                  
           IF  STAT-DATE   EQUAL TO  SPACES                                     
               CALL  'QDATE'   USING   QDATE-PARM                               
                                       HI-DATE                                  
                                       ST-DATE                                  
           ELSE                                                                 
               CALL  'QDATE'   USING   QDATE-PARM                               
                                       STAT-DATE                                
                                       ST-DATE.                                 
                                                                                
      ******************************************************************        
      *    - SET START SWITCH ON IF VALID                                       
      *    - CALL 'GPRSGMNT' TO INITIALIZE THE SYS NUMBER                       
      ******************************************************************        
       REINIT-PAGE.                                                             
           IF  START-SW   EQUAL TO  '1'                                         
           OR  CURR-SEG1   LESS THAN  SAVE-RESTART-1                            
               GO  TO  REINIT-PAGE1.                                            
           MOVE '1' TO START-SW.                                                
      *    CALL 'GPRSGMNT' USING PRINT-SYS022, CURR-SEG1.                       
      *    PERFORM PRINT-LINEUP-PAGES THRU PRINT-LINEUP-PAGES-EXIT.             
                                                                                
       REINIT-PAGE1.                                                            
      ******************************************************************        
      *    ZERO OUT THE ACCUMULATION TABLE FOR COLUMN PRINT, PAGE NO.           
      *    SET UP THE LANGUAGE SUB FOR PRINTING HEADING LITERALS                
      *    GET THE REQUIRED TRAILERS FOR PROCESSING                             
      ******************************************************************        
           MOVE  ZEROS                TO  GRP-ACCT-COL-ACCUM (1).               
           MOVE GRP-ACCT-COLUMN-ACCUM TO  GRP-ACCT-COL-ACCUM-TO-ZERO.           
           MOVE  ZEROS                TO  PAGE-NO.                              
           MOVE T-GROUP               TO  NEW-PAGE-GROUP                        
           MOVE T-ACCT                TO  NEW-PAGE-ACCT.                        
GNE        MOVE T-GROUP               TO  LT-GROUP.                             
GNE        MOVE T-ACCT                TO  LT-ACCT.                              
                                                                                
           IF  T-FORM EQUAL '1' OR '2' OR '4' OR '5'                            
               MOVE 1 TO LANG-SUB                                               
           ELSE                                                                 
               MOVE 2 TO LANG-SUB.                                              
                                                                                
GNE        MOVE '000' TO WS-TRAILER-000-IDENT.                                  
GNE        CALL GZACCMT7 USING LT-GRPACCT                                       
GNE                              MASTER-VSAM-000                                
GNE                              E-CODE.                                        
           IF E-CODE   NOT EQUAL TO   SPACES                                    
              GO TO WTL-ROUTINE.                                                
GNE        MOVE  WS-TRAILER-000-REC  TO  GMGENTR.                               
                                                                                
GNE        MOVE '010' TO WS-TRAILER-010-IDENT.                                  
GNE        CALL GZACCMT7 USING LT-GRPACCT                                       
GNE                              MASTER-VSAM-010                                
GNE                              E-CODE.                                        
           IF  E-CODE   NOT EQUAL TO   SPACES                                   
               MOVE ' ' TO GGICOUNTRY                                           
               PERFORM ERROR-ROUTINE.                                           
GNE        MOVE WS-TRAILER-010-REC   TO  GMSTSTR.                               
                                                                                
           MOVE '030' TO WS-TRAILER-030-IDENT.                                  
GNE        CALL GZACCMT7 USING LT-GRPACCT                                       
GNE                              MASTER-VSAM-030                                
GNE                              E-CODE.                                        
           IF  E-CODE  NOT EQUAL TO  SPACES                                     
               MOVE ' ' TO GGICOUNTRY                                           
               PERFORM ERROR-ROUTINE.                                           
GNE        MOVE WS-TRAILER-030-REC   TO  GMBILTR.                               
                                                                                
GNE        CALL  GZNAEXP7    USING   GMBILTR                                    
GNE                                    NAME-EXPAND-AREA                         
GNE                                    E-CODE.                                  
           IF  E-CODE   NOT EQUAL TO   SPACES                                   
               MOVE ' ' TO GGICOUNTRY                                           
               PERFORM ERROR-ROUTINE.                                           
                                                                                
           IF GGICOUNTRY NOT EQUAL '0'                                          
              MOVE '1' TO GGICOUNTRY.                                           
      ******************************************************************        
      *    TRANSFORM THE 'GGIBENEFIT-COMB' TABLE INTO TABLE BY                  
      *    COVERAGE CODE.  IN THIS NEW TABLE, EACH ENTRY (COVERAGE CODE)        
      *    WILL HAVE THE COLUMNS (1 TO 9) WHICH IT IS REQUIRED IN.              
      *                                                                         
      *    EG. COMB TABLE =                                                     
      *     1     3    1     1      1     1      2                              
      *    LIFE  LIFE  WI    WI    LTD   LTD   HEALTH                           
      *    AMT   PREM  AMT   PREM  AMT   PREM  PREM                             
      *     V     P     V     P     V     P     P                               
      *                                                                         
      *    CODES = 150,150,160,083,10,10,130,130,19,99                          
      *                                                                         
      *    USE THE TOP ROW OF NUMBERS TO ASSIGN THE NEXT "N" CODES              
      *    TO THE NEXT AVAILABLE COLUMN.                                        
      *                                                                         
      *    CODE POSITIONS/VALUES        COLUMN ASSIGNED TO                      
      *     1     = 150                     1                                   
      *     2,3,4 = 150,160,083             2                                   
      *     5     = 10                      3                                   
      *     6     = 10                      4                                   
      *     7     = 130                     5                                   
      *     8     = 130                     6                                   
      *     9,10  = 19,99                   7                                   
      *                                                                         
      *    END UP WITH THIS TABLE.                                              
      *    #CODES = 7                                                           
      *    CODE  #COLS  COL LIST                                                
      *    150     2     1,2                                                    
      *    160     1     2                                                      
      *     83     1     2                                                      
      *     10     2     3,4                                                    
      *    130     2     5,6                                                    
      *     19     1     7                                                      
      *     99     1     7                                                      
      ******************************************************************        
                                                                                
       BUILD-TABLE-BY-COV-CODE.                                                 
      ****************************************************************          
      *    RELEASE # 1.                                                         
      *    WANT TO EXPAND THE COMPRESSED 6-BIT BENEFIT COMBINATIONS             
      *    INTO READABLE FORMAT.                                                
      ****************************************************************          
           MOVE 'E'                      TO GGIBIT6X-FUNCTION.                  
           MOVE +171                     TO GGIBIT6X-CHAR-CNT.                  
           MOVE SPACES                   TO GGI6BITX.                           
                                                                                
           CALL 'GUTBITS6' USING GGIBIT6X-FUNCTION                              
                                 GGIBIT6X-CHAR-CNT                              
                                 GGITITLES-AREA                                 
                                 GGI6BITX.                                      
                                                                                
           MOVE 0 TO GGICOV-SUB.                                                
           MOVE 0 TO GGICOL-SUB                                                 
           MOVE 0 TO TITLE-NUM-CODES.                                           
       CHANGE-GGICOL.                                                           
           ADD  1 TO GGICOL-SUB                                                 
           IF GGICOL-SUB GREATER THAN 9 OR                                      
              B6-GGIPREM-OR-VOL (GGICOL-SUB) = SPACES                           
              GO TO END-TABLE-BUILD.                                            
           MOVE 0 TO GGICOL-CTR.                                                
       BUILD-TABLE-LOOP.                                                        
           ADD +1 TO GGICOL-CTR.                                                
           IF GGICOL-CTR GREATER THAN GGINUM-COV-CODES (GGICOL-SUB)             
              GO TO CHANGE-GGICOL.                                              
           ADD +1 TO GGICOV-SUB.                                                
      *    CHECK IF THIS COVERAGE CODE IS ALREADY STORED.                       
           MOVE +0 TO CHECK-SUB.                                                
       CHECK-TABLE-LOOP.                                                        
           ADD +1 TO CHECK-SUB.                                                 
           IF CHECK-SUB GREATER THAN TITLE-NUM-CODES                            
              ADD +1 TO TITLE-NUM-CODES                                         
              MOVE GGICOV-CODES (GGICOV-SUB) TO                                 
                                TITLE-COV-CODE (TITLE-NUM-CODES)                
              MOVE +1 TO NUM-COLS (TITLE-NUM-CODES)                             
              MOVE GGICOL-SUB TO COLS-OF-COV-CODE (TITLE-NUM-CODES, 1)          
              GO TO BUILD-TABLE-LOOP.                                           
           IF GGICOV-CODES (GGICOV-SUB) EQUAL TITLE-COV-CODE (CHECK-SUB)        
              ADD +1 TO NUM-COLS (CHECK-SUB)                                    
              MOVE NUM-COLS (CHECK-SUB) TO COL-SUB                              
              MOVE GGICOL-SUB TO                                                
                   COLS-OF-COV-CODE (CHECK-SUB, COL-SUB)                        
              GO TO BUILD-TABLE-LOOP.                                           
           GO TO CHECK-TABLE-LOOP.                                              
       END-TABLE-BUILD.                                                         
                                                                                
      ******************************************************************        
      *    DETERMINE IF DEPENDENT HEADINGS ARE REQUIRED.                        
      ******************************************************************        
           MOVE +0 TO STATS-SUB.                                                
           MOVE '000' TO DEPENDENT-IND.                                         
       REINIT-STATS-LOOP.                                                       
           ADD +1 TO STATS-SUB.                                                 
           IF STATS-SUB GREATER THAN GSTNUM-COV-CODES                           
              GO TO SET-HEAD-LINES.                                             
           IF GSTSTAT-COV-CODE (STATS-SUB) EQUAL 160                            
              MOVE '1' TO DEP-LIFE-IND.                                         
           IF GSTSTAT-COV-CODE (STATS-SUB) EQUAL 19 AND                         
              (GSTSTAT-VOL (STATS-SUB) EQUAL 2 OR 3)                            
              MOVE '1' TO DEP-EHC-IND.                                          
           IF GSTSTAT-COV-CODE (STATS-SUB) EQUAL 99 AND                         
              (GSTSTAT-VOL (STATS-SUB) EQUAL 2 OR 3)                            
              MOVE '1' TO DEP-DEN-IND.                                          
           GO TO REINIT-STATS-LOOP.                                             
      ******************************************************************        
      *    SET UP THE TITLE LINES FOR THE REPORT                                
      ******************************************************************        
       SET-HEAD-LINES.                                                          
           MOVE SPACES TO TITLE-LINES.                                          
           MOVE NAME-LIT (LANG-SUB) TO T2-NAME-LIT.                             
           MOVE BIRTH-LIT1 (LANG-SUB) TO T1-BIRTH-LIT1.                         
           MOVE BIRTH-LIT2 (LANG-SUB) TO T2-BIRTH-LIT2.                         
           MOVE CERT-LIT-LINE1 (LANG-SUB) TO T1-CERT-LIT1.                      
           MOVE CERT-LIT-LINE2 (LANG-SUB) TO T2-CERT-LIT2.                      
           MOVE CLASS-LIT (LANG-SUB) TO T2-CLASS-LIT.                           
           IF DEPENDENT-IND NOT EQUAL '000'                                     
              MOVE DEPENDENT-LIT (LANG-SUB) TO T1-DEP-LIT.                      
           IF DEP-LIFE-IND NOT EQUAL '0'                                        
              MOVE DEP-LIT-LIFE (LANG-SUB) TO T2-DEP-LIFE-LIT.                  
           IF DEP-EHC-IND NOT EQUAL '0'                                         
              MOVE DEP-LIT-EHC  (LANG-SUB) TO T2-DEP-EHC-LIT.                   
           IF DEP-DEN-IND NOT EQUAL '0'                                         
              MOVE DEP-LIT-DEN  (LANG-SUB) TO T2-DEP-DEN-LIT.                   
           MOVE +0 TO TITLE-SUB.                                                
       REINIT-COL-TITLES.                                                       
           ADD +1 TO TITLE-SUB.                                                 
           IF TITLE-SUB GREATER THAN 9 OR                                       
              B6-GGIPREM-OR-VOL (TITLE-SUB) = SPACES                            
              GO TO REINIT-TOTAL-PREM.                                          
           MOVE B6-GGITITLE-LINE1 (TITLE-SUB)      TO                           
                T1-COL-LIT1       (TITLE-SUB).                                  
           MOVE B6-GGITITLE-LINE2 (TITLE-SUB)      TO                           
                T2-COL-LIT2       (TITLE-SUB).                                  
           GO TO REINIT-COL-TITLES.                                             
      ******************************************************************        
      *  - STORE THE SUBSCRIPT SINCE USED FOR TOTAL PREM COLUMN                 
      *  - SET UP THE COLUMN TITLES FOR THE 'TOTAL PREM'                        
      ******************************************************************        
       REINIT-TOTAL-PREM.                                                       
           MOVE TOTAL-COL-LINE1 (LANG-SUB) TO T1-COL-LIT1 (TITLE-SUB).          
           MOVE TOTAL-COL-LINE2 (LANG-SUB) TO T2-COL-LIT2 (TITLE-SUB).          
           MOVE TITLE-SUB TO PREM-SUB.                                          
                                                                                
      ******************************************************************        
      *    SET UP THE GROUP OFFICE LIT - ACCESS THE FIELD OFFICE FILE           
      *    FOR THE LITERAL.  CONCATENATE THE GROUP OFFICE LIT AND THE           
      *    GROUP OFFICE NO.                                                     
      ******************************************************************        
           MOVE SPACES TO STORE-OFFICE-NM-NUM.                                  
           MOVE GGIGROUP-OFFICE TO FOF-GRP-OFFICE.                              
           IF GGIGROUP-OFFICE EQUAL '10590' OR '00095'                          
              MOVE 'HEAD OFFICE' TO FOF-BRANCH-NAME                             
              GO TO GRP-OFF-FIND-LAST-CHAR.                                     
           CALL 'ZACCVSAM' USING FOF-PARM1                                      
                                 FOF-PARM2                                      
                                 FIELD-OFFICE-FILE.                             
           IF FOF-ERRCODE NOT EQUAL LOW-VALUES                                  
              SET OFFICE-SUB TO 1                                               
              GO TO MOVE-OFFICE-NUM.                                            
                                                                                
      *  REMOVE THE LITERAL 'GROUP OFFICE' FROM THE GROUP OFFICE NAME           
      *  FIELD.  IT IS ONLY ON GROUP OFFICES WHOSE GROUP OFFICE NUMBER          
      *  IS GREATER THAN 15000                                                  
                                                                                
           IF  GGIGROUP-OFFICE GREATER THAN '09999'                             
               IF (GGIGROUP-OFFICE LESS THAN '15000')                           
                   GO TO GRP-OFF-FIND-LAST-CHAR                                 
           ELSE                                                                 
      *-------------------------------------------------------------*           
      *                                                             *           
      *  KEEP THIS LOGIC INTACT UNTIL JAN '86.                      *           
      *                                                             *           
      *-------------------------------------------------------------*           
               IF (GGIGROUP-OFFICE LESS THAN '00100')                           
                   GO TO GRP-OFF-FIND-LAST-CHAR.                                
           MOVE +2 TO FOF-SUB.                                                  
                                                                                
       FIND-FIRST-SPACE-LOOP.                                                   
           IF (FOF-SUB GREATER THAN +25)                                        
               GO TO INIT-OFFICE.                                               
           IF (FOF-BNCK (FOF-SUB) NOT EQUAL ' ')                                
               ADD +1 TO FOF-SUB                                                
               GO TO FIND-FIRST-SPACE-LOOP.                                     
                                                                                
      *  SAVE THE SPOT WHERE THE GROUP OFFICE NUMBER CAN BE PLACED              
                                                                                
           SET OFFICE-SUB TO FOF-SUB.                                           
           SET OFFICE-SUB UP BY 1.                                              
                                                                                
       ZAP-LOOP.                                                                
           IF (FOF-SUB NOT GREATER THAN +25)                                    
               MOVE ' ' TO FOF-BNCK (FOF-SUB)                                   
               ADD +1 TO FOF-SUB                                                
               GO TO ZAP-LOOP.                                                  
           GO TO INIT-OFFICE.                                                   
      *                                                                         
      *    FOR GROUP OFFICES LESS THAN 15000, FIND THE FIRST NON BLANK          
      *    CHARACTER IN THE LITERAL (FROM RIGHT TO LEFT) AND SET THE            
      *    INDEX OFFICE-SUB TO THAT VALUE + 2.                                  
      *                                                                         
       GRP-OFF-FIND-LAST-CHAR.                                                  
           MOVE +26 TO FOF-SUB.                                                 
       GRP-OFF-FIND-LAST-CHAR-LOOP.                                             
           SUBTRACT +1 FROM FOF-SUB.                                            
           IF FOF-SUB EQUAL +0 OR                                               
              FOF-BNCK (FOF-SUB) NOT EQUAL ' '                                  
              SET OFFICE-SUB TO FOF-SUB                                         
              SET OFFICE-SUB UP BY 2                                            
           ELSE                                                                 
              GO TO GRP-OFF-FIND-LAST-CHAR-LOOP.                                
                                                                                
       INIT-OFFICE.                                                             
           MOVE FOF-BRANCH-NAME TO STORE-OFFICE-NM-NUM.                         
                                                                                
       MOVE-OFFICE-NUM.                                                         
           MOVE '(' TO STORE-OFF-NM-NUM (OFFICE-SUB).                           
           MOVE ')' TO STORE-OFF-NM-NUM (OFFICE-SUB + 6).                       
           MOVE GGIGROUP-OFFICE TO EDIT-GRP-OFFICE.                             
           MOVE EDIT-GRP-OFF-1 TO STORE-OFF-NM-NUM (OFFICE-SUB + 1).            
           MOVE EDIT-GRP-OFF-2 TO STORE-OFF-NM-NUM (OFFICE-SUB + 2).            
           MOVE EDIT-GRP-OFF-3 TO STORE-OFF-NM-NUM (OFFICE-SUB + 3).            
           MOVE EDIT-GRP-OFF-4 TO STORE-OFF-NM-NUM (OFFICE-SUB + 4).            
           MOVE EDIT-GRP-OFF-5 TO STORE-OFF-NM-NUM (OFFICE-SUB + 5).            
                                                                                
      ******************************************************************        
      *    SET UP THE NEW PAGE                                                  
      ******************************************************************        
       REINIT-PAGE2.                                                            
           MOVE T-FORM TO  NEW-PAGE-FORM.                                       
           PERFORM   NEW-PAGE THRU NP-EXIT.                                     
                                                                                
      ******************************************************************        
      * -  ZERO OUT COLUMN TOTALS FOR THIS DETAIL                               
      * -  PRINT A NEW PAGE, IF THE LAST PAGE IS FULL                           
      * -  MOVE THE FIXED DETAIL INFORMATION                                    
      ******************************************************************        
       NORM-PROC.                                                               
           MOVE  ZEROS                TO  COL-ACCUM (1).                        
           MOVE  COLUMN-ACCUM-DETAIL  TO  COL-ACCUM-TO-ZERO.                    
           IF  LINE-CT   NOT LESS THAN  +30                                     
               PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT                  
               PERFORM   NEW-PAGE THRU NP-EXIT.                                 
           IF  T-ORD   EQUAL TO   'N'                                           
               MOVE  T-CERT-N      TO  P-CERT                                   
               MOVE  T-NAME-N      TO  P-NAME                                   
             ELSE                                                               
               MOVE  T-CERT-A      TO  P-CERT                                   
               MOVE  T-NAME-A      TO  P-NAME.                                  
           MOVE  T-CLS             TO  P-CLASS.                                 
           CALL 'QDATE' USING QDATE-PARM  T-BIRTHDATE  WK-BIRTHDATE             
           MOVE WK-MMMYY TO P-BDATE.                                            
      ******************************************************************        
      *    FIND COVERAGE CODE IN COL TABLE                                      
      ******************************************************************        
      *  - LOOP THRU THE COVERAGE INFORMATION AND ACCUMULATE TOTALS.            
      *    TURN ON DEPENDENT INDICATORS AS REQUIRED.                            
      *  - MATCH THE COVERAGE CODE ON THE SEGMENT TO ONE IN THE STORED          
      *    TABLE.  IF NO MATCH, START PROCESSING THE NEXT COV. SEGMENT.         
      *    FOR A MATCH, ADD THE APPROPRIATE FIELDS (PREM OR VOLUME) TO          
      *    TO THE COLUMN TOTALS AS SPECIFIED IN THE TABLE (THE ORIGINAL         
      *    GENERAL INFORMATION TABLE WILL INDICATE IF THE COLUMN IS FOR         
      *    PREMIUM OR VOLUME).                                                  
      *    THE EHC (019) SUBLINES, MUST BE ACCUMULATED BEFORE PRINTING          
      *    IF 019 COVERAGE CODE IS REQUESTED FOR ONE OF THE COLUMNS.            
      *    THE SAME HOLDS TRUE FOR DENTAL (099).  IN ALL OTHER CASES,           
      *    HOWEVER, THE COVERAGE CODE ON THE SEGMENT MUST MATCH EXACTLY         
      *    TO ONE IN THE STORED TABLE.                                          
      *  - IGNORE THOSE SEGMENTS WHICH HAVE 'ES', 'LX' OR 'DX' IN THE           
      *    SELECTION IND. FIELD.                                                
      ******************************************************************        
           MOVE +0 TO CERT-SUB.                                                 
       CERT-COV-LOOP.                                                           
           ADD +1 TO CERT-SUB.                                                  
           IF CERT-SUB GREATER THAN T-NO-OF-COV-CODES                           
              GO TO MOVE-AMOUNTS.                                               
           IF T-COV-CODE (CERT-SUB) EQUAL 160  AND                              
             (T-VOLUME (CERT-SUB) NOT EQUAL 0)                                  
              MOVE 'X' TO P-DEP-LIFE.                                           
           IF (T-COV-CODE (CERT-SUB) NOT GREATER THAN EHC-CODE-MAX)  AND        
              (T-COV-CODE (CERT-SUB) NOT LESS THAN EHC-CODE-MIN)     AND        
              (T-VOLUME   (CERT-SUB) EQUAL 2 OR 3)                              
              MOVE 'X' TO P-DEP-EHC.                                            
           IF (T-COV-CODE (CERT-SUB) NOT GREATER THAN DEN-CODE-MAX)  AND        
              (T-COV-CODE (CERT-SUB) NOT LESS THAN DEN-CODE-MIN)     AND        
              (T-VOLUME   (CERT-SUB) EQUAL 2 OR 3)                              
              MOVE 'X' TO P-DEP-DEN.                                            
           IF T-SEL-IND (CERT-SUB) EQUAL 'ES' OR 'LX' OR 'DX'                   
              GO TO CERT-COV-LOOP.                                              
           MOVE +0 TO CHECK-SUB.                                                
       CHK-TABLE-LOOP.                                                          
           ADD +1 TO CHECK-SUB.                                                 
           IF CHECK-SUB GREATER THAN TITLE-NUM-CODES                            
              GO TO TOTAL-PREM.                                                 
           IF (TITLE-COV-CODE (CHECK-SUB) EQUAL 019)                AND         
              (T-COV-CODE (CERT-SUB) NOT GREATER THAN EHC-CODE-MAX) AND         
              (T-COV-CODE (CERT-SUB) NOT LESS THAN EHC-CODE-MIN)                
              GO TO NORM-PROC-FOUND-ENTRY.                                      
           IF (TITLE-COV-CODE (CHECK-SUB) EQUAL 099)                AND         
              (T-COV-CODE (CERT-SUB) NOT GREATER THAN DEN-CODE-MAX) AND         
              (T-COV-CODE (CERT-SUB) NOT LESS THAN DEN-CODE-MIN)                
              GO TO NORM-PROC-FOUND-ENTRY.                                      
           IF TITLE-COV-CODE (CHECK-SUB) NOT EQUAL T-COV-CODE (CERT-SUB)        
              GO TO CHK-TABLE-LOOP.                                             
      *                                                                         
      *    ENTRY HAS BEEN FOUND.  ACCUMULATE THE REQUIRED VALUES IN COL.        
      *    SPECIFIED                                                            
      *                                                                         
       NORM-PROC-FOUND-ENTRY.                                                   
           MOVE +0 TO COL-SUB.                                                  
       INCRE-COL-SUB.                                                           
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB GREATER THAN NUM-COLS (CHECK-SUB)                         
              GO TO TOTAL-PREM.                                                 
           MOVE COLS-OF-COV-CODE (CHECK-SUB, COL-SUB) TO GGI-TITLE-SUB.         
           IF B6-GGIPREM-OR-VOL (GGI-TITLE-SUB) = 'P'                           
              ADD T-PREM (CERT-SUB) TO COL-ACCUM (GGI-TITLE-SUB)                
           ELSE                                                                 
              ADD T-VOLUME (CERT-SUB) TO COL-ACCUM (GGI-TITLE-SUB).             
           GO TO INCRE-COL-SUB.                                                 
      *                                                                         
      *    ACCUMULATE IN THE TOTAL PREMIUM COLUMN.                              
      *                                                                         
       TOTAL-PREM.                                                              
           ADD T-PREM (CERT-SUB) TO COL-ACCUM (PREM-SUB)                        
           GO TO CERT-COV-LOOP.                                                 
      ****                                                                      
      *    MOVE THE COLUMN AMOUNTS TO THE PRINT LINE USING THE                  
      *    APPROPRIATE EDIT MASK                                                
      ****                                                                      
       MOVE-AMOUNTS.                                                            
           MOVE +0 TO COL-SUB.                                                  
       MOVE-AMTS-LOOP.                                                          
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB NOT LESS THAN PREM-SUB                                    
              GO TO ACCUM-TOT-PREM.                                             
           IF B6-GGIPREM-OR-VOL (COL-SUB) = 'P'                                 
              COMPUTE PREM-ROUNDED ROUNDED = COL-ACCUM (COL-SUB)                
              MOVE PREM-ROUNDED        TO EDIT-PREM                             
              MOVE EDIT-PREM           TO P-COL-DATA (COL-SUB)                  
           ELSE                                                                 
              MOVE COL-ACCUM (COL-SUB) TO EDIT-VOL                              
              MOVE EDIT-VOL            TO P-COL-DATA (COL-SUB).                 
           GO TO MOVE-AMTS-LOOP.                                                
       ACCUM-TOT-PREM.                                                          
           COMPUTE PREM-ROUNDED ROUNDED = COL-ACCUM (COL-SUB).                  
           MOVE PREM-ROUNDED           TO EDIT-PREM.                            
           MOVE EDIT-PREM              TO P-COL-DATA (COL-SUB).                 
      ******************************************************************        
      *    SAVE THE KEY                                                         
      *    GET THE NEXT RECORD                                                  
      ******************************************************************        
           MOVE  CURR-KEY      TO  PREV-KEY.                                    
           CALL 'DLSREAD' USING  TAPE-SYS014         TAPE-RETURN                
                                 TAPE-REC            TAPE-SYS014-RECSIZE        
                                 TAPE-SYS014-BLKSIZE TAPE-SYS014-FORMAT         
                                 TAPE-SYS014-COUNT.                             
           IF  TAPE-RETURN   NOT EQUAL TO   ZEROS                               
               MOVE  HIGH-VALUES   TO  CURR-KEY.                                
      ******************************************************************        
      *    WILL THE PREVIOUS LINE FIT ON THE PAGE                               
      *    YES - PRINT IT                                                       
      *    NO  - SAVE THE LINE, PRINT THE HEADINGS ON NEW PAGE, THEN            
      *          PRINT THE LINE.                                                
      ******************************************************************        
           ADD   +1                TO  LINE-CT.                                 
           IF (LINE-CT NOT GREATER THAN 28) OR (PREV-KEY EQUAL CURR-KEY)        
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE PR-LINE1 TO SAVE-LINE                                        
              MOVE SPACES TO PR-LINE1                                           
              PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT                   
              PERFORM   NEW-PAGE THRU NP-EXIT                                   
              MOVE SAVE-LINE TO PR-LINE1.                                       
           PERFORM PRINT-RTN.                                                   
           GO  TO  SUMMARY.                                                     
                                                                                
       PRINT-RTN.                                                               
           IF START-SW EQUAL '1'                                                
              IF CC EQUAL '1' THEN                                              
                 MOVE +1 TO MY-LINE-CT                                          
              ELSE                                                              
              IF CC EQUAL ' ' THEN                                              
                 ADD  +1 TO MY-LINE-CT                                          
              ELSE                                                              
              IF CC EQUAL '0' THEN                                              
                 ADD  +2 TO MY-LINE-CT                                          
              ELSE                                                              
              IF CC EQUAL '-' THEN                                              
                 ADD  +3 TO MY-LINE-CT                                          
              ELSE                                                              
                 NEXT SENTENCE.                                                 
           IF  START-SW EQUAL '1'                                               
               PERFORM DLSWRITE-RTN.                                            
      *        CALL 'DLSWRITE' USING PRINT-SYS022    PRINT-RETURN               
      *                              PRINT-LINE      PRINT-RECSIZE              
      *                              PRINT-BLKSIZE   PRINT-FORMAT               
      *                              PRINT-SYS022-COUNT.                        
           MOVE SPACES TO PRINT-LINE.                                           
                                                                                
       DLSWRITE-RTN.                                                            
                                                                                
           IF LANG-SUB = 1                                                      
              CALL 'DLSWRITE' USING PRINT-SYS065  PRINT-RTN65                   
                                    PRINT-LINE    PRINT-RECSIZE65               
                                    PRINT-BLKSIZE65 PRINT-FORMAT65              
                                    PRINT-SYS065-COUNT.                         
                                                                                
           IF LANG-SUB = 2                                                      
              CALL 'DLSWRITE' USING PRINT-SYS064  PRINT-RTN64                   
                                    PRINT-LINE    PRINT-RECSIZE64               
                                    PRINT-BLKSIZE64 PRINT-FORMAT64              
                                    PRINT-SYS064-COUNT.                         
                                                                                
      ******************************************************************        
      *    PRINT THE NEW PAGE INFORMATION                                       
      *    ADD 1 TO THE APPROPRIATE CERT LISTING ACCUMULATOR                    
      *        - US      IF FORM CODE '1' - OTHER GROUPS                        
      *        - ENGLISH IF FORM CODE '2' - OTHER GROUPS                        
      *        - FRENCH  IF FORM CODE '3' - OTHER GROUPS                        
      *        - US      IF FORM CODE '4' - GROUPS 111,115                      
      *        - ENGLISH IF FORM CODE '5' - GROUPS 111,115                      
      *        - FRENCH  IF FORM CODE '6' - GROUPS 111,115                      
      ******************************************************************        
       NEW-PAGE.                                                                
           MOVE '1' TO CC.                                                      
           PERFORM PRINT-RTN.                                                   
           MOVE '0' TO CC.                                                      
           MOVE 'PAGE' TO PAGE-LIT.                                             
           ADD +1 TO PAGE-NO.                                                   
           MOVE PAGE-NO TO OUT-PAGE.                                            
           PERFORM PRINT-RTN.                                                   
           MOVE REPORT-TITLE (LANG-SUB) TO P-TITLE.                             
           PERFORM PRINT-RTN.                                                   
           IF E-CODE EQUAL SPACES                                               
              MOVE NAME-LINE (1) TO P-GROUP-NAME.                               
           PERFORM PRINT-RTN.                                                   
           IF E-CODE EQUAL SPACES                                               
              AND NAME-DELIMETER (1) EQUAL '$'                                  
              MOVE NAME-LINE (2) TO P-GROUP-NAME.                               
           PERFORM PRINT-RTN.                                                   
           IF E-CODE EQUAL SPACES                                               
              AND NAME-DELIMETER (1) EQUAL '$'                                  
              AND NAME-DELIMETER (2) EQUAL '$'                                  
              MOVE NAME-LINE (3) TO P-GROUP-NAME.                               
           PERFORM PRINT-RTN.                                                   
           MOVE '0' TO CC.                                                      
           MOVE GROUP-NO-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                   
           MOVE NEW-PAGE-GROUP TO P-GROUP.                                      
           MOVE NEW-PAGE-ACCT TO P-ACCT.                                        
           MOVE DATE-PREP-LIT (LANG-SUB) TO P-PREP-DATE-LIT.                    
           MOVE ST-DATE TO P-PREP-DATE.                                         
           PERFORM PRINT-RTN.                                                   
           MOVE GROUP-OFF-LIT (LANG-SUB) TO P-GRP-NUM-OFF-LIT.                  
           MOVE STORE-OFFICE-NM-NUM TO P-GRP-OFFICE.                            
           PERFORM PRINT-RTN.                                                   
           MOVE '-' TO CC.                                                      
           PERFORM PRINT-RTN.                                                   
           MOVE '0' TO CC.                                                      
           MOVE TITLE-LINE1 TO PR-LINE1                                         
           PERFORM PRINT-RTN.                                                   
           MOVE TITLE-LINE2 TO PR-LINE1                                         
           PERFORM PRINT-RTN.                                                   
           MOVE '0' TO CC.                                                      
           MOVE +0 TO LINE-CT.                                                  
           IF  START-SW EQUAL TO '0'                                            
               GO TO NP-EXIT.                                                   
           IF  NEW-PAGE-FORM EQUAL '1'                                          
               ADD +1 TO ACCUM-CERT-US-OTH                                      
           ELSE                                                                 
           IF  NEW-PAGE-FORM EQUAL '2'                                          
               ADD +1 TO ACCUM-CERT-ENG-OTH                                     
           ELSE                                                                 
           IF  NEW-PAGE-FORM EQUAL '3'                                          
               ADD +1 TO ACCUM-CERT-FR-OTH                                      
           ELSE                                                                 
           IF  NEW-PAGE-FORM EQUAL '4'                                          
               ADD +1 TO ACCUM-CERT-US-SPGS                                     
           ELSE                                                                 
           IF  NEW-PAGE-FORM EQUAL '5'                                          
               ADD +1 TO ACCUM-CERT-ENG-SPGS                                    
           ELSE                                                                 
           IF  NEW-PAGE-FORM EQUAL '6'                                          
               ADD +1 TO ACCUM-CERT-FR-SPGS.                                    
       NP-EXIT.                                                                 
           EXIT.                                                                
                                                                                
      ******************************************************************        
      *    PRINT THE EXPLANATION OF THE DEPENDENT HEADINGS AT THE BOTTOM        
      *    OF THE PAGE IF REQUIRED.                                             
      ******************************************************************        
       PRINT-END-PAGE.                                                          
           IF DEPENDENT-IND EQUAL '000'                                         
              GO TO PRINT-END-PAGE-EXIT.                                        
       PRINT-END-PAGE-LOOP.                                                     
           IF MY-LINE-CT LESS THAN +54                                          
              MOVE ' ' TO CC                                                    
              PERFORM PRINT-RTN                                                 
              GO TO PRINT-END-PAGE-LOOP.                                        
           MOVE '0' TO CC.                                                      
           MOVE EXPL-ABREV-LIT-1 (LANG-SUB) TO PR-ABBREV-LIT1.                  
           PERFORM PRINT-RTN.                                                   
           IF DEP-LIFE-IND EQUAL '1'                                            
              MOVE EXPL-ABREV-LIT-2 (LANG-SUB) TO PR-ABBREV-LIT2                
              PERFORM PRINT-RTN.                                                
           IF DEP-EHC-IND  EQUAL '1'                                            
              MOVE EXPL-ABREV-LIT-3 (LANG-SUB) TO PR-ABBREV-LIT2                
              PERFORM PRINT-RTN.                                                
           IF DEP-DEN-IND  EQUAL '1'                                            
              MOVE EXPL-ABREV-LIT-4 (LANG-SUB) TO PR-ABBREV-LIT2                
              PERFORM PRINT-RTN.                                                
       PRINT-END-PAGE-EXIT.                                                     
           EXIT.                                                                
      ******************************************************************        
      *    PRINT THE SETUP PAGES SO THAT THE FORM CAN BE LINED UP ON            
      *    THE PRINTER                                                          
      ******************************************************************        
       PRINT-LINEUP-PAGES.                                                      
           MOVE PRINT-LINE TO SAVE-LINE.                                        
           PERFORM PRINT-X-PAGE THRU PRINT-X-PAGE-EXIT 3 TIMES.                 
           MOVE SAVE-LINE TO PRINT-LINE.                                        
       PRINT-LINEUP-PAGES-EXIT.                                                 
                                 EXIT.                                          
       PRINT-X-PAGE.                                                            
           MOVE '1' TO PRINT-LINE.                                              
           PERFORM PRINT-RTN.                                                   
           MOVE '-' TO PRINT-LINE.                                              
           PERFORM PRINT-RTN.                                                   
           MOVE '-' TO PRINT-LINE.                                              
           PERFORM PRINT-RTN.                                                   
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'X' TO PR-LINE8.                                            
           MOVE '  PRINT THIS BOX OF XS IN THE BLUE BOX' TO PR-X-LIT.           
           PERFORM PRINT-RTN.                                                   
           PERFORM PRINT-X-X-LINE THRU PRINT-X-X-LINE-EXIT 54 TIMES.            
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE ALL 'X' TO PR-LINE8.                                            
           PERFORM PRINT-RTN.                                                   
           GO TO PRINT-X-PAGE-EXIT.                                             
       PRINT-X-X-LINE.                                                          
           MOVE ' ' TO PRINT-LINE.                                              
           MOVE 'X' TO PR-X-1  PR-X-2.                                          
           PERFORM PRINT-RTN.                                                   
       PRINT-X-X-LINE-EXIT.                                                     
                             EXIT.                                              
       PRINT-X-PAGE-EXIT.                                                       
                           EXIT.                                                
                                                                                
      ******************************************************************        
      *    PRINT THE DASH LINE AND TOTAL LINE ON THE BOTTOM TWO LINES           
      *    OF THE BOXED AREA.                                                   
      ******************************************************************        
       END-GRP.                                                                 
           IF  START-SW  EQUAL TO  '0'                                          
               GO  TO  END-GRP-EXIT.                                            
       END-GRP-LOOP.                                                            
           MOVE ' ' TO CC.                                                      
           IF MY-LINE-CT LESS THAN +48 THEN                                     
              PERFORM PRINT-RTN                                                 
              GO TO END-GRP-LOOP.                                               
           MOVE DASH-LINE TO PR-LINE1.                                          
           PERFORM PRINT-RTN.                                                   
           MOVE TOTAL-GROUP-SUM (LANG-SUB) TO P-TOTAL-LIT.                      
           MOVE LIVES-INSURED-LIT (LANG-SUB) TO P-LIVES-INS-LIT.                
           MOVE GSTPART TO P-LIVES-INS.                                         
       MOVE-TOT-AMOUNTS.                                                        
           MOVE +0 TO COL-SUB.                                                  
       MOVE-TOT-AMTS-LOOP.                                                      
           ADD +1 TO COL-SUB.                                                   
           IF COL-SUB NOT LESS THAN PREM-SUB                                    
              GO TO MOVE-TOTAL-PREM.                                            
           IF B6-GGIPREM-OR-VOL (COL-SUB) = 'P'                                 
              MOVE GRP-ACCT-COL-ACCUM (COL-SUB) TO  EDIT-PREM                   
              MOVE EDIT-PREM TO P-COL-DATA (COL-SUB)                            
           ELSE                                                                 
              MOVE GRP-ACCT-COL-ACCUM (COL-SUB) TO  EDIT-VOL                    
              MOVE EDIT-VOL  TO P-COL-DATA (COL-SUB).                           
           GO TO MOVE-TOT-AMTS-LOOP.                                            
       MOVE-TOTAL-PREM.                                                         
           MOVE GRP-ACCT-COL-ACCUM (COL-SUB) TO  EDIT-PREM                      
           MOVE EDIT-PREM TO P-COL-DATA (COL-SUB)                               
           PERFORM PRINT-RTN.                                                   
           PERFORM PRINT-END-PAGE THRU PRINT-END-PAGE-EXIT.                     
       END-GRP-EXIT.                                                            
           EXIT.                                                                
                                                                                
       ERROR-ROUTINE.                                                           
           MOVE  T-GROUP        TO  E-GROUP.                                    
           MOVE  T-ACCT         TO  E-ACCT.                                     
           MOVE  GGICOUNTRY     TO  E-COUNTRY.                                  
      *                                                                         
      * NEXT MOVES SET UP THE NEW INFO ON ERROR FILE  MARCUS.                   
      *                                                                         
           MOVE T-PRODUCT          TO  E-PROD-CD.                               
           MOVE T-GRP-OFF         TO  E-OFFICE.                                 
      *                                                                         
           CALL  'DLSWRITE' USING  TAPE-SYS011  TAPE-RETURN                     
                                   ERR-REC TAPE-SYS011-RECSIZE                  
                                   TAPE-SYS011-BLKSIZE                          
                                   TAPE-SYS011-FORMAT                           
                                   TAPE-SYS011-COUNT.                           
       WTL-ROUTINE.                                                             
           CALL 'WTL' USING  WTL-MESSAGE-AREA1 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
           CALL 'WTL' USING  WTL-MESSAGE-AREA2 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
           MOVE E-CODE TO WTL-RET-CODE                                          
           CALL 'WTL' USING  WTL-MESSAGE-AREA3 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
           MOVE T-GROUP  TO WTL-GROUP.                                          
           MOVE T-ACCT   TO WTL-ACCT.                                           
           CALL 'WTL' USING  WTL-MESSAGE-AREA4 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
           CALL 'WTL' USING  WTL-MESSAGE-AREA5 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
           CALL 'WTL' USING  WTL-MESSAGE-AREA6 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
           MOVE 'YES' TO WTL-REPLY-CODE                                         
           CALL 'WTL' USING  WTL-MESSAGE-AREA7 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
           MOVE 'NO' TO WTL-REPLY-CODE                                          
           CALL 'WTL' USING  WTL-MESSAGE-AREA8 WTL-FLAG                         
                             WTL-REPLY-CODE    WTL-REPLY-AREA                   
GNE   *%   CALL 'ZPARDUMP' USING DUMP-PARTITION.                                
MAN07      MOVE 'GPRCERTL' TO GWRDUMP-PROGRAM-NAME                              
MAN07      CALL GWCDUMP USING ICBM                                              
MAN07                         GWRDUMP.                                          
                                                                                
