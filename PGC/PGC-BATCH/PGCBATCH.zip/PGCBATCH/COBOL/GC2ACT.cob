       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.      GC2ACT.                                                 
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *DATE-WRITTEN.    FEB 93.                                                 
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *    CREATE M&D ACCOUNTING FORMAT FILE FROM GIPSY COMMISSION              
      *    RELEASE RECORD.                                                      
      *         INPUT  - GIPSY COMMISSION RELEASE RECORD                        
      *         OUTPUT - M&D ACCOUNTING FORMAT FILE                             
      ******************************************************************        
      *    FEB/93 K. CURRIE.                                                    
      *         - PROGRAM CREATION.                                             
      *                                                                         
SUSP05*                                                                         
SUSP05*    MAY/06 F. DAZA.                                                      
SUSP05*         - INCREASED RECORD LENGTH TO +584                               
SUSP05*           FOR JEXTDATE & JEXTRACT                                       
SUSP05*           (SUSPENSE IMPROVEMENT POJECT)                                 
      *                                                                         
      *    JUL/2005  R. KNAUD.                                                  
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)                  
      *                  GET THE DATE FROM THE DATECARD FILE                    
      *                  PGW.PROD.DATEFILE(0) INSTEAD OF                        
      *                  THE FIRST RECORD IN THE GIPSY MASTER FILE.             
      *                                                                         
      *    OCT/2008 IBM                                                         
      *         -  ENTERPRISE COMPILER UPGRADE                                  
      *                                                                         
      *    FEB/2009 C MUNCAN                                                    
      *         -  VB DDNAMES FROM SYS010 & SYS015 TO SYS070 & SYS075           
      *                                                                         
      ******************************************************************        
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
       EJECT                                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------         
      *    DYNAMIC CALLED ROUTINES                                              
      *----------------------------------------------------------------         
       01  WS-CALLED-MODULES.                                                   
           05  QDATEQ2           PIC X(08)    VALUE 'QDATEQ2'.                  
                                                                                
       01  WS-FIELDS.                                                           
           05  W-S-BEGINS                      PIC X(32)  VALUE                 
FXXTOK     'GC2ACT START WORKING STORAGE  '.                                    
           05  WS-GROUP15.                                                      
               10  FILLER        PIC X(4).                                      
               10  WS-GROUP7     PIC S9(7) COMP-3.                              
           05  WS-GROUP          PIC X(7).                                      
           05  WS-ACCT4.                                                        
               10  FILLER        PIC X.                                         
               10  WS-ACCT3      PIC X(3).                                      
           05  WS-FOGL-CODE.                                                    
               10  WS-FOGL-CODE4 PIC 9(4).                                      
               10  FILLER        PIC X(6).                                      
           05  WS-HOLD-CURRENCY  PIC 99.                                        
           05  WS-CURRENCY.                                                     
               10  FILLER        PIC X.                                         
               10  WS-CURRENCY1  PIC X.                                         
           05  DDMMMYYYY-DATE.                                                  
               10  EXTRACT-DD    PIC 99.                                        
               10  EXTRACT-MMM   PIC X(3).                                      
               10  EXTRACT-YYYY  PIC 9(4).                                      
           05  YYYYMMDD-DATE.                                                   
               10  FORMAT-YYYY   PIC 9(4).                                      
               10  FORMAT-MM     PIC 9(2).                                      
               10  FORMAT-DD     PIC 9(2).                                      
           05  WS-DATE.                                                         
               07  CENTURY       PIC S9.                                        
               07  WS-DDMMYY.                                                   
                   10  WS-DD     PIC 99.                                        
                   10  WS-MM     PIC 99.                                        
                   10  WS-YY     PIC 99.                                        
           05  WS-DATE-N REDEFINES WS-DATE PIC S9(7).                           
           05  WS-DATE-OUT      COMP-3     PIC S9(7).                           
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *****************************************************************         
      *    GACDATE                                                              
      ******************************************************************        
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
      *****************************************************************         
      *    QDATE PARAMETERS                                                     
      *****************************************************************         
       01  QDATE-FIELDS.                                                        
           05  QDATE-AB-FORMAT              PIC XX    VALUE 'AB'.               
           05  QDATE-BA-FORMAT              PIC XX    VALUE 'BA'.               
           05  QDATE-BB-FORMAT              PIC XX    VALUE 'BB'.               
           05  QDATE-BC-FORMAT              PIC XX    VALUE 'BC'.               
           05  QDATE-AC-FORMAT              PIC XX    VALUE 'AC'.               
           05  QDATE-AD-FORMAT              PIC XX    VALUE 'AD'.               
           05  QDATE-CA-FORMAT              PIC XX    VALUE 'CA'.               
           05  QDATE-CB-FORMAT              PIC XX    VALUE 'CB'.               
           05  QDATE-CC-FORMAT              PIC XX    VALUE 'CC'.               
                                                                                
      *****************************************************************         
      *    TEXT LINES                                                           
      *****************************************************************         
       01  IN-COM-RELEASE-RECORD.                                               
REN        05  FILLER                        PIC X(12).                         
           05  IN-COM-RECORD                 PIC X(300).                        
      *01  GIPSY COMMISSION RELEASE RECORD.                                     
           COPY GCOMRLS7.                                                       
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  GARDTCRD.                                                            
           COPY GARDTCRD.                                                       
      /                                                                         
       01  ACCOUNTING-DATE-RECORD.                                              
           10  JEXTDATE-LL                   PIC S9(4) COMP.                    
           10  JEXTDATE-DD                   PIC S9(4) COMP.                    
           COPY JEXTDATE.                                                       
      /                                                                         
       01  ACCOUNTING-RECORD.                                                   
           10  JEXTRACT-LL                   PIC S9(4) COMP.                    
           10  JEXTRACT-DD                   PIC S9(4) COMP.                    
           COPY JEXTRACT.                                                       
      /                                                                         
      *****************************************************************         
      *    I/O MODULE PARAMETERS                                                
      *****************************************************************         
       01  READ-COMMSSN-RELEASE-FILE.                                           
           05  READ-COMMSSN-SYS070           PIC X(6)  VALUE 'SYS070'.          
           05  READ-COMMSSN-RET-CODE  COMP-3 PIC S9    VALUE +0.                
           05  READ-COMMSSN-REC-SIZE         PIC 9(5)  VALUE 304.               
           05  READ-COMMSSN-BLOCK-SIZE       PIC 9(5)  VALUE 23412.             
           05  READ-COMMSSN-REC-FORMAT       PIC X(2)  VALUE 'VB'.              
           05  READ-COMMSSN-REC-COUNT COMP-3 PIC S9(7) VALUE +0.                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  READ-GARDTCRD-FILE.                                                  
           05  READ-GARDTCRD-SYS011          PIC X(6)  VALUE 'SYS011'.          
           05  READ-GARDTCRD-RET-CODE COMP-3 PIC S9    VALUE +0.                
           05  READ-GARDTCRD-REC-SIZE        PIC 9(5)  VALUE 200.               
           05  READ-GARDTCRD-BLOCK-SIZE      PIC 9(5)  VALUE 27800.             
           05  READ-GARDTCRD-REC-FORMAT      PIC X(2)  VALUE 'FB'.              
           05  READ-GARDTCRD-REC-COUNT COMP-3 PIC S9(7) VALUE +0.               
                                                                                
       01  WRITE-ACCNTNG-SELECT-RECORDS.                                        
           05  WRITE-ACCNTNG-SYS075           PIC X(6)  VALUE 'SYS075'.         
           05  WRITE-ACCNTNG-RET-CODE  COMP-3 PIC S9    VALUE +0.               
           05  WRITE-ACCNTNG-REC-SIZE         PIC 9(5)  VALUE 23472.            
           05  WRITE-ACCNTNG-BLOCK-SIZE       PIC 9(5)  VALUE 23476.            
           05  WRITE-ACCNTNG-REC-FORMAT       PIC X(2)  VALUE 'VB'.             
           05  WRITE-ACCNTNG-REC-COUNT COMP-3 PIC S9(7) VALUE +0.               
                                                                                
       01  W-S-ENDS                         PIC X(30)  VALUE                    
FXXTOK     'GC2ACT END WORKING STORAGE'.                                        
                                                                                
       EJECT                                                                    
       PROCEDURE DIVISION.                                                      
                                                                                
       0000-GWCOCACT.                                                           
                                                                                
           PERFORM 1000-INITIALIZATION THRU                                     
                   1000-INITIALIZATION-EXIT.                                    
           PERFORM 2000-PROCESS-COMMISSION THRU                                 
                   2000-PROCESS-COMMISSION-EXIT UNTIL                           
                   READ-COMMSSN-RET-CODE NOT EQUAL +0                           
           PERFORM 1900-FINALIZATION THRU                                       
                   1900-FINALIZATION-EXIT.                                      
                                                                                
       0000-GWCOCACT-EXIT.                                                      
           EXIT.                                                                
           STOP RUN.                                                            
      /                                                                         
                                                                                
       1000-INITIALIZATION.                                                     
      ***************************************************************           
      * CREATE JEXTDATE RECORD USING THE DATE FROM THE DATECARD                 
      * FILE PGW.PROD.DATEFILE(0).  SELECT THE RECORD WITH                      
      * GARDTCRD-IDENTIFIER = 'LEAP-1'.  USE THE DATE FIELD                     
      * GARDTCRD-DAYMONYY FROM THIS RECORD.                                     
      ***************************************************************           
           MOVE SPACES         TO ACCOUNTING-DATE-RECORD.                       
SUSP05     MOVE +584           TO JEXTDATE-LL.                                  
           MOVE +0             TO JEXTDATE-DD.                                  
           MOVE 'D'            TO JEXTDATE-RECTYPE.                             
           MOVE 'C'            TO JEXTDATE-FEEDER-SYSTEM.                       
           MOVE 01             TO JEXTDATE-RUN-NUMBER.                          
                                                                                
      * VOCOMM VCM/GIPSY                                                        
           MOVE SPACES         TO GARDTCRD-IDENTIFIER.                          
           MOVE 0              TO GARDTCRD-DAY.                                 
           MOVE SPACES         TO GARDTCRD-MON.                                 
           MOVE 0              TO GARDTCRD-YY.                                  
           PERFORM 9000-READ-REC-SYS011                                         
              THRU 9000-READ-REC-SYS011-EXIT                                    
             UNTIL GARDTCRD-IDENTIFIER = 'LEAP-1'.                              
           MOVE '1B2E'         TO VDATE-REQUEST-AREA.                           
           MOVE GARDTCRD-DAYMONYY TO VDATE-EXT-DATE.                            
           CALL 'GC2DATE' USING GAC-DATE-PARAMETERS.                            
                                                                                
           CALL QDATEQ2 USING QDATE-AD-FORMAT                                   
                              VDATE-ALIS-DATE1                                  
                              DDMMMYYYY-DATE.                                   
           CALL QDATEQ2 USING QDATE-AB-FORMAT                                   
                              VDATE-ALIS-DATE1                                  
                              WS-DDMMYY.                                        
                                                                                
           MOVE EXTRACT-YYYY   TO FORMAT-YYYY.                                  
           MOVE WS-MM          TO FORMAT-MM.                                    
           MOVE EXTRACT-DD     TO FORMAT-DD.                                    
                                                                                
           MOVE YYYYMMDD-DATE  TO JEXTDATE-RUN-LOW-DATE                         
                                  JEXTDATE-RUN-HIGH-DATE.                       
           CALL 'DLSWRITE' USING WRITE-ACCNTNG-SYS075                           
                                 WRITE-ACCNTNG-RET-CODE                         
                                 ACCOUNTING-DATE-RECORD                         
                                 WRITE-ACCNTNG-REC-SIZE                         
                                 WRITE-ACCNTNG-BLOCK-SIZE                       
                                 WRITE-ACCNTNG-REC-FORMAT                       
                                 WRITE-ACCNTNG-REC-COUNT.                       
                                                                                
       1000-INITIALIZATION-EXIT.                                                
           EXIT.                                                                
      /                                                                         
                                                                                
       1900-FINALIZATION.                                                       
      ***************************************************************           
      * CLOSE OUTPUT FILES.                                                     
      ***************************************************************           
           MOVE +4              TO WRITE-ACCNTNG-RET-CODE.                      
           PERFORM 9000-WRITE-ACCNTNG-SYS075 THRU                               
                   9000-WRITE-ACCNTNG-SYS075-EXIT.                              
       1900-FINALIZATION-EXIT.                                                  
           EXIT.                                                                
      /                                                                         
                                                                                
       2000-PROCESS-COMMISSION.                                                 
                                                                                
           PERFORM 9000-READ-REC-SYS070 THRU                                    
                   9000-READ-REC-SYS070-EXIT.                                   
           IF READ-COMMSSN-RET-CODE NOT EQUAL +0                                
              GO TO 2000-PROCESS-COMMISSION-EXIT.                               
                                                                                
           MOVE IN-COM-RELEASE-RECORD TO GCOMRLSE.                              
                                                                                
           MOVE SPACES                TO ACCOUNTING-RECORD.                     
SUSP05     MOVE +584                  TO JEXTRACT-LL.                           
           MOVE +0                    TO JEXTRACT-DD.                           
           MOVE 'R'                   TO JEXTRACT-RECTYPE.                      
           MOVE 'C'                   TO JEXTRACT-FEEDER-SYSTEM.                
           MOVE 'N'                   TO JEXTRACT-REQ-ACCRUAL-FLAG.             
           MOVE 'C'                   TO JEXTRACT-REQ-CASH-FLAG.                
           MOVE 'N'                   TO JEXTRACT-REQ-CASHMAN-FLAG.             
           MOVE YYYYMMDD-DATE         TO JEXTRACT-EFF-DATE.                     
           MOVE 'N'                   TO JEXTRACT-STAFF-PLAN.                   
           MOVE 'N'                   TO JEXTRACT-ASO-PLAN.                     
           MOVE GCRL-BRANCH           TO JEXTRACT-PAYCENTRE.                    
           MOVE GCRL-GROUP            TO WS-GROUP15.                            
           MOVE WS-GROUP7             TO JEXTRACT-GROUP.                        
           MOVE GCRL-SUB-ACCOUNT      TO WS-ACCT4.                              
           MOVE WS-ACCT3              TO JEXTRACT-GROUP-ACCT.                   
           MOVE ZEROS                 TO JEXTRACT-CERTIFICATE.                  
           MOVE GCRL-FOGL-CODE        TO WS-FOGL-CODE.                          
           IF  WS-FOGL-CODE4 = 2314                                             
               MOVE 140               TO JEXTRACT-BENEFIT                       
           ELSE                                                                 
               MOVE ZEROS             TO JEXTRACT-BENEFIT.                      
           MOVE 'N'                   TO JEXTRACT-REISSUE-FLAG.                 
           MOVE 'N'                   TO JEXTRACT-TPA-ID.                       
           MOVE GCRL-CURRENCY         TO WS-HOLD-CURRENCY.                      
           MOVE WS-HOLD-CURRENCY      TO WS-CURRENCY.                           
           MOVE WS-CURRENCY1          TO JEXTRACT-CURRENCY.                     
           MOVE SPACES                TO JEXTRACT-LANGUAGE.                     
           MOVE '99'                  TO JEXTRACT-RESIDENCE-X.                  
           MOVE 'Y'                   TO JEXTRACT-MAP-FOGL-CODE.                
           MOVE GCRL-FOGL-CODE        TO JEXTRACT-FOGL-CODE.                    
           MOVE SPACES                TO JEXTRACT-PAYMENT-TYPE.                 
           MOVE SPACES                TO JEXTRACT-MICR-SYSTEM.                  
           MOVE SPACES                TO JEXTRACT-MICR-NO-X.                    
           MOVE SPACES                TO JEXTRACT-BANK-INFORMATION.             
                                                                                
           IF  GCRL-CODE (+1) = +113 AND GCRL-CAUSE = +340                      
               MOVE 'PAIDFYSF'        TO JEXTRACT-MNEMONIC                      
           ELSE                                                                 
           IF  GCRL-CODE (+1) = +113                                            
               MOVE 'PAIDFYCM'        TO JEXTRACT-MNEMONIC                      
           ELSE                                                                 
           IF  (GCRL-CODE (+1) = +121 OR GCRL-CODE (+1) = +131) AND             
               GCRL-CAUSE = +340                                                
               MOVE 'PAIDRNSF'        TO JEXTRACT-MNEMONIC                      
           ELSE                                                                 
           IF  GCRL-CODE (+1) = +121 OR GCRL-CODE (+1) = +131                   
               MOVE 'PAIDRNCM'        TO JEXTRACT-MNEMONIC                      
           ELSE                                                                 
           IF  GCRL-CODE (+1) = +118 AND GCRL-PREMNO < +13                      
               MOVE 'EARNFYCM'        TO JEXTRACT-MNEMONIC                      
           ELSE                                                                 
           IF  GCRL-CODE (+1) = +118 AND GCRL-PREMNO > +12                      
               MOVE 'EARNRNCM'        TO JEXTRACT-MNEMONIC.                     
                                                                                
           MOVE GCRL-CMAMT (+1)       TO JEXTRACT-AMT.                          
           MOVE 'N'                   TO JEXTRACT-ACCT-OVERRIDES.               
           MOVE SPACES                TO JEXTRACT-DEBIT-ACCT-NO.                
           MOVE SPACES                TO JEXTRACT-CREDIT-ACCT-NO.               
           MOVE SPACES                TO JEXTRACT-PAYEE-NAME.                   
           MOVE SPACES                TO JEXTRACT-ADDRESS-LINE (+1)             
                                         JEXTRACT-ADDRESS-LINE (+2)             
                                         JEXTRACT-ADDRESS-LINE (+3)             
                                         JEXTRACT-ADDRESS-LINE (+4)             
                                         JEXTRACT-ADDRESS-LINE (+5)             
                                         JEXTRACT-ADDRESS-LINE (+6)             
                                         JEXTRACT-ADDRESS-LINE (+7).            
           MOVE SPACES                TO JEXTRACT-CHEQUE-REMARKS.               
           MOVE ZEROS                 TO JEXTRACT-ERROR-COUNT.                  
           MOVE SPACES                TO JEXTRACT-PREV-MICR-SYSTEM.             
           MOVE SPACES                TO JEXTRACT-PREV-MICR-NO-X.               
           MOVE GCRL-AGENT-CODE       TO JEXTRACT-AGENT.                        
           MOVE GCRL-PREM-DUE-DATE    TO JEXTRACT-DUE-DATE.                     
                                                                                
           PERFORM 9000-WRITE-ACCNTNG-SYS075 THRU                               
                   9000-WRITE-ACCNTNG-SYS075-EXIT.                              
                                                                                
       2000-PROCESS-COMMISSION-EXIT.                                            
           EXIT.                                                                
      /                                                                         
                                                                                
       9000-READ-REC-SYS070.                                                    
           CALL 'DLSREAD' USING  READ-COMMSSN-SYS070                            
                                 READ-COMMSSN-RET-CODE                          
                                 IN-COM-RECORD                                  
                                 READ-COMMSSN-REC-SIZE                          
                                 READ-COMMSSN-BLOCK-SIZE                        
                                 READ-COMMSSN-REC-FORMAT                        
                                 READ-COMMSSN-REC-COUNT.                        
       9000-READ-REC-SYS070-EXIT.                                               
           EXIT.                                                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       9000-READ-REC-SYS011.                                                    
           CALL 'DLSREAD' USING  READ-GARDTCRD-SYS011                           
                                 READ-GARDTCRD-RET-CODE                         
                                 GARDTCRD                                       
                                 READ-GARDTCRD-REC-SIZE                         
                                 READ-GARDTCRD-BLOCK-SIZE                       
                                 READ-GARDTCRD-REC-FORMAT                       
                                 READ-GARDTCRD-REC-COUNT.                       
       9000-READ-REC-SYS011-EXIT.                                               
           EXIT.                                                                
                                                                                
       9000-WRITE-ACCNTNG-SYS075.                                               
           CALL 'DLSWRITE' USING WRITE-ACCNTNG-SYS075                           
                                 WRITE-ACCNTNG-RET-CODE                         
                                 ACCOUNTING-RECORD                              
                                 WRITE-ACCNTNG-REC-SIZE                         
                                 WRITE-ACCNTNG-BLOCK-SIZE                       
                                 WRITE-ACCNTNG-REC-FORMAT                       
                                 WRITE-ACCNTNG-REC-COUNT.                       
       9000-WRITE-ACCNTNG-SYS075-EXIT.                                          
           EXIT.                                                                
