       CBL DATA(24)                                                             
       ID DIVISION.                                                             
       PROGRAM-ID.     GPRLAPNT.                                                
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *DATE-COMPILED.                                                           
      *REMARKS.    TO INFORM THE GROUP POLICYHOLDER THAT THE GROUP              
      *        ACCOUNT IS IN ARREARS AND CLAIMS HAVE BEEN SUSPENDED.            
      ***************************************************************           
      *                                                                         
      *  CHANGED MAY-25-88 BY B. G. WILKE                                       
      *     CHAGNED FORMAT OF LAPSE NOTICE  AS FOLLOWS                          
      *        GROUP AND ACCOUNT ON SAME LINE (MOVED ACCOUNT)                   
      *        AGENT'S NAME ON NEXT LINE  (ADDED THIS LINE)                     
      *   AND  GFO AND BRANCH ON THE NEXT LINE (ADDED THIS LINE,                
      *                   REMOVED  SHORT NAME OF CUSTOMER)                      
      *                                                                         
      *  MODIFIED INPUT TO THE PROGRAM BY THE ADDITION OF A GFO FIELD           
      *  SO THAT THE LAPSE NOTICES MAY BE SORTED BY GFO, GROUP, ACCOUNT         
      *                                      M. BURTON     AUG 88               
      *                                                                         
      *  ADDED 3 DAYS TO THE LAPSED NOTICES BEING SENT TO GFO 15100             
      *  (B.C. OFFICES) IN ORDER TO MAKE UP FOR DISTANCE DELAY.                 
      *                                      B. DOUGHTY    JAN 89               
      *                                                                         
      *----------------------------------------------------------------*        
      *                 GIPSY  RELEASY 1  START                        *        
      *----------------------------------------------------------------*        
      *  M DRURY AUG/89  - ADD 6  POSITIONS TO RECORD FROM PRINTAL     *        
      *                  - THESE POSITIONS ARE FOR SORT.               *        
      *                  - CHANGE WORDING OF LAPSE NOTICE.             *        
      *  A SCHLEICHER    - ADDED TELEPHONE TABLE TO PICK UP TOLL FREE  *        
      *      AUG/89        NUMBER AND DISPLAY IT                       *        
      *----------------------------------------------------------------*        
      *                 GIPSY  RELEASY 1  END                          *        
      *----------------------------------------------------------------*        
      *                                                                *        
      *  M DRURY JAN/90  - BECAUSE THE LEAD TIME WAS SHORTENED FROM    *        
      *                    3 MONTHS TO 2 MONTHS, THE ARISES AFTER      *        
      *                    DATE IS 1 MONTH TOO SOON.. USE END OF MONTH.*        
      *----------------------------------------------------------------*        
      *  M BURTON MAR/90 - MOVED THE CALL TO THE GIPSY MASTER FOR      *        
      *                    ENGLISH VERSION AND ADDED A CALLED TO THE   *        
      *                    GIPSY MASTER GENERAL TRAILER TO CORRECT     *        
      *                    THE TELEPHONE NUMBERS BEING DISPLAYED ON    *        
      *                    THE LAPSE NOTICES                           *        
      *----------------------------------------------------------------*        
      *  M DRURY APR/90  - IF THE JOB IS BEING RUN ON A FRIDAY, CHANGE *        
      *                    THE DATE TO SUNDAY.                         *        
      *                    USE GC2DATE TO TELL WHAT DAY IT IS          *        
      *                    MON-1 TUES-2 WED-3 THUR-4 FRI-5 SAT-6 SUN-7 *        
      *----------------------------------------------------------------*        
NAL   *  A MA    JUN/96  - CHECK TLU111 FOR CONVERTED NAL CUSTOMERS    *        
NAL   *                    PRINT NAL/PAL TOLL FREE NUMBER ON NOTICE IF *        
NAL   *                    FOUND. DETERMINE FRENCH OR ENGLISH NUMBER   *        
NAL   *                    BY PROVINCE AND LANGUAGE CODE               *        
      *----------------------------------------------------------------*        
      * SEP/97 LARRY GLEASON  (Y2K97260)                               *Y2K97260
      *      - Y2K CHANGES - MODIFY CODE TO Y2K COMPLIANCE.            *Y2K97260
      *        OVERDUE NOTICE REPORT - DATES MADE COMPLIANT            *Y2K97260
      *                                                                *        
FDEFT * 23DEC99 FEDERICO DAZA                                          *MAC2CMD 
FDEFT *      - BYPASS LAPSE NOTICES FOR EFT PARTICIPANTS               *MAC2CMD 
ZUR1  * JUN/2001 MELANSON FOR ZURICH                                   *        
      *   - TLU111 NOW IDENTIFIES BOTH NAL AND ZURICH, SO CHANGE LOGIC *        
      *     SO THAT THE APPROPRIATE 1-800 NUMBERS ARE USED             *        
      *----------------------------------------------------------------*        
      * J SASSO AUG/2002 - lapse report verbage change for French and  *        
      *                    English.                                    *        
      *                    Task # 14899                                *        
      ******************************************************************        
      * J SASSO DEC/2002 - lapse report spelling change for aggreement *        
      *                    to agreement.                               *        
      *                    Task # 24949                                *        
      *----------------------------------------------------------------*        
      * C ARSENE FEB/05  - GBSS TASK 37699                             *        
      *                    changed to use english or french toll free  *        
      *  IBMECU   OCT/08 - ENTERPRISE COMPILER UPGRADE                 *        
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       77  FILLER                  PIC X(32)      VALUE                         
           '*** START OF W/S FOR GPRLAPNT **'.                                  
       77  PHONE-INDEX-SAVE        PIC S9(8) COMP VALUE +0.                     
       77  PHONE-INDEX             PIC S9(8) COMP VALUE +0.                     
                                                                                
       01  FILLER                  PIC X(32)      VALUE                         
           '*****  START OF GC2DATE *******'.                                   
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
                                                                                
       01  REFORMATTED-DATE.                                                    
           05  REFORMAT-DAY          VALUE SPACES  PIC XX.                      
           05  REFORMAT-MON          VALUE SPACES  PIC XXX.                     
           05  REFORMAT-YEAR         VALUE SPACES  PIC XXXX.            Y2K97260
                                                                                
       01  OLD-FORMAT-DATE.                                                     
           05  OLD-FORM-DAY          VALUE SPACES  PIC XX.                      
           05  OLD-FORM-MON          VALUE SPACES  PIC XXX.                     
           05  OLD-FORM-YEAR         VALUE SPACES  PIC XXXX.            Y2K97260
                                                                                
       01  DATE-FIELDS.                                                         
           05  CURRDATE       COMP-3.                                           
               10  CURR-YYY          VALUE ZEROES  PIC S9(3).                   
               10  CURR-DDD          VALUE ZEROES  PIC S9(3).                   
           05  WS-PREP-DATE   COMP-3.                                           
               10  PREP-YYY          VALUE ZEROES  PIC S9(3).                   
               10  PREP-DDD          VALUE ZEROES  PIC S9(3).                   
                                                                                
       01  STORE-RESTART.                                                       
           03  SAVE-RESTART.                                                    
               05  LSM-REC-TYPE                    PIC X.                       
               05  LSM-RFORM                       PIC X.                       
GNE            05  LSM-RGROUP     COMP-3           PIC S9(7).                   
               05  LSM-RACCT                       PIC XXX.                     
                                                                                
       01  FILLER.                                                              
           05  WS-ENGLISH      VALUE '1'           PIC  X(01).                  
           05  WS-FRENCH       VALUE '2'           PIC  X(01).                  
           05  WS-FORMS        VALUE SPACE         PIC  X(01).                  
           05  WS-SKIP-CHAN2   VALUE '2'           PIC  X(01).                  
           05  WS-SKIP-CHAN1   VALUE '1'           PIC  X(01).                  
           05  WS-SKIP-LINE3   VALUE '-'           PIC  X(01).                  
           05  WS-NAEXP.                                                        
             07  WS-NAME-ADDR  OCCURS  6 TIMES.                                 
               09  WS-NALBL                        PIC  X(30).                  
               09  WS-NADEL                        PIC  X(01).                  
           05  FILLER  COMP-3.                                                  
             07  WSCP3-365     VALUE +365          PIC S9(03).                  
             07  WSCP3-15      VALUE +15           PIC S9(03).                  
             07  WSCP3-14      VALUE +14           PIC S9(03).                  
             07  WSCP3-17      VALUE +17           PIC S9(03).                  
             07  WSCP3-1       VALUE +1            PIC S9(03).                  
             07  WSCP3-HIDATE.                                                  
               09  WSCP3-HIYR  VALUE +0            PIC S9(03).                  
               09  WSCP3-HIDAY VALUE +14           PIC S9(03).                  
NAL        05  WS-PHONE-CLAIMS-OFFICE              PIC  X(05).                  
NAL        05  WS-PHONE-GROUP-OFFICE               PIC  X(05).                  
           05  WS-SYS058                 PIC X(06) VALUE 'SYS058'.              
           05  WS-SYS059                 PIC X(06) VALUE 'SYS059'.              
           05  WS-PRINT-SYS058-COUNT     PIC S9(7)  COMP-3  VALUE +0.           
           05  WS-PRINT-SYS059-COUNT     PIC S9(7)  COMP-3  VALUE +0.           
           05  WS-TAX-H                            PIC S9(7)V99 COMP-3.         
           05  WS-PREM-OVD-TOTAL                   PIC S9(7)V99 COMP-3.         
           05  WS-PREM-CUR-TOTAL                   PIC S9(7)V99 COMP-3.         
           05  WS-MPAY-TOTAL                       PIC S9(7)V99 COMP-3.         
           05  WS-TOTAL                            PIC S9(8)V99 COMP-3.         
MAN07      05  MPAY-SUB                            PIC S9(3) COMP.              
           05  MBIL-SUB                            PIC S9(3).                   
           05  WS-MPAY-END-SW                      PIC X  VALUE 'N'.            
           05  WS-MBIL-END-SW                      PIC X  VALUE 'N'.            
                                                                                
NAL    01  TLU111-PARMS.                                                00940000
NAL        05  TLU111-ERRIND                       PIC X(1).            00950000
NAL        05  TLU111-SEARCH-ARGUMENT.                                          
NAL            10  TLU111-GROUP                    PIC 9(7).            00960000
NAL        05  TLU111-TABLE-NUM                    PIC S9(3) COMP-3     00970000
NAL                                                VALUE +111.          00970000
NAL        05  TLU111-CII-EFF-DATE                 PIC 9(8).            00980000
NAL        05  TLU111-GROUP-EFF-DATE               PIC 9(8).            00980000
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *       GIPSY MASTER VSAM FILE INFORMATION                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
GNE    01  MASTER-VSAM-000.                                                     
           05 WS-TRAILER-000-IDENT          PIC X(3).                           
           05 WS-TRAILER-000-REC            PIC X(16280).                       
                                                                                
GNE    01  MASTER-VSAM-030.                                                     
           05 WS-TRAILER-030-IDENT          PIC X(3).                           
           05 WS-TRAILER-030-REC            PIC X(16280).                       
                                                                                
GNE    01  MASTER-VSAM-080.                                                     
           05 WS-TRAILER-080-IDENT          PIC X(3).                           
           05 WS-TRAILER-080-REC            PIC X(16280).                       
                                                                                
GNE    01  MASTER-VSAM-090.                                                     
           05 WS-TRAILER-090-IDENT          PIC X(3).                           
           05 WS-TRAILER-090-REC            PIC X(16280).                       
                                                                                
      ******************************************************************        
      *  SYNCRONIZED MUST BE A 01 CONDITION.                                    
                                                                                
       01  FILLER.                                                              
           05  WS-E-CODE       VALUE SPACES        PIC  X(03).                  
           05  WS-QDATE-AD     VALUE 'AD'          PIC  X(02).                  
           05  WS-QDATE-AF     VALUE 'AF'          PIC  X(02).                  
           05  WS-TRL030       VALUE '030'         PIC  X(03).                  
           05  WS-TRL000       VALUE '000'         PIC  X(03).                  
           05  WS-TRL080       VALUE '080'         PIC  X(03).                  
           05  WS-TRL090       VALUE '090'         PIC  X(03).                  
                                                                                
      *  FRENCH VERBAGE FOR LAPSE NOTICE                                        
           05  FRE-LINE-1.                                                      
             07  WS-FLNE1-DATE                     PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(90).          Y2K97260
                                                                                
           05  FRE-LINE-2.                                                      
             07  WS-NAME-F                         PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  FRE-LINE-3.                                                      
             07  WS-ATTN-F                         PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  FRE-LINE-4.                                                      
             07  WS-ADDR1-F                        PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  FRE-LINE-5.                                                      
             07  WS-ADDR2-F                        PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  FRE-LINE-6.                                                      
             07  WS-ADDR3-F                        PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  FRE-LINE-7.                                                      
             07  WS-ADDR4-F                        PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  FRE-LINE-8.                                                      
             07  FILLER                            PIC  X(48) VALUE     Y2K97260
                 '                                RAPPEL IMPORTANT'.            
             07  FILLER                            PIC  X(51).          Y2K97260
                                                                                
           05  FRE-LINE-9.                                                      
             07  FILLER                            PIC  X(12)  VALUE    Y2K97260
                 'Contrat no: '.                                                
GNE          07  WS-GROUP-F                        PIC  X(07).          Y2K97260
             07  FILLER                            PIC  X(03) VALUE     Y2K97260
                 ' / '.                                                         
             07  WS-ACCT-F                         PIC  X(03).                  
GNE          07  FILLER                            PIC  X(74).          Y2K97260
                                                                                
           05  FRE-LINE-10.                                                     
             07  FILLER                            PIC  X(12)  VALUE    Y2K97260
                 'Conseiller: '.                                                
             07  WS-AGT-F                          PIC  X(25).          Y2K97260
             07  FILLER                            PIC  X(62).          Y2K97260
                                                                                
           05  FRE-LINE-11.                                                     
             07  FILLER                            PIC  X(12)  VALUE    Y2K97260
                 'Bureau:     '.                                                
             07  WS-BRANCH-F                       PIC  X(05).          Y2K97260
             07  FILLER                            PIC  X(82).          Y2K97260
                                                                                
           05  FRE-LINE-12.                                                     
             07  FILLER                            PIC  X(45)  VALUE    Y2K97260
                 'Montants de prime et de taxe on souffrance:  '.               
             07  WS-AMT-OVD-WHOLE-F                PIC  --B---B--9.     Y2K97260
             07  FILLER                            PIC  X VALUE ','.    Y2K97260
             07  WS-AMT-OVD-DECIMAL-F              PIC  V99.            Y2K97260
             07  FILLER                            PIC  X(43).          Y2K97260
                                                                                
           05  FRE-LINE-13.                                                     
             07  FILLER                            PIC  X(33)  VALUE    Y2K97260
                 'Montants de prime et taxe dus en '.                           
             07  WS-FLNE12-DATE                    PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(3)   VALUE    Y2K97260
                 ':  '.                                                         
             07  WS-AMT-CUR-WHOLE-F                PIC  --B---B--9.     Y2K97260
             07  FILLER                            PIC  X   VALUE ','.  Y2K97260
             07  WS-AMT-CUR-DECIMAL-F              PIC  V99.            Y2K97260
             07  FILLER                            PIC  X(44).          Y2K97260
                                                                                
           05  FRE-LINE-14.                                                     
             07  FILLER                            PIC  X(44)  VALUE    Y2K97260
                 'Montant total d�:                          '.                 
             07  WS-AMT-TOT-WHOLE-F                PIC  ---B---B--9.    Y2K97260
             07  FILLER                            PIC  X   VALUE ','.  Y2K97260
             07  WS-AMT-TOT-DECIMAL-F              PIC  V99.            Y2K97260
             07  FILLER                            PIC  X(43).                  
                                                                                
           05  FRE-LINE-15.                                                     
             07  FILLER                            PIC  X(43)  VALUE    Y2K97260
                 'Nos dossiers indiquent que la prime due le '.                 
             07  WS-FLNE3-DATE                     PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(41)  VALUE    Y2K97260
                 ' n''a pas �t� acquitt�e.  Veuillez ne pas'.                   
             07  FILLER                            PIC  X(06).                  
                                                                                
           05  FRE-LINE-16.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'tenir compte du pr�sent rappel si votre paiement '.           
             07  FILLER                            PIC  X(48)  VALUE    Y2K97260
                 'se trouve d�j� dans la poste.  Si toutefois vous'.            
             07  FILLER                            PIC  X(02).                  
                                                                                
           05  FRE-LINE-17.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'avez oubli� de faire le paiement, veuillez le met'.           
             07  FILLER                            PIC  X(47)  VALUE    Y2K97260
                 'tre � la poste imm�diatement afin de r�gler le '.             
             07  FILLER                            PIC  X(03).          Y2K97260
                                                                                
           05  FRE-LINE-18.                                                     
             07  FILLER                            PIC  X(47)  VALUE    Y2K97260
                 'solde de votre compte.  Veuillez y joindre une '.             
             07  FILLER                            PIC  X(46)  VALUE    Y2K97260
                 'copie du pr�sent avis ou le talon de paiement.'.              
             07  FILLER                            PIC  X(06).          Y2K97260
                                                                                
           05  FRE-LINE-19.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'Nous avons mis en suspens la couverture pr�vue pa'.           
             07  FILLER                            PIC  X(27)  VALUE    Y2K97260
                 'r votre contrat en date du '.                                 
             07  WS-FLNE16-DATE                    PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(01)  VALUE    Y2K97260
                 '.'.                                                           
             07  FILLER                            PIC  X(13).          Y2K97260
                                                                                
           05  FRE-LINE-20.                                                     
             07  FILLER                            PIC  X(50)  VALUE    Y2K97260
                 'Nous serons heureux de lever la suspension si nous'.          
             07  FILLER                            PIC  X(39)  VALUE    Y2K97260
                 ' recevons le montant total de la prime '.                     
             07  FILLER                            PIC  X(10).          Y2K97260
                                                                                
           05  FRE-LINE-21.                                                     
             07  FILLER                            PIC  X(13)  VALUE    Y2K97260
                 'due d''ici le '.                                              
             07  WS-FLNE17-DATE                    PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(01)  VALUE    Y2K97260
                 '.'.                                                           
             07  FILLER                            PIC  X(76).          Y2K97260
                                                                                
           05  FRE-LINE-22.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'Afin que les demandes de r�glement soient trait�e'.           
             07  FILLER                            PIC  X(45)  VALUE    Y2K97260
                 's en temps opportun, nous devons recevoir les'.               
             07  FILLER                            PIC  X(05).          Y2K97260
                                                                                
           05  FRE-LINE-23.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'primes mensuelles conform�ment aux dispositions d'.           
             07  FILLER                            PIC  X(39)  VALUE    Y2K97260
                 'e votre contrat.  Afin d''�viter que la'.                     
             07  FILLER                            PIC  X(11).          Y2K97260
                                                                                
           05  FRE-LINE-24.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'couverture ne soit de nouveau interrompue, vous d'.           
             07  FILLER                            PIC  X(44)  VALUE    Y2K97260
                 'evriez peut-�tre envisager d''acquitter les'.                 
             07  FILLER                            PIC  X(06).          Y2K97260
                                                                                
           05  FRE-LINE-25.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'primes par pr�l�vement automatique.  Pour obtenir'.           
             07  FILLER                            PIC  X(40)  VALUE    Y2K97260
                 ' le formulaire autorisant le pr�l�vement'.                    
             07  FILLER                            PIC  X(10).          Y2K97260
                                                                                
           05  FRE-LINE-26.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'automatique ou des renseignements sur votre compt'.           
             07  FILLER                            PIC  X(41)  VALUE    Y2K97260
                 'e, veuillez t�l�phoner sans frais � notre'.                   
             07  FILLER                            PIC  X(09).          Y2K97260
                                                                                
           05  FRE-LINE-27.                                                     
             07  FILLER                            PIC  X(44)  VALUE    Y2K97260
                 'Service � la client�le au num�ro ci-dessous.'.                
             07  FILLER                            PIC  X(55).          Y2K97260
                                                                                
           05  FRE-LINE-28.                                                     
             07  FILLER                            PIC  X(48)  VALUE    Y2K97260
                 'Nous vous remercions de votre prompte collaborat'.            
             07  FILLER                            PIC  X(04)  VALUE    Y2K97260
                 'ion.'.                                                        
             07  FILLER                            PIC  X(46).          Y2K97260
                                                                                
           05  FRE-LINE-29.                                                     
             07  FILLER                            PIC  X(45)  VALUE    Y2K97260
                 'Num�ro sans frais du Service � la client�le: '.               
             07  WS-FLNE4-NUMBER                   PIC  X(14).          Y2K97260
             07  FILLER                            PIC  X(40).          Y2K97260
                                                                                
      *                ENGLISH VERBAGE FOR LAPSE NOTICE                         
           05  ENG-LINE-1.                                                      
             07  WS-ELNE1-DATE                     PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(90).          Y2K97260
                                                                                
           05  ENG-LINE-2.                                                      
             07  WS-NAME                           PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  ENG-LINE-3.                                                      
             07  WS-ATTN                           PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  ENG-LINE-4.                                                      
             07  WS-ADDR1                          PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  ENG-LINE-5.                                                      
             07  WS-ADDR2                          PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  ENG-LINE-6.                                                      
             07  WS-ADDR3                          PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  ENG-LINE-7.                                                      
             07  WS-ADDR4                          PIC  X(30).          Y2K97260
             07  FILLER                            PIC  X(69).          Y2K97260
                                                                                
           05  ENG-LINE-8.                                                      
             07  FILLER                            PIC  X(49) VALUE     Y2K97260
                 '                        IMPORTANT REMINDER NOTICE'.           
             07  FILLER                            PIC  X(50).          Y2K97260
                                                                                
           05  ENG-LINE-9.                                                      
             07  FILLER                            PIC  X(24)  VALUE    Y2K97260
                 'Group / Account Number: '.                                    
GNE          07  WS-GROUP                          PIC  X(07).          Y2K97260
             07  FILLER                            PIC  X(03) VALUE     Y2K97260
                 ' / '.                                                         
             07  WS-ACCT                           PIC  X(03).                  
GNE          07  FILLER                            PIC  X(62).          Y2K97260
                                                                                
           05  ENG-LINE-10.                                                     
             07  FILLER                            PIC  X(24)  VALUE    Y2K97260
                 'Plan Advisor:           '.                                    
             07  WS-AGT                            PIC  X(25).          Y2K97260
             07  FILLER                            PIC  X(50).          Y2K97260
                                                                                
           05  ENG-LINE-11.                                                     
             07  FILLER                            PIC  X(24)  VALUE    Y2K97260
                 'Office:                 '.                                    
             07  WS-BRANCH                         PIC  X(05).          Y2K97260
             07  FILLER                            PIC  X(70).          Y2K97260
                                                                                
           05  ENG-LINE-12.                                                     
             07  FILLER                            PIC  X(38)  VALUE    Y2K97260
                 'Premium & Tax Amounts Overdue:        '.                      
             07  WS-AMT-OVD                        PIC  Z,ZZZ,ZZ9.99-.  Y2K97260
             07  FILLER                            PIC  X(51).          Y2K97260
                                                                                
           05  ENG-LINE-13.                                                     
             07  FILLER                            PIC  X(26)  VALUE    Y2K97260
                 'Premium & Tax Amounts Due '.                                  
             07  WS-ELNE12-DATE                    PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(03)  VALUE    Y2K97260
                 ':  '.                                                         
             07  WS-AMT-CUR                        PIC  Z,ZZZ,ZZ9.99-.  Y2K97260
             07  FILLER                            PIC  X(51).          Y2K97260
                                                                                
           05  ENG-LINE-14.                                                     
             07  FILLER                            PIC  X(37)  VALUE    Y2K97260
                 'Total Amount Owing:                  '.                       
             07  WS-AMT-TOT                        PIC  ZZ,ZZZ,ZZ9.99-. Y2K97260
             07  FILLER                            PIC  X(51).                  
                                                                                
           05  ENG-LINE-15.                                                     
             07  FILLER                            PIC  X(44)  VALUE    Y2K97260
                 'Our records show the premium payment due on '.                
             07  WS-ELNE3-DATE                     PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(29)  VALUE    Y2K97260
                 ' is outstanding.  If you have'.                               
             07  FILLER                            PIC  X(17).          Y2K97260
                                                                                
           05  ENG-LINE-16.                                                     
             07  FILLER                            PIC  X(47)  VALUE    Y2K97260
                 'already mailed your payment, please disregard t'.             
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'his notice.  If you have overlooked your payment,'.           
             07  FILLER                            PIC  X(03).          Y2K97260
                                                                                
           05  ENG-LINE-17.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'please mail it immediately to bring your account '.           
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'up to date.  Please include a copy of this notice'.           
             07  FILLER                            PIC  X(01).          Y2K97260
                                                                                
           05  ENG-LINE-18.                                                     
             07  FILLER                            PIC  X(43)  VALUE    Y2K97260
                 'or the statement remittance stub with your '.                 
             07  FILLER                            PIC  X(08)  VALUE    Y2K97260
                 'payment.'.                                                    
             07  FILLER                            PIC  X(48).          Y2K97260
                                                                                
           05  ENG-LINE-19.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'We have suspended coverage provided under your po'.           
             07  FILLER                            PIC  X(11)  VALUE    Y2K97260
                 'licy as of '.                                                 
             07  WS-ELNE16-DATE                    PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(14)  VALUE    Y2K97260
                 '.  We would be'.                                              
             07  FILLER                            PIC  X(16).          Y2K97260
                                                                                
           05  ENG-LINE-20.                                                     
             07  FILLER                            PIC  X(45)  VALUE    Y2K97260
                 'pleased to remove suspension on your account '.               
             07  FILLER                            PIC  X(40)  VALUE    Y2K97260
                 'if the total premium due is received by '.                    
             07  WS-ELNE6-DATE                     PIC  X(09).          Y2K97260
             07  FILLER                            PIC  X(01)  VALUE    Y2K97260
                 '.'.                                                           
             07  FILLER                            PIC  X(04).          Y2K97260
                                                                                
           05  ENG-LINE-21.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'In order to ensure the timely payment of claims, '.           
             07  FILLER                            PIC  X(43)  VALUE    Y2K97260
                 'monthly premiums must be received according'.                 
             07  FILLER                            PIC  X(07).          Y2K97260
                                                                                
           05  ENG-LINE-22.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'to the terms of your contract.  To ensure uninter'.           
             07  FILLER                            PIC  X(45)  VALUE    Y2K97260
                 'rupted service in the future, you may wish to'.               
             07  FILLER                            PIC  X(05).          Y2K97260
                                                                                
           05  ENG-LINE-23.                                                     
             07  FILLER                            PIC  X(49)  VALUE    Y2K97260
                 'consider making premium payments using pre-author'.           
             07  FILLER                            PIC  X(39)  VALUE    Y2K97260
                 'ized debit.  For a pre-authorized debit'.                     
             07  FILLER                            PIC  X(11).          Y2K97260
                                                                                
           05  ENG-LINE-24.                                                     
             07  FILLER                            PIC  X(48)  VALUE    Y2K97260
                 'agreement form or any questions about your accou'.            
             07  FILLER                            PIC  X(41)  VALUE    Y2K97260
                 'nt, please contact the Toll-Free Customer'.                   
             07  FILLER                            PIC  X(10).          Y2K97260
                                                                                
           05  ENG-LINE-25.                                                     
             07  FILLER                            PIC  X(27)  VALUE    Y2K97260
                 'Service Number noted below.'.                                 
             07  FILLER                            PIC  X(72).          Y2K97260
                                                                                
           05  ENG-LINE-26.                                                     
             07  FILLER                            PIC  X(48)  VALUE    Y2K97260
                 'Your prompt attention to this matter is apprecia'.            
             07  FILLER                            PIC  X(04)  VALUE    Y2K97260
                 'ted.'.                                                        
             07  FILLER                            PIC  X(47).          Y2K97260
                                                                                
           05  ENG-LINE-27.                                                     
             07  FILLER                            PIC  X(34)  VALUE    Y2K97260
                 'Toll-Free Customer Service Number '.                          
             07  WS-ELNE4-NUMBER                   PIC  X(14).          Y2K97260
             07  FILLER                            PIC  X(51).          Y2K97260
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
           '*****  START OF GTELENOS *****'.                                    
           COPY GTELENOS.                                                       
                                                                                
      *  REPORT LINE SET UP AREA                                                
                                                                                
       01  WS-REPORT-AREA.                                                      
           05  WS-RPT-CC                           PIC  X(01).                  
           05  FILLER                              PIC  X(10).                  
           05  WS-RPT-TEXT                         PIC  X(99).                  
           05  FILLER                              PIC  X(22).                  
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
           '*****  START OF GERRREC  *****'.                                    
GNE        COPY GERRREC7.                                                       
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
           '*****  START OF GMBNATR  *****'.                                    
           COPY GMBNATR.                                                        
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
GNE        '*****  START OF GMGENTR7 *****'.                                    
GNE        COPY GMGENTR7.                                                       
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
           '*****  START OF GMBILTR  *****'.                                    
           COPY GMBILTR.                                                        
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
           '*****  START OF GMPAYTR  *****'.                                    
           COPY GMPAYTR.                                                        
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
           '*****  START OF EAGNFILE *****'.                                    
           COPY EAGNFILE.                                                       
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
           '*****  START OF GFMAGENT-PARMS'.                                    
       01  GFMAGENT-PARMS.                                                      
           05  GFMAGENT-FUNCTION     PIC X(6)   VALUE SPACES.                   
           05  GFMAGENT-ERROR        PIC X(5)   VALUE SPACES.                   
           05  GFMAGENT-KEY.                                                    
               10  GFMAGENT-CODE     PIC S9(7)  VALUE ZERO    COMP-3.           
               10  GFMAGENT-ACCOUNT  PIC X(1)   VALUE SPACE.                    
                                                                                
       01  FILLER                  PIC X(30)      VALUE                         
GNE        '*****  START OF GLAPSNO7  ****'.                                    
                                                                                
       01  WS-LAPSE-NOTICE-RECORD.                                              
GNE        COPY GLAPSNO7.                                                       
                                                                                
      *  FROM GIPSY PRINT FILE LAPSE NOTICE                                     
                                                                                
FDEFT  01  PAD-REQUEST.                                                         
FDEFT                             COPY GWEFLPDR.                                
FDEFT  01  PAD-WORKING-FIELDS.                                                  
FDEFT      05  GWEFCPDR    VALUE 'GWEFCPDR'   PIC X(08).                        
FDEFT      05  PAD-KEY-DATA.                                                    
FDEFT          10 FILLER       VALUE '0'      PIC X(01).                        
GNE            10 PAD-GROUP                   PIC 9(07).                        
FDEFT          10 PAD-ACCOUNT                 PIC X(03).                        
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  GC2DATE                      PIC X(8)  VALUE 'GC2DATE'.          
MAN07      05  GZACCMT7                     PIC X(8)  VALUE 'GZACCMT7'.         
MAN07      05  TLUCOBD                      PIC X(8)  VALUE 'TLUCOBD'.          
MAN07      05  GZNAEXP7                     PIC X(8)  VALUE 'GZNAEXP7'.         
       LINKAGE SECTION.                                                         
                                                                                
       01  TAPE-SYS014-RECORD.                                                  
           05  TAPE-SYS014-PART1.                                               
               07  FILLER                        PIC  X(4).                     
               07  TAPE-SYS014-TYPE              PIC  X.                        
               07  FILLER                        PIC  X(07).                    
           05  TAPE-SYS014-GRPOFF                PIC  X(5).                     
           05  TAPE-SYS014-PART2                 PIC  X(42).                    
                                                                                
      *  FROM GPRINTAL DRIVER MODULE                                            
                                                                                
       01  LSMISC-AREA.                                                         
           05  FILLER                              PIC  X(04).                  
           05  LSM-HIDATE.                                                      
             07  LSM-HIYEAR                COMP-3  PIC S9(03).                  
             07  LSM-HIDAY                 COMP-3  PIC S9(03).                  
           05  FILLER                              PIC  X(08).                  
           05  LSM-RESTART.                                                     
             07  LSM-RCOMP.                                                     
               09  LSM-REC-TYPE                    PIC  X(01).                  
               09  LSM-RFORM                       PIC  X(01).                  
GNE            09  LSM-RGROUP                      PIC  9(07).                  
               09  LSM-RACCT                       PIC  X(03).                  
             07  FILLER                            PIC  X(04).                  
GNE****    05  FILLER              PIC XX.                                      
                                                                                
           COPY GPRPRINT.                                                       
                                                                                
           COPY GPRTPARM.                                                       
                                                                                
           COPY GPRACCUM.                                                       
                                                                                
       01  GO-TO-SW                PIC S9      COMP-3.                          
                                                                                
       PROCEDURE DIVISION USING TAPE-SYS014-RECORD                              
                                LSMISC-AREA                                     
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM                                        
                                GO-TO-SW.                                       
      *************************************************************             
       INITIALIZE-ROUTINE.                                                      
      *************************************************************             
      * GET TODAY DATE IN ALIS FORMAT FOR CALCS ON GIPSY                        
           MOVE 'E' TO VDATE-REQ-SERVICE.                                       
           MOVE 'A' TO VDATE-REQ-BASIS.                                         
           MOVE '1' TO VDATE-REQ-DETAIL.                                        
           MOVE 'E' TO VDATE-REQ-LANGUAGE                                       
MAN07      CALL GC2DATE USING GAC-DATE-PARAMETERS.                              
                                                                                
           IF VDATE-RET-CODE = ZERO THEN                                        
      *       MOVE VDATE-ALIS-DATE2 TO CURRDATE                                 
              MOVE VDATE-ALIS-DATE1 TO CURRDATE                                 
              DISPLAY 'currdate: ' CURR-YYY, '/', CURR-DDD                      
           ELSE                                                                 
              DISPLAY 'ERROR : GET TODAY DATE',                                 
              VDATE-RETURN-AREA  , '          ',                                
              VDATE-ALIS-DATE1   , '          ',                                
              VDATE-EXT-DATE.                                                   
                                                                                
      *    NEXT LINE SETS UP THE ERROR REPORT RECORD TYPE   MARCUS.             
           MOVE '6' TO E-REC-TYPE.                                              
      *  SET THE PARMS FOR GC2DATE.                                    *        
      *      SERVICE 8 WILL RETURN THE DAY OF THE WEEK                 *        
      *      BASIS A TELLS THE TYPE OF CALNDER TO USE                  *        
      *      DAY-OF-WEEK IS THE DAY THE MODULE WAS CALLED.             *        
           MOVE '8'         TO VDATE-REQ-SERVICE.                               
           MOVE 'A'         TO VDATE-REQ-BASIS.                                 
           MOVE  LSM-HIDATE TO VDATE-ALIS-DATE1.                                
MAN07      CALL GC2DATE   USING GAC-DATE-PARAMETERS.                            
           IF VDATE-DAY-OF-WEEK   =  +5                                         
               ADD +2   TO LSM-HIDAY.                                           
                                                                                
           IF LSM-HIDAY > 365                                                   
               SUBTRACT 365 FROM LSM-HIDAY                                      
               ADD 1 TO LSM-HIYEAR.                                             
                                                                                
           MOVE ZERO TO PRINT-RETURN.                                           
           MOVE SPACES TO WS-REPORT-AREA.                                       
                                                                                
           CALL 'QDATE' USING WS-QDATE-AD                                       
                              LSM-HIDATE                                        
                              WS-ELNE1-DATE.                                    
           CALL 'QDATE' USING WS-QDATE-AF                                       
                              LSM-HIDATE                                        
                              WS-FLNE1-DATE.                                    
           MOVE LSM-HIDATE TO WSCP3-HIDATE.                                     
           ADD WSCP3-14    TO WSCP3-HIDAY.                                      
           IF WSCP3-HIDAY GREATER WSCP3-365                                     
               SUBTRACT WSCP3-365 FROM WSCP3-HIDAY                              
               ADD WSCP3-1 TO WSCP3-HIYR.                                       
           CALL 'QDATE' USING WS-QDATE-AD                                       
                              WSCP3-HIDATE                                      
                              WS-ELNE6-DATE.                                    
           CALL 'QDATE' USING WS-QDATE-AF                                       
                              WSCP3-HIDATE                                      
                              WS-FLNE17-DATE.                                   
           IF  LSM-RGROUP OF LSM-RCOMP NOT NUMERIC                              
               MOVE 0 TO LSM-RGROUP OF LSM-RCOMP.                               
           MOVE CORRESPONDING LSM-RCOMP TO SAVE-RESTART.                        
                                                                                
      * RESTART ROUTINE                                                         
                                                                                
           IF  LSM-REC-TYPE OF SAVE-RESTART NOT = '6'                           
FDEFT *->  BYPASS IF EFT PARTICIPANT                                            
FDEFT          MOVE TAPE-SYS014-RECORD TO LAPSE-NOTICE-RECORD                   
FDEFT          PERFORM CHECK-PAD-REQUEST                                        
FDEFT          IF REQ-PAD-IN-EFFECT                                             
FDEFT          OR REQ-PAD-SUSPENDED THEN                                        
FDEFT *->  BYPASS                                                               
FDEFT              DISPLAY LSTGROUP '-' LSTACCT ' BYPASSED!, STATUS: '          
FDEFT                      REQ-STATUS                                           
FDEFT              GO TO FILE-INPUT-READ                                        
FDEFT          ELSE                                                             
FDEFT *->          NOT A QUALIFYING EFT CLIENT, PROCESS NORMALLY                
                   GO TO FORMS-MOUNTED.                                         
                                                                                
      *************************************************************             
       RESTART-ROUTINE.                                                         
      *************************************************************             
           IF  LSM-RFORM OF SAVE-RESTART NOT EQUAL SPACES                       
               IF GO-TO-SW EQUAL +4                                             
                   IF LSTFORM GREATER THAN LSM-RFORM OF SAVE-RESTART            
                       GO TO END-OPERATIONS.                                    
           IF LST-CURR-KEY NOT LESS THAN SAVE-RESTART                           
                                                                                
FDEFT *->      DO PAD REQUEST, CHECK AND BYPASS IF EFT PARTICIPANT              
FDEFT          MOVE LSM-RGROUP OF SAVE-RESTART TO LSTGROUP                      
FDEFT          MOVE LSM-RACCT  OF SAVE-RESTART TO LSTACCT                       
FDEFT          PERFORM CHECK-PAD-REQUEST                                        
FDEFT          IF NOT (REQ-PAD-IN-EFFECT OR REQ-PAD-SUSPENDED) THEN             
FDEFT *->          NOT A QUALIFYING EFT CLIENT, PROCEED NORMALLY                
FDEFT              DISPLAY LSTGROUP '-' LSTACCT ' BYPASSED!, STATUS: '          
FDEFT                      REQ-STATUS                                           
                   GO TO FORMS-MOUNTED                                          
FDEFT          ELSE                                                             
FDEFT *->          BYPASS, PROCEED TO READ NEXT INPUT RECORD                    
FDEFT              NEXT SENTENCE.                                               
                                                                                
           CALL 'DLSREAD' USING  TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 TAPE-SYS014-RECORD                             
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
                                                                                
           IF TAPE-RETURN  NOT EQUAL ZEROS                                      
           OR  TAPE-SYS014-TYPE NOT EQUAL '6'                                   
               GO TO END-OPERATIONS.                                            
           MOVE TAPE-SYS014-RECORD TO LAPSE-NOTICE-RECORD.                      
           GO TO RESTART-ROUTINE.                                               
                                                                                
      *************************************************************             
       FORMS-MOUNTED.                                                           
      *************************************************************             
           MOVE TAPE-SYS014-RECORD TO LAPSE-NOTICE-RECORD.                      
           MOVE LSTFORM TO WS-FORMS.                                            
                                                                                
           PERFORM LAPSE-NOTICE.                                                
                                                                                
      *************************************************************             
       LAPSE-NOTICE.                                                            
      *************************************************************             
                                                                                
           IF LSTFORM NOT EQUAL WS-ENGLISH                                      
              GO TO FRENCH-VERSION.                                             
                                                                                
      *  ENGLISH VERSION                                                        
                                                                                
           ADD +1             TO ACCUM-LAPSE-ENG.                               
                                                                                
           CALL 'QDATE' USING WS-QDATE-AD                                       
                              LSTOVDUE-DATE                                     
                              WS-ELNE3-DATE.                                    
                                                                                
           MOVE WS-ELNE3-DATE    TO   OLD-FORMAT-DATE                           
           PERFORM REFORMAT-DATE THRU REFORMAT-EXIT.                            
           MOVE REFORMATTED-DATE TO   WS-ELNE16-DATE.                           
                                                                                
           MOVE SPACES    TO E-CODE.                                            
GNE   *    MOVE WS-TRL000 TO GMGENTR.                                           
GNE        MOVE '000' TO WS-TRAILER-000-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-000                                
GNE                              WS-E-CODE.                                     
           IF WS-E-CODE EQUAL SPACES                                            
GNE           MOVE  WS-TRAILER-000-REC  TO  GMGENTR                             
GNE           NEXT SENTENCE                                                     
           ELSE                                                                 
              PERFORM ERR-RTN                                                   
              GO TO ERPTLNE8.                                                   
                                                                                
           MOVE +0        TO PHONE-INDEX-SAVE.                                  
           MOVE +1        TO PHONE-INDEX.                                       
                                                                                
NAL   *    CHECK TLU111 TO DETERMINE NAL GROUPS                                 
NAL   *    DURING CONVERSION, USE SPECIAL NAL/PAL TOLL FREE NUMBER              
NAL   *    CLAIM OFFICE = 99999 AND GFO = 99999 IF FRENCH /                     
NAL   *    GFO = ***** IF ENGLISH                                               
                                                                                
NAL        MOVE GGIGROUP-OFFICE    TO WS-PHONE-GROUP-OFFICE.                    
NAL        MOVE GGICLAIMS-OFFICE   TO WS-PHONE-CLAIMS-OFFICE.                   
NAL                                                                             
NAL        MOVE GGIGROUP-NUMBER TO TLU111-GROUP                         06720034
GNE        CALL TLUCOBD USING     TLU111-ERRIND                                 
GNE                                TLU111-SEARCH-ARGUMENT                       
GNE                                TLU111-TABLE-NUM                             
GNE                                TLU111-CII-EFF-DATE                          
GNE                                TLU111-GROUP-EFF-DATE.                       
                                                                        04240000
NAL        IF TLU111-ERRIND = SPACE                                     04250000
ZUR1          IF    GGIGROUP-NUMBER > 0050999                                   
ZUR1            AND GGIGROUP-NUMBER < 0060000                                   
ZUR1          THEN                                                              
ZUR1             NEXT SENTENCE                                                  
ZUR1          ELSE                                                              
ZUR1             MOVE '99999'    TO WS-PHONE-CLAIMS-OFFICE                      
ZUR1             IF GGIRESIDENCE = '01' OR GGILANGUAGE  = 'F'                   
ZUR1                MOVE '99999' TO WS-PHONE-GROUP-OFFICE                       
ZUR1             ELSE                                                           
ZUR1                MOVE '*****' TO WS-PHONE-GROUP-OFFICE                       
ZUR1       .                                                                    
                                                                                
GBSS  *                                                                         
GBSS  *    GBSS TASK 37699 - USE ENGLISH OR FRENCH TOLL FREE                    
GBSS  *    CLAIM OFFICE = 99999 AND GFO = 99999 IF FRENCH /                     
GBSS  *    CLAIM OFFICE = 99999 AND GFO = ***** IF ENGLISH                      
GBSS  *                                                                         
GBSS       MOVE '99999'             TO WS-PHONE-CLAIMS-OFFICE.                  
GBSS         IF GGILANGUAGE  = 'F'                                              
GBSS            MOVE '99999'          TO WS-PHONE-GROUP-OFFICE                  
GBSS         ELSE                                                               
GBSS            MOVE '*****'          TO WS-PHONE-GROUP-OFFICE.                 
                                                                                
           PERFORM PHONE-SEARCH THRU PHONE-SEARCH-EXIT                          
             UNTIL PHONE-INDEX-SAVE NOT EQUAL +0.                               
           MOVE TELEPHONE-TOLL-FREE (PHONE-INDEX-SAVE)                          
                                   TO WS-ELNE4-NUMBER.                          
                                                                                
           IF GGIGROUP-OFFICE = '15100' OR                                      
              GGIGROUP-OFFICE = '15160'                                         
              PERFORM BC-REINSTATE-DATE                                         
           ELSE                                                                 
              PERFORM RESET-REINSTATE-DATE.                                     
                                                                                
           MOVE LSTGROUP TO WS-GROUP.                                           
           MOVE LSTACCT  TO WS-ACCT.                                            
                                                                                
      *  READ FOR GIPSY MASTER TRAILER 040                                      
                                                                                
           MOVE SPACES    TO WS-E-CODE.                                         
GNE   *    MOVE WS-TRL030 TO GBNTRIDENT.                                        
GNE        MOVE '030' TO WS-TRAILER-030-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-030                                
GNE                              WS-E-CODE.                                     
           IF WS-E-CODE EQUAL SPACES                                            
GNE        MOVE WS-TRAILER-030-REC   TO  GMBNATR                                
GNE   *         NEXT SENTENCE                                                   
           ELSE                                                                 
                MOVE WS-E-CODE TO E-CODE                                        
                PERFORM ERR-RTN                                                 
                GO TO ERPTLNE8.                                                 
GNE        CALL GZNAEXP7 USING GMBNATR                                          
GNE                              WS-NAEXP                                       
GNE                              WS-E-CODE.                                     
           IF WS-E-CODE EQUAL SPACES                                            
                                     NEXT SENTENCE                              
           ELSE                                                                 
                MOVE WS-E-CODE TO E-CODE                                        
                PERFORM ERR-RTN                                                 
                   GO TO ERPTLNE8.                                              
                                                                                
           MOVE WS-NALBL (+1) TO WS-NAME.                                       
                                                                                
      *************************************************************             
       ERPTLNE8.                                                                
      *************************************************************             
                                                                                
      * READ GIPSY MASTER GENERAL INFO. TRAILER                                 
      * FOR GFO, BRANCH AND BILLING-AGENT                                       
                                                                                
           MOVE SPACES    TO E-CODE.                                            
GNE   *    MOVE WS-TRL000 TO GMGENTR.                                           
GNE        MOVE '000' TO WS-TRAILER-000-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-000                                
GNE                              WS-E-CODE.                                     
           IF WS-E-CODE EQUAL SPACES                                            
GNE        MOVE  WS-TRAILER-000-REC  TO  GMGENTR                                
GNE   *                           NEXT SENTENCE                                 
           ELSE                                                                 
                 MOVE WS-E-CODE TO E-CODE                                       
                 PERFORM ERR-RTN                                                
                 GO TO ERPTLNE10.                                               
                                                                                
      * READ AGENT FILE FOR AGENT NAME USING BILLING-AGENT                      
      * NUMBER FROM MASTER RECORD                                               
                                                                                
           MOVE GGIBILLING-AGENT TO GFMAGENT-CODE.                              
           MOVE '0'              TO GFMAGENT-ACCOUNT.                           
           MOVE 'GETRAN'         TO GFMAGENT-FUNCTION.                          
           CALL 'GFMAGENT'  USING   GFMAGENT-FUNCTION                           
                                    GFMAGENT-ERROR                              
                                    AGENT-NAME-FILE                             
                                    GFMAGENT-KEY.                               
           IF GFMAGENT-ERROR EQUAL LOW-VALUES                                   
               MOVE AGT-NAME      TO WS-AGT                                     
           ELSE                                                                 
               MOVE SPACES        TO WS-AGT.                                    
                                                                                
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+2) TO WS-ATTN.                                   
           MOVE SPACES            TO E-CODE.                                    
                                                                                
      * SET UP THE NEW ERROR-FIELDS   PCODE AND GFO                             
                                                                                
           MOVE GGIPRODUCT-CODE TO E-PROD-CD.                                   
           MOVE GGIGROUP-OFFICE TO E-OFFICE.                                    
           MOVE GGIGROUP-OFFICE TO WS-BRANCH.                                   
                                                                                
      *************************************************************             
       ERPTLNE10.                                                               
      *************************************************************             
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+3) TO WS-ADDR1.                                  
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+4) TO WS-ADDR2.                                  
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+5) TO WS-ADDR3.                                  
           CALL 'QDATE' USING WS-QDATE-AD                                       
                              LSTCUR-DATE                                       
                              WS-ELNE12-DATE.                                   
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+6) TO WS-ADDR4.                                  
                                                                                
           PERFORM 150-CALCS THRU 150-CALCS-EXIT.                               
                                                                                
           IF WS-TOTAL LESS THAN ZERO                                           
              OR WS-TOTAL = 0                                                   
              OR WS-PREM-OVD-TOTAL LESS THAN ZERO                               
              OR WS-PREM-OVD-TOTAL = 0                                          
              GO TO FILE-INPUT-READ.                                            
                                                                                
           MOVE WS-TOTAL          TO WS-AMT-TOT.                                
           MOVE WS-PREM-CUR-TOTAL TO WS-AMT-CUR.                                
           MOVE WS-PREM-OVD-TOTAL TO WS-AMT-OVD.                                
                                                                                
      *  print all 27 lines to form lapse notice                                
           MOVE SPACES        TO WS-RPT-TEXT.                                   
           MOVE WS-SKIP-CHAN1 TO WS-RPT-CC.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '0'           TO WS-RPT-CC.                                     
           MOVE SPACES        TO WS-RPT-TEXT.                                   
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '0'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '0'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-1  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE ' '         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-2  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-3  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-4  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-5  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-6  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-7  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '-'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-8  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '+'         TO WS-RPT-CC.                                       
           MOVE ENG-LINE-8  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '-'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-9  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-10 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-11 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-12 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-13 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-14 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-15 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-16 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-17 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-18 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-19 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-20 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-21 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-22 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-23 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-24 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-25 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-26 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE ENG-LINE-27 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
      *************************************************************             
       FILE-INPUT-READ.                                                         
      *************************************************************             
           CALL 'DLSREAD' USING  TAPE-SYS014                                    
                                 TAPE-RETURN                                    
                                 TAPE-SYS014-RECORD                             
                                 TAPE-SYS014-RECSIZE                            
                                 TAPE-SYS014-BLKSIZE                            
                                 TAPE-SYS014-FORMAT                             
                                 TAPE-SYS014-COUNT.                             
           IF TAPE-RETURN NOT EQUAL ZEROS                                       
           OR  TAPE-SYS014-TYPE NOT EQUAL '6'                                   
                   GO TO END-OPERATIONS.                                        
           MOVE TAPE-SYS014-RECORD TO LAPSE-NOTICE-RECORD.                      
                                                                                
FDEFT *->  BYPASS IF EFT PARTICIPANT                                            
                                                                                
FDEFT      PERFORM CHECK-PAD-REQUEST.                                           
FDEFT      IF REQ-PAD-IN-EFFECT                                                 
FDEFT      OR REQ-PAD-SUSPENDED THEN                                            
FDEFT *->      BYPASS                                                           
FDEFT          DISPLAY LSTGROUP '-' LSTACCT ' BYPASSED!, STATUS: '              
FDEFT                  REQ-STATUS                                               
FDEFT          GO TO FILE-INPUT-READ                                            
FDEFT      ELSE                                                                 
FDEFT *->      NOT A QUALIFYING EFT CLIENT, PROCESS NORMALLY                    
FDEFT          NEXT SENTENCE.                                                   
                                                                                
           IF LSTFORM NOT EQUAL TO WS-FORMS                                     
             AND LSM-RFORM OF SAVE-RESTART NOT EQUAL TO SPACE                   
               IF  GO-TO-SW EQUAL +4                                            
                   GO TO END-OPERATIONS                                         
               ELSE                                                             
                   GO TO FORMS-MOUNTED                                          
           ELSE                                                                 
               GO TO LAPSE-NOTICE.                                              
                                                                                
      *************************************************************             
       PRINT-ROUTINE.                                                           
      *************************************************************             
           IF LSTFORM EQUAL WS-ENGLISH                                          
              CALL 'DLSWRITE' USING WS-SYS058                                   
                                    PRINT-RETURN                                
                                    WS-REPORT-AREA                              
                                    PRINT-RECSIZE                               
                                    PRINT-BLKSIZE                               
                                    PRINT-FORMAT                                
                                    WS-PRINT-SYS058-COUNT                       
           ELSE                                                                 
              CALL 'DLSWRITE' USING WS-SYS059                                   
                                    PRINT-RETURN                                
                                    WS-REPORT-AREA                              
                                    PRINT-RECSIZE                               
                                    PRINT-BLKSIZE                               
                                    PRINT-FORMAT                                
                                    WS-PRINT-SYS059-COUNT.                      
      *************************************************************             
       BC-REINSTATE-DATE.                                                       
      *************************************************************             
           MOVE LSM-HIDATE        TO WSCP3-HIDATE.                              
           ADD WSCP3-17           TO WSCP3-HIDAY.                               
           IF WSCP3-HIDAY GREATER WSCP3-365                                     
               SUBTRACT WSCP3-365 FROM WSCP3-HIDAY                              
               ADD WSCP3-1        TO WSCP3-HIYR.                                
           CALL 'QDATE' USING WS-QDATE-AD                                       
                              WSCP3-HIDATE                                      
                              WS-ELNE6-DATE.                                    
           CALL 'QDATE' USING WS-QDATE-AF                                       
                              WSCP3-HIDATE                                      
                              WS-FLNE17-DATE.                                   
                                                                                
      *************************************************************             
       RESET-REINSTATE-DATE.                                                    
      *************************************************************             
           MOVE LSM-HIDATE        TO WSCP3-HIDATE.                              
           ADD WSCP3-14           TO WSCP3-HIDAY.                               
           IF WSCP3-HIDAY GREATER WSCP3-365                                     
               SUBTRACT WSCP3-365 FROM WSCP3-HIDAY                              
               ADD WSCP3-1        TO WSCP3-HIYR.                                
           CALL 'QDATE' USING WS-QDATE-AD                                       
                              WSCP3-HIDATE                                      
                              WS-ELNE6-DATE.                                    
           CALL 'QDATE' USING WS-QDATE-AF                                       
                              WSCP3-HIDATE                                      
                              WS-FLNE17-DATE.                                   
                                                                                
      *************************************************************             
       PHONE-SEARCH.                                                            
      ******************************************************************        
      *    TABLE SEARCH FOR PHONE NUMBERS. CLAIMS OFFICE/GFO ARE KEYS.          
      *    NOTE: LAST TABLE ENTRY HAS CLAIMS OFFICE = '*****' AND               
      *          GFO = '*****' WHICH GUARANTEES A MATCH AND IS USED             
      *          AS THE SEARCH DEFAULT.                                         
      ******************************************************************        
                                                                                
NAL        IF (TELEPHONE-CLMS-OFF (PHONE-INDEX) = WS-PHONE-CLAIMS-OFFICE        
            OR TELEPHONE-CLMS-OFF (PHONE-INDEX) = '*****' )                     
           AND                                                                  
NAL           (TELEPHONE-GFO (PHONE-INDEX)      = WS-PHONE-GROUP-OFFICE         
            OR TELEPHONE-GFO (PHONE-INDEX)      = '*****' )                     
           THEN                                                                 
                   MOVE PHONE-INDEX TO PHONE-INDEX-SAVE                         
           .                                                                    
           ADD  +1                  TO PHONE-INDEX.                             
       PHONE-SEARCH-EXIT.                                                       
           EXIT.                                                                
                                                                                
      * BUILD FRENCH LAPSE NOTICE                                               
      *************************************************************             
       FRENCH-VERSION.                                                          
      *************************************************************             
                                                                                
           ADD +1             TO ACCUM-LAPSE-FR.                                
           CALL 'QDATE' USING WS-QDATE-AF                                       
                              LSTOVDUE-DATE                                     
                              WS-FLNE3-DATE.                                    
                                                                                
           MOVE WS-FLNE3-DATE    TO   OLD-FORMAT-DATE                           
           PERFORM REFORMAT-DATE THRU REFORMAT-EXIT.                            
           MOVE REFORMATTED-DATE TO   WS-FLNE16-DATE.                           
                                                                                
      *    ADDED THE NEXT CALL TO GET THE CORRECT INFORMATION FROM GIPSY        
      *    BEFORE SEARCHING FOR THE PHONE NUMBER              M BURTON          
                                                                                
           MOVE SPACES    TO E-CODE.                                            
GNE   *    MOVE WS-TRL000 TO GMGENTR.                                           
GNE        MOVE '000' TO WS-TRAILER-000-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-000                                
GNE                              WS-E-CODE.                                     
           IF WS-E-CODE EQUAL SPACES                                            
GNE        MOVE  WS-TRAILER-000-REC  TO  GMGENTR                                
GNE   *                           NEXT SENTENCE                                 
           ELSE                                                                 
              PERFORM ERR-RTN                                                   
              GO TO FRPTLNE8.                                                   
           MOVE +0        TO PHONE-INDEX-SAVE.                                  
           MOVE +1        TO PHONE-INDEX.                                       
                                                                                
NAL   *    CHECK TLU111 TO DETERMINE NAL GROUPS                                 
NAL   *    DURING CONVERSION, USE SPECIAL NAL/PAL TOLL FREE NUMBER              
NAL   *    CLAIM OFFICE = 99999 AND GFO = 99999 IF FRENCH /                     
NAL   *    GFO = ***** IF ENGLISH                                               
                                                                                
NAL        MOVE GGIGROUP-OFFICE    TO WS-PHONE-GROUP-OFFICE.                    
NAL        MOVE GGICLAIMS-OFFICE   TO WS-PHONE-CLAIMS-OFFICE.                   
NAL                                                                             
NAL        MOVE GGIGROUP-NUMBER    TO TLU111-GROUP                      06720034
GNE        CALL TLUCOBD USING     TLU111-ERRIND                                 
GNE                                TLU111-SEARCH-ARGUMENT                       
GNE                                TLU111-TABLE-NUM                             
GNE                                TLU111-CII-EFF-DATE                          
GNE                                TLU111-GROUP-EFF-DATE.                       
                                                                        04240000
NAL        IF TLU111-ERRIND = SPACE                                     04250000
ZUR1          IF    GGIGROUP-NUMBER > 0050999                                   
ZUR1            AND GGIGROUP-NUMBER < 0060000                                   
ZUR1          THEN                                                              
ZUR1             NEXT SENTENCE                                                  
ZUR1          ELSE                                                              
ZUR1             MOVE '99999'      TO WS-PHONE-CLAIMS-OFFICE                    
ZUR1             IF GGIRESIDENCE = '01' OR GGILANGUAGE  = 'F'                   
ZUR1                MOVE '99999'   TO WS-PHONE-GROUP-OFFICE                     
ZUR1             ELSE                                                           
ZUR1                MOVE '*****'   TO WS-PHONE-GROUP-OFFICE                     
ZUR1       .                                                                    
                                                                                
GBSS  *                                                                         
GBSS  *    GBSS TASK 37699 - USE ENGLISH OR FRENCH TOLL FREE                    
GBSS  *    CLAIM OFFICE = 99999 AND GFO = 99999 IF FRENCH /                     
GBSS  *    CLAIM OFFICE = 99999 AND GFO = ***** IF ENGLISH                      
GBSS  *                                                                         
GBSS       MOVE '99999'             TO WS-PHONE-CLAIMS-OFFICE.                  
GBSS         IF GGILANGUAGE  = 'F'                                              
GBSS            MOVE '99999'          TO WS-PHONE-GROUP-OFFICE                  
GBSS         ELSE                                                               
GBSS            MOVE '*****'          TO WS-PHONE-GROUP-OFFICE.                 
                                                                                
           PERFORM PHONE-SEARCH THRU                                            
                   PHONE-SEARCH-EXIT UNTIL                                      
                   PHONE-INDEX-SAVE NOT EQUAL +0.                               
           MOVE TELEPHONE-TOLL-FREE (PHONE-INDEX-SAVE)                          
                                   TO WS-FLNE4-NUMBER.                          
                                                                                
           MOVE SPACES   TO WS-RPT-TEXT.                                        
           MOVE LSTGROUP TO WS-GROUP-F.                                         
           MOVE LSTACCT  TO WS-ACCT-F.                                          
                                                                                
      *    READ FOR GIPSY MASTER TRAILER 040                                    
                                                                                
           MOVE SPACES    TO WS-E-CODE.                                         
           MOVE SPACES    TO WS-RPT-TEXT.                                       
GNE   *    MOVE WS-TRL030 TO GBNTRIDENT.                                        
GNE        MOVE '030' TO WS-TRAILER-030-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-030                                
GNE                              WS-E-CODE.                                     
           IF WS-E-CODE EQUAL SPACES                                            
GNE        MOVE WS-TRAILER-030-REC   TO  GMBNATR                                
GNE   *                              NEXT SENTENCE                              
           ELSE                                                                 
                MOVE WS-E-CODE TO E-CODE                                        
                PERFORM ERR-RTN                                                 
                   GO TO FRPTLNE8.                                              
GNE        CALL GZNAEXP7 USING GMBNATR                                          
GNE                              WS-NAEXP                                       
GNE                              WS-E-CODE.                                     
           IF WS-E-CODE EQUAL SPACES                                            
                                     NEXT SENTENCE                              
           ELSE                                                                 
                MOVE WS-E-CODE TO E-CODE                                        
                PERFORM ERR-RTN                                                 
                   GO TO FRPTLNE8.                                              
           MOVE WS-NALBL (+1)  TO WS-NAME-F.                                    
                                                                                
      *************************************************************             
       FRPTLNE8.                                                                
      *************************************************************             
                                                                                
      * READ GIPSY MASTER GENERAL INFO. TRAILER                                 
      * FOR GFO, BRANCH AND BILLING-AGENT                                       
                                                                                
           MOVE SPACES    TO E-CODE.                                            
GNE   *    MOVE WS-TRL000 TO GMGENTR.                                           
GNE        MOVE '000' TO WS-TRAILER-000-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-000                                
GNE                              WS-E-CODE.                                     
           IF E-CODE EQUAL SPACES                                               
GNE        MOVE  WS-TRAILER-000-REC  TO  GMGENTR                                
GNE   *                           NEXT SENTENCE                                 
           ELSE                                                                 
              MOVE  WS-E-CODE TO E-CODE                                         
                 PERFORM ERR-RTN                                                
                 GO TO ERPTLNE10.                                               
                                                                                
      * FINISHED SEARCH MASTER RECORD FOR LINES 9 AND 10                        
                                                                                
      * READ AGENT FILE FOR AGENT NAME USING BILLING-AGENT                      
      * NUMBER FROM MASTER RECORD                                               
                                                                                
           MOVE GGIBILLING-AGENT    TO GFMAGENT-CODE.                           
           MOVE '0'                 TO GFMAGENT-ACCOUNT.                        
           MOVE 'GETRAN'            TO GFMAGENT-FUNCTION.                       
           CALL 'GFMAGENT'   USING     GFMAGENT-FUNCTION                        
                                       GFMAGENT-ERROR                           
                                       AGENT-NAME-FILE                          
                                       GFMAGENT-KEY.                            
           IF GFMAGENT-ERROR EQUAL LOW-VALUES                                   
               MOVE AGT-NAME      TO WS-AGT-F                                   
           ELSE                                                                 
               MOVE SPACES        TO WS-AGT-F.                                  
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+2) TO WS-ATTN-F.                                 
           MOVE SPACES            TO E-CODE.                                    
                                                                                
           MOVE GGIGROUP-OFFICE   TO WS-BRANCH-F.                               
                                                                                
      *************************************************************             
       FRPTLNE10.                                                               
      *************************************************************             
           MOVE SPACES            TO WS-RPT-TEXT.                               
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+3) TO WS-ADDR1-F.                                
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+4) TO WS-ADDR2-F.                                
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+5) TO WS-ADDR3-F.                                
           CALL 'QDATE' USING WS-QDATE-AF                                       
                              LSTCUR-DATE                                       
                              WS-FLNE12-DATE.                                   
           MOVE SPACES        TO WS-RPT-TEXT.                                   
           IF WS-E-CODE EQUAL SPACES                                            
               MOVE WS-NALBL (+6) TO WS-ADDR4-F.                                
                                                                                
           PERFORM 150-CALCS THRU 150-CALCS-EXIT.                               
                                                                                
           IF WS-TOTAL LESS THAN ZERO                                           
              OR WS-TOTAL EQUAL ZERO                                            
              OR WS-PREM-OVD-TOTAL LESS THAN ZERO                               
              OR WS-PREM-OVD-TOTAL = 0                                          
              GO TO FILE-INPUT-READ.                                            
                                                                                
           DIVIDE WS-PREM-CUR-TOTAL BY +1 GIVING WS-AMT-CUR-WHOLE-F             
                    REMAINDER WS-AMT-CUR-DECIMAL-F.                             
           DIVIDE WS-TOTAL BY +1 GIVING WS-AMT-TOT-WHOLE-F                      
                    REMAINDER WS-AMT-TOT-DECIMAL-F.                             
           DIVIDE WS-PREM-OVD-TOTAL BY +1 GIVING WS-AMT-OVD-WHOLE-F             
                    REMAINDER WS-AMT-OVD-DECIMAL-F.                             
                                                                                
      *  print all 27 lines to form lapse notice                                
           MOVE WS-SKIP-CHAN1 TO WS-RPT-CC.                                     
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '0'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '0'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '0'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-1  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE ' '         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-2  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-3  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-4  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-5  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-6  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-7  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '-'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-8  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '+'         TO WS-RPT-CC.                                       
           MOVE FRE-LINE-8  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE '-'         TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-9  TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-10 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-11 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-12 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-13 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-14 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-15 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-16 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-17 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-18 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-19 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-20 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-21 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-22 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-23 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-24 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-25 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-26 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-27 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-28 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE SPACES      TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           MOVE SPACES      TO WS-RPT-CC.                                       
           MOVE FRE-LINE-29 TO WS-RPT-TEXT.                                     
           PERFORM PRINT-ROUTINE.                                               
                                                                                
           GO TO FILE-INPUT-READ.                                               
                                                                                
      *************************************************************             
       ERR-RTN.                                                                 
      *************************************************************             
           MOVE LSTCOMP           TO E-NORM.                                    
                                                                                
      * NEXT LINES SET UP THE ERROR REPORT PCODE AND OFFICE MARCUS.             
                                                                                
           MOVE GGIPRODUCT-CODE   TO  E-PROD-CD.                                
           MOVE GGIGROUP-OFFICE   TO  E-OFFICE.                                 
                                                                                
           CALL 'DLSWRITE' USING  TAPE-SYS011                                   
                                  TAPE-RETURN                                   
                                  ERR-REC                                       
                                  TAPE-SYS011-RECSIZE                           
                                  TAPE-SYS011-BLKSIZE                           
                                  TAPE-SYS011-FORMAT                            
                                  TAPE-SYS011-COUNT.                            
           MOVE SPACES TO WS-E-CODE.                                            
                                                                                
      *************************************************************             
       END-OPERATIONS.                                                          
      *************************************************************             
           GOBACK.                                                              
           STOP RUN.                                                            
                                                                                
      *************************************************************             
       REFORMAT-DATE.                                                           
      *************************************************************             
           MOVE OLD-FORM-MON  TO  REFORMAT-MON.                                 
           MOVE OLD-FORM-YEAR TO  REFORMAT-YEAR.                                
           IF OLD-FORM-MON    =   'FEB' OR 'FEV'                                
               MOVE '28'      TO  REFORMAT-DAY                                  
               GO TO REFORMAT-EXIT.                                             
           IF OLD-FORM-MON    =   'SEP'  OR 'APR'  OR                           
                                  'JUN'  OR 'NOV'  OR                           
                                  'AVR'                                         
               MOVE '30'      TO  REFORMAT-DAY                                  
           ELSE                                                                 
               MOVE '31'      TO  REFORMAT-DAY.                                 
       REFORMAT-EXIT.                                                           
           EXIT.                                                                
                                                                                
      *************************************************************             
       100-LOOP-MPAY.                                                           
      *************************************************************             
                                                                                
           IF GPAPAY-AMOUNT (MPAY-SUB) IS NUMERIC                               
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE 'Y' TO WS-MPAY-END-SW.                                       
                                                                                
           IF GPAPAYMENT-DATE (MPAY-SUB) < WS-PREP-DATE OR                      
              GPAPAYMENT-DATE (MPAY-SUB) = WS-PREP-DATE                         
              GO TO 100-LOOP-MPAY-EXIT.                                         
                                                                                
           IF GPAPAYMENT-DATE (MPAY-SUB) > WS-PREP-DATE                         
              AND GPAPAYMENT-DATE (MPAY-SUB) < CURRDATE                         
              ADD GPAPAY-AMOUNT (MPAY-SUB) TO WS-MPAY-TOTAL.                    
                                                                                
       100-LOOP-MPAY-EXIT.                                                      
           EXIT.                                                                
                                                                                
      *************************************************************             
       150-CALCS.                                                               
      *************************************************************             
                                                                                
      * add the most current tax amount to the lapse notice total               
           MOVE SPACES    TO WS-E-CODE.                                         
           MOVE ZEROES    TO WS-TAX-H.                                          
GNE   *    MOVE WS-TRL080 TO GMBILTR.                                           
GNE        MOVE '080' TO WS-TRAILER-080-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-080                                
GNE                              WS-E-CODE.                                     
                                                                                
           MOVE ZEROES TO WS-PREM-CUR-TOTAL                                     
           MOVE 'N' TO WS-MBIL-END-SW.                                          
           IF WS-E-CODE EQUAL SPACES                                            
GNE           MOVE WS-TRAILER-080-REC   TO  GMBILTR                             
GNE           MOVE GBI-PREM-DUE (GBINO-HIST-SEG) TO WS-TOTAL                    
GNE           MOVE GBIHIST-ADMIN-FEE (GBINO-HIST-SEG) TO WS-TAX-H               
GNE           MOVE GBIHIST-PREPARED-YEAR (GBINO-HIST-SEG) TO                    
GNE                           PREP-YYY                                          
GNE           MOVE GBIHIST-PREPARED-DAY (GBINO-HIST-SEG) TO                     
GNE                           PREP-DDD                                          
              PERFORM 175-COVERAGE-CALCS THRU 175-COVERAGE-CALCS-EXIT           
                 VARYING MBIL-SUB FROM +1 BY +1                                 
                 UNTIL WS-MBIL-END-SW = 'Y' OR MBIL-SUB = +10                   
           ELSE                                                                 
              PERFORM ERR-RTN.                                                  
                                                                                
      * subtract payments from the total amount                                 
           MOVE SPACES    TO WS-E-CODE.                                         
GNE   *    MOVE WS-TRL090 TO GMPAYTR.                                           
GNE        MOVE '090' TO WS-TRAILER-090-IDENT.                                  
GNE        CALL GZACCMT7 USING LSTCOMP                                          
GNE                              MASTER-VSAM-090                                
GNE                              WS-E-CODE.                                     
                                                                                
           MOVE 'N' TO WS-MPAY-END-SW.                                          
           MOVE ZEROES TO WS-MPAY-TOTAL.                                        
      * Loop thru MPAY to find payments between prep date and run date          
           IF WS-E-CODE EQUAL SPACES                                            
GNE           MOVE WS-TRAILER-090-REC   TO  GMPAYTR                             
              PERFORM 100-LOOP-MPAY THRU 100-LOOP-MPAY-EXIT                     
                 VARYING MPAY-SUB FROM +1 BY +1                                 
                 UNTIL WS-MPAY-END-SW = 'Y' OR MPAY-SUB = +60                   
           ELSE                                                                 
              PERFORM ERR-RTN.                                                  
                                                                                
      *  Calculations for Output fields                                         
      *  add ws-mpay-total to ws-total because #'s stored as negative           
           ADD WS-MPAY-TOTAL TO WS-TOTAL.                                       
           ADD WS-TAX-H TO WS-PREM-CUR-TOTAL.                                   
           SUBTRACT WS-PREM-CUR-TOTAL FROM WS-TOTAL                             
                GIVING WS-PREM-OVD-TOTAL.                                       
                                                                                
       150-CALCS-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *************************************************************             
       175-COVERAGE-CALCS.                                                      
      *************************************************************             
                                                                                
           IF  GBIAMT-BILLED (GBINO-HIST-SEG , MBIL-SUB) IS NUMERIC             
              ADD GBIAMT-BILLED (GBINO-HIST-SEG , MBIL-SUB) TO                  
                             WS-PREM-CUR-TOTAL                                  
           ELSE                                                                 
              MOVE 'Y' TO WS-MBIL-END-SW.                                       
                                                                                
       175-COVERAGE-CALCS-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *************************************************************             
FDEFT  CHECK-PAD-REQUEST.                                                       
FDEFT ******************************************************************        
FDEFT *     SET ALL KEY PARMS AND                                               
FDEFT *     CALL THE PAD REQUEST PROGRAM VIA GWEFCPDX MODULE                    
FDEFT ******************************************************************        
FDEFT      MOVE 'GIPSY'         TO REQ-SOURCE.                                  
FDEFT      MOVE 'PREMIUM'       TO REQ-FUNCTION.                                
FDEFT      MOVE '********'      TO REQ-PROD-LINE.                               
FDEFT      MOVE '**'            TO REQ-ADMIN-TYPE.                              
FDEFT      MOVE 'GRPA'          TO REQ-KEY-TYPE.                                
FDEFT      MOVE LSTGROUP        TO PAD-GROUP.                                   
FDEFT      MOVE LSTACCT         TO PAD-ACCOUNT.                                 
FDEFT      MOVE PAD-KEY-DATA    TO REQ-KEY-DATA.                                
FDEFT      MOVE  ZERO           TO REQ-EFF-DATE-IN.                             
FDEFT      MOVE  ZERO           TO REQ-AMOUNT.                                  
FDEFT      MOVE 'I'             TO REQ-REASON-CODE.                             
FDEFT      MOVE 'CQGPPDEP'      TO REQ-ENTRY-ID.                                
FDEFT      MOVE SPACES          TO REQ-MAINTAINER-ID.                           
FDEFT      CALL GWEFCPDR     USING PAD-REQUEST.                                 
FDEFT  CHECK-PAD-REQUEST-EXIT.                                                  
FDEFT      EXIT.                                                                
