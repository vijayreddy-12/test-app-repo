       IDENTIFICATION DIVISION.                                                 
FXXTOK   PROGRAM-ID. GC2PRGSL.                                                  
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *  DATE-COMPILED.                                                         
      *---------------------------------------------------------------*         
      * COMMISSIONS DATABASE PURGE PROCESSING - SELECTION PROGRAM     *         
      *      THIS PROGRAM IDENTIFIES THE GROUPS IN COMMISSIONS D/B    *         
      * WHICH DO NOT EXIST ON THE VCM OR GIPSY MASTER.                *         
      * A SELECTION CARD IS GENERATED FOR THESE GROUPS.               *         
      *---------------------------------------------------------------*         
      * DDNAME    DESCRIPTION                                         *         
      *  GWCOMP01  COMMISSION DATABASE AREA 1 - READ ONLY   <LOCAL>   *         
      *  VSDSI83   VCM                      - READ ONLY               *         
      *  GACBMAS   GIPSY MASTER             - READ ONLY               *         
      *  DLSO20    CONTROL CARD OUTPUT FILE - OUTPUT                  *         
      *---------------------------------------------------------------*         
      * DATE     USERID     DESCRIPTION                                         
      *                                                                         
      *    JUN93  TRUDY     PROGRAM CREATED                                     
      *                                                                         
      *    FEB03  BEAUBIB   CONVERT TO COBOL II                                 
      *                     BRING UP TO CURRENT STANDARD.  IE GAEDATSR          
      *                                                                         
      *    JUL/2005  R. KNAUD.                                                  
      *         - HUB:  COMM GMASTER ROUTER (VOCOMM VCM/GIPSY)                  
      *                  USE VOGPWRA7 TO READ THE VCM AND GIPSY                 
      *                  MASTER FILES.                                          
      *                                                                         
      *    OCT/2008  IBM      - ENTERPRISE COMPILER UPGRADE                     
      *---------------------------------------------------------------*         
       EJECT                                                                    
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES COPRGSEL          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
                                                                                
      *---------------------------------------------------------------*         
      * GWCOMP01-COMMISSIONS DATABASE AREA 1 ONLY **                  *         
      *---------------------------------------------------------------*         
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2PRGSL WS BEGINS HERE**'.                                  
                                                                                
       01  DYNAMIC-PROGRAMS.                                                    
           05  GAEDATSR                PIC X(8)       VALUE 'GAEDATSR'.         
      * VOCOMM VCM/GIPSY                                                        
           05  VOGPWRA7                PIC X(8)       VALUE 'VOGPWRA7'.         
           05  GWCDUMP                 PIC X(8)       VALUE 'GWCDUMP'.          
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
                                                                                
       01  DYNAMIC-STORAGE.                                                     
           05  WS-DUMP-2               PIC X(1)  VALUE '2'.                     
FXXTOK     05  WS-PROGRAM-NAME         PIC X(8)  VALUE 'GC2PRGSL'.              
                                                                                
       01  RECORD-COUNTS.                                                       
           05  WS-COUNT                PIC S9(8) COMP VALUE ZERO.               
           05  WS-PURGE                PIC S9(8) COMP VALUE ZERO.               
                                                                                
      * VOCOMM VCM/GIPSY                                                        
       01  VOGPWRA7-PROTOCOL.                                                   
                                        COPY VOGPWCIO.                          
       01  VOGPW-DATA-RECORD            PIC X(15700).                           
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'OUTPUT-RECORD                   '.                                  
                                                                                
       01  OUTPUT-RECORD.                                                       
FXXTOK     05  OUTPUT-PROGRAM-NAME     PIC X(8)  VALUE 'GC2PRGSL'.              
           05  FILLER                  PIC X(1)  VALUE SPACE.                   
           05  OUTPUT-GROUP-7.                                                  
               10 FILLER               PIC 9(2)  VALUE ZEROES.                  
               10 OUTPUT-GROUP-5       PIC 9(5).                                
           05  FILLER                  PIC X(64) VALUE SPACES.                  
                                                                                
      *---------------------------------------------------------------*         
      *          DATASERVER RECORDS                                   *         
      *---------------------------------------------------------------*         
       01  PRINT-DATA-020       PIC X(80).                                      
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
      *---------------------------------------------------------------*         
      *         DATABASE - SUBSCHEMA DESCRIPTION                      *         
      *---------------------------------------------------------------*         
                                                                                
       01  FILLER                   PIC X(32)         VALUE                     
           'SUBSCHEMA-CONTROL               '.                                  
                                                                                
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      *---------------------------------------------------------------*         
      * COMMISSIONS DATABASE RECORDS                                  *         
      *---------------------------------------------------------------*         
       01  FILLER                   PIC X(32)         VALUE                     
           'GWCORGROUP                      '.                                  
      * GWCORGROUP                                                              
CPYNME     COPY GCIGROUP.                                                       
                                                                                
       01  WS-END.                                                              
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2PRGSL WS ENDS HERE  **'.                                  
                                                                                
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2PRGSL'         TO FCCSPL-CURR-PGM.                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
           PERFORM 100-INITIALIZE THRU 100-INITIALIZE-EXIT.                     
                                                                                
      *---------------------------------------------------------------*         
      * SWEEP FOR ALL GROUP RECORDS                                             
      *---------------------------------------------------------------*         
           PERFORM 200-PROCESS-GROUPS                                           
              THRU 200-PROCESS-GROUPS-EXIT                                      
             UNTIL DB-END-OF-SET.                                               
                                                                                
      *---------------------------------------------------------------*         
      * TERMINATION:   DISPLAY INPUT/OUTPUT COUNTS                    *         
      *                CLOSE ALL FILES                                *         
      *---------------------------------------------------------------*         
           DISPLAY 'NUMBER OF GROUP RECORDS READ ' WS-COUNT.                    
           DISPLAY 'NUMBER OF GROUPS SELECTED    ' WS-PURGE.                    
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  CLOSE FILES (VCM/GIPSY FILES)                                          
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-CLOSE-FILES    TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 250-READ-VCM-GIPSY THRU 250-READ-VCM-GIPSY-EXIT.             
                                                                                
           CALL GAEDATSR    USING FINISH-LR                                     
                                  PRINT-DATA-020                                
                                  ICBM.                                         
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           MOVE ZERO TO RETURN-CODE.                                            
           STOP RUN.                                                            
                                                                                
       100-INITIALIZE.                                                          
      *---------------------------------------------------------------*         
      * INITIALIZE:  INITIATE IDMS ENVIRONMENT                                  
      *              GET FIRST GROUP RECORD                                     
      *---------------------------------------------------------------*         
      *    COPY IDMS SUBSCHEMA-BINDS.                                           
      *%   BIND  RUN-UNIT.                                                      
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND  GWCORGROUP.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           MOVE LOW-VALUES                TO LINKAGE-CONTROL.                   
           MOVE WS-PROGRAM-NAME           TO ICBM-PROGRAM-NAME                  
                                             OUTPUT-PROGRAM-NAME.               
      * VOCOMM VCM/GIPSY                                                        
      *  OPEN FILES (VCM/GIPSY FILES)                                           
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-OPEN-FILES     TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE 0                  TO VGWI-GROUP.                               
           MOVE SPACES             TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 250-READ-VCM-GIPSY THRU 250-READ-VCM-GIPSY-EXIT.             
                                                                                
      *%   OBTAIN FIRST GWCORGROUP WITHIN GW-COMP-AREA1.                        
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 5 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
                                                                                
       100-INITIALIZE-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
      * MAIN LINE ROUTINE - PROCESS COMMISSIONS GROUP RECORDS         *         
      *   -LOCATE THE VCM RECORD OR THE GIPSY MASTER RECORD FOR THE   *         
      *      CURRENT COMMISSION GROUP RECORD.                         *         
      *   -IF NO VCM OR GIPSY MASTER PRESENT, WRITE A PURGE  REQUEST  *         
      *---------------------------------------------------------------*         
       200-PROCESS-GROUPS.                                                      
           ADD +1 TO WS-COUNT.                                                  
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *  READ NEXT (VCM/GIPSY FILES)                                            
           INITIALIZE VOGPWRAP-OUTPUT                                           
                      VOGPW-DATA-RECORD.                                        
           SET VGWI-SOURCE-UNKNOWN TO TRUE.                                     
           SET VGWI-READ-NEXT-WG   TO TRUE.                                     
           SET VGWI-COV-ANY        TO TRUE.                                     
           MOVE GROUP-NUMBER OF GWCORGROUP                                      
                                   TO VGWI-GROUP.                               
           MOVE LOW-VALUES         TO VGWI-ACCOUNT.                             
           SET VGWI-LR-GIPSY-EXP   TO TRUE.                                     
           PERFORM 250-READ-VCM-GIPSY THRU 250-READ-VCM-GIPSY-EXIT.             
           IF VGWO-RET-CODE = '01'                                              
      *    READ-NEXT-WITHIN-GROUP END-OF-GROUP                                  
REN           MOVE GROUP-NUMBER OF GWCORGROUP TO OUTPUT-GROUP-7                 
              MOVE WS-PROGRAM-NAME            TO OUTPUT-PROGRAM-NAME            
              PERFORM 900-WRITE-RECORD THRU 900-WRITE-RECORD-EXIT               
           ELSE                                                                 
              IF VGWO-RET-CODE NOT < '90'                                       
      *       SEVERE ERROR                                                      
                 CALL GWCDUMP USING ICBM                                        
                                    GWRDUMP                                     
              END-IF                                                            
           END-IF.                                                              
                                                                                
      *%   OBTAIN NEXT GWCORGROUP WITHIN GW-COMP-AREA1                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-NEXT                                         
MAN02                 FCCSPLIO-GWCORGROUP                                       
MAN02                 FCCSPL-GWCORGROUP                                         
MAN02                 FCCSPL-GW-COMP-AREA1                                      
MAN02                 GWCORGROUP                                                
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
       200-PROCESS-GROUPS-EXIT.                                                 
           EXIT.                                                                
                                                                                
      * VOCOMM VCM/GIPSY                                                        
      *---------------------------------------------                            
       250-READ-VCM-GIPSY.                                                      
                                                                                
           CALL VOGPWRA7   USING VOGPWRA7-PROTOCOL                              
                                 VOGPW-DATA-RECORD.                             
                                                                                
       250-READ-VCM-GIPSY-EXIT.                                                 
           EXIT.                                                                
                                                                                
       900-WRITE-RECORD.                                                        
      *---------------------------------------------------------------*         
      * SUBROUTINE - GENERATE PURGE REQUEST CONTROL CARD              *         
      *---------------------------------------------------------------*         
           MOVE OUTPUT-RECORD         TO PRINT-DATA-020.                        
           MOVE 'PRINT-DATA-020'      TO LOGICAL-RECORD-NAME.                   
                                                                                
           CALL GAEDATSR          USING  STORE-LR                               
                                         PRINT-DATA-020                         
                                         ICBM.                                  
                                                                                
            IF NOT LR-STATUS-OK                                                 
               DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                       
            END-IF.                                                             
                                                                                
            INITIALIZE OUTPUT-RECORD.                                           
            ADD +1 TO WS-PURGE.                                                 
                                                                                
       900-WRITE-RECORD-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *---------------------------------------------------------------*         
      * SUBROUTINE - IDMS-DB STATUS CHECKING                          *         
      *---------------------------------------------------------------*         
      *COPY IDMS IDMS-STATUS.                                                   
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
