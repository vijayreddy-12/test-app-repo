       IDENTIFICATION DIVISION.                                                 
      *========================                                                 
                                                                                
FXXTOK PROGRAM-ID.     GC2RAR.                                                  
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
                                                                                
      *REMARKS.                                                                 
                                                                                
      **************************************************************            
      *PROGRAM OVERVIEW: TITLE - GWCOCRAR                                       
      *                                                                         
      *                 DESCRIPTION - PRINTS A REPORT FROM THE                  
      *                               MESSAGES CREATED IN GWCOCRAD              
      **************************************************************            
      *HISTORY:                                                                 
      *  DATE       PROGRAMMER             CHANGES                              
      *  NOV 10/86  HAMPTON    CREATION                                         
      **************************************************************            
      *                     COMMISSION RELEASE                     *            
      **************************************************************            
      *  SEP 90     NIKELSKI   CHANGE GROUP PAGE BREAK TO GFO      *            
      *                        NOT GROUP/ACCT                      *            
      *  SEP 08     IBMECU     ENTERPRISE COMPILER UPGRADE         *            
      **************************************************************            
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCRAR          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-STARTS.                                                           
           05  FILLER               PIC  X(32)        VALUE                     
FXXTOK         '** GC2RAR W-S STARTS HERE **'.                                  
       01  WS-PARAMETERS.                                                       
           05  WS-PAGE-NO            PIC S9(4) COMP-3 VALUE ZERO.               
           05  QDATE-FORMATC         PIC XX    VALUE 'AC'.                      
           05  WS-LINE-COUNT         PIC S9(4) COMP-3 VALUE ZERO.               
           05  WS-PREV-RPT-NO        PIC X.                                     
           05  WS-PREV-GFO           PIC X(5).                                  
           05  WTL-MESSAGE.                                                     
               10  WTL-MSG-LENGTH PIC S999  COMP-3 VALUE +80.                   
               10  WTL-MSG-CC     PIC X            VALUE '0'.                   
               10  FILLER         PIC X(4)         VALUE 'GFO='.                
               10  WTL-GFO-NUMBER     PIC X(5)     VALUE SPACES.                
               10  FILLER         PIC X(7)         VALUE 'GROUP='.              
REN            10  WTL-GROUP-NUMBER   PIC X(7)     VALUE SPACES.                
REN            10  FILLER         PIC X            VALUE SPACES.                
               10  FILLER         PIC X(9)         VALUE 'ACCOUNT='.            
               10  WTL-GROUP-ACCOUNT  PIC XXX      VALUE SPACES.                
REN            10  FILLER         PIC XX           VALUE SPACES.                
               10  WTL-ABEND-MSG  PIC X(41)        VALUE SPACES.                
      /                                                                         
       01  DLS-READ-PARMS.                                                      
           05  DLS-SYS010-SYSNUM    PIC X(6)          VALUE 'SYS010'.           
           05  DLS-SYS010-RETURN    PIC S9    COMP-3  VALUE ZERO.               
           05  DLS-SYS010-REC-SIZE  PIC 9(5)          VALUE 116.                
           05  DLS-SYS010-BLK-SIZE  PIC 9(5)          VALUE 27956.              
           05  DLS-SYS010-FORMAT    PIC XX            VALUE 'FB'.               
           05  DLS-SYS010-REC-COUNT PIC S9(7) COMP-3  VALUE ZERO.               
                                                                                
       01  WS-RECORD-IN.                                                        
           05  WS-RPT-NO-IN         PIC X.                                      
           05  WS-GFO-IN            PIC X(5).                                   
           05  WS-GR-ACCT-IN.                                                   
REN            10  WS-GR-IN         PIC X(7).                                   
               10  WS-ACCT-IN       PIC X(3).                                   
           05  WS-MSG-IN            PIC X(100).                                 
       01  FILLER      REDEFINES WS-RECORD-IN.                                  
REN        05  FILLER               PIC X(16).                                  
           05  WS-DATE-IN.                                                      
               10  FILLER           PIC S9(3) COMP-3.                           
               10  FILLER           PIC S9(3) COMP-3.                           
           05  FILLER               PIC X(96).                                  
      /                                                                         
       01  DLS-WRITE-PARMS.                                                     
           05  DLS-SYS020-SYSNUM    PIC X(6)          VALUE 'SYS020'.           
           05  DLS-SYS020-RETURN    PIC S9    COMP-3  VALUE ZERO.               
           05  DLS-SYS020-REC-SIZE  PIC 9(5)          VALUE 133.                
           05  DLS-SYS020-BLK-SIZE  PIC 9(5)          VALUE 3990.               
           05  DLS-SYS020-FORMAT    PIC XX            VALUE 'FB'.               
           05  DLS-SYS020-REC-COUNT PIC S9(7) COMP-3  VALUE ZERO.               
      /                                                                         
       01  WS-EXCEPTION-REPORT.                                                 
           05  WS-REPORT-HEADING.                                               
               10  FILLER              PIC X          VALUE '1'.                
FXXTOK         10  FILLER              PIC X(12)      VALUE 'GC2RAR'.           
               10  FILLER              PIC X(34)      VALUE SPACES.             
               10  FILLER              PIC X(39)      VALUE                     
               'ANNUALIZED COMMISSIONS REPORT (RENEWAL)'.                       
               10  FILLER              PIC X(27)      VALUE SPACES.             
               10  WS-RPT-DATE         PIC X(7)       VALUE SPACES.             
               10  FILLER              PIC X(4)       VALUE SPACES.             
               10  FILLER              PIC X(5)       VALUE 'PAGE '.            
               10  WS-RPT-PAGE-NO      PIC ZZZ9.                                
                                                                                
           05  WS-ACTION-HEADING.                                               
               10  FILLER              PIC X          VALUE '-'.                
               10  FILLER              PIC X(12)      VALUE                     
               'ACTION ITEMS'.                                                  
                                                                                
           05  WS-ACTION-UNDERSCORE.                                            
               10  FILLER              PIC X          VALUE SPACES.             
               10  FILLER              PIC X(12)      VALUE                     
               '------------'.                                                  
                                                                                
           05  WS-INFORMATION-HEADING.                                          
               10  FILLER              PIC X          VALUE '-'.                
               10  FILLER              PIC X(17)      VALUE                     
               'INFORMATION ITEMS'.                                             
                                                                                
           05  WS-INFORMATION-UNDERSCORE.                                       
               10  FILLER              PIC X          VALUE SPACES.             
               10  FILLER              PIC X(17)      VALUE                     
               '-----------------'.                                             
                                                                                
           05  WS-RPT-DETAIL-LINE.                                              
               10  FILLER              PIC X         VALUE '0'.                 
               10  WS-RPT-DETAILS.                                              
                   15  WS-GFO-OUT      PIC X(5).                                
                   15  FILLER          PIC X(3)      VALUE SPACES.              
REN                15  WS-GR-ACCT-OUT  PIC X(10).                               
                   15  FILLER          PIC X(2)      VALUE SPACES.              
                   15  WS-MSG-OUT      PIC X(110).                              
                                                                                
           05  WS-NO-ACTION-MSG.                                                
               10  FILLER              PIC X          VALUE '-'.                
               10  FILLER              PIC X(34)      VALUE                     
               'NO ACTION MESSAGES FOR THIS REPORT'.                            
                                                                                
           05  WS-NO-INFO-MSG.                                                  
               10  FILLER              PIC X          VALUE '-'.                
               10  FILLER              PIC X(39)      VALUE                     
               'NO INFORMATION MESSAGES FOR THIS REPORT'.                       
                                                                                
           05  WS-LINE-OUT             PIC X(133).                              
       01  WS-ENDS                            PIC  X(32)  VALUE                 
           'WORKING STORAGE ENDS HERE'.                                         
      /                                                                         
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  QDATEQ2                 PIC X(8)       VALUE 'QDATEQ2'.          
           05  GWCDUMP                 PIC X(8)       VALUE 'GWCDUMP'.          
                                                                                
       COPY GWRDUMP.                                                            
                                                                                
       01  ICBM.                                                                
           COPY ICBM.                                                           
                                                                                
       PROCEDURE DIVISION.                                                      
                                                                                
       100-MAINLINE.                                                            
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   READ FIRST RECORD (DATE RECORD)                             *         
      *   CONVERT DATE TO DDMMMYY                                     *         
      *   READ NEXT RECORD                                            *         
      *   IF NO MESSAGES,                                             *         
      *      PRINT HEADINGS FOR BOTH ACTION ITEMS AND INFO ITEMS      *         
      *      AND A MESSAGE THAT THERE ARE NO ACTION OR INFO ITEMS FOR *         
      *      THIS THIS REPORT                                         *         
      *   ELSE                                                        *         
      *   IF THE FIRST MESSAGE IS AN INFO ITEM, PRINT ACTION          *         
      *      HEADINGS AND A MESSAGE THAT THERE ARE TO NO ACTION       *         
      *      ITEMS                                                    *         
      *   PROCESS ALL RECORDS UNTIL END OF FILE                       *         
      *   IF LAST MESSAGE READ WAS AN ACTION ITEM,                    *         
      *      PRINT THE INFO HEADINGS AND A MESSAGE THAT THERE ARE NO  *         
      *      INFO ITEMS                                               *         
      *   CLOSE PRINT FILE                                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 250-READ-INPUT.                                              
MAN02      CALL QDATEQ2 USING QDATE-FORMATC                                     
MAN02                         WS-DATE-IN                                        
MAN02                         WS-RPT-DATE.                                      
           PERFORM 250-READ-INPUT.                                              
                                                                                
           IF DLS-SYS010-RETURN EQUAL TO +4                                     
           THEN                                                                 
               PERFORM 300-WRITE-ACTION-HEADINGS                                
               MOVE WS-NO-ACTION-MSG TO WS-LINE-OUT                             
               PERFORM 500-WRITE-REPORT                                         
               PERFORM 350-WRITE-INFO-HEADINGS                                  
               MOVE WS-NO-INFO-MSG TO WS-LINE-OUT                               
               PERFORM 500-WRITE-REPORT                                         
           ELSE                                                                 
               IF WS-RPT-NO-IN EQUAL TO '2'                                     
               THEN                                                             
                   PERFORM 300-WRITE-ACTION-HEADINGS                            
                   MOVE WS-NO-ACTION-MSG TO WS-LINE-OUT                         
                   PERFORM 500-WRITE-REPORT.                                    
                                                                                
           PERFORM 200-PROCESS-DETAILS THRU 299-EXIT                            
               UNTIL DLS-SYS010-RETURN GREATER THAN ZERO.                       
                                                                                
           IF WS-RPT-NO-IN EQUAL TO '1'                                         
           THEN                                                                 
               PERFORM 350-WRITE-INFO-HEADINGS                                  
               MOVE WS-NO-INFO-MSG TO WS-LINE-OUT                               
               PERFORM 500-WRITE-REPORT.                                        
                                                                                
           MOVE +4 TO DLS-SYS020-RETURN.                                        
           PERFORM 500-WRITE-REPORT.                                            
           STOP RUN.                                                            
      /                                                                         
       200-PROCESS-DETAILS.                                                     
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   IF LINE COUNT IS GREATER THAN 60 OR THE MESSAGE TYPE HAS    *         
      *      CHANGED                                                  *         
      *   THEN                                                        *         
      *       PAGE TO NEW PAGE AND PRINT HEADINGS                     *         
      *   INVOKE PRINT DETAIL LINE                                    *         
      *   READ NEXT INPUT RECORD                                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF WS-LINE-COUNT GREATER THAN +60                                    
           OR WS-PREV-RPT-NO NOT EQUAL TO WS-RPT-NO-IN                          
           THEN                                                                 
               IF WS-RPT-NO-IN EQUAL TO '1'                                     
               THEN                                                             
                   PERFORM 300-WRITE-ACTION-HEADINGS                            
               ELSE                                                             
                   PERFORM 350-WRITE-INFO-HEADINGS                              
           ELSE                                                                 
               NEXT SENTENCE.                                                   
                                                                                
           PERFORM 400-WRITE-DETAILS.                                           
           MOVE WS-RPT-NO-IN TO WS-PREV-RPT-NO.                                 
           MOVE WS-GFO-IN     TO WS-PREV-GFO.                                   
                                                                                
       250-READ-INPUT.                                                          
                                                                                
           CALL 'DLSREAD' USING DLS-SYS010-SYSNUM                               
                                DLS-SYS010-RETURN                               
                                WS-RECORD-IN                                    
                                DLS-SYS010-REC-SIZE                             
                                DLS-SYS010-BLK-SIZE                             
                                DLS-SYS010-FORMAT                               
                                DLS-SYS010-REC-COUNT.                           
           IF  DLS-SYS010-RETURN IS GREATER THAN +4                             
           THEN                                                                 
               MOVE WS-GFO-IN TO WTL-GFO-NUMBER                                 
               MOVE WS-GR-IN TO WTL-GROUP-NUMBER                                
               MOVE WS-ACCT-IN TO WTL-GROUP-ACCOUNT                             
               MOVE 'DLSREAD FAILED - FORCED TO ABEND'                          
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
                                                                                
       299-EXIT.                                                                
           EXIT.                                                                
      /                                                                         
       300-WRITE-ACTION-HEADINGS.                                               
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   ADD 1 TO PAGE NUMBER                                        *         
      *   PRINT REPORT HEADING                                        *         
      *   PRINT HEADINGS FOR THE ACTION SECTION                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           ADD +1 TO WS-PAGE-NO.                                                
           MOVE WS-PAGE-NO TO WS-RPT-PAGE-NO.                                   
           MOVE WS-REPORT-HEADING TO WS-LINE-OUT.                               
           PERFORM 500-WRITE-REPORT.                                            
           MOVE WS-ACTION-HEADING TO WS-LINE-OUT.                               
           PERFORM 500-WRITE-REPORT.                                            
           MOVE WS-ACTION-UNDERSCORE TO WS-LINE-OUT.                            
           PERFORM 500-WRITE-REPORT.                                            
           MOVE +5 TO WS-LINE-COUNT.                                            
           MOVE SPACES TO WS-RPT-DETAILS.                                       
      /                                                                         
       350-WRITE-INFO-HEADINGS.                                                 
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   ADD 1 TO PAGE NUMBER                                        *         
      *   PRINT REPORT HEADING                                        *         
      *   PRINT HEADINGS FOR THE INFORMATION SECTION                  *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           ADD +1 TO WS-PAGE-NO.                                                
           MOVE WS-PAGE-NO TO WS-RPT-PAGE-NO.                                   
           MOVE WS-REPORT-HEADING TO WS-LINE-OUT.                               
           PERFORM 500-WRITE-REPORT.                                            
           MOVE WS-INFORMATION-HEADING TO WS-LINE-OUT.                          
           PERFORM 500-WRITE-REPORT.                                            
           MOVE WS-INFORMATION-UNDERSCORE TO WS-LINE-OUT.                       
           PERFORM 500-WRITE-REPORT.                                            
           MOVE +5 TO WS-LINE-COUNT.                                            
           MOVE SPACES TO WS-RPT-DETAILS.                                       
      /                                                                         
       400-WRITE-DETAILS.                                                       
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *   SUPPRESS GROUP NUMBER IF MORE THAN ONE MESSAGE FOR A GROUP  *         
      *   PRINT DETAIL LINE                                           *         
      *   ADD 2 TO LINE COUNT FOR DOUBLE SPACING                      *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           IF WS-GFO-IN EQUAL TO WS-PREV-GFO                                    
           THEN                                                                 
               MOVE SPACES TO WS-GFO-OUT                                        
           ELSE                                                                 
               MOVE WS-GFO-IN     TO WS-GFO-OUT.                                
           MOVE WS-GR-ACCT-IN     TO WS-GR-ACCT-OUT.                            
           MOVE WS-MSG-IN TO WS-MSG-OUT.                                        
           MOVE WS-RPT-DETAIL-LINE TO WS-LINE-OUT.                              
           PERFORM 500-WRITE-REPORT.                                            
           ADD +2 TO WS-LINE-COUNT.                                             
      /                                                                         
       500-WRITE-REPORT.                                                        
                                                                                
           CALL 'DLSWRITE' USING DLS-SYS020-SYSNUM                              
                                 DLS-SYS020-RETURN                              
                                 WS-LINE-OUT                                    
                                 DLS-SYS020-REC-SIZE                            
                                 DLS-SYS020-BLK-SIZE                            
                                 DLS-SYS020-FORMAT                              
                                 DLS-SYS020-REC-COUNT.                          
                                                                                
           IF  DLS-SYS020-RETURN IS GREATER THAN +4                             
           THEN                                                                 
               MOVE WS-GFO-IN TO WTL-GFO-NUMBER                                 
               MOVE WS-GR-IN TO WTL-GROUP-NUMBER                                
               MOVE WS-ACCT-IN TO WTL-GROUP-ACCOUNT                             
               MOVE 'DLSWRITE FAILED - FORCED TO ABEND'                         
                   TO WTL-ABEND-MSG                                             
               CALL 'WTL' USING WTL-MESSAGE                                     
               CALL GWCDUMP USING ICBM                                          
                                  GWRDUMP.                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                      END OF SOURCE                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
