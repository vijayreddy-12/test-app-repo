       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GC2COMCR.                                                   
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *REMARKS.  THIS PROGRAMME PRODUCES SUMMARY REPORTS OF THE                 
      *          COMMISSION RELEASE FILE PASSED TO THE COMMISSION               
      *          SYSTEM.                                                        
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * HISTORY                                                                 
      *  10AUG87  HAMPTON    - ADDED RENEWAL PAID GCRL CODE OF 121              
      *  17AUG89  SCHLEICHER - CHANGED REPORTS TO                               
      *                                                                         
      *    JUN90  SCHLEICHER - CHANGES MADE TO COMMISSION RELEASE RECORD        
      *                                                                         
      *  18SEP90  BUCKNELL   - REMOVE CALL TO GPRSGMNT; OUTPUT DIRECTLY         
      *                        TO SYS068 (MICROFICHE).                          
      * 07OCT08  IBMECU        - ENTERPRISE COMPILER UPGRADE          *         
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
      /                                                                         
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                                      PIC X(44)              
             VALUE '**** GC2COMCR - WORKING STORAGE STARTS ****'.               
                                                                                
       77  LINE-COUNT       VALUE ZEROS  COMP-3          PIC S9(5).             
       77  PAGE-COUNT       VALUE ZEROS  COMP-3          PIC S9(5).             
       77  TEMP-AMOUNT-FIELD VALUE +0                    PIC S9(11).            
       77  REPORT-PAGE-SIZE VALUE ZEROS  COMP            PIC S9(4).             
      *77  REPORT-1-FORM    VALUE 'WB'                   PIC XX.                
      *77  REPORT-2-FORM    VALUE 'WA'                   PIC XX.                
       01  PRINT-PARMS.                                                         
           03  PRINT-SYS068        PIC X(6)           VALUE 'SYS068'.           
           03  PRINT-RETURN        PIC S9(1)  COMP-3  VALUE +0.                 
           03  PRINT-RECSIZE       PIC 9(5)           VALUE 00133.              
           03  PRINT-BLKSIZE       PIC 9(5)           VALUE 03990.              
           03  PRINT-FORMAT        PIC X(2)           VALUE 'FB'.               
           03  PRINT-SYS068-COUNT  PIC S9(7)  COMP-3  VALUE +0.                 
      /                                                                         
       01  QDATE-PARAMETERS.                                                    
           05  QDATE-FORMAT-AC      VALUE 'AC'           PIC XX.                
           05  QDATE-FORMAT-BC      VALUE 'BC'           PIC XX.                
           05  QDATE-ALIS-DATE.                                                 
               10  QDATE-ALIS-YEAR VALUE ZEROS  COMP-3   PIC S9(3).             
               10  QDATE-ALIS-DAY  VALUE ZEROS  COMP-3   PIC S9(3).             
           05  QDATE-FORMATTED-DATE                      PIC X(7).              
           05  QDATE-ALIS-DATE-1.                                               
               10  QDATE-ALIS-DD     VALUE ZEROS         PIC 99.                
               10  QDATE-ALIS-MM     VALUE ZEROS         PIC 99.                
               10  QDATE-ALIS-YY     VALUE ZEROS         PIC 99.                
       01  WORK-ACCOUNT.                                                        
           05  WORK-ACCOUNT-FIRST-3                      PIC XXXX.              
           05  WORK-ACCOUNT-LAST-19                      PIC X(19).             
                                                                                
       01  WORK-AMOUNT                          COMP-3   PIC S9(11).            
                                                                                
       01  WORK-AMOUNT-99 REDEFINES WORK-AMOUNT COMP-3   PIC S9(9)V99.          
                                                                                
       01  DETAIL-LINE.                                                         
           05  DETAIL-CC                                 PIC X.                 
           05  DETAIL-PRINT-LINE                         PIC X(132).            
                                                                                
       01  SAVE-DETAIL-LINE                              PIC X(133).            
                                                                                
       01  REPORT-NUMBER    VALUE +1                     PIC S9.                
           88  REPORT-1                    VALUE +1.                            
           88  REPORT-2                    VALUE +2.                            
      /                                                                         
      *****************************************************************         
      *  COMMISSION RELEASE SUMMARY REPORT OUTPUT AREA                *         
      *****************************************************************         
                                                                                
       01  REPORT-1-TITLE-LINE-1.                                               
           05  REPORT-1-TITLE-1-CC     VALUE '1'         PIC X.                 
           05  REPORT-1-PROGRAMME-NAME VALUE 'GC2COMCR'  PIC X(8).              
           05  FILLER                  VALUE SPACES      PIC X(44).             
           05  REPORT-1-TITLE                            PIC X(26)              
                VALUE 'COMMISSION RELEASE SUMMARY'.                             
           05  FILLER                  VALUE SPACES      PIC X(14).             
           05  REPORT-1-REPORT-DATE-TITLE                PIC X(12)              
                VALUE 'REPORT DATE '.                                           
           05  REPORT-1-REPORT-DATE    VALUE SPACES      PIC X(7).              
           05  FILLER                  VALUE SPACES      PIC X(11).             
           05  REPORT-1-PAGE-TITLE     VALUE 'PAGE '     PIC X(5).              
           05  REPORT-1-PAGE-NUMBER    VALUE ZEROS       PIC ZZ9.               
           05  FILLER                  VALUE SPACES      PIC XX.                
                                                                                
       01  REPORT-1-TITLE-LINE-2.                                               
           05  REPORT-1-TITLE-2-CC     VALUE '0'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(4).              
           05  REPORT-1-TITLE-2-A                        PIC X(42)              
                VALUE 'GROUP   ACCOUNT   AGENT  AGENT   MANAGER  '.             
           05  REPORT-1-TITLE-2-B                        PIC X(45)              
                VALUE 'BRANCH  CURR-  MODE  EFFECTIVE  PREMIUM      '.          
           05  REPORT-1-TITLE-2-C                        PIC X(36)              
                VALUE 'FOGL     VARIABLE  CAUSE  COMMISSION'.                   
           05  FILLER                  VALUE SPACES      PIC X(5).              
                                                                                
       01  REPORT-1-TITLE-LINE-3.                                               
           05  REPORT-1-TITLE-3-CC     VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(4).              
           05  REPORT-1-TITLE-3-A                        PIC X(42)              
                VALUE 'NUMBER            CODE   SHARE            '.             
           05  REPORT-1-TITLE-3-B                        PIC X(45)              
                VALUE '         ENCY           DATE    DUE DATE     '.          
           05  REPORT-1-TITLE-3-C                        PIC X(36)              
                VALUE 'CODE       CODE             AMOUNT  '.                   
           05  FILLER                  VALUE SPACES      PIC X(5).              
                                                                                
       01  REPORT-1-OUTPUT-LINE.                                                
           05  REPORT-1-OUTPUT-CC                        PIC X.                 
REN        05  FILLER                                    PIC X(2).              
REN        05  REPORT-1-GROUP-NUMBER                     PIC 9(7).              
           05  FILLER                                    PIC X(4).              
           05  REPORT-1-GROUP-ACCOUNT                    PIC XXXX.              
           05  FILLER                                    PIC X(4).              
           05  REPORT-1-AGENT-CODE                       PIC Z(5)9.             
           05  FILLER                                    PIC XX.                
           05  REPORT-1-AGENT-SHARE                      PIC ZZ9.99.            
           05  FILLER                                    PIC X(4).              
           05  REPORT-1-MANAGER                          PIC ZZ9.               
           05  FILLER                                    PIC X(6).              
           05  REPORT-1-BRANCH                           PIC X(5).              
           05  FILLER                                    PIC X(3).              
           05  REPORT-1-CURRENCY                         PIC Z9.                
           05  FILLER                                    PIC X(4).              
           05  REPORT-1-MODE                             PIC Z9.                
           05  FILLER                                    PIC X(4).              
           05  REPORT-1-EFFECTIVE-DATE                   PIC X(7).              
           05  FILLER                                    PIC X(4).              
           05  REPORT-1-PREMIUM-DUE-DATE                 PIC X(7).              
           05  FILLER                                    PIC XX.                
           05  REPORT-1-FOGL-CODE                        PIC 9(10).             
           05  FILLER                                    PIC X(5).              
           05  REPORT-1-VARIABLE-CODE                    PIC ZZ9.               
           05  FILLER                                    PIC X(5).              
           05  REPORT-1-CAUSE                            PIC Z99.               
           05  FILLER                                    PIC X(3).              
           05  REPORT-1-COMMISSION-AMOUNT         PIC ZZZ,ZZZ,ZZ9.99-.          
                                                                                
       01  REPORT-1-TOTAL-LINE.                                                 
           05  REPORT-1-TOTAL-CC      VALUE '-'          PIC X.                 
           05  FILLER                 VALUE SPACES       PIC XXX.               
           05  REPORT-1-TOTAL-A                          PIC X(45)              
                VALUE 'TOTAL NUMBER OF COMMISSION RELEASE RECORDS   '.          
           05  REPORT-1-TOTAL-RECORDS VALUE ZEROS        PIC ZZZ,ZZ9-.          
           05  FILLER                 VALUE SPACES       PIC X(76).             
                                                                                
       01  REPORT-1-END-LINE.                                                   
           05  REPORT-1-END-CC        VALUE '-'          PIC X.                 
           05  FILLER                 VALUE SPACES       PIC X(45).             
           05  REPORT-1-END                              PIC X(40)              
                VALUE 'END OF COMMISSION RELEASE SUMMARY REPORT'.               
           05  FILLER                 VALUE SPACES       PIC X(47).             
      /                                                                         
      *****************************************************************         
      *  COMMISSIONS FEED CONTROL TOTALS OUTPUT AREA                  *         
      *****************************************************************         
                                                                                
       01  REPORT-2-TITLE-LINE.                                                 
           05  REPORT-2-TITLE-CC       VALUE '1'         PIC X.                 
           05  REPORT-2-PROGRAMME-NAME VALUE 'GC2COMCR'  PIC X(8).              
           05  FILLER                  VALUE SPACES      PIC X(41).             
           05  REPORT-2-TITLE                            PIC X(31)              
                VALUE 'COMMISSIONS FEED CONTROL TOTALS'.                        
           05  FILLER                  VALUE SPACES      PIC X(12).             
           05  REPORT-2-REPORT-DATE-TITLE                PIC X(12)              
                VALUE 'REPORT DATE '.                                           
           05  REPORT-2-REPORT-DATE    VALUE SPACES      PIC X(7).              
           05  FILLER                  VALUE SPACES      PIC X(11).             
           05  REPORT-2-PAGE-TITLE     VALUE 'PAGE '     PIC X(5).              
           05  REPORT-2-PAGE-NUMBER    VALUE ZEROS       PIC ZZ9.               
           05  FILLER                  VALUE SPACES      PIC XX.                
                                                                                
       01  REPORT-2-OUTPUT-LINE-1.                                              
           05  REPORT-2-OUTPUT-1-CC    VALUE '-'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(9).              
           05  REPORT-2-OUTPUT-1                         PIC X(45)              
                VALUE 'TOTAL NUMBER OF COMMISSION RELEASE RECORDS   '.          
           05  REPORT-2-TOTAL-RECORDS  VALUE ZEROS       PIC ZZZ,ZZ9.           
           05  FILLER                  VALUE SPACES      PIC X(71).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-2.                                              
           05  REPORT-2-OUTPUT-2-CC    VALUE '-'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(9).              
           05  REPORT-2-OUTPUT-2                         PIC X(26)              
                VALUE 'PAID FY COMMISSION RECORDS'.                             
           05  FILLER                  VALUE SPACES      PIC X(97).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-3.                                              
           05  REPORT-2-OUTPUT-3-CC    VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-3                         PIC X(25)              
                VALUE 'TOTAL NUMBER OF RECORDS  '.                              
           05  REPORT-2-3-RECORDS      VALUE ZEROS       PIC ZZZ,ZZ9-.          
           05  FILLER                  VALUE SPACES      PIC X(70).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-4.                                              
           05  REPORT-2-OUTPUT-4-CC    VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-4                         PIC X(38)              
                VALUE 'TOTAL COMMISSION AMOUNT               '.                 
           05  REPORT-2-4-AMOUNT   VALUE ZEROS PIC $$,$$$,$$$,$$9.99-.          
           05  FILLER                  VALUE SPACES      PIC X(39).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-5.                                              
           05  REPORT-2-OUTPUT-5-CC    VALUE '-'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(9).              
           05  REPORT-2-OUTPUT-5                         PIC X(31)              
                VALUE 'PAID RENEWAL COMMISSION RECORDS'.                        
           05  FILLER                  VALUE SPACES      PIC X(92).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-6.                                              
           05  REPORT-2-OUTPUT-6-CC    VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-6                         PIC X(25)              
                VALUE 'TOTAL NUMBER OF RECORDS  '.                              
           05  REPORT-2-6-RECORDS      VALUE ZEROS       PIC ZZZ,ZZ9.           
           05  FILLER                  VALUE SPACES      PIC X(71).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-7.                                              
           05  REPORT-2-OUTPUT-7-CC    VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-7                         PIC X(38)              
                VALUE 'TOTAL COMMISSION AMOUNT               '.                 
           05  REPORT-2-7-AMOUNT   VALUE ZEROS PIC $$,$$$,$$$,$$9.99-.          
           05  FILLER                  VALUE SPACES      PIC X(39).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-8.                                              
           05  REPORT-2-OUTPUT-8-CC    VALUE '-'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(9).              
           05  REPORT-2-OUTPUT-8                         PIC X(23)              
                VALUE 'PAID COMMISSION RECORDS'.                                
           05  FILLER                  VALUE SPACES      PIC X(100).            
                                                                                
       01  REPORT-2-OUTPUT-LINE-9.                                              
           05  REPORT-2-OUTPUT-9-CC    VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-9                         PIC X(25)              
                VALUE 'TOTAL NUMBER OF RECORDS  '.                              
           05  REPORT-2-9-RECORDS      VALUE ZEROS       PIC ZZZ,ZZ9.           
           05  FILLER                  VALUE SPACES      PIC X(71).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-10.                                             
           05  REPORT-2-OUTPUT-10-CC   VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-10                        PIC X(38)              
                VALUE 'TOTAL COMMISSION AMOUNT               '.                 
           05  REPORT-2-10-AMOUNT  VALUE ZEROS PIC $$,$$$,$$$,$$9.99-.          
           05  FILLER                  VALUE SPACES      PIC X(39).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-11.                                             
           05  REPORT-2-OUTPUT-11-CC   VALUE '-'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(9).              
           05  REPORT-2-OUTPUT-11                        PIC X(19)              
                VALUE 'SERVICE FEE RECORDS'.                                    
           05  FILLER                  VALUE SPACES      PIC X(104).            
                                                                                
       01  REPORT-2-OUTPUT-LINE-12.                                             
           05  REPORT-2-OUTPUT-12-CC   VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-12                        PIC X(25)              
                VALUE 'TOTAL NUMBER OF RECORDS  '.                              
           05  REPORT-2-12-RECORDS     VALUE ZEROS       PIC ZZZ,ZZ9.           
           05  FILLER                  VALUE SPACES      PIC X(71).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-13.                                             
           05  REPORT-2-OUTPUT-13-CC   VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-13                        PIC X(38)              
                VALUE 'TOTAL AMOUNT                          '.                 
           05  REPORT-2-13-AMOUNT  VALUE ZEROS PIC $$,$$$,$$$,$$9.99-.          
           05  FILLER                  VALUE SPACES      PIC X(39).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-14.                                             
           05  REPORT-2-OUTPUT-14-CC   VALUE '-'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(9).              
           05  REPORT-2-OUTPUT-14                        PIC X(20)              
                VALUE 'SALES CREDIT RECORDS'.                                   
           05  FILLER                  VALUE SPACES      PIC X(103).            
                                                                                
       01  REPORT-2-OUTPUT-LINE-15.                                             
           05  REPORT-2-OUTPUT-15-CC   VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-15                        PIC X(25)              
                VALUE 'TOTAL NUMBER OF RECORDS  '.                              
           05  REPORT-2-15-RECORDS     VALUE ZEROS       PIC ZZZ,ZZ9.           
           05  FILLER                  VALUE SPACES      PIC X(71).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-16.                                             
           05  REPORT-2-OUTPUT-16-CC   VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-16                        PIC X(38)              
                VALUE 'TOTAL AMOUNT                          '.                 
           05  REPORT-2-16-AMOUNT  VALUE ZEROS PIC $$,$$$,$$$,$$9.99-.          
           05  FILLER                  VALUE SPACES      PIC X(39).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-17.                                             
           05  REPORT-2-OUTPUT-17-CC   VALUE '-'         PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(9).              
           05  REPORT-2-OUTPUT-17                        PIC X(25)              
                VALUE 'EARNED COMMISSION RECORDS'.                              
           05  FILLER                  VALUE SPACES      PIC X(98).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-18.                                             
           05  REPORT-2-OUTPUT-18-CC   VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-18                        PIC X(25)              
                VALUE 'TOTAL NUMBER OF RECORDS  '.                              
           05  REPORT-2-18-RECORDS     VALUE ZEROS       PIC ZZZ,ZZ9.           
           05  FILLER                  VALUE SPACES      PIC X(71).             
                                                                                
       01  REPORT-2-OUTPUT-LINE-19.                                             
           05  REPORT-2-OUTPUT-19-CC   VALUE SPACE       PIC X.                 
           05  FILLER                  VALUE SPACES      PIC X(29).             
           05  REPORT-2-OUTPUT-19                        PIC X(38)              
                VALUE 'TOTAL COMMISSION AMOUNT               '.                 
           05  REPORT-2-19-AMOUNT  VALUE ZEROS PIC $$,$$$,$$$,$$9.99-.          
           05  FILLER                  VALUE SPACES      PIC X(39).             
                                                                                
       01  REPORT-2-END-LINE.                                                   
           05  REPORT-2-END-CC        VALUE '-'          PIC X.                 
           05  FILLER                 VALUE SPACES       PIC X(42).             
           05  REPORT-2-END                              PIC X(45)              
                VALUE 'END OF COMMISSIONS FEED CONTROL TOTALS REPORT'.          
           05  FILLER                 VALUE SPACES       PIC X(45).             
      /                                                                         
      *****************************************************************         
      *  REPORT 2 ACCUMULATORS                                        *         
      *****************************************************************         
                                                                                
       01  REPORT-2-ACCUMULATORS.                                               
           05  TOTAL-PAID-FY-RECORDS       COMP-3        PIC S9(5).             
           05  TOTAL-PAID-FY-AMOUNT        COMP-3        PIC S9(11)V99.         
           05  TOTAL-PAID-RENEWAL-RECORDS  COMP-3        PIC S9(5).             
           05  TOTAL-PAID-RENEWAL-AMOUNT   COMP-3        PIC S9(11)V99.         
           05  TOTAL-PAID-RECORDS          COMP-3        PIC S9(5).             
           05  TOTAL-PAID-AMOUNT           COMP-3        PIC S9(11)V99.         
           05  TOTAL-SERVICE-FEE-RECORDS   COMP-3        PIC S9(5).             
           05  TOTAL-SERVICE-FEE-AMOUNT    COMP-3        PIC S9(11)V99.         
           05  TOTAL-SALES-CREDIT-RECORDS  COMP-3        PIC S9(5).             
           05  TOTAL-SALES-CREDIT-AMOUNT   COMP-3        PIC S9(11)V99.         
           05  TOTAL-EARNED-RECORDS        COMP-3        PIC S9(5).             
           05  TOTAL-EARNED-AMOUNT         COMP-3        PIC S9(11)V99.         
           05  TOTAL-COMMISSION-RECORDS    COMP-3        PIC S9(5).             
                                                                                
       01  WS-END                                        PIC X(42)              
             VALUE '**** GC2COMCR - WORKING STORAGE ENDS ****'.                 
      /                                                                         
      *****************************************************************         
      *  LINKAGE SECTION                                              *         
      *****************************************************************         
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  LSTAPE-RECORD.                                                       
           05  FILLER                                    PIC X(4).              
           05  LSTREC-CHG.                                                      
               10  LSTREC-TYPE                           PIC X(1).              
               10  FILLER                                PIC X(1).              
           05  FILLER                                    PIC X(309).            
       01  GCOMRLSE REDEFINES LSTAPE-RECORD. COPY GCOMRLS7 SUPPRESS             
                                                          REPLACING             
                                            ==01  GCOMRLSE.== BY ====.          
                                                                                
       01  LSMISC-AREA.                                                         
           05  FILLER                                    PIC X(4).              
           05  LSM-HIDATE                                PIC X(4).              
           05  FILLER                                    PIC X(24).             
                                                                                
       COPY GPRTPARM.                                                           
                                                                                
       COPY GPRACCUM.                                                           
      /                                                                         
       PROCEDURE DIVISION USING LSTAPE-RECORD                                   
                                LSMISC-AREA                                     
                                GPRTPARM                                        
                                GPRACCUM.                                       
                                                                                
      *****************************************************************         
      *  INITIALIZATION ROUTINE                                       *         
      *****************************************************************         
                                                                                
           CALL 'ZLINECT' USING REPORT-PAGE-SIZE.                               
           SUBTRACT 3 FROM REPORT-PAGE-SIZE.                                    
           MOVE REPORT-PAGE-SIZE TO LINE-COUNT.                                 
           MOVE LSM-HIDATE TO QDATE-ALIS-DATE.                                  
           CALL 'QDATE' USING QDATE-FORMAT-AC                                   
                              QDATE-ALIS-DATE                                   
                              QDATE-FORMATTED-DATE.                             
           MOVE QDATE-FORMATTED-DATE TO REPORT-1-REPORT-DATE                    
                                        REPORT-2-REPORT-DATE.                   
           PERFORM ZERO-ACCUMULATORS THRU ZERO-ACCUM-EXIT.                      
           MOVE ZEROS TO PAGE-COUNT.                                            
      /                                                                         
      *****************************************************************         
      *  PRODUCE THE SUMMARY REPORT AND ACCUMULATE CONTROL TOTALS     *         
      *****************************************************************         
                                                                                
       PRODUCE-REPORTS.                                                         
           PERFORM REPORT-PROCESSING THRU REPORT-EXIT                           
               UNTIL LSTREC-TYPE IS NOT EQUAL TO 'W' OR                         
                     TAPE-RETURN IS NOT EQUAL TO ZEROS.                         
           PERFORM END-REPORT-1 THRU END-REPORT-1-EXIT.                         
           PERFORM PRODUCE-REPORT-2 THRU PRODUCE-REPORT-2-EXIT.                 
                                                                                
       PRODUCE-REPORTS-EXIT.                                                    
           EXIT PROGRAM.                                                        
                                                                                
      *****************************************************************         
      *  ZERO REPORT 2 ACCUMULATORS                                   *         
      *****************************************************************         
                                                                                
       ZERO-ACCUMULATORS.                                                       
           MOVE ZEROS TO TOTAL-PAID-FY-RECORDS                                  
                         TOTAL-PAID-FY-AMOUNT                                   
                         TOTAL-PAID-RENEWAL-RECORDS                             
                         TOTAL-PAID-RENEWAL-AMOUNT                              
                         TOTAL-PAID-RECORDS                                     
                         TOTAL-PAID-AMOUNT                                      
                         TOTAL-SERVICE-FEE-RECORDS                              
                         TOTAL-SERVICE-FEE-AMOUNT                               
                         TOTAL-SALES-CREDIT-RECORDS                             
                         TOTAL-SALES-CREDIT-AMOUNT                              
                         TOTAL-EARNED-RECORDS                                   
                         TOTAL-EARNED-AMOUNT                                    
                         TOTAL-COMMISSION-RECORDS.                              
                                                                                
       ZERO-ACCUM-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *****************************************************************         
      *  PRODUCE THE SUMMARY REPORT AND ACCUMULATE CONTROL TOTALS     *         
      *****************************************************************         
                                                                                
       REPORT-PROCESSING.                                                       
           PERFORM PRODUCE-REPORT-1-LINE THRU REPORT-1-EXIT.                    
           PERFORM ACCUMULATE-REPORT-2 THRU REPORT-2-EXIT.                      
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                LSTAPE-RECORD                                   
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
                                                                                
       REPORT-EXIT.                                                             
           EXIT.                                                                
      /                                                                         
      *****************************************************************         
      *  PRODUCE SUMMARY REPORT LINE                                  *         
      *****************************************************************         
                                                                                
       PRODUCE-REPORT-1-LINE.                                                   
           MOVE SPACES               TO REPORT-1-OUTPUT-LINE.                   
           MOVE GCRL-GROUP           TO REPORT-1-GROUP-NUMBER.                  
           MOVE GCRL-SUB-ACCOUNT     TO WORK-ACCOUNT.                           
           MOVE WORK-ACCOUNT-FIRST-3 TO REPORT-1-GROUP-ACCOUNT.                 
           MOVE GCRL-AGENT-CODE      TO REPORT-1-AGENT-CODE.                    
           MOVE GCRL-SHARE           TO REPORT-1-AGENT-SHARE.                   
           MOVE GCRL-MGR             TO REPORT-1-MANAGER.                       
           MOVE GCRL-BRANCH          TO REPORT-1-BRANCH.                        
           MOVE GCRL-CURRENCY        TO REPORT-1-CURRENCY.                      
           MOVE GCRL-MODE            TO REPORT-1-MODE.                          
           MOVE GCRL-EFF-DD          TO QDATE-ALIS-DD.                          
           MOVE GCRL-EFF-MM          TO QDATE-ALIS-MM.                          
           MOVE GCRL-EFF-YY          TO QDATE-ALIS-YY.                          
      *    ADD +100 GCRL-EFF-YEAR GIVING QDATE-ALIS-YEAR.                       
      *    MOVE GCRL-EFF-DAY         TO QDATE-ALIS-DAY.                         
           CALL 'QDATE' USING QDATE-FORMAT-BC                                   
                              QDATE-ALIS-DATE-1                                 
                              QDATE-FORMATTED-DATE.                             
           MOVE QDATE-FORMATTED-DATE TO REPORT-1-EFFECTIVE-DATE.                
           MOVE GCRL-PREM-DD         TO QDATE-ALIS-DD.                          
           MOVE GCRL-PREM-MM         TO QDATE-ALIS-MM.                          
           MOVE GCRL-PREM-YY         TO QDATE-ALIS-YY.                          
      *    DIVIDE GCRL-PREM-DUE-DATE BY +1000 GIVING QDATE-ALIS-YEAR.           
      *    COMPUTE QDATE-ALIS-DAY    = GCRL-PREM-DUE-DATE -                     
      *                                 (QDATE-ALIS-YEAR * 1000).               
      *    ADD +100 TO QDATE-ALIS-YEAR.                                         
           CALL 'QDATE' USING QDATE-FORMAT-BC                                   
                              QDATE-ALIS-DATE-1                                 
                              QDATE-FORMATTED-DATE.                             
           MOVE QDATE-FORMATTED-DATE TO REPORT-1-PREMIUM-DUE-DATE.              
           MOVE GCRL-FOGL-CODE       TO REPORT-1-FOGL-CODE.                     
           MOVE GCRL-CODE (1)        TO REPORT-1-VARIABLE-CODE.                 
           MOVE GCRL-CAUSE           TO REPORT-1-CAUSE.                         
                                                                                
           IF (GCRL-CODE (1) IS EQUAL TO +113 AND                               
               GCRL-CAUSE IS EQUAL TO 80) OR                                    
              (GCRL-CODE (1) IS EQUAL TO +118 AND                               
               GCRL-CAUSE IS EQUAL TO 80) OR                                    
              (GCRL-CODE (1) IS EQUAL TO +121 AND                               
               GCRL-CAUSE IS EQUAL TO 80) OR                                    
              (GCRL-CODE (1) IS EQUAL TO +131 AND                               
               GCRL-CAUSE IS EQUAL TO 80) OR                                    
              (GCRL-CODE (1) IS EQUAL TO +131 AND                               
               GCRL-CAUSE IS EQUAL TO 61)                                       
               THEN                                                             
               MOVE GCRL-CMAMT  (1) TO WORK-AMOUNT                              
               MOVE WORK-AMOUNT-99  TO REPORT-1-COMMISSION-AMOUNT               
            ELSE                                                                
               IF GCRL-CODE (1) IS EQUAL TO +141 OR +142                        
                  COMPUTE TEMP-AMOUNT-FIELD = GCRL-CMAMT (1) * 100              
                  MOVE TEMP-AMOUNT-FIELD                                        
                                       TO REPORT-1-COMMISSION-AMOUNT            
               ELSE                                                             
                  MOVE GCRL-CMAMT  (1) TO REPORT-1-COMMISSION-AMOUNT.           
           MOVE REPORT-1-OUTPUT-LINE TO DETAIL-LINE.                            
           PERFORM PRINT-REPORT-ROUTINE THRU PRINT-REPORT-EXIT.                 
                                                                                
       REPORT-1-EXIT.                                                           
           EXIT.                                                                
      /                                                                         
      *****************************************************************         
      *  ACCUMULATE CONTROL TOTALS                                    *         
      *****************************************************************         
                                                                                
       ACCUMULATE-REPORT-2.                                                     
           ADD +1 TO TOTAL-COMMISSION-RECORDS.                                  
           IF GCRL-CODE (1) IS EQUAL TO +113 AND                                
              GCRL-CAUSE IS EQUAL TO +341                                       
              THEN                                                              
                 ADD +1               TO TOTAL-PAID-FY-RECORDS                  
                 ADD +1               TO TOTAL-PAID-RECORDS                     
                 ADD GCRL-CMAMT (1)   TO TOTAL-PAID-FY-AMOUNT                   
                                         TOTAL-PAID-AMOUNT.                     
           IF ( GCRL-CODE (1) IS EQUAL TO +121 AND                              
                GCRL-CAUSE IS EQUAL TO +341 )                                   
           OR ( GCRL-CODE (1) IS EQUAL TO +131 AND                              
                GCRL-CAUSE IS EQUAL TO +341 )                                   
              THEN                                                              
                 ADD +1               TO TOTAL-PAID-RENEWAL-RECORDS             
                 ADD +1               TO TOTAL-PAID-RECORDS                     
                 ADD GCRL-CMAMT (1)   TO TOTAL-PAID-RENEWAL-AMOUNT              
                                         TOTAL-PAID-AMOUNT.                     
           IF (GCRL-CODE (1) IS EQUAL TO +131 AND                               
               GCRL-CAUSE IS EQUAL TO +340)   OR                                
              (GCRL-CODE (1) IS EQUAL TO +121 AND                               
               GCRL-CAUSE IS EQUAL TO +340)   OR                                
              (GCRL-CODE (1) IS EQUAL TO +113 AND                               
               GCRL-CAUSE IS EQUAL TO +340)                                     
              THEN                                                              
                 ADD +1               TO TOTAL-SERVICE-FEE-RECORDS              
                 ADD GCRL-CMAMT (1)   TO TOTAL-SERVICE-FEE-AMOUNT.              
           IF  GCRL-CODE (1) IS EQUAL TO +141  OR                               
               GCRL-CODE (1) IS EQUAL TO +142                                   
              THEN                                                              
                 ADD +1              TO TOTAL-SALES-CREDIT-RECORDS              
                 COMPUTE TOTAL-SALES-CREDIT-AMOUNT =                            
                 (100 * GCRL-CMAMT  (1)) + TOTAL-SALES-CREDIT-AMOUNT.           
           IF   GCRL-CODE (1) IS EQUAL TO +118                                  
              THEN                                                              
                 ADD +1               TO TOTAL-EARNED-RECORDS                   
                 ADD GCRL-CMAMT (1)   TO TOTAL-EARNED-AMOUNT.                   
                                                                                
       REPORT-2-EXIT.                                                           
           EXIT.                                                                
                                                                                
      *****************************************************************         
      *  END REPORT 1                                                 *         
      *****************************************************************         
                                                                                
       END-REPORT-1.                                                            
           ADD +1                        TO PAGE-COUNT                          
           MOVE PAGE-COUNT               TO REPORT-1-PAGE-NUMBER                
           MOVE REPORT-1-TITLE-LINE-1    TO DETAIL-LINE                         
           PERFORM PRINT-ROUTINE THRU PRINT-EXIT                                
           MOVE TOTAL-COMMISSION-RECORDS TO REPORT-1-TOTAL-RECORDS.             
           MOVE REPORT-1-TOTAL-LINE      TO DETAIL-LINE.                        
           PERFORM PRINT-ROUTINE THRU PRINT-EXIT.                               
           MOVE REPORT-1-END-LINE        TO DETAIL-LINE.                        
           PERFORM PRINT-ROUTINE THRU PRINT-EXIT.                               
           MOVE +2                       TO REPORT-NUMBER.                      
           MOVE PAGE-COUNT               TO ACCUM-CR-SUMMARY.                   
           MOVE ZEROS                    TO PAGE-COUNT.                         
                                                                                
       END-REPORT-1-EXIT.                                                       
           EXIT.                                                                
      /                                                                         
      *****************************************************************         
      *  PRODUCE REPORT 2                                             *         
      *****************************************************************         
                                                                                
       PRODUCE-REPORT-2.                                                        
           MOVE REPORT-PAGE-SIZE           TO LINE-COUNT.                       
           MOVE TOTAL-COMMISSION-RECORDS   TO REPORT-2-TOTAL-RECORDS.           
           MOVE REPORT-2-OUTPUT-LINE-1     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE REPORT-2-OUTPUT-LINE-2     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-PAID-FY-RECORDS      TO REPORT-2-3-RECORDS.               
           MOVE REPORT-2-OUTPUT-LINE-3     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-PAID-FY-AMOUNT       TO REPORT-2-4-AMOUNT.                
           MOVE REPORT-2-OUTPUT-LINE-4     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE REPORT-2-OUTPUT-LINE-5     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-PAID-RENEWAL-RECORDS TO REPORT-2-6-RECORDS.               
           MOVE REPORT-2-OUTPUT-LINE-6     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-PAID-RENEWAL-AMOUNT  TO REPORT-2-7-AMOUNT.                
           MOVE REPORT-2-OUTPUT-LINE-7     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE REPORT-2-OUTPUT-LINE-8     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-PAID-RECORDS         TO REPORT-2-9-RECORDS.               
           MOVE REPORT-2-OUTPUT-LINE-9     TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-PAID-AMOUNT          TO REPORT-2-10-AMOUNT.               
           MOVE REPORT-2-OUTPUT-LINE-10    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE REPORT-2-OUTPUT-LINE-11    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-SERVICE-FEE-RECORDS  TO REPORT-2-12-RECORDS.              
           MOVE REPORT-2-OUTPUT-LINE-12    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-SERVICE-FEE-AMOUNT   TO REPORT-2-13-AMOUNT.               
           MOVE REPORT-2-OUTPUT-LINE-13    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE REPORT-2-OUTPUT-LINE-14    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-SALES-CREDIT-RECORDS TO REPORT-2-15-RECORDS.              
           MOVE REPORT-2-OUTPUT-LINE-15    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-SALES-CREDIT-AMOUNT  TO REPORT-2-16-AMOUNT.               
           MOVE REPORT-2-OUTPUT-LINE-16    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE REPORT-2-OUTPUT-LINE-17    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-EARNED-RECORDS       TO REPORT-2-18-RECORDS.              
           MOVE REPORT-2-OUTPUT-LINE-18    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE TOTAL-EARNED-AMOUNT        TO REPORT-2-19-AMOUNT.               
           MOVE REPORT-2-OUTPUT-LINE-19    TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE REPORT-2-END-LINE          TO DETAIL-LINE.                      
           PERFORM PRINT-REPORT-ROUTINE    THRU PRINT-REPORT-EXIT.              
           MOVE PAGE-COUNT                 TO ACCUM-CR-CONTROL.                 
                                                                                
       PRODUCE-REPORT-2-EXIT.                                                   
           EXIT.                                                                
      /                                                                         
      *****************************************************************         
      *  PRINT A REPORT LINE                                          *         
      *****************************************************************         
                                                                                
       PRINT-REPORT-ROUTINE.                                                    
           IF LINE-COUNT IS NOT LESS THAN REPORT-PAGE-SIZE                      
              THEN PERFORM TITLE-REPORT THRU TITLE-EXIT.                        
           IF DETAIL-CC IS EQUAL TO SPACES                                      
              THEN ADD +1 TO LINE-COUNT.                                        
           IF DETAIL-CC IS EQUAL TO '0'                                         
              THEN ADD +2 TO LINE-COUNT.                                        
           IF DETAIL-CC IS EQUAL TO '-'                                         
              THEN ADD +3 TO LINE-COUNT.                                        
           PERFORM PRINT-ROUTINE THRU PRINT-EXIT.                               
                                                                                
       PRINT-REPORT-EXIT.                                                       
           EXIT.                                                                
                                                                                
      *****************************************************************         
      *  PRINT THE REPORT TITLE                                       *         
      *****************************************************************         
                                                                                
       TITLE-REPORT.                                                            
           MOVE DETAIL-LINE TO SAVE-DETAIL-LINE                                 
           ADD +1 TO PAGE-COUNT                                                 
           IF REPORT-1                                                          
              THEN                                                              
                 MOVE PAGE-COUNT TO REPORT-1-PAGE-NUMBER                        
                 MOVE REPORT-1-TITLE-LINE-1 TO DETAIL-LINE                      
                 PERFORM PRINT-ROUTINE THRU PRINT-EXIT                          
                 MOVE REPORT-1-TITLE-LINE-2 TO DETAIL-LINE                      
                 PERFORM PRINT-ROUTINE THRU PRINT-EXIT                          
                 MOVE REPORT-1-TITLE-LINE-3 TO DETAIL-LINE                      
                 PERFORM PRINT-ROUTINE THRU PRINT-EXIT                          
                 MOVE +4                    TO LINE-COUNT                       
              ELSE                                                              
                 MOVE PAGE-COUNT TO REPORT-2-PAGE-NUMBER                        
                 MOVE REPORT-2-TITLE-LINE TO DETAIL-LINE                        
                 PERFORM PRINT-ROUTINE THRU PRINT-EXIT                          
                 MOVE +2                    TO LINE-COUNT.                      
           MOVE SAVE-DETAIL-LINE TO DETAIL-LINE.                                
           IF DETAIL-CC IS EQUAL TO SPACES                                      
              THEN MOVE '0' TO DETAIL-CC.                                       
                                                                                
       TITLE-EXIT.                                                              
           EXIT.                                                                
      /                                                                         
      *****************************************************************         
      *  PRINT A LINE                                                 *         
      *****************************************************************         
                                                                                
       PRINT-ROUTINE.                                                           
           CALL 'DLSWRITE' USING PRINT-SYS068                                   
                                 PRINT-RETURN                                   
                                 DETAIL-LINE                                    
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS068-COUNT.                            
                                                                                
       PRINT-EXIT.                                                              
           EXIT.                                                                
