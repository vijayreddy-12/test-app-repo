       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRMNTHS.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS.  THIS PROGRAM WILL PRINT THE "START OF" AND "END OF"            
      *          PAGES BEFORE AND AFTER THE REPORT PRODUCED BY                  
      *          "GPRLTDPD".                                                    
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      ******************************************************************        
      *DATE-WRITTEN.  MODIFIED MAY 1984                                         
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
      /                                                                         
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *         FORMS CODE THAT WILL BE PASTED TO "GPRSGMNT"           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  FORM-STANDARD1          VALUE '9B'      PIC X(2).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *              PAGE AND LINE COUNT VARIABLES                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-COUNTER           VALUE +0 COMP-3 PIC S9(7).                   
       01  LINE-INC                VALUE +0 COMP   PIC S9(4).                   
                                                                                
       01  PRINT-SYS020              PIC X(06) VALUE 'SYS020'.                  
       01  PRINT-SYS020-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *    LINE USED TO PRINT THE "START OF" AND "END OF" MESSAGES     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  START-MESSAGE  VALUE 'S T A R T  O F'   PIC X(14).                   
       01  END-MESSAGE    VALUE '  E N D  O F  '   PIC X(14).                   
       01  MISC-LINE.                                                           
           03  FILLER              VALUE '0'       PIC X(1).                    
           03  FILLER              VALUE SPACES    PIC X(59).                   
           03  MISC-MSG                            PIC X(14).                   
           03  FILLER              VALUE SPACES    PIC X(59).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *   TITLES THAT WILL BE PRINTED AND PASSED TO CALLED PROEGRAMS   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  UA-HEADING                              PIC X(29)                    
           VALUE 'LTD CASH PREMIUMS PAID REPORT'.                               
      *01  UB-HEADING                              PIC X(47)                    
      *    VALUE 'U.S. GROUP ORDINARY RENEWAL PREMIUMS FOR AGENCY'.             
      *----------------------------------------------------------------*        
      *                                                                *        
      *            LINE USED TO PRINT THE "FOR" MESSAGE                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-DATE-LINE.                                                        
           03  FILLER              VALUE '0'       PIC X(1).                    
           03  FILLER              VALUE SPACES    PIC X(59).                   
           03  PR-DATE-MSG.                                                     
               05  FILLER          VALUE 'F O R  ' PIC X(7).                    
               05  PR-DATE                         PIC X(5).                    
           03  FILLER              VALUE SPACES    PIC X(61).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *   TITLES AND DATES THAT WILL BE PASSED TO CALLED PROEGRAMS     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-PARAM-LINES.                                                      
           03  HEADING-PARAM                       PIC X(50).                   
           03  DATE-PARAM                          PIC X(12).                   
           03  PAGE-NUMBER                 COMP-3  PIC S9(5).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *           DATES AND VARIABLES USED ON THE TITLE PAGES          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-DATE.                                                          
           03  PRINT-DAY                           PIC X(2).                    
           03  PRINT-MO-YR                         PIC X(5).                    
       01  FUNCTION-AC             VALUE 'AC'      PIC X(2).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *   PAGE HEADING REQUIRED TO MEET GIPSY PROGRAMMING STANDARDS    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PAGE-HEADING.                                                        
           03  FILLER           VALUE '1GPRMNTHS'  PIC X(9).                    
           03  FILLER           VALUE SPACES       PIC X(114).                  
           03  FILLER           VALUE 'PAGE '      PIC X(5).                    
           03  PAGE-HEADING-NUMBER    VALUE ZEROS  PIC ZZZZ9.                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    PAGE HEADINGS LAYOUT                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-HEADING-LINE.                                                     
           03  FILLER              VALUE '0'       PIC X(1).                    
           03  FILLER              VALUE SPACES    PIC X(40).                   
           03  PR-HEADING                          PIC X(50).                   
           03  PR-LTD-HEADING  REDEFINES  PR-HEADING.                           
               05  FILLER                          PIC X(10).                   
               05  LTD-HEADING                     PIC X(30).                   
               05  FILLER                          PIC X(10).                   
           03  FILLER              VALUE SPACES    PIC X(42).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *                       PRINT BUFFER                             *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PR-LINE.                                                             
           03  PR-CC                               PIC X(1).                    
           03  PR-REC              VALUE SPACES    PIC X(132).                  
      /                                                                         
       LINKAGE SECTION.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *         LAYOUT OF PRINT RECORD PASSED TO THIS PROGRAM          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-REC.                                                            
           03  T-REC-LEN                           PIC X(4).                    
           03  T-REC-KEY.                                                       
               05  T-REC-TYPE                      PIC X(1).                    
               05  T-REC-FORM                      PIC X(1).                    
           03  FILLER                              PIC X(69).                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *     LAYOUT OF RESTART INFORMATION PASSED TO THIS PROGRAM       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  MISC-AREA.                                                           
           03  LO-DATE                             PIC X(4).                    
           03  HI-DATE                             PIC X(4).                    
           03  FILLER                              PIC X(8).                    
           03  RESTART-INFO.                                                    
               05  RESTART-KEY                     PIC X(1).                    
               05  RESTART-REST                    PIC X(11).                   
           03  FILLER                              PIC X(4).                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *     PRINT PARAMETERS COPY BOOK FOR SYS022 THROUGH SYS029       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-PARAMETERS. COPY 'GPRPRINT' REPLACING                          
                                            ==01  GPRPRINT.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *         TAPE PARAMETERS COPY BOOK FOR SYS011 AND SYS014        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TAPE-PARAMETERS. COPY 'GPRTPARM' REPLACING                           
                                            ==01  GPRTPARM.== BY ====.          
      *----------------------------------------------------------------*        
      *                                                                *        
      *               REPORT ACCUMULATORS COPY BOOK                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-ACCUMULATORS. COPY 'GPRACCUM' REPLACING                       
                                            ==01  GPRACCUM.== BY ====.          
      /                                                                         
       PROCEDURE DIVISION USING TAPE-REC                                        
                                MISC-AREA                                       
                                PRINT-PARAMETERS                                
                                TAPE-PARAMETERS                                 
                                REPORT-ACCUMULATORS.                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *     READ RECORD FROM THE INPUT FILE UNTIL YOU ARE AT THE       *        
      *     RECORD REQUESTED OR AN ERROR HAS OCCURED                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
           PERFORM  READ-TAPE THRU READ-TAPE-EXIT                               
                    UNTIL T-REC-TYPE IS NOT LESS THAN RESTART-KEY               
                          OR TAPE-RETURN IS NOT EQUAL TO ZEROES.                
      *----------------------------------------------------------------*        
      *                                                                *        
      *           CHECK TO SEE IF THIS PROGRAM IS DONE                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROES                               
           OR  T-REC-TYPE IS NOT EQUAL TO 'U' THEN                              
               GO TO END-OF-JOB.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *           CONVERT HIGH RUNDATE PASSED TO THIS PROGRAM          *        
      *           FROM A PACKED FORMAT TO A CHARACTER FORMAT           *        
      *                                                                *        
      *----------------------------------------------------------------*        
           CALL 'QDATE' USING FUNCTION-AC                                       
                              HI-DATE                                           
                              PRINT-DATE.                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *            MOVE CONVERTED DATE SO IT CAN BE USED IN THE        *        
      *            REPORT HEADING                                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE PRINT-MO-YR TO PR-DATE.                                         
           MOVE PR-DATE-MSG TO DATE-PARAM.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *        CHECK THE RECORD AND DECIDE WHICH PROGRAM TO CALL       *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  T-REC-KEY IS EQUAL TO 'UA' THEN                                  
               PERFORM  PROCESS-UA-RECORDS THRU                                 
                        PROCESS-UA-RECORDS-EXIT.                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  REPORT 'UB' NOW OBSOLETE                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  T-REC-KEY IS EQUAL TO 'UB' THEN                                  
               PERFORM  READ-TAPE THRU READ-TAPE-EXIT                           
                        UNTIL T-REC-KEY IS NOT EQUAL TO 'UB'.                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *           WHEN YOU HAVE GOTTEN THIS FAR YOU FINISHED           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
      /                                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *                                                                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PROCESS-UA-RECORDS.                                                      
           MOVE SPACES TO PR-LTD-HEADING.                                       
           MOVE UA-HEADING TO LTD-HEADING                                       
                              HEADING-PARAM.                                    
           MOVE SPACES TO MISC-LINE                                             
      *    CALL 'GPRSGMNT' USING PRINT-SYS023                                   
      *                          FORM-STANDARD1.                                
           MOVE +1 TO PAGE-NUMBER.                                              
           MOVE PAGE-NUMBER TO PAGE-HEADING-NUMBER.                             
           MOVE START-MESSAGE TO MISC-MSG.                                      
           PERFORM PRINT-COVER-PAGE THRU                                        
                   PRINT-COVER-PAGE-EXIT.                                       
           CALL 'GPRLTDPD' USING TAPE-REC                                       
                                 MISC-AREA                                      
                                 PRINT-PARAMETERS                               
                                 PR-PARAM-LINES                                 
                                 TAPE-PARAMETERS                                
                                 REPORT-ACCUMULATORS.                           
           ADD +1 TO PAGE-NUMBER.                                               
           MOVE PAGE-NUMBER TO PAGE-HEADING-NUMBER.                             
           MOVE END-MESSAGE TO MISC-MSG.                                        
           PERFORM PRINT-COVER-PAGE THRU                                        
                   PRINT-COVER-PAGE-EXIT.                                       
           ADD +2 TO ACCUM-LTDPREM.                                             
       PROCESS-UA-RECORDS-EXIT.                                                 
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                 GPRGOPDS IS NOW OBSOLETE                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *PROCESS-UB-RECORDS.                                                      
      *    MOVE UB-HEADING TO PR-HEADING                                        
      *                       HEADING-PARAM.                                    
      *    MOVE SPACES TO MISC-LINE                                             
      *    CALL 'GPRSGMNT' USING PRINT-SYS023                                   
      *                          FORM-STANDARD1.                                
      *    MOVE +1 TO PAGE-NUMBER.                                              
      *    MOVE PAGE-NUMBER TO PAGE-HEADING-NUMBER.                             
      *    MOVE START-MESSAGE TO MISC-MSG.                                      
      *    PERFORM PRINT-COVER-PAGE THRU                                        
      *            PRINT-COVER-PAGE-EXIT.                                       
      *    CALL 'GPRGOPDS' USING TAPE-REC                                       
      *                          MISC-AREA                                      
      *                          PR-PARAM-LINES                                 
      *                          TAPE-PARAMETERS.                               
      *    ADD +1 TO PAGE-NUMBER.                                               
      *    MOVE PAGE-NUMBER TO PAGE-HEADING-NUMBER.                             
      *    MOVE END-MESSAGE TO MISC-MSG.                                        
      *    PERFORM PRINT-COVER-PAGE THRU                                        
      *            PRINT-COVER-PRINT-EXIT.                                      
      *PROCESS-UB-RECORDS-EXIT.                                                 
      *    EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                                                                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-COVER-PAGE.                                                        
           PERFORM POSITION-PAGE THRU                                           
                   POSITION-PAGE-EXIT.                                          
           MOVE MISC-LINE TO PR-LINE.                                           
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           MOVE PR-HEADING-LINE TO PR-LINE.                                     
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           MOVE PR-DATE-LINE TO PR-LINE.                                        
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
       PRINT-COVER-PAGE-EXIT.                                                   
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                                                                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       POSITION-PAGE.                                                           
           MOVE PAGE-HEADING TO PR-LINE.                                        
           MOVE ZEROES TO LINE-INC.                                             
       POSITION-LOOP.                                                           
           ADD +1 TO LINE-INC.                                                  
           IF  LINE-INC IS GREATER THAN +6 THEN                                 
               GO TO POSITION-PAGE-EXIT.                                        
           PERFORM PRINT-LINE THRU                                              
                   PRINT-LINE-EXIT.                                             
           MOVE '-' TO PR-CC.                                                   
           GO TO POSITION-LOOP.                                                 
       POSITION-PAGE-EXIT.                                                      
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *            WRITE A LINE OUT TO THE PRINT FILE                  *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-LINE.                                                              
           CALL 'DLSWRITE' USING PRINT-SYS020                                   
                                 PRINT-RETURN                                   
                                 PR-LINE                                        
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS020-COUNT.                            
           MOVE SPACES TO PR-LINE.                                              
       PRINT-LINE-EXIT.                                                         
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *   SET UP THE CALL TO A GENERAL I/O ROUTINE TO READ A RECORD    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       READ-TAPE.                                                               
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                TAPE-REC                                        
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
       READ-TAPE-EXIT.                                                          
           EXIT.                                                                
