                                                                                
       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2ADD.                                                      
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *AUTHOR.        ED BUNGAY.                                                
      *DATE-WRITTEN.  SEP, 2007.                                                
      *DATE-COMPILED.                                                           
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *REMARKS.                                                                 
      *    THIS PROGRAM CREATES AN ADVISOR ADDRESS EXTRACT FILE                 
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *           
      *  HISTORY:                                                               
      *                                                                         
      *  04SEP07  E. BUNGAY     CREATION                                        
      *  24OCT08  IBM GR        UPGRADED IN ENTERPRISE COMPILER PROJECT         
      ******************************************************************        
                                                                                
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCADD          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       CONFIGURATION SECTION.                                                   
                                                                                
       INPUT-OUTPUT SECTION.                                                    
                                                                                
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                      PIC  X(32)  VALUE                     
FXXTOK         '** GC2ADD W-S STARTS HERE **'.                                  
                                                                                
      *----------------------------------------------------                     
      *           DYNAMIC PROGRAM                                               
      *----------------------------------------------------                     
       01  WS-GAEDATSR.                                                         
           05  GAEDATSR               PIC X(8) VALUE 'GAEDATSR'.                
                                                                                
       01  WS-PARAMETERS.                                                       
                                                                                
           05  WS-ZPARDUMP-FUNCTION       PIC X(1)        VALUE '1'.            
           05  WS-ADDRESS-LINE3           PIC X(30)       VALUE SPACES.         
           05  WS-GAEDATSR-VERB           PIC X(16)       VALUE SPACES.         
                                                                                
       01  WS-SWITCHES.                                                         
           05  ERROR-SWITCH               PIC X           VALUE '0'.            
           05  WS-COMTABLE-EOF            PIC X           VALUE 'N'.            
               88  END-OF-COMTABLE                        VALUE 'Y'.            
           05  WS-ADVISOR-EOF             PIC X           VALUE 'N'.            
               88  END-OF-ADVISOR                         VALUE 'Y'.            
           05  AGENT-SWITCH               PIC X           VALUE 'N'.            
               88  AGENT-INFO-FOUND                       VALUE 'Y'.            
           05  WS-ADD-AGENT-SW            PIC X           VALUE 'N'.            
               88  ADD-AGENT                              VALUE 'Y'.            
           05  WS-VALID-PROVINCE          PIC X(2)        VALUE SPACES.         
               88  VALID-PROVINCE         VALUE 'AB' 'BC' 'MB' 'NB'             
                   'NL' 'NS' 'NT' 'NU' 'ON' 'PE' 'PQ' 'QC' 'SK' 'YT'.           
           05  WS-END-OF-DATEPARM         PIC X           VALUE 'N'.            
               88  END-OF-DATEPARM                        VALUE 'Y'.            
                                                                                
       01  WS-COUNTERS.                                                         
           05  WS-TOT-DETAIL-CNT          PIC 9(9)        VALUE ZERO.           
           05  WS-SEQ-NUMBER              PIC 9(7)        VALUE ZERO.           
                                                                                
       01  WS-DATES.                                                            
           05  WS-DATETIME.                                                     
               10  WS-DATETIME-DATE       PIC X(8).                             
               10  WS-DATETIME-TIME       PIC X(6).                             
                                                                                
       01  GARDTCRD-RECORD.                                                     
           COPY GARDTCRD.                                                       
                                                                                
       01  ADVISOR-RECORD.                                                      
           COPY GCOMADDR.                                                       
                                                                                
       01  ADVISOR-FTP-RECORD.                                                  
           05  FILLER           PIC X(80) VALUE 'ADVISOR EXTRACT SENT'.         
                                                                                
       01  COMTABLE-RECORD.                                                     
           COPY GCOMADD1.                                                       
                                                                                
      *****************************************************************         
      *   AGENT ADDRESS FILE (FROM AGI)                             ***         
      *****************************************************************         
       01  ZACCVSAM-AGTADDR.                                                    
           05  PARAM1-AGTADDR.                                                  
               10  DDNAME-AGTADDR          PIC X(7)    VALUE 'VSDSI30'.         
               10  ACCTYPE-AGTADDR         PIC X(5)    VALUE 'KEYED'.           
               10  RECTYPE-AGTADDR         PIC X       VALUE 'F'.               
               10  FUNCTION-AGTADDR        PIC X(6)    VALUE 'GETRAN'.          
               10  ERRCODE-AGTADDR.                                             
                   15  ERRCODE-AGTADDR-1   PIC X(3).                            
                   15  ERRCODE-AGTADDR-EOF PIC X(2).                            
               10  READCT-AGTADDR          PIC S9(7) VALUE +0 COMP-3.           
               10  WRITECT-AGTADDR         PIC S9(7) VALUE +0 COMP-3.           
               10  UPDATECT-AGTADDR        PIC S9(7) VALUE +0 COMP-3.           
               10  DELETECT-AGTADDR        PIC S9(7) VALUE +0 COMP-3.           
               10  RECLGTH-AGTADDR         PIC S9(4)          COMP.             
             05  PARAM2-AGTADDR.                                                
                 10  PARAM2-AGENT-CODE     PIC X(6)  VALUE SPACES.              
                                                                                
      *****************************************************************         
      *01  AGENT-ADDRESS-RECORD.                                    ***         
      *****************************************************************         
           COPY AGTADDR.                                                        
                                                                                
      *****************************************************************         
      *   MESSAGES USED FOR THE ERROR LOGIC USING THE CALL TO WTL     *         
      *****************************************************************         
                                                                                
       01  WS-USER-ABEND-CODE.                                                  
           05  WS-COMP-CODE-X            PIC X(04).                             
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(4) COMP.             
       01  WTL-MESSAGE-PARAMETERS.                                              
           05  WTL-MESSAGES-AREA.                                               
               10  WTL-MESS-LENGTH       PIC S9(3)  VALUE +133  COMP-3.         
               10  WTL-MESS-CC           PIC X(1)   VALUE SPACES.               
               10  WTL-MESS-TEXT         PIC X(132) VALUE SPACES.               
           05  WTL-FLAG                  PIC X(1)   VALUE 'B'.                  
           05  WTL-REPLY                 PIC X(3)   VALUE 'NO '.                
           05  WTL-REPLY-AREA            PIC X(80)  VALUE SPACES.               
       01  WTL-MESSAGE-LIST.                                                    
           05  WTL-1                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - PROBLEM READING DATE CARD FILE          '.              
           05  WTL-2                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - CURRENT DATE NOT FOUND IN DATE CARD FILE'.              
           05  WTL-3                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - EMPTY AGTADDR FILE.    CODE 008A0       '.              
           05  WTL-4                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - BAD RETURN CODE FROM AGTADDR FILE READ  '.              
           05  WTL-5                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - ERROR READING INPUT COMTABLE EXTRACT FILE'.             
           05  WTL-6.                                                           
               10 FILLER                 PIC X(40) VALUE                        
FXXTOK                   'GC2ADD - REQUESTED ADVISOR NOT FOUND  '.              
               10 FILLER                 PIC X(40) VALUE                        
                          'IN THE AGENT ADDRESS FILE'.                          
           05  WTL-7                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - ERROR READING INPUT ADVISOR FILE         '.             
           05  WTL-8                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - ERROR WRITING ADVISOR EXTRACT RECORD     '.             
           05  WTL-9                     PIC X(80)  VALUE                       
FXXTOK        'GC2ADD - ERROR WRITING FTP TRIGGER FILE           '.             
                                                                                
       01  WTL-MESSAGE-TABLE REDEFINES WTL-MESSAGE-LIST.                        
           05  WTL-MESSAGE-ENTRY OCCURS 9 TIMES.                                
               10  WTL-MESSAGE           PIC X(80).                             
                                                                                
       01  WTL-SUB                       PIC S9(4)  VALUE +0   COMP.            
                                                                                
      *----------------------------------------------------                     
      *          DATASERVER RECORDS                                             
      *----------------------------------------------------                     
       01  ICBM.                                                                
           COPY ICBM.                                                           
       01  DATA-SERVICE-VERB.                                                   
           COPY GARDSVRB.                                                       
                                                                                
       01  LOGICAL-RECORD-NAMES.                                                
                                      COPY HCSLRNAM.                            
              10  LR-ADVISOR-IN       PIC X(16) VALUE 'CARD-DATA-010'.          
              10  LR-GARDTCRD-IN      PIC X(16) VALUE 'CARD-DATA-011'.          
              10  LR-COMTABLE-IN      PIC X(16) VALUE 'CARD-DATA-012'.          
              10  LR-ADVISOR-OUT      PIC X(16) VALUE 'PRINT-DATA-020'.         
              10  LR-FTP-OUT          PIC X(16) VALUE 'PRINT-DATA-022'.         
       01  WS-ENDS                       PIC  X(32) VALUE                       
FXXTOK                                '** GC2ADD W-S ENDS HERE **'.             
                                                                                
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
                                                                                
       MAINLINE.                                                                
                                                                                
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                PROGRAM MAINLINE                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
                                                                                
           PERFORM 000-INITIALIZE THRU 099-EXIT.                                
                                                                                
           PERFORM 2000-MAIN-PROCESS THRU                                       
                   2000-MAIN-PROCESS-EXIT UNTIL                                 
                   END-OF-COMTABLE.                                             
                                                                                
           PERFORM 100-END-OF-JOB.                                              
                                                                                
           STOP RUN.                                                            
                                                                                
       000-INITIALIZE.                                                          
      *****************************************************************         
      *    POSITION VSAM AT BEGINNING OF FILE.                        *         
      *    SPECIAL WTL MESSAGE IF SETLIM FAILS BECAUSE FILE IS EMPTY. *         
      *    READ AGENT ADDRESS VSAM FILE.                              *         
      *****************************************************************         
                                                                                
FXXTOK     MOVE 'GC2ADD'          TO ICBM-PROGRAM-NAME.                         
           MOVE LOW-VALUES          TO LINKAGE-CONTROL.                         
           MOVE SPACES              TO GARDTCRD-IDENTIFIER.                     
           MOVE 0                   TO GARDTCRD-DAY.                            
           MOVE SPACES              TO GARDTCRD-MON.                            
           MOVE 0                   TO GARDTCRD-YY.                             
           MOVE 'N'                 TO WS-END-OF-DATEPARM.                      
                                                                                
      *********************************************************                 
      *********** GET CURRENT DATE FROM DATE PARM FILE ********                 
      *********************************************************                 
           MOVE OBTAIN-FIRST                   TO WS-GAEDATSR-VERB.             
           PERFORM 8200-READ-REC-SYS011                                         
              THRU 8200-READ-REC-SYS011-EXIT.                                   
                                                                                
           IF END-OF-DATEPARM                                                   
              DISPLAY 'NO DATA IN DATE CARD FILE'                               
              MOVE +1                          TO WTL-SUB                       
              MOVE 0016                        TO WS-COMP-CODE                  
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
           IF GARDTCRD-IDENTIFIER NOT = 'CURRENT'                               
              MOVE OBTAIN-NEXT                 TO WS-GAEDATSR-VERB              
              PERFORM 8200-READ-REC-SYS011                                      
                THRU 8200-READ-REC-SYS011-EXIT                                  
                UNTIL GARDTCRD-IDENTIFIER = 'CURRENT'                           
                OR END-OF-DATEPARM                                              
                                                                                
              IF END-OF-DATEPARM                                                
                 DISPLAY 'CURRENT DATE NOT FOUND IN'                            
                         ' DATE PARAMETER FILE'                                 
                 MOVE +2                       TO WTL-SUB                       
                 MOVE 0016                   TO WS-COMP-CODE                    
                 PERFORM 9999-WTL-ABEND      THRU 9999-EXIT                     
              END-IF                                                            
           END-IF.                                                              
                                                                                
           MOVE GARDTCRD-Y4M2D2                TO WS-DATETIME-DATE.             
                                                                                
           MOVE LOW-VALUES                     TO PARAM2-AGTADDR.               
           MOVE 'SETLIM'                       TO FUNCTION-AGTADDR.             
                                                                                
           PERFORM 8000-READ-AGENT-ADDR  THRU                                   
                   8000-READ-AGENT-ADDR-EXIT.                                   
                                                                                
           IF  ERRCODE-AGTADDR = 'O08A0'                                        
               MOVE +3                     TO WTL-SUB                           
               MOVE 0016                   TO WS-COMP-CODE                      
               PERFORM 9999-WTL-ABEND      THRU 9999-EXIT                       
           END-IF.                                                              
                                                                                
           IF  ERRCODE-AGTADDR NOT = LOW-VALUES                                 
               MOVE +4                     TO WTL-SUB                           
               MOVE 0016                   TO WS-COMP-CODE                      
               PERFORM 9999-WTL-ABEND      THRU 9999-EXIT                       
           END-IF.                                                              
                                                                                
           MOVE 'GETRAN'                       TO FUNCTION-AGTADDR.             
                                                                                
      ***********************************************************               
      *** GET FIRST TRANSACTION FROM THE LAST ADVISOR EXTRACT ***               
      *** SO WE CAN GET THE SEQUENCE NUMBER THAT WILL BE      ***               
      *** INCREMENTED AND OUTPUT TO THE NEW EXTRACT FILE.     ***               
      ***********************************************************               
           MOVE ZEROS                          TO WS-TOT-DETAIL-CNT.            
           MOVE OBTAIN-FIRST                   TO WS-GAEDATSR-VERB.             
           PERFORM 8100-READ-REC-SYS010 THRU                                    
                    8100-READ-REC-SYS010-EXIT.                                  
           IF LR-STATUS-OK                                                      
              MOVE AEXTRACT-SEQUENCE-NUMBER    TO WS-SEQ-NUMBER                 
              COMPUTE WS-SEQ-NUMBER = WS-SEQ-NUMBER + 1                         
           ELSE                                                                 
              MOVE ZEROS                       TO WS-SEQ-NUMBER                 
           END-IF.                                                              
                                                                                
      ***********************************************************               
      *** GET FIRST RECORD FROM THE INPUT COMTABLE EXTRACT    ***               
      *** FILE.                                               ***               
      ***********************************************************               
           MOVE 'N'                            TO WS-COMTABLE-EOF.              
           MOVE OBTAIN-FIRST                   TO WS-GAEDATSR-VERB.             
           PERFORM 8300-READ-REC-SYS012 THRU                                    
                   8300-READ-REC-SYS012-EXIT.                                   
                                                                                
       099-EXIT.                                                                
           EXIT.                                                                
                                                                                
       100-END-OF-JOB.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    WRITE HEADER RECORD                                        *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           MOVE SPACES                    TO ADVISOR-RECORD.                    
           MOVE 'H'                       TO AEXTRACT-HDR-RECTYPE.              
           MOVE 'ADVISOR   '              TO AEXTRACT-FILE-TYPE.                
           MOVE 'MANULIFE  '              TO AEXTRACT-SYSTEM-IDENTIFIER.        
           MOVE WS-TOT-DETAIL-CNT         TO AEXTRACT-TOTAL-DETAIL-REC.         
           MOVE WS-SEQ-NUMBER             TO AEXTRACT-SEQUENCE-NUMBER.          
           MOVE WS-DATETIME-DATE          TO AEXTRACT-DATE.                     
                                                                                
           PERFORM 9000-WRITE-ADVISOR-SYS020 THRU                               
                   9000-WRITE-ADVISOR-SYS020-EXIT.                              
                                                                                
           PERFORM 9100-WRITE-ADVFTP-SYS022 THRU                                
                   9100-WRITE-ADVFTP-SYS022-EXIT.                               
                                                                                
       2000-MAIN-PROCESS.                                                       
      *****************************************************************         
      *     INVOKE GET AGENT ADDRESS RECORD                           *         
      *         BYPASS AGENT 000000 - DUMMY RECORD FOR LIBERTY/ AETNA *         
      *****************************************************************         
           IF COMTABLE-ADVISOR-NUMBER = ZEROES                                  
              GO TO 2000-GET-NEXT                                               
           END-IF.                                                              
                                                                                
           MOVE 'N'                    TO WS-ADD-AGENT-SW.                      
           MOVE SPACES                 TO ADVISOR-RECORD.                       
           MOVE SPACES                 TO AEXTRACT-ADDR3.                       
           PERFORM 5000-GET-COM-AGENT THRU 5000-GET-COM-AGENT-EXIT.             
                                                                                
      *****************************************************************         
      * IF AGENT INFORMATION HAS CHANGED WRITE IT OUT TO THE EXTRACT  *         
      *****************************************************************         
           IF ADD-AGENT                                                         
              COMPUTE WS-TOT-DETAIL-CNT = WS-TOT-DETAIL-CNT + 1                 
              MOVE 'D'                 TO AEXTRACT-DET-RECTYPE                  
              MOVE AGENT-CODE          TO AEXTRACT-ADVISOR-NUMBER               
              MOVE AGENT-NAME1         TO AEXTRACT-ADVISOR-NAME1                
              MOVE AGENT-NAME2         TO AEXTRACT-ADVISOR-NAME2                
              MOVE AGENT-ADDRESS-LINE1 TO AEXTRACT-ADDR1                        
              MOVE AGENT-ADDRESS-LINE2 TO AEXTRACT-ADDR2                        
              MOVE WS-ADDRESS-LINE3    TO AEXTRACT-ADDR3                        
              PERFORM 9000-WRITE-ADVISOR-SYS020 THRU                            
                      9000-WRITE-ADVISOR-SYS020-EXIT                            
           END-IF.                                                              
                                                                                
      *****************************************************************         
      * READ THE NEXT INPUT COMTABLE EXTRACT RECORD                   *         
      *****************************************************************         
       2000-GET-NEXT.                                                           
           MOVE LR-COMTABLE-IN         TO LOGICAL-RECORD-NAME.                  
           MOVE OBTAIN-NEXT            TO WS-GAEDATSR-VERB.                     
                                                                                
           PERFORM 8300-READ-REC-SYS012 THRU                                    
                   8300-READ-REC-SYS012-EXIT.                                   
                                                                                
       2000-MAIN-PROCESS-EXIT.                                                  
           EXIT.                                                                
                                                                                
      **********************************************************                
      *** RETRIEVE THE AGENT INFO FROM THE AGENT VSAM FILE TO **                
      *** CHECK IF AGENT INFO HAS CHANGED.                    **                
      **********************************************************                
       5000-GET-COM-AGENT.                                                      
           INITIALIZE AGENT-ADDRESS-RECORD.                                     
           MOVE COMTABLE-ADVISOR-NUMBER    TO PARAM2-AGENT-CODE.                
           MOVE SPACES                     TO WS-ADDRESS-LINE3.                 
           MOVE SPACES                     TO ERRCODE-AGTADDR.                  
           PERFORM 8000-READ-AGENT-ADDR THRU                                    
                   8000-READ-AGENT-ADDR-EXIT.                                   
                                                                                
      **********************************************************                
      **   SOMETIMES AGENTS ARE ADDED TO THE SYSTEM BEFORE THEIR                
      **   ADDRESS GETS UPDATED.   MARK ADDRESS AS UNKNOWN FOR                  
      **   NOW, AND IT SHOULD BE CORRECTED FOR THE NEXT RUN.                    
      **********************************************************                
           IF  ERRCODE-AGTADDR NOT =  (SPACES AND LOW-VALUES)                   
               MOVE 'ADDRESS UNKNOWN'       TO AGENT-ADDRESS-LINE2              
               MOVE COMTABLE-ADVISOR-NUMBER TO AGENT-CODE                       
               MOVE COMTABLE-ADVISOR-NAME1  TO AGENT-NAME1                      
           END-IF.                                                              
                                                                                
      **********************************************************                
      ** TRYING TO BETTER LINE UP THE CITY AND POSTAL CODE ON **                
      ** THE ADDRESS COMMING FROM THE AGENT VSAM FILE INTO    **                
      ** THE THIRD ADDRESS LINE ON THE EXTRACT FILE.          **                
      **********************************************************                
           MOVE AGENT-POSTAL-SYMBOL        TO WS-VALID-PROVINCE.                
                                                                                
           IF VALID-PROVINCE AND AGENT-CITY = SPACES                            
              STRING  AGENT-POSTAL-SYMBOL   DELIMITED BY SPACE                  
                      ' '                   DELIMITED BY SIZE                   
                      AGENT-POSTAL-CODE1    DELIMITED BY SPACE                  
                      ' '                   DELIMITED BY SIZE                   
                      AGENT-POSTAL-CODE2    DELIMITED BY SPACE                  
                 INTO WS-ADDRESS-LINE3                                          
           ELSE                                                                 
             IF VALID-PROVINCE                                                  
                STRING  AGENT-CITY          DELIMITED BY '  '                   
                        ', '                DELIMITED BY SIZE                   
                        AGENT-POSTAL-SYMBOL DELIMITED BY SPACE                  
                        ' '                 DELIMITED BY SIZE                   
                        AGENT-POSTAL-CODE1  DELIMITED BY SPACE                  
                        ' '                 DELIMITED BY SIZE                   
                        AGENT-POSTAL-CODE2  DELIMITED BY SPACE                  
                   INTO WS-ADDRESS-LINE3                                        
             ELSE                                                               
                MOVE AGENT-ADDRESS-LINE3   TO WS-ADDRESS-LINE3.                 
                                                                                
      **********************************************************                
      ** COMPARE THE NAME AND ADDRESS FIELDS ON THE AGENT FILE**                
      ** WITH THE RECORD FROM THE INPUT COMTABLE FILE AND     **                
      ** IF THERE ARE DIFFERENCES THEN SET THE FLAG SO THAT   **                
      ** THE CHANGED AGENT ADDRESS RECORD WILL BE WRITTEN TO  **                
      ** THE EXTRACT FILE.                                    **                
      **********************************************************                
           IF AGENT-NAME1         = COMTABLE-ADVISOR-NAME1 AND                  
              AGENT-NAME2         = COMTABLE-ADVISOR-NAME2 AND                  
              AGENT-ADDRESS-LINE1 = COMTABLE-ADDR1 AND                          
              AGENT-ADDRESS-LINE2 = COMTABLE-ADDR2 AND                          
              WS-ADDRESS-LINE3    = COMTABLE-ADDR3                              
              MOVE 'N'                     TO WS-ADD-AGENT-SW                   
           ELSE                                                                 
              MOVE 'Y'                     TO WS-ADD-AGENT-SW.                  
                                                                                
       5000-GET-COM-AGENT-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *************************************************                         
      ** READ THE AGENT ADDRESS VSAM FILE             *                         
      *************************************************                         
       8000-READ-AGENT-ADDR.                                                    
           CALL 'ZACCVSAM'               USING PARAM1-AGTADDR                   
                                               PARAM2-AGTADDR                   
                                               AGENT-ADDRESS-RECORD.            
       8000-READ-AGENT-ADDR-EXIT.                                               
           EXIT.                                                                
                                                                                
      **********************************************************                
      ** READ ADVISOR EXTRACT FILE TO PICK UP SEQUENCE NUMBER **                
      **********************************************************                
       8100-READ-REC-SYS010.                                                    
           MOVE LR-ADVISOR-IN               TO LOGICAL-RECORD-NAME.             
           CALL GAEDATSR                 USING WS-GAEDATSR-VERB                 
                                               ADVISOR-RECORD                   
                                               ICBM.                            
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'                   TO WS-ADVISOR-EOF                   
              ELSE                                                              
                DISPLAY 'ERROR READING INPUT ADVISOR FILE'                      
                MOVE 'Y'                    TO WS-ADVISOR-EOF                   
                MOVE +7                     TO WTL-SUB                          
                MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                     
                PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                        
              END-IF                                                            
           END-IF.                                                              
                                                                                
       8100-READ-REC-SYS010-EXIT.                                               
           EXIT.                                                                
                                                                                
      *************************************************                         
      ** READ DATE PARM FILE TO RETRIEVE CURRENT DATE *                         
      *************************************************                         
       8200-READ-REC-SYS011.                                                    
           MOVE LR-GARDTCRD-IN              TO LOGICAL-RECORD-NAME.             
           CALL GAEDATSR                 USING WS-GAEDATSR-VERB                 
                                               GARDTCRD-RECORD                  
                                               ICBM.                            
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'                   TO WS-END-OF-DATEPARM               
              ELSE                                                              
                DISPLAY 'ERROR READING GARDTCRD DATE PARM'                      
                MOVE 'Y'                    TO WS-END-OF-DATEPARM               
                MOVE +1                     TO WTL-SUB                          
                MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                     
                PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                        
              END-IF                                                            
           END-IF.                                                              
                                                                                
       8200-READ-REC-SYS011-EXIT.                                               
           EXIT.                                                                
                                                                                
      *************************************************                         
      ** READ COMTABLE INPUT FILE                     *                         
      *************************************************                         
       8300-READ-REC-SYS012.                                                    
           MOVE LR-COMTABLE-IN              TO LOGICAL-RECORD-NAME.             
           CALL GAEDATSR                 USING WS-GAEDATSR-VERB                 
                                               COMTABLE-RECORD                  
                                               ICBM.                            
           IF LR-STATUS-OK                                                      
              NEXT SENTENCE                                                     
           ELSE                                                                 
              IF LR-NOT-FOUND                                                   
                 MOVE 'Y'                   TO WS-COMTABLE-EOF                  
              ELSE                                                              
                DISPLAY 'ERROR READING INPUT COMTABLE EXTRACT FILE'             
                MOVE 'Y'                    TO WS-COMTABLE-EOF                  
                MOVE +5                     TO WTL-SUB                          
                MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                     
                PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                        
              END-IF                                                            
           END-IF.                                                              
                                                                                
       8300-READ-REC-SYS012-EXIT.                                               
           EXIT.                                                                
                                                                                
      *************************************************                         
      ** WRITE ADVISOR UPDATE EXTRACT FILE            *                         
      *************************************************                         
       9000-WRITE-ADVISOR-SYS020.                                               
           MOVE 'PRINT-DATA-020'          TO LOGICAL-RECORD-NAME.               
                                                                                
           CALL GAEDATSR               USING STORE-LR                           
                                             ADVISOR-RECORD                     
                                             ICBM.                              
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING EXTRACT: ' ICBM                        
              MOVE 'Y'                    TO WS-COMTABLE-EOF                    
              MOVE +8                     TO WTL-SUB                            
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
           INITIALIZE ADVISOR-RECORD.                                           
                                                                                
       9000-WRITE-ADVISOR-SYS020-EXIT.                                          
           EXIT.                                                                
                                                                                
      *************************************************                         
      ** WRITE ADVISOR FTP TRIGGER FILE               *                         
      *************************************************                         
       9100-WRITE-ADVFTP-SYS022.                                                
           MOVE 'PRINT-DATA-022'          TO LOGICAL-RECORD-NAME.               
                                                                                
           CALL GAEDATSR               USING STORE-LR                           
                                             ADVISOR-FTP-RECORD                 
                                             ICBM.                              
                                                                                
           IF NOT LR-STATUS-OK                                                  
              DISPLAY '*** ERROR WRITING FTP REC: ' ICBM                        
              MOVE 'Y'                    TO WS-COMTABLE-EOF                    
              MOVE +9                     TO WTL-SUB                            
              MOVE PROGRAM-LINKAGE-STATUS TO WS-COMP-CODE                       
              PERFORM 9999-WTL-ABEND    THRU 9999-EXIT                          
           END-IF.                                                              
                                                                                
           INITIALIZE ADVISOR-FTP-RECORD.                                       
                                                                                
       9100-WRITE-ADVFTP-SYS022-EXIT.                                           
           EXIT.                                                                
                                                                                
      ******************************************************************        
      * 9999-WTL-ABEND                                                          
      ******************************************************************        
       9999-WTL-ABEND.                                                          
           MOVE WTL-MESSAGE (WTL-SUB)     TO WTL-MESS-TEXT.                     
           CALL 'WTL'                  USING WTL-MESSAGES-AREA                  
                                             WTL-FLAG                           
                                             WTL-REPLY                          
                                             WTL-REPLY-AREA.                    
                                                                                
           CALL 'ILBOABN0'             USING WS-COMP-CODE.                      
                                                                                
       9999-EXIT.                                                               
           EXIT.                                                                
                                                                                
      *****************************************************************         
      *                      END OF SOURCE                            *         
      *****************************************************************         
