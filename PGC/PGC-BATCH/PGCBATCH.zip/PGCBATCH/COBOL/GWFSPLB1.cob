       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.  GWFSPLB1.                                                   
       AUTHOR.      FORECROSS CORPORATION.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *             I/O SPLITTING - BATCH VERSION                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
       FILE-CONTROL.                                                            
           SELECT OPTIONAL SPLITTER-CONTROL-FILE                                
                                            ASSIGN TO SPLTCNTL.                 
                                                                                
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
       FD  SPLITTER-CONTROL-FILE                                                
           LABEL RECORDS ARE STANDARD.                                          
       01  SPLITTER-CONTROL-RECORD      PIC X(80).                              
                                                                                
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------*        
      *               RECORD XXXX1 BEGIN-WORKING-STORAGE               *        
      *----------------------------------------------------------------*        
       01  XXXX1-BEGIN-WORKING-STORAGE.                                         
               10  XXXX1-CONST-1            PIC X(32)                           
FXXTOK                 VALUE '** GWFSPLB1 WORKING STRG BEGINS'.                 
                                                                                
      *----------------------------------------------------------------*        
      *                RECORD XXCPYRGT COPYRIGHT-NOTICE                *        
      *----------------------------------------------------------------*        
       01  XXCPYRGT-COPYRIGHT-NOTICE.                                           
               10  FILLER                  PIC X(32)                            
                       VALUE 'COPYRIGHT 2000-2010   FORECROSS '.                
               10  FILLER                  PIC X(32)                            
                       VALUE 'CORPORATION. ALL RIGHTS RESERVED'.                
                                                                                
       01  WS-SAVE-DEBUG-FLAG               PIC X.                              
       01  WS-TIMESTAMP                     PIC X(26).                          
       01  FILLER PIC X(32) VALUE                                               
FXXTOK     'GWFSPLB1 STATS TABLE BEGINS'.                                       
       01  WS-STATS-TABLE.                                                      
           05  WS-STATS-TABLE-ENTRY         OCCURS 500 TIMES.                   
               10  WS-STATS-TIMES-EXECUTED  PIC 9(9).                           
               10  WS-STATS-TOTAL-TIME      PIC 9(9).                           
       01  WS-DML-SEQ-NO-DISPLAY            PIC ZZ9.                            
       01  WS-TIMES-EXECUTED-DISPLAY        PIC ZZZ,ZZZ,ZZ9.                    
       01  WS-TOT-EXECUTION-TIME-DISPLAY    PIC ZZZ,ZZZ,ZZ9.                    
       01  WS-AVG-EXECUTION-TIME-DISPLAY    PIC ZZZ,ZZ9.999.                    
       01  WS-SQLCODE-DEBUG-DISPLAY         PIC -999.                           
       01  WS-TIME                          PIC 9(8).                           
       01  WS-TIME-REDEF                    REDEFINES WS-TIME.                  
           05  WS-TIME-HOURS                PIC 99.                             
           05  WS-TIME-MINUTES              PIC 99.                             
           05  WS-TIME-SECONDS              PIC 99.                             
           05  WS-TIME-HUNDRETHS            PIC 99.                             
       01  WS-HUNDRETHS-1                   PIC 9(9).                           
       01  WS-HUNDRETHS-2                   PIC 9(9).                           
       01  WS-STATS-INTERIM-COUNTER         PIC 9(7) VALUE ZERO  COMP-3.        
       01  FILLER PIC X(32) VALUE                                               
FXXTOK     'GWFSPLB1 TRACE TABLE BEGINS'.                                       
       01  TRACE-TABLE                      PIC X(320) VALUE SPACES.            
       01  FILLER PIC X(32) VALUE                                               
FXXTOK     'GWFSPLB1 TRACE TABLE ENDS'.                                         
       01  WORKT-TABLE                      PIC X(320) VALUE SPACES.            
       01  COMP-CODE                        PIC S9(4)         COMP.             
       01  WS-99-DISPLAY                    PIC 99.                             
MAN07  01  WS-SUB1                          PIC 999 COMP.                       
MAN07  01  WS-SUB2                          PIC 999 COMP.                       
       01  WS-LINK-MODULE-NAME              PIC X(8).                           
       01  WS-IDMS-MAJOR-CODE               PIC XX   VALUE '14'.                
       01  WS-9999-DISPLAY                  PIC 9999.                           
       01  WS-SQLCODE-DISPLAY.                                                  
           05  FILLER                       PIC X    VALUE '9'.                 
           05  WS-SQLCODE-NUMERIC           PIC 999.                            
       01  WS-RECORD-RELATED-FLAG           PIC X    VALUE 'N'.                 
           88  WS-RECORD-RELATED-YES                 VALUE 'Y'.                 
           88  WS-RECORD-RELATED-NO                  VALUE 'N'.                 
       01  WS-ABSTIME                       PIC S9(15)        COMP-3.           
       01  WS-SAVE-RECORD-NAME              PIC X(16).                          
       01  WS-SAVE-SET-NAME                 PIC X(16).                          
       01  SPLITTER-ERROR-AREA-0            PIC X(128) VALUE 'SPLT0'.           
       01  SPLITTER-ERROR-AREA-1.                                               
           05  FILLER                       PIC X(6) VALUE 'SPLT1 '.            
           05  SPERR-DATE                   PIC X(10).                          
           05  FILLER                       PIC X    VALUE SPACES.              
           05  SPERR-TIME                   PIC X(8).                           
           05  FILLER                       PIC X(10) VALUE                     
FXXTOK         ' GWFSPLB1 '.                                                    
           05  FILLER                       PIC X(6) VALUE ' PGM: '.            
           05  SPERR-PROGRAM-NAME           PIC X(8).                           
           05  FILLER                       PIC X(10)                           
                                                VALUE ' DML SEQ#:'.             
           05  SPERR-DML-SEQ-NO             PIC ZZZ9.                           
           05  FILLER                       PIC X(6) VALUE ' REC: '.            
           05  SPERR-RECORD-NAME            PIC X(7).                           
           05  FILLER                       PIC X(6) VALUE ' SET: '.            
           05  SPERR-SET-NAME               PIC X(16).                          
           05  FILLER                       PIC X(30) VALUE SPACES.             
                                                                                
       01  SPLITTER-ERROR-AREA-2.                                               
           05  FILLER                       PIC X(6) VALUE 'SPLT2 '.            
           05  FILLER                       PIC X(13)                           
                                                VALUE 'ERR MESSAGE: '.          
           05  SPERR-ERROR-MESSAGE          PIC X(80).                          
           05  FILLER                       PIC X(29) VALUE SPACES.             
                                                                                
       01  SPLITTER-ERROR-AREA-3.                                               
           05  FILLER                       PIC X(6) VALUE 'SPLT3 '.            
           05  FILLER                       PIC X(8) VALUE 'METHOD: '.          
           05  SPERR-METHOD-NAME            PIC X(20).                          
           05  FILLER                       PIC X(10)                           
                                                VALUE ' ERRSTAT: '.             
           05  SPERR-ERROR-STATUS           PIC X(4).                           
           05  FILLER                       PIC X(9)                            
                                                VALUE ' SQLCODE:'.              
           05  SPERR-SQLCODE                PIC -ZZZ9.                          
           05  FILLER                       PIC X(11)                           
                                                VALUE ' SQLERRMC: '.            
           05  SPERR-SQLERRMC-AREA.                                             
               10  SPERR-SQLERRMC           PIC X                               
                   OCCURS 0 TO 70 TIMES                                         
                   DEPENDING ON SPERR-SQLERRML.                                 
       01  SPERR-SQLERRML       VALUE 70    PIC S9(4) COMP.                     
       01  WS-SQLCODE-ERROR-DISPLAY         PIC -ZZZ9.                          
                                                                                
      * FCCMODNM                                                                
CPYNME     COPY GWFMODN1.                                                       
                                                                                
           EXEC SQL                                                             
               INCLUDE SQLCA                                                    
           END-EXEC.                                                            
*******    EXEC SQL                                                             
*******        INCLUDE CBCVDBKW                                                 
*******    END-EXEC.                                                            
      * CBCVDBLT                                                                
CPYNME     EXEC SQL INCLUDE GWTFCKEP                                            
CPYNME                               END-EXEC.                                  
                                                                                
           COPY GWFCRCD1 REPLACING DBLINK-CURSOR-CODES BY                       
           WS-CURSOR-CODES-BASE.                                                
                                                                                
           COPY GWFCRCD1 REPLACING DBLINK-CURSOR-CODES BY                       
           WS-CURSOR-CODES-SAVE.                                                
                                                                                
       01  WS-TIMESTAMP-WORK.                                                   
           05  WS-YEAR                     PIC X(4).                            
           05  FILLER                      PIC X.                               
           05  WS-MONTH                    PIC X(2).                            
           05  FILLER                      PIC X.                               
           05  WS-DAY                      PIC X(2).                            
           05  FILLER                      PIC X.                               
           05  WS-HOUR                     PIC 99.                              
           05  FILLER                      PIC X.                               
           05  WS-MIN                      PIC 99.                              
           05  FILLER                      PIC X.                               
           05  WS-SEC                      PIC 99.                              
           05  FILLER                      PIC X.                               
           05  WS-MS                       PIC V9(6).                           
                                                                                
       01  WS-TIME-WORK.                                                        
           05  WS-GRAND-TIME       COMP-3  PIC S9(7)V9(6) VALUE +0.             
           05  WS-GRAND-COUNT      COMP-3  PIC S9(9)      VALUE +0.             
           05  WS-PERCENT          COMP-3  PIC S9(3)      VALUE +0.             
           05  WS-TIME1            COMP-3  PIC S9(5)V9(6) VALUE +0.             
           05  WS-TIME2            COMP-3  PIC S9(5)V9(6) VALUE +0.             
           05  WS-ELAPSED          COMP-3  PIC S9(5)V9(6) VALUE +0.             
           05  WS-WORK-MIN         COMP-3  PIC S9(5)      VALUE +0.             
           05  WS-WORK-HR          COMP-3  PIC S9(5)      VALUE +0.             
           05  WS-WORK-SEC         COMP-3  PIC S9(5)V9(6) VALUE +0.             
           05  WS-DISPLAY-2                PIC ZZZ,ZZZ,ZZ9.                     
           05  WS-PERCENT-1                PIC ZZ9.                             
           05  WS-PERCENT-2                PIC ZZ9.                             
           05  WS-DISPLAY.                                                      
               10  WS-DISP-HR              PIC 99         VALUE ZERO.           
               10  FILLER                  PIC X          VALUE ':'.            
               10  WS-DISP-MIN             PIC 99         VALUE ZERO.           
               10  FILLER                  PIC X          VALUE ':'.            
               10  WS-DISP-SEC             PIC 99.999999  VALUE ZERO.           
           05  WS-FLAG                     PIC X          VALUE 'N'.            
           05  WS-ACCUM.                                                        
               10  WS-ROW          OCCURS 900 TIMES                             
                                   INDEXED BY IX1 IX2.                          
                   15  WS-TOTAL    COMP-3  PIC S9(5)V9(6) VALUE +0.             
                   15  WS-COUNT    COMP-3  PIC S9(9)      VALUE +0.             
                   15  WS-DML-NO           PIC 9(3)       VALUE  0.             
                                                                                
      *----------------------------------------------------------------*        
      *                RECORD XXXX2 END-WORKING-STORAGE                *        
      *----------------------------------------------------------------*        
       01  XXXX2-END-WORKING-STORAGE.                                           
               10  XXXX2-CONST-2            PIC X(32)                           
FXXTOK                 VALUE '** GWFSPLB1 WORKING STRG ENDS'.                   
                                                                                
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07      05  CEE3ABD                      PIC X(8)  VALUE 'CEE3ABD'.          
MAN07      05  SNAPAID                      PIC X(8)  VALUE 'SNAPAID'.          
GNE    01  ABDCODE                          PIC S9(4) COMP VALUE +1043.         
GNE    01  ABDCLEANUP                       PIC S9(4) COMP VALUE +1.            
       LINKAGE SECTION.                                                         
       01  DFHEIBLK                         PIC X.                              
                                                                                
       01  DFHCOMMAREA                      PIC X.                              
                                                                                
       01  DBLINK-SUBSCHEMA-CONTROL.                                            
           20  DBLINK-IDMS-SUBSCHEMA-CONTROL                                    
                                            PIC X(512).                         
      * CBCVDBSS                                                                
CPYNME     EXEC SQL INCLUDE GWFCVDBS                                            
CPYNME                               END-EXEC.                                  
                                                                                
      * FCCSPLCA                                                                
CPYNME     COPY GWFCSPLC.                                                       
                                                                                
      * CBRSKEYS                                                                
CPYNME     EXEC SQL INCLUDE GWFRSKY1                                            
CPYNME                               END-EXEC.                                  
                                                                                
      * CBCURCOD                                                                
CPYNME     EXEC SQL INCLUDE GWFCRCD1                                            
CPYNME                               END-EXEC.                                  
                                                                                
       01  LS-METHOD-NAME                   PIC X(40).                          
       01  LS-I-O-MODULE-NAME               PIC X(8).                           
       01  LS-DBKEY                         PIC S9(8)         COMP.             
       01  LS-STRING-8                      PIC X(8).                           
       01  LS-STRING-16                     PIC X(16).                          
       01  LS-SORTKEY                       PIC X(200).                         
       01  LS-DBKEY-WORK                    PIC S9(8)         COMP.             
                                                                                
CM0303 01  LINK-FILLER.                                                         
           05  LINK-FILLER-1                    PIC S9(3)     COMP-3.           
           05  LINK-FILLER-2                    PIC S9(3)     COMP-3.           
           05  LINK-FILLER-3                    PIC S9(3)     COMP-3.           
           05  LINK-FILLER-4                    PIC S9(3)     COMP-3.           
           05  LINK-FILLER-5                    PIC S9(3)     COMP-3.           
           05  LINK-FILLER-6                    PIC S9(3)     COMP-3.           
                                                                                
       PROCEDURE DIVISION USING DFHEIBLK                                        
                                DFHCOMMAREA                                     
                                DBLINK-SUBSCHEMA-CONTROL                        
                                DBLINK-RECORD-SET-KEYS                          
CM0303                          DBLINK-CURSOR-CODES                             
CM0303                          LINK-FILLER.                                    
                                                                                
       DECLARATIVES.                                                            
       S00-DEBUG SECTION.                                                       
           USE FOR DEBUGGING                                                    
                             ON ALL PROCEDURES.                                 
       S00-P10-CHECK-FOR-TRACE.                                                 
           IF NOT FCCSPL-BATCH-DEBUG-TRACE                                      
               GO TO S00-P99-EXIT                                               
           END-IF.                                                              
       S00-P20-TRACE-PARAGRAPH.                                                 
           IF DEBUG-CONTENTS = SPACES                                           
FXXTOK         DISPLAY 'GWFSPLB1  ' DEBUG-NAME '  GO TO'                        
           ELSE                                                                 
FXXTOK         DISPLAY 'GWFSPLB1  ' DEBUG-NAME '  ' DEBUG-CONTENTS.             
                                                                                
       S00-P99-EXIT.                                                            
           EXIT.                                                                
                                                                                
       END DECLARATIVES.                                                        
                                                                                
      *----------------------------------------------------------------*        
      *             000-DRIVER ROUTINE                                 *        
      *----------------------------------------------------------------*        
       000-DRIVER SECTION.                                                      
                                                                                
           PERFORM 020-INITIALIZE.                                              
           PERFORM 040-MAINLINE.                                                
           PERFORM 990-RETURN.                                                  
                                                                                
       000-DRIVER-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             020-INITIALIZE ROUTINE                             *        
      *----------------------------------------------------------------*        
       020-INITIALIZE SECTION.                                                  
                                                                                
           SET ADDRESS OF LS-METHOD-NAME TO FCCSPL-ADDR-METHOD.                 
           SET ADDRESS OF LS-I-O-MODULE-NAME                                    
               TO FCCSPL-ADDR-I-O-MODULE                                        
           MOVE 'N' TO FCCSPL-EVALUATE-ERROR-FLAG.                              
           INITIALIZE  FCCSPL-ERROR-MESSAGE.                                    
           MOVE SPACES TO FCCSPL-RECORD-NAME.                                   
           MOVE FCCSPL-SET-NAME TO WS-SAVE-SET-NAME                             
           MOVE SPACES TO FCCSPL-SET-NAME.                                      
           MOVE ZERO TO FCCSPL-IOMOD-SQLCODE.                                   
           MOVE ZERO TO FCCSPLLK-SQLCODE.                                       
           MOVE ZERO TO ERROR-STATUS.                                           
           IF FCCSPL-DEBUG-INTERIM-COUNTER NOT NUMERIC                          
               MOVE 10000 TO FCCSPL-DEBUG-INTERIM-COUNTER                       
           END-IF.                                                              
           IF FCCSPL-DEBUG-INTERIM-COUNTER < 1                                  
               MOVE 10000 TO FCCSPL-DEBUG-INTERIM-COUNTER                       
           END-IF.                                                              
                                                                                
           PERFORM 060-CHECK-ADDRESSES.                                         
                                                                                
       020-INITIALIZE-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             040-MAINLINE ROUTINE                               *        
      *----------------------------------------------------------------*        
       040-MAINLINE SECTION.                                                    
                                                                                
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
               DISPLAY ' '                                                      
FXXTOK         DISPLAY 'GWFSPLB1  ENTRY INTO GWFSPLB1, METHOD = '               
                   LS-METHOD-NAME                                               
FXXTOK         DISPLAY 'GWFSPLB1  FCCSPL-DML-SEQ-NO = '                         
                   FCCSPL-DML-SEQ-NO                                            
           END-IF                                                               
           IF FCCSPL-BATCH-DEBUG-STATS                                          
               IF LS-METHOD-NAME = 'BEGIN-THREAD'                               
                   INITIALIZE WS-STATS-TABLE                                    
                   MOVE 123456789 TO                                            
                       WS-STATS-TIMES-EXECUTED (500)                            
FXXTOK             DISPLAY 'GWFSPLB1  INITIALIZING STATS TABLE 1'               
               END-IF                                                           
               IF WS-STATS-TIMES-EXECUTED (500) NOT NUMERIC                     
                   INITIALIZE WS-STATS-TABLE                                    
                   MOVE 123456789 TO                                            
                       WS-STATS-TIMES-EXECUTED (500)                            
FXXTOK             DISPLAY 'GWFSPLB1  INITIALIZING STATS TABLE 2'               
               END-IF                                                           
               IF WS-STATS-TIMES-EXECUTED (500) NOT = 123456789                 
                   INITIALIZE WS-STATS-TABLE                                    
                   MOVE 123456789 TO                                            
                       WS-STATS-TIMES-EXECUTED (500)                            
FXXTOK             DISPLAY 'GWFSPLB1  INITIALIZING STATS TABLE 3'               
               END-IF                                                           
           END-IF.                                                              
           MOVE '0' TO FCCSPL-RETURN-CODE.                                      
           MOVE LS-METHOD-NAME TO FCCSPL-METHOD-NAME.                           
           MOVE WS-CURSOR-CODES-SAVE TO DBLINK-CURSOR-CODES.                    
      **********************************                                        
      *    PREVENT THE USE OF UNINITIALIZED KEYS WHICH CAN OCCUR IF THE         
      *    TOP ADS DIALOG DOES NOT CONTAIN ANY DML AND PERHAPS OTHER            
      *    PLACES                                                               
      **********************************                                        
           IF DBLINK-KEYS-INIT-REQD                                             
               MOVE SPACES TO DBLINK-RECORD-KEYS                                
               MOVE LOW-VALUES TO DBLINK-SET-KEYS                               
               MOVE SPACES TO DBLINK-SET-FLAGS                                  
               MOVE LOW-VALUES TO DBLINK-IDENTITIES                             
           END-IF                                                               
                                                                                
           EVALUATE FCCSPL-METHOD-NAME                                          
               WHEN 'BEGIN-THREAD'                                              
                   MOVE '14' TO WS-IDMS-MAJOR-CODE                              
                   MOVE ZERO TO ERROR-STATUS                                    
                   PERFORM 100-BIND-RUN-UNIT                                    
               WHEN 'LOCK'                                                      
                   MOVE '09' TO WS-IDMS-MAJOR-CODE                              
                   MOVE ZERO TO ERROR-STATUS                                    
               WHEN 'COMMIT'                                                    
                   MOVE '18' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 110-COMMIT                                           
               WHEN 'ROLLBACK'                                                  
                   MOVE '19' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 120-ROLLBACK                                         
               WHEN 'END-THREAD'                                                
                   MOVE '01' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 160-FINISH                                           
               WHEN 'LOCK-TABLE'                                                
                   MOVE '09' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 170-LOCK-TABLE                                       
               WHEN 'KEEP-LONGTERM'                                             
                   MOVE '51' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 180-KEEP-LONGTERM                                    
               WHEN 'SAVE-DBKEY'                                                
                   MOVE '15' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 200-SAVE-DBKEY                                       
               WHEN 'SAVE-DBKEY-OWNER'                                          
               WHEN 'SAVE-DBKEY2'                                               
                   MOVE WS-SAVE-SET-NAME TO FCCSPL-SET-NAME                     
                   MOVE '15' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 200-SAVE-DBKEY                                       
               WHEN 'CREATE-RELATIONSHIP'                                       
                   MOVE '07' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 210-CONNECT                                          
               WHEN 'DELETE-RELATIONSHIP'                                       
                   MOVE '11' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 220-DISCONNECT                                       
               WHEN 'DELETE'                                                    
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 230-ERASE                                            
               WHEN 'DELETE-CASCADE'                                            
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 231-ERASE-ALL                                        
               WHEN 'DELETE-PERMANENT'                                          
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 232-ERASE-PERMANENT                                  
               WHEN 'DELETE-SELECTIVE'                                          
                   MOVE '02' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 233-ERASE-SELECTIVE                                  
               WHEN 'SELECT-USING-PRIM-KEY'                                     
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 240-OBTAIN-CALC                                      
               WHEN 'SELECT-USING-CURR'                                         
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 241-OBTAIN-CURRENT                                   
               WHEN 'SELECT-USING-DBKEY'                                        
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 242-OBTAIN-DBKEY                                     
               WHEN 'SELECT-PARENT'                                             
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 243-OBTAIN-OWNER                                     
               WHEN 'SELECT-NEXT-USING-ALT-KEY'                                 
               WHEN 'SELECT-FIRST-USING-ALT-KEY'                                
               WHEN 'SELECT-PRIOR-USING-ALT-KEY'                                
               WHEN 'SELECT-USING-ALT-KEY'                                      
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 244-OBTAIN-USING-SORTKEY                             
               WHEN 'FETCH-FIRST'                                               
CN0217         WHEN 'FETCH-FIRST-U'                                             
CM0303         WHEN 'FETCH-FIRST-AGT'                                           
CM0307         WHEN 'FETCH-FIRST-ALPH'                                          
CM0303         WHEN 'FETCH-FIRST-LTD'                                           
CM0307         WHEN 'FETCH-FIRST-MDR'                                           
CM0303         WHEN 'FETCH-FIRST-PPD'                                           
CM0303         WHEN 'FETCH-FIRST-SCF'                                           
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-LAST-ONE'                                            
               WHEN 'FETCH-LAST'                                                
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-NEXT'                                                
CN0217         WHEN 'FETCH-NEXT-U'                                              
CM0303         WHEN 'FETCH-NEXT-AGT'                                            
CM0307         WHEN 'FETCH-NEXT-ALPH'                                           
CM0303         WHEN 'FETCH-NEXT-LTD'                                            
CM0307         WHEN 'FETCH-NEXT-MDR'                                            
CM0303         WHEN 'FETCH-NEXT-PPD'                                            
CM0303         WHEN 'FETCH-NEXT-SCF'                                            
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'SELECT-NEXT'                                               
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-PRIOR'                                               
CN0217         WHEN 'FETCH-PRIOR-U'                                             
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'FETCH-NTH'                                                 
                   MOVE '03' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 245-OBTAIN-FLNPN                                     
               WHEN 'SELECT-DELETE'                                             
                   MOVE '99' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 247-SELECT-DELETE                                    
               WHEN 'IF-DEPENDENTS-EXIST'                                       
                   MOVE '16' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 260-IF-SET-EMPTY                                     
      *        WHEN 'NOT-IF-DEPENDENTS-EXIST'                                   
      * THE NOT IS HANDLED IN THE CALLING PROGRAMS CONVERSION                   
      *   SETTING THE 1601 FOR NOT TESTS ELSE 0000                              
      * THE I/O MODULE CONTAINS NO "NOT" VARIATIONS FOR THIS DML                
      *            MOVE '16' TO WS-IDMS-MAJOR-CODE                              
      *            PERFORM 260-IF-SET-EMPTY                                     
               WHEN 'IF-PARENT-EXISTS'                                          
                   MOVE '16' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 262-IF-SET-MEMBER                                    
      *        WHEN 'NOT-IF-PARENT-EXISTS'                                      
      * THE NOT IS HANDLED IN THE CALLING PROGRAMS CONVERSION                   
      *   SETTING THE 1601 FOR NOT TESTS ELSE 0000                              
      * THE I/O MODULE CONTAINS NO "NOT" VARIATIONS FOR THIS DML                
      *            MOVE '16' TO WS-IDMS-MAJOR-CODE                              
      *            PERFORM 262-IF-SET-MEMBER                                    
               WHEN 'UPDATE'                                                    
                   MOVE '08' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 270-MODIFY                                           
               WHEN 'INSERT'                                                    
                   MOVE '12' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 280-STORE                                            
               WHEN 'RETURN-DBKEY'                                              
                   MOVE '17' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 290-RETURN                                           
               WHEN 'CLOSE-ALL-CURSORS'                                         
                   MOVE '99' TO WS-IDMS-MAJOR-CODE                              
                   PERFORM 420-LINK-TO-SQL-MODULE                               
               WHEN OTHER                                                       
FXXTOK             STRING 'GWFSPLB1 INVALID METHOD = '                          
                       FCCSPL-METHOD-NAME                                       
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 970-EVALUATE-ERROR                                   
           END-EVALUATE.                                                        
                                                                                
       040-MAINLINE-EXIT.                                                       
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             060-CHECK-ADDRESSES ROUTINE                        *        
      *----------------------------------------------------------------*        
       060-CHECK-ADDRESSES SECTION.                                             
                                                                                
           MOVE ZERO TO WS-SUB1.                                                
                                                                                
       060-CHECK-ADDRESSES-010.                                                 
                                                                                
           ADD 1 TO WS-SUB1.                                                    
           IF WS-SUB1 > 10                                                      
FXXTOK         STRING 'GWFSPLB1 ERROR, ALL 10 ADDRESSES USED'                   
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
               PERFORM 980-ABORT                                                
           END-IF.                                                              
           IF FCCSPL-ADDRESS-BASE (WS-SUB1) = ZERO                              
               COMPUTE FCCSPL-NUM-ADDR = WS-SUB1 - 1                            
               GO TO 060-CHECK-ADDRESSES-EXIT                                   
           END-IF.                                                              
           GO TO 060-CHECK-ADDRESSES-010.                                       
                                                                                
       060-CHECK-ADDRESSES-EXIT.                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             100-BIND-RUN-UNIT ROUTINE                          *        
      *----------------------------------------------------------------*        
       100-BIND-RUN-UNIT SECTION.                                               
                                                                                
           MOVE FCCSPL-DEBUG-FLAG TO WS-SAVE-DEBUG-FLAG.                        
           MOVE SPACES TO DBLINK-RECORD-KEYS.                                   
           MOVE LOW-VALUES TO DBLINK-SET-KEYS.                                  
           MOVE SPACES TO DBLINK-SET-FLAGS.                                     
           MOVE LOW-VALUES TO DBLINK-IDENTITIES                                 
           INITIALIZE DBLINK-SUBSCHEMA-CTRL.                                    
           MOVE FCCSPL-PROGRAM-NAME TO PROGRAM-NAME OF                          
                                       DBLINK-SUBSCHEMA-CTRL.                   
           INITIALIZE FCCSPLCA-C.                                               
           MOVE WS-SAVE-DEBUG-FLAG TO FCCSPL-DEBUG-FLAG.                        
           MOVE 'N'        TO FCCSPL-SYNCH-ERROR-FLAG.                          
           MOVE  ZERO TO ERROR-STATUS.                                          
                                                                                
       100-CHECK-SPLITTER-CONTROL.                                              
                                                                                
           OPEN INPUT SPLITTER-CONTROL-FILE.                                    
                                                                                
       100-READ-SPLITTER-CONTROL.                                               
                                                                                
           READ SPLITTER-CONTROL-FILE                                           
               AT END                                                           
                   CLOSE SPLITTER-CONTROL-FILE                                  
                   GO TO 100-BIND-RUN-UNIT-EXIT                                 
           END-READ.                                                            
                                                                                
       S01-P30-DISPLAY-CONTENTS.                                                
                                                                                
           DISPLAY 'SPLITTER-CONTROL-RECORD = '                                 
               SPLITTER-CONTROL-RECORD                                          
           IF SPLITTER-CONTROL-RECORD (1:5) = 'FLAG='                           
               MOVE SPLITTER-CONTROL-RECORD (6:1)                               
                 TO FCCSPL-DEBUG-FLAG                                           
               DISPLAY 'FCCSPL-DEBUG-FLAG SET TO '                              
                   FCCSPL-DEBUG-FLAG                                            
           END-IF.                                                              
           IF SPLITTER-CONTROL-RECORD (1:15) = 'STATS-INVERVAL='                
               OR 'STATS INTERVAL='                                             
                    UNSTRING SPLITTER-CONTROL-RECORD (16:)                      
                        DELIMITED BY SPACES                                     
                            INTO FCCSPL-DEBUG-INTERIM-COUNTER                   
                    IF FCCSPL-DEBUG-INTERIM-COUNTER NOT NUMERIC                 
                        DISPLAY 'STATISTICS INTERVAL NOT NUMERIC, WILL'         
                            ' BE SET TO 10,000'                                 
                        MOVE 10000 TO FCCSPL-DEBUG-INTERIM-COUNTER              
                    ELSE                                                        
                        DISPLAY 'STATISTICS INTERVAL SET TO '                   
                            FCCSPL-DEBUG-INTERIM-COUNTER                        
                    END-IF                                                      
           END-IF.                                                              
           GO TO 100-READ-SPLITTER-CONTROL.                                     
                                                                                
       100-BIND-RUN-UNIT-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             110-COMMIT ROUTINE                                 *        
      *----------------------------------------------------------------*        
       110-COMMIT SECTION.                                                      
                                                                                
           EXEC SQL                                                             
               COMMIT                                                           
           END-EXEC                                                             
                                                                                
           IF SQLCODE = ZERO                                                    
               MOVE  ZERO TO ERROR-STATUS                                       
               GO TO 110-COMMIT-EXIT                                            
           END-IF                                                               
                                                                                
           MOVE SQLCODE TO WS-9999-DISPLAY                                      
FXXTOK     STRING 'GWFSPLB1 COMMIT FAILED, SQLCODE = '                          
                WS-9999-DISPLAY                                                 
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
           PERFORM 980-ABORT.                                                   
                                                                                
       110-COMMIT-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             120-ROLLBACK ROUTINE                               *        
      *----------------------------------------------------------------*        
       120-ROLLBACK SECTION.                                                    
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 2 AND 3                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 ROLLBACK, PARMS NOT 2 OR 3, BUT = '             
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           PERFORM 124-SQL-ROLLBACK.                                            
                                                                                
       120-ROLLBACK-EXIT.                                                       
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             124-SQL-ROLLBACK ROUTINE                           *        
      *----------------------------------------------------------------*        
       124-SQL-ROLLBACK SECTION.                                                
                                                                                
           EXEC SQL                                                             
               ROLLBACK                                                         
           END-EXEC                                                             
                                                                                
           IF SQLCODE = ZERO                                                    
               MOVE SPACES TO DBLINK-RECORD-KEYS                                
               MOVE LOW-VALUES TO DBLINK-SET-KEYS                               
               MOVE SPACES TO DBLINK-SET-FLAGS                                  
               MOVE LOW-VALUES TO DBLINK-IDENTITIES                             
               MOVE WS-CURSOR-CODES-BASE TO DBLINK-CURSOR-CODES                 
               GO TO 124-SQL-ROLLBACK-EXIT                                      
           END-IF                                                               
                                                                                
           MOVE SQLCODE TO WS-9999-DISPLAY                                      
FXXTOK     STRING 'GWFSPLB1 ROLLBACK FAILED, SQLCODE = '                        
                   WS-9999-DISPLAY                                              
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
                                                                                
           PERFORM 980-ABORT.                                                   
                                                                                
       124-SQL-ROLLBACK-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             160-FINISH ROUTINE                                 *        
      *----------------------------------------------------------------*        
       160-FINISH SECTION.                                                      
                                                                                
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
              OR FCCSPL-DEBUG-FLAG = '4'                                        
              PERFORM 1010-DISPLAY-TOTALS                                       
                 THRU 1010-DISPLAY-TOTALS-EXIT                                  
           END-IF                                                               
           IF FCCSPL-BATCH-DEBUG-STATS                                          
               ACCEPT WS-TIME FROM TIME                                         
               DISPLAY ' '                                                      
FXXTOK         DISPLAY 'GWFSPLB1 FINAL STATS FOLLOW (TIME = '                   
               WS-TIME-HOURS                                                    
               ':'                                                              
               WS-TIME-MINUTES                                                  
               ':'                                                              
               WS-TIME-SECONDS                                                  
               '.'                                                              
               WS-TIME-HUNDRETHS                                                
               '): '                                                            
               DISPLAY ' '                                                      
               PERFORM 989-DISPLAY-STATS                                        
           END-IF                                                               
           PERFORM 110-COMMIT.                                                  
                                                                                
           MOVE 'N' TO FCCSPLLK-BEGIN-THREAD-FLAG.                              
                                                                                
       160-FINISH-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             170-LOCK-TABLE ROUTINE                             *        
      *----------------------------------------------------------------*        
       170-LOCK-TABLE SECTION.                                                  
                                                                                
           MOVE 1 TO WS-SUB2.                                                   
                                                                                
       170-CHECK-AND-PROCESS.                                                   
                                                                                
           IF FCCSPL-VARDATA (WS-SUB2:8) = SPACES                               
               OR WS-SUB2 NOT < 400                                             
                   GO TO 170-LOCK-TABLE-EXIT                                    
           END-IF.                                                              
           MOVE FCCSPL-VARDATA (WS-SUB2:8)                                      
               TO LS-I-O-MODULE-NAME.                                           
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (3)                                            
           MOVE LS-STRING-16 TO FCCSPL-LOCK-MODE.                               
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
           IF ERROR-STATUS NOT = ZERO                                           
               GO TO 170-LOCK-TABLE-EXIT                                        
           END-IF.                                                              
           ADD 8 TO WS-SUB2                                                     
           GO TO 170-CHECK-AND-PROCESS.                                         
                                                                                
       170-LOCK-TABLE-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             180-KEEP-LONGTERM ROUTINE                          *        
      *----------------------------------------------------------------*        
       180-KEEP-LONGTERM SECTION.                                               
                                                                                
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (3)                                            
           EVALUATE LS-STRING-16                                                
               WHEN 'RELEASE-ALL'                                               
                   PERFORM 182-RELEASE-ALL                                      
                   GO TO 180-KEEP-LONGTERM-EXIT                                 
               WHEN 'SHARE-WAIT'                                                
                   MOVE '02' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'UP-EXCL-NOWAIT'                                            
                   MOVE '08' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN 'UP-SHR-NOWAIT'                                             
                   MOVE '04' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'EXCL-NOWAIT'                                               
                   MOVE '05' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'RELEASE'                                                   
                   MOVE '06' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN 'NOTIFY-CURRENT'                                            
                   MOVE '07' TO FCCSPL-KEEP-LONG-TYPE                           
               WHEN 'UP-EXCL-NODEAD-N'                                          
                   MOVE '08' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN 'TEST-NOTIFY'                                               
                   MOVE '09' TO FCCSPL-KEEP-LONG-TYPE                           
                   MOVE FCCSPL-KEEP-LONG-ID TO FC-KEEP-LONG-ID                  
                   PERFORM 184-GET-IO-MODULE-NAME                               
                   IF SQLCODE NOT = ZERO                                        
                       PERFORM 198-ADJUST-ERROR-STATUS                          
                       GO TO 180-KEEP-LONGTERM-EXIT                             
                   END-IF                                                       
               WHEN OTHER                                                       
FXXTOK             STRING 'GWFSPLB1 INVALID KEEP LONGTERM, TYPE = '             
                       DELIMITED BY SIZE                                        
                       LS-STRING-16 DELIMITED BY SPACES                         
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 970-EVALUATE-ERROR                                   
                   GO TO 180-KEEP-LONGTERM-EXIT                                 
           END-EVALUATE                                                         
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       180-KEEP-LONGTERM-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             182-RELEASE-ALL  ROUTINE                           *        
      *----------------------------------------------------------------*        
       182-RELEASE-ALL  SECTION.                                                
                                                                                
           EXEC SQL                                                             
FXXTOK         DELETE FROM TFCKEP                                               
                WHERE FC_EIBTRMID = :FC-EIBTRMID                                
           END-EXEC                                                             
           MOVE SQLCODE TO FCCSPL-SQLCODE                                       
           IF SQLCODE = ZERO OR +100                                            
               MOVE ZERO TO ERROR-STATUS                                        
               GO TO 182-RELEASE-ALL-EXIT                                       
           END-IF.                                                              
           PERFORM 198-ADJUST-ERROR-STATUS.                                     
                                                                                
       182-RELEASE-ALL-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             184-GET-IO-MODULE-NAME ROUTINE                     *        
      *----------------------------------------------------------------*        
       184-GET-IO-MODULE-NAME SECTION.                                          
                                                                                
           EXEC SQL                                                             
               SELECT FC_KEEP_LONG_REC                                          
                   INTO :FC-KEEP-LONG-REC                                       
FXXTOK             FROM TFCKEP                                                  
                   WHERE FC_KEEP_LONG_ID = :FC-KEEP-LONG-ID                     
                   AND   FC_EIBTRMID         = :FC-EIBTRMID                     
                   AND   FC_KEEP_LONG_TYPE   = 'NOTIFY'                         
           END-EXEC.                                                            
           IF SQLCODE = +100                                                    
               MOVE '5121' TO ERROR-STATUS                                      
               GO TO 184-GET-IO-MODULE-NAME-EXIT                                
           END-IF.                                                              
           MOVE FC-KEEP-LONG-REC TO FCCSPL-RECORD-NAME                          
           PERFORM 300-FIND-I-O-MODULE-NAME.                                    
                                                                                
       184-GET-IO-MODULE-NAME-EXIT.                                             
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             198-ADJUST-ERROR-STATUS ROUTINE                    *        
      *----------------------------------------------------------------*        
       198-ADJUST-ERROR-STATUS SECTION.                                         
                                                                                
           IF SQLCODE < ZERO                                                    
               MOVE '9' TO WS-SQLCODE-DISPLAY                                   
               COMPUTE WS-SQLCODE-NUMERIC =                                     
                                SQLCODE * (-1)                                  
           ELSE                                                                 
               MOVE '8' TO WS-SQLCODE-DISPLAY                                   
               MOVE              SQLCODE TO WS-SQLCODE-NUMERIC                  
           END-IF                                                               
           MOVE WS-SQLCODE-DISPLAY TO ERROR-STATUS.                             
                                                                                
       198-ADJUST-ERROR-STATUS-EXIT.                                            
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             200-SAVE-DBKEY ROUTINE                             *        
      *----------------------------------------------------------------*        
       200-SAVE-DBKEY   SECTION.                                                
                                                                                
           MOVE RECORD-NAME TO WS-SAVE-RECORD-NAME.                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 4 AND 5 AND 6                               
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 ACCEPT DBK, NUM PARMS NOT 4/5, BUT = '          
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-DBKEY TO FCCSPL-ADDRESS (3).                       
           MOVE FCCSPL-ADDRESS-BASE (3) TO FCCSPL-A-DBKEY.                      
           MOVE ZERO TO LS-DBKEY.                                               
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (4)                                            
           MOVE LS-STRING-16 TO FCCSPL-ACCEPT-TYPE                              
                                                                                
           IF FCCSPL-NUM-ADDR = 5                                               
               SET ADDRESS OF LS-STRING-16                                      
                   TO FCCSPL-ADDRESS (5)                                        
               IF FCCSPL-ACCEPT-RECORD                                          
                   MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                      
                   MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME               
               ELSE                                                             
                   MOVE LS-STRING-16 TO FCCSPL-SET-NAME                         
                   MOVE SPACES TO FCCSPL-ACCEPT-SUBTYPE                         
               END-IF                                                           
           ELSE                                                                 
           IF FCCSPL-NUM-ADDR = 6                                               
               SET ADDRESS OF LS-STRING-16                                      
                   TO FCCSPL-ADDRESS (5)                                        
               MOVE LS-STRING-16 TO FCCSPL-SET-NAME                             
               SET ADDRESS OF LS-STRING-16                                      
                   TO FCCSPL-ADDRESS (6)                                        
               MOVE LS-STRING-16 TO FCCSPL-ACCEPT-SUBTYPE                       
           ELSE                                                                 
               MOVE RECORD-NAME TO FCCSPL-RECORD-NAME                           
               PERFORM 300-FIND-I-O-MODULE-NAME                                 
               MOVE 'RECORD' TO FCCSPL-ACCEPT-TYPE                              
           END-IF.                                                              
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
           IF RECORD-NAME = SPACES                                              
               MOVE WS-SAVE-RECORD-NAME TO RECORD-NAME                          
           END-IF.                                                              
                                                                                
       200-SAVE-DBKEY-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             210-CONNECT ROUTINE                                *        
      *----------------------------------------------------------------*        
       210-CONNECT   SECTION.                                                   
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 CONNECT - NUM PARMS NOT 5, BUT = '              
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME.                      
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       210-CONNECT-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             220-DISCONNECT ROUTINE                             *        
      *----------------------------------------------------------------*        
       220-DISCONNECT   SECTION.                                                
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 DISCONNECT - NUM PARMS NOT 5, BUT = '           
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       220-DISCONNECT-EXIT.                                                     
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             230-ERASE ROUTINE                                  *        
      *----------------------------------------------------------------*        
       230-ERASE   SECTION.                                                     
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 ERASE - NUM PARMS NOT 5, BUT = '                
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE SPACES TO FCCSPL-ERASE-TYPE.                                    
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       230-ERASE-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             231-ERASE-ALL ROUTINE                              *        
      *----------------------------------------------------------------*        
       231-ERASE-ALL   SECTION.                                                 
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 ERASE ALL - NUM PARMS NOT 5, BUT = '            
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE 'ALL' TO FCCSPL-ERASE-TYPE.                                     
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       231-ERASE-ALL-EXIT.                                                      
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             232-ERASE-PERMANENT ROUTINE                        *        
      *----------------------------------------------------------------*        
       232-ERASE-PERMANENT SECTION.                                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 ERASE PERMNENT - NUM PARMS NOT 5, BUT '         
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE 'PERMANENT' TO FCCSPL-ERASE-TYPE.                               
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       232-ERASE-PERMANENT-EXIT.                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             233-ERASE-SELECTIVE ROUTINE                        *        
      *----------------------------------------------------------------*        
       233-ERASE-SELECTIVE SECTION.                                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 ERASE SELECTIV - NUM PARMS NOT 5, BUT '         
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE 'SELECTIVE' TO FCCSPL-ERASE-TYPE.                               
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       233-ERASE-SELECTIVE-EXIT.                                                
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             240-OBTAIN-CALC ROUTINE                            *        
      *----------------------------------------------------------------*        
       240-OBTAIN-CALC   SECTION.                                               
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 6                                           
             AND FCCSPL-NUM-ADDR NOT = 7                                        
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 F/O CALC, NUM PARMS NOT 6, BUT = '              
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           IF FCCSPL-NUM-ADDR = 6                                               
               MOVE 'CALC' TO FCCSPL-OBTAIN-CALC-TYPE                           
           ELSE                                                                 
               MOVE 'DUPLICATE' TO FCCSPL-OBTAIN-CALC-TYPE                      
           END-IF.                                                              
                                                                                
           SUBTRACT 1 FROM FCCSPL-NUM-ADDR                                      
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           ADD 1 TO FCCSPL-NUM-ADDR                                             
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       240-OBTAIN-CALC-EXIT.                                                    
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             241-OBTAIN-CURRENT ROUTINE                         *        
      *----------------------------------------------------------------*        
       241-OBTAIN-CURRENT   SECTION.                                            
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5 AND 6                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 F/O CURR, NUM PARMS NOT 5/6, BUT = '            
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           SUBTRACT 1 FROM FCCSPL-NUM-ADDR                                      
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           ADD 1 TO FCCSPL-NUM-ADDR                                             
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
                                                                                
           IF LS-STRING-16 = 'CURRENT'                                          
               MOVE SPACES TO FCCSPL-OBTAIN-CURR-TYPE                           
               MOVE RECORD-NAME TO FCCSPL-RECORD-NAME                           
               PERFORM 300-FIND-I-O-MODULE-NAME                                 
               PERFORM 400-LINK-TO-I-O-MODULE                                   
           ELSE                                                                 
               MOVE 'RECORD' TO FCCSPL-OBTAIN-CURR-TYPE                         
               MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                          
               MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD                  
               PERFORM 400-LINK-TO-I-O-MODULE                                   
           END-IF.                                                              
                                                                                
       241-OBTAIN-CURRENT-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             242-OBTAIN-DBKEY ROUTINE                           *        
      *----------------------------------------------------------------*        
       242-OBTAIN-DBKEY   SECTION.                                              
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 6 AND 7                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 F/O DB-KEY, NUM PARMS NOT 6/7, BUT = '          
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-DBKEY-WORK TO FCCSPL-ADDRESS (3).                  
           MOVE FCCSPL-ADDRESS-BASE (3) TO FCCSPL-A-DBKEY.                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           SUBTRACT 1 FROM FCCSPL-NUM-ADDR                                      
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           ADD 1 TO FCCSPL-NUM-ADDR                                             
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           IF FCCSPL-NUM-ADDR = 6                                               
               PERFORM 295-FIND-IOMOD-VIA-DBKEY                                 
               IF SQLCODE NOT = ZERO                                            
                   PERFORM 198-ADJUST-ERROR-STATUS                              
                   GO TO 242-OBTAIN-DBKEY-EXIT                                  
               END-IF                                                           
               MOVE 'RECORD' TO FCCSPL-OBTAIN-DBKEY-TYPE                        
           ELSE                                                                 
               SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                
               MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                          
               MOVE 'RECORD' TO FCCSPL-OBTAIN-DBKEY-TYPE                        
               MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD                  
           END-IF                                                               
           PERFORM 400-LINK-TO-I-O-MODULE                                       
                                                                                
           IF LS-DBKEY-WORK = ZERO                                              
               AND ERROR-STATUS = '0326'                                        
                   MOVE '0302' TO ERROR-STATUS                                  
           END-IF.                                                              
                                                                                
       242-OBTAIN-DBKEY-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             243-OBTAIN-OWNER ROUTINE                           *        
      *----------------------------------------------------------------*        
       243-OBTAIN-OWNER   SECTION.                                              
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 7                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 F/O OWNER, NUM PARMS NOT 7, BUT = '             
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (6)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (7)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       243-OBTAIN-OWNER-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             244-OBTAIN-USING-SORTKEY   ROUTINE                 *        
      *----------------------------------------------------------------*        
       244-OBTAIN-USING-SORTKEY   SECTION.                                      
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 8                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 F/O USING, NUM PARMS NOT 8, BUT = '             
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3)                    
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-SORTKEY TO FCCSPL-ADDRESS (6)                      
           MOVE LS-SORTKEY TO FCCSPL-SORTKEY                                    
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (7)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (8)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
FXXTOK         DISPLAY 'GWFSPLB1  SORT-KEY(1:50)      = '                       
                       FCCSPL-SORTKEY(1:50)                                     
           END-IF                                                               
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       244-OBTAIN-USING-SORTKEY-EXIT.                                           
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             245-OBTAIN-FLNPN ROUTINE                           *        
      *----------------------------------------------------------------*        
       245-OBTAIN-FLNPN   SECTION.                                              
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 7                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 F/O FLNPN, NUM PARMS NOT 7, BUT = '             
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3)                    
                                                                                
           IF LS-STRING-16 = 'ANY'                                              
FXXTOK         STRING 'GWFSPLB1 OBTAIN FLNPN ERR, * ANY * NOT ALLOWED'          
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 980-ABORT                                                
           ELSE                                                                 
               MOVE 'RECORD' TO FCCSPL-OBTAIN-FLNPN-TYPE                        
               MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                          
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (5) TO FCCSPL-A-RECORD                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (6)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (7)                    
           MOVE LS-STRING-16 TO FCCSPL-FIND-OBTAIN-TYPE                         
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       245-OBTAIN-FLNPN-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             247-SELECT-DELETE ROUTINE                          *        
      *----------------------------------------------------------------*        
       247-SELECT-DELETE SECTION.                                               
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 SELECT/DEL NUM PARMS NOT 5, BUT = '             
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           MOVE 'CALC' TO FCCSPL-OBTAIN-CALC-TYPE                               
           SET ADDRESS OF LS-STRING-16                                          
               TO FCCSPL-ADDRESS (FCCSPL-NUM-ADDR)                              
           MOVE LS-STRING-16 TO FCCSPL-FIND-OR-OBTAIN                           
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       247-SELECT-DELETE-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             260-IF-SET-EMPTY ROUTINE                           *        
      *----------------------------------------------------------------*        
       260-IF-SET-EMPTY   SECTION.                                              
                                                                                
           MOVE RECORD-NAME TO WS-SAVE-RECORD-NAME.                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 IF EMPTY - NUM PARMS NOT 5, BUT = '             
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5)                    
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
           IF RECORD-NAME = SPACES                                              
               MOVE WS-SAVE-RECORD-NAME TO RECORD-NAME                          
           END-IF.                                                              
                                                                                
       260-IF-SET-EMPTY-EXIT.                                                   
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             262-IF-SET-MEMBER ROUTINE                          *        
      *----------------------------------------------------------------*        
       262-IF-SET-MEMBER   SECTION.                                             
                                                                                
           MOVE RECORD-NAME TO WS-SAVE-RECORD-NAME.                             
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 5                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 IF MEMBER - NUM PARMS NOT 5, BUT = '            
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5)                    
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
                                                                                
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
           IF RECORD-NAME = SPACES                                              
               MOVE WS-SAVE-RECORD-NAME TO RECORD-NAME                          
           END-IF.                                                              
                                                                                
       262-IF-SET-MEMBER-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             270-MODIFY ROUTINE                                 *        
      *----------------------------------------------------------------*        
       270-MODIFY   SECTION.                                                    
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 4                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 MODIFY - NUM PARMS NOT 4, BUT = '               
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-RECORD-NAME TO WS-SAVE-RECORD-NAME                       
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       270-MODIFY-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             280-STORE  ROUTINE                                 *        
      *----------------------------------------------------------------*        
       280-STORE   SECTION.                                                     
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 4                                           
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 STORE - NUM PARMS NOT 4, BUT = '                
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (3).                   
           MOVE LS-STRING-16 TO FCCSPL-RECORD-NAME                              
           MOVE FCCSPL-ADDRESS-BASE (4) TO FCCSPL-A-RECORD.                     
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       280-STORE-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             290-RETURN ROUTINE                                 *        
      *----------------------------------------------------------------*        
       290-RETURN SECTION.                                                      
                                                                                
           IF FCCSPL-NUM-ADDR NOT = 6 AND 7                                     
               MOVE FCCSPL-NUM-ADDR TO WS-99-DISPLAY                            
FXXTOK         STRING 'GWFSPLB1 RETURN, NUM PARMS NOT 6 OR 7, BUT = '           
                   WS-99-DISPLAY                                                
                   DELIMITED BY SIZE                                            
                   INTO FCCSPL-ERROR-MESSAGE                                    
               PERFORM 970-EVALUATE-ERROR                                       
           END-IF.                                                              
                                                                                
           SET ADDRESS OF LS-DBKEY TO FCCSPL-ADDRESS (3).                       
           MOVE FCCSPL-ADDRESS-BASE (3) TO FCCSPL-A-DBKEY.                      
           MOVE 'Y' TO WS-RECORD-RELATED-FLAG.                                  
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (4)                    
           MOVE LS-STRING-16 TO FCCSPL-SET-NAME                                 
           SET ADDRESS OF LS-STRING-16 TO FCCSPL-ADDRESS (5)                    
           MOVE LS-STRING-16 TO FCCSPL-RETURN-TYPE                              
           MOVE FCCSPL-ADDRESS-BASE (6) TO FCCSPL-A-RECORD                      
                                                                                
           IF FCCSPL-NUM-ADDR = 7                                               
               IF FCCSPL-TYPE-USING                                             
                   SET ADDRESS OF LS-SORTKEY TO FCCSPL-ADDRESS (7)              
                   MOVE LS-SORTKEY TO FCCSPL-SORTKEY                            
                   MOVE FCCSPL-SORTKEY TO FCCSPL-KEY                            
                   IF FCCSPL-BATCH-DEBUG-DISPLAY                                
                       DISPLAY ' '                                              
FXXTOK                 DISPLAY 'GWFSPLB1  RETURN DBKEY USING DETECTED'          
FXXTOK                 DISPLAY 'GWFSPLB1  FCCSPL-SORTKEY = '                    
                           FCCSPL-SORTKEY                                       
                   END-IF                                                       
               ELSE                                                             
FXXTOK             STRING 'GWFSPLB1 RETURN, 7 PARMS, TYPE SHOULD BE'            
                   ' USING BUT = '                                              
                       DELIMITED BY SIZE                                        
                   FCCSPL-RETURN-TYPE                                           
                       DELIMITED BY SPACE                                       
                   INTO FCCSPL-ERROR-MESSAGE                                    
                   PERFORM 970-EVALUATE-ERROR                                   
                END-IF                                                          
           ELSE                                                                 
               IF FCCSPL-TYPE-USING                                             
FXXTOK             STRING 'GWFSPLB1 RETURN, 6 PARMS, TYPE SHOULD NOT'           
                   ' BE USING'                                                  
                       DELIMITED BY SIZE                                        
                   INTO FCCSPL-ERROR-MESSAGE                                    
                   PERFORM 970-EVALUATE-ERROR                                   
                END-IF                                                          
           END-IF.                                                              
           PERFORM 400-LINK-TO-I-O-MODULE.                                      
                                                                                
       290-RETURN-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             295-FIND-IOMOD-VIA-DBKEY ROUTINE                   *        
      *----------------------------------------------------------------*        
       295-FIND-IOMOD-VIA-DBKEY SECTION.                                        
                                                                                
*******    EXEC SQL                                                             
*******        SELECT FC_RECORD_NAME                                            
*******        INTO  :FCCSPL-RECORD-NAME                                        
*******        FROM   FCDBKEY                                                   
*******        WHERE  FC_DBKEY = :LS-DBKEY-WORK                                 
*******    END-EXEC.                                                            
*******    IF SQLCODE NOT = ZERO                                                
*******        GO TO 295-FIND-IOMOD-VIA-DBKEY-EXIT                              
*******    END-IF.                                                              
*******    PERFORM 300-FIND-I-O-MODULE-NAME.                                    
FXXTOK             STRING 'GWFSPLB1 INVALID METHOD = '                          
                       FCCSPL-METHOD-NAME                                       
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 970-EVALUATE-ERROR.                                  
                                                                                
       295-FIND-IOMOD-VIA-DBKEY-EXIT.                                           
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             300-FIND-I-O-MODULE-NAME ROUTINE                   *        
      *----------------------------------------------------------------*        
       300-FIND-I-O-MODULE-NAME SECTION.                                        
                                                                                
           SET FCCSPLNM-INDEX TO 1.                                             
                                                                                
           SEARCH FCCSPLNM-TABLE-ENTRY                                          
               AT END                                                           
FXXTOK             STRING 'GWFSPLB1 300 REC NAME SEARCH NOFIND, REC = '         
                       FCCSPL-RECORD-NAME                                       
                           DELIMITED BY SIZE                                    
                           INTO FCCSPL-ERROR-MESSAGE                            
                       PERFORM 980-ABORT                                        
               WHEN FCCSPL-RECORD-NAME =                                        
                        FCCSPLNM-RECORD-NAME (FCCSPLNM-INDEX)                   
                   MOVE FCCSPLNM-I-O-MODULE-NAME (FCCSPLNM-INDEX)               
                       TO LS-I-O-MODULE-NAME                                    
           END-SEARCH.                                                          
           IF LS-I-O-MODULE-NAME = '$ERROR$'                                    
FXXTOK         STRING 'GWFSPLB1 300 REC NAME SEARCH $ERROR$, REC = '            
                   FCCSPL-RECORD-NAME                                           
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
                   PERFORM 980-ABORT                                            
           END-IF.                                                              
                                                                                
       300-FIND-I-O-MODULE-NAME-EXIT.                                           
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             400-LINK-TO-I-O-MODULE ROUTINE                     *        
      *----------------------------------------------------------------*        
       400-LINK-TO-I-O-MODULE SECTION.                                          
                                                                                
           MOVE ZERO TO SQLCODE.                                                
                                                                                
           PERFORM 420-LINK-TO-SQL-MODULE                                       
                                                                                
           MOVE FCCSPLLK-SQLCODE TO FCCSPL-SQLCODE                              
                                                                                
           IF ERROR-STATUS = '7777'                                             
FXXTOK         STRING 'GWFSPLB1, METHOD = '                                     
                   FCCSPL-METHOD-NAME (1:26)                                    
                   ', EVALUATE ERROR 7777'                                      
                       DELIMITED BY SIZE                                        
                       INTO FCCSPL-ERROR-MESSAGE                                
               PERFORM 985-WRITE-ERROR-QUEUE                                    
           END-IF                                                               
           IF (ERROR-STATUS (1:1) = '8'                                         
                OR  ERROR-STATUS (1:1) = '9')                                   
                   IF FCCSPL-ERROR-MESSAGE = SPACES                             
FXXTOK                 STRING 'GWFSPLB1 ERROR, METHOD = '                       
                           FCCSPL-METHOD-NAME (1:26)                            
                           ', ERROR-STATUS = '                                  
                           ERROR-STATUS                                         
                               DELIMITED BY SIZE                                
                               INTO FCCSPL-ERROR-MESSAGE                        
                   END-IF                                                       
                   PERFORM 985-WRITE-ERROR-QUEUE                                
           END-IF.                                                              
                                                                                
           IF ERROR-STATUS (3:2) = '29'                                         
               IF FCCSPL-ERROR-MESSAGE = SPACES                                 
                   MOVE SQLCODE TO WS-SQLCODE-ERROR-DISPLAY                     
                   STRING 'ROLLBACK, METH: '                                    
                       FCCSPL-METHOD-NAME (1:26)                                
                       ', ERROR-STATUS: '                                       
                       ERROR-STATUS                                             
                       ', SQLCODE: '                                            
                       WS-SQLCODE-ERROR-DISPLAY                                 
                           DELIMITED BY SIZE                                    
                           INTO FCCSPL-ERROR-MESSAGE                            
               END-IF                                                           
               PERFORM 985-WRITE-ERROR-QUEUE                                    
           END-IF.                                                              
                                                                                
       400-LINK-TO-I-O-MODULE-EXIT.                                             
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             420-LINK-TO-SQL-MODULE ROUTINE                     *        
      *----------------------------------------------------------------*        
       420-LINK-TO-SQL-MODULE SECTION.                                          
                                                                                
           IF FCCSPLLK-SQLCODE NOT NUMERIC                                      
               MOVE ZERO TO FCCSPLLK-SQLCODE                                    
           END-IF.                                                              
           MOVE FCCSPL-PROGRAM-NAME TO DBLINK-PROGRAM-NAME.                     
           IF LS-I-O-MODULE-NAME = 'GLBLCTL'                                    
               MOVE '9997' TO ERROR-STATUS                                      
               GO TO 420-LINK-TO-SQL-MODULE-EXIT                                
           END-IF.                                                              
           MOVE LS-I-O-MODULE-NAME TO WS-LINK-MODULE-NAME.                      
           MOVE LS-I-O-MODULE-NAME TO FCCSPL-IO-MODULE-NAME                     
MAN        MOVE '3' TO WS-LINK-MODULE-NAME (3:1)                                
                                                                                
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
              OR FCCSPL-DEBUG-FLAG = '4'                                        
*******    EXEC SQL                                                             
*******        SELECT CURRENT TIMESTAMP                                         
*******          INTO :WS-TIMESTAMP                                             
*******    END-EXEC                                                             
           EXEC SQL                                                             
               SET :WS-TIMESTAMP = CURRENT TIMESTAMP                            
           END-EXEC                                                             
           MOVE WS-TIMESTAMP TO WS-TIMESTAMP-WORK                               
           COMPUTE WS-TIME1 =                                                   
               (((WS-HOUR * 60) + WS-MIN) * 60) + WS-SEC + WS-MS                
           END-IF                                                               
           IF FCCSPL-BATCH-DEBUG-STATS                                          
               ADD 1 TO WS-STATS-TIMES-EXECUTED (FCCSPL-DML-SEQ-NO)             
               ADD 1 TO WS-STATS-INTERIM-COUNTER                                
               ACCEPT WS-TIME FROM TIME                                         
               COMPUTE WS-HUNDRETHS-1 =                                         
                   WS-TIME-HOURS * 360000 +                                     
                   WS-TIME-MINUTES * 6000 +                                     
                   WS-TIME-SECONDS * 100 +                                      
                   WS-TIME-HUNDRETHS                                            
           END-IF                                                               
           CALL WS-LINK-MODULE-NAME                                             
                 USING                                                          
                     DFHEIBLK                                                   
                     DFHCOMMAREA                                                
                     DBLINK-SUBSCHEMA-CONTROL                                   
                     DBLINK-RECORD-SET-KEYS                                     
CM0303               DBLINK-CURSOR-CODES                                        
CM0303               LINK-FILLER.                                               
                                                                                
           IF FCCSPL-BATCH-DEBUG-STATS                                          
               ACCEPT WS-TIME FROM TIME                                         
               COMPUTE WS-HUNDRETHS-2 =                                         
                   WS-TIME-HOURS * 360000 +                                     
                   WS-TIME-MINUTES * 6000 +                                     
                   WS-TIME-SECONDS * 100 +                                      
                   WS-TIME-HUNDRETHS                                            
               COMPUTE WS-STATS-TOTAL-TIME (FCCSPL-DML-SEQ-NO) =                
                   WS-STATS-TOTAL-TIME (FCCSPL-DML-SEQ-NO)                      
                   + WS-HUNDRETHS-2 - WS-HUNDRETHS-1                            
               IF WS-STATS-INTERIM-COUNTER >=                                   
                 FCCSPL-DEBUG-INTERIM-COUNTER                                   
                   ACCEPT WS-TIME FROM TIME                                     
                   DISPLAY ' '                                                  
FXXTOK             DISPLAY 'GWFSPLB1 INTERIM STATS FOLLOW (TIME = '             
                   WS-TIME-HOURS                                                
                   ':'                                                          
                   WS-TIME-MINUTES                                              
                   ':'                                                          
                   WS-TIME-SECONDS                                              
                   '.'                                                          
                   WS-TIME-HUNDRETHS                                            
                   '): '                                                        
                   DISPLAY ' '                                                  
                   PERFORM 989-DISPLAY-STATS                                    
                   MOVE ZERO TO WS-STATS-INTERIM-COUNTER                        
               END-IF                                                           
           END-IF                                                               
           IF FCCSPL-METHOD-NAME = 'SAVE-DBKEY'                                 
              AND ERROR-STATUS = '0306'                                         
                  MOVE ZERO TO ERROR-STATUS                                     
                  MOVE -1 TO LS-DBKEY                                           
           END-IF                                                               
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
               MOVE FCCSPL-IOMOD-SQLCODE TO WS-SQLCODE-DEBUG-DISPLAY            
               DISPLAY ' '                                                      
FXXTOK         DISPLAY 'GWFSPLB1  RETURNED FROM CALL TO I/O MODULE: '           
                       WS-LINK-MODULE-NAME                                      
FXXTOK         DISPLAY 'GWFSPLB1  RECORD-NAME         = '                       
                       RECORD-NAME                                              
FXXTOK         DISPLAY 'GWFSPLB1  ERROR-STATUS        = '                       
                       ERROR-STATUS                                             
FXXTOK         DISPLAY 'GWFSPLB1  SQLCODE             = '                       
                   WS-SQLCODE-DEBUG-DISPLAY                                     
           END-IF                                                               
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
             OR FCCSPL-DEBUG-FLAG = '4'                                         
               PERFORM 1000-DISPLAY-ELAPSED                                     
                  THRU 1000-DISPLAY-ELAPSED-EXIT                                
           END-IF                                                               
           MOVE SPACES TO FCCSPL-CURR-REC-NAME                                  
           MOVE SPACES TO FCCSPL-CURR-REC-KEY                                   
           IF FCCSPLLK-SQLCODE = -913                                           
               PERFORM 124-SQL-ROLLBACK                                         
               MOVE -911 TO FCCSPLLK-SQLCODE                                    
           END-IF                                                               
                                                                                
           IF FCCSPLLK-SQLCODE = -911                                           
               MOVE WS-IDMS-MAJOR-CODE TO ERROR-STATUS (1:2)                    
               MOVE '29' TO ERROR-STATUS (3:2)                                  
           END-IF                                                               
                                                                                
           IF FCCSPL-EVALUATE-ERROR-FLAG = 'Y'                                  
               MOVE '9998' TO ERROR-STATUS                                      
               MOVE 'N' TO FCCSPL-EVALUATE-ERROR-FLAG                           
           END-IF.                                                              
                                                                                
           IF ERROR-STATUS = '9999'                                             
               IF FCCSPL-IOMOD-SQLCODE < ZERO                                   
                   MOVE '9' TO WS-SQLCODE-DISPLAY                               
                   COMPUTE WS-SQLCODE-NUMERIC =                                 
                       FCCSPL-IOMOD-SQLCODE * (-1)                              
               ELSE                                                             
                   MOVE '8' TO WS-SQLCODE-DISPLAY                               
                   MOVE FCCSPL-IOMOD-SQLCODE TO WS-SQLCODE-NUMERIC              
               END-IF                                                           
               MOVE WS-SQLCODE-DISPLAY TO ERROR-STATUS                          
           END-IF.                                                              
                                                                                
       420-LINK-TO-SQL-MODULE-EXIT.                                             
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             970-EVALUATE-ERROR ROUTINE                         *        
      *----------------------------------------------------------------*        
       970-EVALUATE-ERROR SECTION.                                              
                                                                                
           IF ERROR-STATUS = ZERO                                               
               MOVE '7777' TO ERROR-STATUS                                      
           END-IF.                                                              
                                                                                
           PERFORM 985-WRITE-ERROR-QUEUE                                        
                                                                                
           EXEC SQL                                                             
               ROLLBACK                                                         
           END-EXEC                                                             
                                                                                
           MOVE LOW-VALUES TO FCCSPL-ADDRESSES.                                 
           MOVE    +99 TO COMP-CODE                                             
GNE   *%   CALL    'ILBOABN0' USING COMP-CODE.                                  
GNE        CALL SNAPAID                                                         
GNE        MOVE +13 TO RETURN-CODE                                              
GNE        CALL CEE3ABD USING ABDCODE                                           
GNE                           ABDCLEANUP.                                       
                                                                                
       970-EVALUATE-ERROR-EXIT.                                                 
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             980-ABORT ROUTINE                                  *        
      *----------------------------------------------------------------*        
       980-ABORT SECTION.                                                       
                                                                                
           PERFORM 985-WRITE-ERROR-QUEUE                                        
                                                                                
           EXEC SQL                                                             
               ROLLBACK                                                         
           END-EXEC                                                             
                                                                                
           MOVE LOW-VALUES TO FCCSPL-ADDRESSES.                                 
           MOVE    +99 TO COMP-CODE                                             
GNE   *%   CALL    'ILBOABN0' USING COMP-CODE.                                  
GNE        CALL SNAPAID                                                         
GNE        MOVE +13 TO RETURN-CODE                                              
GNE        CALL CEE3ABD USING ABDCODE                                           
GNE                           ABDCLEANUP.                                       
                                                                                
       980-ABORT-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             985-WRITE-ERROR-QUEUE ROUTINE                      *        
      *----------------------------------------------------------------*        
       985-WRITE-ERROR-QUEUE SECTION.                                           
                                                                                
           MOVE SPACES TO SPERR-DATE.                                           
           MOVE SPACES TO SPERR-TIME.                                           
           MOVE SPACES TO SPERR-PROGRAM-NAME.                                   
           MOVE ZERO TO SPERR-DML-SEQ-NO.                                       
           MOVE SPACES TO SPERR-RECORD-NAME.                                    
           MOVE SPACES TO SPERR-SET-NAME.                                       
           MOVE SPACES TO SPERR-ERROR-MESSAGE.                                  
           MOVE SPACES TO SPERR-METHOD-NAME.                                    
           MOVE SPACES TO SPERR-ERROR-STATUS.                                   
           MOVE ZERO TO SPERR-SQLCODE.                                          
           MOVE SPACES TO SPERR-SQLERRMC-AREA.                                  
           MOVE ZERO TO SPERR-DML-SEQ-NO.                                       
           MOVE ZERO TO SPERR-SQLCODE.                                          
                                                                                
           MOVE FCCSPL-PROGRAM-NAME   TO SPERR-PROGRAM-NAME                     
           MOVE FCCSPL-RECORD-NAME    TO SPERR-RECORD-NAME                      
           MOVE FCCSPL-ERROR-MESSAGE  TO SPERR-ERROR-MESSAGE                    
           MOVE FCCSPL-SET-NAME       TO SPERR-SET-NAME                         
           MOVE FCCSPL-METHOD-NAME    TO SPERR-METHOD-NAME                      
           MOVE FCCSPL-DML-SEQ-NO     TO SPERR-DML-SEQ-NO                       
           MOVE FCCSPL-IOMOD-SQLCODE  TO SPERR-SQLCODE                          
           MOVE ERROR-STATUS TO SPERR-ERROR-STATUS                              
                                                                                
           IF FCCSPL-IOMOD-SQLCODE NOT < ZERO                                   
               MOVE ZERO TO SPERR-SQLERRML                                      
           ELSE                                                                 
               MOVE FCCSPL-IOMOD-SQLERRML TO SPERR-SQLERRML                     
           END-IF.                                                              
                                                                                
           MOVE FCCSPL-IOMOD-SQLERRMC TO SPERR-SQLERRMC-AREA                    
                                                                                
           DISPLAY ' '.                                                         
FXXTOK     DISPLAY 'GWFSPLB1 ERROR, DATA FOLLOWS'                               
           DISPLAY ' '.                                                         
           DISPLAY '    '  SPLITTER-ERROR-AREA-1                                
           DISPLAY '    '  SPLITTER-ERROR-AREA-2                                
           DISPLAY '    '  SPLITTER-ERROR-AREA-3.                               
                                                                                
       985-WRITE-ERROR-QUEUE-EXIT.                                              
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             989-DISPLAY-STATS ROUTINE                          *        
      *----------------------------------------------------------------*        
       989-DISPLAY-STATS SECTION.                                               
                                                                                
           MOVE ZERO TO WS-SUB1                                                 
           PERFORM 499 TIMES                                                    
               ADD 1 TO WS-SUB1                                                 
               IF WS-STATS-TIMES-EXECUTED (WS-SUB1) > ZERO                      
                   MOVE WS-SUB1 TO WS-DML-SEQ-NO-DISPLAY                        
                   MOVE WS-STATS-TIMES-EXECUTED (WS-SUB1) TO                    
                       WS-TIMES-EXECUTED-DISPLAY                                
FXXTOK             DISPLAY 'GWFSPLB1 STATS, DML SEQ # '                         
                       WS-DML-SEQ-NO-DISPLAY                                    
                       ' WAS EXECUTED '                                         
                       WS-TIMES-EXECUTED-DISPLAY                                
                       ' TIMES'                                                 
                   MOVE WS-STATS-TOTAL-TIME(WS-SUB1) TO                         
                       WS-TOT-EXECUTION-TIME-DISPLAY                            
                   DISPLAY '    TOTAL EXECUTION TIME IN HUNDRETHS OF'           
                       ' A SECOND = '                                           
                       WS-TOT-EXECUTION-TIME-DISPLAY                            
                   COMPUTE WS-AVG-EXECUTION-TIME-DISPLAY =                      
                       WS-STATS-TOTAL-TIME(WS-SUB1) /                           
                       WS-STATS-TIMES-EXECUTED (WS-SUB1)                        
                   DISPLAY '    AVG   EXECUTION TIME IN HUNDRETHS OF'           
                       ' A SECOND = '                                           
                       WS-AVG-EXECUTION-TIME-DISPLAY                            
               END-IF                                                           
           END-PERFORM.                                                         
                                                                                
       989-DISPLAY-STATS-EXIT.                                                  
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *             990-RETURN ROUTINE                                 *        
      *----------------------------------------------------------------*        
       990-RETURN SECTION.                                                      
                                                                                
           MOVE LOW-VALUES TO FCCSPL-ADDRESSES.                                 
           MOVE ZERO TO FCCSPL-A-RECORD.                                        
           MOVE 'N' TO WS-RECORD-RELATED-FLAG.                                  
           MOVE SPACES TO FCCSPL-RECORD-NAME                                    
           MOVE 'Y' TO DBLINK-INIT-HV-FLAG                                      
                                                                                
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
               MOVE FCCSPL-IOMOD-SQLCODE TO WS-SQLCODE-DEBUG-DISPLAY            
               DISPLAY ' '                                                      
FXXTOK         DISPLAY 'GWFSPLB1  ABOUT TO RETURN TO CALLING PROGRAM'           
FXXTOK         DISPLAY 'GWFSPLB1  RECORD-NAME         = '                       
                       RECORD-NAME                                              
FXXTOK         DISPLAY 'GWFSPLB1  ERROR-STATUS        = '                       
                       ERROR-STATUS                                             
FXXTOK         DISPLAY 'GWFSPLB1  SQLCODE             = '                       
                   WS-SQLCODE-DEBUG-DISPLAY                                     
           END-IF                                                               
           MOVE DBLINK-CURSOR-CODES TO WS-CURSOR-CODES-SAVE.                    
                                                                                
           GOBACK.                                                              
                                                                                
       990-RETURN-EXIT.                                                         
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *----------------------------------------------------------------*        
       1000-DISPLAY-ELAPSED SECTION.                                            
                                                                                
           MOVE TRACE-TABLE TO WORKT-TABLE                                      
           MOVE WORKT-TABLE TO TRACE-TABLE(9:)                                  
           MOVE FCCSPL-DML-SEQ-NO TO TRACE-TABLE(1:4)                           
           MOVE ERROR-STATUS      TO TRACE-TABLE(5:4)                           
*******    EXEC SQL                                                             
*******        SELECT CURRENT TIMESTAMP                                         
*******          INTO :WS-TIMESTAMP                                             
*******    END-EXEC                                                             
           EXEC SQL                                                             
               SET :WS-TIMESTAMP = CURRENT TIMESTAMP                            
           END-EXEC                                                             
           MOVE WS-TIMESTAMP  TO WS-TIMESTAMP-WORK.                             
           COMPUTE WS-TIME2 =                                                   
               (((WS-HOUR * 60) + WS-MIN) * 60) + WS-SEC + WS-MS                
           COMPUTE WS-ELAPSED = WS-TIME2 - WS-TIME1                             
           IF FCCSPL-BATCH-DEBUG-DISPLAY                                        
           DIVIDE WS-ELAPSED BY +60 GIVING WS-WORK-MIN                          
               REMAINDER WS-WORK-SEC                                            
           DIVIDE WS-WORK-MIN  BY 60 GIVING WS-WORK-HR                          
               REMAINDER WS-WORK-MIN                                            
           MOVE WS-WORK-HR TO WS-DISP-HR                                        
           MOVE WS-WORK-MIN TO WS-DISP-MIN                                      
           MOVE WS-WORK-SEC TO WS-DISP-SEC                                      
FXXTOK     DISPLAY 'GWFSPLB1  I/O MODULE TIME: ' WS-DISPLAY                     
           END-IF                                                               
           SET IX1 TO FCCSPL-DML-SEQ-NO                                         
           MOVE FCCSPL-DML-SEQ-NO TO WS-DML-NO(IX1)                             
           ADD +1         TO WS-COUNT(IX1) WS-GRAND-COUNT.                      
           ADD WS-ELAPSED TO WS-TOTAL(IX1) WS-GRAND-TIME.                       
                                                                                
       1000-DISPLAY-ELAPSED-EXIT.                                               
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *----------------------------------------------------------------*        
       1010-DISPLAY-TOTALS SECTION.                                             
                                                                                
           DISPLAY ' '.                                                         
FXXTOK     DISPLAY 'GWFSPLB1  I/O MODULE TIME BY DML'                           
           DISPLAY ' '.                                                         
           MOVE 'N' TO WS-FLAG                                                  
           PERFORM WITH TEST AFTER UNTIL WS-FLAG = 'N'                          
               SET IX1 TO +1                                                    
               SET IX2 TO +2                                                    
               MOVE 'N' TO WS-FLAG                                              
               PERFORM WITH TEST AFTER UNTIL IX2 > +249                         
                   IF WS-TOTAL(IX1) < WS-TOTAL(IX2)                             
                       MOVE WS-ROW(IX1) TO WS-ROW(250)                          
                       MOVE WS-ROW(IX2) TO WS-ROW(IX1)                          
                       MOVE WS-ROW(250) TO WS-ROW(IX2)                          
                       MOVE 'Y' TO WS-FLAG                                      
                   END-IF                                                       
                   SET IX1 IX2 UP BY +1                                         
               END-PERFORM                                                      
           END-PERFORM.                                                         
           SET IX1 TO +1.                                                       
           PERFORM WITH TEST BEFORE UNTIL WS-TOTAL(IX1) = +0                    
               DIVIDE WS-TOTAL(IX1) BY +60 GIVING WS-WORK-MIN                   
                   REMAINDER WS-WORK-SEC                                        
               DIVIDE WS-WORK-MIN  BY 60 GIVING WS-WORK-HR                      
                   REMAINDER WS-WORK-MIN                                        
               MOVE WS-WORK-HR TO WS-DISP-HR                                    
               MOVE WS-WORK-MIN TO WS-DISP-MIN                                  
               MOVE WS-WORK-SEC TO WS-DISP-SEC                                  
               MOVE WS-COUNT(IX1) TO WS-DISPLAY-2                               
               COMPUTE WS-PERCENT ROUNDED                                       
                       = WS-TOTAL(IX1) * 100 / WS-GRAND-TIME                    
               MOVE WS-PERCENT TO WS-PERCENT-1                                  
               COMPUTE WS-PERCENT ROUNDED                                       
                       = WS-COUNT(IX1) * 100 / WS-GRAND-COUNT                   
               MOVE WS-PERCENT TO WS-PERCENT-2                                  
               DISPLAY '          '                                             
                       'DML: ' WS-DML-NO(IX1) ' TOTAL TIME: ' WS-DISPLAY        
                       '  PERCENT ' WS-PERCENT-1                                
                      '    TOTAL CALLS: '  WS-DISPLAY-2                         
                       '  PERCENT ' WS-PERCENT-2                                
               SET IX1 UP BY +1                                                 
           END-PERFORM.                                                         
                                                                                
       1010-DISPLAY-TOTALS-EXIT.                                                
           EXIT.                                                                
                                                                                
