       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.    GC2LCALC.                                                 
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *DATE-WRITTEN.  APR 1992.                                                 
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *    USING THE PASSED COMMISSION SCALE RECORD, BASE AND CURRENT           
      *    PREMIUM AMOUNT, CALCULATE THE AMOUNT OF COMMISSION FOR               
      *    CURRENT PREMIUM.                                                     
      ******************************************************************        
      ******************************************************************        
      * AUG 08 IBM GR                                                           
      *      - UPGRADED IN ECU PROJECT                                          
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GCSLCALC          
      ******************************************************************        
                                                                                
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(24)      VALUE                       
FXXTOK     'GC2LCALC WS STARTS HERE*'.                                          
                                                                                
       01  WS-FIELDS.                                                           
           05  GTABCOMM-SUB          PIC S9(3)      VALUE ZEROES.               
           05  END-OF-PROC-SW        PIC X          VALUE 'N'.                  
               88  END-OF-PROCESSING                VALUE 'Y'.                  
           05  WS-TOT-PREM           PIC S9(7)V99   VALUE ZEROES                
                                                    COMP-3.                     
           05  WS-CURR-PREM          PIC S9(7)V99   VALUE ZEROES                
                                                    COMP-3.                     
           05  WS-TEMP-PREM          PIC S9(7)V99   VALUE ZEROES                
                                                    COMP-3.                     
           05  WS-CALC-PREM          PIC S9(7)V99   VALUE ZEROES                
                                                    COMP-3.                     
           05  WS-CALC-COMM          PIC S9(7)V99   VALUE ZEROES                
                                                    COMP-3.                     
                                                                                
      /                                                                         
       01  WS-END                    PIC X(24)      VALUE                       
FXXTOK     'GC2LCALC WS ENDS   HERE*'.                                          
       01  WS-END-BYTE-X             PIC X(1)       VALUE '*'.                  
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE '        '   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
       LINKAGE SECTION.                                                         
                                                                                
      *01  GCSLCALP.                                                            
           COPY GCSLCALP.                                                       
       01  GTABCOMM-RECORD.                                                     
           COPY GTABCOMM.                                                       
      /                                                                         
       PROCEDURE DIVISION USING GCSL-CALC-PARMS                                 
                                GTABCOMM-RECORD.                                
                                                                                
       0000-GCSLCALC.                                                           
      ******************************************************************        
      *    INIT RETURN AREA.                                                    
      ******************************************************************        
           MOVE GCSL-BASE-PREMIUM   TO WS-TOT-PREM.                             
           MOVE GCSL-CURR-PREMIUM   TO WS-CURR-PREM.                            
           MOVE +0                  TO WS-TEMP-PREM.                            
           MOVE +0                  TO WS-CALC-PREM.                            
           MOVE '0'                 TO GCSL-CALC-RET-CODE.                      
           MOVE 'N'                 TO END-OF-PROC-SW.                          
           MOVE +1                  TO GTABCOMM-SUB.                            
      *                                                                         
           PERFORM 1000-CHECK-PREMIUM  THRU                                     
                   1000-CHECK-PREMIUM-EXIT                                      
            VARYING GTABCOMM-SUB  FROM  +1  BY +1                               
              UNTIL GTABCOMM-SUB  >     GTABCOMM-BAND-CNT                       
               OR   END-OF-PROCESSING.                                          
      *                                                                         
                                                                                
       0000-GCSLCALC-EXIT.                                                      
           GOBACK.                                                              
      /                                                                         
       1000-CHECK-PREMIUM.                                                      
      ******************************************************************        
      *  CHECK THE PREMIUMS GIVEN THE RATE TABLE PASSED.                        
      ******************************************************************        
                                                                                
           IF  WS-TOT-PREM > GTABCOMM-BAND-AMT (GTABCOMM-SUB)                   
               GO TO 1000-CHECK-PREMIUM-EXIT.                                   
                                                                                
           MOVE WS-CURR-PREM         TO WS-TEMP-PREM.                           
           ADD  WS-CURR-PREM         TO WS-TOT-PREM.                            
                                                                                
           IF  WS-TOT-PREM > GTABCOMM-BAND-AMT (GTABCOMM-SUB)                   
               SUBTRACT WS-CURR-PREM FROM WS-TOT-PREM                           
               MOVE GTABCOMM-BAND-AMT (GTABCOMM-SUB)                            
                                       TO WS-TEMP-PREM                          
               SUBTRACT WS-TOT-PREM  FROM WS-TEMP-PREM.                         
                                                                                
           PERFORM 2000-CALC-COMM  THRU                                         
                   2000-CALC-COMM-EXIT.                                         
                                                                                
       1000-CHECK-PREMIUM-EXIT.                                                 
           EXIT.                                                                
      /                                                                         
       2000-CALC-COMM.                                                          
      ******************************************************************        
      *    CALCULATE THE COMM BASED ON THE RECORD PASSED TO THE PROGRAM         
      ******************************************************************        
           SUBTRACT WS-TEMP-PREM FROM WS-CURR-PREM.                             
           MOVE WS-TEMP-PREM       TO WS-CALC-PREM.                             
           COMPUTE WS-CALC-COMM ROUNDED                                         
                                 =  (WS-CALC-PREM *                             
                                     GTABCOMM-BAND-PCT                          
                                         (GTABCOMM-SUB)) / 100.                 
           ADD  WS-CALC-COMM       TO GCSL-COMMISSION.                          
      *                                                                         
           IF  WS-CURR-PREM      =   +0                                         
               MOVE 'Y'            TO END-OF-PROC-SW                            
           ELSE                                                                 
               ADD WS-TEMP-PREM    TO WS-TOT-PREM.                              
                                                                                
       2000-CALC-COMM-EXIT.                                                     
           EXIT.                                                                
      /                                                                         
                                                                                
