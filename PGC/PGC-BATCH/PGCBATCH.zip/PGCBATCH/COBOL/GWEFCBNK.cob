       IDENTIFICATION DIVISION.                                         00010000
       PROGRAM-ID.    GWEFCBNK.                                         00020000
      *AUTHOR.        BRYAN MELANSON.                                   00030000
      *INSTALLATION.  MANULIFE.                                         00040000
      *DATE-WRITTEN.                                                    00050000
      *DATE-COMPILED.                                                   00060000
      *----------------------------------------------------------------*00070000
      *  SYSTEM    : EFT                                                00080000
      *                                                                 00090000
      *  LANGUAGE  : COBOL II (CIIBC)                                   00100000
      *                                                                 00110000
      *    THIS MODULE PERFORMS I/O FUNCTIONS FOR EFT BANK INFORMATION  00120000
      *  FILE.  IT FILLS IN KEY INFO AND ADJUSTS VERBS RECEIVED FROM    00130000
      *  THE APPLICATION.  FOR EXAMPLE THE APPLICATION MAY THINK IT IS  00140000
      *  DOING A 'KEYED READ', BUT IS ACTUALLY STARTING A BROWSE AND    00150000
      *  READING THE FIRST RECORD.                                      00160000
      *    IT CALLS EITHER A CICS OR BATCH SUB MODULE TO PERFORM THE    00170000
      *  ACTUAL I/O LOGIC                                               00180000
      *                                                                 00190000
      *NOTE: LINKAGE AREA IS IN COMMON WITH HISTORY IO MODULE GWEFCHST  00200000
      *                                                                 00210000
      *-HISTORY LOG-------------------------------------------------    00220000
      *  SEQ  DATE       DESIGNER   DESCRIPTION                         00230000
      *  001  SEP 1999   B MELANSON CREATED                             00240000
BM002 *  002  NOV 1999   B MELANSON -EDITS ARE MOVED UP TO CICS SCREEN  00250000
BM002 *                             -REVERSE LOGIC IMPROVED             00260000
BM002 *                             -ADDING WITH PREVIOUS VOIDS         00270000
      *  003  15MAR2008 IBM GR       ENTERPRISE COMPILER UPGRADE        00280000
      *                              PROJECT - BUNDLE 5                 00290000
      *----------------------------------------------------------------*00300000
                                                                        00310000
       ENVIRONMENT DIVISION.                                            00320000
       CONFIGURATION SECTION.                                           00330000
       SOURCE-COMPUTER. IBM-370.                                        00340000
       OBJECT-COMPUTER. IBM-370.                                        00350000
       INPUT-OUTPUT SECTION.                                            00360000
       FILE-CONTROL.                                                    00370000
       DATA DIVISION.                                                   00380000
       FILE SECTION.                                                    00390000
                                                                        00400000
       WORKING-STORAGE SECTION.                                         00410000
       01  FILLER                             PIC X(40) VALUE           00420000
               '**   GWEFCBNK WORKING STORAGE BEGINS  **'.              00430000
                                                                        00440000
      *----------------------------------------------------------------*00450000
      *  EFT BANK INFORMATION RECORD LAYOUT                            *00460000
      *----------------------------------------------------------------*00470000
       01  EFT-BANK-INFO.    COPY GWEFRBNK.                             00480000
                                                                        00490000
      *----------------------------------------------------------------*00500000
      *    WORK VARIABLES                                              *00510000
      *----------------------------------------------------------------*00520000
       01  WORK-FIELDS.                                                 00530000
           05 HIGH-DATE    VALUE 99999999         PIC 9(08).            00540000
           05 I-O-SUBROUTINES.                                          00550000
               10 GWEFCCBP VALUE 'GWEFCCBP'       PIC X(08).            00560000
               10 GWEFCBBP VALUE 'GWEFCBBP'       PIC X(08).            00570000
           05 FILLER                VALUE 'N'     PIC X(01).            00580000
              88  NO-DESIRED-FOUND  VALUE 'N'.                          00590000
              88  A-DESIRED-FOUND   VALUE 'F'.                          00600000
           05  RESTART-BANK-INFO-KEY               PIC X(68).           00610000
           05  SV-MNT-SEQ                          PIC 9(02).           00620000
           05  ADD-MNT-SEQ                         PIC 9(02).           00630000
           05  WK-EFF-DATE-COMPLEMENT              PIC 9(08).           00640000
           05  FILLER                  VALUE 'N '  PIC X(02).           00650000
               88  BROWSE-NOT-STARTED  VALUE 'N '.                      00660000
               88  BROWSE-ACTIVE       VALUE 'BA'.                      00670000
               88  BROWSE-DORMANT      VALUE 'BD'.                      00680000
                                                                        00690000
      * LINKAGE FOR THE EFT I/O SUBROUTINES                             00700000
       01  IOS-REQUEST-PARMS.  COPY GWEFLIOS.                           00710000
                                                                        00720000
                                                                        00730000
                                                                        00740000
       01  FILLER                   PIC X(40) VALUE                     00750000
               '***  GWEFCBNK WORKING STORAGE ENDS   ***'.              00760000
                                                                        00770000
       LINKAGE SECTION.                                                 00780000
                                                                        00790000
      * LINKAGE FOR THE EFT I/O MAINLINES                               00800000
       01  IOM-REQUEST-PARMS.  COPY GWEFLIOM.                           00810000
                                                                        00820000
                                                                        00830000
       PROCEDURE DIVISION USING IOM-REQUEST-PARMS.                      00840000
                                                                        00850000
       000-MAINLINE.                                                    00860000
           MOVE   SPACES          TO EFT-IOM-ERROR-DATA.                00870000
           SET  EFT-IOM-STATUS-OK TO TRUE.                              00880000
           EVALUATE TRUE                                                00890000
           WHEN EFT-IOM-START-BROWSE                                    00900000
               PERFORM 200-START-BROWSE        THRU 200-EXIT            00910000
           WHEN EFT-IOM-END-BROWSE                                      00920000
               PERFORM 280-END-BROWSE          THRU 280-EXIT            00930000
           WHEN EFT-IOM-READ-NEXT-VALID                                 00940000
               PERFORM 300-READ-NEXT-VALID     THRU 300-EXIT            00950000
           WHEN EFT-IOM-READ-NEXT                                       00960000
               SET NO-DESIRED-FOUND            TO TRUE                  00970000
               PERFORM 320-READ-NEXT-RECORD    THRU 320-EXIT            00980000
           WHEN EFT-IOM-READ-PREV-VALID                                 00990000
               PERFORM 340-READ-PREV-VALID     THRU 340-EXIT            01000000
           WHEN EFT-IOM-READ-PREV                                       01010000
               SET NO-DESIRED-FOUND            TO TRUE                  01020000
               PERFORM 360-READ-PREV-RECORD    THRU 360-EXIT            01030000
           WHEN EFT-IOM-READ-KEYED                                      01040000
               PERFORM 380-READ-KEYED-RECORD   THRU 380-EXIT            01050000
           WHEN EFT-IOM-WRITE                                           01060000
               PERFORM 400-WRITE-BANK-RECORD   THRU 400-EXIT            01070000
           WHEN EFT-IOM-UPDATE                                          01080000
               PERFORM 420-UPDATE-BI-HISTORY   THRU 420-EXIT            01090000
           WHEN EFT-IOM-RE-WRITE                                        01100000
               PERFORM 450-REWRITE-BANK-RECORD THRU 450-EXIT            01110000
           WHEN EFT-IOM-CLOSE-FILE                                      01120000
               PERFORM 290-CLOSE-FILE          THRU 290-EXIT            01130000
           WHEN EFT-IOM-READ-FIRST                                      01140000
               SET EFT-IOM-NOT-SUPPORTED TO TRUE                        01150000
               MOVE 'VERB "  " NOT YET CODED  IN BANK INFO '            01160000
                        TO EFT-IOM-ERROR-TEXT                           01170000
               MOVE EFT-IOM-VERB TO EFT-IOM-ERROR-TEXT(7:2)             01180000
           WHEN EFT-IOM-OPEN-FILE                                       01190000
           WHEN EFT-IOM-DELETE                                          01200000
               SET EFT-IOM-NOT-SUPPORTED TO TRUE                        01210000
               MOVE 'VERB "  " WILL NOT BE SUPPORTED IN BANK INFO '     01220000
                        TO EFT-IOM-ERROR-TEXT                           01230000
               MOVE EFT-IOM-VERB TO EFT-IOM-ERROR-TEXT(7:2)             01240000
           WHEN OTHER                                                   01250000
               SET EFT-IOM-NOT-SUPPORTED TO TRUE                        01260000
               MOVE 'VERB "  " IS UNKNOWN TO THIS LOGIC '               01270000
                        TO EFT-IOM-ERROR-TEXT                           01280000
               MOVE EFT-IOM-VERB TO EFT-IOM-ERROR-TEXT(7:2)             01290000
           END-EVALUATE.                                                01300000
                                                                        01310000
           GOBACK.                                                      01320000
                                                                        01330000
      *----------------------------------------------                   01340000
      *--------                           -----------                   01350000
      *---                                       ----                   01360000
      *-       BROWSE MAINTENANCE SECTION           -                   01370000
      *---                                       ----                   01380000
      *--------                           -----------                   01390000
      *----------------------------------------------                   01400000
       200-START-BROWSE.                                                01410000
           IF BROWSE-ACTIVE                                             01420000
               PERFORM 280-END-BROWSE             THRU 280-EXIT         01430000
           END-IF.                                                      01440000
           IF EFT-IOM-STATUS-OK                                         01450000
               PERFORM 210-REQUEST-START-BROWSE   THRU 210-EXIT         01460000
           END-IF.                                                      01470000
       200-EXIT.    EXIT.                                               01480000
                                                                        01490000
      * START THE BROWSE FROM LINKAGE KEY FIELDS SENT (IOM)             01500000
       210-REQUEST-START-BROWSE.                                        01510000
           PERFORM 900-MOVE-IOM-TO-BNK-KEY-FIELDS THRU 900-EXIT.        01520000
           MOVE EFT-BANK-INFO           TO EFT-IOS-RECORD-DATA          01530000
           SET EFT-IOS-START-BROWSE     TO TRUE                         01540000
           PERFORM 990-IO-SUBROUTINE-CALL         THRU 990-EXIT.        01550000
           IF EFT-IOM-STATUS-OK                                         01560000
              SET BROWSE-ACTIVE TO TRUE                                 01570000
           END-IF.                                                      01580000
       210-EXIT.    EXIT.                                               01590000
                                                                        01600000
      * START THE BROWSE FROM LAST GOOD RECORD READ                     01610000
       215-RE-START-BROWSE.                                             01620000
           MOVE LOW-VALUES            TO EFT-BANK-INFO.                 01630000
           MOVE RESTART-BANK-INFO-KEY TO BNK-INFO-KEY.                  01640000
           MOVE EFT-BANK-INFO         TO EFT-IOS-RECORD-DATA.           01650000
           SET  EFT-IOS-START-BROWSE  TO TRUE.                          01660000
           PERFORM 990-IO-SUBROUTINE-CALL THRU 990-EXIT.                01670000
           IF EFT-IOM-STATUS-OK                                         01680000
              SET BROWSE-ACTIVE      TO TRUE                            01690000
           ELSE                                                         01700000
              SET BROWSE-NOT-STARTED TO TRUE                            01710000
           END-IF.                                                      01720000
       215-EXIT.    EXIT.                                               01730000
                                                                        01740000
                                                                        01750000
       270-SUSPEND-BROWSE.                                              01760000
           SET EFT-IOS-END-BROWSE   TO TRUE.                            01770000
           PERFORM 990-IO-SUBROUTINE-CALL THRU 990-EXIT.                01780000
           IF EFT-IOM-STATUS-OK                                         01790000
              SET BROWSE-DORMANT    TO TRUE                             01800000
           END-IF.                                                      01810000
       270-EXIT.    EXIT.                                               01820000
                                                                        01830000
       280-END-BROWSE.                                                  01840000
           SET EFT-IOS-END-BROWSE   TO TRUE.                            01850000
           PERFORM 990-IO-SUBROUTINE-CALL THRU 990-EXIT.                01860000
           IF EFT-IOM-STATUS-OK                                         01870000
               SET BROWSE-NOT-STARTED TO TRUE                           01880000
           END-IF.                                                      01890000
       280-EXIT.    EXIT.                                               01900000
                                                                        01910000
       290-CLOSE-FILE.                                                  01920000
           SET EFT-IOS-CLOSE        TO TRUE.                            01930000
           PERFORM 990-IO-SUBROUTINE-CALL THRU 990-EXIT.                01940000
       290-EXIT.    EXIT.                                               01950000
                                                                        01960000
      *----------------------------------------------                   01970000
      *--------                           -----------                   01980000
      *---                                       ----                   01990000
      *-           READ ACCESS  SECTION             -                   02000000
      *---                                       ----                   02010000
      *--------                           -----------                   02020000
      *----------------------------------------------                   02030000
*REV  *   IF IN A READ NEXT/PREV MODE AND WE READ OUT OF THE SET        02040000
*REV  * OF VALID RECORDS, THEN THE READ SHOULD REVERSE DIRECTION        02050000
*REV  * AND PROCEED UNTIL A VALID RECORD IS FOUND                       02060000
*REV  * - A 'SET OF RECORDS' MAY BE DEFINED AS THE TIME LINE FOR        02070000
*REV  *   ONE BANK INFORMATION SET                                      02080000
*REV  * - A VALID RECORD MAY BE ANY MEMBER OF THE SET, OR POSSIBLY      02090000
*REV  *   ONLY A RECORD THAT IS NOT VOIDED (DEPENDING ON REQUEST)       02100000
*REV  * - IF A 'DESIRED' RECORD WAS READ, WHEN REVERSING DIRECTION      02110000
*REV  *   2 READS ARE REQUIRED TO POSITION TO THE 'DESIRED' BLOCK       02120000
      *---------------------------------------------------------------- 02130000
      * IF BROWSE HAS TO BE OPENED, THEN RE-READ THE 'CURRENT' RECORD   02140000
      *  (FIRST RECORD READ WITH 'KEYED READ')                          02150000
      *---------------------------------------------------------------- 02160000
                                                                        02170000
       300-READ-NEXT-VALID.                                             02180000
           SET NO-DESIRED-FOUND              TO TRUE.                   02190000
           PERFORM 320-READ-NEXT-RECORD      THRU 320-EXIT              02200000
             WITH TEST AFTER                                            02210000
             UNTIL NOT BNK-VOID                                         02220000
                OR EFT-IOM-ERROR.                                       02230000
       300-EXIT.    EXIT.                                               02240000
                                                                        02250000
       320-READ-NEXT-RECORD.                                            02260000
           EVALUATE TRUE                                                02270000
           WHEN BROWSE-NOT-STARTED                                      02280000
               PERFORM 210-REQUEST-START-BROWSE         THRU 210-EXIT   02290000
               IF BROWSE-ACTIVE                                         02300000
                   PERFORM 325-REQUEST-READ-NEXT-RECORD THRU 325-EXIT   02310000
               END-IF                                                   02320000
           WHEN BROWSE-DORMANT                                          02330000
               PERFORM 215-RE-START-BROWSE              THRU 215-EXIT   02340000
               IF BROWSE-ACTIVE                                         02350000
                   PERFORM 325-REQUEST-READ-NEXT-RECORD THRU 325-EXIT   02360000
               END-IF                                                   02370000
           WHEN OTHER                                                   02380000
               CONTINUE                                                 02390000
           END-EVALUATE.                                                02400000
           IF BROWSE-ACTIVE                                             02410000
               PERFORM 325-REQUEST-READ-NEXT-RECORD   THRU 325-EXIT     02420000
               IF EFT-IOM-STATUS-OK                                     02430000
                  PERFORM 910-DETERMINE-IF-DESIRED    THRU 910-EXIT     02440000
                  IF EFT-IOM-NOT-FOUND                                  02450000
                     PERFORM 365-REQUEST-READ-PREV-RECORD  THRU 365-EXIT02460000
                     IF EFT-IOM-STATUS-OK                               02470000
                        PERFORM 910-DETERMINE-IF-DESIRED   THRU 910-EXIT02480000
                     END-IF                                             02490000
                     IF A-DESIRED-FOUND AND EFT-IOM-NOT-FOUND           02500000
                         PERFORM 365-REQUEST-READ-PREV-RECORD           02510000
                                                           THRU 365-EXIT02520000
                     END-IF                                             02530000
                     IF  EFT-IOM-STATUS-OK                              02540000
                      OR EFT-IOM-NOT-FOUND                              02550000
                        SET EFT-IOM-NOT-FOUND  TO TRUE                  02560000
                        MOVE 'END OF BROWSE'   TO EFT-IOM-ERROR-TEXT    02570000
                     END-IF                                             02580000
                  ELSE                                                  02590000
                     SET A-DESIRED-FOUND    TO TRUE                     02600000
                  END-IF                                                02610000
               END-IF                                                   02620000
           ELSE                                                         02630000
               SET EFT-IOM-READNEXT-FAILED TO TRUE                      02640000
               MOVE 'NO BROWSE IN EFFECT'  TO EFT-IOM-ERROR-TEXT        02650000
           END-IF.                                                      02660000
       320-EXIT.    EXIT.                                               02670000
                                                                        02680000
       325-REQUEST-READ-NEXT-RECORD.                                    02690000
           SET EFT-IOS-READ-NEXT      TO TRUE                           02700000
           PERFORM 990-IO-SUBROUTINE-CALL  THRU 990-EXIT.               02710000
       325-EXIT.    EXIT.                                               02720000
                                                                        02730000
       340-READ-PREV-VALID.                                             02740000
           SET NO-DESIRED-FOUND              TO TRUE.                   02750000
           PERFORM 360-READ-PREV-RECORD       THRU 360-EXIT             02760000
             WITH TEST AFTER                                            02770000
             UNTIL NOT BNK-VOID                                         02780000
                OR EFT-IOM-ERROR.                                       02790000
       340-EXIT.    EXIT.                                               02800000
                                                                        02810000
       360-READ-PREV-RECORD.                                            02820000
           EVALUATE TRUE                                                02830000
           WHEN BROWSE-NOT-STARTED                                      02840000
               PERFORM 210-REQUEST-START-BROWSE         THRU 210-EXIT   02850000
               IF BROWSE-ACTIVE                                         02860000
                   PERFORM 365-REQUEST-READ-PREV-RECORD THRU 365-EXIT   02870000
               END-IF                                                   02880000
           WHEN BROWSE-DORMANT                                          02890000
               PERFORM 215-RE-START-BROWSE              THRU 215-EXIT   02900000
               IF BROWSE-ACTIVE                                         02910000
                   PERFORM 365-REQUEST-READ-PREV-RECORD THRU 365-EXIT   02920000
               END-IF                                                   02930000
           WHEN OTHER                                                   02940000
               CONTINUE                                                 02950000
           END-EVALUATE.                                                02960000
           IF BROWSE-ACTIVE                                             02970000
               PERFORM 365-REQUEST-READ-PREV-RECORD   THRU 365-EXIT     02980000
               IF EFT-IOM-STATUS-OK                                     02990000
                  PERFORM 910-DETERMINE-IF-DESIRED    THRU 910-EXIT     03000000
                  IF EFT-IOM-NOT-FOUND                                  03010000
                     PERFORM 325-REQUEST-READ-NEXT-RECORD  THRU 325-EXIT03020000
                     IF EFT-IOM-STATUS-OK                               03030000
                        PERFORM 910-DETERMINE-IF-DESIRED   THRU 910-EXIT03040000
                     END-IF                                             03050000
                     IF A-DESIRED-FOUND AND EFT-IOM-NOT-FOUND           03060000
                         PERFORM 325-REQUEST-READ-NEXT-RECORD           03070000
                                                           THRU 325-EXIT03080000
                     END-IF                                             03090000
                     IF  EFT-IOM-STATUS-OK                              03100000
                      OR EFT-IOM-NOT-FOUND                              03110000
                        SET EFT-IOM-NOT-FOUND  TO TRUE                  03120000
                        MOVE 'END OF BROWSE'   TO EFT-IOM-ERROR-TEXT    03130000
                     END-IF                                             03140000
                  ELSE                                                  03150000
                     SET A-DESIRED-FOUND    TO TRUE                     03160000
                  END-IF                                                03170000
               END-IF                                                   03180000
           ELSE                                                         03190000
               SET EFT-IOM-READNEXT-FAILED TO TRUE                      03200000
               MOVE 'NO BROWSE IN EFFECT'  TO EFT-IOM-ERROR-TEXT        03210000
           END-IF.                                                      03220000
       360-EXIT.    EXIT.                                               03230000
                                                                        03240000
       365-REQUEST-READ-PREV-RECORD.                                    03250000
           SET EFT-IOS-READ-PREV           TO TRUE.                     03260000
           PERFORM 990-IO-SUBROUTINE-CALL  THRU 990-EXIT.               03270000
       365-EXIT.    EXIT.                                               03280000
                                                                        03290000
       380-READ-KEYED-RECORD.                                           03300000
           IF BROWSE-ACTIVE                                             03310000
               PERFORM 280-END-BROWSE               THRU 280-EXIT       03320000
           END-IF.                                                      03330000
           IF EFT-IOM-STATUS-OK                                         03340000
               PERFORM 210-REQUEST-START-BROWSE     THRU 210-EXIT       03350000
           END-IF.                                                      03360000
           EVALUATE TRUE                                                03370000
           WHEN EFT-IOM-STATUS-OK                                       03380000
               PERFORM 300-READ-NEXT-VALID          THRU 300-EXIT       03390000
               IF EFT-IOM-NOT-FOUND                                     03400000
                   MOVE 'RECORD NOT FOUND' TO EFT-IOM-ERROR-TEXT        03410000
               END-IF                                                   03420000
           WHEN EFT-IOM-STARTBR-FAILED                                  03430000
               SET   EFT-IOM-NOT-FOUND     TO TRUE                      03440000
               MOVE 'RECORD NOT FOUND'     TO EFT-IOM-ERROR-TEXT        03450000
           WHEN OTHER                                                   03460000
               CONTINUE                                                 03470000
           END-EVALUATE.                                                03480000
       380-EXIT.    EXIT.                                               03490000
                                                                        03500000
      *----------------------------------------------                   03510000
      *--------                           -----------                   03520000
      *---                                       ----                   03530000
      *-          UPDATE ACCESS SECTION             -                   03540000
      *---                                       ----                   03550000
      *--------                           -----------                   03560000
      *----------------------------------------------                   03570000
                                                                        03580000
      *---------------------------------------------------------------- 03590000
      *    THIS LOGIC PERFORMS THE FUNCTION OF 'ADDING' A NEW BANK INFO 03600000
      * STREAM OF RECORDS FOR A NEW GROUP WITHIN THE RECORD TYPE        03610000
      *---------------------------------------------------------------- 03620000
       400-WRITE-BANK-RECORD.                                           03630000
           IF BROWSE-ACTIVE                                             03640000
               PERFORM 280-END-BROWSE             THRU 280-EXIT         03650000
           END-IF.                                                      03660000
           IF EFT-IOM-STATUS-OK                                         03670000
               PERFORM 405-WRITE-EDITS            THRU 405-EXIT         03680000
           END-IF.                                                      03690000
           IF EFT-IOM-STATUS-OK                                         03700000
               SET  EFT-IOS-WRITE       TO TRUE                         03710000
               MOVE EFT-BANK-INFO       TO EFT-IOS-RECORD-DATA          03720000
               PERFORM 990-IO-SUBROUTINE-CALL     THRU 990-EXIT         03730000
               IF EFT-IOM-STATUS-OK                                     03740000
                   MOVE EFT-BANK-INFO   TO EFT-IOM-RECORD-DATA          03750000
               END-IF                                                   03760000
           END-IF.                                                      03770000
       400-EXIT.    EXIT.                                               03780000
                                                                        03790000
      *---------------------------------------------------------------- 03800000
      * -REVIEW BROWSE DATA LOOKING FOR CHRONOLOGICAL POSITION          03810000
      * -EFF DATE OF NEW DATA MAY NOT PRECEED CURRENT VALID DATA        03820000
      *---------------------------------------------------------------- 03830000
       405-WRITE-EDITS.                                                 03840000
           PERFORM 210-REQUEST-START-BROWSE      THRU 210-EXIT.         03850000
           EVALUATE TRUE                                                03860000
           WHEN EFT-IOM-STATUS-OK                                       03870000
               SUBTRACT BNK-IOM-MNT-DATE FROM HIGH-DATE                 03880000
                                GIVING WK-EFF-DATE-COMPLEMENT           03890000
               SET NO-DESIRED-FOUND              TO TRUE                03900000
               PERFORM 320-READ-NEXT-RECORD      THRU 320-EXIT          03910000
                 WITH TEST AFTER                                        03920000
                 UNTIL NOT BNK-VOID                                     03930000
                    OR (   BNK-VOID AND  WK-EFF-DATE-COMPLEMENT         03940000
                                   NOT > BNK-EFF-DATE-COMPLEMENT)       03950000
                    OR EFT-IOM-ERROR                                    03960000
               PERFORM 410-ADD-EDITS             THRU 410-EXIT          03970000
               IF EFT-IOM-STATUS-OK                                     03980000
                   PERFORM 270-SUSPEND-BROWSE    THRU 270-EXIT          03990000
               END-IF                                                   04000000
           WHEN EFT-IOM-STARTBR-FAILED                                  04010000
               SET EFT-IOM-NOT-FOUND   TO TRUE                          04020000
               PERFORM 410-ADD-EDITS             THRU 410-EXIT          04030000
           END-EVALUATE.                                                04040000
           IF EFT-IOM-STATUS-OK                                         04050000
              SUBTRACT BNK-IOM-EFF-DATE FROM HIGH-DATE                  04060000
                       GIVING BNK-EFF-DATE-COMPLEMENT                   04070000
              SUBTRACT BNK-IOM-MNT-DATE FROM HIGH-DATE                  04080000
                       GIVING BNK-MNT-DATE-COMPLEMENT                   04090000
              MOVE SV-MNT-SEQ  TO BNK-MNT-SEQ-COMPLEMENT                04100000
           END-IF.                                                      04110000
       405-EXIT.    EXIT.                                               04120000
                                                                        04130000
       410-ADD-EDITS.                                                   04140000
           EVALUATE TRUE                                                04150000
           WHEN EFT-IOM-NOT-FOUND                                       04160000
                MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO               04170000
BM002           SET EFT-IOM-STATUS-OK TO TRUE                           04180000
BM002           MOVE 98 TO                               SV-MNT-SEQ     04190000
           WHEN EFT-IOM-STATUS-OK                                       04200000
             AND BNK-VOID                                               04210000
             AND BNK-RECORD-TYPE = EFT-IOM-RECORD-TYPE                  04220000
             AND BNK-KEY-TYPE    = EFT-IOM-KEY-TYPE                     04230000
             AND BNK-KEY-DATA    = EFT-IOM-KEY-DATA                     04240000
BM002           IF    HIGH-DATE - BNK-IOM-MNT-DATE                      04250000
BM002                            = BNK-MNT-DATE-COMPLEMENT              04260000
BM002             AND HIGH-DATE - BNK-IOM-EFF-DATE                      04270000
BM002                            = BNK-EFF-DATE-COMPLEMENT              04280000
BM002               SUBTRACT 1 FROM BNK-MNT-SEQ-COMPLEMENT              04290000
BM002                                            GIVING ADD-MNT-SEQ     04300000
BM002           ELSE                                                    04310000
BM002               MOVE 98 TO                          ADD-MNT-SEQ     04320000
BM002           END-IF                                                  04330000
BM002           PERFORM 320-READ-NEXT-RECORD      THRU 320-EXIT         04340000
BM002             WITH TEST AFTER                                       04350000
BM002             UNTIL NOT BNK-VOID                                    04360000
BM002                OR EFT-IOM-ERROR                                   04370000
BM002           IF EFT-IOM-STATUS-OK                                    04380000
BM002             AND BNK-RECORD-TYPE = EFT-IOM-RECORD-TYPE             04390000
BM002             AND BNK-KEY-TYPE    = EFT-IOM-KEY-TYPE                04400000
BM002             AND BNK-KEY-DATA    = EFT-IOM-KEY-DATA                04410000
BM002           THEN                                                    04420000
BM002              SET EFT-IOM-BAD-KEY   TO TRUE                        04430000
BM002              MOVE 'BANK INFO ALREADY EXISTS' TO EFT-IOM-ERROR-TEXT04440000
BM002           ELSE                                                    04450000
BM002              MOVE ADD-MNT-SEQ         TO SV-MNT-SEQ               04460000
BM002              MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO            04470000
BM002              SET EFT-IOM-STATUS-OK    TO TRUE                     04480000
BM002           END-IF                                                  04490000
           WHEN EFT-IOM-ERROR                                           04500000
                CONTINUE                                                04510000
           WHEN  BNK-RECORD-TYPE = EFT-IOM-RECORD-TYPE                  04520000
             AND BNK-KEY-TYPE    = EFT-IOM-KEY-TYPE                     04530000
             AND BNK-KEY-DATA    = EFT-IOM-KEY-DATA                     04540000
                SET EFT-IOM-BAD-KEY   TO TRUE                           04550000
                MOVE 'BANK INFO ALREADY EXISTS' TO EFT-IOM-ERROR-TEXT   04560000
           WHEN OTHER                                                   04570000
                SET EFT-IOM-LOGIC-ERROR TO TRUE                         04580000
                MOVE 'EFTCIBNK 410- '   TO EFT-IOM-ERROR-TEXT           04590000
           END-EVALUATE.                                                04600000
       410-EXIT.    EXIT.                                               04610000
                                                                        04620000
      *---------------------------------------------------------------- 04630000
      *    THIS LOGIC PERFORMS THE FUNCTION OF ADDING A NEW BANK INFO   04640000
      * RECORD INTO AN EXISTING HISTORY STREAM OF RECORDS FOR A GROUP   04650000
      * WITHIN THE RECORD TYPE                                          04660000
      *---------------------------------------------------------------- 04670000
       420-UPDATE-BI-HISTORY.                                           04680000
           IF BROWSE-ACTIVE                                             04690000
               PERFORM 280-END-BROWSE             THRU 280-EXIT         04700000
           END-IF.                                                      04710000
           IF EFT-IOM-STATUS-OK                                         04720000
               PERFORM 425-UPDATE-EDITS           THRU 425-EXIT         04730000
           END-IF.                                                      04740000
           IF EFT-IOM-STATUS-OK                                         04750000
               SET  EFT-IOS-WRITE       TO TRUE                         04760000
               MOVE EFT-BANK-INFO       TO EFT-IOS-RECORD-DATA          04770000
               PERFORM 990-IO-SUBROUTINE-CALL     THRU 990-EXIT         04780000
               IF EFT-IOM-STATUS-OK                                     04790000
                   MOVE EFT-BANK-INFO   TO EFT-IOM-RECORD-DATA          04800000
               END-IF                                                   04810000
           END-IF.                                                      04820000
       420-EXIT.    EXIT.                                               04830000
                                                                        04840000
      *---------------------------------------------------------------- 04850000
      * -REVIEW BROWSE DATA LOOKING FOR CHRONOLOGICAL POSITION          04860000
      * -EFF DATE OF NEW DATA MAY NOT PRECEED CURRENT VALID DATA        04870000
      *---------------------------------------------------------------- 04880000
       425-UPDATE-EDITS.                                                04890000
           PERFORM 210-REQUEST-START-BROWSE      THRU 210-EXIT.         04900000
           IF EFT-IOM-STATUS-OK                                         04910000
               SET NO-DESIRED-FOUND              TO TRUE                04920000
               PERFORM 320-READ-NEXT-RECORD      THRU 320-EXIT          04930000
                 WITH TEST AFTER                                        04940000
                 UNTIL NOT BNK-VOID                                     04950000
                    OR HIGH-DATE - BNK-IOM-EFF-DATE                     04960000
                              < BNK-EFF-DATE-COMPLEMENT                 04970000
                    OR HIGH-DATE - BNK-IOM-EFF-DATE                     04980000
                              = BNK-EFF-DATE-COMPLEMENT                 04990000
                    OR EFT-IOM-ERROR                                    05000000
               PERFORM 427-VERIFY-DATE           THRU 427-EXIT          05010000
           END-IF.                                                      05020000
           IF EFT-IOM-STATUS-OK                                         05030000
               PERFORM 270-SUSPEND-BROWSE        THRU 270-EXIT          05040000
           END-IF.                                                      05050000
           IF EFT-IOM-STATUS-OK                                         05060000
               EVALUATE TRUE                                            05070000
               WHEN HIGH-DATE - BNK-IOM-EFF-DATE                        05080000
                              = BNK-EFF-DATE-COMPLEMENT                 05090000
                  IF HIGH-DATE - BNK-IOM-MNT-DATE                       05100000
                               = BNK-MNT-DATE-COMPLEMENT                05110000
                  THEN                                                  05120000
                      MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO         05130000
                      SUBTRACT 1 FROM SV-MNT-SEQ                        05140000
                               GIVING BNK-MNT-SEQ-COMPLEMENT            05150000
                  ELSE                                                  05160000
                      MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO         05170000
                      MOVE     98  TO BNK-MNT-SEQ-COMPLEMENT            05180000
                  END-IF                                                05190000
               WHEN OTHER                                               05200000
                  IF HIGH-DATE - BNK-IOM-MNT-DATE                       05210000
                               = BNK-MNT-DATE-COMPLEMENT                05220000
                  THEN                                                  05230000
                      MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO         05240000
                      SUBTRACT 1 FROM SV-MNT-SEQ                        05250000
                               GIVING BNK-MNT-SEQ-COMPLEMENT            05260000
                  ELSE                                                  05270000
                      MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO         05280000
                      MOVE     98  TO BNK-MNT-SEQ-COMPLEMENT            05290000
                  END-IF                                                05300000
               END-EVALUATE                                             05310000
           END-IF.                                                      05320000
       425-EXIT.    EXIT.                                               05330000
                                                                        05340000
       427-VERIFY-DATE.                                                 05350000
           EVALUATE TRUE                                                05360000
           WHEN EFT-IOM-NOT-FOUND                                       05370000
               SET EFT-IOM-BAD-KEY   TO TRUE                            05380000
               MOVE 'PREVIOUS HISTORY NOT FOUND' TO EFT-IOM-ERROR-TEXT  05390000
           WHEN EFT-IOM-ERROR                                           05400000
               CONTINUE                                                 05410000
           WHEN HIGH-DATE - BNK-IOM-EFF-DATE                            05420000
                          > BNK-EFF-DATE-COMPLEMENT                     05430000
              SET EFT-IOM-BAD-KEY           TO TRUE                     05440000
              MOVE 'EFFECTIVE BEFORE LAST IN-FORCE RECORD'              05450000
                            TO EFT-IOM-ERROR-TEXT                       05460000
           WHEN OTHER                                                   05470000
               SET EFT-IOM-STATUS-OK TO TRUE                            05480000
           END-EVALUATE.                                                05490000
       427-EXIT.    EXIT.                                               05500000
                                                                        05510000
                                                                        05520000
      *---------------------------------------------------------------- 05530000
      *    THIS LOGIC PERFORMS THE FUNCTION OF CHANGING AN EXISTING     05540000
      * BANK INFORMATION RECORD, ONLY ALLOWED CHANGE IS A CHANGE TO THE 05550000
      * 'VOID' STATUS (RECORD IS LOGICALLY DELETED)                     05560000
      *---------------------------------------------------------------- 05570000
       450-REWRITE-BANK-RECORD.                                         05580000
           IF BROWSE-ACTIVE                                             05590000
               PERFORM 280-END-BROWSE         THRU 280-EXIT             05600000
           END-IF.                                                      05610000
           IF EFT-IOM-STATUS-OK                                         05620000
               PERFORM 455-REWRITE-EDITS      THRU 455-EXIT             05630000
           END-IF.                                                      05640000
           IF EFT-IOM-STATUS-OK                                         05650000
               SET  EFT-IOS-UPDATE      TO TRUE                         05660000
               MOVE EFT-IOM-RECORD-DATA TO EFT-IOS-RECORD-DATA          05670000
               PERFORM 990-IO-SUBROUTINE-CALL THRU 990-EXIT             05680000
           END-IF.                                                      05690000
       450-EXIT.    EXIT.                                               05700000
                                                                        05710000
       455-REWRITE-EDITS.                                               05720000
           MOVE EFT-IOM-RECORD-DATA TO EFT-BANK-INFO.                   05730000
BM002      PERFORM 210-REQUEST-START-BROWSE      THRU 210-EXIT.         05740000
BM002      IF EFT-IOM-STATUS-OK                                         05750000
BM002          PERFORM 300-READ-NEXT-VALID       THRU 300-EXIT          05760000
BM002      END-IF.                                                      05770000
BM002      IF EFT-IOM-STATUS-OK                                         05780000
BM002          PERFORM 270-SUSPEND-BROWSE        THRU 270-EXIT          05790000
BM002      END-IF.                                                      05800000
BM002      IF EFT-IOM-STATUS-OK      AND  NOT                           05810000
BM002          (      EFT-IOM-RECORD-TYPE  = BNK-RECORD-TYPE            05820000
BM002         AND EFT-IOM-KEY-TYPE         = BNK-KEY-TYPE               05830000
BM002         AND EFT-IOM-KEY-DATA         = BNK-KEY-DATA               05840000
BM002         AND BNK-IOM-EFF-DATE + BNK-EFF-DATE-COMPLEMENT = HIGH-DATE05850000
BM002         AND BNK-IOM-MNT-DATE + BNK-MNT-DATE-COMPLEMENT = HIGH-DATE05860000
BM002         AND BNK-IOM-MNT-SEQ  + BNK-MNT-SEQ-COMPLEMENT  = 99 )     05870000
BM002      THEN                                                         05880000
BM002          SET EFT-IOM-BAD-DATA          TO TRUE                    05890000
BM002          MOVE 'CAN ONLY "VOID" LAST RECORD'                       05900000
BM002                        TO EFT-IOM-ERROR-TEXT                      05910000
BM002      END-IF.                                                      05920000
       455-EXIT.    EXIT.                                               05930000
                                                                        05940000
                                                                        05950000
      *----------------------------------------------                   05960000
      *--------                           -----------                   05970000
      *---                                       ----                   05980000
      *-             UTILITY  SECTION               -                   05990000
      *---                                       ----                   06000000
      *--------                           -----------                   06010000
      *----------------------------------------------                   06020000
                                                                        06030000
                                                                        06040000
                                                                        06050000
      *------------------------------------------------------------     06060000
      * PREP FOR A START BROWSE                                         06070000
      * =======================                                         06080000
      * - MOVE FIELDS FROM THE LINKAGE PROTOCOL FIELDS TO THE           06090000
      *      CORRESPONDING FIELDS IN THE BANK INFO LAYOUT IN WS         06100000
      * - WHEN UPDATE CALL                                              06110000
      *      SET BANK INFO TO GET FIRST VALID RECORD                    06120000
      *        (ASSUMED AS THIS MUST BE THE ONE UPDATED)                06130000
      *   WHEN WRITE  CALL                                              06140000
      *      SET BANK INFO TO GET FIRST VALID RECORD                    06150000
      *        (ASSUMED AS THIS MUST BE THE PREVIOUS RECORD)            06160000
      *   ELSE                                                          06170000
      *      CALCULATE BANK INFO COMPLEMENTED FIELDS FROM IOM           06180000
      *------------------------------------------------------------     06190000
       900-MOVE-IOM-TO-BNK-KEY-FIELDS.                                  06200000
           MOVE LOW-VALUES              TO EFT-BANK-INFO.               06210000
           MOVE EFT-IOM-RECORD-TYPE     TO BNK-RECORD-TYPE.             06220000
           MOVE EFT-IOM-KEY-TYPE        TO BNK-KEY-TYPE.                06230000
           MOVE EFT-IOM-KEY-DATA        TO BNK-KEY-DATA.                06240000
      *--                                                               06250000
           EVALUATE TRUE                                                06260000
           WHEN EFT-IOM-UPDATE                                          06270000
           WHEN EFT-IOM-WRITE                                           06280000
           WHEN EFT-IOM-RE-WRITE                                        06290000
               MOVE ZERO            TO BNK-EFF-DATE-COMPLEMENT          06300000
               MOVE ZERO            TO BNK-MNT-DATE-COMPLEMENT          06310000
               MOVE ZERO            TO BNK-MNT-SEQ-COMPLEMENT           06320000
           WHEN OTHER                                                   06330000
               IF BNK-IOM-EFF-DATE > 0                                  06340000
                   SUBTRACT BNK-IOM-EFF-DATE FROM HIGH-DATE             06350000
                                    GIVING BNK-EFF-DATE-COMPLEMENT      06360000
               ELSE                                                     06370000
                   MOVE ZERO        TO BNK-EFF-DATE-COMPLEMENT          06380000
               END-IF                                                   06390000
      *--                                                               06400000
               IF BNK-IOM-MNT-DATE > 0                                  06410000
                   SUBTRACT BNK-IOM-MNT-DATE FROM HIGH-DATE             06420000
                                    GIVING BNK-MNT-DATE-COMPLEMENT      06430000
               ELSE                                                     06440000
                   MOVE ZERO        TO BNK-MNT-DATE-COMPLEMENT          06450000
               END-IF                                                   06460000
      *--                                                               06470000
               IF BNK-IOM-MNT-SEQ > 0                                   06480000
                   SUBTRACT BNK-IOM-MNT-SEQ FROM 99                     06490000
                                GIVING BNK-MNT-SEQ-COMPLEMENT           06500000
               ELSE                                                     06510000
                   MOVE ZERO        TO BNK-MNT-SEQ-COMPLEMENT           06520000
               END-IF                                                   06530000
           END-EVALUATE.                                                06540000
       900-EXIT.    EXIT.                                               06550000
                                                                        06560000
                                                                        06570000
      *------------------------------------------------------------     06580000
      *    DETERMINES IF THE RECORD JUST READ, QUALIFIES UNDER THE      06590000
      * MAJOR PART  OF THE KEY TO BE IN THE BROWSE                      06600000
      *------------------------------------------------------------     06610000
       910-DETERMINE-IF-DESIRED.                                        06620000
           MOVE EFT-IOS-RECORD-DATA TO EFT-BANK-INFO.                   06630000
           IF    BNK-RECORD-TYPE = EFT-IOM-RECORD-TYPE                  06640000
             AND BNK-KEY-TYPE    = EFT-IOM-KEY-TYPE                     06650000
             AND BNK-KEY-DATA    = EFT-IOM-KEY-DATA                     06660000
           THEN                                                         06670000
               EVALUATE  TRUE                                           06680000
               WHEN EFT-IOM-READ-KEYED                                  06690000
               WHEN EFT-IOM-READ-NEXT                                   06700000
               WHEN EFT-IOM-READ-NEXT-VALID                             06710000
               WHEN EFT-IOM-READ-PREV                                   06720000
               WHEN EFT-IOM-READ-PREV-VALID                             06730000
                  MOVE EFT-BANK-INFO TO EFT-IOM-RECORD-DATA             06740000
               WHEN OTHER                                               06750000
                  MOVE BNK-MNT-SEQ-COMPLEMENT TO SV-MNT-SEQ             06760000
               END-EVALUATE                                             06770000
               MOVE BNK-INFO-KEY  TO RESTART-BANK-INFO-KEY              06780000
           ELSE                                                         06790000
               SET EFT-IOM-NOT-FOUND TO TRUE                            06800000
           END-IF.                                                      06810000
       910-EXIT.    EXIT.                                               06820000
                                                                        06830000
                                                                        06840000
       990-IO-SUBROUTINE-CALL.                                          06850000
                                                                        06860000
CALL>>     COPY GWEFCBNC.                                               06870000
                                                                        06880000
           MOVE EFT-IOS-ERROR-DATA TO EFT-IOM-ERROR-DATA.               06890000
       990-EXIT.    EXIT.                                               06900000
                                                                        06910000
      *--------------------------------*                                06920000
      *  END OF     EFTCIBNK                                            06930000
      *--------------------------------*                                06940000
