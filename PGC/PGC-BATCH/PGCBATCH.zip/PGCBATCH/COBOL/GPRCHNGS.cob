       CBL DATA(24)                                                             
       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRCHNGS.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS.  THIS PROGRAM IS CALLED BY GPRINTAL TO PRINT A SPECIAL          
      *          LIST REPORT.                                                   
      ******************************************************************        
      *                       HISTORY                                  *        
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
      *                                                                *        
      *----------------------------------------------------------------*        
      *                 GIPSY  RELEASY 1  START                        *        
      *----------------------------------------------------------------*        
      *  M DRURY AUG/89  - REMOVE CERTIFICATE FROM REPORT              *        
      *                  - ADD PROD CODE AND BRANCH/GFO (OFFICE)       *        
      *  M BURTON NOV/89 - ADD EFFECTIVE DATE AND PRODUCT CODE TO      *        
      *                    TERMINATION AND REINSTATEMENT REPORTS (1,3) *        
      *----------------------------------------------------------------*        
      *                 GIPSY  RELEASY 1  END                          *        
      *----------------------------------------------------------------*        
      *  M PRANGE OCT/90 - FORM "8", ORDER "N" IS NOW USED TO HOLD     *        
      *                    CHANGES TO NEXT-RENEWAL DATE ON THE PSM     *        
      *                    INSTEAD OF GGINEXT-ANNIVERSARY DATE.        *        
      *----------------------------------------------------------------*        
      *  IBMECU   OCT/08 - ENTERPRISE COMPILER UPGRADE                 *        
      *                                                                *        
      *DATE-WRITTEN.  MODIFIED JUNE 6 1986.                                     
      *                        BY FERNAND GAGNE                                 
      *DATE-COMPILED.                                                           
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *          VARIABLES USED TO CONTROL REPORT PAGING               *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PAGE-SIZE                   PIC S9(4) COMP SYNC VALUE +0.            
       01  LINE-COUNT                  PIC S9(3) COMP-3    VALUE +0.            
       01  PAGE-COUNT                  PIC S9(5) COMP-3    VALUE +0.            
       01  RECORD-COUNT                PIC S9(5) COMP-3    VALUE +0.            
       01  PRINT-SYS016              PIC X(06) VALUE 'SYS016'.                  
       01  PRINT-SYS016-COUNT        PIC S9(7)  COMP-3  VALUE +0.               
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    QDATE  PARAMTERS                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  QDATE-PARM                  PIC X(2)            VALUE 'AC'.          
       01  CONVERTED-HIDATE            PIC X(7)            VALUE SPACES.        
      *----------------------------------------------------------------*        
      *                                                                *        
      *        VARIABLE PASSED TO GPRSGMNT TO SEGMENT OUTPUT           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  FORM-STANDARD               PIC X(2)            VALUE '91'.          
       01  SUB1                        PIC S9(4) COMP SYNC VALUE +0.            
       01  REPORT-COUNTRY-SW           PIC X(1)            VALUE '0'.           
       01  OLD-FORM                    PIC X(1)            VALUE SPACES.        
      *----------------------------------------------------------------*        
      *                                                                *        
      *                                                                *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TITLES1.                                                             
           03  FILLER                  PIC X(27)                                
               VALUE 'TERMINATION                '.                             
           03  FILLER                  PIC X(27)                                
               VALUE SPACES.                                                    
           03  FILLER                  PIC X(27)                                
               VALUE 'REINSTATEMENT              '.                             
           03  FILLER                  PIC X(27)                                
               VALUE SPACES.                                                    
           03  FILLER                  PIC X(27)                                
               VALUE SPACES.                                                    
           03  FILLER                  PIC X(27)                                
               VALUE SPACES.                                                    
           03  FILLER                  PIC X(27)                                
               VALUE 'REQUEST FOR LIST           '.                             
           03  SS-FILLER.                                                       
               05  FILLER              PIC X(21)                                
                   VALUE 'SPECIAL STATEMENTS:  '.                               
               05  SS-COUNTRY          PIC X(6)                                 
                   VALUE 'CANADA'.                                              
       01  TITLES2 REDEFINES TITLES1.                                           
           03  TITLES3 OCCURS 8 TIMES  PIC X(27).                               
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  PAGE HEADING LAYOUT                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  HEADER-LAYOUT.                                                       
           03  FILLER                  PIC X(9)    VALUE '1GPRCHNGS'.           
           03  FILLER                  PIC X(14)   VALUE SPACES.                
           03  HEADER-TITLE            PIC X(27)   VALUE SPACES.                
           03  FILLER                  PIC X(8)    VALUE SPACES.                
           03  HEADER-HIDATE           PIC X(7)    VALUE SPACES.                
           03  FILLER                  PIC X(5)    VALUE SPACES.                
           03  FILLER                  PIC X(5)    VALUE 'PAGE '.               
           03  HEADER-PAGE-NUMBER      PIC ZZZZ9   VALUE ZEROS.                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  PAGE COLUMN LAYOUT                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  COLUMN-LAYOUT.                                                       
           03  FILLER                  PIC X(1)    VALUE '0'.                   
           03  FILLER                  PIC X(6)    VALUE SPACES.                
           03  FILLER                  PIC X(5)    VALUE 'GROUP'.               
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  FILLER                  PIC X(4)    VALUE 'ACCT'.                
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  FILLER                  PIC X(11)   VALUE 'CERTIFICATE'.         
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  FILLER                  PIC X(7)    VALUE 'NAME   '.             
           03  FILLER                  PIC X(17)   VALUE SPACES.                
           03  FILLER                  PIC X(8)    VALUE 'EFF DATE'.            
           03  FILLER                  PIC X(2)    VALUE SPACES.                
           03  FILLER                  PIC X(7)    VALUE 'PRODUCT'.             
       01  COLUMN7-LAYOUT.                                                      
           03  FILLER                  PIC X(1)    VALUE '0'.                   
           03  FILLER                  PIC X(9)    VALUE SPACES.                
           03  FILLER                  PIC X(5)    VALUE 'GROUP'.               
           03  FILLER                  PIC X(5)    VALUE SPACES.                
           03  FILLER                  PIC X(4)    VALUE 'ACCT'.                
           03  FILLER                  PIC X(5)    VALUE SPACES.                
           03  FILLER                  PIC X(11)   VALUE 'CERTIFICATE'.         
           03  FILLER                  PIC X(5)    VALUE SPACES.                
           03  FILLER                  PIC X(7)    VALUE 'DEPT   '.             
           03  FILLER                  PIC X(23)   VALUE SPACES.                
                                                                                
       01  COLUMN8-LAYOUT.                                                      
           03  FILLER                  PIC X(1)    VALUE '0'.                   
           03  FILLER                  PIC X(1)    VALUE SPACES.                
           03  FILLER                  PIC X(7)    VALUE 'PRODUCT'.             
           03  FILLER                  PIC X(1)    VALUE SPACES.                
           03  FILLER                  PIC X(6)    VALUE 'OFFICE'.              
           03  FILLER                  PIC X(3)    VALUE SPACES.                
           03  FILLER                  PIC X(5)    VALUE 'GROUP'.               
           03  FILLER                  PIC X(5)    VALUE SPACES.                
           03  FILLER                  PIC X(4)    VALUE 'ACCT'.                
 GNE       03  FILLER                  PIC X(3)    VALUE SPACES.                
           03  FILLER                  PIC X(7)    VALUE 'EFF DTE'.             
           03  FILLER                  PIC X(2)    VALUE SPACES.                
           03  FILLER                  PIC X(8)    VALUE 'ACTIVITY'.            
 GNE       03  FILLER                  PIC X(26)   VALUE SPACES.                
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    PAGE LINE LAYOUT                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LINE-LAYOUT.                                                         
           03  FILLER                  PIC X(5)   VALUE SPACES.                 
GNE        03  LINE-GROUP              PIC Z(7)    VALUE ZEROS.                 
GNE        03  FILLER                  PIC X(3)    VALUE SPACES.                
           03  LINE-ACCT               PIC X(3)    VALUE SPACES.                
           03  FILLER                  PIC X(6)    VALUE SPACES.                
           03  LINE-CERT               PIC Z(9)    VALUE ZEROS.                 
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  LINE-NAME               PIC X(32)   VALUE SPACES.                
           03  FILLER                  PIC X(2)    VALUE SPACES.                
           03  LINE-EFFDATE            PIC X(7)    VALUE SPACES.                
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  LINE-PRODUCT            PIC X       VALUE SPACES.                
                                                                                
       01  LINE7-LAYOUT.                                                        
           03  FILLER                  PIC X(5)   VALUE SPACES.                 
GNE        03  LINE7-GROUP             PIC Z(7)    VALUE ZEROS.                 
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  LINE7-ACCT              PIC X(3)    VALUE SPACES.                
GNE        03  FILLER                  PIC X(3)    VALUE SPACES.                
           03  LINE7-CERT              PIC Z(9)    VALUE ZEROS.                 
           03  FILLER                  PIC X(3)    VALUE SPACES.                
           03  LINE7-NAME              PIC X(44)   VALUE SPACES.                
           03  FILLER                  PIC X(2)    VALUE SPACES.                
                                                                                
       01  LINE8-LAYOUT.                                                        
           03  FILLER                  PIC X(5)    VALUE SPACES.                
           03  LINE8-PROD              PIC X       VALUE SPACES.                
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  LINE8-OFFICE            PIC 9(6)    VALUE ZEROS.                 
           03  FILLER                  PIC X(3)    VALUE SPACES.                
GNE        03  LINE8-GROUP             PIC Z(7)    VALUE ZEROS.                 
           03  FILLER                  PIC X(4)    VALUE SPACES.                
           03  LINE8-ACCT              PIC X(3)    VALUE SPACES.                
GNE        03  FILLER                  PIC X(3)    VALUE SPACES.                
           03  LINE8-NAME.                                                      
               05  LINE8-EFFDATE       PIC X(7)    VALUE SPACES.                
               05  FILLER              PIC X(3)    VALUE SPACES.                
GNE            05  LINE8-ACCT-CHANGE   PIC X(26)   VALUE SPACES.                
               05  LINE8-RENEW-DATE    PIC X(7)    VALUE SPACES.                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    TOTAL LINE LAYOUT                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TOTAL-LINE.                                                          
           03  FILLER                  PIC X       VALUE '0'.                   
           03  FILLER                  PIC X(11)   VALUE SPACES.                
           03  FILLER                  PIC X(34)                                
                   VALUE 'TOTAL NUMBER OF RECORDS PRINTED   '.                  
           03  TOTAL-LINE-TOTAL        PIC Z(5)9   VALUE ZEROS.                 
           03  FILLER                  PIC X(29)   VALUE SPACES.                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                       OUTPUT BUFFER                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-LINE                  PIC X(80)  VALUE SPACES.                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *   AREA USED TO SAVE THE OUTPUT BUFFER DURING COUNTRY CHANGES   *        
      *   FOR SPECIAL STATEMENTS LISTING                               *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  SAVE-PRINT-LINE             PIC X(80)  VALUE SPACES.                 
                                                                                
       LINKAGE SECTION.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *    TYPE "N" REPORT PRINT RECORDS ARE PRINTED WITH DIFFERENT    *        
      *    FORM TYPES TO IDENTIFY THE FOLLOWING INFORMATION:           *        
      *                                                                *        
      *                 FORM           INFORMATION                     *        
      *                ------   --------------------------             *        
      *                                                                *        
      *                  1       TERMINATIONS                          *        
      *                  3       REINSTATMENTS                         *        
      *                  7       REQUEST FOR LISTS                     *        
      *                  8       SPECIAL STATEMENTS                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *                                                                         
      *                  FORMS CODE 1 TO 7                                      
      *                                                                         
GNE        COPY GFMCHRE7.                                                       
       01  FILLER                  PIC X(5393).                                 
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *      RESTART INFORMATION PASS TO THIS PROGRAM BY GPRINTAL      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  MISC-AREA.                                                           
           03  FILLER                  PIC X(4).                                
           03  MISC-HIDATE             PIC X(4).                                
           03  FILLER                  PIC X(24).                               
      *----------------------------------------------------------------*        
      *                                                                *        
      *                PRINT PARAMETER COPY BOOK                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY GPRPRINT.                                                           
      *----------------------------------------------------------------*        
      *                                                                *        
      *                TAPE PARAMETER COPY BOOK                        *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY GPRTPARM.                                                           
      *----------------------------------------------------------------*        
      *                                                                *        
      *               REPORT ACCUMULATOR COPY BOOK                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       COPY GPRACCUM.                                                           
                                                                                
       PROCEDURE DIVISION USING GI-CH-CHANGE-RECORD                             
                                MISC-AREA                                       
                                GPRPRINT                                        
                                GPRTPARM                                        
                                GPRACCUM.                                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *      IF THE FIRST RECORD HAS A FORM TYPE OF 2 OR 4, SKIP IT    *        
      *      AND READ THE NEXT RECORD. IF THIS RECORD IS NOT A TYPE    *        
      *      N RECORD OR IS THE END-OF-FILE, EXIT THE PROGRAMME.       *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  GI-CH-FORM IS EQUAL TO '1' OR                                    
               GI-CH-FORM IS EQUAL TO '2' OR                                    
               GI-CH-FORM IS EQUAL TO '3' OR                                    
               GI-CH-FORM IS EQUAL TO '4' OR                                    
               GI-CH-FORM IS EQUAL TO '5'                                       
               PERFORM READ-ROUTINE THRU READ-ROUTINE-EXIT                      
               IF  TAPE-RETURN IS NOT EQUAL TO ZEROS                            
               OR  GI-CH-RECORD-TYPE IS NOT EQUAL TO 'N' THEN                   
                   GO TO END-OF-JOB.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *      CHANGE THE HIGH RUN DATE ON THE DATE RECORD FROM AN       *        
      *      ALIS PACKED DATE TO A CHARACTER DATE (FORMAT DDMMMYY)     *        
      *                                                                *        
      *----------------------------------------------------------------*        
           CALL 'QDATE' USING QDATE-PARM                                        
                              MISC-HIDATE                                       
                              CONVERTED-HIDATE.                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *      THIS MODULE WILL RETURN THE MAXIMUM NUMBER OF LINES       *        
      *      THAT CAN BE PRINTED ON A 11 X 15 PAGE.                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
           CALL 'ZLINECT' USING PAGE-SIZE.                                      
           SUBTRACT +2 FROM PAGE-SIZE.                                          
      *----------------------------------------------------------------*        
      *                                                                *        
      *      WILL SEGMENT PRINTER OUTPUT WHEN MORE THAN ONE SPECIAL    *        
      *      FORMS REPORT IS BEING WRITTEN TO THE SAME LOGICAL UNIT    *        
      *      NUMBER.                                                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-STANDARD.                                 
                                                                                
           MOVE ZEROES TO PRINT-RETURN.                                         
                                                                                
       INITIALIZE-TAPE-FORM.                                                    
           MOVE ZEROS TO RECORD-COUNT.                                          
           MOVE +1    TO PAGE-COUNT.                                            
           PERFORM   NEWPAGE-ROUTINE THRU                                       
                     NEWPAGE-ROUTINE-EXIT.                                      
      *----------------------------------------------------------------*        
      *                                                                *        
      *     IF THE PAGE IS FULL GO TO THE NEXT PAGE ADD ONE TO THE     *        
      *     PAGE COUNT AND PRINT THE NECESSARY HEADING AND TITLES.     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NORMAL-PROCESSING.                                                       
           IF  LINE-COUNT IS GREATER THAN PAGE-SIZE THEN                        
               ADD +1 TO PAGE-COUNT                                             
               PERFORM  NEWPAGE-ROUTINE THRU                                    
                        NEWPAGE-ROUTINE-EXIT.                                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *     HANDLE THE LAYOUT DIFFERENCE BETWEEN SPECIAL STATEMENT     *        
      *     RECORDS AND THE OTHER CHANGE LIST RECORDS.                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
           ADD +1 TO RECORD-COUNT.                                              
           IF  GI-CH-FORM IS EQUAL TO '8' THEN                                  
               MOVE GI-M2D-GROUP TO LINE8-GROUP                                 
               MOVE GI-M2D-ACCOUNT TO LINE8-ACCT                                
               MOVE GI-M2D-SRT-PCODE      TO LINE8-PROD                         
               MOVE GI-M2D-SRT-BRANCH-GFO TO LINE8-OFFICE                       
           ELSE                                                                 
               IF GI-CH-FORM IS EQUAL TO '7' THEN                               
                  MOVE GI-CH-GROUP TO LINE7-GROUP                               
                  MOVE GI-CH-ACCOUNT TO LINE7-ACCT                              
               ELSE                                                             
                  MOVE GI-CH-GROUP TO LINE-GROUP                                
                  MOVE GI-CH-ACCOUNT TO LINE-ACCT                               
                  IF GI-CH-ORDER IS EQUAL TO 'A' THEN                           
                     MOVE GI-CH-CERT1    TO LINE-CERT                           
                     MOVE GI-CH-NAME1    TO LINE-NAME                           
                  ELSE                                                          
                     MOVE GI-CH-CERT2    TO LINE-CERT                           
                     MOVE GI-CH-NAME2    TO LINE-NAME.                          
                                                                                
           IF GI-CH-FORM IS EQUAL TO '1' OR '3' THEN                            
               MOVE GI-CH-SRT-PCODE      TO LINE-PRODUCT                        
               IF GI-CH-EFFYEAR NUMERIC AND                                     
                  GI-CH-EFFDAY  NUMERIC                                         
                  CALL 'QDATE' USING QDATE-PARM                                 
                                     GI-CH-EFFDATE                              
                                     LINE-EFFDATE                               
               ELSE                                                             
                  MOVE SPACES TO LINE-EFFDATE.                                  
      *----------------------------------------------------------------*        
      *                                                                *        
      *      THIS IS A REQUEST FOR LISTS SO TELL THE USER WHAT THE     *        
      *      ORDER CODE MEANS                                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  GI-CH-FORM IS EQUAL TO '7' THEN                                  
               IF  GI-CH-ORDER IS EQUAL TO 'A' THEN                             
                   MOVE 'AUDIT' TO LINE7-NAME                                   
               ELSE                                                             
                   MOVE 'RATE' TO LINE7-NAME.                                   
      *----------------------------------------------------------------*        
      *                                                                *        
      *     IF THIS IS A SPECIAL STATEMENTS RECORD CHECK TO SEE IF     *        
      *     THE COUNTRY HAS CHANGED IF SO CHANGE THE TITLE AND START   *        
      *     A NEW PAGE                                                 *        
      *                                                                *        
      *----------------------------------------------------------------*        
           IF  GI-CH-FORM IS EQUAL TO '8' THEN                                  
               IF  GI-M2D-COUNTRY IS NOT EQUAL REPORT-COUNTRY-SW THEN           
                   MOVE +1 TO PAGE-COUNT                                        
                   MOVE PRINT-LINE TO SAVE-PRINT-LINE                           
                   PERFORM NEWPAGE-ROUTINE THRU                                 
                           NEWPAGE-ROUTINE-EXIT                                 
                   MOVE SAVE-PRINT-LINE TO PRINT-LINE.                          
      *----------------------------------------------------------------*        
      *                                                                *        
      *     IF THIS IS A SPECIAL STATEMENT RECORD CHANGE THE DATE      *        
      *     ON THE RECORD TO CHARACTER FORMAT AND THIS DECIDE WHAT     *        
      *     TYPE OF RECORD IT IS BY THE USE OF THE ORDER CODE.         *        
      *                                                                *        
      *----------------------------------------------------------------*        
      *----------------------------------------------------------------*        
      *  M PRANGE OCT/90 - FORM "8", ORDER "N" IS NOW USED TO HOLD     *        
      *                    CHANGES TO NEXT-RENEWAL DATE ON THE PSM     *        
      *                    INSTEAD OF GGINEXT-ANNIVERSARY DATE.        *        
      *----------------------------------------------------------------*        
           IF  GI-CH-FORM = '8'                                                 
               MOVE SPACES          TO LINE8-NAME                               
               IF  GI-M2D-ORDER = 'N'                                           
                   CALL 'QDATE' USING QDATE-PARM                                
                                      GI-P5B-NEXT-RENEWAL-DATE                  
                                      LINE8-RENEW-DATE                          
               ELSE                                                             
                   CALL 'QDATE' USING QDATE-PARM                                
                                      GI-M2D-NEXT-ANNIVERSARY-DATE              
                                      LINE8-EFFDATE.                            
           IF  GI-CH-FORM = '8'                                                 
               IF  GI-M2D-ORDER = 'I'                                           
                   MOVE 'ISSUE'           TO LINE8-ACCT-CHANGE                  
               ELSE                                                             
               IF  GI-M2D-ORDER = 'R'                                           
                   MOVE 'REINSTATEMENT'   TO LINE8-ACCT-CHANGE                  
               ELSE                                                             
               IF  GI-M2D-ORDER = 'U'                                           
                   MOVE 'RE-TERMINATION'  TO LINE8-ACCT-CHANGE                  
               ELSE                                                             
               IF  GI-M2D-ORDER = 'J'                                           
                   MOVE 'RE-ISSUE'        TO LINE8-ACCT-CHANGE                  
               ELSE                                                             
               IF  GI-M2D-ORDER = 'V'                                           
                   MOVE 'REVISED BILLING' TO LINE8-ACCT-CHANGE                  
               ELSE                                                             
               IF  GI-M2D-ORDER = 'N'                                           
                   MOVE 'RENEWAL DATE HAS CHANGED TO'                           
                                          TO LINE8-ACCT-CHANGE                  
               ELSE                                                             
                   MOVE 'TERMINATION'     TO LINE8-ACCT-CHANGE.                 
                                                                                
           IF GI-CH-FORM IS EQUAL TO '8' THEN                                   
              MOVE LINE8-LAYOUT TO PRINT-LINE                                   
           ELSE                                                                 
              IF GI-CH-FORM IS EQUAL TO '7' THEN                                
                 MOVE LINE7-LAYOUT TO PRINT-LINE                                
              ELSE                                                              
                 MOVE LINE-LAYOUT  TO PRINT-LINE.                               
           PERFORM   PRINT-ROUTINE THRU                                         
                     PRINT-ROUTINE-EXIT.                                        
           ADD +1 TO LINE-COUNT.                                                
           MOVE SPACES TO LINE8-RENEW-DATE.                                     
           MOVE GI-CH-FORM TO OLD-FORM.                                         
           PERFORM  READ-ROUTINE THRU                                           
                    READ-ROUTINE-EXIT.                                          
           IF  TAPE-RETURN IS NOT EQUAL TO ZEROS                                
           OR  GI-CH-RECORD-TYPE IS NOT EQUAL TO 'N' THEN                       
               PERFORM PRINT-TOTAL-LINE THRU PRINT-TOTAL-EXIT                   
               GO TO END-OF-JOB.                                                
           IF  GI-CH-FORM IS NOT EQUAL TO OLD-FORM THEN                         
               PERFORM PRINT-TOTAL-LINE THRU PRINT-TOTAL-EXIT                   
               GO TO INITIALIZE-TAPE-FORM.                                      
           GO TO NORMAL-PROCESSING.                                             
       END-OF-JOB.                                                              
               EXIT PROGRAM.                                                    
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *   PRODUCE A LINE OF OUTPUT SHOWING THE NUMBER OF CERTS PRINTED *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-TOTAL-LINE.                                                        
           MOVE RECORD-COUNT TO TOTAL-LINE-TOTAL.                               
           MOVE TOTAL-LINE   TO PRINT-LINE.                                     
           PERFORM PRINT-ROUTINE THRU PRINT-ROUTINE-EXIT.                       
                                                                                
       PRINT-TOTAL-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *   SET UP THE CALL TO A GENERAL I/O ROUTINE TO READ A RECORD    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       READ-ROUTINE.                                                            
           CALL 'DLSREAD' USING TAPE-SYS014                                     
                                TAPE-RETURN                                     
                                GI-CH-CHANGE-RECORD                             
                                TAPE-SYS014-RECSIZE                             
                                TAPE-SYS014-BLKSIZE                             
                                TAPE-SYS014-FORMAT                              
                                TAPE-SYS014-COUNT.                              
           IF (GI-CH-FORM IS EQUAL TO '1' OR                                    
               GI-CH-FORM IS EQUAL TO '2' OR                                    
               GI-CH-FORM IS EQUAL TO '3' OR                                    
               GI-CH-FORM IS EQUAL TO '4' OR                                    
               GI-CH-FORM IS EQUAL TO '5') AND                                  
               GI-CH-RECORD-TYPE IS EQUAL TO 'N' AND                            
               TAPE-RETURN IS EQUAL TO 0                                        
               THEN                                                             
                    GO TO READ-ROUTINE.                                         
       READ-ROUTINE-EXIT.                                                       
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *   SET UP THE CALL TO A GENERAL I/O ROUTINE TO WRITE A RECORD   *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-ROUTINE.                                                           
           CALL 'DLSWRITE' USING PRINT-SYS016                                   
                                 PRINT-RETURN                                   
                                 PRINT-LINE                                     
                                 PRINT-RECSIZE                                  
                                 PRINT-BLKSIZE                                  
                                 PRINT-FORMAT                                   
                                 PRINT-SYS016-COUNT.                            
       PRINT-ROUTINE-EXIT.                                                      
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *            ROUTINE TO PRINT TITLES ON A NEW PAGE               *        
      *                                                                *        
      *----------------------------------------------------------------*        
       NEWPAGE-ROUTINE.                                                         
           ADD +1 TO ACCUM-DETCHNGS.                                            
           MOVE GI-CH-FORM TO SUB1.                                             
           IF  GI-CH-FORM IS EQUAL TO '8' THEN                                  
               MOVE GI-M2D-COUNTRY TO REPORT-COUNTRY-SW                         
               IF  GI-M2D-COUNTRY IS EQUAL TO '0' THEN                          
                   MOVE 'CANADA' TO SS-COUNTRY                                  
               ELSE                                                             
                   MOVE 'U.S.A.' TO SS-COUNTRY.                                 
           MOVE TITLES3 (SUB1) TO HEADER-TITLE.                                 
           MOVE CONVERTED-HIDATE TO HEADER-HIDATE.                              
           MOVE PAGE-COUNT TO HEADER-PAGE-NUMBER.                               
           MOVE HEADER-LAYOUT TO PRINT-LINE.                                    
           PERFORM  PRINT-ROUTINE THRU                                          
                    PRINT-ROUTINE-EXIT.                                         
           IF  GI-CH-FORM IS EQUAL TO '8' THEN                                  
              MOVE COLUMN8-LAYOUT TO PRINT-LINE                                 
           ELSE                                                                 
              IF GI-CH-FORM IS EQUAL TO '7' THEN                                
                 MOVE COLUMN7-LAYOUT TO PRINT-LINE                              
              ELSE                                                              
                 MOVE COLUMN-LAYOUT TO PRINT-LINE.                              
           PERFORM  PRINT-ROUTINE THRU                                          
                    PRINT-ROUTINE-EXIT.                                         
           MOVE SPACES TO PRINT-LINE.                                           
           PERFORM  PRINT-ROUTINE THRU                                          
                    PRINT-ROUTINE-EXIT.                                         
           MOVE +4 TO LINE-COUNT.                                               
       NEWPAGE-ROUTINE-EXIT.                                                    
           EXIT.                                                                
