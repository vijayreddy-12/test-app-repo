       IDENTIFICATION DIVISION.                                                 
GNE                                                                             
       PROGRAM-ID. GSPTRAN5.                                                    
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      ******************************************************************        
      * CHANGE HISTORY                                                          
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
      *  JUN/11 R.COOKE T154910 EXPAND AD&D RATE FIELDS               *         
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      ******************************************************************        
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       77  SUB-PSM             COMP SYNC           PIC S9(4).                   
       77  CLASS-SUB                               PIC S9(3) COMP.              
       77  ZFUNCT      VALUE 'AC'                  PIC XX.                      
       77  PR-SUB                                  PIC S9(3) COMP-3.            
       77  COV-SUB                                 PIC S9(3) COMP-3.            
       77  WK-RATE-100          COMP-3             PIC S9(4)V9(5).              
       77  WK-RATE-1000         COMP-3             PIC S9(5)V9(4).              
                                                                                
       01  PSM-LINE-HEADINGS.                                                   
           05  LPSM-HEAD1.                                                      
               10  FILLER                PIC X(7)  VALUE 'IDENT'.               
               10  FILLER                PIC X(4)  VALUE 'YR'.                  
               10  FILLER                PIC X(13) VALUE 'CUR YR PAID'.         
               10  FILLER                PIC X(13) VALUE 'LST YR PAID'.         
               10  FILLER                PIC X(13) VALUE 'CUR YR SERV'.         
               10  FILLER                PIC X(13) VALUE 'LST YR SERV'.         
               10  FILLER                PIC X(9)  VALUE 'LST CHG'.             
               10  FILLER                PIC X(8)  VALUE 'NXT RNEW'.            
           05  LPSM-HEAD2.                                                      
               10  FILLER                PIC X(7)  VALUE 'POINT'.               
               10  FILLER                PIC X(12) VALUE 'COMB IND'.            
               10  FILLER                PIC X(9)  VALUE SPACES.                
               10  FILLER                PIC X(14) VALUE '   LIFE'.             
               10  FILLER                PIC X(13) VALUE '   LTD '.             
               10  FILLER                PIC X(25) VALUE '   A&S '.             
       01  RATES-LINE-HEADINGS.                                                 
           05  LRATES-HEAD1.                                                    
               10  FILLER                PIC X(13) VALUE '  COVERAGE'.          
               10  FILLER                PIC X(8)  VALUE 'EFFECT'.              
               10  FILLER                PIC X(14) VALUE 'PROCESS'.             
               10  FILLER                PIC X(26) VALUE 'GROUP'.               
               10  FILLER                PIC X(8)  VALUE 'END'.                 
               10  FILLER                PIC X(7)  VALUE 'WAIVER'.              
               10  FILLER                PIC X(7)  VALUE 'UNDWR'.               
               10  FILLER                PIC X(5)  VALUE 'CHG'.                 
               10  FILLER                PIC X(3)  VALUE 'NUM'.                 
           05  LRATES-HEAD2.                                                    
               10  FILLER                PIC X(14) VALUE '    CODE'.            
               10  FILLER                PIC X(9)  VALUE 'DATE'.                
               10  FILLER                PIC X(11) VALUE 'DATE'.                
               10  FILLER                PIC X(27) VALUE 'CLASSES'.             
               10  FILLER                PIC X(9)  VALUE 'DATE'.                
               10  FILLER                PIC X(6)  VALUE 'IND'.                 
               10  FILLER                PIC X(6)  VALUE 'IDENT'.               
               10  FILLER                PIC X(6)  VALUE 'CODE'.                
               10  FILLER                PIC X(3)  VALUE 'COV'.                 
           05  LRATES-EHC-DENTAL-1.                                             
               10  FILLER                PIC X(16) VALUE SPACES.                
               10  FILLER                PIC X(9)  VALUE 'STD'.                 
               10  FILLER                PIC X(9)  VALUE 'STD'.                 
               10  FILLER                PIC X(9)  VALUE 'STD'.                 
               10  FILLER                PIC X(9)  VALUE 'ACT'.                 
               10  FILLER                PIC X(9)  VALUE 'ACT'.                 
               10  FILLER                PIC X(3)  VALUE 'ACT'.                 
           05  LRATES-EHC-DENTAL-2.                                             
               10  FILLER                PIC X(15) VALUE '  LINE CODE'.         
               10  FILLER                PIC X(10) VALUE 'SINGLE'.              
               10  FILLER                PIC X(9)  VALUE 'FAM1'.                
               10  FILLER                PIC X(8)  VALUE 'FAM2'.                
               10  FILLER                PIC X(10) VALUE 'SINGLE'.              
               10  FILLER                PIC X(9)  VALUE 'FAM1'.                
               10  FILLER                PIC X(4)  VALUE 'FAM2'.                
           05  LRATES-LIFE-1.                                                   
               10  FILLER                PIC X(45) VALUE SPACES.                
               10  FILLER                PIC X(6)  VALUE 'RATE'.                
               10  FILLER                PIC X(9)  VALUE 'AVGAGE'.              
               10  FILLER                PIC X(6)  VALUE '%'.                   
           05  LRATES-LIFE-2.                                                   
               10  FILLER                PIC X(14) VALUE '  LINE CODE'.         
               10  FILLER                PIC X(8)  VALUE 'FACTOR'.              
               10  FILLER                PIC X(14) VALUE 'STANDARD'.            
               10  FILLER                PIC X(10) VALUE 'ACTUAL'.              
               10  FILLER                PIC X(8)  VALUE 'TABLE'.               
               10  FILLER                PIC X(7)  VALUE 'IND'.                 
               10  FILLER                PIC X(9)  VALUE 'ADJ'.                 
           05  LRATES-AD-D-1.                                                   
               10  FILLER                PIC X(14) VALUE '  LINE CODE'.         
               10  FILLER                PIC X(5)  VALUE 'STD'.                 
               10  FILLER                PIC X(6)  VALUE 'ACTUAL'.              
           05  LRATES-WI-1.                                                     
               10  FILLER                PIC X(15) VALUE '  LINE CODE'.         
               10  FILLER                PIC X(7)  VALUE 'STD'.                 
               10  FILLER                PIC X(6)  VALUE 'ACTUAL'.              
           05  LRATES-LTD-1.                                                    
               10  FILLER                PIC X(16) VALUE '  LINE CODE'.         
               10  FILLER                PIC X(8)  VALUE 'STD'.                 
               10  FILLER                PIC X(6)  VALUE 'ACTUAL'.              
                                                                                
       01  PR-RATE-DATA-LINES.                                                  
           03  PR-DATA-COV-CODE               PIC 999.                          
           03  FILLER                         PIC X     VALUE '-'.              
           03  PR-DATA-COV-LIT                PIC X(8).                         
           03  FILLER                         PIC XX    VALUE SPACES.           
           03  PR-RATE-DATA-TYPES.                                              
               05  PR-RATE-DATA-LIFE.                                           
                   10  PR-DEP-FACTOR          PIC ZZZZ9.                        
                   10  FILLER                 PIC XX.                           
                   10  PR-LIFE-STD            PIC Z(4)9.9(5).                   
                   10  FILLER                 PIC XX.                           
                   10  PR-LIFE-ACT            PIC Z(4)9.9(5).                   
                   10  FILLER                 PIC XXX.                          
                   10  PR-RATE-TABLE          PIC XXX.                          
                   10  FILLER                 PIC X(5).                         
                   10  PR-AVGAGE-IND          PIC X.                            
                   10  FILLER                 PIC X(5).                         
                   10  PR-PERC-ADJ            PIC 9.99.                         
                   10  FILLER                 PIC XX.                           
               05  PR-RATE-DATA-DEN-EHC REDEFINES PR-RATE-DATA-LIFE.            
                   10  PR-DEN-EHC-STD-SIN     PIC ZZZ9.999.                     
                   10  FILLER                 PIC X.                            
                   10  PR-DEN-EHC-STD-FAM1    PIC ZZZ9.999.                     
                   10  FILLER                 PIC X.                            
                   10  PR-DEN-EHC-STD-FAM2    PIC ZZZ9.999.                     
                   10  FILLER                 PIC X.                            
                   10  PR-DEN-EHC-ACT-SIN     PIC ZZZ9.999.                     
                   10  FILLER                 PIC X.                            
                   10  PR-DEN-EHC-ACT-FAM1    PIC ZZZ9.999.                     
                   10  FILLER                 PIC X.                            
                   10  PR-DEN-EHC-ACT-FAM2    PIC ZZZ9.999.                     
                   10  FILLER                 PIC X.                            
               05  PR-RATE-DATA-AD-D REDEFINES PR-RATE-DATA-LIFE.               
                   10  PR-AD-D-STD            PIC Z9.999.                       
                   10  FILLER                 PIC XX.                           
                   10  PR-AD-D-ACT            PIC Z9.999.                       
               05  PR-RATE-DATA-WI REDEFINES PR-RATE-DATA-LIFE.                 
                   10  PR-WI-STD              PIC Z9.999.                       
                   10  FILLER                 PIC XX.                           
                   10  PR-WI-ACT              PIC Z9.999.                       
               05  PR-RATE-DATA-LTD REDEFINES PR-RATE-DATA-LIFE.                
                   10  PR-LTD-STD             PIC Z9.9(5).                      
                   10  FILLER                 PIC XX.                           
                   10  PR-LTD-ACT             PIC Z9.9(5).                      
                                                                                
       01  GNUMONIC-PARAMETERS.                                                 
           03  GNUM-TABLENUM   COMP  VALUE +22     PIC S9(4).                   
           03  GNUM-RETURN.                                                     
               05  GNUM-COV-LIT                    PIC X(8).                    
               05  FILLER                          PIC X(9).                    
                                                                                
       LINKAGE SECTION.                                                         
       77  LINE-COUNT  COMP                        PIC S9(4).                   
                                                                                
       01  PRINT-LINES.                                                         
           03  PR-LINES-PSM.                                                    
               05  PR-LINE1-PSM                    PIC X(91).                   
               05  PR-LINE2-PSM.                                                
                   10  PR-IDENT                    PIC X(5).                    
                   10  FILLER                      PIC XX.                      
                   10  PR-POL-YR                   PIC Z9.                      
                   10  FILLER                      PIC XX.                      
                   10  PR-CUR-YR-PD                PIC ZZZZ,ZZ9.99-.            
                   10  FILLER                      PIC X.                       
                   10  PR-LST-YR-PD                PIC ZZZZ,ZZ9.99-.            
                   10  FILLER                      PIC XXX.                     
                   10  PR-CUR-YR-SV                PIC ZZ,ZZ9.99-.              
                   10  FILLER                      PIC XXX.                     
                   10  PR-LST-YR-SV                PIC ZZ,ZZ9.99-.              
                   10  FILLER                      PIC X.                       
                   10  PR-LST-CHG-DT               PIC X(7).                    
                   10  FILLER                      PIC XX.                      
                   10  PR-NXT-RNEW-DT              PIC X(7).                    
                   10  FILLER                      PIC X(12).                   
               05  PR-LINE3-PSM                    PIC X(91).                   
               05  PR-SEGMENT-PSM.                                              
                   07  PR-SEG-PSM     OCCURS 5 TIMES.                           
                       10  PR-LINE4-PSM OCCURS 3 TIMES.                         
                           15  FILLER              PIC XX.                      
                           15  PR-POINT            PIC X.                       
                           15  FILLER              PIC X(7).                    
                           15  PR-COMB-IND         PIC X.                       
                           15  FILLER              PIC X(8).                    
                           15  PR-TYPE             PIC X(9).                    
                           15  PR-LIFE             PIC ZZZZ,ZZ9.99-.            
                           15  PR-LTD              PIC ZZZZZ,ZZ9.99-.           
                           15  PR-A-S              PIC ZZZZZ,ZZ9.99-.           
                           15  FILLER              PIC X(25).                   
           03  PR-LINES-RATES REDEFINES PR-LINES-PSM.                           
               05  PR-LINE1-RATES                  PIC X(91).                   
               05  PR-LINE2-RATES                  PIC X(91).                   
               05  PR-LINE3-RATES.                                              
                   10  PR-COV-CODE                 PIC 999.                     
                   10  PR-LINE3-DASH               PIC X.                       
                   10  PR-COV-LIT                  PIC X(8).                    
                   10  FILLER                      PIC X.                       
                   10  PR-EFFECTIVE-DATE           PIC X(7).                    
                   10  FILLER                      PIC X.                       
                   10  PR-PROCESSED-DATE           PIC X(7).                    
                   10  FILLER                      PIC X.                       
                   10  PR-CLASSES OCCURS 10 TIMES.                              
                       15  PR-CLASS                PIC XX.                      
                       15  FILLER                  PIC X.                       
                   10  PR-END-DATE                 PIC X(7).                    
                   10  FILLER                      PIC X(5).                    
                   10  PR-WAIVER                   PIC X.                       
                   10  FILLER                      PIC X(5).                    
                   10  PR-UW-IDENT                 PIC X(3).                    
                   10  FILLER                      PIC X(3).                    
                   10  PR-REASON                   PIC XX.                      
                   10  FILLER                      PIC X(3).                    
                   10  PR-NUM-COV-CODE             PIC ZZ9.                     
               05  PR-LINE4-RATES OCCURS 14 TIMES  PIC X(91).                   
                                                                                
       01  POINT-IN-SCALE-MASTER.                                               
GNE                               COPY  PSMASTE7  REPLACING                     
GNE                                ==01  PSMASTE7.== BY == ==.                  
                                                                                
       01  RATES-RECORD.                                                        
GNE                              COPY GRATES7  REPLACING                        
                                  ==01  GROUP-RATES-RECORD.== BY == ==.         
       PROCEDURE DIVISION.                                                      
                                                                                
           ENTRY 'GSPTTPSM' USING LINE-COUNT                                    
                                  PRINT-LINES                                   
                                  POINT-IN-SCALE-MASTER.                        
                                                                                
      **** BUILD PSM ROOT HEADING + PRINT LINE                 ****             
                                                                                
           MOVE +2 TO LINE-COUNT.                                               
           MOVE LPSM-HEAD1                 TO  PR-LINE1-PSM.                    
           MOVE SPACE                      TO  PR-LINE2-PSM.                    
           MOVE PSMIDENTITY                TO  PR-IDENT.                        
           MOVE PSMPOLICY-YEAR             TO  PR-POL-YR.                       
           MOVE PSMPAID-CUR-POL-YR         TO  PR-CUR-YR-PD.                    
           MOVE PSMPAID-LST-POL-YR         TO  PR-LST-YR-PD.                    
           MOVE PSMSERV-CUR-POL-YR         TO  PR-CUR-YR-SV.                    
           MOVE PSMSERV-LST-POL-YR         TO  PR-LST-YR-SV.                    
           CALL 'QDATE' USING  ZFUNCT                                           
                               PSMLAST-CHG-DATE                                 
                               PR-LST-CHG-DT.                                   
           IF  PR-LST-CHG-DT = '*******'                                        
               MOVE SPACE TO PR-LST-CHG-DT.                                     
           CALL 'QDATE' USING  ZFUNCT                                           
                               PSMNXT-RNEW-DATE                                 
                               PR-NXT-RNEW-DT.                                  
           IF  PR-NXT-RNEW-DT = '*******'                                       
               MOVE SPACE TO PR-NXT-RNEW-DT.                                    
                                                                                
      **** BUILD PSM SEGMENT INFORMATION LINES AND HEADINGS    ****             
                                                                                
           MOVE SPACES TO PR-SEGMENT-PSM.                                       
           MOVE +1 TO  SUB-PSM.                                                 
           IF  PSMPOINT (1) NOT = ' '                                           
               MOVE LPSM-HEAD2             TO  PR-LINE3-PSM                     
               ADD  +1                     TO  LINE-COUNT.                      
       POINT-IN-SCALE-SEG-LOOP.                                                 
           IF  PSMPOINT (SUB-PSM) NOT = ' '                                     
               MOVE PSMPOINT (SUB-PSM)     TO  PR-POINT (SUB-PSM, 1)            
               MOVE PSMCOMB-IND (SUB-PSM)  TO  PR-COMB-IND (SUB-PSM, 1)         
               MOVE '1ST YR-'              TO  PR-TYPE (SUB-PSM, 1)             
               MOVE 'CUR YR-'              TO  PR-TYPE (SUB-PSM, 2)             
               MOVE 'LST YR-'              TO  PR-TYPE (SUB-PSM, 3)             
               MOVE PSMPREM-FRST-YR-LIFE (SUB-PSM)                              
                                           TO  PR-LIFE (SUB-PSM, 1)             
               MOVE PSMPREM-FRST-YR-LTD  (SUB-PSM)                              
                                           TO  PR-LTD  (SUB-PSM, 1)             
               MOVE PSMPREM-FRST-YR-A-S  (SUB-PSM)                              
                                           TO  PR-A-S  (SUB-PSM, 1)             
               MOVE PSMRNEW-CUR-YR-LIFE (SUB-PSM)                               
                                           TO PR-LIFE (SUB-PSM, 2)              
               MOVE PSMRNEW-CUR-YR-LTD  (SUB-PSM)                               
                                           TO PR-LTD  (SUB-PSM, 2)              
               MOVE PSMRNEW-CUR-YR-A-S (SUB-PSM)                                
                                           TO  PR-A-S (SUB-PSM, 2)              
               MOVE PSMRNEW-LST-YR-LIFE (SUB-PSM)                               
                                           TO PR-LIFE (SUB-PSM, 3)              
               MOVE PSMRNEW-LST-YR-LTD  (SUB-PSM)                               
                                           TO PR-LTD  (SUB-PSM, 3)              
               MOVE PSMRNEW-LST-YR-A-S (SUB-PSM)                                
                                           TO  PR-A-S (SUB-PSM, 3)              
               ADD +3 TO LINE-COUNT                                             
               ADD +1 TO SUB-PSM                                                
               IF  SUB-PSM NOT GREATER THAN +5                                  
                   GO TO POINT-IN-SCALE-SEG-LOOP.                               
                                                                                
      **** GETBACK TO  CALLING MODULE                      ****                 
                                                                                
           GOBACK.                                                              
                                                                                
           ENTRY 'GSPTTRTE' USING LINE-COUNT                                    
                                  PRINT-LINES                                   
                                  RATES-RECORD.                                 
                                                                                
      **** BUILD RATES ROOT HEADING + PRINT LINE           ****                 
                                                                                
           MOVE +3 TO LINE-COUNT.                                               
           MOVE LRATES-HEAD1 TO PR-LINE1-RATES.                                 
           MOVE LRATES-HEAD2 TO PR-LINE2-RATES.                                 
           MOVE SPACES       TO PR-LINE3-RATES.                                 
           MOVE GRCOV-CODE TO PR-COV-CODE.                                      
           MOVE '-' TO PR-LINE3-DASH.                                           
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 PR-COV-CODE                                    
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO PR-COV-LIT.                                     
           CALL 'QDATE' USING  ZFUNCT                                           
                               GREFFECTIVE-DATE                                 
                               PR-EFFECTIVE-DATE.                               
           CALL 'QDATE' USING  ZFUNCT                                           
                               GRPROCESSED-DATE                                 
                               PR-PROCESSED-DATE.                               
           CALL 'QDATE' USING  ZFUNCT                                           
                               GREND-DATE                                       
                               PR-END-DATE.                                     
           MOVE GRWAIVER-OF-PREM TO PR-WAIVER.                                  
           MOVE GRUW-IDENT       TO PR-UW-IDENT.                                
           MOVE GRREASON         TO PR-REASON.                                  
           MOVE GRNUM-COV-CODE   TO PR-NUM-COV-CODE.                            
           MOVE +0 TO CLASS-SUB.                                                
       MOVE-CLASSES.                                                            
           ADD +1 TO CLASS-SUB.                                                 
           IF CLASS-SUB NOT GREATER THAN 10                                     
              MOVE GRCLASS (CLASS-SUB) TO PR-CLASS (CLASS-SUB)                  
              GO TO MOVE-CLASSES.                                               
           IF GRNUM-COV-CODE EQUAL +0                                           
              GO TO DONE-RATES-PROCESSING.                                      
                                                                                
      *****  DETERMINE HEADINGS AND PRINT DATA LINES REQUIRED    *****          
      *****  DEPENDING ON THE LINE OF BUSINESS                   *****          
                                                                                
           ADD +1 TO LINE-COUNT.                                                
           MOVE +2 TO PR-SUB.                                                   
           IF GRCOV-CODE EQUAL +10                                              
              MOVE LRATES-WI-1 TO PR-LINE4-RATES (1)                            
              GO TO PRINT-WI-DATA.                                              
           IF GRCOV-CODE EQUAL +19 OR +99                                       
              MOVE LRATES-EHC-DENTAL-1 TO PR-LINE4-RATES (1)                    
              MOVE LRATES-EHC-DENTAL-2 TO PR-LINE4-RATES (2)                    
              ADD +1 TO PR-SUB                                                  
              ADD +1 TO LINE-COUNT                                              
              GO TO PRINT-EHC-DEN-DATA.                                         
           IF GRCOV-CODE EQUAL +80                                              
              MOVE LRATES-AD-D-1 TO PR-LINE4-RATES (1)                          
              GO TO PRINT-AD-D-DATA.                                            
           IF GRCOV-CODE EQUAL +130                                             
              MOVE LRATES-LTD-1 TO PR-LINE4-RATES (1)                           
              GO TO PRINT-LTD-DATA.                                             
           IF GRCOV-CODE EQUAL +140                                             
              MOVE LRATES-LIFE-1 TO PR-LINE4-RATES (1).                         
              MOVE LRATES-LIFE-2 TO PR-LINE4-RATES (2)                          
              ADD +1 TO PR-SUB                                                  
              ADD +1 TO LINE-COUNT                                              
              GO TO PRINT-LIFE-DATA.                                            
                                                                                
       PRINT-EHC-DEN-DATA.                                                      
           MOVE +0 TO COV-SUB.                                                  
           IF GRCOV-CODE EQUAL +19                                              
              GO TO PRINT-EHC-LOOP.                                             
       PRINT-DEN-LOOP.                                                          
           MOVE SPACES TO PR-RATE-DATA-TYPES.                                   
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GRNUM-COV-CODE                               
              GO TO DONE-RATES-PROCESSING.                                      
           MOVE GRDEN-COV-CODE (COV-SUB) TO PR-DATA-COV-CODE.                   
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 PR-DATA-COV-CODE                               
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO PR-DATA-COV-LIT.                                
           MOVE GRDEN-STD-SIN (COV-SUB) TO PR-DEN-EHC-STD-SIN.                  
           MOVE GRDEN-STD-FAM1 (COV-SUB) TO PR-DEN-EHC-STD-FAM1.                
           MOVE GRDEN-STD-FAM2 (COV-SUB) TO PR-DEN-EHC-STD-FAM2.                
           MOVE GRDEN-ACTUAL-SIN (COV-SUB) TO PR-DEN-EHC-ACT-SIN.               
           MOVE GRDEN-ACTUAL-FAM1 (COV-SUB) TO PR-DEN-EHC-ACT-FAM1.             
           MOVE GRDEN-ACTUAL-FAM2 (COV-SUB) TO PR-DEN-EHC-ACT-FAM2.             
           MOVE PR-RATE-DATA-LINES TO PR-LINE4-RATES (PR-SUB).                  
           ADD +1 TO LINE-COUNT.                                                
           ADD +1 TO PR-SUB.                                                    
           GO TO PRINT-DEN-LOOP.                                                
       PRINT-EHC-LOOP.                                                          
           MOVE SPACES TO PR-RATE-DATA-TYPES.                                   
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GRNUM-COV-CODE                               
              GO TO DONE-RATES-PROCESSING.                                      
           MOVE GREHC-COV-CODE (COV-SUB) TO PR-DATA-COV-CODE.                   
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 PR-DATA-COV-CODE                               
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO PR-DATA-COV-LIT.                                
           MOVE GREHC-STD-SIN (COV-SUB) TO PR-DEN-EHC-STD-SIN.                  
           MOVE GREHC-STD-FAM1 (COV-SUB) TO PR-DEN-EHC-STD-FAM1.                
           MOVE GREHC-STD-FAM2 (COV-SUB) TO PR-DEN-EHC-STD-FAM2.                
           MOVE GREHC-ACTUAL-SIN (COV-SUB) TO PR-DEN-EHC-ACT-SIN.               
           MOVE GREHC-ACTUAL-FAM1 (COV-SUB) TO PR-DEN-EHC-ACT-FAM1.             
           MOVE GREHC-ACTUAL-FAM2 (COV-SUB) TO PR-DEN-EHC-ACT-FAM2.             
           MOVE PR-RATE-DATA-LINES TO PR-LINE4-RATES (PR-SUB).                  
           ADD +1 TO LINE-COUNT.                                                
           ADD +1 TO PR-SUB.                                                    
           GO TO PRINT-EHC-LOOP.                                                
                                                                                
       PRINT-WI-DATA.                                                           
           MOVE +0 TO COV-SUB.                                                  
       PRINT-WI-LOOP.                                                           
           MOVE SPACES TO PR-RATE-DATA-TYPES.                                   
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GRNUM-COV-CODE                               
              GO TO DONE-RATES-PROCESSING.                                      
           MOVE GRWI-COV-CODE (COV-SUB) TO PR-DATA-COV-CODE.                    
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 PR-DATA-COV-CODE                               
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO PR-DATA-COV-LIT.                                
           MOVE GRWI-STD (COV-SUB) TO PR-WI-STD.                                
           MOVE GRWI-ACTUAL (COV-SUB) TO PR-WI-ACT.                             
           MOVE PR-RATE-DATA-LINES TO PR-LINE4-RATES (PR-SUB).                  
           ADD +1 TO LINE-COUNT.                                                
           ADD +1 TO PR-SUB.                                                    
           GO TO PRINT-WI-LOOP.                                                 
                                                                                
       PRINT-AD-D-DATA.                                                         
           MOVE +0 TO COV-SUB.                                                  
       PRINT-AD-D-LOOP.                                                         
           MOVE SPACES TO PR-RATE-DATA-TYPES.                                   
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GRNUM-COV-CODE                               
              GO TO DONE-RATES-PROCESSING.                                      
           MOVE GRADD-COV-CODE (COV-SUB) TO PR-DATA-COV-CODE.                   
                                                                                
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 PR-DATA-COV-CODE                               
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO PR-DATA-COV-LIT.                                
           MOVE GRADD-STD (COV-SUB) TO PR-AD-D-STD.                             
           MOVE GRADD-ACTUAL (COV-SUB) TO PR-AD-D-ACT.                          
           MOVE PR-RATE-DATA-LINES TO PR-LINE4-RATES (PR-SUB).                  
           ADD +1 TO LINE-COUNT.                                                
           ADD +1 TO PR-SUB.                                                    
           GO TO PRINT-AD-D-LOOP.                                               
                                                                                
       PRINT-LTD-DATA.                                                          
      ******************************************************************        
      *    ADJUST THE DECIMAL POINT IN STANDARD AND ACTUAL FIELDS FOR           
      *    PRINTING (MULTIPLY BY 100).                                          
      ******************************************************************        
           MOVE +0 TO COV-SUB.                                                  
       PRINT-LTD-LOOP.                                                          
           MOVE SPACES TO PR-RATE-DATA-TYPES.                                   
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GRNUM-COV-CODE                               
              GO TO DONE-RATES-PROCESSING.                                      
           MOVE GRLTD-COV-CODE (COV-SUB) TO PR-DATA-COV-CODE.                   
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 PR-DATA-COV-CODE                               
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO PR-DATA-COV-LIT.                                
           MULTIPLY GRLTD-STD (COV-SUB) BY 100 GIVING WK-RATE-100.              
           MOVE WK-RATE-100 TO PR-LTD-STD.                                      
           MULTIPLY GRLTD-ACTUAL (COV-SUB) BY 100 GIVING WK-RATE-100.           
           MOVE WK-RATE-100 TO PR-LTD-ACT.                                      
           MOVE PR-RATE-DATA-LINES TO PR-LINE4-RATES (PR-SUB).                  
           ADD +1 TO LINE-COUNT.                                                
           ADD +1 TO PR-SUB.                                                    
           GO TO PRINT-LTD-LOOP.                                                
                                                                                
       PRINT-LIFE-DATA.                                                         
      ******************************************************************        
      *    ADJUST THE DECIMAL POINT IN STANDARD AND ACTUAL FIELDS FOR           
      *    PRINTING (MULTIPLY BY 1000 UNLESS IT IS SURVIVOR INCOME              
      *    COVERAGE (300) THEN MULTIPY BY 100)                                  
      ******************************************************************        
           MOVE +0 TO COV-SUB.                                                  
       PRINT-LIFE-LOOP.                                                         
           MOVE SPACES TO PR-RATE-DATA-TYPES.                                   
           ADD +1 TO COV-SUB.                                                   
           IF COV-SUB GREATER THAN GRNUM-COV-CODE                               
              GO TO DONE-RATES-PROCESSING.                                      
           MOVE GRLI-COV-CODE (COV-SUB) TO PR-DATA-COV-CODE.                    
           CALL 'GNUMTABL' USING GNUM-TABLENUM                                  
                                 PR-DATA-COV-CODE                               
                                 GNUM-RETURN.                                   
           MOVE GNUM-COV-LIT TO PR-DATA-COV-LIT.                                
           IF GRLI-COV-CODE (COV-SUB) EQUAL +160                                
              MOVE GRLI-DL-FACTOR (COV-SUB) TO PR-DEP-FACTOR                    
              MOVE GRLI-DL-STD (COV-SUB) TO PR-LIFE-STD                         
              MOVE GRLI-DL-ACTUAL (COV-SUB) TO PR-LIFE-ACT                      
              GO TO MOVE-LIFE-LINE.                                             
           IF GRLI-AVG-STD (COV-SUB) NUMERIC                                    
              IF GRLI-COV-CODE (COV-SUB) EQUAL 161                              
                 MOVE GRLI-AVG-STD (COV-SUB) TO PR-LIFE-STD                     
                 MOVE GRLI-AVG-ACTUAL (COV-SUB) TO PR-LIFE-ACT                  
              ELSE                                                              
                 IF (GRLI-COV-CODE (COV-SUB) NOT LESS THAN +300) AND            
                    (GRLI-COV-CODE (COV-SUB) NOT GREATER THAN +399)             
                     MULTIPLY GRLI-AVG-STD (COV-SUB) BY 100 GIVING              
                                                     WK-RATE-100                
                     MOVE WK-RATE-100 TO PR-LIFE-STD                            
                     MULTIPLY GRLI-AVG-ACTUAL (COV-SUB) BY 100 GIVING           
                                                     WK-RATE-100                
                     MOVE WK-RATE-100 TO PR-LIFE-ACT                            
                  ELSE                                                          
                     MULTIPLY GRLI-AVG-STD (COV-SUB) BY 1000 GIVING             
                                                     WK-RATE-1000               
                     MOVE WK-RATE-1000 TO PR-LIFE-STD                           
                     MULTIPLY GRLI-AVG-ACTUAL (COV-SUB) BY 1000 GIVING          
                                                     WK-RATE-1000               
                     MOVE WK-RATE-1000 TO PR-LIFE-ACT                           
           ELSE                                                                 
              MOVE GRLI-RATE-TABLE (COV-SUB) TO PR-RATE-TABLE                   
              MOVE GRLI-AVG-AGE-IND (COV-SUB) TO PR-AVGAGE-IND                  
              MOVE GRLI-PERC-ADJ (COV-SUB) TO PR-PERC-ADJ.                      
                                                                                
       MOVE-LIFE-LINE.                                                          
           MOVE PR-RATE-DATA-LINES TO PR-LINE4-RATES (PR-SUB).                  
           ADD +1 TO LINE-COUNT.                                                
           ADD +1 TO PR-SUB.                                                    
           GO TO PRINT-LIFE-LOOP.                                               
                                                                                
       DONE-RATES-PROCESSING.                                                   
           GOBACK.                                                              
                                                                                
MAN07 *9999-DUMP-ROUTINE.                                                       
MAN07 ******************************************************************        
MAN07 *    SERIOUS ERROR OCCURRED.                                              
MAN07 *    DISPLAY SOME CONSOLE MESSAGES, TAKE A DUMP THEN ABEND.               
MAN07 *    COPYBOOK GWRDUMP IS REQUIRED                                         
MAN07 ******************************************************************        
MAN07 *                                                                         
MAN07 *    MOVE WS-PROGRAM-ID TO GWRDUMP-PROGRAM-NAME.                          
MAN07 *    CALL GWCDUMP    USING ICBM                                           
MAN07 *                          GWRDUMP.                                       
MAN07 *                                                                         
MAN07 *9999-EXIT.                                                               
MAN07 *    EXIT.                                                                
