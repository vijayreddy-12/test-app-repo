       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID. GC2PBP.                                                      
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                            HISTORY                            *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *  PRINT EXTRACT CREATED IN GWCOCRC5                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      * 09OCT90 ANITA NIKELSKI - CREATED                              *         
      * 30APR91 IAN BUCKNELL   - FIXED SPELLING IN REPORT TITLE       *         
      * 07OCT08  IBMECU        - ENTERPRISE COMPILER UPGRADE          *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                                         
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCPBP          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
      /                                                                         
       WORKING-STORAGE SECTION.                                                 
       01  WS-BEGINS                          PIC  X(32)  VALUE                 
FXXTOK         '** GC2PBP W-S STARTS HERE **'.                                  
      *                                                                         
      *----------------------------------------------------------------*        
      *                       OUTPUT BUFFER                            *        
      *----------------------------------------------------------------*        
       01  DLSWRITE-PARAMETERS.                                                 
           05  DLSW-SYS020            PIC X(6)  VALUE 'SYS020'.                 
           05  DLSW-RET-CODE          PIC S9    COMP-3.                         
           05  DLSW-REC-SIZE          PIC 9(5)  VALUE 80.                       
           05  DLSW-BLK-SIZE          PIC 9(5)  VALUE 23440.                    
           05  DLSW-REC-FMT           PIC XX    VALUE 'FB'.                     
           05  DLSW-REC-CNT           PIC S9(7) COMP-3 VALUE +0.                
                                                                                
       01  DLSREAD-PARAMETERS.                                                  
           05  DLSR-SYS010            PIC X(6)  VALUE 'SYS010'.                 
           05  DLSR-RET-CODE          PIC S9    COMP-3.                         
           05  DLSR-REC-SIZE          PIC 9(5)  VALUE 50.                       
           05  DLSR-BLK-SIZE          PIC 9(5)  VALUE 23450.                    
           05  DLSR-REC-FMT           PIC XX    VALUE 'FB'.                     
           05  DLSR-REC-CNT           PIC S9(7) COMP-3 VALUE +0.                
      *                                                                         
       01  EXTRACT-RECORD.                                                      
REN        05  GROUP-NUMBER           PIC X(7).                                 
           05  GROUP-ACCOUNT          PIC X(3).                                 
           05  GROUP-AGENT            PIC 9(6).                                 
           05  GROUP-PBI              PIC X(25).                                
           05  GROUP-PAYMENT          PIC X(11).                                
      *                                                                         
       01  PRINT-LINE                  PIC X(80)  VALUE SPACES.                 
       01  REPORT-LAYOUT.                                                       
      *                                                                         
           05  HEADING-01.                                                      
               10  FILLER                            PIC X VALUE '1'.           
               10  FILLER                            PIC X(42)                  
FXXTOK             VALUE 'GC2PBP          INCONSISTENT AGENT PAYBASI'.          
               10  FILLER                            PIC X(25)                  
                   VALUE 'S REPORT        RUNDATE: '.                           
               10  H1-RUNDATE                        PIC X(07).                 
REN            10  FILLER                            PIC X(5)                   
                   VALUE SPACES.                                                
      *                                                                         
           05  HEADING-02.                                                      
               10  FILLER                            PIC X VALUE ' '.           
REN            10  FILLER                            PIC X(42)                  
REN                VALUE '                                          '.          
               10  FILLER                            PIC X(25)                  
                   VALUE '                   PAGE: '.                           
               10  H2-PAGE                           PIC ZZ9.                   
REN            10  FILLER                            PIC X(9)                   
                   VALUE SPACES.                                                
      *                                                                         
           05  HEADING-03.                                                      
               10  FILLER                            PIC X VALUE '0'.           
REN            10  FILLER       VALUE SPACES         PIC X(2).                  
               10  FILLER                            PIC X(40)                  
                   VALUE '                             PAYBASIS   '.            
               10  FILLER                            PIC X(26)                  
                   VALUE '                   PAYMENT'.                          
REN            10  FILLER                            PIC X(11)                  
                   VALUE SPACES.                                                
      *                                                                         
           05  HEADING-04.                                                      
               10  FILLER                            PIC X VALUE ' '.           
REN            10  FILLER       VALUE SPACES         PIC X(2).                  
               10  FILLER                            PIC X(40)                  
                   VALUE 'GROUP    ACCT    AGENT #     INDICATOR  '.            
               10  FILLER                            PIC X(25)                  
                   VALUE '                   METHOD'.                           
REN            10  FILLER                            PIC X(12)                  
                   VALUE SPACES.                                                
      *                                                                         
           05  DETAIL-01.                                                       
               10  FILLER                            PIC X VALUE ' '.           
REN            10  D1-GROUP                          PIC 9(07).                 
               10  FILLER                            PIC X(4)                   
                   VALUE '    '.                                                
               10  D1-ACCOUNT                        PIC X(03).                 
               10  FILLER                            PIC X(5)                   
                   VALUE '     '.                                               
               10  D1-AGENT                          PIC ZZZZZ9.                
               10  FILLER                            PIC X(6)                   
                   VALUE '      '.                                              
               10  D1-PAYBASIS-IND                   PIC X(25).                 
               10  FILLER                            PIC X(5)                   
                   VALUE '     '.                                               
               10  D1-PAYMENT                        PIC X(11).                 
REN            10  FILLER                            PIC X(7)                   
                   VALUE SPACES.                                                
      *                                                                         
           05  EOF-HEADING.                                                     
               10  FILLER                            PIC X VALUE '-'.           
               10  FILLER                            PIC X(50)                  
                    VALUE '        *** END OF REPORT ***'.                      
               10  FILLER                            PIC X(29)                  
                   VALUE SPACES.                                                
      *                                                                         
           05  EMPTY-HEADING.                                                   
               10  FILLER                            PIC X VALUE '-'.           
               10  FILLER                            PIC X(50)                  
                    VALUE '      *** NOTHING TO REPORT ***'.                    
               10  FILLER                            PIC X(29)                  
                   VALUE SPACES.                                                
      *                                                                         
      *                                                                         
       01  WS-PARAMETERS.                                                       
           05  END-PROCESS                VALUE 'N'       PIC X.                
               88  END-PROCESS-88         VALUE 'Y'.                            
           05  WS-PAGE      VALUE +0      COMP-3          PIC S9(3).            
           05  WS-LINE      VALUE +0      COMP-3          PIC S9(3).            
           05  QDATE-BC     VALUE 'BC'                    PIC XX.               
           05  RUN-DATE     VALUE LOW-VALUES.                                   
               10  RUN-DAY                                PIC 9(2).             
               10  FILLER                                 PIC X(1).             
               10  RUN-MONTH                              PIC 9(2).             
               10  FILLER                                 PIC X(1).             
               10  RUN-YEAR                               PIC 9(2).             
       01  WS-ENDS                            PIC  X(32)  VALUE                 
FXXTOK                                '** GC2PBP W-S ENDS HERE **'.             
      /                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
MAN02      05  ZCURRDAT                     PIC X(8)  VALUE 'ZCURRDAT'.         
                                                                                
       PROCEDURE DIVISION.                                                      
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                                         
       000-MAINLINE.                                                            
           PERFORM A100-INITIALIZE        THRU A100-EXIT.                       
           PERFORM A200-MAINLINE          THRU A200-EXIT                        
                                          UNTIL END-PROCESS-88.                 
           PERFORM A300-WRAPUP            THRU A300-EXIT.                       
           STOP RUN.                                                            
      *                                                                         
       A100-INITIALIZE.                                                         
      *                                                                         
           MOVE +65           TO WS-LINE.                                       
           MOVE +0            TO WS-PAGE.                                       
      *                                                                         
      *    DISPLAY '***** GWCOCPBP DISPLAYS BEGIN: *****'                       
      *                                                                         
           CALL   ZCURRDAT   USING  RUN-DATE.                                   
MAN02      CALL  QDATEQ2     USING  QDATE-BC                                    
MAN02                               RUN-DATE                                    
MAN02                               H1-RUNDATE.                                 
      *                                                                         
           PERFORM R100-READ-EXTRACT THRU R100-EXIT.                            
           IF DLSR-RET-CODE NOT = +0                                            
              MOVE 'Y'               TO END-PROCESS                             
           ELSE                                                                 
              MOVE 'N'               TO END-PROCESS.                            
      *                                                                         
      *                                                                         
       A100-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       A200-MAINLINE.                                                           
           PERFORM M100-MOVE-TO-DETAIL    THRU M100-EXIT                        
           PERFORM P200-PRINT-DETAIL      THRU P200-EXIT.                       
           PERFORM R100-READ-EXTRACT THRU R100-EXIT.                            
           IF DLSR-RET-CODE NOT = +0                                            
              MOVE 'Y'               TO END-PROCESS                             
           ELSE                                                                 
              MOVE 'N'               TO END-PROCESS.                            
      *                                                                         
       A200-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       A300-WRAPUP.                                                             
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    PRINT REPORT CLOSING COMMENTS                              *         
      *    CLOSE PRINT FILE                                           *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           PERFORM P300-PRINT-EOF    THRU P300-EXIT.                            
           MOVE +4                   TO DLSW-RET-CODE.                          
           PERFORM W100-WRITE-SYS020 THRU W100-EXIT.                            
      *    DISPLAY '***** GWCOCPBP DISPLAYS ENDS: *****'.                       
      *                                                                         
       A300-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       M100-MOVE-TO-DETAIL.                                                     
           MOVE GROUP-NUMBER                TO D1-GROUP.                        
           MOVE GROUP-ACCOUNT               TO D1-ACCOUNT.                      
           MOVE GROUP-AGENT                 TO D1-AGENT.                        
           MOVE GROUP-PBI                   TO D1-PAYBASIS-IND.                 
           MOVE GROUP-PAYMENT               TO D1-PAYMENT.                      
      *                                                                         
       M100-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       P100-PRINT-HEADINGS.                                                     
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    INCREMENT PAGE COUNT                                       *         
      *    PRINT HEADINGS                                             *         
      *    RESET LINE COUNT                                           *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           ADD +1                    TO WS-PAGE.                                
           MOVE WS-PAGE              TO H2-PAGE.                                
           MOVE HEADING-01           TO PRINT-LINE.                             
           PERFORM W100-WRITE-SYS020 THRU W100-EXIT.                            
           MOVE HEADING-02           TO PRINT-LINE.                             
           PERFORM W100-WRITE-SYS020 THRU W100-EXIT.                            
           MOVE HEADING-03           TO PRINT-LINE.                             
           PERFORM W100-WRITE-SYS020 THRU W100-EXIT.                            
           MOVE HEADING-04           TO PRINT-LINE.                             
           PERFORM W100-WRITE-SYS020 THRU W100-EXIT.                            
           MOVE +5                   TO WS-LINE.                                
      *                                                                         
       P100-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       P200-PRINT-DETAIL.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    IF THE PAGE IS FULL PRINT HEADINGS                         *         
      *    PRINT DETAIL                                               *         
      *    INCREMENT LINE COUNT                                       *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           IF WS-LINE > 60                                                      
              PERFORM P100-PRINT-HEADINGS THRU P100-EXIT.                       
      *                                                                         
           MOVE DETAIL-01                 TO PRINT-LINE.                        
           PERFORM W100-WRITE-SYS020      THRU W100-EXIT.                       
           ADD +1                         TO WS-LINE.                           
      *                                                                         
       P200-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       P300-PRINT-EOF.                                                          
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    IF NOTHING HAS BEEN PRINTED - PRINT-HEADINGS               *         
      *       PRINT 'NOTHING TO REPORT'                               *         
      *    ELSE                                                       *         
      *       PRINT 'END OF REPORT'                                   *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           IF WS-LINE = 65                                                      
              PERFORM P100-PRINT-HEADINGS THRU P100-EXIT                        
              MOVE EMPTY-HEADING          TO PRINT-LINE                         
              PERFORM W100-WRITE-SYS020   THRU W100-EXIT                        
           ELSE                                                                 
              MOVE EOF-HEADING            TO PRINT-LINE                         
              PERFORM W100-WRITE-SYS020   THRU W100-EXIT.                       
      *                                                                         
       P300-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       R100-READ-EXTRACT.                                                       
           CALL 'DLSREAD' USING DLSR-SYS010                                     
                                DLSR-RET-CODE                                   
                                EXTRACT-RECORD                                  
                                DLSR-REC-SIZE                                   
                                DLSR-BLK-SIZE                                   
                                DLSR-REC-FMT                                    
                                DLSR-REC-CNT.                                   
      *                                                                         
       R100-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
       W100-WRITE-SYS020.                                                       
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *    PRINT REPORT TO OUTPUT QUEUE                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
           CALL 'DLSWRITE' USING DLSW-SYS020                                    
                                 DLSW-RET-CODE                                  
                                 PRINT-LINE                                     
                                 DLSW-REC-SIZE                                  
                                 DLSW-BLK-SIZE                                  
                                 DLSW-REC-FMT                                   
                                 DLSW-REC-CNT.                                  
      *                                                                         
       W100-EXIT.                                                               
           EXIT.                                                                
      *                                                                         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
      *                                                               *         
      *                      END OF SOURCE                            *         
      *                                                               *         
      * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *         
