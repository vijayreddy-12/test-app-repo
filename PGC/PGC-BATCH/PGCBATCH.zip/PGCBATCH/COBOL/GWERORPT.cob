       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.  GWERORPT.                                                   
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *REMARKS.  THIS WAS  ====>   GPRERROR FROM PRINTAL   <======              
      *                                                                         
      *          THIS MODULE READS BACK IN THE ERROR FILE AND PRINTS            
      *          AN OUTPUT ERROR REPORT WHICH CONTAINS ERRORS WHICH             
      *          OCCURRED WHILE PRINTING GPRINTAL REPORTS.                      
      *DATE-WRITTEN.  MODIFIED MAY 1984.                                        
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *                       HISTORY                                  *        
      ******************************************************************        
      *                                                                *        
      *----------------------------------------------------------------*        
      *                 GIPSY  RELEASY 1  START                        *        
      *----------------------------------------------------------------*        
      *  M DRURY AUG/89  - ADD PROD CODE AND BRANCH/GFO (OFFICE)       *        
      *----------------------------------------------------------------*        
      *                 GIPSY  RELEASY 1  END                          *        
      *----------------------------------------------------------------*        
      *  M BURTON SEP/91 - CHECK TO SEE IF GROUP AND CERT FIELDS       *        
      *                    ARE NUMERIC BEFORE MOVING TO OUTPUT         *        
      *----------------------------------------------------------------*        
      *  IBM      OCT/08 - ENTERPRISE COMPILER UPGRADE                 *        
      *----------------------------------------------------------------*        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GERRORPT          
MAN07 * MAY2013 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
                                                                                
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *                MISCELLANOUS VARIABLES                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
       77   FILLER                           PIC X(50)   VALUE                  
FXXTOK      '***** START OF WORKING STORAGE FOR GWERORPT *****'.                
       77  PAGE-SIZE                   PIC S9(4) COMP   SYNC VALUE +0.          
       77  LINE-COUNT                  PIC S9(4) COMP   SYNC VALUE +99.         
       77  PAGE-NUMBER                 PIC S9(5) COMP-3      VALUE +0.          
       77  FORM-STANDARD               PIC X(2)              VALUE '91'.        
       77  PREV-REC                    PIC X(1)        VALUE LOW-VALUES.        
                                                                                
      *----------------------------------------------------------------*        
      *         DISK PARAMETERS FOR ERROR RECORDS INPUT FILE           *        
      *----------------------------------------------------------------*        
           COPY GPRTPARM.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *         DISK PARAMETERS FOR ERROR RECORDS OUTPUT FILE          *        
      *----------------------------------------------------------------*        
           COPY GPRPRINT.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                   ERROR RECORD LAYOUT                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
GNE        COPY GERRREC7.                                                       
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                OUTPUT ERROR REPORT TITLES                      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-TITLES.                                                       
           03  TITL-1.                                                          
FXXTOK         05  FILLER              PIC X(8)   VALUE 'GWERORPT'.             
               05  FILLER              PIC X(13)  VALUE SPACES.                 
               05  FILLER              PIC X(35)                                
                   VALUE 'O U T P U T  E R R O R  R E P O R T'.                 
               05  FILLER              PIC X(13)  VALUE SPACES.                 
               05  FILLER              PIC X(5)   VALUE 'PAGE '.                
               05  TITL-PAGE-NUMBER    PIC ZZZZ9  VALUE ZEROS.                  
           03  GROUP-ACCT-TITLE.                                                
               05  FILLER              PIC X(7)   VALUE 'PRODUCT'.              
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(6)   VALUE 'OFFICE'.               
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(5)   VALUE 'GROUP'.                
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(4)   VALUE 'ACCT'.                 
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(11)  VALUE 'CERTIFICATE'.          
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(5)   VALUE 'ERROR'.                
               05  FILLER              PIC X(32)  VALUE SPACES.                 
               05  FILLER              PIC X(7)   VALUE 'COUNTRY'.              
           03  AGENT-ACCT-TITLE.                                                
               05  FILLER              PIC X(7)   VALUE 'PRODUCT'.              
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(6)   VALUE 'OFFICE'.               
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(5)   VALUE 'AGENT'.                
               05  FILLER              PIC X(3)   VALUE SPACES.                 
               05  FILLER              PIC X(4)   VALUE 'ACCT'.                 
               05  FILLER              PIC X(17)  VALUE SPACES.                 
               05  FILLER              PIC X(5)   VALUE 'ERROR'.                
               05  FILLER              PIC X(32)  VALUE SPACES.                 
               05  FILLER              PIC X(7)   VALUE 'COUNTRY'.              
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    PRINT LINE LAYOUT                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-LINE.                                                          
           03  CC                      PIC X(1)           VALUE SPACES.         
           03  PRINT-REC.                                                       
               05  FIILER              PIC XXX            VALUE SPACES.         
               05  P-PROD-CD           PIC X              VALUE SPACES.         
               05  FIILER              PIC X(7)           VALUE SPACES.         
               05  P-OFFICE            PIC X(5)           VALUE SPACES.         
               05  FIILER              PIC XXX            VALUE SPACES.         
               05  P-GROUP-X.                                                   
REN                07  P-GROUP         PIC Z(7)           VALUE  ZEROS.         
                   07  FILLER          PIC X.                                   
               05  FILLER              PIC X(3)           VALUE  SPACES.        
               05  P-ACCT              PIC X(3)           VALUE  SPACES.        
               05  FILLER              PIC X(4)           VALUE  SPACES.        
               05  P-CERT              PIC Z(9)           VALUE  ZEROS.         
               05  FILLER              PIC X(5)           VALUE  SPACES.        
               05  P-MESS.                                                      
                   07  P-CODE          PIC X(3)           VALUE  SPACES.        
                   07  P-MESS2         PIC X(32)          VALUE  SPACES.        
               05  FILLER              PIC X(4)           VALUE  SPACES.        
               05  P-COUNTRY           PIC X(3)           VALUE  SPACES.        
REN            05  FILLER              PIC X(40)          VALUE  SPACES.        
           03  PRINT-REC2 REDEFINES PRINT-REC.                                  
               05  FILLER              PIC X(25).                               
               05  P-TITL1             PIC X(30).                               
               05  FILLER              PIC X(77).                               
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         ERROR CODE AND CORRESPONDING ERROR MESSAGE             *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  ERROR-TABLE.                                                         
           03  ERROR-TAB.                                                       
               05  FILLER                          PIC X(38)                    
                   VALUE 'A01AGENT RECORD NOT ON NAME FILE      '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'A02AGENT N/F READ ERROR               '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'B01BRANCH NOT ON BRANCH FILE          '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'M20A & S COVERAGE CODE IS C, J OR S   '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'M21A & S COVERAGE CODE IS W, X, Y OR Z'.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'M39TOTAL DUE THIS MONTH OUT OF BALANCE'.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'M40BILNG CNTRL OR INFRCE REC NOT RECVD'.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'M50NUMBER OF LIVES IS 0               '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'R01MASTER RECORD NOT ON FILE          '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'R03MASTER DISK ERROR                  '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'S01INVALID BENEFIT CODE               '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'S02FRENCH BENEFIT CODE NOT ON FILE    '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'S03BENEFIT CODE NOT ON FILE           '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'S04BENEFIT CODE DISK ERROR            '.              
               05  FILLER                          PIC X(38)                    
                   VALUE 'S05GIVEN BENEFIT CODE IS FRENCH       '.              
           03  ERR-TABLE1 REDEFINES ERROR-TAB.                                  
               05  ERR-TABLE2 OCCURS 15 TIMES INDEXED BY ERR-INDEX.             
                   07  ERR-TAB                     PIC X(3).                    
                   07  ERR-MESS                    PIC X(35).                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         RECORD TYPE AND CORRESPONDING RECORD NAME              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  TITLE-TABLE.                                                         
           03  TITLE-TAB.                                                       
               05  FILLER                          PIC X(30)                    
                   VALUE 'HSERVICE OFFICE ARREARS       '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE 'TNXT SCHED ARREARS ACTIVITY   '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE 'IPENDING COMMISSION           '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE 'QFIRST YEAR COMMISSION        '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE 'SMASTER RECORD STATUS         '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE '2B I L L I N G                '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE '3IDENTIFICATION CERTIFICATES  '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE '4A D D R E S S   L A B E L S  '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE '5CERTIFICATE HOLDER LISTING   '.                      
               05  FILLER                          PIC X(30)                    
                   VALUE '6LAPSE NOTICE                 '.                      
           03  TITL-TABLE REDEFINES TITLE-TAB.                                  
               05  TITL-TABL OCCURS 10 TIMES INDEXED BY TITL-INDEX.             
                   07  T-REC                       PIC X(1).                    
                   07  T-TITL                      PIC X(29).                   
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *               NO ERROS FOR THIS RUN MESSAGE                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  NO-ERROR-MSG.                                                        
           03  FILLER          VALUE '0'           PIC X(1).                    
           03  FILLER          VALUE SPACES        PIC X(10).                   
           03  FILLER                              PIC X(18)                    
               VALUE 'NO ERRORS THIS RUN'.                                      
                                                                                
MAN02  COPY GWFERRWS.                                                           
       PROCEDURE DIVISION.                                                      
      *----------------------------------------------------------------*        
      *     GET THE MAXIMUM NUMBER OF LINES THAT CAN BE PRINTED ON     *        
      *     AN 11 X 15 PIECE OF PAPER AND CHNAGE THE FORM NUMBER       *        
      *     THIS REPORT                                                *        
      *----------------------------------------------------------------*        
MAN02      CALL 'ZLINECT'                   USING   PAGE-SIZE.                  
      *----------------------------------------------------------------*        
      *   MOVE TO A NEW PAGE AND PRINT ALL HEADINGS THAT ARE NEEDED    *        
      *----------------------------------------------------------------*        
           PERFORM READ-ROUTINE             THRU    READ-ROUTINE-EXIT.          
           IF  TAPE-RETURN        NOT       =       +0                          
               ADD +1                       TO      PAGE-NUMBER                 
               PERFORM  NEW-PAGE            THRU    NEW-PAGE-EXIT               
               MOVE NO-ERROR-MSG            TO      PRINT-LINE                  
               PERFORM PRINT-ROUTINE        THRU    PRINT-ROUTINE-EXIT          
               GO TO END-OF-JOB.                                                
           MOVE E-REC-TYPE                  TO      PREV-REC.                   
           GO TO FIRST-TIME.                                                    
                                                                                
      *----------------------------------------------------------------*        
      *    INITIALIZE PREVIOUS RECORD TYPE AND READ AN ERROR RECORD    *        
      *----------------------------------------------------------------*        
       ERR-LOOP.                                                                
           MOVE E-REC-TYPE                  TO      PREV-REC.                   
           PERFORM READ-ROUTINE             THRU    READ-ROUTINE-EXIT.          
                                                                                
       FIRST-TIME.                                                              
           IF  TAPE-RETURN    NOT           =       ZEROS                       
               GO TO END-OF-JOB.                                                
           IF  LINE-COUNT    GREATER        THAN    PAGE-SIZE                   
               ADD +1                       TO      PAGE-NUMBER                 
               PERFORM  NEW-PAGE            THRU    NEW-PAGE-EXIT.              
      *----------------------------------------------------------------*        
      *       IF THE ERROR RECORD TYPE HAS NOT CHANGED THEN KEEP       *        
      *       PROCESSING THE RECORDS.  IF THE ERROR RECORD TYPE                 
      *       HAS CHANGED GET THE TITLE THAT MATCHES THAT RECORD       *        
      *       A START A NEW PAGE WITH THE APPROPRIATE HEADINGS.        *        
      *----------------------------------------------------------------*        
           IF  E-REC-TYPE                   =       PREV-REC                    
               PERFORM PROCESS-ERROR        THRU    PROCESS-ERROR-EXIT          
           ELSE                                                                 
               MOVE +1                      TO      PAGE-NUMBER                 
               PERFORM  NEW-PAGE            THRU    NEW-PAGE-EXIT               
               PERFORM TITL-LOOP            THRU    TITL-LOOP-EXIT              
               PERFORM PROCESS-ERROR        THRU    PROCESS-ERROR-EXIT.         
           GO TO ERR-LOOP.                                                      
      *----------------------------------------------------------------*        
      *        IF YOU HAVE GOT TO THIS POINT YOUR FINISH               *        
      *----------------------------------------------------------------*        
       END-OF-JOB.                                                              
               MOVE +4                      TO      TAPE-RETURN                 
                                                    PRINT-RETURN.               
               PERFORM PRINT-ROUTINE        THRU    PRINT-ROUTINE-EXIT          
               STOP RUN.                                                        
                                                                                
      *----------------------------------------------------------------*        
      *               PRINT THE TITLES ON A NEW PAGE                   *        
      *----------------------------------------------------------------*        
       NEW-PAGE.                                                                
           MOVE '1'                         TO      CC.                         
           MOVE PAGE-NUMBER                 TO      TITL-PAGE-NUMBER.           
           MOVE TITL-1                      TO      PRINT-REC.                  
           PERFORM PRINT-ROUTINE            THRU    PRINT-ROUTINE-EXIT.         
           MOVE +1                          TO      LINE-COUNT.                 
       NEW-PAGE-EXIT.                                                           
           EXIT.                                                                
                                                                                
       PRINT-ROUTINE.                                                           
           CALL 'DLSWRITE'                  USING   PRINT-SYS022                
                                                    PRINT-RETURN                
                                                    PRINT-LINE                  
                                                    PRINT-RECSIZE               
                                                    PRINT-BLKSIZE               
                                                    PRINT-FORMAT                
                                                    PRINT-SYS022-COUNT.         
           MOVE SPACES                      TO      PRINT-REC.                  
       PRINT-ROUTINE-EXIT.                                                      
           EXIT.                                                                
                                                                                
       READ-ROUTINE.                                                            
           CALL 'DLSREAD'                   USING   TAPE-SYS011                 
                                                    TAPE-RETURN                 
                                                    ERR-REC                     
                                                    TAPE-SYS011-RECSIZE         
                                                    TAPE-SYS011-BLKSIZE         
                                                    TAPE-SYS011-FORMAT          
                                                    TAPE-SYS011-COUNT.          
       READ-ROUTINE-EXIT.                                                       
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *                    PROCESS ERROR RECORD                        *        
      *----------------------------------------------------------------*        
       PROCESS-ERROR.                                                           
           IF LINE-COUNT    GREATER         THAN    PAGE-SIZE                   
              MOVE +0                       TO      LINE-COUNT                  
              ADD +1                        TO      PAGE-NUMBER                 
              PERFORM NEW-PAGE              THRU    NEW-PAGE-EXIT.              
              PERFORM TITL-LOOP             THRU    TITL-LOOP-EXIT.             
           MOVE E-PROD-CD                   TO      P-PROD-CD.                  
           MOVE E-OFFICE                    TO      P-OFFICE.                   
           MOVE SPACES                      TO      P-GROUP-X.                  
           IF  E-REC-TYPE                   =       'Q'                         
             OR (E-REC-TYPE                 =       'I'                         
               AND E-CODE1                  =       'A')                        
               MOVE E-AACCT                 TO      P-ACCT                      
               MOVE E-AGENT                 TO      P-GROUP-X                   
               PERFORM AGENT-ERROR          THRU    AGENT-ERROR-EXIT            
               GO TO PROCESS-ERROR-EXIT.                                        
           IF E-GROUP NUMERIC                                                   
              MOVE E-GROUP                  TO      P-GROUP                     
           ELSE                                                                 
              MOVE ZERO                     TO      P-GROUP.                    
           MOVE E-ACCT                      TO      P-ACCT.                     
           IF E-CERT NUMERIC                                                    
              MOVE E-CERT                   TO      P-CERT                      
           ELSE                                                                 
              MOVE ZERO                     TO      P-CERT.                     
           IF  E-COUNTRY                    =       '0'                         
               MOVE 'CAN'                   TO      P-COUNTRY                   
           ELSE                                                                 
               IF  E-COUNTRY                =       '1'                         
                   MOVE 'USA'               TO      P-COUNTRY                   
               ELSE                                                             
                   IF  E-COUNTRY            =       SPACES                      
                       MOVE SPACES          TO      P-COUNTRY.                  
           IF  E-CODE1                      =       'N' OR 'X'                  
               PERFORM EXP-ERROR            THRU    EXP-ERROR-EXIT              
               GO TO PROCESS-ERROR-EXIT.                                        
           PERFORM MESS-LOOP                THRU    MESS-LOOP-EXIT.             
       PROCESS-ERROR-EXIT.                                                      
           EXIT.                                                                
      *----------------------------------------------------------------*        
      *     GET THE NAME OF THE RECORDS THAT ARE BEING PROCESSED       *        
      *----------------------------------------------------------------*        
       TITL-LOOP.                                                               
           SET TITL-INDEX                   TO      1.                          
           SEARCH TITL-TABL                 VARYING TITL-INDEX                  
             AT END                                                             
               GO TO TITL-LOOP-EXIT                                             
             WHEN                                                               
               E-REC-TYPE                   =       T-REC (TITL-INDEX)          
                 MOVE T-TITL (TITL-INDEX)   TO      P-TITL1.                    
           MOVE '-'                         TO      CC.                         
           PERFORM PRINT-ROUTINE            THRU    PRINT-ROUTINE-EXIT.         
           IF  E-REC-TYPE                   =       'I'                         
            OR  E-REC-TYPE                  =       'Q'                         
               MOVE AGENT-ACCT-TITLE        TO      PRINT-REC                   
           ELSE                                                                 
               MOVE GROUP-ACCT-TITLE        TO      PRINT-REC.                  
           MOVE SPACES                      TO      CC.                         
           PERFORM PRINT-ROUTINE            THRU    PRINT-ROUTINE-EXIT.         
           ADD +7                           TO      LINE-COUNT.                 
       TITL-LOOP-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *      MOVE AGENTS NAME FILE ERROR MESSAGES TO OUTPUT BUFFER     *        
      *----------------------------------------------------------------*        
       AGENT-ERROR.                                                             
           MOVE E-CODE                      TO      P-CODE.                     
           IF  E-CODE                       =       'A01'                       
               MOVE ERR-MESS (1)            TO      P-MESS                      
           ELSE                                                                 
               IF  E-CODE                   =       'A02'                       
                   MOVE ERR-MESS (2)        TO      P-MESS                      
               ELSE                                                             
                   MOVE ERR-MESS (3)        TO      P-MESS.                     
           ADD +1                           TO      LINE-COUNT.                 
           PERFORM PRINT-ROUTINE            THRU    PRINT-ROUTINE-EXIT.         
       AGENT-ERROR-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *  SUPPLY ERROR MESSAGE FOR MASTER OR NAME + ADDRESS EXPANSION   *        
      *----------------------------------------------------------------*        
       EXP-ERROR.                                                               
           MOVE E-CODE                      TO      P-CODE.                     
           IF  E-CODE1                      =       'N'                         
              MOVE ' NAME + ADDRESS EXPAND' TO      P-MESS2                     
           ELSE                                                                 
              MOVE ' MASTER EXPAND'         TO      P-MESS2.                    
           ADD +1                           TO      LINE-COUNT.                 
           PERFORM PRINT-ROUTINE            THRU    PRINT-ROUTINE-EXIT.         
       EXP-ERROR-EXIT.                                                          
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *     GET THE ERROR MESSAGE THAT CORRESPONDS TO THE ERROR CODE   *        
      *     FROM THE ERROR MESSAGE TABLE                               *        
      *----------------------------------------------------------------*        
       MESS-LOOP.                                                               
           SET ERR-INDEX                    TO      1.                          
           SEARCH ERR-TABLE2 VARYING ERR-INDEX                                  
              AT END                                                            
                 GO TO MESS-LOOP-EXIT                                           
              WHEN                                                              
                 E-CODE                     =       ERR-TAB (ERR-INDEX)         
                  MOVE ERR-MESS (ERR-INDEX) TO      P-MESS.                     
           ADD +1                           TO      LINE-COUNT.                 
           PERFORM PRINT-ROUTINE            THRU    PRINT-ROUTINE-EXIT.         
       MESS-LOOP-EXIT.                                                          
           EXIT.                                                                
                                                                                
MAN07 *9999-DUMP-ROUTINE.                                                       
MAN07 ******************************************************************        
MAN07 *    SERIOUS ERROR OCCURRED.                                              
MAN07 *    DISPLAY SOME CONSOLE MESSAGES, TAKE A DUMP THEN ABEND.               
MAN07 *    COPYBOOK GWRDUMP IS REQUIRED                                         
MAN07 ******************************************************************        
MAN07 *                                                                         
MAN07 *    MOVE WS-PROGRAM-ID TO GWRDUMP-PROGRAM-NAME.                          
MAN07 *    CALL GWCDUMP    USING ICBM                                           
MAN07 *                          GWRDUMP.                                       
MAN07 *                                                                         
MAN07 *9999-EXIT.                                                               
MAN07 *    EXIT.                                                                
