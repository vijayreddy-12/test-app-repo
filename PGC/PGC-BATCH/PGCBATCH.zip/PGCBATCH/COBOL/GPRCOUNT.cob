       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.  GPRCOUNT.                                                   
      *This program has been examined/renovated for Year 2000 compliance.       
      *REMARKS.  THIS PROGRAM PRINTS OUT A REPORT LISTING ALL THE               
      *        REPORTS PRODUCED BY GPRINTAL AND HOW MANY PAGES FOR              
      *        REPRT WAS PRODUCED THIS RUN.                                     
      *****************************************************************         
      *               GIPSY RELEASE # 1                               *         
      *                                                               *         
      *  NOV 89   CHANGED OUTPUT ERROR TITLE TO RXPLUS COVERAGE       *         
      *                                             M BURTON          *         
      *  NOV 90   CHANGED COMMISSION RELEASE TITLES TO MAKE NOTE      *         
      *           OF THE FACT THAT THEY'RE ON MICROFICHE NOW          *         
      *           (SUPPORT RELEASE 3)               I BUCKNELL        *         
      *                                             M BURTON          *         
      *  DEC/91   M. PRANGE                                           *         
      *         - ADDED OVERAGE EXPIRY LETTERS & REPORTS (XL AND XR)  *         
      *         - REMOVED RXPLUS REFERENCE (X)                        *         
      *                                                               *         
      *  OCT/92   K. CURRIE                                           *         
      *         - REMOVED 'SOON TO BE RELEASED' FROM OVERAGE LETTER   *         
      *  SEP/08 IBMECU       - ENTERPRISE COMPILER UPGRADE            *         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      *****************************************************************         
       ENVIRONMENT DIVISION.                                                    
       DATA DIVISION.                                                           
       WORKING-STORAGE SECTION.                                                 
       01  START-DATA-DIVISION  PIC X(16)  VALUE '* START OF  WS *'.            
      *----------------------------------------------------------------*        
      *                                                                *        
      *    INITIALIZE TABLE SUBSCRIPT, FORM CODE AND PRINT BUFFER      *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  SUBSCRIPT            PIC S9(3)  COMP-3  VALUE +0.                    
       01  FORM-STANDARD-TWICE  PIC X(2)           VALUE '92'.                  
       01  PRT-BUFFER           PIC X(80)         VALUE SPACES.                 
       01  TEST-DATE            PIC X(8).                                       
       01  QDATE-BC             PIC X(2)           VALUE 'BC'.                  
       01  PRINT-SYS014         PIC X(6)           VALUE 'SYS014'.              
       01  PRINT-SYS014-COUNT   PIC S9(7) COMP-3   VALUE +0.                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *             TABLE OF DIFFERENT REPORT IDENTIFIERS              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  RECORD-TYPES.                                                        
           03  FILLER           PIC X(5)           VALUE '  HA '.               
           03  FILLER           PIC X(5)           VALUE '  HB '.               
           03  FILLER           PIC X(5)           VALUE '  I  '.               
           03  FILLER           PIC X(5)           VALUE '  J  '.               
           03  FILLER           PIC X(5)           VALUE '  K  '.               
           03  FILLER           PIC X(5)           VALUE '  N  '.               
           03  FILLER           PIC X(5)           VALUE '  P  '.               
           03  FILLER           PIC X(5)           VALUE '  Q  '.               
           03  FILLER           PIC X(5)           VALUE '  R  '.               
           03  FILLER           PIC X(5)           VALUE '  T  '.               
           03  FILLER           PIC X(5)           VALUE '  UA '.               
           03  FILLER           PIC X(5)           VALUE '  V  '.               
           03  FILLER           PIC X(5)           VALUE '  WA '.               
           03  FILLER           PIC X(5)           VALUE '  WB '.               
           03  FILLER           PIC X(5)           VALUE '  XL '.               
           03  FILLER           PIC X(5)           VALUE '  XR '.               
           03  FILLER           PIC X(5)           VALUE '  21 '.               
           03  FILLER           PIC X(5)           VALUE '  22 '.               
           03  FILLER           PIC X(5)           VALUE '  23 '.               
           03  FILLER           PIC X(5)           VALUE '  24 '.               
           03  FILLER           PIC X(5)           VALUE '  25 '.               
           03  FILLER           PIC X(5)           VALUE '  26 '.               
           03  FILLER           PIC X(5)           VALUE '  31 '.               
           03  FILLER           PIC X(5)           VALUE '  32 '.               
           03  FILLER           PIC X(5)           VALUE '  33 '.               
           03  FILLER           PIC X(5)           VALUE '  34 '.               
           03  FILLER           PIC X(5)           VALUE '  35 '.               
           03  FILLER           PIC X(5)           VALUE '  36 '.               
           03  FILLER           PIC X(5)           VALUE '  4  '.               
           03  FILLER           PIC X(5)           VALUE '  51 '.               
           03  FILLER           PIC X(5)           VALUE '  52 '.               
           03  FILLER           PIC X(5)           VALUE '  53 '.               
           03  FILLER           PIC X(5)           VALUE '  54 '.               
           03  FILLER           PIC X(5)           VALUE '  55 '.               
           03  FILLER           PIC X(5)           VALUE '  56 '.               
           03  FILLER           PIC X(5)           VALUE '  61 '.               
           03  FILLER           PIC X(5)           VALUE '  62 '.               
       01  RECORD-ID  REDEFINES RECORD-TYPES.                                   
           03  REC-ID OCCURS 37 TIMES      PIC X(5).                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *           TABLE OF DIFFERENT REPORT TITLES                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-TITLES.                                                       
           03  FILLER           PIC X(53)  VALUE                                
               'GROUP SERVICE OFFICE - REPORT OF LAPSE NOTICES MAILED'.         
           03  FILLER           PIC X(53)  VALUE                                
               'GROUP SERVICE OFFICE OVERDUE PREMIUM REPORT          '.         
           03  FILLER           PIC X(53)  VALUE                                
               'PENDING GROUP COMMISSION REPORT                      '.         
           03  FILLER           PIC X(53)  VALUE                                
               'GIPSY PREMIUM AND ACCOUNTING TRANSACTION REGISTER    '.         
           03  FILLER           PIC X(53)  VALUE                                
               'GIPSY TRANSACTION REGISTER                           '.         
           03  FILLER           PIC X(53)  VALUE                                
               'DETAIL CHANGES REPORTS                               '.         
           03  FILLER           PIC X(53)  VALUE                                
               'NAP RELEASE REPORT                                   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'FIRST YEAR GROUP COMMISSIONS                         '.         
           03  FILLER           PIC X(53)  VALUE                                
               'REMINDER LISTING                                     '.         
           03  FILLER           PIC X(53)  VALUE                                
               'NEXT SCHEDULED ARREARS ACTIVITY REPORT               '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LTD CASH PREMIUMS PAID REPORT                        '.         
           03  FILLER           PIC X(53)  VALUE                                
               'BILLING EXCEPTION REPORT                             '.         
           03  FILLER           PIC X(53)  VALUE                                
               'COMMISSION RELEASE CONTROL REPORT  (FICHE)           '.         
           03  FILLER           PIC X(53)  VALUE                                
               'COMMISSION RELEASE SUMMARY REPORT  (FICHE)           '.         
           03  FILLER           PIC X(53)  VALUE                                
               'OVERAGE EXPIRY LETTERS                               '.         
           03  FILLER           PIC X(53)  VALUE                                
               'OVERAGE EXPIRY REPORT                                '.         
           03  FILLER           PIC X(53)  VALUE                                
               '                                                     '.         
           03  FILLER           PIC X(53)  VALUE                                
               'GROUP PREMIUM STATEMENT - ENG (BY GROUP OFFICE)      '.         
           03  FILLER           PIC X(53)  VALUE                                
               'GROUP PREMIUM STATEMENT - FR  (BY GROUP OFFICE)      '.         
           03  FILLER           PIC X(53)  VALUE                                
               '                                                     '.         
           03  FILLER           PIC X(53)  VALUE                                
               '                                                     '.         
           03  FILLER           PIC X(53)  VALUE                                
               '                                                     '.         
      *    03  FILLER           PIC X(53)  VALUE                                
      *        'GROUP PREMIUM STATEMENT - US  (OTHER GROUP OFFICES)  '.         
      *    03  FILLER           PIC X(53)  VALUE                                
      *        'GROUP PREMIUM STATEMENT - ENG (OTHER GROUP OFFICES)  '.         
      *    03  FILLER           PIC X(53)  VALUE                                
      *        'GROUP PREMIUM STATEMENT - FR  (OTHER GROUP OFFICES)  '.         
      *    03  FILLER           PIC X(53)  VALUE                                
      *        'GROUP PREMIUM STATEMENT - US  (GRP OFF 111, 115)     '.         
      *    03  FILLER           PIC X(53)  VALUE                                
      *        'GROUP PREMIUM STATEMENT - ENG (GRP OFF 111, 115)     '.         
      *    03  FILLER           PIC X(53)  VALUE                                
      *        'GROUP PREMIUM STATEMENT - FR  (GRP OFF 111, 115)     '.         
           03  FILLER           PIC X(53)  VALUE                                
               'IDENTIFICATION CERTIFICATE - US  (OTHER GRP OFF)     '.         
           03  FILLER           PIC X(53)  VALUE                                
               'IDENTIFICATION CERTIFICATE - ENG (OTHER GRP OFF)     '.         
           03  FILLER           PIC X(53)  VALUE                                
               'IDENTIFICATION CERTIFICATE - FR  (OTHER GRP OFF)     '.         
           03  FILLER           PIC X(53)  VALUE                                
               'IDENTIFICATION CERTIFICATE - US  (GRP OFF 111,115)   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'IDENTIFICATION CERTIFICATE - ENG (GRP OFF 111,115)   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'IDENTIFICATION CERTIFICATE - FR  (GRP OFF 111,115)   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'ADDRESS LABELS                                       '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LISTING OF GROUP CERTIFICATE HOLDERS - US  (OTHER)   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LISTING OF GROUP CERTIFICATE HOLDERS - ENG (OTHER)   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LISTING OF GROUP CERTIFICATE HOLDERS - FR  (OTHER)   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LISTING OF GROUP CERTIFICATE HOLDERS - US  (111,115) '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LISTING OF GROUP CERTIFICATE HOLDERS - ENG (111,115) '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LISTING OF GROUP CERTIFICATE HOLDERS - FR  (111,115) '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LAPSE NOTICE - ENG                                   '.         
           03  FILLER           PIC X(53)  VALUE                                
               'LAPSE NOTICE - FR                                    '.         
       01  REPORT-NAME  REDEFINES REPORT-TITLES.                                
           03  TITLE-74 OCCURS 37 TIMES    PIC X(53).                           
      *----------------------------------------------------------------*        
      *                                                                *        
      *                        PAGE HEADING                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  HEADER-LAYOUT.                                                       
           03  FILLER              PIC X(23)                                    
               VALUE '1GPRCOUNT              '.                                 
           03  FILLER              PIC X(40)                                    
               VALUE 'GPRINTAL REPORTS PRODUCED CONTROL REPORT'.                
           03  FILLER              PIC X(10)                                    
               VALUE '  RUNDATE '.                                              
           03  RUN-DATE            PIC X(7).                                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    COLUMN  HEADINGS                            *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  COLUMN-LAYOUT.                                                       
           03  FILLER              PIC X(28)                                    
               VALUE '-   REPORT ID   REPORT TITLE'.                            
           03  FILLER              PIC X(43)   VALUE SPACES.                    
           03  FILLER              PIC X(9)    VALUE 'NO. PAGES'.               
      *----------------------------------------------------------------*        
      *                                                                *        
      *                    PRINT LINE LAYOUT                           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  LINE-LAYOUT.                                                         
           03  FILLER              PIC X(5)    VALUE '0    '.                   
           03  PRT-REPORT-ID       PIC X(5)    VALUE SPACES.                    
           03  FILLER              PIC X(6)    VALUE SPACES.                    
           03  PRT-REPORT-TITLE    PIC X(53)   VALUE SPACES.                    
           03  FILLER              PIC X(4)    VALUE SPACES.                    
           03  PRT-NO-PAGES        PIC ZZZZ9.                                   
           03  FILLER              PIC X(2)    VALUE SPACES.                    
       01  DLSWRITE-PARMS-SYS030.                                               
           05  DLS-SYS030                 PIC X(6) VALUE 'SYS030'.              
           05  DLS-SYS030-RETURN-CODE COMP-3 PIC S9(1) VALUE +0.                
           05  DLS-SYS030-RECSIZE         PIC 9(5) VALUE 00133.                 
           05  DLS-SYS030-BLKSIZE         PIC 9(5) VALUE 03990.                 
           05  DLS-SYS030-FORMAT          PIC XX   VALUE 'FB'.                  
           05  DLS-SYS030-COUNT    COMP-3 PIC S9(7) VALUE +0.                   
                                                                                
       01  END-DATA-DIVISION    PIC X(20)  VALUE '** END  OF WS  **'.           
MAN07  01  CALLED-PROGRAMS.                                                     
MAN07 *    05  GC2TODAY                     PIC X(8)  VALUE 'GC2TODAY'.         
GNE        05  QDATEQ2                      PIC X(8)  VALUE 'QDATEQ2'.          
       LINKAGE SECTION.                                                         
      *----------------------------------------------------------------*        
      *                                                                *        
      *              REPORT ACCUMULATORS COPY BOOK                     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  REPORT-ACCUMULATORS.                                                 
        COPY   GPRACCUM  REPLACING                                              
                                            ==01  GPRACCUM.== BY ====.          
       01  REPORT-COUNT  REDEFINES REPORT-ACCUMULATORS.                         
           03  ACCUM     OCCURS 37 TIMES   PIC S9(5) COMP-3.                    
      *----------------------------------------------------------------*        
      *                                                                *        
      *                PRINT PARAMETER COPY BOOK                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       01  PRINT-PARAMETERS.                                                    
        COPY  GPRPRINT  REPLACING                                               
                                            ==01  GPRPRINT.== BY ====.          
                                                                                
       PROCEDURE DIVISION  USING REPORT-ACCUMULATORS                            
                                 PRINT-PARAMETERS.                              
      *----------------------------------------------------------------*        
      *                                                                *        
      *     GET CURRENT SYSTEM DATE AND CALL THE PROGRAM THAT          *        
      *     WILL SEGMENT THE PRINT GOING OUT ON SYS022.                *        
      *                                                                *        
      *----------------------------------------------------------------*        
GNE        CALL 'ZCURRDAT' USING TEST-DATE.                                     
GNE   *    CALL 'QDATE' USING QDATE-BC                                          
GNE        CALL QDATEQ2 USING QDATE-BC                                          
                              TEST-DATE                                         
                              RUN-DATE.                                         
                                                                                
      *    CALL 'GPRSGMNT' USING PRINT-SYS022                                   
      *                          FORM-STANDARD-TWICE.                           
                                                                                
           MOVE ZERO TO PRINT-RETURN.                                           
                                                                                
           PERFORM HEADING-RTN THRU HEADING-RTN-EXIT.                           
      *----------------------------------------------------------------*        
      *                                                                *        
      *                  INITIALIZE SUBSCRIPT                          *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE +1 TO SUBSCRIPT.                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     CHECK TO SEE IF ALL THE REPORT PAGE COUNTS ARE PRINTED.    *        
      *     FORCE A PAGE BREAK AT CERTIFICATE LISTING ACCUMULATORS     *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-ACCUMULATORS.                                                      
           IF  SUBSCRIPT IS GREATER THAN +37 THEN                               
               GO TO END-OF-JOB.                                                
           IF  SUBSCRIPT EQUAL +30                                              
               PERFORM HEADING-RTN THRU HEADING-RTN-EXIT.                       
      *----------------------------------------------------------------*        
      *                                                                *        
      *     MOVE THE IDENTIFIER CODE, REPORT TITLE AND THE NUMBER      *        
      *     OF PAGES PRINTED FOR THAT REPORT TO THE LINE LAYOUT        *        
      *     AND INCREASE THE SUBSCRIPT BY ONE.                         *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE REC-ID (SUBSCRIPT) TO PRT-REPORT-ID.                            
           MOVE TITLE-74 (SUBSCRIPT) TO PRT-REPORT-TITLE.                       
           MOVE ACCUM  (SUBSCRIPT) TO PRT-NO-PAGES.                             
           ADD +1 TO SUBSCRIPT.                                                 
      *----------------------------------------------------------------*        
      *                                                                *        
      *     MOVE THE LINE LAYOUT TO THE PRINT BUFFER THEN CALL THE     *        
      *     PROCEDURE TO WRITE IT OUT ON SYS022.  THEN GO BACK AN      *        
      *     SEE IF WE ARE FINISHED.                                    *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE LINE-LAYOUT TO PRT-BUFFER.                                      
           PERFORM  PRINT-LINE THRU                                             
                    PRINT-LINE-EXIT.                                            
           GO TO PRINT-ACCUMULATORS.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *          AT THIS POINT WE ARE FINSIHED AND CAN LEAVE           *        
      *                                                                *        
      *----------------------------------------------------------------*        
       END-OF-JOB.                                                              
           EXIT PROGRAM.                                                        
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *     MOVE THE REPORT TITLES TO THE PRINT BUFFER THEN            *        
      *     CALL THE PROCEDURE TO WRITE IT OUT ON SYS022.              *        
      *                                                                *        
      *----------------------------------------------------------------*        
       HEADING-RTN.                                                             
           MOVE HEADER-LAYOUT TO PRT-BUFFER.                                    
           PERFORM  PRINT-LINE THRU                                             
                    PRINT-LINE-EXIT.                                            
      *----------------------------------------------------------------*        
      *                                                                *        
      *     MOVE THE COLUMN TITLES TO THE PRINT BUFFER THEN CALL       *        
      *     THE PROCEDURE TO WRITE IT OUT ON SYS022.                   *        
      *                                                                *        
      *----------------------------------------------------------------*        
           MOVE COLUMN-LAYOUT TO PRT-BUFFER.                                    
           PERFORM  PRINT-LINE THRU                                             
                    PRINT-LINE-EXIT.                                            
       HEADING-RTN-EXIT.                                                        
           EXIT.                                                                
                                                                                
      *----------------------------------------------------------------*        
      *                                                                *        
      *         SET UP CALL TO A GENERAL I/O ROUTINE "DLSWRITE"        *        
      *                                                                *        
      *    FOR DLSWRITE TO WORK YOU MUST SUPPLY IT WITH THE SYSTEM     *        
      *    NUMBER, AREA WHICH IS TO BE WRITTEN OUT, LOGICAL RECORD     *        
      *    LENGTH, LOGICAL BLOCK SIZE AND THE LOGICAL RECORD FORMAT.   *        
      *    THE PROGRAM WILL RETURN A RETURN CODE AND THE NUMBER OF     *        
      *    RECORD WRITTEN TO THAT SYSTEM NUMBER.                       *        
      *                                                                *        
      *----------------------------------------------------------------*        
       PRINT-LINE.                                                              
           CALL  'DLSWRITE' USING PRINT-SYS014                                  
                                  PRINT-RETURN                                  
                                  PRT-BUFFER                                    
                                  PRINT-RECSIZE                                 
                                  PRINT-BLKSIZE                                 
                                  PRINT-FORMAT                                  
                                  PRINT-SYS014-COUNT.                           
       PRINT-LINE-EXIT.                                                         
           EXIT.                                                                
