       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.    GSCFACT.                                                  
      *This program has been examined/renovated for Year 2000 compliance.       
      *AUTHOR.        ANITA NIKELSKI.                                           
      *DATE-WRITTEN.  JUL 1992.                                                 
      *               SEPTEMBER 2008 - ENTERPRISE COMPILER UPGRADE              
      *DATE-COMPILED.                                                           
      ******************************************************************        
      *    RETRIEVES A SALE CREDIT SCALE & FACTOR VALUES BASED ON PARMS         
      *    RECEIVED.                                                            
      ******************************************************************        
       ENVIRONMENT DIVISION.                                                    
       CONFIGURATION SECTION.                                                   
       INPUT-OUTPUT SECTION.                                                    
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(24)      VALUE                       
           'GSCFACT WS STARTS HERE*'.                                           
                                                                                
       01  WS-SUB1                   PIC 999.                                   
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
           COPY GSCCALP.                                                        
                                                                                
       01  GTABSC-RECORD.                                                       
           COPY GTABPARM.                                                       
      /                                                                         
       PROCEDURE DIVISION USING GSC-CALC-PARMS                                  
                                GTABSC-RECORD.                                  
                                                                                
       0000-GSCFACT.                                                            
           IF GSC-RET-CURR-FLAG                                                 
              PERFORM 1000-FIND-CURR-FACTOR THRU 1000-EXIT                      
                      VARYING WS-SUB1 FROM +1                                   
                      BY +1                                                     
                      UNTIL WS-SUB1 > GTABSC-TABLE-SIZE                         
           ELSE                                                                 
              PERFORM 2000-FIND-OLD-FACTOR THRU 2000-EXIT                       
                      VARYING WS-SUB1 FROM +1                                   
                      BY +1                                                     
                      UNTIL WS-SUB1 > GTABSC-TABLE-SIZE.                        
           GOBACK.                                                              
      /                                                                         
                                                                                
       1000-FIND-CURR-FACTOR.                                                   
           IF GSC-PRODUCT-CODE = GTABSC-PRODUCT-CODE (WS-SUB1)                  
              IF GSC-FY AND                                                     
                 GSC-FY-RN-TYPE   = GTABSC-FY-RN     (WS-SUB1)                  
                 MOVE GTABSC-FACTOR (WS-SUB1) TO GSC-RET-FY-CURR-FACTOR         
                 MOVE +99                     TO WS-SUB1                        
              ELSE                                                              
              IF GSC-RN AND                                                     
                 GSC-FY-RN-TYPE   = GTABSC-FY-RN     (WS-SUB1)                  
                 MOVE GTABSC-FACTOR (WS-SUB1) TO GSC-RET-RN-CURR-FACTOR         
                 MOVE +99                     TO WS-SUB1                        
              ELSE                                                              
              IF GSC-FY-RN                                                      
                 IF GTABSC-FY-RN (WS-SUB1) = 'FY'                               
                    MOVE GTABSC-FACTOR (WS-SUB1) TO                             
                    GSC-RET-FY-CURR-FACTOR                                      
                 ELSE                                                           
                 IF GTABSC-FY-RN (WS-SUB1) = 'RN'                               
                    MOVE GTABSC-FACTOR (WS-SUB1) TO                             
                    GSC-RET-FY-CURR-FACTOR.                                     
                                                                                
       1000-EXIT.                                                               
           EXIT.                                                                
                                                                                
       2000-FIND-OLD-FACTOR.                                                    
           IF GSC-PRODUCT-CODE = GTABSC-PRODUCT-CODE (WS-SUB1)                  
              IF GSC-FY AND                                                     
                 GSC-FY-RN-TYPE   = GTABSC-FY-RN     (WS-SUB1)                  
                 MOVE GTABSC-FACTOR (WS-SUB1) TO GSC-RET-FY-OLD-FACTOR          
                 MOVE +99                     TO WS-SUB1                        
              ELSE                                                              
              IF GSC-RN AND                                                     
                 GSC-FY-RN-TYPE   = GTABSC-FY-RN     (WS-SUB1)                  
                 MOVE GTABSC-FACTOR (WS-SUB1) TO GSC-RET-RN-OLD-FACTOR          
                 MOVE +99                     TO WS-SUB1                        
              ELSE                                                              
              IF GSC-FY-RN                                                      
                 IF GTABSC-FY-RN (WS-SUB1) = 'FY'                               
                    MOVE GTABSC-FACTOR (WS-SUB1) TO                             
                    GSC-RET-FY-OLD-FACTOR                                       
                 ELSE                                                           
                 IF GTABSC-FY-RN (WS-SUB1) = 'RN'                               
                    MOVE GTABSC-FACTOR (WS-SUB1) TO                             
                    GSC-RET-FY-OLD-FACTOR.                                      
                                                                                
       2000-EXIT.                                                               
           EXIT.                                                                
