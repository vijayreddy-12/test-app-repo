       IDENTIFICATION DIVISION.                                         00010099
FXXTOK PROGRAM-ID.      GC2SEQ.                                                 
      *AUTHOR.          MURRAY E MCGILL.                                00030099
      *DATE-WRITTEN     OCTOBER 22 2008.                                00040099
       DATE-COMPILED.                                                   00050099
      *REMARKS.                                                         00060099
      ******************************************************************00070099
      *                                                                 00080099
      *   NAME         - GC2SEQ                                         00090099
      *                  (CREATION OF EXPENDED GIPSY COMMISSION FILE)   00100099
      *                                                                 00110099
      *   DESCRIPTION  - THIS PROGRAM REFORMATS THE GIPSY COMMISSION    00120099
      *                  FILE.                                          00130099
      *                - INPUT IS PGW.COMM.PROD.DAILY.FILE(+1)          00140099
      *                                                                 00150099
      ******************************************************************00200099
      *                                                                 00210099
       ENVIRONMENT DIVISION.                                            00220099
      *---------------------                                            00230099
       CONFIGURATION SECTION.                                           00240099
       SOURCE-COMPUTER.  IBM-3090.                                      00250099
       OBJECT-COMPUTER.  IBM-3090.                                      00260099
       SPECIAL-NAMES.                                                   00261099
                                                                        00262099
           C02 IS CH2                                                   00263099
           C03 IS CH3                                                   00264099
           C04 IS CH4                                                   00265099
           C05 IS CH5                                                   00266099
           C06 IS CH6                                                   00267099
           C07 IS CH7                                                   00268099
           C08 IS CH8                                                   00269099
           C09 IS CH9                                                   00269199
           C10 IS CH10                                                  00269299
           C11 IS CH11                                                  00269399
           C12 IS CH12                                                  00269499
           S01 IS P01                                                   00269599
           S02 IS P02                                                   00269699
           C01  IS TOP-OF-PAGE.                                         00269799
      *                                                                 00269899
       INPUT-OUTPUT SECTION.                                            00269999
      *---------------------                                            00270099
      *                                                                 00280099
       FILE-CONTROL.                                                    00290099
      *-------------                                                    00300099
      *INPUT FILE FROM THE DAILY GIPSY COMMISSIONS                      00310099
           SELECT COM-FILE-IN ASSIGN COMFILE                            00320099
                                 FILE STATUS  WS-FSTATUS-COMFILE.       00330099
                                                                        00340099
      *OUTPUT FILE EXPANDED GIPSY COMMISSION FILE                       00371599
           SELECT COM-FILE1-OUT  ASSIGN COMFILE1                        00371699
                                 FILE STATUS   WS-FSTATUS-MLIFILE1.     00371799
                                                                        00371899
           SELECT COM-FILE2-OUT  ASSIGN COMFILE2                        00371999
                                 FILE STATUS   WS-FSTATUS-MLIFILE2.     00372099
                                                                        00373099
           SELECT COM-ERROR-RPRT-OUT  ASSIGN ERRORRPT                   00381599
                                 FILE STATUS   WS-FSTATUS-MLIERRRPT.    00381699
                                                                        00381799
      *                                                                 00382499
       DATA DIVISION.                                                   00382599
      *--------------                                                   00382699
      *                                                                 00382799
       FILE SECTION.                                                    00382899
      *-------------                                                    00382999
                                                                        00383099
       FD  COM-FILE-IN                                                  00383199
           LABEL RECORDS ARE STANDARD                                   00383299
           RECORDING MODE IS V                                          00383399
           BLOCK CONTAINS 0 RECORDS                                     00383499
           DATA RECORD IS IN-GIPSY-COMMSSN-REC.                         00383599
                                                                        00383699
       01  IN-GIPSY-COMMSSN-REC       PIC X(300).                       00383799
                                                                        00383899
       FD COM-FILE1-OUT                                                 00460099
           LABEL RECORDS ARE OMITTED                                    00470099
           RECORDING MODE IS V                                          00383399
           BLOCK CONTAINS 0 RECORDS                                     00480099
           DATA RECORD IS OUT-GIPSY-DETAIL-REC.                         00490099
                                                                        00491099
       01  OUT-GIPSY-DETAIL-REC               PIC X(300).               00492099
                                                                        00493099
       FD COM-FILE2-OUT                                                 00494099
           LABEL RECORDS ARE OMITTED                                    00495099
           RECORDING MODE IS F                                          00383399
           BLOCK CONTAINS 0 RECORDS                                     00496099
           DATA RECORD IS OUT-GIPSY-SUMMRY-REC.                         00497099
                                                                        00498099
       01  OUT-GIPSY-SUMMRY-REC               PIC X(500).               00499099
                                                                        00500099
       FD COM-ERROR-RPRT-OUT                                            00571099
           LABEL RECORDS ARE OMITTED                                    00571199
           BLOCK CONTAINS 0 RECORDS                                     00571299
           DATA RECORD IS ERROR-RPRT.                                   00571399
                                                                        00571499
       01  ERROR-RPRT.                                                  00571599
           05  ERROR-RPRT-LINE                PIC X(132).               00571699
                                                                        00571799
      *-----------------------                                          00573499
       WORKING-STORAGE SECTION.                                         00573599
      *------------------------                                         00573699
                                                                        00573799
      *01  GIPSY COMMISSION RELEASE RECORD.                                     
       01  IN-COM-RELEASE-RECORD.                                               
      *03  GIPSY COMMISSION RELEASE RECORD.                                     
           COPY GCOMRLS2 REPLACING == (ID) == BY == IN ==.                      
                                                                                
       01  OUT-COM-RELEASE-RECORD.                                              
      *03  GIPSY COMMISSION RELEASE RECORD.                                     
           COPY GCOMRLS2 REPLACING == (ID) == BY == OUT ==.                     
                                                                                
       01  OUT-CCOMTRANS-REC.                                                   
      *03  CCOMMRELEASE-REC.                                                    
           COPY GCEXPCRR.                                                       
                                                                                
       01  ERROR-RPRT-A.                                                00574099
           05  ERROR-RPRT-CTL                 PIC X(01).                00574199
           05  ERROR-RPRT-LINE-A              PIC X(132).               00574299
                                                                        00574399
       01  ERROR-STORE-REC.                                             00600099
           05  WS-ERROR-REC OCCURS 2000 INDEXED BY ERROR-INDX.          00610099
               10  WS-ERROR-POLICY-NAME           PIC X(50).            00620099
               10  WS-ERROR-POLICY-NUMBER         PIC X(06).            00630099
               10  WS-ERROR-MESSAGE-S             PIC X(25).            00640099
               10  WS-ERROR-CERT-NUMBER           PIC X(09).            00650099
               10  WS-ERROR-CLAIMANT-NAME         PIC X(30).            00660099
               10  WS-ERROR-INCURRED-FROM-DATE    PIC X(08).            00661099
               10  WS-ERROR-BEN-CODE              PIC X(01).            00662099
               10  WS-ERROR-SERVICE-CODE          PIC X(05).            00663099
               10  WS-ERROR-SERVICE-SUB-CODE      PIC X(05).            00664099
               10  WS-ERROR-REC-COUNT             PIC S9(06) COMP-3.    00665099
               10  WS-ERROR-TOTAL-CHARGED-AMT     PIC 9(10)V99  VALUE 0.00666099
                                                                        00667099
       01  WS-USER-ABEND-CODE.                                          00692699
           05  WS-COMP-CODE-X                 PIC X(02).                00692799
           05  WS-COMP-CODE REDEFINES WS-COMP-CODE-X PIC 9(04) COMP.    00692899
       01  WS-EXTRACT-DATE.                                             00692999
           05  WS-EXTRACT-DATE-YYYY           PIC  X(04).               00693099
           05  WS-EXTRACT-DATE-MM             PIC  X(02).               00694099
           05  WS-EXTRACT-DATE-DD             PIC  X(02).               00694199
       01  WS-FOGL-CODE.                                                        
           05  WS-FOGL-CODE-1-4               PIC  9(04).                       
           05  WS-FOGL-CODE-5-6               PIC  9(02).                       
           05  WS-FOGL-CODE-7                 PIC  9(01).                       
           05  WS-FOGL-CODE-8-10              PIC  9(03).                       
       01  WS-COVERAGE-TYPE                   PIC  X(05).                       
       01  WS-PRODUCT-CODE                    PIC  X(05).                       
       01  WS-CAUSE-CODE  PIC  9(03).                                           
       01  WS-CODE342-DATA.                                                     
           05  WS-CODE342-KEY.                                                  
               10  WS-CODE342-GROUP    COMP-3 PIC S9(15).                       
               10  WS-CODE342-SUB-ACCOUNT     PIC  X(04).                       
               10  WS-CODE342-BRANCH          PIC S9(5).                        
               10  WS-CODE342-FOGL-CODE       PIC 9(10).                        
               10  WS-CODE342-AGENT-CODE      PIC S9(6).                        
               10  WS-CODE342-CAUSE           PIC S9(3).                        
               10  WS-CODE342-CODE            PIC S9(3).                        
           05  WS-CODE342-CRAMT               PIC S9(11).                       
                                                                                
       01  WS-C-OLD342-DATA.                                                    
           05  WS-C-OLD342-KEY.                                                 
               10  WS-C-OLD342-GROUP   COMP-3 PIC S9(15).                       
               10  WS-C-OLD342-SUB-ACCOUNT    PIC  X(04).                       
               10  WS-C-OLD342-BRANCH         PIC S9(5).                        
               10  WS-C-OLD342-FOGL-CODE      PIC 9(10).                        
               10  WS-C-OLD342-AGENT-CODE     PIC S9(6).                        
               10  WS-C-OLD342-CAUSE          PIC S9(3).                        
               10  WS-C-OLD342-CODE           PIC S9(3).                        
           05  WS-C-OLD342-CRAMT              PIC S9(11).                       
                                                                                
       01  WS-CONTRACT                        PIC  9(06).               00694299
       01  WS-NUMBER-OUT                      PIC S9(14)V9999.          00694399
       01  WS-CHARGED-AMT                     PIC 9(10)V99  VALUE 0.    00694499
       01  WS-ERROR                           PIC  X(01).               00694599
       01  WS-FIP                             PIC  X(03) VALUE 'FIP'.   00694699
       01  WS-SUB                             PIC S9(04) COMP VALUE +1. 00694799
       01  WS-LENGTH                          PIC S9(04) COMP VALUE +10.00694899
       01  WS-DATE-CYYMMDD                    PIC  X(07).               00830099
       01  FILLER REDEFINES WS-DATE-CYYMMDD.                            00840099
           05  WS-CYYMMDD-DATE-C              PIC  X(01).               00850099
           05  WS-CYYMMDD-DATE-YY             PIC  X(02).               00860099
           05  WS-CYYMMDD-DATE-MM             PIC  X(02).               00870099
           05  WS-CYYMMDD-DATE-DD             PIC  X(02).               00880099
       01  WS-CSV-DATE-MMSDDSYY               PIC  X(10).               00890099
       01  FILLER REDEFINES WS-CSV-DATE-MMSDDSYY.                       00900099
           05  WS-CSV-DATE-MM                 PIC  X(02).               00910099
           05  SLASH-01                       PIC  X(01).               00920099
           05  WS-CSV-DATE-DD                 PIC  X(02).               00930099
           05  SLASH-02                       PIC  X(01).               00940099
           05  WS-CSV-DATE-YY                 PIC  X(02).               00950099
       01  WS-DATE-CCYYMMDD                   PIC  X(08).               00960099
       01  FILLER REDEFINES WS-DATE-CCYYMMDD.                           00970099
           05  WS-CCYYMMDD-DATE-CC            PIC  X(02).               00980099
           05  WS-CCYYMMDD-DATE-YY            PIC  X(02).               00990099
           05  WS-CCYYMMDD-DATE-MM            PIC  X(02).               01000099
           05  WS-CCYYMMDD-DATE-DD            PIC  X(02).               01010099
                                                                        01070099
       01  WS-FILE-STATUS.                                              01080099
           05  WS-FSTATUS-XRFFILE             PIC  X(02) VALUE SPACE.   01090099
               88  WS-FSXRFFILE-OPEN-OK                   VALUE '00'.   01100099
               88  WS-FSXRFFILE-READ-EOF                  VALUE '10'.   01101099
           05  WS-FSTATUS-COMFILE             PIC  X(02) VALUE SPACE.   01102099
               88  WS-FSCOMFILE-OPEN-OK                   VALUE '00'.   01103099
               88  WS-FSCOMFILE-READ-EOF                  VALUE '10'.   01104099
           05  WS-FSTATUS-PARMFILE            PIC  X(02) VALUE SPACE.   01105099
               88  WS-FSPARMFILE-OPEN-OK                  VALUE '00'.   01106099
               88  WS-FSPARMFILE-READ-EOF                 VALUE '10'.   01107099
           05  WS-FSTATUS-MLIFILE1            PIC  X(02) VALUE SPACE.   01150099
               88  WS-FSMLIFILE1-OPEN-OK                   VALUE '00'.  01160099
               88  WS-FSMLIFILE1-READ-EOF                  VALUE '10'.  01170099
           05  WS-FSTATUS-MLIFILE2            PIC  X(02) VALUE SPACE.   01180099
               88  WS-FSMLIFILE2-OPEN-OK                   VALUE '00'.  01190099
               88  WS-FSMLIFILE2-READ-EOF                  VALUE '10'.  01200099
           05  WS-FSTATUS-MLIFILE3            PIC  X(02) VALUE SPACE.   01210099
               88  WS-FSMLIFILE3-OPEN-OK                   VALUE '00'.  01220099
               88  WS-FSMLIFILE3-READ-EOF                  VALUE '10'.  01230099
           05  WS-FSTATUS-MLIFILE4            PIC  X(02) VALUE SPACE.   01240099
               88  WS-FSMLIFILE4-OPEN-OK                   VALUE '00'.  01241099
               88  WS-FSMLIFILE4-READ-EOF                  VALUE '10'.  01242099
           05  WS-FSTATUS-MLIFILE5            PIC  X(02) VALUE SPACE.   01243099
               88  WS-FSMLIFILE5-OPEN-OK                   VALUE '00'.  01244099
               88  WS-FSMLIFILE5-READ-EOF                  VALUE '10'.  01245099
           05  WS-FSTATUS-MLIFILE6            PIC  X(02) VALUE SPACE.   01246099
               88  WS-FSMLIFILE6-OPEN-OK                   VALUE '00'.  01247099
               88  WS-FSMLIFILE6-READ-EOF                  VALUE '10'.  01248099
           05  WS-FSTATUS-MLIFILE7            PIC  X(02) VALUE SPACE.   01248199
               88  WS-FSMLIFILE7-OPEN-OK                   VALUE '00'.  01248299
               88  WS-FSMLIFILE7-READ-EOF                  VALUE '10'.  01248399
           05  WS-FSTATUS-MLIFILE8            PIC  X(02) VALUE SPACE.   01248499
               88  WS-FSMLIFILE8-OPEN-OK                   VALUE '00'.  01248599
               88  WS-FSMLIFILE8-READ-EOF                  VALUE '10'.  01248699
           05  WS-FSTATUS-MLIFILE9            PIC  X(02) VALUE SPACE.   01248799
               88  WS-FSMLIFILE9-OPEN-OK                   VALUE '00'.  01248899
               88  WS-FSMLIFILE9-READ-EOF                  VALUE '10'.  01248999
           05  WS-FSTATUS-MLIFIL10            PIC  X(02) VALUE SPACE.   01249099
               88  WS-FSMLIFIL10-OPEN-OK                   VALUE '00'.  01249199
               88  WS-FSMLIFIL10-READ-EOF                  VALUE '10'.  01249299
           05  WS-FSTATUS-MLIFIL11            PIC  X(02) VALUE SPACE.   01249399
               88  WS-FSMLIFIL11-OPEN-OK                   VALUE '00'.  01249499
               88  WS-FSMLIFIL11-READ-EOF                  VALUE '10'.  01249599
           05  WS-FSTATUS-MLIFIL12            PIC  X(02) VALUE SPACE.   01249699
               88  WS-FSMLIFIL12-OPEN-OK                   VALUE '00'.  01249799
               88  WS-FSMLIFIL12-READ-EOF                  VALUE '10'.  01249899
           05  WS-FSTATUS-MLIFIL13            PIC  X(02) VALUE SPACE.   01249999
               88  WS-FSMLIFIL13-OPEN-OK                   VALUE '00'.  01250099
               88  WS-FSMLIFIL13-READ-EOF                  VALUE '10'.  01250199
           05  WS-FSTATUS-MLIFIL14            PIC  X(02) VALUE SPACE.   01250299
               88  WS-FSMLIFIL14-OPEN-OK                   VALUE '00'.  01250399
               88  WS-FSMLIFIL14-READ-EOF                  VALUE '10'.  01250499
           05  WS-FSTATUS-MLIFIL15            PIC  X(02) VALUE SPACE.   01250599
               88  WS-FSMLIFIL15-OPEN-OK                   VALUE '00'.  01250699
               88  WS-FSMLIFIL15-READ-EOF                  VALUE '10'.  01250799
           05  WS-FSTATUS-MLIFIL16            PIC  X(02) VALUE SPACE.   01250899
               88  WS-FSMLIFIL16-OPEN-OK                   VALUE '00'.  01250999
               88  WS-FSMLIFIL16-READ-EOF                  VALUE '10'.  01251099
           05  WS-FSTATUS-MLIFIL17            PIC  X(02) VALUE SPACE.   01251199
               88  WS-FSMLIFIL17-OPEN-OK                   VALUE '00'.  01251299
               88  WS-FSMLIFIL17-READ-EOF                  VALUE '10'.  01251399
           05  WS-FSTATUS-MLIFIL18            PIC  X(02) VALUE SPACE.   01251499
               88  WS-FSMLIFIL18-OPEN-OK                   VALUE '00'.  01251599
               88  WS-FSMLIFIL18-READ-EOF                  VALUE '10'.  01251699
           05  WS-FSTATUS-MLIFIL19            PIC  X(02) VALUE SPACE.   01251799
               88  WS-FSMLIFIL19-OPEN-OK                   VALUE '00'.  01251899
               88  WS-FSMLIFIL19-READ-EOF                  VALUE '10'.  01251999
           05  WS-FSTATUS-MLIFIL20            PIC  X(02) VALUE SPACE.   01252099
               88  WS-FSMLIFIL20-OPEN-OK                   VALUE '00'.  01252199
               88  WS-FSMLIFIL20-READ-EOF                  VALUE '10'.  01252299
           05  WS-FSTATUS-MLIERRFL            PIC  X(02) VALUE SPACE.   01252399
               88  WS-FSMLIERRFL-OPEN-OK                   VALUE '00'.  01252499
               88  WS-FSMLIERRFL-READ-EOF                  VALUE '10'.  01252599
           05  WS-FSTATUS-MLIERRRPT           PIC  X(02) VALUE SPACE.   01252699
               88  WS-FSMLIERRRPT-OPEN-OK                  VALUE '00'.  01252799
               88  WS-FSMLIERRRPT-READ-EOF                 VALUE '10'.  01252899
           05  WS-FSTATUS-MLIERRSUM           PIC  X(02) VALUE SPACE.   01252999
               88  WS-FSMLIERRSUM-OPEN-OK                  VALUE '00'.  01253099
               88  WS-FSMLIERRSUM-READ-EOF                 VALUE '10'.  01253199
           05  WS-FSTATUS-MLIERRLST           PIC  X(02) VALUE SPACE.   01253299
               88  WS-FSMLIERRLST-OPEN-OK                  VALUE '00'.  01253399
               88  WS-FSMLIERRLST-READ-EOF                 VALUE '10'.  01253499
           05  WS-FSEMPFILE-EXTINFO.                                    01253599
               10  WS-FSEMPFILE-RET-CODE       PIC S9(4) COMP.          01253699
               10  WS-FSEMPFILE-FUNCTION-CODE  PIC S9(4) COMP.          01253799
               10  WS-FSEMPFILE-FEEDBACK-CODE  PIC S9(4) COMP.          01253899
           05  WS-RECORD-TYPE                 PIC  X(01) VALUE SPACE.   01253999
               88  WS-DETAIL-REC                          VALUE 'D'.    01254099
               88  WS-HEADER-REC                          VALUE 'H'.    01255099
               88  WS-TRAILER-REC                         VALUE 'T'.    01256099
                                                                        01257099
       01  ABRT-ERROR-CODE              PIC S9(04) COMP VALUE +0.       01258099
                                                                        01259099
       01  WS-ERROR-RPRT.                                               01260099
           05  WS-ERROR-RPRT-LINE1.                                     01270099
               10  WS-ERROR-LINE1-ASA   PIC X(01) VALUE '1'.            01280099
               10  FILLER               PIC X(10) VALUE 'RUN DATE: '.   01290099
               10  WS-ERROR-LINE1-DATE.                                 01300099
                   15  WS-ERROR-DT-MMM  PIC X(03) VALUE SPACE.          01310099
                   15  WS-ERROR-DT-FIL1 PIC X(01) VALUE SPACE.          01320099
                   15  WS-ERROR-DT-DD   PIC X(02) VALUE SPACE.          01321099
                   15  WS-ERROR-DT-FIL2 PIC X(01) VALUE SPACE.          01322099
                   15  WS-ERROR-DT-YYYY PIC X(04) VALUE SPACE.          01323099
               10  FILLER               PIC X(13) VALUE SPACE.          01324099
               10  WS-ERROR-TITLE       PIC X(33) VALUE                 01325099
                   'GIPSY CRR & EXPCRR ERROR REPORT '.                  01326099
               10  FILLER               PIC X(14) VALUE SPACE.          01327099
               10  FILLER               PIC X(05) VALUE 'PAGE '.        01328099
               10  WS-ERROR-LINE1-PAGE  PIC ZZZZ9.                      01329099
               10  FILLER               PIC X(41) VALUE SPACE.          01330099
           05  WS-ERROR-RPRT-LINE2.                                     01340099
               10  FILLER-ASA           PIC X(01) VALUE ' '.            01341099
               10  FILLER               PIC X(10) VALUE 'PGM NAME: '.   01342099
FXXTOK         10  FILLER               PIC X(08) VALUE 'GC2SEQ'.               
               10  FILLER               PIC X(114) VALUE SPACE.         01344099
           05  WS-ERROR-RPRT-LINE3.                                     01345099
               10  FILLER-ASA           PIC X(01) VALUE ' '.            01346099
               10  FILLER               PIC X(10) VALUE 'REPORT# : '.   01347099
               10  FILLER               PIC X(05) VALUE 'AU-01'.        01348099
               10  FILLER               PIC X(117) VALUE SPACE.         01349099
           05  WS-ERROR-RPRT-LINE5.                                     01349199
               10  FILLER-ASA           PIC X(01) VALUE ' '.            01349299
               10  FILLER               PIC X(02) VALUE SPACE.          01349399
               10  FILLER               PIC X(50) VALUE                 01349499
                   'POLICY HOLDER NAME                                '.01349599
               10  FILLER               PIC X(02) VALUE SPACE.          01349699
               10  FILLER               PIC X(06) VALUE 'POLICY'.       01349799
               10  FILLER               PIC X(02) VALUE SPACE.          01349899
               10  FILLER               PIC X(09) VALUE 'CERT #'.       01349999
               10  FILLER               PIC X(02) VALUE SPACE.          01350099
               10  FILLER               PIC X(08) VALUE 'PATIENT '.     01350199
               10  FILLER               PIC X(02) VALUE SPACE.          01350299
               10  FILLER               PIC X(05) VALUE 'PROC '.        01350399
               10  FILLER               PIC X(02) VALUE SPACE.          01350499
               10  FILLER               PIC X(05) VALUE 'SUB  '.        01350599
               10  FILLER               PIC X(02) VALUE SPACE.          01350699
               10  FILLER               PIC X(30) VALUE                 01350799
               'ERROR MESSAGE                 '.                        01350899
               10  FILLER               PIC X(03) VALUE SPACE.          01350999
           05  WS-ERROR-RPRT-LINE6.                                     01351099
               10  FILLER-ASA           PIC X(01) VALUE ' '.            01351199
               10  FILLER               PIC X(02) VALUE SPACE.          01351299
               10  FILLER               PIC X(50) VALUE SPACE.          01351399
               10  FILLER               PIC X(02) VALUE SPACE.          01351499
               10  FILLER               PIC X(06) VALUE 'NUMBER'.       01351599
               10  FILLER               PIC X(02) VALUE SPACE.          01351699
               10  FILLER               PIC X(09) VALUE SPACE.          01351799
               10  FILLER               PIC X(02) VALUE SPACE.          01351899
               10  FILLER               PIC X(08) VALUE 'DOB     '.     01351999
               10  FILLER               PIC X(02) VALUE SPACE.          01352099
               10  FILLER               PIC X(05) VALUE 'CODE '.        01352199
               10  FILLER               PIC X(02) VALUE SPACE.          01352299
               10  FILLER               PIC X(05) VALUE 'CODE '.        01352399
               10  FILLER               PIC X(02) VALUE SPACE.          01352499
               10  FILLER               PIC X(30) VALUE SPACE.          01352599
               10  FILLER               PIC X(03) VALUE SPACE.          01352699
           05  WS-ERROR-RPRT-LINE7.                                     01352799
               10  FILLER-ASA           PIC X(01) VALUE '0'.            01352899
               10  FILLER               PIC X(02) VALUE SPACE.          01352999
               10  WS-ERROR-POL-NAME    PIC X(50) VALUE SPACE.          01353099
               10  FILLER               PIC X(02) VALUE SPACE.          01353199
               10  WS-ERROR-POL-NUM     PIC X(06) VALUE SPACE.          01353299
               10  FILLER               PIC X(02) VALUE SPACE.          01353399
               10  WS-ERROR-CERT-NUM    PIC X(09) VALUE SPACE.          01353499
               10  FILLER               PIC X(02) VALUE SPACE.          01353599
               10  WS-ERROR-PATIENT-DOB PIC X(08) VALUE SPACE.          01353699
               10  FILLER               PIC X(02) VALUE SPACE.          01353799
               10  WS-ERROR-PROC-CODE   PIC X(05) VALUE SPACE.          01353899
               10  FILLER               PIC X(02) VALUE SPACE.          01353999
               10  WS-ERROR-SUB-CODE    PIC X(05) VALUE SPACE.          01354099
               10  FILLER               PIC X(02) VALUE SPACE.          01355099
               10  WS-ERROR-MESSAGE     PIC X(30) VALUE SPACE.          01355199
               10  FILLER               PIC X(03) VALUE SPACE.          01355299
           05  WS-ERROR-RPRT-SUM-LINE1.                                 01355399
               10  FILLER                 PIC  X(01) VALUE '0'.         01355499
               10  FILLER                 PIC  X(24) VALUE SPACE.       01355599
               10  FILLER                 PIC  X(25) VALUE              01355699
                   'DETAIL RECORDS READ      '.                         01355799
               10  FILLER                 PIC  X(01) VALUE SPACE.       01355899
               10  FILLER                 PIC  X(02) VALUE ': '.        01355999
               10  WS-SUM-RCRDS-READ      PIC  ZZZ,ZZZ,ZZ9.             01356099
               10  FILLER                 PIC  X(26) VALUE SPACE.       01356199
               10  FILLER                 PIC  X(23) VALUE SPACE.       01356299
           05  WS-ERROR-RPRT-SUM-LINE2.                                 01356399
               10  FILLER                 PIC  X(01) VALUE '0'.         01356499
               10  FILLER                 PIC  X(24) VALUE SPACE.       01356599
               10  FILLER                 PIC  X(25) VALUE              01356699
                   'DETAIL RECORDS WRITTEN   '.                         01356799
               10  FILLER                 PIC  X(01) VALUE SPACE.       01356899
               10  FILLER                 PIC  X(02) VALUE ': '.        01356999
               10  WS-SUM-RCRDS-WRTTN     PIC  ZZZ,ZZZ,ZZ9.             01357099
               10  FILLER                 PIC  X(26) VALUE SPACE.       01358099
               10  FILLER                 PIC  X(23) VALUE SPACE.       01359099
           05  WS-ERROR-RPRT-SUM-LINE3.                                 01359199
               10  FILLER                 PIC  X(01) VALUE '0'.         01359299
               10  FILLER                 PIC  X(24) VALUE SPACE.       01359399
               10  FILLER                 PIC  X(25) VALUE              01359499
                   'ERROR RECORDS WRITTEN    '.                         01359599
               10  FILLER                 PIC  X(01) VALUE SPACE.       01359699
               10  FILLER                 PIC  X(02) VALUE ': '.        01359799
               10  WS-SUM-RCRDS-ERR-WRTTN PIC   ZZZ,ZZZ,ZZ9.            01359899
               10  FILLER                 PIC  X(26) VALUE SPACE.       01359999
               10  FILLER                 PIC  X(23) VALUE SPACE.       01360099
           05  WS-ERROR-RPRT-SUM-LINE4.                                 01360199
               10  FILLER                 PIC  X(01) VALUE '0'.         01360299
               10  FILLER                 PIC  X(24) VALUE SPACE.       01360399
               10  FILLER                 PIC  X(25) VALUE              01360499
                   'BALANCE CONTROL          '.                         01360599
               10  FILLER                 PIC  X(01) VALUE SPACE.       01360699
               10  FILLER                 PIC  X(02) VALUE ': '.        01360799
               10  WS-SUM-RCRDS-BALANCE   PIC  ZZZ,ZZZ,ZZ9.             01360899
               10  FILLER                 PIC  X(26) VALUE SPACE.       01360999
               10  FILLER                 PIC  X(23) VALUE SPACE.       01361099
           05  WS-ERROR-RPRT-SUM-LINE5.                                 01361199
               10  FILLER                 PIC  X(01) VALUE '0'.         01361299
               10  FILLER                 PIC  X(24) VALUE SPACE.       01361399
               10  FILLER                 PIC  X(25) VALUE              01361499
                   'BATCHES WRITTEN          '.                         01361599
               10  FILLER                 PIC  X(01) VALUE SPACE.       01361699
               10  FILLER                 PIC  X(02) VALUE ': '.        01361799
               10  WS-SUM-RCRDS-BTCH      PIC  ZZZ,ZZZ,ZZ9.             01361899
               10  FILLER                 PIC  X(26) VALUE SPACE.       01361999
               10  FILLER                 PIC  X(23) VALUE SPACE.       01362099
                                                                        01370999
       01  WS-COUNTERS.                                                 01371099
           05  WS-MATCH-CNT             PIC 9(08) VALUE 0.              01371199
           05  WS-COMFILE-CNT           PIC 9(08) VALUE 0.              01371299
           05  WS-OUTCOM1-CNT           PIC 9(08) VALUE 0.              01371299
           05  WS-OUTCOM2-CNT           PIC 9(08) VALUE 0.              01371299
           05  WS-TRAILER-IN-A.                                         01371399
               10  WS-TRAILER-CNT-A     PIC X(09).                      01371499
           05  WS-TRAILER-IN-N REDEFINES WS-TRAILER-IN-A.               01371599
               10  WS-TRAILER-CNT-N     PIC 9(09).                      01371699
           05  WS-CSV-D-CNT             PIC 9(09) VALUE 0.              01371799
           05  WS-BALANCE-CNT           PIC 9(08) VALUE 0.              01371899
           05  WS-PARMFILE-CNT          PIC 9(08) VALUE 0.              01371999
           05  WS-DINFILE-CNT           PIC 9(08) VALUE 0.              01372099
           05  WS-SKIP-CNT              PIC 9(08) VALUE 0.              01372199
           05  WS-SKIP-D-CNT            PIC 9(09) VALUE 0.              01372299
           05  WS-MLIFILE-CNT           PIC 9(08) VALUE 0.              01372399
           05  WS-MLIERRFL-CNT          PIC 9(08) VALUE 0.              01372499
           05  WS-MLIERRRPT-CNT         PIC 9(08) VALUE 0.              01372599
           05  WS-HEADER-CNT            PIC 9(08) VALUE 0.              01372699
           05  WS-TRAILER-CNT           PIC 9(08) VALUE 0.              01372799
           05  WS-SEQUENCE-NO           PIC 9(08) VALUE 0.              01372799
                                                                        01372899
       01  WS-TOTALS.                                                   01372999
           05  WS-DETAIL-REC-TOT          PIC 9(6)      VALUE 0.        01373099
           05  WS-CHARGED-AMT-TOT         PIC 9(10)V99  VALUE 0.        01373199
           05  WS-ELIGIBLE-AMT-TOT        PIC 9(10)V99  VALUE 0.        01373299
           05  WS-REIMBURSE-AMT-TOT       PIC 9(10)V99  VALUE 0.        01373399
           05  WS-DEDUCTIBLE-AMT-TOT      PIC 9(10)V99  VALUE 0.        01373499
           05  WS-ALL-AMOUNTS-TOT         PIC 9(10)V99  VALUE 0.        01373599
                                                                        01373699
       01  WS-BTCH-TOTALS.                                              01373799
           05  WS-BTCH-DETAIL-REC-TOT     PIC 9(6)      VALUE 0.        01373899
           05  WS-BTCH-CHARGED-AMT-TOT    PIC 9(10)V99  VALUE 0.        01373999
           05  WS-BTCH-ELIGIBLE-AMT-TOT   PIC 9(10)V99  VALUE 0.        01374099
           05  WS-BTCH-REIMBURSE-AMT-TOT  PIC 9(10)V99  VALUE 0.        01375099
           05  WS-BTCH-DEDUCTIBLE-AMT-TOT PIC 9(10)V99  VALUE 0.        01376099
           05  WS-BTCH-ALL-AMOUNTS-TOT    PIC 9(10)V99  VALUE 0.        01377099
                                                                        01378099
       01  WS-WORK-AREA.                                                01420099
           05  WS-BATCH-CNT             PIC 9(2) VALUE ZEROES.          01430099
           05  WS-REPORT-LINE-CNT       PIC S9(05) COMP-3 VALUE +999.   01440099
           05  WS-REPORT-SUM-CNT        PIC S9(05) COMP-3 VALUE +999.   01450099
           05  WS-REPORT-LST-CNT        PIC S9(05) COMP-3 VALUE +0.     01460099
           05  WS-ACTIVITY-PAGE-CNT     PIC S9(05) COMP-3 VALUE +0.     01470099
           05  WS-SUMMARY-PAGE-CNT      PIC S9(05) COMP-3 VALUE +0.     01480099
           05  WS-ERR-LST-PAGE-CNT      PIC S9(05) COMP-3 VALUE +0.     01490099
           05  WS-ERROR-MESSAGE-H       PIC X(25).                      01500099
           05  WS-ERROR-CNT             PIC S9(04) COMP-3 VALUE +0.     01510099
           05  WS-ERROR-CNT2            PIC S9(04) COMP-3 VALUE +0.     01520099
                                                                        01530099
       01  WS-SWITCHES.                                                 01540099
           05  WS-EOF-SW                PIC X(1) VALUE SPACE.           01550099
               88  WS-EOF-YES                    VALUE 'Y'.             01560099
               88  WS-EOF-NO                     VALUE 'N'.             01570099
           05  WS-ABORT-SW              PIC X(1) VALUE SPACE.           01571099
               88  WS-ABORT-YES                  VALUE 'Y'.             01572099
               88  WS-ABORT-NO                   VALUE 'N'.             01573099
           05  WS-CODE342-IND           PIC X(1) VALUE SPACE.           01574099
               88  WS-CODE342-FOUND              VALUE 'Y'.             01575099
               88  WS-CODE342-NOT-FOUND          VALUE 'N'.             01576099
           05  WS-FIRST-REC-IND         PIC X(1) VALUE SPACE.           01574099
               88  WS-FIRST-REC                  VALUE 'Y'.             01575099
               88  WS-NOT-FIRST-REC              VALUE 'N'.             01576099
           05  WS-MEM-FOUND-SW          PIC X(1) VALUE SPACE.           01577099
               88  WS-MEM-FOUND                  VALUE 'Y'.             01578099
               88  WS-MEM-NOT-FOUND              VALUE 'N'.             01579099
           05  WS-HDR-FOUND-SW          PIC X(1) VALUE SPACE.           01580099
               88  WS-HDR-FOUND                  VALUE 'Y'.             01590099
               88  WS-HDR-NOT-FOUND              VALUE 'N'.             01600099
           05  WS-TLR-FOUND-SW          PIC X(1) VALUE SPACE.           01610099
               88  WS-TLR-FOUND                  VALUE 'Y'.             01620099
               88  WS-TLR-NOT-FOUND              VALUE 'N'.             01630099
           05  WS-COM-WRITE-SW          PIC X(1) VALUE SPACE.           01640099
               88  WS-COM-WRITE                  VALUE 'Y'.             01650099
               88  WS-COM-BYPASS-WRITE           VALUE 'N'.             01660099
           05  WS-COM-WRITE-RPT         PIC X(1) VALUE SPACE.           01661099
               88  WS-ERR-RPT-IND                VALUE 'E'.             01662099
               88  WS-SUM-RPT-IND                VALUE 'S'.             01663099
               88  WS-LST-RPT-IND                VALUE 'L'.             01664099
                                                                        01665099
      *----------------------------------------------------------------*01990099
      *    DATA SERVER ACTION VERBS                                     02000099
      *----------------------------------------------------------------*02010099
       01  GAEDATSR                       PIC X(08) VALUE 'GAEDATSR'.   02020099
       01  WS-GAEDATSR-VERB               PIC X(16).                    02030099
                                                                        02040099
       01  GAEDATSR-PARMS.                                              02050099
                                      COPY GARDSVRB.                    02050099
                                                                        02060099
      *---------------------------------------------------------------- 02070099
      * LOGICAL RECORD NAMES - INPUT                                    02080099
      *---------------------------------------------------------------- 02090099
      * INPUT PARAMETER    - 80 BYTE CARD IMAGE                         02100099
       01  CARD-DATA-010         VALUE 'CARD-DATA-010   ' PIC X(16).    02110099
      * INPUT PARAMETER    - 80 BYTE CARD IMAGE                         02120099
       01  CARD-DATA-011         VALUE 'CARD-DATA-011   ' PIC X(50).    02130099
      * INPUT PARAMETER    - 80 BYTE CARD IMAGE                         02140099
       01  CARD-DATA-012         VALUE 'CARD-DATA-012   ' PIC X(80).    02150099
       01  WS-PARAMETER-CARDS.                                          02160099
           05  PARM-COMM-SEQ.                                           02170099
               10  PARM-COMM-SEQ-CNTRL PIC  X(08).                          0217
               10  FILLER              PIC  X(01).                          0217
               10  PARM-COMM-SEQ-NUMBR PIC  X(07).                          0217
               10  FILLER              PIC  X(72).                          0217
      *----------------------------------------------------------------*02252499
      *    INTERFACE CONTROL BLOCK                                      02252599
      *----------------------------------------------------------------*02252699
       01  ICBM.                                                        02252799
                                      COPY ICBM.                        02252799
                                                                        02252899
      *----------------------------------------------------------------*02252999
      *    LOGICAL RECORD NAMES                                         02253099
      *----------------------------------------------------------------*02254099
       01  LOGICAL-RECORD-NAMES.                                        02255099
                                      COPY HCSLRNAM.                    02255099
                                                                        02256099
      *---------------------------------------------------------------- 02257099
      * DATE ROUTINE (GC2TODAY) PARAMETER                               02258099
      *---------------------------------------------------------------- 02259099
                                                                        02260099
       01  GC2DATE                       PIC X(08) VALUE 'GC2DATE'.     02270099
                                                                        02280099
       01  GACDATE-PARMS.                                               02290099
           COPY GARDATEP.                                               02300099
                                                                        02310099
      *============================================================     02320099
       PROCEDURE DIVISION.                                              02330099
      *============================================================     02340099
      *------------------------------------------------------------     02350099
       0000-MAINLINE SECTION.                                           02360099
      *------------------------------------------------------------     02370099
                                                                        02380099
           DISPLAY 'STARTING'                                                   
      *    MOVE 'GC2SEQ'           TO ICBM-PROGRAM-NAME.                        
                                                                                
           PERFORM 1000-OPEN-FILES                                      02390099
              THRU 1000-OPEN-FILES-X                                    02400099
           DISPLAY 'AFTER OPEN'                                                 
                                                                        02410099
           PERFORM 2000-INITIALIZE                                      02420099
              THRU 2000-INITIALIZE-X                                    02430099
           DISPLAY 'AFTER INIT'                                                 
                                                                        02440099
           MOVE PARM-COMM-SEQ-NUMBR TO WS-SEQUENCE-NO                           
           PERFORM 3000-CREATE-DETAIL-RECORD                            02480099
              THRU 3000-CREATE-DETAIL-RECORD-X                          02490099
                   UNTIL WS-FSCOMFILE-READ-EOF                          02500099
           DISPLAY 'AFTER DETAIL'                                               
                                                                        02510099
           PERFORM 3100-WRITE-DETAIL-RECORD                             0099    
              THRU 3100-WRITE-DETAIL-RECORD-X.                          0099    
           DISPLAY 'AFTER FDETAIL'                                              
                                                                        02580099
           PERFORM 5000-CREATE-AUDIT-TRAIL                              02620099
              THRU 5000-CREATE-AUDIT-TRAIL-X.                           02630099
           DISPLAY 'AFTER AUDIT  '                                              
                                                                        02640099
           PERFORM 9999-CLOSE-FILES                                     02674099
              THRU 9999-CLOSE-FILES-X.                                  02675099
                                                                        02676099
           GOBACK.                                                      02677099
                                                                        02678099
       0000-MAINLINE-X.                                                 02679099
           EXIT.                                                        02680099
                                                                        02690099
      *------------------------------------------------------------     02700099
       1000-OPEN-FILES.                                                 02710099
      *------------------------------------------------------------     02720099
                                                                        02730099
           OPEN INPUT  COM-FILE-IN                                      02740099
                OUTPUT COM-FILE1-OUT                                    02770099
                OUTPUT COM-FILE2-OUT                                    02780099
                OUTPUT COM-ERROR-RPRT-OUT.                              02890999
                                                                        02894099
       1000-OPEN-FILES-X.                                               02895099
           EXIT.                                                        02896099
                                                                        02897099
      *------------------------------------------------------------     02984999
       2000-INITIALIZE.                                                 02985099
      *------------------------------------------------------------     02985199
      *                                                                 02985299
           INITIALIZE                                                   02985399
                         WS-CODE342-DATA                                        
                         WS-C-OLD342-DATA                                       
                         WS-COMFILE-CNT                                 02985499
                         WS-OUTCOM1-CNT                                 02985499
                         WS-OUTCOM2-CNT                                 02985499
                         WS-CSV-D-CNT                                   02985599
                         WS-PARMFILE-CNT                                02985699
                         WS-DINFILE-CNT                                 02985799
                         WS-SKIP-CNT                                    02985899
                         WS-SKIP-D-CNT                                  02985999
                         WS-MLIFILE-CNT                                 02986099
                         WS-MLIERRFL-CNT                                02986199
                         WS-MLIERRRPT-CNT                               02986299
                         WS-HEADER-CNT                                  02986399
                         WS-TRAILER-CNT                                 02986499
                         WS-RECORD-TYPE                                 02986599
                         WS-DETAIL-REC-TOT                              02986699
                         WS-ELIGIBLE-AMT-TOT                            02986799
                         WS-REIMBURSE-AMT-TOT                           02986899
                         WS-DEDUCTIBLE-AMT-TOT                          02986999
                         WS-ALL-AMOUNTS-TOT                             02987099
                         WS-BTCH-DETAIL-REC-TOT                         02988099
                         WS-BTCH-ELIGIBLE-AMT-TOT                       02989099
                         WS-BTCH-REIMBURSE-AMT-TOT                      02990099
                         WS-BTCH-DEDUCTIBLE-AMT-TOT                     03000099
                         WS-BTCH-ALL-AMOUNTS-TOT                        03010099
                         WS-BATCH-CNT                                   03020099
                         ERROR-STORE-REC                                03030099
                                                                        03040099
           SET LR-STATUS-OK             TO TRUE                         03050099
           SET WS-HDR-NOT-FOUND         TO TRUE                         03060099
           SET WS-TLR-NOT-FOUND         TO TRUE                         03070099
           SET WS-EOF-NO                TO TRUE                         03090099
                                                                        03100099
FXXTOK     MOVE 'GC2SEQ'           TO ICBM-PROGRAM-NAME                         
                                                                        03120099
      *    ----------------------------------------------------         03121099
      *    CALL  GC2DATE  FOR TODAY'S DATE ****                         03121199
      *    ----------------------------------------------------         03121299
                                                                        03121399
           MOVE 'E'                  TO VDATE-REQ-SERVICE               03121499
           MOVE 'A'                  TO VDATE-REQ-BASIS                 03121599
           MOVE '1'                  TO VDATE-REQ-DETAIL                03121699
           MOVE 'E'                  TO VDATE-REQ-LANGUAGE              03121799
                                                                        03121899
           CALL GC2DATE USING GACDATE-PARMS                             03121999
           END-CALL                                                     03122099
                                                                        03123099
           IF VDATE-RET-FAIL                                            03124099
                 DISPLAY '**FAILED TO GET THE DATE FROM GC2DATE'        03125099
                         'RETURN CODE :', VDATE-RET-CODE                03126099
                 MOVE 03   TO WS-COMP-CODE                              03127099
                 PERFORM 9999-ABEND                                     03128099
                    THRU 9999-ABEND-EXIT                                03129099
                                                                        03130099
           ELSE                                                         03140099
                 MOVE VDATE1-YYYYMMDD TO WS-EXTRACT-DATE                03150099
                 MOVE WS-EXTRACT-DATE-YYYY TO WS-ERROR-DT-YYYY          03160099
                 MOVE WS-EXTRACT-DATE-DD   TO WS-ERROR-DT-DD            03160199
                 EVALUATE WS-EXTRACT-DATE-MM                            03160299
                     WHEN '01'                                          03160399
                               MOVE 'JAN'  TO WS-ERROR-DT-MMM           03160399
                     WHEN '02'                                          03160499
                               MOVE 'FEB'  TO WS-ERROR-DT-MMM           03160499
                     WHEN '03'                                          03160599
                               MOVE 'MAR'  TO WS-ERROR-DT-MMM           03160599
                     WHEN '04'                                          03160699
                               MOVE 'APR'  TO WS-ERROR-DT-MMM           03160699
                     WHEN '05'                                          03160799
                               MOVE 'MAY'  TO WS-ERROR-DT-MMM           03160799
                     WHEN '06'                                          03160899
                               MOVE 'JUN'  TO WS-ERROR-DT-MMM           03160899
                     WHEN '07'                                          03160999
                               MOVE 'JUL'  TO WS-ERROR-DT-MMM           03160999
                     WHEN '08'                                          03161099
                               MOVE 'AUG'  TO WS-ERROR-DT-MMM           03161099
                     WHEN '09'                                          03161199
                               MOVE 'SEP'  TO WS-ERROR-DT-MMM           03161199
                     WHEN '10'                                          03161299
                               MOVE 'OCT'  TO WS-ERROR-DT-MMM           03161299
                     WHEN '11'                                          03161399
                               MOVE 'NOV'  TO WS-ERROR-DT-MMM           03161399
                     WHEN '12'                                          03161499
                               MOVE 'DEC'  TO WS-ERROR-DT-MMM           03161499
                 END-EVALUATE                                           03161599
           END-IF                                                       03161699
                                                                        03161799
      *-----------------------------------------------------------------03161899
      *    READ THE INPUT PARM VALUE TO DETERMINE START SEQUENCE NUM    03161999
      *-----------------------------------------------------------------03162099
           MOVE CARD-DATA-010      TO LOGICAL-RECORD-NAME               03163099
           MOVE OBTAIN-FIRST       TO WS-GAEDATSR-VERB                  03164099
           CALL GAEDATSR USING     WS-GAEDATSR-VERB                     03165099
                                   PARM-COMM-SEQ                        03166099
                                   ICBM                                 03167099
           END-CALL                                                     03168099
                                                                                
           IF LR-STATUS-OK                                              03169099
               DISPLAY 'COMM START SEQUENCE NUMBER : ' PARM-COMM-SEQ    03170099
           ELSE                                                         03180099
               DISPLAY 'GAEDATSR READ ERROR - PARM CONTRACT MISSING'    03190099
               DISPLAY '** END OF JOB **'                               03200099
               MOVE 04   TO WS-COMP-CODE                                03210099
               PERFORM 9999-ABEND                                       03220099
                  THRU 9999-ABEND-EXIT                                  03230099
           END-IF                                                       03240099
      *-----------------------------------------------------------------03620099
      *  PARM CONTRACT MUST BE NUMERIC                                  03630099
      *-----------------------------------------------------------------03640099
                                                                        03650099
           INSPECT PARM-COMM-SEQ-NUMBR                                  03660099
                   REPLACING LEADING SPACES                             03670099
                   BY        ZEROES                                     03680099
                                                                        03690099
           IF  PARM-COMM-SEQ-NUMBR IS NUMERIC                           03870099
FXXTOK         IF  PARM-COMM-SEQ-CNTRL = 'GC2SEQ'                               
                   CONTINUE                                                     
               ELSE                                                             
                   DISPLAY ' INVALID CNTRL VALUE SHOULD BE "GC2SEQ"'        0391
                   DISPLAY ' *** END OF JOB *** '                           0392
                   MOVE 07   TO WS-COMP-CODE                                0393
                   PERFORM 9999-ABEND                                       0394
                      THRU 9999-ABEND-EXIT                                  0395
               END-IF                                                           
           ELSE                                                         03890099
                                                                        03900099
               DISPLAY ' SEQUENCE NUMBER SHOULD BE NUMERIC! '           03910099
               DISPLAY ' *** END OF JOB *** '                           03920099
               MOVE 07   TO WS-COMP-CODE                                03930099
               PERFORM 9999-ABEND                                       03940099
                  THRU 9999-ABEND-EXIT                                  03950099
                                                                        03960099
           END-IF                                                       03970099
                                                                        03980099
           PERFORM 9000-READ-COMFILE                                    04210099
              THRU 9000-READ-COMFILE-X                                  04220099
                                                                        04230099
           IF WS-FSCOMFILE-READ-EOF                                     04260099
              DISPLAY SPACE                                             04270099
              DISPLAY 'PGM=GC2SEQ    //COMFILE FILE HAS NO RECORDS.'    04280099
           ELSE                                                                 
               SET WS-FIRST-REC TO TRUE                                         
           END-IF.                                                      04290099
                                                                        04300099
           SET WS-ERR-RPT-IND TO TRUE                                   04310099
                                                                        04320099
           ADD   +1                   TO   WS-ACTIVITY-PAGE-CNT.        04330099
           MOVE  WS-ACTIVITY-PAGE-CNT TO   WS-ERROR-LINE1-PAGE.         04340099
                                                                        04350099
           MOVE 'GIPSY CRR & EXPCRR ERROR REPORT '                              
             TO WS-ERROR-TITLE                                          04370099
           PERFORM P-200-PRINT-HEADINGS                                 04380099
              THRU P-200-EXIT.                                          04390099
           MOVE  +7                   TO   WS-REPORT-LINE-CNT.          04400099
                                                                        04410099
           SET WS-SUM-RPT-IND TO TRUE                                   04420099
                                                                        04430099
           ADD   +1                   TO   WS-SUMMARY-PAGE-CNT.         04440099
           MOVE  WS-SUMMARY-PAGE-CNT TO   WS-ERROR-LINE1-PAGE.          04450099
                                                                        04460099
           MOVE 'GIPSY CRR & EXPCRR SUMMARY REPORT'                             
             TO WS-ERROR-TITLE                                          04480099
           PERFORM P-200-PRINT-HEADINGS                                 04481099
              THRU P-200-EXIT.                                          04482099
           MOVE  +7                   TO   WS-REPORT-SUM-CNT.           04483099
                                                                        04484099
       2000-INITIALIZE-X.                                               04487099
           EXIT.                                                        04488099
      *-----------------------------------------------------------------04652799
       3000-CREATE-DETAIL-RECORD.                                       04652899
      *-----------------------------------------------------------------04652999
                                                                        04653099
           DISPLAY 'IN 3000-A'                                                  
           MOVE IN-GCRL-CAUSE                                                   
             TO WS-CAUSE-CODE                                                   
                                                                                
           DISPLAY 'IN 3000-B'                                                  
           DISPLAY 'CAUSE CODE:' WS-CAUSE-CODE                                  
      *    -------------------------------------------------------------05660099
      *    VALUE IS DERIVED FROM THE FIRST 4 DIGIT OF OUT-BCRL-FOGL-CODE05650099
      *    -------------------------------------------------------------05660099
           INITIALIZE WS-FOGL-CODE                                              
                      WS-COVERAGE-TYPE                                          
                      WS-PRODUCT-CODE.                                          
                                                                                
           MOVE IN-GCRL-FOGL-CODE TO WS-FOGL-CODE                               
                                                                                
           EVALUATE WS-FOGL-CODE-1-4                                            
               WHEN 2204                                                        
                         MOVE 'LTD  ' TO WS-COVERAGE-TYPE                       
               WHEN 2207                                                        
                         MOVE 'AS   ' TO WS-COVERAGE-TYPE                       
               WHEN 2314                                                        
                         MOVE 'LIFE ' TO WS-COVERAGE-TYPE                       
           END-EVALUATE.                                                        
                                                                        05670099
      *    -------------------------------------------------------------05660099
      *    VALUE IS DERIVED FROM THE 7TH DIGIT OF OUT-BCRL-FOGL-CODE    05650099
      *    -------------------------------------------------------------05660099
           EVALUATE WS-FOGL-CODE-7                                              
               WHEN 1                                                           
                          MOVE 'ALPHA' TO WS-PRODUCT-CODE                       
               WHEN 4                                                           
                          MOVE 'CORP ' TO WS-PRODUCT-CODE                       
               WHEN OTHER                                                       
                          MOVE 'SIG  ' TO WS-PRODUCT-CODE                       
           END-EVALUATE.                                                        
                                                                                
      *    -------------------------------------------------------------05660099
      *    SPECIAL PROCESSING FOR CAUSE CODE 342 THESE RECORDS ARE      05650099
      *    ROLLED UP FOR THE CRR RECORDS                                05650099
      *    -------------------------------------------------------------05660099
           IF  WS-CAUSE-CODE = 342                                              
               DISPLAY 'IN 3000-C'                                              
               SET WS-CODE342-FOUND TO TRUE                                     
               DISPLAY 'IN 3000-C1'                                             
               EVALUATE WS-FOGL-CODE-7                                          
                   WHEN 1                                                       
                          MOVE 2400000001 TO IN-GCRL-FOGL-CODE                  
                   WHEN 2                                                       
                          MOVE 2400000002 TO IN-GCRL-FOGL-CODE                  
                   WHEN 3                                                       
                          MOVE 2400000003 TO IN-GCRL-FOGL-CODE                  
                   WHEN 4                                                       
                          MOVE 2400000003 TO IN-GCRL-FOGL-CODE                  
                   WHEN 5                                                       
                          MOVE 2400000003 TO IN-GCRL-FOGL-CODE                  
                   WHEN 6                                                       
                          MOVE 2400000003 TO IN-GCRL-FOGL-CODE                  
                   WHEN 7                                                       
                          MOVE 2400000003 TO IN-GCRL-FOGL-CODE                  
               END-EVALUATE                                                     
               DISPLAY 'IN 3000-C2'                                             
                                                                                
               MOVE IN-GCRL-GROUP       TO WS-CODE342-GROUP                     
               MOVE IN-GCRL-SUB-ACCOUNT TO WS-CODE342-SUB-ACCOUNT               
               MOVE IN-GCRL-BRANCH      TO WS-CODE342-BRANCH                    
               MOVE IN-GCRL-FOGL-CODE   TO WS-CODE342-FOGL-CODE                 
               MOVE IN-GCRL-AGENT-CODE  TO WS-CODE342-AGENT-CODE                
               MOVE IN-GCRL-CAUSE       TO WS-CODE342-CAUSE                     
               MOVE IN-GCRL-CODE  (1)   TO WS-CODE342-CODE                      
               DISPLAY 'IN 3000-C3'                                             
               DISPLAY 'GCRL-CRAMT:' IN-GCRL-CRAMT (1)                          
               COMPUTE WS-CODE342-CRAMT                                         
                     = IN-GCRL-CRAMT (1)                                        
                     + WS-CODE342-CRAMT                                         
               DISPLAY 'IN 3000-C4'                                             
           ELSE                                                                 
               SET WS-CODE342-NOT-FOUND TO TRUE                                 
           END-IF.                                                              
                                                                                
           IF WS-NOT-FIRST-REC                                                  
               IF  WS-C-OLD342-KEY NOT = WS-CODE342-KEY                         
               OR  WS-CAUSE-CODE NOT = 342                                      
                   DISPLAY 'IN 3000-D'                                          
                   PERFORM 3100-WRITE-DETAIL-RECORD                             
                      THRU 3100-WRITE-DETAIL-RECORD-X                           
               END-IF                                                       0505
           END-IF                                                       0505    
                                                                                
           MOVE WS-SEQUENCE-NO                                                  
             TO IN-GCRL-MATCH-SEQUENCE-NO                                       
                                                                        04860099
           DISPLAY 'IN 3000-E'                                                  
           PERFORM 3200-CREATE-EXPANDED-RECORD                                  
              THRU 3200-CREATE-EXPANDED-RECORD-X.                               
                                                                                
           MOVE WS-CODE342-CRAMT TO WS-C-OLD342-CRAMT                           
                                                                                
           INITIALIZE OUT-COM-RELEASE-RECORD.                                   
           MOVE IN-COM-RELEASE-RECORD TO OUT-COM-RELEASE-RECORD.                
                                                                                
           MOVE WS-CODE342-KEY TO WS-C-OLD342-KEY                               
                                                                                
           SET WS-NOT-FIRST-REC TO TRUE                                         
                                                                                
           PERFORM 9000-READ-COMFILE                                    05540099
              THRU 9000-READ-COMFILE-X.                                 05550099
                                                                        05470099
       3000-CREATE-DETAIL-RECORD-X.                                     05570099
            EXIT.                                                       05580099
                                                                        05590099
      *------------------------------------------------------------     05600099
       3100-WRITE-DETAIL-RECORD.                                        05480099
      *------------------------------------------------------------     05600099
           DISPLAY 'IN 3100-A'                                                  
           MOVE OUT-GCRL-CAUSE                                                  
             TO WS-CAUSE-CODE                                                   
                                                                                
           MOVE WS-SEQUENCE-NO TO OUT-GCRL-MATCH-SEQUENCE-NO                    
           IF  WS-CAUSE-CODE = 342                                              
               MOVE WS-C-OLD342-CRAMT TO OUT-GCRL-CRAMT (1)                     
           END-IF.                                                              
                                                                                
           INITIALIZE WS-C-OLD342-CRAMT                                         
                      WS-CODE342-CRAMT.                                         
                                                                                
           COMPUTE WS-CODE342-CRAMT                                             
                 = IN-GCRL-CRAMT (1)                                            
                 + WS-CODE342-CRAMT.                                            
                                                                                
           ADD +1 TO WS-OUTCOM1-CNT                                             
                                                                                
           WRITE OUT-GIPSY-DETAIL-REC FROM OUT-COM-RELEASE-RECORD.      0099    
                                                                        05530099
           INITIALIZE WS-C-OLD342-DATA.                                         
      *------------------------------------------------------------     05600099
           COMPUTE WS-SEQUENCE-NO = WS-SEQUENCE-NO + 1.                         
      *------------------------------------------------------------     05600099
                                                                                
       3100-WRITE-DETAIL-RECORD-X.                                      05570099
            EXIT.                                                       05580099
                                                                        05590099
      *------------------------------------------------------------     05600099
       3200-CREATE-EXPANDED-RECORD.                                     05610099
      *------------------------------------------------------------     05620099
           DISPLAY 'IN 3200-A'                                                  
           INITIALIZE OUT-CCOMTRANS-REC.                                        
           MOVE IN-GCOMRLS2       TO CCOMMRELEASE-REC.                  05630099
           MOVE IN-GCRL-ACCT-EFFECTIVE-DATE                                     
             TO AGCCRREX-INSURANCE-BEGINS-DATE                                  
                                                                                
      *    -------------------------------------------------------------05660099
      *    VALUE IS DERIVED FROM THE FIRST 4 DIGIT OF OUT-BCRL-FOGL-CODE05650099
      *    -------------------------------------------------------------05660099
               MOVE WS-COVERAGE-TYPE  TO AGCCRREX-COVERAGE-TYPE                 
                                                                        05670099
      *    -------------------------------------------------------------05660099
      *    VALUE IS DERIVED FROM THE 7TH DIGIT OF OUT-BCRL-FOGL-CODE    05650099
      *    -------------------------------------------------------------05660099
               MOVE WS-PRODUCT-CODE    TO AGCCRREX-PRODUCT-CODE                 
                                                                        05720099
           ADD +1 TO WS-OUTCOM2-CNT                                             
                                                                                
           WRITE OUT-GIPSY-SUMMRY-REC FROM OUT-CCOMTRANS-REC.           0099    
                                                                        06190099
       3200-CREATE-EXPANDED-RECORD-X.                                   06200099
            EXIT.                                                       06210099
                                                                        06220099
      *------------------------------------------------------------     10080099
       5000-CREATE-AUDIT-TRAIL.                                         10090099
      *------------------------------------------------------------     10100099
                                                                        10110099
           DISPLAY 'COMM RECORDS READ TOTAL     - ' WS-COMFILE-CNT      10120099
           DISPLAY ' '.                                                 10130099
                                                                        10140099
           DISPLAY 'CRR         RECORDS WRITTEN - ' WS-OUTCOM1-CNT      10150099
           DISPLAY 'EXPANDED CR RECORDS WRITTEN - ' WS-OUTCOM2-CNT      10160099
           DISPLAY ' '.                                                 10200099
                                                                        10210099
           DISPLAY 'CRR CRAMT TOTAL READ         - '                    10220099
                                    WS-CHARGED-AMT-TOT                  10230099
           DISPLAY 'CRR CRAMT TOTAL WRITTEN      - '                    10240099
                                    WS-ELIGIBLE-AMT-TOT                 10250099
           DISPLAY 'EXPANDED CRAMT  WRITTEN      - '                    10260099
                                    WS-REIMBURSE-AMT-TOT                10270099
                                                                        10300099
           SET WS-ERR-RPT-IND TO TRUE.                                  10310099
           ADD   +1                   TO   WS-ACTIVITY-PAGE-CNT.        10320099
           MOVE  WS-ACTIVITY-PAGE-CNT TO   WS-ERROR-LINE1-PAGE.         10330099
                                                                        10340099
           MOVE 'COMMISSION CRR     ERROR REPORT '                      10350099
             TO WS-ERROR-TITLE                                          10360099
           PERFORM P-200-PRINT-HEADINGS                                 10370099
              THRU P-200-EXIT.                                          10380099
                                                                        10390099
           PERFORM P-300-PRINT-SUMMARY-LINES                            10400099
              THRU P-300-EXIT.                                          10410099
                                                                        10411099
       5000-CREATE-AUDIT-TRAIL-X.                                       10412099
            EXIT.                                                       10413099
                                                                        10414099
      *------------------------------------------------------------     10434399
       9000-READ-COMFILE.                                               10434499
      *------------------------------------------------------------     10434599
                                                                        10434699
           READ COM-FILE-IN                                             10434799
                AT END                                                  10434899
                       MOVE '10' TO  WS-FSTATUS-COMFILE.                10434899
                                                                        10434999
           EVALUATE WS-FSTATUS-COMFILE                                  10435099
              WHEN '00'                                                 10436099
                        PERFORM                                         10436099
                            COMPUTE WS-COMFILE-CNT = WS-COMFILE-CNT + 1 10437099
                        END-PERFORM                                     10440099
                        MOVE IN-GIPSY-COMMSSN-REC                               
                          TO IN-COM-RELEASE-RECORD                              
              WHEN '04'                                                 10450099
                        PERFORM                                         10450099
                            COMPUTE WS-COMFILE-CNT = WS-COMFILE-CNT + 1 10460099
                        END-PERFORM                                     10490099
                        MOVE IN-GIPSY-COMMSSN-REC                               
                          TO IN-COM-RELEASE-RECORD                              
              WHEN '10'                                                 10500099
                        CONTINUE                                        10500099
              WHEN OTHER                                                10510099
                     DISPLAY '++ READ //COMFILE ERROR, FILE STATUS = '  10520099
                            WS-FSTATUS-COMFILE                          10530099
                     DISPLAY SPACE                                      10540099
                     DISPLAY '++ ERROR FILE //COMFILE, RETURN   CODE = '10550099
                            WS-FSEMPFILE-RET-CODE                       10560099
                     DISPLAY SPACE                                      10570099
                     DISPLAY '++ ERROR FILE //COMFILE, FUNCTION CODE = '10580099
                            WS-FSEMPFILE-FUNCTION-CODE                  10590099
                     DISPLAY SPACE                                      10600099
                     DISPLAY '++ ERROR FILE //COMFILE, FEEDBACK CODE = '10610099
                            WS-FSEMPFILE-FEEDBACK-CODE                  10620099
                     MOVE '10' TO  WS-FSTATUS-COMFILE                   10630099
           END-EVALUATE.                                                10640099
                                                                        10650099
       9000-READ-COMFILE-X.                                             10660099
           EXIT.                                                        10670099
                                                                        10680099
      *------------------------------------------------------------     13427299
       9300-WRITE-MLI-ERR-RPRT-OUT.                                     13427399
      *------------------------------------------------------------     13427499
           SET WS-ERR-RPT-IND TO TRUE                                   13427599
                                                                        13427699
           IF  WS-REPORT-LINE-CNT GREATER 60                            13427799
               MOVE 'GIPSY CRR & EXPCRR ERROR REPORT '                          
                 TO WS-ERROR-TITLE                                      13427999
               ADD   +1                   TO WS-ACTIVITY-PAGE-CNT       13428099
               MOVE  WS-ACTIVITY-PAGE-CNT TO WS-ERROR-LINE1-PAGE        13429099
               PERFORM P-200-PRINT-HEADINGS                             13430099
               MOVE  +7  TO   WS-REPORT-LINE-CNT                        13431099
           END-IF.                                                      13431199
           ADD +1 TO WS-MLIERRRPT-CNT.                                  13431299
      *    MOVE CSV-POLICY-NAME      TO WS-ERROR-POL-NAME               13431399
      *    MOVE CSV-POLICY-NUMBER    TO WS-ERROR-POL-NUM                13431499
      *    MOVE CSV-CERT-NUMBER      TO WS-ERROR-CERT-NUM               13431599
      *    MOVE CSV-CLAIMANT-DOB     TO WS-ERROR-PATIENT-DOB            13431699
      *    MOVE CSV-SERVICE-CODE     TO WS-ERROR-PROC-CODE              13431799
      *    MOVE CSV-SERVICE-SUB-CODE TO WS-ERROR-SUB-CODE               13431899
           MOVE WS-ERROR-MESSAGE-H   TO WS-ERROR-MESSAGE                13431999
           MOVE WS-ERROR-RPRT-LINE7 TO ERROR-RPRT-A.                    13432099
                                                                        13432199
           PERFORM W-100-WRITE-OREPORT.                                 13432299
                                                                        13432399
           ADD   2 TO WS-REPORT-LINE-CNT.                               13432499
                                                                        13432599
       9300-WRITE-MLI-ERR-RPRT-OUT-X.                                   13433899
            EXIT.                                                       13433999
                                                                        13434099
       W-100-WRITE-OREPORT SECTION.                                     13448199
           MOVE ERROR-RPRT-LINE-A TO ERROR-RPRT-LINE.                   13448299
           EVALUATE ERROR-RPRT-CTL                                      13448399
               WHEN '+'                                                 13448499
                   WRITE ERROR-RPRT AFTER 0 LINE                        13448599
               WHEN ' '                                                 13448699
                   WRITE ERROR-RPRT AFTER ADVANCING 1 LINE              13448799
               WHEN '0'                                                 13448899
                   WRITE ERROR-RPRT AFTER ADVANCING 2 LINE              13448999
               WHEN '-'                                                 13449099
                   WRITE ERROR-RPRT AFTER ADVANCING 3 LINE              13449199
               WHEN '1'                                                 13449299
                   WRITE ERROR-RPRT AFTER ADVANCING PAGE                13449399
               WHEN '2'                                                 13449499
                   WRITE ERROR-RPRT AFTER ADVANCING CH2                 13449599
               WHEN '3'                                                 13449699
                   WRITE ERROR-RPRT AFTER ADVANCING CH3                 13449799
               WHEN '4'                                                 13449899
                   WRITE ERROR-RPRT AFTER ADVANCING CH4                 13449999
               WHEN '5'                                                 13450099
                   WRITE ERROR-RPRT AFTER ADVANCING CH5                 13450199
               WHEN '6'                                                 13450299
                   WRITE ERROR-RPRT AFTER ADVANCING CH6                 13450399
               WHEN '7'                                                 13450499
                   WRITE ERROR-RPRT AFTER ADVANCING CH7                 13450599
               WHEN '8'                                                 13450699
                   WRITE ERROR-RPRT AFTER ADVANCING CH8                 13450799
               WHEN '9'                                                 13450899
                   WRITE ERROR-RPRT AFTER ADVANCING CH9                 13450999
               WHEN 'A'                                                 13451099
                   WRITE ERROR-RPRT AFTER ADVANCING CH10                13451199
               WHEN 'B'                                                 13451299
                   WRITE ERROR-RPRT AFTER ADVANCING CH11                13451399
               WHEN 'C'                                                 13451499
                   WRITE ERROR-RPRT AFTER ADVANCING CH12                13451599
               WHEN 'V'                                                 13451699
                   WRITE ERROR-RPRT AFTER ADVANCING P01                 13451799
               WHEN 'W'                                                 13451899
                   WRITE ERROR-RPRT AFTER ADVANCING P02                 13451999
               WHEN OTHER                                               13452099
                   DISPLAY 'ASA CODE ERROR'                             13452199
           END-EVALUATE.                                                13452299
                                                                        13452399
       W-100-EXIT.                                                      13452499
           EXIT.                                                        13452599
      *                                                                 13452699
       P-200-PRINT-HEADINGS SECTION.                                    13461999
      ***************************************************************   13462099
      * PRINT PAGE HEADINGS                                         *   13462199
      ***************************************************************   13462299
                                                                        13462399
           INITIALIZE ERROR-RPRT-A.                                     13462499
                                                                        13462599
           IF  WS-ERR-RPT-IND                                           13462699
               MOVE WS-ERROR-RPRT-LINE1 TO ERROR-RPRT-A                 13462799
               PERFORM W-100-WRITE-OREPORT                              13462899
               MOVE WS-ERROR-RPRT-LINE2 TO ERROR-RPRT-A                 13462999
               PERFORM W-100-WRITE-OREPORT                              13463099
               MOVE WS-ERROR-RPRT-LINE3 TO ERROR-RPRT-A                 13463199
               PERFORM W-100-WRITE-OREPORT                              13463299
               MOVE WS-ERROR-RPRT-LINE5 TO ERROR-RPRT-A                 13463399
               PERFORM W-100-WRITE-OREPORT                              13463499
               MOVE WS-ERROR-RPRT-LINE6 TO ERROR-RPRT-A                 13463599
               PERFORM W-100-WRITE-OREPORT                              13463699
           END-IF.                                                      13463799
                                                                        13466899
       P-200-EXIT.                                                      13466999
           EXIT.                                                        13467099
                                                                        13467199
       P-300-PRINT-SUMMARY-LINES    SECTION.                            13467299
      ***************************************************************   13467399
      * PRINT THE SUMMARY LINES ON THE ACTIVITY REPORT              *   13467499
      ***************************************************************   13467599
                                                                        13467699
           MOVE  WS-COMFILE-CNT  TO WS-SUM-RCRDS-READ.                  13467799
           MOVE  WS-MLIFILE-CNT  TO WS-SUM-RCRDS-WRTTN.                 13467899
           MOVE  WS-MLIERRFL-CNT TO WS-SUM-RCRDS-ERR-WRTTN.             13467999
                                                                        13468099
           COMPUTE WS-BALANCE-CNT = WS-COMFILE-CNT                      13468199
                                  - WS-MLIFILE-CNT                      13468299
                                  - WS-MLIERRFL-CNT                     13468399
           MOVE  WS-BALANCE-CNT  TO WS-SUM-RCRDS-BALANCE.               13468499
           MOVE  WS-BATCH-CNT    TO WS-SUM-RCRDS-BTCH.                  13468599
                                                                        13468699
           MOVE SPACE                TO ERROR-RPRT-A.                   13468799
           PERFORM W-100-WRITE-OREPORT.                                 13468899
                                                                        13468999
           MOVE WS-ERROR-RPRT-SUM-LINE1 TO ERROR-RPRT-A.                13469099
           PERFORM W-100-WRITE-OREPORT.                                 13469199
                                                                        13469299
           MOVE WS-ERROR-RPRT-SUM-LINE2 TO ERROR-RPRT-A.                13469399
           PERFORM W-100-WRITE-OREPORT.                                 13469499
                                                                        13469599
           MOVE WS-ERROR-RPRT-SUM-LINE3 TO ERROR-RPRT-A.                13469699
           PERFORM W-100-WRITE-OREPORT.                                 13469799
                                                                        13469899
           MOVE WS-ERROR-RPRT-SUM-LINE4 TO ERROR-RPRT-A.                13469999
           PERFORM W-100-WRITE-OREPORT.                                 13470099
                                                                        13470199
           MOVE WS-ERROR-RPRT-SUM-LINE5 TO ERROR-RPRT-A.                13470299
           PERFORM W-100-WRITE-OREPORT.                                 13470399
                                                                        13470499
       P-300-EXIT.                                                      13470599
           EXIT.                                                        13470699
      *                                                                 13470799
      *------------------------------------------------------------     13482299
       9999-CLOSE-FILES.                                                13482399
      *------------------------------------------------------------     13482499
                                                                        13482599
           CLOSE      COM-FILE-IN                                       13482699
                      COM-FILE1-OUT                                     13482699
                      COM-FILE2-OUT                                     13482699
                      COM-ERROR-RPRT-OUT.                               13482999
                                                                        13496099
       9999-CLOSE-FILES-X.                                              13496199
           EXIT.                                                        13496299
      *                                                                 13496399
       9999-ABEND.                                                      13496499
                                                                        13496599
      *    ------------------------------------------------------------ 13496699
      *    ABEND THE JOB - DISPLAY RETURN CODE IN WRK-COMP-CODE         13496799
      *    ------------------------------------------------------------ 13496899
                                                                        13496999
           CALL 'ILBOABN0'    USING  WS-COMP-CODE                               
           END-CALL.                                                    13498099
                                                                        13499099
       9999-ABEND-EXIT.                                                 13500099
           EXIT.                                                        13510099
