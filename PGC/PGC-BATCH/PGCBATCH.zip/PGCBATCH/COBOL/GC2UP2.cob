       IDENTIFICATION DIVISION.                                                 
FXXTOK PROGRAM-ID.   GC2UP2.                                                    
      *%****************************************************************        
      *%  DATE 12/23/10                                                *        
      *%                                                               *        
      *%  CONVERTED USING FORECROSS CORPORATION REDEPLOYMENT SOFTWARE  *        
      *%                                                               *        
      *%                     CONVERT/IDMS-DB                           *        
      *%                                                               *        
      *%****************************************************************        
      *%          COPYRIGHT 2010 - FORECROSS CORPORATION               *        
      *%                    ALL RIGHTS RESERVED                        *        
      *%****************************************************************        
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *AUTHOR.       M. PRANGE.                                                 
      *DATE-WRITTEN. NOV/90.                                                    
      ******************************************************************        
      *                                                                         
      *    UPDATE THE COMMISSION HISTORY DATA BASE - DAILY.                     
      *    CHANGES NEXT-RECON-DATE ON GROUPS THAT TERMINATED IN GIPSY.          
      *                                                                         
      ******************************************************************        
      *                                                                         
      *    JAN/92 M. PRANGE                                                     
      *         - HILITE GROUP/ACCT IF FUTURE DATED GWCORCOMP RECORDS           
      *           EXIST RELATIVE TO "NEW" NEXT-RECON-DATE.                      
      *                                                                         
      *    DEC 93 A. NIKELSKI                                                   
      *         - PRODUCTION FIX, MAKE SURE THAT NEXT-RECON-DATE IS             
      *           BEING UPDATED                                                 
      *    OCT 08 IBM                 COMPILER UPGRADE.                         
      ******************************************************************        
MAN02 * NOV2010 - IDMSDB2 - IDMS TO DB2 CONVERSION - REPLACES GWCOCUP2          
      *****************************************************************         
                                                                                
       ENVIRONMENT DIVISION.                                                    
      *IDMS-CONTROL SECTION.                                                    
      *PROTOCOL. MODE IS BATCH-AUTOSTATUS DEBUG.                                
      *IDMS-RECORDS MANUAL.                                                     
                                                                                
       DATA DIVISION.                                                           
      *SCHEMA SECTION.                                                          
      *DB  SSGWCO01 WITHIN SCGWCO01.                                            
      /                                                                         
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  WS-START                  PIC X(24)      VALUE                       
FXXTOK     'GC2UP2 WS STARTS HERE '.                                            
                                                                                
       01  WS-GROUP-X.                                                          
REN        05  WS-GROUP              PIC 9(7)       VALUE ZERO.                 
       01  WS-ALIS-TERM-DATE.                                                   
           05  WS-ALIS-TERM-YEAR     PIC S9(3)      VALUE +0     COMP-3.        
           05  WS-ALIS-TERM-DAY      PIC S9(3)      VALUE +0     COMP-3.        
       01  WS-DISP-TERM-DATE         PIC X(9)       VALUE SPACES.               
                                                                                
       01  WS-SUBSCRIPTS.                                                       
           05  WS-ERROR-SUB          PIC S9(4)      VALUE +0     COMP.          
           05  WS-WARNING-SUB        PIC S9(4)      VALUE +0     COMP.          
                                                                                
       01  WS-SINGLE-SPACE           PIC X(1)       VALUE ' '.                  
       01  WS-DOUBLE-SPACE           PIC X(1)       VALUE '0'.                  
       01  WS-TRIPLE-SPACE           PIC X(1)       VALUE '-'.                  
       01  WS-NEW-PAGE               PIC X(1)       VALUE '1'.                  
       01  WS-LINE-CNT               PIC S9(4)      VALUE +0     COMP.          
       01  WS-LINE-MAX               PIC S9(4)      VALUE +60    COMP.          
       01  WS-LINE-INCR              PIC S9(4)      VALUE +0     COMP.          
       01  WS-PAGE-CNT               PIC S9(4)      VALUE +0     COMP.          
      /                                                                         
      *01  GRECONDT.                                                            
           COPY GRECOND7.                                                       
      /                                                                         
       01  HDG1-RECORD.                                                         
           05  HDG1-CC               PIC X(1)       VALUE '1'.                  
FXXTOK     05  HDG1-PROGRAM          PIC X(8)       VALUE 'GC2UP2'.             
           05  FILLER                PIC X(40)      VALUE SPACES.               
           05  FILLER                PIC X(28)      VALUE                       
               'MANUFACTURERS LIFE OF CANADA'.                                  
           05  FILLER                PIC X(38)      VALUE SPACES.               
           05  FILLER                PIC X(11)      VALUE 'FILE DATE: '.        
           05  HDG1-FILE-DATE        PIC X(7)       VALUE SPACES.               
                                                                                
       01  HDG2-RECORD.                                                         
           05  HDG2-CC               PIC X(1)       VALUE ' '.                  
           05  FILLER                PIC X(44)      VALUE SPACES.               
           05  FILLER                PIC X(75)      VALUE                       
               'COMMISSION HISTORY UPDATE - TERMINATED GROUPS'.                 
           05  FILLER                PIC X(9)       VALUE 'PAGE:    '.          
           05  HDG2-PAGE             PIC ZZZ9.                                  
                                                                                
       01  HDG3-RECORD.                                                         
           05  HDG3-CC               PIC X(1)       VALUE '0'.                  
           05  FILLER                PIC X(50)      VALUE                       
               '                        TERMINATED  TERMINATED    '.            
           05  FILLER                PIC X(50)      VALUE                       
               '   NEXT                                           '.            
           05  FILLER                PIC X(32)      VALUE                       
               '                                '.                              
                                                                                
       01  HDG4-RECORD.                                                         
           05  HDG4-CC               PIC X(1)       VALUE ' '.                  
           05  FILLER                PIC X(50)      VALUE                       
REN            '  GROUP   ACCT  STATUS   EFF.DATE    PRO.DATE     '.            
           05  FILLER                PIC X(50)      VALUE                       
               'RECON DATE     HILITE MESSAGE                     '.            
           05  FILLER                PIC X(32)      VALUE                       
               '                                '.                              
                                                                                
       01  HDG5-RECORD.                                                         
           05  HDG5-CC               PIC X(1)       VALUE ' '.                  
           05  FILLER                PIC X(50)      VALUE                       
REN            ' -------  ----  ------  ----------  ----------    '.            
           05  FILLER                PIC X(50)      VALUE                       
               '----------     -----------------------------------'.            
           05  FILLER                PIC X(32)      VALUE                       
               '--------------------------------'.                              
                                                                                
       01  HDG99-RECORD.                                                        
           05  HDG99-CC              PIC X(1)       VALUE '-'.                  
           05  FILLER                PIC X(132)     VALUE                       
               '** END OF REPORT **'.                                           
                                                                                
       01  REPORT-RECORD.                                                       
           05  RPT-CC                PIC X(1)       VALUE SPACES.               
           05  FILLER                PIC X(132)     VALUE SPACES.               
                                                                                
       01  DET1-RECORD.                                                         
           05  DET1-CC               PIC X(1)       VALUE ' '.                  
REN        05  FILLER                PIC X(1)       VALUE SPACES.               
REN        05  DET1-GROUP            PIC 9(7)       VALUE ZERO.                 
           05  FILLER                PIC X(3)       VALUE SPACES.               
           05  DET1-ACCT             PIC X(3)       VALUE SPACES.               
           05  FILLER                PIC X(4)       VALUE SPACES.               
           05  DET1-STATUS           PIC X(2)       VALUE SPACES.               
           05  FILLER                PIC X(5)       VALUE SPACES.               
           05  DET1-EFF-DATE         PIC X(9)       VALUE SPACES.               
           05  FILLER                PIC X(3)       VALUE SPACES.               
           05  DET1-PRO-DATE         PIC X(9)       VALUE SPACES.               
           05  FILLER                PIC X(5)       VALUE SPACES.               
           05  DET1-NEW-RECON-DATE   PIC X(9)       VALUE SPACES.               
           05  FILLER                PIC X(4)       VALUE SPACES.               
           05  DET1-MESSAGE          PIC X(50)      VALUE SPACES.               
           05  FILLER                PIC X(18)      VALUE SPACES.               
      /                                                                         
       01  GAC-DATE-PARAMETERS.                                                 
           COPY GARDATEP.                                                       
      /                                                                         
      *%   COPY IDMS SUBSCHEMA-CONTROL.                                         
IOS        COPY GWFRSKY1.                                                       
IOS        COPY GWFCRCD1.                                                       
IOS    01  DBLINK-SUBSCHEMA-CONTROL.                                            
IOS        20  DBLINK-IDMS-SUBSCHEMA-CONTROL      PIC X(512).                   
IOS        COPY GWFCVDBS.                                                       
IOS        COPY GWFCSPLC.                                                       
IOS                                                                             
      /                                                                         
      * GWCORGRACCT                                                             
CPYNME     COPY GCIGRACT.                                                       
      /                                                                         
      * GWCORCOMP                                                               
CPYNME     COPY GCICOMP.                                                        
      /                                                                         
       01  READ-EXT-PARMS.                                                      
           05  READ-EXT-SYSUNIT      PIC X(6)       VALUE 'SYS010'.             
           05  READ-EXT-RET-CODE     PIC S9(1)      VALUE +0   COMP-3.          
               88  READ-EXT-OK                      VALUE +0.                   
               88  READ-EXT-EOF                     VALUE +4.                   
           05  READ-EXT-RECSZ        PIC 9(5)       VALUE 50.                   
           05  READ-EXT-BLKSZ        PIC 9(5)       VALUE 23450.                
           05  READ-EXT-RECFM        PIC X(2)       VALUE 'FB'.                 
           05  READ-EXT-REC-CNT      PIC S9(7)      VALUE +0   COMP-3.          
                                                                                
       01  WRITE-RPT-PARMS.                                                     
           05  WRITE-RPT-SYSUNIT     PIC X(6)       VALUE 'SYS021'.             
           05  WRITE-RPT-RET-CODE    PIC S9(1)      VALUE +0   COMP-3.          
               88  WRITE-RPT-OK                     VALUE +0.                   
               88  WRITE-RPT-EOF                    VALUE +4.                   
           05  WRITE-RPT-RECSZ       PIC 9(5)       VALUE 133.                  
           05  WRITE-RPT-BLKSZ       PIC 9(5)       VALUE 3990.                 
           05  WRITE-RPT-RECFM       PIC X(2)       VALUE 'FB'.                 
           05  WRITE-RPT-REC-CNT     PIC S9(7)      VALUE +0   COMP-3.          
                                                                                
       01  WS-END                    PIC X(24)      VALUE                       
FXXTOK     'GC2UP2 WS ENDS   HERE '.                                            
       01  WS-END-BYTE-X             PIC X(1)       VALUE SPACES.               
      /                                                                         
IOS    01  DUMMY-PARM-1                               PIC X(10).                
IOS    01  DUMMY-PARM-2                            PIC X(10).                   
IOS                                                                             
IOS        COPY GWFLTRL1.                                                       
IOS        COPY GWFMODN1.                                                       
IOS        COPY GWFCVDBW.                                                       
IOS    01  SUBSCHEMA-SSNAME    VALUE 'SSGWCO01'   PIC X(8).                     
IOS                                                                             
MAN02  COPY GWFERRWS.                                                           
MAN02  01  CALLED-PROGRAMS.                                                     
MAN02      05  GWFADDR                      PIC X(8)  VALUE 'GWFADDR'.          
           05  GC2DATE                      PIC X(8)  VALUE 'GC2DATE'.          
                                                                                
FLT30       EXEC SQL INCLUDE SQLCA END-EXEC.                                    
                                                                                
       PROCEDURE DIVISION.                                                      
FXXTOK     MOVE 'GC2UP2'         TO FCCSPL-CURR-PGM.                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME.                         
                                                                                
       0000-GWCOCUP2.                                                           
                                                                                
           PERFORM 1000-INITIALIZATION THRU                                     
                   1000-INITIALIZATION-EXIT.                                    
           PERFORM 2000-MAIN-PROCESS THRU                                       
                   2000-MAIN-PROCESS-EXIT UNTIL                                 
                   READ-EXT-EOF.                                                
           PERFORM 1900-FINALIZATION THRU                                       
                   1900-FINALIZATION-EXIT.                                      
                                                                                
       0000-GWCOCUP2-EXIT.                                                      
      *%   FINISH.                                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 1 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +2  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-END-THREAD                                         
MAN02                 FCCSPL-GLBLCTL                                            
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
           STOP RUN.                                                            
      /                                                                         
       1000-INITIALIZATION.                                                     
      **************************************************************            
      *                                                                         
      **************************************************************            
FXXTOK     MOVE 'GC2UP2'          TO PROGRAM-NAME.                              
      *%   BIND RUN-UNIT.                                                       
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 2 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +3  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-BEGIN-THREAD                                       
MAN02                 FCCSPL-GLBLCTL                                            
MAN02                 FCCSPL-GLOBALSS                                           
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *%   BIND GWCORGRACCT.                                                    
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   BIND GWCORCOMP.                                                      
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
      *%   READY GW-COMP-AREA1 USAGE-MODE IS UPDATE.                            
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
      *%   READY GW-COMP-AREA2 USAGE-MODE IS RETRIEVAL.                         
IOS        MOVE ZEROS TO ERROR-STATUS.                                          
                                                                                
           MOVE +99                 TO WS-LINE-CNT.                             
                                                                                
           PERFORM 1100-PROCESS-DATE-EXTRACT THRU                               
                   1100-PROCESS-DATE-EXTRACT-EXIT.                              
       1000-INITIALIZATION-EXIT.                                                
           EXIT.                                                                
                                                                                
       1100-PROCESS-DATE-EXTRACT.                                               
      **************************************************************            
      *    GET EXTRACT DATE RECORD.                                             
      **************************************************************            
           MOVE '???????'                TO HDG1-FILE-DATE.                     
                                                                                
           PERFORM 9000-READ-EXTRACT THRU                                       
                   9000-READ-EXTRACT-EXIT.                                      
           IF  READ-EXT-EOF                                                     
               GO TO 1100-PROCESS-DATE-EXTRACT-EXIT.                            
           IF  GRECONDT-REC-TYPE NOT = 'D'                                      
               GO TO 1100-PROCESS-DATE-EXTRACT-EXIT.                            
                                                                                
           MOVE GRECONDT-EFF-DATE         TO VDATE-ALIS-DATE1.                  
           MOVE '2B2E'                    TO VDATE-REQUEST-AREA.                
           CALL  GC2DATE  USING GAC-DATE-PARAMETERS.                            
           IF  VDATE-RET-FAIL                                                   
               MOVE '???????'             TO HDG1-FILE-DATE                     
           ELSE                                                                 
               MOVE VDATE-EXT-DATE        TO HDG1-FILE-DATE.                    
       1100-PROCESS-DATE-EXTRACT-EXIT.                                          
           EXIT.                                                                
      /                                                                         
       1900-FINALIZATION.                                                       
      **************************************************************            
      *    WRITE 'END OF REPORT' LINE.                                          
      *    CLOSE OUTPUT FILES.                                                  
      **************************************************************            
           MOVE +3               TO WS-LINE-INCR.                               
           PERFORM 8000-NEW-PAGE-TEST THRU                                      
                   8000-NEW-PAGE-TEST-EXIT.                                     
           ADD  +3               TO WS-LINE-CNT.                                
           MOVE HDG99-RECORD     TO REPORT-RECORD.                              
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
      *                                                                         
           MOVE +4               TO WRITE-RPT-RET-CODE.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
       1900-FINALIZATION-EXIT.                                                  
           EXIT.                                                                
      /                                                                         
       2000-MAIN-PROCESS.                                                       
      ****************************************************************          
      *    READ NEXT EXTRACT AND BUILD REPORT LINE.                             
      *    UPDATE DATABASE.                                                     
      ****************************************************************          
           PERFORM 9000-READ-EXTRACT THRU                                       
                   9000-READ-EXTRACT-EXIT.                                      
           IF  READ-EXT-EOF                                                     
               GO TO 2000-MAIN-PROCESS-EXIT.                                    
           IF  GRECONDT-REC-TYPE NOT = 'T'                                      
               GO TO 2000-MAIN-PROCESS-EXIT.                                    
                                                                                
           IF  GRECONDT-EFF-DATE > GRECONDT-PRO-DATE                            
               MOVE GRECONDT-EFF-DATE    TO WS-ALIS-TERM-DATE                   
           ELSE                                                                 
               MOVE GRECONDT-PRO-DATE    TO WS-ALIS-TERM-DATE.                  
                                                                                
           MOVE WS-ALIS-TERM-DATE         TO VDATE-ALIS-DATE1.                  
           MOVE '2B1E'                    TO VDATE-REQUEST-AREA.                
           CALL  GC2DATE  USING GAC-DATE-PARAMETERS.                            
           IF  VDATE-RET-FAIL                                                   
               MOVE '*********'           TO WS-DISP-TERM-DATE                  
           ELSE                                                                 
               MOVE VDATE-EXT-DATE        TO WS-DISP-TERM-DATE.                 
                                                                                
           PERFORM 3000-UPDATE-DATABASE THRU                                    
                   3000-UPDATE-DATABASE-EXIT.                                   
                                                                                
           PERFORM 4000-PRODUCE-REPORT THRU                                     
                   4000-PRODUCE-REPORT-EXIT.                                    
       2000-MAIN-PROCESS-EXIT.                                                  
           EXIT.                                                                
      /                                                                         
       3000-UPDATE-DATABASE.                                                    
      ****************************************************************          
      *    CHANGE "NEXT-RECON-DATE" ON GRCORGRACCT RECORD.                      
      *    ARE THERE ANY GWCORCOMP RECORDS THAT HAVE AN EFF DATE >              
      *    THE NEXT RECON DATE ?                                                
      ****************************************************************          
           MOVE +0                    TO WS-ERROR-SUB                           
                                         WS-WARNING-SUB.                        
                                                                                
           MOVE GRECONDT-GROUP        TO WS-GROUP.                              
           MOVE WS-GROUP-X            TO GROUP-NUMBER  OF GWCORGRACCT.          
           MOVE GRECONDT-ACCT         TO GR-ACCOUNT    OF GWCORGRACCT.          
      *%   OBTAIN CALC GWCORGRACCT                                              
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 7 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-PRIM-KEY                              
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-REC-NOT-FOUND                                              
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                   MOVE +1            TO WS-ERROR-SUB                           
                   GO TO 3000-UPDATE-DATABASE-EXIT.                             
                                                                                
           IF  WS-DISP-TERM-DATE = '*********'                                  
               MOVE +2                TO WS-ERROR-SUB                           
               GO TO 3000-UPDATE-DATABASE-EXIT.                                 
      *                                                                         
           PERFORM 3100-CHECK-GWCORCOMP THRU                                    
                   3100-CHECK-GWCORCOMP-EXIT.                                   
      *                                                                         
      *%   OBTAIN CURRENT GWCORGRACCT.                                          
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 8 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +6  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-SELECT-USING-CURR                                  
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
      *                                                                         
           MOVE WS-ALIS-TERM-DATE     TO NEXT-RECON-DATE OF GWCORGRACCT.        
      *                                                                         
      *%   MODIFY GWCORGRACCT.                                                  
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 9 TO FCCSPL-DML-SEQ-NO                                          
IOS        MOVE +4  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-UPDATE                                             
MAN02                 FCCSPLIO-GWCORGRACCT                                      
MAN02                 FCCSPL-GWCORGRACCT                                        
MAN02                 GWCORGRACCT                                               
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        PERFORM 799-SQL-STATUS                                               
IOS           THRU 799-SQL-STATUS-EXIT.                                         
       3000-UPDATE-DATABASE-EXIT.                                               
           EXIT.                                                                
      /                                                                         
       3100-CHECK-GWCORCOMP.                                                    
      ****************************************************************          
      *    CHECK THE 1ST GWCORCOMP RECORD TO SEE IF ITS EFF DATE IS             
      *    > THE NEXT RECON DATE. IF SO - SET WARNING.                          
      ****************************************************************          
      *%   OBTAIN FIRST GWCORCOMP WITHIN GRACCT-COMP                            
IOS        MOVE FCCSPL-CURR-PGM TO FCCSPL-PROGRAM-NAME                          
IOS        MOVE 10 TO FCCSPL-DML-SEQ-NO                                         
IOS        MOVE +7  TO FCCSPL-ADDRESS-COUNT                                     
MAN02      CALL GWFADDR                                                         
MAN02           USING FCCSPL-ADDRESS-AREA                                       
MAN02                 FCCSPL-FETCH-FIRST                                        
MAN02                 FCCSPLIO-GWCORCOMP                                        
MAN02                 FCCSPL-GWCORCOMP                                          
MAN02                 FCCSPL-GRACCT-COMP                                        
MAN02                 GWCORCOMP                                                 
MAN02                 FCCSPL-OBTAIN                                             
MAN02                 FCCSPL-NOKEEP                                             
IOS        END-CALL                                                             
FXXTOK     CALL GWFSPLB1                                                        
IOS             USING DUMMY-PARM-1                                              
IOS                   DUMMY-PARM-2                                              
IOS                   DBLINK-SUBSCHEMA-CONTROL                                  
IOS                   DBLINK-RECORD-SET-KEYS                                    
IOS                   DBLINK-CURSOR-CODES                                       
IOS        END-CALL                                                             
IOS        IF NOT DB-END-OF-SET                                                 
IOS           PERFORM 799-SQL-STATUS-02                                         
IOS              THRU 799-SQL-STATUS-02-EXIT                                    
IOS        ELSE                                                                 
                   GO TO 3100-CHECK-GWCORCOMP-EXIT.                             
                                                                                
           IF  COMP-EFF-DATE OF GWCORCOMP > WS-ALIS-TERM-DATE                   
               MOVE +1                TO WS-WARNING-SUB.                        
       3100-CHECK-GWCORCOMP-EXIT.                                               
           EXIT.                                                                
      /                                                                         
       4000-PRODUCE-REPORT.                                                     
      ****************************************************************          
      *    PRINT REPORT DETAIL SHOWING CHANGES.                                 
      ****************************************************************          
           MOVE SPACES                    TO DET1-RECORD.                       
           MOVE WS-SINGLE-SPACE           TO DET1-CC.                           
                                                                                
           MOVE GRECONDT-GROUP            TO DET1-GROUP.                        
           MOVE GRECONDT-ACCT             TO DET1-ACCT.                         
           MOVE GRECONDT-STATUS           TO DET1-STATUS.                       
                                                                                
           MOVE GRECONDT-EFF-DATE         TO VDATE-ALIS-DATE1.                  
           MOVE '2B1E'                    TO VDATE-REQUEST-AREA.                
           CALL  GC2DATE  USING GAC-DATE-PARAMETERS.                            
           IF  VDATE-RET-FAIL                                                   
               MOVE '*********'           TO DET1-EFF-DATE                      
           ELSE                                                                 
               MOVE VDATE-EXT-DATE        TO DET1-EFF-DATE.                     
                                                                                
           MOVE GRECONDT-PRO-DATE         TO VDATE-ALIS-DATE1.                  
           MOVE '2B1E'                    TO VDATE-REQUEST-AREA.                
           CALL  GC2DATE  USING GAC-DATE-PARAMETERS.                            
           IF  VDATE-RET-FAIL                                                   
               MOVE '*********'           TO DET1-PRO-DATE                      
           ELSE                                                                 
               MOVE VDATE-EXT-DATE        TO DET1-PRO-DATE.                     
                                                                                
           IF  WS-ERROR-SUB = +0                                                
               MOVE WS-DISP-TERM-DATE     TO DET1-NEW-RECON-DATE                
               IF  WS-WARNING-SUB = +1                                          
                   MOVE 'WARNING - FUTURE DATED ADJUSTMENTS EXIST   '           
                                          TO DET1-MESSAGE                       
               ELSE                                                             
                   NEXT SENTENCE                                                
           ELSE                                                                 
           IF  WS-ERROR-SUB = +1                                                
               MOVE 'NOT UPDATED - NO GROUP/ACCT RECORD ON COMMISSIONS '        
                                          TO DET1-MESSAGE                       
           ELSE                                                                 
           IF  WS-ERROR-SUB = +2                                                
               MOVE 'NOT UPDATED - INVALID TERMINATION DATE ON GIPSY   '        
                                          TO DET1-MESSAGE                       
           ELSE                                                                 
               MOVE 'NOT UPDATED - REASON UNKNOWN                      '        
                                          TO DET1-MESSAGE.                      
      *                                                                         
           MOVE +1                        TO WS-LINE-INCR.                      
           PERFORM 8000-NEW-PAGE-TEST THRU                                      
                   8000-NEW-PAGE-TEST-EXIT.                                     
           ADD  +1                        TO WS-LINE-CNT.                       
           MOVE DET1-RECORD               TO REPORT-RECORD.                     
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
       4000-PRODUCE-REPORT-EXIT.                                                
           EXIT.                                                                
      /                                                                         
       8000-NEW-PAGE-TEST.                                                      
      **************************************************************            
      *    CHECK IF NEXT LINE SHOULD BE PRINTED ON A NEW PAGE.                  
      **************************************************************            
           IF  WS-LINE-CNT + WS-LINE-INCR NOT > WS-LINE-MAX                     
               GO TO 8000-NEW-PAGE-TEST-EXIT.                                   
                                                                                
           ADD  +1                    TO WS-PAGE-CNT.                           
           MOVE WS-PAGE-CNT           TO HDG2-PAGE.                             
           MOVE HDG1-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG2-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG3-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG4-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE HDG5-RECORD           TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE SPACES                TO REPORT-RECORD.                         
           PERFORM 9000-WRITE-REPORT THRU                                       
                   9000-WRITE-REPORT-EXIT.                                      
           MOVE +7                    TO WS-LINE-CNT.                           
       8000-NEW-PAGE-TEST-EXIT.                                                 
           EXIT.                                                                
      /                                                                         
       9000-READ-EXTRACT.                                                       
           CALL 'DLSREAD'  USING READ-EXT-SYSUNIT                               
                                 READ-EXT-RET-CODE                              
                                 GRECONDT                                       
                                 READ-EXT-RECSZ                                 
                                 READ-EXT-BLKSZ                                 
                                 READ-EXT-RECFM                                 
                                 READ-EXT-REC-CNT.                              
       9000-READ-EXTRACT-EXIT.                                                  
           EXIT.                                                                
                                                                                
       9000-WRITE-REPORT.                                                       
           CALL 'DLSWRITE' USING WRITE-RPT-SYSUNIT                              
                                 WRITE-RPT-RET-CODE                             
                                 REPORT-RECORD                                  
                                 WRITE-RPT-RECSZ                                
                                 WRITE-RPT-BLKSZ                                
                                 WRITE-RPT-RECFM                                
                                 WRITE-RPT-REC-CNT.                             
       9000-WRITE-REPORT-EXIT.                                                  
           EXIT.                                                                
      /                                                                         
      *%   COPY IDMS     IDMS-STATUS.                                           
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   798-START-OF-STATUS ROUTINES                *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    798-START-OF-STATUS SECTION.                                             
IOS   *    ERROR STATUS ROUTINES FOLLOW                                         
IOS        CONTINUE.                                                            
IOS    798-START-OF-STATUS-EXIT.                                                
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-SQL-STATUS ROUTINE                      *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-SQL-STATUS.                                                          
IOS        IF BATCH-ACCEPTABLE-ERROR-STATUS                                     
IOS            GO TO 799-SQL-STATUS-EXIT                                        
IOS        END-IF.                                                              
IOS    799-SQL-STATUS-02.                                                       
IOS        IF ERROR-STATUS = ZEROS                                              
IOS            GO TO 799-SQL-STATUS-02-EXIT                                     
IOS        END-IF.                                                              
      * ECBATCH                                                                 
CPYNME     EXEC SQL INCLUDE GWFBATCH END-EXEC.                                  
IOS    799-SQL-STATUS-02-EXIT.                                                  
IOS    799-SQL-STATUS-EXIT.                                                     
IOS        EXIT.                                                                
      *%---------------------------------------------------------------*        
      *%                                                               *        
      *%                   799-END-OF-STATUS ROUTINES                  *        
      *%                                                               *        
      *%---------------------------------------------------------------*        
IOS    799-END-OF-STATUS SECTION.                                               
IOS   *    ERROR STATUS ROUTINES COMPLETE                                       
IOS        CONTINUE.                                                            
IOS    799-END-OF-STATUS-EXIT.                                                  
IOS        EXIT.                                                                
                                                                                
       IDMS-ABORT.                                                              
       IDMS-ABORT-EXIT.                                                         
           EXIT.                                                                
