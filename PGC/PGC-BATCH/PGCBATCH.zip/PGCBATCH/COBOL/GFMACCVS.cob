       IDENTIFICATION DIVISION.                                                 
GNE                                                                             
       PROGRAM-ID.    GFMACCVS.                                                 
      *THIS PROGRAM HAS BEEN EXAMINED/RENOVATED FOR YEAR 2000 COMPLIANCE.       
      *REMARKS.       THIS IS A PROGRAM WHICH USES ZACCVSAM TO ACCESS           
      *               THE AGENT NAME FILE, AND USES                             
      *               LSV00300 TO ACCESS THE ACCOUNT NAME FILE.                 
      *                                                                         
      * LSV00300 IS NOW OBSOLETE                                                
      * LSV00300 USED TO CALL ZACCVSAM AND RETURN A RECORD FROM                 
      * PGW.ADMN.PROD.MACTNAME.VSAM THIS HAS BEEN REPLACED WITH A               
      * NEW FILE PGW.ADMN.PROD.AIS.CONVERT.VSAM                                 
      *                                                                         
      * THE NEW FILE IS 52 BYTES INSTEAD OF THE OLD 47 AND FIELDS               
      * HAVE BEEN ADDED AND MOVED. AT THIS TIME THE ACTUAL VALUES               
      * OF THE FILE ARE NOT BEING USED, THE CALL VERIFIES THAT A                
      * VALID CODE WAS USED BECAUSE OF THE "POSITIVE" RETURN CODE               
      * FROM ZACCVSAM.                                                          
      *                                                                         
      * GFMNMACC IS CALLED IN GFMMAINL TO OPEN AND CLOSE THE FILE               
      * AND FROM GFMEDPRM, WHERE IT VERIFIES THE EXISTENCE OF THE               
      * GL CODE.                                                                
      *************************************************************             
      *   MODIFICATION LOG                                                      
      *   ---------------------                                                 
      *                                                                         
      * 15JUL08    IBM GR  UPGRADED IN ECU PROJECT                              
      *                                                                         
MAN07 * NOV2014 - GROUP NUMBER EXPANSION PROJECT                                
      *************************************************************             
       ENVIRONMENT DIVISION.                                                    
       INPUT-OUTPUT SECTION.                                                    
       FILE-CONTROL.                                                            
                                                                                
       DATA DIVISION.                                                           
       FILE SECTION.                                                            
      *                                                                         
                                                                                
       WORKING-STORAGE SECTION.                                                 
                                                                                
      ******************************************************************        
      *    PARAMETERS TO DO FILE I/O -                                          
      ******************************************************************        
       01  ZACCVSAM-AGENT-PARMS.                                                
           03  ZACCVSAM-AGENT-PARM1.                                            
               05  ZACCAGENT-DDNAME        PIC X(7)  VALUE 'VSDSI37'.           
               05  ZACCAGENT-ACCTYPE       PIC X(5)  VALUE 'KEYED'.             
               05  ZACCAGENT-RECTYPE       PIC X     VALUE 'V'.                 
               05  ZACCAGENT-FUNCTION      PIC X(6).                            
               05  ZACCAGENT-ERRCODE       PIC X(5).                            
               05  ZACCAGENT-READCT        PIC S9(7) COMP-3.                    
               05  ZACCAGENT-WRITECT       PIC S9(7) COMP-3.                    
               05  ZACCAGENT-UPDATECT      PIC S9(7) COMP-3.                    
               05  ZACCAGENT-DELETECT      PIC S9(7) COMP-3.                    
               05  ZACCAGENT-RECLGTH       PIC S9(4) COMP.                      
           03  ZACCVSAM-AGENT-KEY.                                              
               05  ZACCAGENT-AGENT         PIC S9(7) COMP-3.                    
               05  ZACCAGENT-ACCT          PIC X.                               
           03  ZACCVSAM-AGENT-RECORD       PIC X(70).                           
       01  ZACCVSAM-AIS-PARMS.                                                  
           03  ZACCVSAM-AIS-PARM1.                                              
               05  ZACCAIS-DDNAME          PIC X(7)  VALUE 'VSDSI31'.           
               05  ZACCAIS-ACCTYPE         PIC X(5)  VALUE 'KEYED'.             
               05  ZACCAIS-RECTYPE         PIC X     VALUE 'F'.                 
               05  ZACCAIS-FUNCTION        PIC X(6)  VALUE 'GETRAN'.            
               05  ZACCAIS-ERRCODE         PIC X(5).                            
               05  ZACCAIS-READCT          PIC S9(7) COMP-3.                    
               05  ZACCAIS-WRITECT         PIC S9(7) COMP-3.                    
               05  ZACCAIS-UPDATECT        PIC S9(7) COMP-3.                    
               05  ZACCAIS-DELETECT        PIC S9(7) COMP-3.                    
               05  ZACCAIS-RECLGTH         PIC S9(4) COMP.                      
           03  ZACCVSAM-AIS-KEY            PIC 9(7).                            
           03  ZACCVSAM-AIS-RECORD         PIC X(52).                           
                                                                                
      ******************************************************************        
      *    PARAMETERS USED BY WTL TO DISPLAY ERROR MESSAGES                     
      ******************************************************************        
                                                                                
       01  WTL-PARAMETERS.                                                      
           03  WTL-FLAG     VALUE 'B'          PIC X.                           
           03  WTL-REPLY-CODE   VALUE 'YES'    PIC X(3).                        
           03  WTL-REPLY-AREA                  PIC X(120).                      
           03  WTL-MESSAGE-AREA3.                                               
               05  FILLER  COMP-3   VALUE +81  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE3.                                                
                   07  FILLER                  PIC X(46) VALUE                  
                   'ERROR WHEN ACCESSING AGENT FILE WITH ZACCVSAM '.            
                   07  FILLER                  PIC X(9) VALUE                   
                   'FUNCTION'.                                                  
                   07  WTL-MESS3-FUNCTION      PIC X(6).                        
                   07  FILLER                  PIC X(14) VALUE                  
                       ' ERROR CODE = '.                                        
                   07  WTL-MESS3-ERRCODE       PIC X(5).                        
           03  WTL-MESSAGE-AREA4.                                               
               05  FILLER  COMP-3   VALUE +26  PIC S9(3).                       
               05  FILLER           VALUE ' '  PIC X.                           
               05  WTL-MESSAGE4.                                                
                   07  FILLER                  PIC X(8) VALUE                   
                   'AGENT = '.                                                  
                   07  WTL-MESS4-AGENT         PIC 9(6).                        
                   07  FILLER                  PIC X(8) VALUE                   
                   ' ACCT = '.                                                  
                   07  WTL-MESS4-ACCT          PIC XXX.                         
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
      *    PARAMETERS FOR ZACCVSAM TO ACCESS AGENT FILE                         
                                                                                
       01  ZACCVSAM-FUNCTION               PIC X(6).                            
       01  ZACCVSAM-ERRCODE                PIC X(5).                            
       01  AGENT-RECORD                    PIC X(70).                           
                                                                                
       01  RECORD-KEY.                                                          
           03  AGENT-KEY                   PIC X(5).                            
                                                                                
      *    PARAMETERS FOR ACCT NAME FILE                                        
                                                                                
       01  LSV00300-AREA1.                                                      
           05  ACCT-NAME-GLCODE     COMP-3 PIC S9(7).                           
           05  FILLER                      PIC X(43).                           
       01  LSV00300-RETCODE                PIC X.                               
                                                                                
       PROCEDURE DIVISION.                                                      
                                                                                
      ******************************************************************        
      *    GFMAGENT ACCESSES THE AGENT FILE USING ZACCVSAM.  IF AN ERROR        
      *    OCCURS, PRODUCE AN APPROPRIATE ERROR MESSAGE.                        
      ******************************************************************        
                                                                                
           ENTRY 'GFMAGENT' USING ZACCVSAM-FUNCTION,                            
                                  ZACCVSAM-ERRCODE,                             
                                  AGENT-RECORD,                                 
                                  RECORD-KEY.                                   
           MOVE ZACCVSAM-FUNCTION TO ZACCAGENT-FUNCTION                         
           MOVE AGENT-KEY TO ZACCVSAM-AGENT-KEY.                                
           CALL 'ZACCVSAM' USING ZACCVSAM-AGENT-PARM1                           
                                 ZACCVSAM-AGENT-KEY                             
                                 ZACCVSAM-AGENT-RECORD.                         
           MOVE ZACCAGENT-ERRCODE TO ZACCVSAM-ERRCODE.                          
           IF ZACCAGENT-ERRCODE EQUAL LOW-VALUES OR 'R0804' OR 'R0810'          
              NEXT SENTENCE                                                     
           ELSE                                                                 
               MOVE ZACCAGENT-FUNCTION TO WTL-MESS3-FUNCTION                    
               MOVE ZACCAGENT-ERRCODE TO WTL-MESS3-ERRCODE                      
               CALL 'WTL' USING  WTL-MESSAGE-AREA3 WTL-FLAG                     
                                 WTL-REPLY-CODE    WTL-REPLY-AREA               
               IF ZACCAGENT-FUNCTION EQUAL 'CLOFIL' OR 'CLOALL'                 
                  GO TO GFMAGENT-RETURN                                         
               ELSE                                                             
                  MOVE ZACCAGENT-AGENT TO WTL-MESS4-AGENT                       
                  MOVE ZACCAGENT-ACCT  TO WTL-MESS4-ACCT                        
                  CALL 'WTL' USING  WTL-MESSAGE-AREA4 WTL-FLAG                  
                                    WTL-REPLY-CODE    WTL-REPLY-AREA            
                  GO TO GFMAGENT-RETURN.                                        
           IF ZACCVSAM-FUNCTION EQUAL 'GETRAN' OR 'GETSEQ'                      
              MOVE ZACCVSAM-AGENT-RECORD TO AGENT-RECORD.                       
                                                                                
       GFMAGENT-RETURN.                                                         
           GOBACK.                                                              
                                                                                
      ******************************************************************        
      *    GFMNMACC ACCESSES THE ACCT NAME FILE USING LSV00300.                 
      ******************************************************************        
      * GPL                                                                     
                                                                                
           ENTRY 'GFMNMACC' USING LSV00300-AREA1                                
                                  LSV00300-RETCODE.                             
      *    CALL 'LSV00300' USING LSV00300-AREA1                                 
      *                          LSV00300-RETCODE.                              
           MOVE ACCT-NAME-GLCODE TO ZACCVSAM-AIS-KEY.                           
           CALL 'ZACCVSAM' USING ZACCVSAM-AIS-PARM1                             
                                 ZACCVSAM-AIS-KEY                               
                                 ZACCVSAM-AIS-RECORD.                           
           IF ZACCAIS-ERRCODE EQUAL LOW-VALUES THEN                             
              NEXT SENTENCE                                                     
           ELSE                                                                 
              MOVE HIGH-VALUES TO LSV00300-RETCODE.                             
       GFMNMACC-RETURN.                                                         
           GOBACK.                                                              
                                                                                
MAN07 *9999-DUMP-ROUTINE.                                                       
MAN07 ******************************************************************        
MAN07 *    SERIOUS ERROR OCCURRED.                                              
MAN07 *    DISPLAY SOME CONSOLE MESSAGES, TAKE A DUMP THEN ABEND.               
MAN07 *    COPYBOOK GWRDUMP IS REQUIRED                                         
MAN07 ******************************************************************        
MAN07 *                                                                         
MAN07 *    MOVE WS-PROGRAM-ID TO GWRDUMP-PROGRAM-NAME.                          
MAN07 *    CALL GWCDUMP    USING ICBM                                           
MAN07 *                          GWRDUMP.                                       
MAN07 *                                                                         
MAN07 *9999-EXIT.                                                               
MAN07 *    EXIT.                                                                
