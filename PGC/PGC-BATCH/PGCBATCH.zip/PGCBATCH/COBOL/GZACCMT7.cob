       IDENTIFICATION DIVISION.                                                 
       PROGRAM-ID.      GZACCMT7.                                               
                                                                                
      *****************************************************************         
      *                                                               *         
      *  THIS PROGRAM IS A REPLACEMENT FOR THE ASSEMBER PROGRAM       *         
      *  GZACCMTR.                                                    *         
      *                                                               *         
      *****************************************************************         
      * THIS PROGRAM WILL TAKE IN A TRAILER ID AS INPUT AND RETURN    *         
      * BACK A SPECIFIC GIPSY MASTER TRAILER RECORD TO THE CALLING    *         
      * PROGRAM.                                                      *         
      *                                                               *         
      *  CHANGE LOG: GZACCMT7                                         *         
      *  DATE     TASK     DESCRIPTION                                *         
      *  24JAN14  GNE      GROUP NUMBER EXPANSION - INITIAL VERSION   *         
      *****************************************************************         
                                                                   SKIP1        
       ENVIRONMENT DIVISION.                                                    
                                                                   SKIP1        
       CONFIGURATION SECTION.                                                   
                                                                   EJECT        
       DATA DIVISION.                                                           
                                                                   SKIP1        
       WORKING-STORAGE SECTION.                                                 
                                                                                
       01  CALLED-PROGRAMS.                                                     
           05  GACBMAS7                  PIC X(8)  VALUE 'GACBMAS7'.            
           05  GZGETMT7                  PIC X(8)  VALUE 'GZGETMT7'.            
                                                                                
       01  GACBMAS7-PARMS.                                                      
           03  GACBMAS7-FUNC         COMP   PIC S9(4) VALUE +0.                 
           03  GACBMAS7-SEARCH-KEY.                                             
               05  GACBMAS7-GROUP    COMP-3 PIC S9(7).                          
               05  GACBMAS7-ACCT            PIC X(3).                           
               05  FILLER            COMP-3 PIC S9(9).                          
           03  GACBMAS7-WORK                PIC X(9).                           
                                                                                
       01  GACBMAS7-RETURN                  PIC X(3)   VALUE SPACES.            
           88  GACBMAS7-RET-OK                         VALUE '   '.             
           88  GACBMAS7-EOF                            VALUE 'R01'.             
           88  GACBMAS7-NOT-FOUND                      VALUE 'R01'.             
           88  GACBMAS7-DISK-ERROR                     VALUE 'R03'.             
           88  GACBMAS7-DUP-RECORD                     VALUE 'R08'.             
           88  GACBMAS7-FUNC-INVALID                   VALUE 'R09'.             
                                                                                
           COPY GMASTER7.                                                       
      *----------------------------------------------------------------         
                                                                                
       LINKAGE SECTION.                                                         
                                                                                
       01  LS-GRPACCT.                                                          
           05  LS-GROUP          PIC S9(07) COMP-3.                             
           05  LS-ACCT           PIC  X(03).                                    
                                                                                
       01  LS-TRAILER-AREA.                                                     
           05   LS-TRAILER-ID    PIC X(3).                                      
           05   LS-TRAILER-REC   PIC X(16280).                                  
                                                                                
       01   LS-ERROR-CD          PIC X(03).                                     
                                                                                
                                                                                
       PROCEDURE DIVISION USING LS-GRPACCT                                      
                                LS-TRAILER-AREA                                 
                                LS-ERROR-CD.                                    
                                                                                
       A-100-MAINLINE.                                                          
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
                                                                                
           INITIALIZE GACBMAS7-GROUP                                            
                      GACBMAS7-ACCT                                             
                                                                                
           MOVE +2        TO GACBMAS7-FUNC.                                     
           MOVE LS-GROUP  TO GACBMAS7-GROUP.                                    
           MOVE LS-ACCT   TO GACBMAS7-ACCT.                                     
                                                                                
           IF GACBMAS7-ACCT EQUAL LOW-VALUES THEN                               
              MOVE 'R01'  TO LS-ERROR-CD                                        
              GO TO A-100-EXIT                                                  
           END-IF                                                               
                                                                                
           PERFORM B-100-READ-MASTER  THRU B-100-EXIT.                          
                                                                                
           IF NOT GACBMAS7-RET-OK                                               
              MOVE GACBMAS7-RETURN  TO LS-ERROR-CD                              
              GO TO A-100-EXIT                                                  
           END-IF                                                               
                                                                                
           PERFORM C-100-PROCESS-TRLR THRU C-100-EXIT                           
                                                                                
           IF LS-ERROR-CD NOT EQUAL SPACES                                      
              GO TO A-100-EXIT                                                  
           ELSE                                                                 
              MOVE SPACES  TO LS-ERROR-CD                                       
           END-IF.                                                              
                                                                                
       A-100-EXIT.                                                              
           EXIT.                                                                
                                                                                
           GOBACK.                                                              
                                                                                
       B-100-READ-MASTER.                                                       
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
                                                                                
           CALL GACBMAS7     USING  GACBMAS7-PARMS                              
                                    GACBMAS7-RETURN                             
                                    GMASTER7.                                   
                                                                                
       B-100-EXIT.                                                              
           EXIT.                                                                
                                                                                
                                                                                
       C-100-PROCESS-TRLR.                                                      
      *****************************************************************         
      *                                                               *         
      *****************************************************************         
                                                                                
           CALL GZGETMT7      USING     LS-TRAILER-ID                           
                                        GMASTER7                                
                                        LS-TRAILER-REC                          
                                        LS-ERROR-CD.                            
                                                                                
       C-100-EXIT.                                                              
           EXIT.                                                                
