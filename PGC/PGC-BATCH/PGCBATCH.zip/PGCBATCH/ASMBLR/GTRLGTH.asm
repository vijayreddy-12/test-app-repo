GTRLGTH  START                                                          00001000
         PRINT NOGEN                                                    00002000
         REGEQU                                                         00003000
*                                                                       00004000
* THIS ROUTINE IS CALLED USING THE 3 BYTE TRAILER ID.                   00005000
*                                 18 BYTES OF RETURNED LENGTHS          00006000
*                                 - PIC X(4) TR. ID. AND A BLANK        00007000
*                                 - PIC S9(4) COMP # OF LEVEL 1 OCCURS  00008000
*                                 - PIC S9(4) COMP MIN LEVEL 1 LENGTH   00009000
*                                 - PIC S9(4) COMP MAX LEVEL 1 LENGTH   00010000
*                                 - PIC S9(4) COMP # OF LEVEL 2 OCCURS  00011000
*                                 - PIC S9(4) COMP LEVEL 2 LENGTH       00012000
*                                 - PIC S9(4) COMP # OF LEVEL 3 OCCURS  00013000
*                                 - PIC S9(4) COMP LEVEL 3 LENGTH       00014000
*                                1 BYTE FOR ERRORS (TRAILER NOT FOUND)  00015000
*                                                                       00016000
         STM   R14,R12,12(R13)                                          00017000
         BALR  R12,R0                                                   00018000
         USING *,R12                                                    00019000
         ST    R13,MYSAVE+4                                             00020000
         LA    R13,MYSAVE                                               00021000
         LM    R2,R4,0(R1)                                              00022000
         MVI   0(R4),C'1'                                               00023000
*                                                                       00024000
* SET THE ERROR SWITCH TO A DEFAULT OF '1'                              00025000
* LOAD THE GMASXTAB TABLE USING THE DSECT GMEXTAB                       00026000
*                                                                       00027000
         L     R5,=V(GMASXTA7)                                          00028000
         USING GMEXTAB,R5                                               00029000
LOOP     EQU   *                                                        00030000
*                                                                       00031000
* IF THE '*' IS FOUND WE HAVE AN ERROR, NO MATCHING TRAILER IDENT       00032000
*                                                                       00033000
         CLI   0(R5),C'*'                                               00034000
         BE    STOP                                                     00035000
         CLC   0(3,R2),0(R5)                                            00036000
         BE    GOTIT                                                    00037000
*                                                                       00038000
* WE HAVE A MATCH ON TRAILER IDENT, STUFF THE 18 BYTES INTO REG. 3      00039000
* AND EXIT.                                                             00040000
*                                                                       00041000
         LA    R5,18(R5)                                                00042000
         B     LOOP                                                     00043000
GOTIT    EQU   *                                                        00044000
         MVI   0(R4),C' '                                               00045000
         MVC   0(18,R3),0(R5)                                           00046000
STOP     EQU   *                                                        00047000
         L     R13,MYSAVE+4                                             00048000
         LM    R14,R12,12(R13)                                          00049000
         BR    R14                                                      00050000
MYSAVE   DS    18F                                                      00051000
GMEXTAB  DSECT                                                          00052000
GMTRID   DS    CL3                                                      00053000
         DS    C                                                        00054000
GMNUMTR  DS    H                                                        00055000
GMRTMIN  DS    H                                                        00056000
GMRTMAX  DS    H                                                        00057000
GMNOSEG2 DS    H                                                        00058000
GMSEG2L  DS    H                                                        00059000
GMNOSEG3 DS    H                                                        00060000
GMSEG3L  DS    H                                                        00061000
         END                                                            00062000
