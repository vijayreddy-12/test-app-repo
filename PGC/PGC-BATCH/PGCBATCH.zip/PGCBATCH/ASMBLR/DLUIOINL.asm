DLUIOINL START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  SET UP THE REQUIRED FIELDS IN THE NEW AREA. A PREVIOUS                       
*  DCB/ACB NAME IS SET UP SO THAT THE LABEL ROUTINE CAN CHECK                   
*  FOR EITHER NAME. THIS MEANS THAT OLD JCL CAN BE USED WITH                    
*  THIS ROUTINE. SPECIAL FILES ARE FLAGGED HERE. THERE WILL BE                  
*  NO CONTROL OR BALANCE PROCESSING DONE FOR THESE FILES.                       
*                                                                               
         MVC   DCBACBFA,DCBACBP1                                                
         ST    R3,PARM1ADR                                                      
         ZAP   SVREAD,=P'0'                                                     
         ZAP   SVWRITE,=P'0'                                                    
         ZAP   SVUPDATE,=P'0'                                                   
         ZAP   SVDELETE,=P'0'                                                   
         ZAP   RECCNT,=P'0'                                                     
         ZAP   RECMAX,=P'0'                                                     
         ZAP   RECMIN,=P'999999999'                                             
         ZAP   RECAVG,=P'0'                                                     
         ZAP   RECBYTES,=P'0'                                                   
         CLC   DCBACBFA(2),=C'SQ'                                               
         BE    SEQ                                                              
         CLC   DCBACBFA(2),=C'VS'                                               
         BE    VSAM                                                             
SEQ      EQU   *                                                                
         CLC   DCBACBFA+4(3),=C'IN '                                            
         BE    SEQA                                                             
         CLC   DCBACBFA+4(3),=C'IPT'                                            
         BE    SEQA                                                             
         MVC   PVDCBACB(3),=C'DLS'                                              
         MVC   PVDCBACB+3(1),DCBACBFA+2                                         
         MVC   PVDCBACB+4(2),DCBACBFA+5                                         
         MVC   PVDCBACB+6(2),=C'  '                                             
         MVI   FILETYPE,SEQFILE                                                 
         B     GOTTYPE                                                          
SEQA     EQU   *                                                                
         MVC   PVDCBACB,=C'SYSIN   '                                            
         B     GOTTYPE                                                          
VSAM     EQU   *                                                                
         MVC   PVDCBACB(4),=C'VSDS'                                             
         MVC   PVDCBACB+4(1),DCBACBFA+2                                         
         MVC   PVDCBACB+5(2),DCBACBFA+5                                         
         MVI   PVDCBACB+7,C' '                                                  
         MVI   FILETYPE,VSAMFILE                                                
GOTTYPE  EQU   *                                                                
         MVI   OPENIND,NOTOPEN                                                  
         MVI   CNTRLSW,FRSTPASS                                                 
         CLC   DCBACBFA+4(3),=C'045'                                            
         BE    SPECIAL                                                          
         CLC   DCBACBFA+4(3),=C'050'                                            
         BL    NORMAL                                                           
         CLC   DCBACBFA+4(3),=C'080'                                            
         BH    NORMAL                                                           
SPECIAL  EQU   *                                                                
         MVI   SPECLIND,SPECLFIL                                                
         B     GOBACK                                                           
NORMAL   EQU   *                                                                
         MVI   SPECLIND,NOTSPECL                                                
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOINL EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
