*******S**************************************************************          
*     *S**                 D L U I O A C B                                      
*     *S**                                                                      
*     *S** THIS SUBROUTINE SETS UP THE ACB AND RPL CONTROL BLOCKS               
*     *S** FOR A VSAM FILE.                                                     
*******S**************************************************************          
         SPACE                                                                  
*********H*************************************************************         
*     ***H    DATE       - 26OCT95                                              
*     ***H    PROGRAMMER - DAVE EMBURY                                          
*     ***H    ACTION     - REPLACED ENTRY AND EXIT LOGIC, AND REMOVED           
*     ***H                 THE SECOND BASE REGISTER.                            
*     ***H               - UPDATED GENCB MACRO CALL TO REQUEST AN AREA          
*     ***H                 SIZE LARGE ENOUGH TO ACCOMMODATE 30K RECORDS         
*     ***H                 (UP FROM 16K).                                       
*********H*************************************************************         
         EJECT                                                                  
DLUIOACB TMENTER SUB,AMODE=24,RMODE=24                                          
********P**************************************************************         
*     **P*         R E G I S T E R   U S A G E                                  
*     **P*                                                                      
*     **P*     R3  -> REQUEST BLOCK FROM APPLICATION (PARM1) (AT ENTRY)         
*     **P*     R4  -> APPLICATION PROGRAM RECORD AREA        (AT ENTRY)         
*     **P*     R5  -> INTERNAL STORAGE AREA ADDRESS BLOCK    (AT ENTRY)         
*     **P*     R6  -> STORAGE BLOCK FOR THE FILE             (AT ENTRY)         
*     **P*     R8  -  WORK REGISTER                                             
*     **P*     R9  -> POINTS TO ACB                                             
*     **P*     R10 -> RPL                                                       
*     **P*     R12 -  BASE REGISTER                                             
*     **P*     R13 -> CURRENT SAVE AREA                                         
********P**************************************************************         
         SPACE 1                                                                
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
********P**************************************************************         
*     **P*     DETERMINE LENGTH OF A STANDARD ACB & RPL, THEN GET               
*     **P*     STORAGE TO CONTAIN THESE AREAS.                                  
********P**************************************************************         
         SPACE 1                                                                
         SHOWCB AREA=(S,LACBAREA),LENGTH=4,FIELDS=(ACBLEN)                      
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         EJECT                                                                  
         SHOWCB AREA=(S,LRPLAREA),LENGTH=4,FIELDS=(RPLLEN)                      
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         CALL  DLUIOCNB                                                         
         CLI   ERRCODE,C'E'        ERROR RETURN?                                
         BE    GOBACK              YES - EXIT IMMEDIATELY                       
         L     R9,ACBAREA                                                       
         L     R10,RPLAREA                                                      
         EJECT                                                                  
********P**************************************************************         
*     **P*     DETERMINE IF PASSWORD PRESENT. IF NOT CODED,                     
*     **P*     SET LENGTH BYTE TO ZERO TO INDICATE PASSWORD IS NOT              
*     **P*     REQUIRED.                                                        
********P**************************************************************         
         SPACE 1                                                                
         MVI   PASSWRD,X'00'                                                    
         MVC   WORK4(1),PASSWORD                                                
         NI    WORK4,X'F0'                                                      
         CLI   WORK4,X'00'                                                      
         BE    GENRPL                                                           
         ZAP   WORK4(8),PASSWORD(1)                                             
         CVB   R8,WORK4                                                         
         STC   R8,PASSWRD                                                       
         MVC   PASSWRD+1(8),PASSWORD+1                                          
         EJECT                                                                  
********P**************************************************************         
*     **P*     GENERATE A GENERAL RPL FOR THE FILE.                             
********P**************************************************************         
         SPACE 1                                                                
GENRPL   EQU   *                                                                
         GENCB BLK=RPL,WAREA=(R10),LENGTH=(*,LRPLAREA),                *        
               AM=VSAM,ACB=(R9),AREA=(R4),AREALEN=32760,ARG=(S,KEY),   *        
               OPTCD=(FWD,ARD,KEQ,FKS,MVE)                                      
         LTR   R15,R15                                                          
         BNZ   GENERR                                                           
         EJECT                                                                  
********P**************************************************************         
*     **P*     DEPENDING UPON WHETHER THE FILE IS                               
*     **P*     READ ONLY OR READ/WRITE, AND THE                                 
*     **P*     TYPE OF FILE GENERATE THE APPROPRIATE                            
*     **P*     ACB AND MODIFY THE RPL JUST                                      
*     **P*     GENERATED ACCORDINGLY.                                           
*     **P*                                                                      
*     **P*     VSAM ALLOWS THREE TYPES OF FILES:                                
*     **P*           1) KEY SEQUENCED   - USE 'KEY' ACCESS                      
*     **P*           2) ENTRY SEQUENCED - USE 'ADR' ACCESS                      
*     **P*           3) RELATIVE RECORD - USE 'KEY' ACCESS.                     
********P**************************************************************         
         SPACE 1                                                                
         CLI   DCBACBFA+2,C'I'                                                  
         BE    GENIN                                                            
GENOUT   EQU   *                                                                
         CLC   ACCTYPE,=C'ENTRY'                                                
         BE    GENOUTA                                                          
         GENCB BLK=ACB,WAREA=(R9),LENGTH=(*,LACBAREA),                 *        
               AM=VSAM,DDNAME=(*,ACDCBACB),STRNO=1,PASSWD=(S,PASSWRD), *        
               MACRF=(KEY,SEQ,DIR,OUT,NRS,NUB,NRM,NSR,NDF)                      
         LTR   R15,R15                                                          
         BNZ   GENERR                                                           
         MODCB RPL=(R10),OPTCD=(KEY,UPD)                                        
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         B     GOBACK                                                           
         EJECT                                                                  
GENOUTA  EQU   *                                                                
         GENCB BLK=ACB,WAREA=(R9),LENGTH=(*,LACBAREA),                 *        
               AM=VSAM,DDNAME=(*,ACDCBACB),STRNO=1,PASSWD=(S,PASSWRD), *        
               MACRF=(ADR,SEQ,DIR,OUT,NRS,NUB,NRM,NSR,NDF)                      
         LTR   R15,R15                                                          
         BNZ   GENERR                                                           
         MODCB RPL=(R10),OPTCD=(ADR,UPD)                                        
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         B     GOBACK                                                           
         EJECT                                                                  
GENIN    EQU   *                                                                
         CLC   ACCTYPE,=C'ENTRY'                                                
         BE    GENINA                                                           
         GENCB BLK=ACB,WAREA=(R9),LENGTH=(*,LACBAREA),                 *        
               AM=VSAM,DDNAME=(*,ACDCBACB),STRNO=1,PASSWD=(S,PASSWRD), *        
               MACRF=(KEY,SEQ,DIR,IN,NRS,NUB,NRM,NSR,NDF)                       
         LTR   R15,R15                                                          
         BNZ   GENERR                                                           
         MODCB RPL=(R10),OPTCD=(KEY,NUP)                                        
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         B     GOBACK                                                           
         EJECT                                                                  
GENINA   EQU   *                                                                
         GENCB BLK=ACB,WAREA=(R9),LENGTH=(*,LACBAREA),                 *        
               AM=VSAM,DDNAME=(*,ACDCBACB),STRNO=1,PASSWD=(S,PASSWRD), *        
               MACRF=(ADR,SEQ,DIR,IN,NRS,NUB,NRM,NSR,NDF)                       
         LTR   R15,R15                                                          
         BNZ   GENERR                                                           
         MODCB RPL=(R10),OPTCD=(ADR,NUP)                                        
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         B     GOBACK                                                           
         EJECT                                                                  
********P**************************************************************         
*     **P*     GOT AN ERROR GENERATING A CONTROL BLOCK.                         
********P**************************************************************         
         SPACE 1                                                                
GENERR   EQU   *                                                                
         MVC   ERRCODE(2),=C'E4'                                                
         STC   R15,HEXERR                                                       
         MVI   HEXERR+1,X'00'                                                   
         CALL  DLUIOXPF                                                         
         B     GOBACK                                                           
         SPACE 2                                                                
********P**************************************************************         
*     **P*     GOT AN ERROR MODIFYING OR DISPLAYING A CONTROL BLOCK.            
********P**************************************************************         
         SPACE 1                                                                
MANIPERR EQU   *                                                                
         MVC   ERRCODE(2),=C'E5'                                                
         STC   R15,HEXERR                                                       
         MVI   HEXERR+1,X'00'                                                   
         CALL  DLUIOXPF                                                         
         B     GOBACK                                                           
         SPACE 2                                                                
********P**************************************************************         
*     **P*     RETURN TO THE CALLING PROGRAM.                                   
********P**************************************************************         
         SPACE 1                                                                
GOBACK   EQU   *                                                                
         TMLEAVE RC=0                                                           
         SPACE 2                                                                
         LTORG                                                                  
         EJECT                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         EJECT                                                                  
         COPY  DLUIOFLA                                                         
         END                                                                    
