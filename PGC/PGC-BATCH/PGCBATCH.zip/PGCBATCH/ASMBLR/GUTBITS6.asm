*********************************************************************** 00000100
*           15MAR2008   -  IBM GR    - ENTERPRISE COMPILER UPGRADE    * 00000200
*                                      PROJECT - BUNDLE 5             * 00000300
*********************************************************************** 00000400
*                         GUTBITS6                                   *  00020000
*                                                                    *  00030000
*     THIS ROUTINE WILL TRANSLATE INFORMATION FROM AN 8 BIT          *  00040000
*     REPRESENTATION TO 6 BITS AND BACK.  SINCE 6 BITS WILL          *  00050000
*     REPRESENT ONLY 64 CHARACTERS THERE IS OBVIOUSLY A              *  00060000
*     RESTRICTION AS TO WHAT CHARACTERS CAN BE TRANSLATED.           *  00070000
*     THE CHARACTERS WORKED ON BY THIS ROUTINE ARE;                  *  00080000
*                                                                    *  00090000
*         A THRU Z (UPPER CASE)                                      *  00100000
*         0 THRU 9                                                   *  00110000
*         SPACE                                                      *  00120000
*         LOW-VALUES (TRANSLATES TO A SPACE)                         *  00130000
*         ! @ # $ % & * ( ) - + = \ ; : ' " , . / ? < >              *  00140000
*                                                                    *  00150000
*     THIS IS A TOTAL OF 60 CHARACTERS LEAVING 4 FOR FUTURE USE.     *  00160000
*                                                                    *  00170000
*     THIS ROUTINE IS CALLED WITH FOUR PARAMETERS AS FOLLOWS;        *  00180000
*                                                                    *  00190000
*     CALL 'GUTBITS6' USING  FUNCTION-CODE                           *  00200000
*                            NUMBER-OF-CHARACTERS                    *  00210000
*                            CONDENSED-AREA                          *  00220000
*                            EXPANDED-AREA                           *  00230000
*                                                                    *  00240000
*     FUNCTION CODE - ONE BYTE ALPANUMERIC FIELD                     *  00250000
*                   - E TO EXPAND THE CONDENSED AREA (6 TO 8 BITS)   *  00260000
*                     C TO CONDENSE THE EXPANDED AREA (8 TO 6 BITS)  *  00270000
*                   - IF AN ERROR OCCURS A RETURN CODE IS PLACED     *  00280000
*                     IN THIS FIELD                                  *  00290000
*                       "1" - NUMBER OF CHARACTERS LESS THAN 2       *  00300000
*                       "2" - INVALID FUNCTION CODE                  *  00310000
*                       "3" - INVALID CHARACTER                      *  00320000
*     NUMBER OF CHARACTERS - HALFWORD BINARY FIELD CONTAINING THE    *  00330000
*                            NUMBER OF CHARACTERS (NOT BYTES) TO     *  00340000
*                            BE WORKED ON.  SHOULD BE EQUAL TO THE   *  00350000
*                            SIZE OF THE EXPANDED AREA. MUST BE      *  00360000
*                            BETWEEN 2 AND 4096                      *  00370000
*     CONDENSED AREA - AREA CONTAINING / TO CONTAIN THE 6 BIT        *  00380000
*                      REPRESENTATION TO THE DATA                    *  00390000
*     EXPANDED AREA  - AREA CONTAINING / TO CONTAIN THE 8 BIT        *  00400000
*                      REPRESENTATION TO THE DATA                    *  00410000
* ****************************************************************** *  00420000
         EJECT                                                          00430004
*        ENTRY GUTBITS6                                                 00440012
GUTBITS6 START                                                          00441009
GUTBITS6 AMODE 31                                                       00441105
GUTBITS6 RMODE ANY                                                      00442017
         PRINT NOGEN                                                    00450000
*        DC    CL8'GUTBITS6'           PROGRAM NAME                     00460009
*        DC    CL8'&SYSDATE'           PROGRAM ASSEMBLE DATE            00470009
         REGEQU                                                         00480000
*    R1                        CALLERS PARAMETER STRING                 00490000
*    R2                        FUNCTION / ERROR CODE                    00500000
*    R3                        NUMBER OF CHARACTERS TO BE WORKED ON     00510000
*    R4                        CONDENSED AREA                           00520000
*    R5                        EXPANDED AREA                            00530000
*    R6                        LOOP CONTROL REGISTER (BCT)              00540000
*    R7                        BRANCH CONTROL REGISTER (WHICH LOOP)     00550000
*    R8                        WORK REGISTER FOR SHIFT LOGICAL          00560000
*    R13                       CALLER'S SAVE AREA                       00570000
*    R14                       CALLER'S RETURN ADDRESS                  00580000
*    R15                       CALLED ADDRESS (PROGRAM BASE REGISTER)   00590000
         SPACE 4                                                        00600000
* ****************************************************** *              00610000
*   INITIALIZATION AND PARAMETER CHECKING                *              00620000
* ****************************************************** *              00630000
GUTBITS6 CSECT                                                          00640016
         USING *,R15                                                    00640116
         STM   R14,R12,12(R13)      SAVE CALLER'S REGISTERS             00641003
         LM    R2,R5,0(R1)          LOAD PASSED PARAMETERS              00670000
         MVC   HALFWORK,0(R3)       MOVE LENGTH TO HALFWORD             00680000
         L     R6,FULLWORK          LOAD LOOP CONTROL WITH LENGTH       00690000
         CH    R6,HALF02            MORE THAN 1 DIGIT                   00700000
         BL    ERRLNGTH             NO - INVALID LENGTH                 00710000
         CH    R6,HALF4096          MORE THAN 4096 DIGITS               00720000
         BH    ERRLNGTH             YES - INVALID LENGTH                00730000
         SR    R7,R7                SET BRANCH CONTOL TO ZERO           00740000
         CLI   0(R2),C'C'           IS THIS A CONDENSE FUNCTION         00750000
         BE    CONDENSE             YES - GO TO CONDENSE ROUTINE        00760000
         CLI   0(R2),C'E'           IS THIS AN EXPAND FUNCTION          00770000
         BNE   ERRFUNCT             NO - INVALID FUNCTION               00780000
         EJECT                                                          00790000
* ****************************************************** *              00800000
*   EXPAND ROUTINES                                      *              00810000
* ****************************************************** *              00820000
EXPAND   DS    0H            EXPAND FUNCTION                            00830000
         MVC   HALFWORK,0(R4)       MOVE 6 BITS TO CONVERTED            00840000
         SR    R8,R8                CLEAR WORK REGISTER                 00850000
         LA    R7,4(R7)             BUMP BRANCH CONTROL BY BR LENGTH    00860000
         B     EXPDBRCH(R7)         BRANCH TO PROPER BRANCH (R7)        00870000
EXPDBRCH DC    XL4'00'                                                  00880000
EXPDBEG1 B     EXPD0001             NEED TO SHIFT 10 BITS               00890000
EXPDBEG2 B     EXPD0002             NEED TO SHIFT  4 BITS               00900000
EXPDBEG3 B     EXPD0003             NEED TO SHIFT  6 BITS               00910000
EXPDBEG4 B     EXPD0004             NEED TO SHIFT  0 BITS               00920000
EXPD0001 DS    0H                                                       00930000
         NC    HALFWORK,BITS10      NULL ALL BITS BUT 6 TO CONVERT      00940000
         L     R8,FULLWORK          PUT 6 BIT REPRESENTATION IN R8      00950000
         SRL   R8,10(0)             SHIFT 6 BITS BY 10                  00960000
         STH   R8,HALFWORK          STORE SHIFTED VALUE IN HALFWORD     00970000
         B     EXPDBUMP             GO SAVE EXPANDED CHARACTER          00980000
EXPD0002 DS    0H                                                       00990000
         NC    HALFWORK,BITS04      NULL ALL BITS BUT 6 TO CONVERT      01000000
         L     R8,FULLWORK          PUT 6 BIT REPRESENTATION IN R8      01010000
         SRL   R8,4(0)              SHIFT 6 BITS BY 4                   01020000
         STH   R8,HALFWORK          STORE SHIFTED VALUE IN HALFWORD     01030000
         LA    R4,1(R4)             POINT TO NEXT CONDENSED BYTE        01040000
         B     EXPDBUMP             GO SAVE EXPANDED CHARACTER          01050000
EXPD0003 DS    0H                                                       01060000
         NC    HALFWORK,BITS06      NULL ALL BITS BUT 6 TO CONVERT      01070000
         L     R8,FULLWORK          PUT 6 BIT REPRESENTATION IN R8      01080000
         SRL   R8,6(0)              SHIFT 6 BITS BY 6                   01090000
         STH   R8,HALFWORK          STORE SHIFTED VALUE IN HALFWORD     01100000
         B     EXPDBUMP             GO SAVE EXPANDED CHARACTER          01110000
EXPD0004 DS    0H                                                       01120000
         SR    R7,R7                RESET BRANCH CONTROL TO 1ST LOOP    01130000
         NC    HALFWORK,BITS00      NULL ALL BITS BUT 6 TO CONVERT      01140000
         LA    R4,2(R4)             POINT TO NEXT CONDENSED BYTE        01150000
EXPDBUMP DS    0H                                                       01160000
         TR    HALFWORK+1(1),TABEXPD TRANSLATE 6 BITS TO 8 BITS         01170000
         CLI   HALFWORK+1,X'00'     DID BYTE TRANSLATE                  01180000
         BE    ERRTRANS             NO - INVALID CHARACTER              01190000
         MVC   0(1,R5),HALFWORK+1   MOVE BYTE TO EXPANDED AREA          01200000
         LA    R5,1(R5)             POINT TO NEXT EXPAND BYTE           01210000
         BCT   R6,EXPAND            GO GET ANOTHER CHARACTER            01220000
         B     PROGRTRN             ALL DONE - HIT THE ROAD             01230000
         EJECT                                                          01240000
* ****************************************************** *              01250000
*   CONDENSE ROUTINES                                    *              01260000
* ****************************************************** *              01270000
CONDENSE DS    0H            CONDENSE FUNCTION                          01280000
         MVC   HALFWORK,HALF00      INITIALIZE 2 BYTE WORK FIELD        01290000
         MVC   HALFWORK+1(1),0(R5)  MOVE BYTE TO CONVERTED              01300000
         TR    HALFWORK+1(1),TABCOND TRANSLATE 8 BITS TO 6 BITS         01310000
         CLI   HALFWORK+1,X'FF'     DID BYTE TRANSLATE                  01320000
         BE    ERRTRANS             NO - INVALID CHARACTER              01330000
         SR    R8,R8                CLEAR WORK REGISTER                 01340000
         L     R8,FULLWORK          PUT 6 BIT REPRESENTATION IN R8      01350000
         LA    R7,4(R7)             BUMP BRANCH CONTROL BY BR LENGTH    01360000
         B     CONDBRCH(R7)         BRANCH TO PROPER BRANCH (R7)        01370000
CONDBRCH DC    XL4'00'                                                  01380000
CONDBEG1 B     COND0001             NEED TO SHIFT 10 BITS               01390000
CONDBEG2 B     COND0002             NEED TO SHIFT  4 BITS               01400000
CONDBEG3 B     COND0003             NEED TO SHIFT  6 BITS               01410000
CONDBEG4 B     COND0004             NEED TO SHIFT  0 BITS               01420000
COND0001 DS    0H                                                       01430000
         MVI   0(R4),X'00'          INITIALIZE 1ST OUTPUT BYTE          01440000
         SLL   R8,10(0)             SHIFT 6 BITS BY 10                  01450000
         STH   R8,HALFWORK          STORE SHIFTED VALUE IN HALFWORD     01460000
         NC    HALFWORK,BITS10      NULL ALL BITS BUT 6 TO STORE        01470000
         OC    0(2,R4),HALFWORK     INSERT SHIFTED VALUE IN BIT STR     01480000
         B     CONDBUMP             GO GET ANOTHER CHARACTER            01490000
COND0002 DS    0H                                                       01500000
         MVI   1(R4),X'00'          INITIALIZE 2ND OUTPUT BYTE          01510000
         SLL   R8,4(0)              SHIFT 6 BITS BY 4                   01520000
         STH   R8,HALFWORK          STORE SHIFTED VALUE IN HALFWORD     01530000
         NC    HALFWORK,BITS04      NULL ALL BITS BUT 6 TO STORE        01540000
         OC    0(2,R4),HALFWORK     INSERT SHIFTED VALUE IN BIT STR     01550000
         LA    R4,1(R4)             POINT TO NEXT CONDENSED BYTE        01560000
         B     CONDBUMP             GO GET ANOTHER CHARACTER            01570000
COND0003 DS    0H                                                       01580000
         MVI   1(R4),X'00'          INITIALIZE 3RD OUTPUT BYTE          01590000
         SLL   R8,6(0)              SHIFT 6 BITS BY 6                   01600000
         STH   R8,HALFWORK          STORE SHIFTED VALUE IN HALFWORD     01610000
         NC    HALFWORK,BITS06      NULL ALL BITS BUT 6 TO STORE        01620000
         OC    0(2,R4),HALFWORK     INSERT SHIFTED VALUE IN BIT STR     01630000
         B     CONDBUMP             GO GET ANOTHER CHARACTER            01640000
COND0004 DS    0H                                                       01650000
         SR    R7,R7                RESET BRANCH CONTROL TO 1ST LOOP    01660000
         NC    HALFWORK,BITS00      NULL ALL BITS BUT 6 TO STORE        01670000
         OC    0(2,R4),HALFWORK     INSERT UNSHIFTED VALUE IN BIT STR   01680000
         LA    R4,2(R4)             POINT TO NEXT CONDENSED BYTE        01690000
CONDBUMP DS    0H                                                       01700000
         LA    R5,1(R5)             POINT TO NEXT EXPAND BYTE           01710000
         BCT   R6,CONDENSE          GO GET ANOTHER CHARACTER            01720000
         B     PROGRTRN             ALL DONE - HIT THE ROAD             01730000
         EJECT                                                          01740000
* ****************************************************** *              01750000
*   ERROR ROUTINES                                       *              01760000
* ****************************************************** *              01770000
ERRLNGTH DS    0H                                                       01780000
         MVI   0(R2),X'F1'          INDICATE LENGTH ERROR               01790000
         B     PROGRTRN             ALL DONE - HIT THE ROAD             01800000
ERRFUNCT DS    0H                                                       01810000
         MVI   0(R2),X'F2'          INDICATE FUNCTION ERROR             01820000
         B     PROGRTRN             ALL DONE - HIT THE ROAD             01830000
ERRTRANS DS    0H                                                       01840000
         MVI   0(R2),X'F3'          INDICATE TRANSLATE ERROR            01850000
         SPACE 4                                                        01860000
* ****************************************************** *              01870000
*   RETURN TO CALLER ROUTINE                             *              01880000
* ****************************************************** *              01890000
PROGRTRN DS    0H                                                       01900000
         LM    R14,R12,12(R13)      RESTORE CALLER'S REGISTERS          01910000
         SR    R15,R15              SET R15 TO ZERO                     01920000
         BR    R14                  RETURN TO CALLER                    01930000
         EJECT                                                          01940000
         LTORG                                                          01950000
FULLWORK DS    0F                                                       01960000
HALF00   DC    H'0'                                                     01970000
HALFWORK DC    H'0'                                                     01980000
HALF02   DC    H'2'                                                     01990000
HALF4096 DC    H'4096'                                                  02000000
SAVEAREA DS    18F                                                      02001013
STOR13   DS    F                                                        02002013
BITS10   DC    BL2'1111110000000000'                                    02010000
BITS04   DC    BL2'0000001111110000'                                    02020000
BITS06   DC    BL2'0000111111000000'                                    02030000
BITS00   DC    BL2'0000000000111111'                                    02040000
         EJECT                                                          02050000
* ***************************************************************** *   02060000
*        EXPANDED TO CONDENSED VALUES TABLE                         *   02070000
* ***************************************************************** *   02080000
TABCOND  DS    0F                                                       02090000
*                    40                                                 02100000
TBCOND00 DC    1XL16'00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'                  02110000
         DC    3XL16'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'                  02120000
*                    40                     . < ( +                     02130000
TBCOND40 DC    1XL16'00FFFFFFFFFFFFFFFFFFFF2D3A1A1DFF'                  02140000
*                     &                   ! $ * ) ;                     02150000
TBCOND50 DC    1XL16'0FFFFFFFFFFFFFFFFFFF0A0D101B20FF'                  02160000
*                     - /                   , %   > ?                   02170000
TBCOND60 DC    1XL16'1C2EFFFFFFFFFFFFFFFFFF2C0EFF3B2F'                  02180000
*                                         : # @ ' = "                   02190000
TBCOND70 DC    1XL16'FFFFFFFFFFFFFFFFFFFF210C0B2A1E2B'                  02200000
         DC    4XL16'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'                  02210000
*                       A B C D E F G H I                               02220000
TBCONDC0 DC    1XL16'FF010203040506070809FFFFFFFFFFFF'                  02230000
*                       J K L M N O P Q R                               02240000
TBCONDD0 DC    1XL16'FF111213141516171819FFFFFFFFFFFF'                  02250000
*                     \   S T U V W X Y Z                               02260000
TBCONDE0 DC    1XL16'1FFF2223242526272829FFFFFFFFFFFF'                  02270000
*                     0 1 2 3 4 5 6 7 8 9                               02280000
TBCONDF0 DC    1XL16'30313233343536373839FFFFFFFFFFFF'                  02290000
         SPACE 4                                                        02300000
* ***************************************************************** *   02310000
*        CONDENSED  TO  EXPANDED VALUES TABLE                       *   02320000
* ***************************************************************** *   02330000
TABEXPD  DS    0F                                                       02340000
*                       A B C D E F G H I ! @ # $ % &                   02350000
TBEXPD00 DC    1XL16'40C1C2C3C4C5C6C7C8C95A7C7B5B6C50'                  02360000
*                     * J K L M N O P Q R ( ) - + = \                   02370000
TBEXPD10 DC    1XL16'5CD1D2D3D4D5D6D7D8D94D5D604E7EE0'                  02380000
*                     ; : S T U V W X Y Z ' " , . / ?                   02390000
TBEXPD20 DC    1XL16'5E7AE2E3E4E5E6E7E8E97D7F6B4B616F'                  02400000
*                     0 1 2 3 4 5 6 7 8 9 < >                           02410000
TBEXPD30 DC    1XL16'F0F1F2F3F4F5F6F7F8F94C6E00000000'                  02420000
         DC    12XL16'00'                                               02430000
         END                                                            02440000
