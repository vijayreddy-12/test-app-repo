DLUIOVSM START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 0  - USED IN THE VSAM MACROS                                        
*  REGISTER 1  - USED IN THE VSAM MACROS                                        
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 7  - POINTS TO THE ACB                                              
*  REGISTER 8  - POINTS TO THE RPL                                              
*  REGISTER 9  - WORK REGISTER                                                  
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
         L     R7,ACBAREA                                                       
         L     R8,RPLAREA                                                       
*                                                                               
*  OPEN THE FILE IF NOT OPEN. IF THE FILE IS READ/WRITE AND CONTAINS            
*  FIXED LENGTH RECORDS PASS THE RECORD LENGTH TO VSAM AT THIS TIME.            
*                                                                               
         CLI   OPENIND,FILEOPEN                                                 
         BE    OPENED                                                           
         OPEN  ((7))                                                            
         LTR   R15,R15                                                          
         BNZ   OPENERR                                                          
         MVI   OPENIND,FILEOPEN                                                 
         CLI   DCBACBFA+2,C'I'                                                  
         BE    OPENED                                                           
         CLI   DCBACBFA+3,C'F'                                                  
         BNE   OPENED                                                           
         SHOWCB ACB=(7),OBJECT=DATA,AREA=(S,WORK4),LENGTH=4,           *        
               FIELDS=(LRECL)                                                   
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         L     R0,WORK4                                                         
         LR    R1,R8                                                            
         MODCB RPL=(1),RECLEN=(0)                                               
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
*                                                                               
*  THE FILE IS OPEN OR HAS JUST BEEN OPENED. REFRESH THE POINTERS               
*  TO THE KEY AND IO AREA (IN CASE THE APPLICATION PROGRAM IS USING             
*  MORE THAN 1 AREA) AND THEN GO TO THE APPROPRIATE ROUTINE FOR THE             
*  REQUEST.                                                                     
*                                                                               
OPENED   EQU   *                                                                
         LA    R9,KEY                                                           
         MODCB RPL=(8),ARG=(9),AREA=(4)                                         
         LA    R9,FUNCTABL                                                      
         L     R10,NUMFUNCS                                                     
OPENEDA  EQU   *                                                                
         CLC   FUNCTION,0(R9)                                                   
         BE    OPENEDB                                                          
         LA    R9,12(R9)                                                        
         BCT   R10,OPENEDA                                                      
         MVC   ERRCODE,=C'E2    '                                               
         B     GOBACK                                                           
OPENEDB  EQU   *                                                                
         L     R10,8(R9)                                                        
         BR    R10                                                              
*                                                                               
*  READ THE NEXT RECORD (FORWARD OR BACKWARD).                                  
*                                                                               
GETSEQ   EQU   *                                                                
         BAL   R9,GET                                                           
         AP    SVREAD,=P'1'                                                     
         B     GOBACK                                                           
*                                                                               
*  READ THE RECORD WHOSE KEY MATCHES THE KEY PASSED.                            
*                                                                               
GETRAN   EQU   *                                                                
         MODCB RPL=(8),OPTCD=(DIR,KEQ)                                          
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         BAL   R9,GET                                                           
         AP    SVREAD,=P'1'                                                     
         B     GOBACK                                                           
*                                                                               
*  UPDATE THE RECORD THAT WAS LAST READ. FOR VARIABLE LENGTH RECORDS            
*  THE LENGTH IS RESET (REGARDLESS OF A CHANGE IN LENGTH OR NOT).               
*                                                                               
PUTUPD   EQU   *                                                                
         CLI   DCBACBFA+3,C'F'                                                  
         BE    PUTUPDA                                                          
         ZAP   WORK4(8),RECLGTH                                                 
         CVB   R0,WORK4                                                         
         LR    R1,R8                                                            
         MODCB RPL=(1),RECLEN=(0)                                               
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
PUTUPDA  EQU   *                                                                
         BAL   R9,PUTU                                                          
         AP    SVUPDATE,=P'1'                                                   
         B     GOBACK                                                           
*                                                                               
*  ADD RANDOM. ASSUME FORWARD DIRECTION. THE OPTION CODE MUST BE 'NUP'          
*  FOR AN ADD. THIS OPTION IS CHANGED BACK TO 'UPD' IN LOGIC PUTA FOR           
*  SUBSEQUENT PROCESSING. IF WRITING A VARIABLE LENGTH RECORD SET THE           
*  RECORD LENGTH.                                                               
*                                                                               
ADDRAN   EQU   *                                                                
         MODCB RPL=(8),OPTCD=(DIR,FWD,NUP)                                      
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         CLI   DCBACBFA+3,C'F'                                                  
         BE    ADDRANA                                                          
         ZAP   WORK4(8),RECLGTH                                                 
         CVB   R0,WORK4                                                         
         LR    R1,R8                                                            
         MODCB RPL=(1),RECLEN=(0)                                               
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
ADDRANA  EQU   *                                                                
         BAL   R9,PUTA                                                          
         AP    SVWRITE,=P'1'                                                    
         B     GOBACK                                                           
*                                                                               
*  ADD SEQUENTIAL. THE OPTION CODE MUST BE 'NUP' FOR AN ADD. THIS               
*  OPTION IS CHANGED BACK TO 'UPD' IN LOGIC PUTA FOR SUBSEQUENT                 
*  PROCESSING. IF WRITING A VARIABLE LENGTH RECORD SET THE RECORD               
*  LENGTH.                                                                      
*                                                                               
ADDSEQ   EQU   *                                                                
         MODCB RPL=(8),OPTCD=(SEQ,NUP)                                          
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         CLI   DCBACBFA+3,C'F'                                                  
         BE    ADDSEQA                                                          
         ZAP   WORK4(8),RECLGTH                                                 
         CVB   R0,WORK4                                                         
         LR    R1,R8                                                            
         MODCB RPL=(1),RECLEN=(0)                                               
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
ADDSEQA  EQU   *                                                                
         BAL   R9,PUTA                                                          
         AP    SVWRITE,=P'1'                                                    
         B     GOBACK                                                           
*                                                                               
*  DELETE THE RECORD THAT WAS LAST READ.                                        
*                                                                               
DELETE   EQU   *                                                                
         BAL   R9,ERASE                                                         
         AP    SVDELETE,=P'1'                                                   
         B     GOBACK                                                           
*                                                                               
*  SET THE LOWER LIMIT FOR SUBSEQUENT FORWARD SEQUENTIAL READING.               
*                                                                               
SETLIM   EQU   *                                                                
         MODCB RPL=(8),OPTCD=(SEQ,FWD,KGE)                                      
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         BAL   R9,POINT                                                         
         B     GOBACK                                                           
*                                                                               
*  SET THE UPPER LIMIT FOR SUBSEQUENT BACKWARD SEQUENTIAL READING.              
*  IF THE PASSED KEY CONTAINS HIGH VALUES SET THE OPTION CODE TO 'LRD'.         
*                                                                               
SETBWD   EQU   *                                                                
         MODCB RPL=(8),OPTCD=(SEQ,BWD,KEQ)                                      
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         L     R9,=F'4'                                                         
         CLC   ACCTYPE,=C'KEYED'                                                
         BNE   SETBWDA                                                          
         SHOWCB ACB=(7),OBJECT=DATA,AREA=(S,WORK4),LENGTH=4,           *        
               FIELDS=(KEYLEN)                                                  
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         L     R9,WORK4                                                         
         LTR   R9,R9                                                            
         BNP   SETBWDB                                                          
SETBWDA  EQU   *                                                                
         BCTR  R9,R0                                                            
         EX    R9,COMPHIGH                                                      
         BNE   SETBWDB                                                          
         MODCB RPL=(8),OPTCD=(LRD)                                              
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
SETBWDB  EQU   *                                                                
         BAL   R9,POINT                                                         
         B     GOBACK                                                           
COMPHIGH CLC   HIVALS(0),KEY                                                    
*                                                                               
*  CALL ROUTINE DLUIOCLO TO CLOSE THE FILE(S).                                  
*                                                                               
CLOSEIT  EQU   *                                                                
         CALL  DLUIOCLO                                                         
*                                                                               
*  RETURN THE RECORD COUNTS. THEN RETURN TO THE CALLING PROGRAM.                
*                                                                               
GOBACK   EQU   *                                                                
         DROP  R3                                                               
         USING DLUIOPR1,R9                                                      
         L     R9,PARM1ADR                                                      
         MVC   READCT,SVREAD                                                    
         MVC   WRITECT,SVWRITE                                                  
         MVC   UPDATECT,SVUPDATE                                                
         MVC   DELETECT,SVDELETE                                                
         DROP  R9                                                               
         USING DLUIOPR1,R3                                                      
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  REQUEST MACROS. ROUTINE GET RETURNS THE RECORD LENGTH IF VARAIBLE.           
*  ROUTINE PUTU UPDATES RECORDS. ROUTINE PUTA ADDS RECORDS. SEPARATE            
*  ROUTINES ARE REQUIRED BECAUSE THE OPTION CODE MUST BE CHANGED BACK           
*  TO 'UPD' AFTER AN ADD. THE OPTION CODE IS SET TO 'ARD' AFTER A POINT         
*  (IT MAY HAVE BEEN 'LRD'). RETURN THE RBA WHERE REQUIRED.                     
*                                                                               
GET      EQU   *                                                                
         GET   RPL=(8)                                                          
         LTR   R15,R15                                                          
         BNZ   REQERR                                                           
         CLI   DCBACBFA+3,C'F'                                                  
         BE    RETRBA                                                           
         SHOWCB RPL=(8),AREA=(S,WORK4),LENGTH=4,FIELDS=(RECLEN)                 
         L     R10,WORK4                                                        
         CVD   R10,WORK4                                                        
         ZAP   RECLGTH,WORK4(8)                                                 
         B     RETRBA                                                           
PUTU     EQU   *                                                                
         PUT   RPL=(8)                                                          
         LTR   R15,R15                                                          
         BNZ   REQERR                                                           
         B     RETRBA                                                           
PUTA     EQU   *                                                                
         PUT   RPL=(8)                                                          
         LR    R10,R15                                                          
         MODCB RPL=(8),OPTCD=(UPD)                                              
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         LR    R15,R10                                                          
         LTR   R15,R15                                                          
         BNZ   REQERR                                                           
         B     RETRBA                                                           
POINT    EQU   *                                                                
         POINT RPL=(8)                                                          
         LR    R10,R15                                                          
         MODCB RPL=(8),OPTCD=(ARD)                                              
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         LR    R15,R10                                                          
         LTR   R15,R15                                                          
         BNZ   REQERR                                                           
         B     RETRBA                                                           
ERASE    EQU   *                                                                
         ERASE RPL=(8)                                                          
         LTR   R15,R15                                                          
         BNZ   REQERR                                                           
         BR    R9                                                               
RETRBA   EQU   *                                                                
         CLC   ACCTYPE,=C'ENTRY'                                                
         BNER  R9                                                               
         SHOWCB RPL=(8),AREA=(S,WORK4),LENGTH=4,FIELDS=(RBA)                    
         LTR   R15,R15                                                          
         BNZ   MANIPERR                                                         
         MVC   KEY(4),WORK4                                                     
         BR    R9                                                               
*                                                                               
*  ERROR ENCOUNTERED WHILE OPENING A FILE.                                      
*                                                                               
OPENERR  EQU   *                                                                
         MVC   ERRCODE(2),=C'E6'                                                
         STC   R15,HEXERR                                                       
         SHOWCB ACB=(7),AREA=(S,WORK4),LENGTH=4,FIELDS=(ERROR)                  
         MVC   HEXERR+1(1),WORK4+3                                              
         CALL  DLUIOXPF                                                         
         B     GOBACK                                                           
*                                                                               
*  ERROR ENCOUNTERED WHILE EXECUTING A REQUEST MACRO.                           
*                                                                               
REQERR   EQU   *                                                                
         MVC   ERRCODE(2),=C'E7'                                                
         STC   R15,HEXERR                                                       
         SHOWCB RPL=(8),AREA=(S,WORK4),LENGTH=4,FIELDS=(FDBK)                   
         MVC   HEXERR+1(1),WORK4+3                                              
         CALL  DLUIOXPF                                                         
         B     GOBACK                                                           
*                                                                               
*  ERROR ENCOUNTERED WHILE EXECUTING ONE OF THE CONTROL BLOCK                   
*  MANIPULATOR MACROS.                                                          
*                                                                               
MANIPERR EQU   *                                                                
         MVC   ERRCODE(2),=C'E5'                                                
         STC   R15,HEXERR                                                       
         STC   R0,HEXERR+1                                                      
         CALL  DLUIOXPF                                                         
         B     GOBACK                                                           
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOVSM EYECATCHER *****'                               
MYSAVE   DS    18F                THIS PROGRAM'S SAVE AREA                      
HIVALS   DC    255X'FF'           MAXIMUM LENGTH KEY OF HIGH VALUES             
NUMFUNCS DC    F'10'              NUMBER OF FUNCTIONS IN THE TABLE              
FUNCTABL DC    CL6'GETSEQ',CL2'  ',A(GETSEQ)                                    
         DC    CL6'GETRAN',CL2'  ',A(GETRAN)                                    
         DC    CL6'PUTUPD',CL2'  ',A(PUTUPD)                                    
         DC    CL6'ADDRAN',CL2'  ',A(ADDRAN)                                    
         DC    CL6'ADDSEQ',CL2'  ',A(ADDSEQ)                                    
         DC    CL6'DELETE',CL2'  ',A(DELETE)                                    
         DC    CL6'SETLIM',CL2'  ',A(SETLIM)                                    
         DC    CL6'SETBWD',CL2'  ',A(SETBWD)                                    
         DC    CL6'CLOFIL',CL2'  ',A(CLOSEIT)                                   
         DC    CL6'CLOALL',CL2'  ',A(CLOSEIT)                                   
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
