GACCDBEN START                                                                  
         ENTRY GACCDB01,GACCDB02,GACCDB03,GACCDB04,GACCDB05                     
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - POINTS TO BENEFIT CODE                                         
*  REGISTER 4  - POINTS TO BENEFIT CODE RECORD                                  
*  REGISTER 5  - POINTS TO ERROR CODE                                           
*  REGISTER 6  - POINTS TO LANGUAGE CODE                                        
*  REGISTER 7  - POINTS TO RECORD COUNT                                         
*  REGISTER 8  - USED IN BAL INSTRUCTIONS                                       
*  REGISTER 9  - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*                                                                               
GACCDB01 DS    0H                                                               
         NOPR  0                                                                
GACCDB02 DS    0H                                                               
         NOPR  0                                                                
GACCDB03 DS    0H                                                               
         NOPR  0                                                                
GACCDB04 DS    0H                                                               
         NOPR  0                                                                
GACCDB05 DS    0H                                                               
         NOPR  0                                                                
*                                                                               
*  SET UP THE BASE REGISTERS AND DO THE HOUSEKEEPING.                           
*                                                                               
         STM   R14,R12,12(R13)                                                  
         BALR  R11,0                                                            
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING GACCP1,R3                                                        
         USING GACCP2,R4                                                        
         USING GACCP3,R5                                                        
         USING GACCP4,R6                                                        
         USING GACCP5,R7                                                        
*                                                                               
*  SAVE THE ADDRESS OF THE PASSED PARAMETER LIST FOR LATER USE.                 
*  DETERMINE THE ADDRESS OF THE LOGIC TO BE ENTERED. IF THIS IS                 
*  THE FIRST PASS DETERMINE THE ACBNAME. IF THE FILE IS NOT OPEN                
*  THEN ISSUE TWO SETLIM OPERATIONS ON THE FILE. THIS GETS AROUND               
*  ANY OPEN ERRORS THAT MAY OCCUR ON THE FIRST OPEN TRY.                        
*                                                                               
         ST    R1,SAVER1                                                        
         LA    R15,0(R15)                                                       
         S     R15,=A(GACCDB01)                                                 
         SLL   R15,1                                                            
         L     R9,INDADDR(R15)                                                  
*                                                                               
GETACB   EQU   *                                                                
         CLI   FIRSTSW,C'N'                                                     
         BE    DOIOPEN                                                          
         MVI   FIRSTSW,C'N'                                                     
         MVC   ZACCACB,=C'VSDSI96'                                              
         RDJFCB WORKDCB                                                         
         LTR   R15,R15                                                          
         BZ    DOIOPEN                                                          
         MVC   ZACCACB,=C'VSDSO96'                                              
*                                                                               
DOIOPEN  EQU   *                                                                
         CLI   OPENSW,C'Y'                                                      
         BE    GODOIT                                                           
         MVI   OPENSW,C'Y'                                                      
         MVC   ZACCFUNC,=C'SETLIM'                                              
         XC    ZACCKEY,ZACCKEY                                                  
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
*                                                                               
GODOIT   EQU   *                                                                
         L     R1,SAVER1                                                        
         BR    R9                                                               
*                                                                               
*  GACCDB01 WAS CALLED. VERIFY THE BENEFIT CODE. CHANGE THE BENEFIT             
*  CODE TO THE FRENCH EQUIVALENT IF NECESSARY. THEN READ THE RECORD.            
*                                                                               
B01      EQU   *                                                                
         LM    R3,R6,0(R1)                                                      
         MVC   ERRCODE,BLANKS                                                   
         BAL   R8,CHKCODE                                                       
         CLC   ERRCODE,BLANKS                                                   
         BNE   GOBACK                                                           
         MVC   ZACCFUNC,=C'GETRAN'                                              
         MVC   ZACCKEY,BENCODE                                                  
         CLI   LANGCODE,C'F'                                                    
         BNE   B01A                                                             
         BAL   R8,FRENCH                                                        
         CLC   ERRCODE,BLANKS                                                   
         BNE   GOBACK                                                           
B01A     EQU   *                                                                
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         CLC   ZACCERR,LOWVALS                                                  
         BE    B01B                                                             
         MVC   ERRCODE,=C'S03'                                                  
         B     GOBACK                                                           
B01B     EQU   *                                                                
         MVC   BENREC,ZACCREC                                                   
         B     GOBACK                                                           
*                                                                               
*  GACCDB02 WAS CALLED. VERIFY THE BENEFIT CODE. IF THE RECORD                  
*  ALREADY EXISTS UPDATE IT. IF THE RECORD DOES NOT EXIST THEN                  
*  ADD IT TO THE FILE. IF THE BENEFIT CODE IN THE RECORD AREA                   
*  IS HIGH VALUES DELETE THE RECORD.                                            
*                                                                               
B02      EQU   *                                                                
         LM    R3,R5,0(R1)                                                      
         MVC   ERRCODE,BLANKS                                                   
         BAL   R8,CHKCODE                                                       
         CLC   ERRCODE,BLANKS                                                   
         BNE   GOBACK                                                           
         MVC   ZACCFUNC,=C'GETRAN'                                              
         MVC   ZACCKEY,BENCODE                                                  
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         CLC   ZACCERR,LOWVALS                                                  
         BE    B02A                                                             
         CLC   BENREC(2),=X'FFFF'                                               
         BE    GOBACK                                                           
         MVC   ZACCFUNC,=C'ADDRAN'                                              
         MVC   ZACCREC,BENREC                                                   
         B     B02B                                                             
B02A     EQU   *                                                                
         MVC   ZACCFUNC,=C'DELETE'                                              
         CLC   BENREC(2),=X'FFFF'                                               
         BE    B02B                                                             
         MVC   ZACCFUNC,=C'PUTUPD'                                              
         MVC   ZACCREC,BENREC                                                   
B02B     EQU   *                                                                
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         CLC   ZACCERR,LOWVALS                                                  
         BE    GOBACK                                                           
         MVC   ERRCODE,=C'S04'                                                  
         B     GOBACK                                                           
*                                                                               
*  GACCDB03 WAS CALLED. VERIFY THE BENEFIT CODE AND THEN SEE IF                 
*  THE RECORD EXISTS.                                                           
*                                                                               
B03      EQU   *                                                                
         L     R3,0(R1)                                                         
         L     R5,4(R1)                                                         
         MVC   ERRCODE,BLANKS                                                   
         BAL   R8,CHKCODE                                                       
         CLC   ERRCODE,BLANKS                                                   
         BNE   GOBACK                                                           
         MVC   ZACCFUNC,=C'GETRAN'                                              
         MVC   ZACCKEY,BENCODE                                                  
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         CLC   ZACCERR,LOWVALS                                                  
         BE    GOBACK                                                           
         MVC   ERRCODE,=C'S03'                                                  
         B     GOBACK                                                           
*                                                                               
*  GACCDB04 WAS CALLED. A SETLIM IS ISSUED TO POINT TO THE LAST                 
*  READ RECORD. THIS IS DONE SINE THE POINTER MAY HAVE BEEN CHANGED             
*  SINCE THE LAST CALL TO GACCDB04 ( E.G. A CALL TO GACCDB01 WILL               
*  CHANGE THE POINTER ). IF THE POINTER IS NOT AT THE BEGINNING OF              
*  THE FILE TWO RECORDS MUST BE READ IN ORDER TO READ PAST THE LAST             
*  READ RECORD. AT END OF FILE RETURN THE RECORD COUNT AND RESET                
*  THE SAVED BENEFIT CODE AND RECORD COUNTER IN CASE THEY CALL                  
*  GACCDB04 AGAIN.                                                              
*                                                                               
B04      EQU   *                                                                
         L     R4,0(R1)                                                         
         L     R5,4(R1)                                                         
         L     R7,8(R1)                                                         
         MVC   ERRCODE,BLANKS                                                   
         MVC   ZACCFUNC,=C'SETLIM'                                              
         MVC   ZACCKEY,SVCODE                                                   
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         CLC   ZACCERR,LOWVALS                                                  
         BNE   B04B                                                             
         MVC   ZACCFUNC,=C'GETSEQ'                                              
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         CLC   ZACCERR,LOWVALS                                                  
         BNE   B04B                                                             
         CLC   SVCODE,LOWVALS                                                   
         BE    B04A                                                             
         MVC   ZACCFUNC,=C'GETSEQ'                                              
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
         CLC   ZACCERR,LOWVALS                                                  
         BNE   B04B                                                             
B04A     EQU   *                                                                
         MVC   SVCODE,ZACCREC                                                   
         AP    SVCOUNT,=P'1'                                                    
         MVC   BENREC,ZACCREC                                                   
         B     GOBACK                                                           
B04B     EQU   *                                                                
         ZAP   RECCOUNT,SVCOUNT                                                 
         XC    SVCODE,SVCODE                                                    
         ZAP   SVCOUNT,=P'0'                                                    
         B     GOBACK                                                           
*                                                                               
*  GACCDB05 WAS CALLED. CLOSE THE FILE.                                         
*                                                                               
B05      EQU   *                                                                
         MVI   OPENSW,C'N'                                                      
         MVC   ZACCFUNC,=C'CLOFIL'                                              
         LA    R1,ZACCPARM                                                      
         CALL  ZACCVSAM                                                         
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         L     R13,MYSAVE+4                                                     
         LM    R14,R12,12(R13)                                                  
         BR    R14                                                              
*                                                                               
*  VALIDATE THE BENEFIT CODE.                                                   
*                                                                               
CHKCODE  EQU   *                                                                
         MVC   WORKCODE,BENCODE                                                 
         CLI   WORKCODE,C'0'                                                    
         BL    CHKCODEB                                                         
         CLI   WORKCODE,C'9'                                                    
         BH    CHKCODEB                                                         
CHKCODEA EQU   *                                                                
         TR    WORKCODE(1),TRTABLE1                                             
         TR    WORKCODE+1(1),TRTABLE2                                           
         B     CHKCODEC                                                         
CHKCODEB EQU   *                                                                
         TR    WORKCODE(1),TRTABLE2                                             
         TR    WORKCODE+1(1),TRTABLE1                                           
CHKCODEC EQU   *                                                                
         CLC   WORKCODE,=X'FFFF'                                                
         BER   R8                                                               
         MVC   ERRCODE,=C'S01'                                                  
         BR    R8                                                               
*                                                                               
*  CONVERT THE BENEFIT CODE IN ORDER TO READ THE FRENCH RECORD.                 
*                                                                               
FRENCH   EQU   *                                                                
         MVC   WORKCODE,BENCODE                                                 
         TR    WORKCODE(1),TRTABLE3                                             
         CLI   WORKCODE,X'00'                                                   
         BE    FRENCHA                                                          
         CLI   WORKCODE,X'FF'                                                   
         BE    FRENCHB                                                          
         MVC   ZACCKEY,WORKCODE                                                 
         BR    R8                                                               
FRENCHA  EQU   *                                                                
         MVC   ERRCODE,=C'S02'                                                  
         BR    R8                                                               
FRENCHB  EQU   *                                                                
         MVC   ERRCODE,=C'S05'                                                  
         BR    R8                                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
MYSAVE   DS    18F           THIS PROGRAM'S SAVE AREA                           
SAVER1   DS    F             PASSED PARAMETER ADDRESSES SAVED HERE              
*                                                                               
INDADDR  DC    A(B01)        ADDRESS OF GACCDB01 LOGIC                          
         DC    A(B02)        ADDRESS OF GACCDB02 LOGIC                          
         DC    A(B03)        ADDRESS OF GACCDB03 LOGIC                          
         DC    A(B04)        ADDRESS OF GACCDB04 LOGIC                          
         DC    A(B05)        ADDRESS OF GACCDB05 LOGIC                          
*                                                                               
FIRSTSW  DC    CL1'Y'        FIRST PASS INDICATOR                               
OPENSW   DC    CL1'N'        FILE OPEN/CLOSED INDICATOR                         
BLANKS   DC    3C' '                                                            
LOWVALS  DC    104X'00'                                                         
WORKCODE DS    CL2                                                              
*                                                                               
SVCODE   DC    XL2'0000'     LAST READ BENEFIT CODE DURING GACCDB04             
SVCOUNT  DC    PL4'0'        RECORDS READ DURING GACCDB04                       
*                                                                               
*  TRANSLATE TABLES.                                                            
*                                                                               
         DS    0F                                                               
TRTABLE1 DC    256X'00'                                                         
         ORG   TRTABLE1+C'0'                                                    
         DC    10X'FF'                                                          
         ORG                                                                    
TRTABLE2 DC    256X'00'                                                         
         ORG   TRTABLE2+C'A'                                                    
         DC    8X'FF'                                                           
         ORG   TRTABLE2+C'J'                                                    
         DC    5X'FF'                                                           
         ORG   TRTABLE2+C'P'                                                    
         DC    3X'FF'                                                           
         ORG   TRTABLE2+C'S'                                                    
         DC    8X'FF'                                                           
         ORG                                                                    
TRTABLE3 DC    256X'00'                                                         
         ORG   TRTABLE3+C'0'                                                    
         DC    C'345'                                                           
         DC    3X'FF'                                                           
         ORG   TRTABLE3+C'6'                                                    
         DC    C'89'                                                            
         DC    2X'FF'                                                           
         ORG                                                                    
*                                                                               
*  ZACCVSAM PARAMETERS.                                                         
*                                                                               
ZACCPARM DC    A(ZACCACB)                                                       
         DC    A(ZACCKEY)                                                       
         DC    X'80'                                                            
         DC    AL3(ZACCREC)                                                     
         DS    0F                                                               
ZACCACB  DS    CL7                                                              
         DC    CL5'KEYED'                                                       
         DC    CL1'F'                                                           
ZACCFUNC DS    CL6                                                              
ZACCERR  DS    CL5                                                              
ZACCREAD DS    PL4                                                              
ZACCWRIT DS    PL4                                                              
ZACCUPDT DS    PL4                                                              
ZACCDELT DS    PL4                                                              
         DS    0F                                                               
ZACCKEY  DS    CL2                                                              
         DS    0F                                                               
ZACCREC  DS    CL37                                                             
*                                                                               
         DS    0D                                                               
WORKDCB  DCB   DDNAME=VSDSI96,                                         C        
               DSORG=PS,                                               C        
               EXLST=JFCBXIT,                                          C        
               MACRF=(PM)                                                       
*                                                                               
         DS    0F                                                               
JFCBXIT  DC    XL1'07',AL3(JFCBAREA)                                            
         DC    XL4'80000000'                                                    
*                                                                               
         DS    0F                                                               
JFCBAREA DS    CL176                                                            
*                                                                               
         LTORG                                                                  
*                                                                               
*  BENEFIT CODE.                                                                
*                                                                               
GACCP1   DSECT                                                                  
BENCODE  DS    CL2                                                              
*                                                                               
*  BENEFIT CODE RECORD.                                                         
*                                                                               
GACCP2   DSECT                                                                  
BENREC   DS    CL37                                                             
*                                                                               
*  ERROR CODE.                                                                  
*                                                                               
GACCP3   DSECT                                                                  
ERRCODE  DS    CL3                                                              
*                                                                               
*  LANGUAGE CODE.                                                               
*                                                                               
GACCP4   DSECT                                                                  
LANGCODE DS    CL1                                                              
*                                                                               
*  RECORD COUNT.                                                                
*                                                                               
GACCP5   DSECT                                                                  
RECCOUNT DS    PL4                                                              
         END                                                                    
