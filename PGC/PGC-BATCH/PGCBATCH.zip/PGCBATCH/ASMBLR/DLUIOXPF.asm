DLUIOXPF START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  CONVERT THE 2 BYTES IN HEXERR TO READABLE FORM. THE RESULT IS                
*  STORED IN ERRCODE.                                                           
*                                                                               
         UNPK  WORK1(5),HEXERR(3)                                               
         MVC   ERRCODE+2(4),WORK1                                               
         NC    ERRCODE+2(4),MASK                                                
         TR    ERRCODE+2(4),TABLE                                               
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOXPF EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
MASK     DC    XL4'0F0F0F0F'                                                    
TABLE    DC    XL16'F0F1F2F3F4F5F6F7F8F9C1C2C3C4C5C6'                           
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
