DLUIOGFA START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 0  - WORK REGISTER                                                  
*  REGISTER 1  - WORK REGISTER                                                  
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 8  - WORK REGISTER                                                  
*  REGISTER 9  - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
*                                                                               
*  GET VIRTUAL STORAGE FOR A NEW FILEAREA.                                      
*                                                                               
         GETMAIN RU,LV=512                                                      
         LTR   R15,R15                                                          
         BZ    GOTIT                                                            
         MVC   ERRCODE,=C'E1    '                                               
         B     GOBACK                                                           
*                                                                               
*  SAVE THE FILE KEY ( THE DCB/ACB NAME ) AND THE ADDRESS OF THE                
*  FILE AREA. THEN INITIALIZE THE FILE AREA.                                    
*                                                                               
GOTIT    EQU   *                                                                
         L     R8,THISFILE                                                      
         MVC   0(7,R8),DCBACBP1                                                 
         ST    R1,8(R8)                                                         
         LR    R0,R1                                                            
         LA    R1,512                                                           
         SR    R8,R8                                                            
         SR    R9,R9                                                            
         MVCL  R0,R8                                                            
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOGFA EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         END                                                                    
