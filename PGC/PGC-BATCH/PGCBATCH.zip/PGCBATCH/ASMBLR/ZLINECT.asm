ZLINECT  START                                                                  
         REGEQU                                                                 
         SAVE  (14,12),,*                                                       
         BALR  R12,0                                                            
         USING *,R12                                                            
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         L     R3,0(R1)                                                         
*                                                                               
*        MVC   0(2,R3),=X'003C'                                                 
         MVC   0(2,R3),=X'0050'                                                 
*                                                                               
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
MYSAVE   DS    18F                                                              
         END                                                                    
