DLUIOSTA START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  POINT TO THE SEARCH KEY AREA FOR THIS FILE.                                  
*                                                                               
         L     R10,THISFILE                                                     
*                                                                               
*  POINT REGISTER 6 TO THE FILE AREA. STATISTICS ARE PRODUCED                   
*  ONLY FOR OUTPUT FILES.                                                       
*                                                                               
         L     R6,8(R10)                                                        
         LTR   R6,R6                                                            
         BZ    GOBACK                                                           
         CLI   DCBACBFA+2,C'I'                                                  
         BE    GOBACK                                                           
*                                                                               
*  DETERMINE IF THE FILE IS CLOSED.                                             
*                                                                               
         CLI   OPENIND,NOTOPEN                                                  
         BE    STATS                                                            
         B     ACCUM                                                            
*                                                                               
*  THE FILE IS CLOSED. CALCULATE THE AVERAGE RECORD LENGTH.                     
*                                                                               
STATS    EQU   *                                                                
         CP    RECBYTES,=P'0'                                                   
         BE    GOBACK                                                           
         CP    SVWRITE,=P'0'                                                    
         BE    GOBACK                                                           
         ZAP   WORK4(8),RECBYTES                                                
         DP    WORK4(8),SVWRITE                                                 
         ZAP   RECAVG,WORK4(3)                                                  
         B     GOBACK                                                           
*                                                                               
*  IF FIXED LENGTH RECORDS USE THE PASSED RECORD LENGTH. IF                     
*  VARIABLE LENGTH RECORDS GET THE RECORD LENGTH FROM THE RECORD.               
*  IGNORE ALL OTHER TYPES OF RECORDS ( SPANNED AND UNDEFINED ).                 
*  ADD THE RECORD LENGTH INTO THE TOTAL BYTES ACCUMULATOR AND                   
*  THEN DETERMINE IF THIS IS A MAXIMUM OR MINIMUM LENGTH RECORD.                
*                                                                               
ACCUM    EQU   *                                                                
         CLI   DCBACBFA+3,C'F'                                                  
         BE    ACCUMA                                                           
         CLI   DCBACBFA+3,C'V'                                                  
         BNE   GOBACK                                                           
         LH    R10,RECAREA                                                      
         CVD   R10,WORK4                                                        
         B     ACCUMB                                                           
ACCUMA   EQU   *                                                                
         ZAP   WORK4(8),RECLGTH                                                 
ACCUMB   EQU   *                                                                
         AP    RECBYTES,WORK4(8)                                                
         CP    WORK4(8),RECMAX                                                  
         BNH   ACCUMC                                                           
         ZAP   RECMAX,WORK4(8)                                                  
ACCUMC   EQU   *                                                                
         CP    WORK4(8),RECMIN                                                  
         BNL   GOBACK                                                           
         ZAP   RECMIN,WORK4(8)                                                  
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOSTA EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
