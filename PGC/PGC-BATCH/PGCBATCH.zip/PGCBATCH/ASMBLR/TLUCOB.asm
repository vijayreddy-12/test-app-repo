*          DATA SET TLUCOB     AT LEVEL 009 AS OF 95/01/06                      
*          DATA SET PMSTLU     AT LEVEL 009 AS OF 94/12/21              00001   
*          DATA SET PMSTLU     AT LEVEL 033 AS OF 92/01/31              00002   
*          DATA SET TLU        AT LEVEL 001 AS OF 88/03/08              00003   
**********************************************************************  00004   
*  COPIED FROM MAN.TEST.PANLIB 30/06/88 WFY                          *  00005   
*  REVISED MAR 08/88 DJW RE: USE XA COMPILER                         *  00006   
**********************************************************************  00007   
*  CHANGE LOG                                                        *  00008   
*  **********                                                        *  00009   
*                                                                    *  00010   
* 01 - 920127 - PMS - CHANGES TO ALLOW BINARY LOOKUP ON SORTED       *  00011   
*                     TABLES.                                        *  00012   
*                   - USE EQU * FOR STATEMENT LABELS WHERE POSSIBLE  *  00013   
*                                                                    *  00014   
* 02 - 941221 - PMS - CODE ADDED TO SUPPORT 31 BIT ADDRESSING        *  00015   
*                     BY NORM LACOE                                  *  00016   
*                                                                    *  00017   
* 03 - 18JUN08- IBM - ECU PROJECT UPGRADED IN ENTERPRISE             *          
*                     COMPILER PROJECT                               *          
*                                                                    *          
* 04 - 28OCT08- NJJ - TRY TO RESTORE THE TLR ROUTINE IN HERE SO      *          
*                     WE CAN GET RID OF DSASET AND DSATLU...         *          
*                                                                    *          
**********************************************************************  00018   
**                                    CHGLOG START - 00 - YYMMDD - XXX  00019   
**                                    CHGLOG END   - 00 - YYMMDD - XXX  00020   
**                                                                      00021   
**                                    CHGLOG START - 01 - 920127 - PMS  00022   
**                                                                      00023   
               EQUREG                                                   00024   
**                                                                      00025   
**                                    CHGLOG END   - 01 - 920127 - PMS  00026   
TLUCOB   CSECT                                                          00027   
TLUCOB   AMODE 31                                                       00028   
TLUCOB   RMODE ANY                                                      00029   
         USING TLUCOB,R15                                               00030**5
         STM   R14,R12,12(R13) STORE REGISTERS IN CALLER'S DSA          00031   
         LA    R4,SAVEAREA                                              00032   
         ST    R13,SAVEAREA+4  STORE CALLER'S DSA ADDR IN OWN SAVEAREA  00033   
         ST    R4,8(R13)       STORE CURRENT DSA ADDR IN DSA            00034   
         LA    R13,SAVEAREA    ESTABLISH R13 TO POINT TO CURRENT DSA    00035   
         DROP  R15                                                      00036**7
         LR    R10,R15         MOVE BASE REG TO R10                     00037**7
         USING TLUCOB,R10                                               00038**7
         LR    R9,R1           SAVE PARMLIST IN R9                      00039**7
*    SAVE ADDRESS OF 1ST PARM TO TLU, ERROR INDICATOR                   00040   
         L     R2,0(R1)                                                 00041   
         ST    R2,SAVEERR                                               00042   
*    SAVE ADDRESS OF 2ND PARM TO TLU, SEARCH ARGUMENT                   00043   
         L     R2,4(R1)                                                 00044   
         ST    R2,SAVESEAR                                              00045   
*    SAVE ADDRESS OF 4TH PARM TO TLU, RETURN STRING                     00046   
         L     R2,12(R1)                                                00047   
         ST    R2,SAVERET                                               00048   
*    FIRST TIME INDIC INITIALIZED TO 'N', SET TO 'Y IN SETUP            00049   
         CLI   TABIND,C'Y'     FIRST TIME INDICATOR                     00050**3
         BE    DOLOOKUP                                                 00051**7
         LOAD  EP=DSACOB2      RETURNS ADDR IN REG 0                    00052   
         LR    R15,R0                                                   00053   
         BSM   R14,R0          SNEAKY WAY TO TURN ON BIT                00054   
         BALR  R14,R15                                                  00055   
         ST    R11,TABPTR                                               00056**3
         MVI   TABIND,C'Y'     TABLES HAVE BEEN READ                    00057**3
         SPACE 2                                                        00058   
DOLOOKUP EQU   *                                                        00059**7
         L     R2,SAVEERR      RESTORE ADDR OF ERROR INDIC              00060   
         MVI   0(R2),C' '      INITIALIZE TO BLANK, ASSUME SEARCH OK    00061   
         LR    R1,R9           RESTORE PARMLIST IN R1                   00062   
         L     R11,TABPTR      ESTABLISH ADDRESSIBILITY TO TABLE        00063**3
         USING TBLWKA,R11                                               00064**5
         L     R2,TBLADDR                                               00065   
         L     R3,TBLAREA                                               00066   
         L     R4,8(R1)        SET R4 TO TLU TABLE #                    00067   
         LA    R8,*+8          SET UP R8 AS RETURN ADDR                 00068   
         B     LOOKUP                                                   00069   
         LA    R8,FOUND                                                 00070   
         LA    R9,NOTFND                                                00071   
         L     R2,SAVESEAR                                              00072   
         S     R5,=F'1'                                                 00073   
**                                                                      00074   
**                                    CHGLOG START - 01 - 920127 - PMS  00075   
**                                                                      00076   
         CLI   SORTIND,C'Y'           IS TABLE SORTED?                  00077   
         BE    BINSRCH                YES - DO BINARY SEARCH            00078   
**                                                                      00079   
**                                    CHGLOG END   - 01 - 920127 - PMS  00080   
**                                                                      00081   
         B     SEARCH                 NO  - DO SEQUENTIAL SEARCH        00082   
         SPACE 2                                                        00083   
*    R3    -   PTS TO CALLING PARM                                      00084   
*    R4    -   LN OF DATA TO BE MOVED                                   00085   
*    R6    -   PTS TO DATA TO BE MOVED                                  00086   
FOUND    L     R4,SAVERET     R8 IS USED TO BRANCH HERE IF TLU IS FOUND 00087   
         S     R6,=F'1'       REDUCE FOR LN OF STRING FOR MOVE          00088   
         A     R5,=F'1'                                                 00089   
         AR    R3,R5                                                    00090   
LOOPMOVE EQU   *                                                        00091   
         C     R6,=F'255'                                               00092   
         BNH   LE256                                                    00093   
         S     R6,=F'256'                                               00094   
         MVC   0(256,R4),0(3)                                           00095   
         A     R4,=F'256'                                               00096   
         A     R3,=F'256'                                               00097   
         B     LOOPMOVE                                                 00098   
LE256    EQU   *                                                        00099   
         C     R6,=F'0'                                                 00100   
         BL    GOBACK                                                   00101   
         EX    6,RETRN                                                  00102   
         B     GOBACK                                                   00103   
         SPACE 2                                                        00104   
NOTFND   L     R4,SAVEERR                                               00105   
         MVI   0(R4),C'E'                                               00106   
         B     FOUND                                                    00107   
RETRN    MVC   0(0,R4),0(R3)                                            00108   
         SPACE 2                                                        00109   
GOBACK   EQU   *                                                        00110   
         SR    R15,R15              ZERO OUT RETURN CODE (FOR COBOL)    00111   
         OUT                                                            00112   
         SPACE 2                                                        00113   
LOOKUP   ZAP   DOUBLE(8),0(2,R4)    PACK TABLE NUMBER                   00114   
         CVB   R4,DOUBLE             SET R4 TO TABLE #                  00115   
         STC   R4,DOUBLE                                                00116   
         SLL   R4,2                                                     00117   
         L     R2,TBLADDR                                               00118   
         AR    R2,R4                                                    00119   
         CLC   DOUBLE(1),0(R2)                                          00120   
         BNE   ABORTJOB                                                 00121   
         ICM   R3,7,1(R2)       CHGED FROM LOAD FOR 24 BIT ADDR ONLY    00122**9
         MVC   DOUBLE(8),0(R3)                                          00123   
**                                                                      00124   
**                                    CHGLOG START - 01 - 920127 - PMS  00125   
**                                                                      00126   
         L     R7,8(R3)           SAVE THE NUMBER OF TABLE ENTRIES      00127   
         BCTR  R7,0               (IGNORING THE DEFAULT ENTRY).         00128   
         ST    R7,NOENTS          SAVE THE NUMBER OF TABLE ENTRIES      00129   
         MVC   SORTIND,12(R3)     SAVE THE SORTED/UNSORTED INDICATOR    00130   
**                                                                      00131   
**                                    CHGLOG END   - 01 - 920127 - PMS  00132   
**                                                                      00133   
         LM    R5,R6,DOUBLE       SET R5 & R6 TO LN OF SEARCH & RET ARG 00134   
         LR    R7,R5                                                    00135   
         AR    R7,R6                                                    00136   
**                                                                      00137   
**                                    CHGLOG START - 01 - 920127 - PMS  00138   
**                                                                      00139   
*        A     R3,=F'8'                                                 00140   
         A     R3,=F'16'              BYPASS LENGTH OF ARGUMENT         00141   
*                                            LENGTH OF RETURNED VALUE   00142   
*                                            NUMBER OF ENTRIES          00143   
*                                            SORTED/UNSORTED INDICATOR  00144   
         ST    R3,STARTTBL            SAVE THE ADDRESS OF THE VALUES    00145   
         ST    R5,ARGLEN              SAVE THE ARGUMENT LENGTH          00146   
         ST    R6,RETLEN              SAVE THE RETURN VALUE LENGTH      00147   
         ST    R7,ENTLEN              SAVE THE ENTRY LENGTH             00148   
**                                                                      00149   
**                                    CHGLOG END   - 01 - 920127 - PMS  00150   
**                                                                      00151   
         BR    R8                                                       00152   
ABORTJOB EQU   *                                                        00153   
         WTO   'REQUESTED TABLE NOT FOUND IN TLU',ROUTCDE=(2,11)        00154   
         WTO   'JOB TERMINATED',ROUTCDE=(2,11)                          00155   
         ABEND 889,DUMP                                                 00156   
         EJECT                                                          00157   
**                                                                      00158   
**                                    CHGLOG START - 01 - 920127 - PMS  00159   
**                                                                      00160   
**********************************************************************  00161   
**       BINARY SEARCH - DO ONLY IF TABLE IS SORTED                 **  00162   
**********************************************************************  00163   
**                                                                      00164   
BINSRCH  EQU   *                                                        00165   
**********************************************************************  00166   
**       SAVE REGISTERS SO WE CAN USE THEM TEMPORARILY FOR THE      **  00167   
**       SEARCH.                                                    **  00168   
**********************************************************************  00169   
         STM   R2,R5,SAVEREGS                                           00170   
**********************************************************************  00171   
**       INITIALIZE VALUES USED BY SEARCH.                          **  00172   
**********************************************************************  00173   
         MVC   LOWENTN,=F'0'         LOWEST ENTRY TO CHECK              00174   
         MVI   CONTSRCH,C'Y'         CONTINUE SEARCH                    00175   
         MVI   ENTFOUND,C'N'         ENTRY FOUND                        00176   
**********************************************************************  00177   
**       DETERMINE THE NUMBER OF ENTRIES TO SEARCH, RAISED TO THE   **  00178   
**       NEXT HIGHER POWER OF 2.                                    **  00179   
**********************************************************************  00180   
         BAL   R5,SETHIGH                                               00181   
**********************************************************************  00182   
**       DO THE BINARY SEARCH.                                      **  00183   
**********************************************************************  00184   
BINNEXT  EQU   *                                                        00185   
**********************************************************************  00186   
**       DETERMINE THE NUMBER, OFFSET AND ADDRESS OF THE CURRENT    **  00187   
**       ENTRY.                                                     **  00188   
**********************************************************************  00189   
         BAL   R5,SETCURR                                               00190   
**********************************************************************  00191   
**       COMPARE THE SEARCH ARGUMENT TO THE CURRENT ENTRY AND       **  00192   
**       PROCESS ACCORDINGLY.                                       **  00193   
**********************************************************************  00194   
         L     R2,SAVESEAR           GET ADDRESS OF SEARCH ARGUMENT     00195   
         L     R3,CURRENTA           GET ADDRESS OF CURRENT ENTRY       00196   
         L     R5,ARGLEN             GET ARGUMENT LENGTH                00197   
         BCTR  R5,0                  SUBTRACT 1 FOR 'EXECUTE'           00198   
         EX    R5,TESTVALU           COMPARE                            00199   
         BE    ENTMATCH              ENTRY MATCHES ARGUMENT             00200   
         BL    ENTLOW                ENTRY LOWER THAN ARGUMENT          00201   
         BH    ENTHIGH               ENTRY HIGHER THAN ARGUMENT         00202   
ENTMATCH EQU   *                                                        00203   
         MVI   ENTFOUND,C'Y'         ENTRY FOUND                        00204   
         MVI   CONTSRCH,C'N'         STOP SEARCH                        00205   
         ST    R3,CURRENTA           SAVE ADDRESS OF ENTRY              00206   
         B     NOMORE                BRANCH TO END OF LOOP              00207   
ENTLOW   EQU   *                                                        00208   
         MVC   LOWENTN,CURRENTN      RESET LOW ENTRY TO CURRENT ENTRY   00209   
         B     ANYMORE               BRANCH TO END OF LOOP              00210   
ENTHIGH  EQU   *                                                        00211   
         L     R5,CURRENTN           RESET HIGH ENTRY TO ONE LESS THAN  00212   
         BCTR  R5,0                    THE CURRENT ENTRY                00213   
         ST    R5,HIGHENTN                                              00214   
ANYMORE  EQU   *                                                        00215   
         CLI   CONTSRCH,C'Y'         SEARCH MORE?                       00216   
         BE    CHECKHI               YES - CHECK ENTRY NUMBER           00217   
         B     NOMORE                NO  - END SEARCH                   00218   
CHECKHI  EQU   *                                                        00219   
         CLC   CURRENTN,NOENTS       CHECK IF ENTRY NUMBER IS           00220   
*                                      TOO HIGH                         00221   
         BNH   CHECKLO               NO  - CHECK IF ENTRY NUMBER IS     00222   
*                                          TOO LOW                      00223   
         L     R5,NOENTS             YES - SET RETURN ENTRY TO LAST     00224   
         LA    R5,1(R5)                    (DEFAULT) ENTRY IN TABLE     00225   
         ST    R5,CURRENTN                 AND EXIT LOOP                00226   
         BAL   R5,SETCURRO                                              00227   
         B     NOMORE                                                   00228   
CHECKLO  EQU   *                                                        00229   
         CLC   CURRENTN,=F'1'        CHECK IF ENTRY NUMBER IS           00230   
*                                      TOO LOW                          00231   
         BH    CHECKEQ               NO  - CONTINUE CHECKING            00232   
         L     R5,NOENTS             YES - SET RETURN ENTRY TO LAST     00233   
         LA    R5,1(R5)                    (DEFAULT) ENTRY IN TABLE     00234   
         ST    R5,CURRENTN                 AND EXIT LOOP                00235   
         BAL   R5,SETCURRO                                              00236   
         B     NOMORE                                                   00237   
CHECKEQ  EQU   *                                                        00238   
         CLC   HIGHENTN,LOWENTN      CHECK IF WE HAVE GONE THROUGH      00239   
*                                      ALL THE ENTRIES                  00240   
         BH    BINNEXT               NO  - CONTINUE SEARCH              00241   
         L     R5,NOENTS             YES - SET RETURN ENTRY TO LAST     00242   
         LA    R5,1(R5)                    (DEFAULT) ENTRY IN TABLE     00243   
         ST    R5,CURRENTN                 AND EXIT LOOP                00244   
         BAL   R5,SETCURRO                                              00245   
NOMORE   EQU   *                                                        00246   
**********************************************************************  00247   
**       RELOAD THE REGISTERS THAT WE JUST USED WITH THEIR VALUES   **  00248   
**       BEFORE WE USED THEM.                                       **  00249   
**********************************************************************  00250   
         LM    R2,R5,SAVEREGS                                           00251   
**********************************************************************  00252   
**       RELOAD REGISTER 3 WITH THE ADDRESS OF THE ENTRY TO RETURN. **  00253   
**********************************************************************  00254   
         L     R3,CURRENTA                                              00255   
         CLI   ENTFOUND,C'Y'         WAS ENTRY FOUND?                   00256   
         BE    FOUND                 YES                                00257   
         B     NOTFND                NO                                 00258   
         EJECT                                                          00259   
**********************************************************************  00260   
**       DETERMINE THE NUMBER, OFFSET AND ADDRESS OF THE CURRENT    **  00261   
**       ENTRY.                                                     **  00262   
**********************************************************************  00263   
SETCURR  EQU   *                                                        00264   
         L     R3,HIGHENTN           LOAD THE HIGH ENTRY NUMBER         00265   
         S     R3,LOWENTN            SUBTRACT THE LOW ENTRY NUMBER      00266   
         LA    R3,1(R3)              ADD 1                              00267   
         SRL   R3,1                  DIVIDE BY 2                        00268   
         A     R3,LOWENTN            ADD THE LOW ENTRY NUMBER           00269   
         ST    R3,CURRENTN           SAVE CURRENT ENTRY NUMBER          00270   
         CLC   CURRENTN,NOENTS       IS CURRENT ENTRY TOO HIGH?         00271   
         BNH   SETCURRO              NO  - OK                           00272   
         BCTR  R3,0                  YES - SUBTRACT 1 FROM CURRENT      00273   
         ST    R3,HIGHENTN                 NUMBER, MOVE IT TO HIGH      00274   
         B     SETCURR                     NUMBER AND RESET THE         00275   
*                                          CURRENT NUMBER               00276   
SETCURRO EQU   *                                                        00277   
         L     R3,CURRENTN           LOAD CURRENT ENTRY NUMBER          00278   
         BCTR  R3,0                  SUBTRACT 1 AND MULTIPLY BY THE     00279   
         MR    R2,R7                 ENTRY LENGTH TO GET THE ENTRY      00280   
         ST    R3,CURRENTO           OFFSET                             00281   
         A     R3,STARTTBL           ADD THE STARTING ADDRESS OF THE    00282   
         ST    R3,CURRENTA           TABLE VALUES TO GET THE ENTRY      00283   
         BR    R5                    ADDRESS AND RETURN                 00284   
         EJECT                                                          00285   
**********************************************************************  00286   
**       DETERMINE THE NUMBER OF ENTRIES TO SEARCH, RAISED TO THE   **  00287   
**       NEXT HIGHER POWER OF 2 (MINUS 1).                          **  00288   
**********************************************************************  00289   
SETHIGH  EQU   *                                                        00290   
         L     R3,NOENTS             LOAD THE ACTUAL # OF ENTRIES       00291   
         SR    R4,R4                 ZERO OUT THE NUMBER OF SHIFTS      00292   
COMPHIGH EQU   *                                                        00293   
         C     R3,=F'0'              HAVE WE SHIFTED OUT ALL BITS?      00294   
         BE    DONESHR               YES - NOW SHIFT BACK               00295   
         SRL   R3,1                  NO - DIVIDE BY 2                   00296   
         LA    R4,1(R4)                 - INCREMENT THE # OF SHIFTS     00297   
         B     COMPHIGH                 - CHECK IF ZERO YET             00298   
DONESHR  EQU   *                                                        00299   
         LA    R3,1                  INITIALIZE NUMBER OF ENTRIES  TO 1 00300   
         C     R4,=F'0'              ARE THERE ANY ENTRIES IN THE TABLE 00301   
         BH    SHIFTL                YES - CONTINUE                     00302   
         MVI   CONTSRCH,C'N'         NO  - SET THE HIGH ENTRY AND THE   00303   
         MVC   HIGHENTN,NOENTS             LOW ENTRY NUMBER TO THE SAME 00304   
         MVC   LOWENTN,NOENTS              VALUE AND RETURN TO WHERE WE 00305   
         SR    R3,R3                       WILL END THE SEARCH          00306   
         B     CHECKEQ                                                  00307   
SHIFTL   EQU   *                                                        00308   
         SLL   R3,1                  MULTIPLY BY 2                      00309   
         BCT   R4,SHIFTL             REPEAT IF NECESSARY                00310   
         BCTR  R3,0                  DONE - SUBTRACT 1 FROM THE VALUE,  00311   
         ST    R3,HIGHENTN                  SAVE IT AND RETURN TO       00312   
         BR    R5                           SEARCH                      00313   
**                                                                      00314   
**                                    CHGLOG END   - 01 - 920127 - PMS  00315   
**                                                                      00316   
**       THE FOLLOWING REGISTERS EXPECTED TO BE COMPLETED BEFORE        00316   
**       COMING TO SEARCH OR HUNT                                       00316   
**         R2:   ADDRESS OF SOUGHT ARGUMENT                             00316   
**         R3:   POINTER INTO TABLE AT FIRST COMPARISON BYTE            00316   
**         R4:   ADDRESS FOR RESULT TO BE STORED                        00316   
**         R5:   (SEARCH) COLUMN 1 ARG LENGTH MINUS 1                   00316   
**         R6:   (SEARCH) COLUMN 2     LENGTH                           00316   
**         R5:   (HUNT  ) COLUMN 1     LENGTH                           00316   
**         R6:   (HUNT  ) COLUMN 2 ARG LENGTH MINUS 1                   00316   
**         R7:   ACTUAL LENGTH OF A PAIR OF INTERIES FOR INCREMENTS     00316   
**         R8:   SUCCESSFUL LOOKUP RETURN ADDRESS                       00316   
**         R9:   UNSUCCESSFUL LOOKUP RETURN ADDRESS                     00316   
**         R10:  ADDRESSABILITY TO MOST OF TLUCOB CSECT                 00316   
**                                                                      00316   
         EJECT                                                          00317   
SEARCH   EX    5,TESTVALU            HAVE WE FOUND A MATCH?             00318   
         BCR   8,R8                  YES - BRANCH TO 'FOUND' LOGIC      00319   
         EX    5,ISITEND             NO MATCH - END OF TABLE?           00320   
         BCR   8,R9                  YES - BRANCH TO 'NOTFOUND' LOGIC   00321   
         AR    3,7                   POINT TO NEXT ENTRY                00322   
         B     SEARCH                COMPARE NEXT ENTRY                 00323   
         SPACE 2                                                        00324   
TESTVALU CLC   0(0,3),0(2)                                              00325   
ISITEND  CLC   0(0,3),DOLLARS                                           00326   
HUNT     EX    6,TESTVALU                                               00327   
         BCR   8,8                                                      00328   
         EX    6,ISITEND                                                00329   
         BCR   8,9                                                      00330   
         AR    3,7                                                      00331   
         B     HUNT                                                     00332   
         DS    0F                                                       00333   
         DROP  R10                                                              
         EJECT                                                          00334   
TLR      EQU   *                                                        00335   
         ENTRY TLR                                                      00336   
         USING TLR,R15                                                  00337   
         STM   R14,R12,12(R13) STORE REGISTERS IN CALLER'S DSA          00338   
         LA    R4,SAVEAREA                                              00339   
         ST    R13,SAVEAREA+4  STORE CALLER'S DSA ADDR IN OWN SAVEAREA  00340   
         ST    R4,8(R13)       STORE CURRENT DSA ADDR IN DSA            00341   
         LA    R13,SAVEAREA    ESTABLISH R13 TO POINT TO CURRENT DSA    00342   
         LR    R9,R1           SAVE PARMLIST IN R9                              
         L     R2,0(R1)                                                 00343   
         ST    R2,SAVEERR                                               00344   
         L     R2,4(R1)                                                 00345   
         ST    R2,SAVESEAR                                              00346   
         L     R2,12(R1)                                                00347   
         ST    R2,SAVERET                                               00348   
         SPACE                                                                  
*        THE NEXT FEW LINES ARE TRYING TO SET R10 TO THE TLUCOB ADDRESS         
         DROP  R15             AND WE REVERT TO USING TLUCOB R10                
         SR    R10,R10         CLEAR R10                                        
         USING TLUCOB,R10      THIS MATCHES THE USING IN MOST OF ABOVE          
         LA    R2,TLR-TLUCOB   REALLY THE OFFSET OF TLR ENTRY !!                
         LR    R10,R15         TAKE THE ADDRESS WE HAVE                         
         SR    R10,R2          AND MOVE IT BACK TO TLUCOB                       
*        THAT WAS TRICKY. NOW R10 IS OK... BACK TO BUSINESS...                  
         SPACE                                                                  
         CLI   TABIND,C'Y'                                              00349**3
         BE    BYPASSB                                                  00350   
         LOAD  EP=DSACOB2      RETURNS ADDR IN REG 0                    00351   
         LR    R15,R0                                                   00352   
         BSM   R14,R0          SNEAKY WAY TO TURN ON BIT                00353   
         BALR  R14,R15                                                  00354   
         ST    R11,TABPTR      SAVE RESULT PASSED BACK...                       
         MVI   TABIND,C'Y'     AND RECORD THAT WE LOADED THEM           00355**3
         SPACE 2                                                        00357   
BYPASSB  EQU   *                                                        00358   
         L     R2,SAVEERR      RESTORE ADDR OF ERROR INDIC              00359   
         MVI   0(R2),C' '      INITIALIZE TO BLANK, ASSUME SEARCH OK    00360   
         LR    R1,R9                                                    00361   
         L     R11,TABPTR      ESTABLISH ADDRESSIBILITY TO TABLE                
         L     R2,TBLADDR                                               00362   
         L     R3,TBLAREA                                               00363   
         L     R4,8(R1)                                                 00364   
         LA    R8,*+8                                                   00365   
         B     LOOKUP                                                   00366   
         AR    R3,R5                                                    00367   
         LA    R8,GOTIT                                                 00368   
         LA    R9,DIDNOT                                                00369   
         L     R2,SAVESEAR     LOAD ADDRESS OF SEARCH ARG               00370   
         S     R6,=F'1'                                                 00372   
         B     HUNT                                                     00373   
         SPACE 2                                                        00374   
GOTIT    L     R4,SAVERET    ADDRESS FOR RESULT                         00375   
         SR    R3,R5 BACKUP POINTER BY LENGTH OF COL 1                  00377   
         A     R6,=F'1' SET R6 BACK TO REAL LENGTH OF COL 2             00378   
         S     R5,=F'1' SET R5 TO LENGTH -1 FOR MOVING                  00379   
         LR    R2,R6 SWITCH REGISTERS 5 AND 6                           00380   
         LR    R6,R5                                                    00381   
         LR    R5,R2                                                    00382   
         B     LOOPMOVE SO WE CAN EXIT AS BEFORE....                    00383   
         SPACE 2                                                        00384   
DIDNOT   L     R4,SAVEERR                                               00385   
         MVI   0(R4),C'E'                                               00387   
         B     GOTIT                                                    00388   
         EJECT                                                          00389   
         EJECT                                                          00390   
**                                                                      00391   
**                                    CHGLOG START - 01 - 920127 - PMS  00392   
**                                                                      00393   
SAVEAREA DS    18F                                                      00394   
SAVEREGS DS    4F                     TEMPORARY SAVE AREA FOR REGS      00395   
STARTTBL DS    F                      STARTING ADDRESS OF TABLE VALUES  00396   
ENTLEN   DS    F                      LENGTH OF TABLE ENTRY             00397   
ARGLEN   DS    F                      LENGTH OF TABLE ARGUMENT          00398   
RETLEN   DS    F                      LENGTH OF TABLE RETVALUE          00399   
NOENTS   DS    F                      NUMBER OF ENTRIES IN A TABLE      00400   
HIGHENTN DS    F                      HIGHEST ENTRY NUMBER              00401   
LOWENTN  DS    F                      LOWEST ENTRY  NUMBER              00402   
CURRENTN DS    F                      CURRENT ENTRY NUMBER              00403   
CURRENTO DS    F                                    OFFSET              00404   
CURRENTA DS    F                                    ADDRESS             00405   
SORTIND  DS    CL1                    IS TABLE SORTED OR NOT?           00406   
CONTSRCH DS    CL1                    CONTINUE BINARY SEARCH?           00407   
ENTFOUND DS    CL1                    ENTRY FOUND IN TABLE?             00408   
TABIND   DC    CL1'N'                                                   00409**3
**                                                                      00410   
**                                    CHGLOG END   - 01 - 920127 - PMS  00411   
**                                                                      00412   
DOUBLE   DS    D                                                        00413   
TABPTR   DS    F                                                        00414**3
SAVEERR  DS    F                                                        00415**3
SAVERET  DS    F                                                        00416   
SAVESEAR DS    F                                                        00417   
AREA     DS    F                                                        00418   
BLANKS   DC    20CL4'    '                                              00419   
DOLLARS  DC    20CL4'$$$$'                                              00420   
         SPACE 2                                                        00421   
         LTORG                                                          00422   
         SPACE 2                                                        00423**2
TBLWKA   DSECT                                                          00424**4
TBLADDR  DS    F                                                        00425**2
TBLAREA  DS    F                                                        00426**2
ADDRESS  DS    999F                                                     00427**2
         END                                                            00428**2
