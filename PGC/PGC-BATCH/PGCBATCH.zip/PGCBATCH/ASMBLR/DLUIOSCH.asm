DLUIOSCH START                                                                  
         ENTRY FILEKEYS                                                         
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
*                                                                               
*  SEARCH THROUGH THE FILE KEYS LOOKING FOR THIS FILE. IF YOU RUN OVER          
*  THE END OF THE TABLE INDICATE AN ERROR. RETURN WITH THE FIELD                
*  'THISFILE' POINTING TO THE KEY OR THE NEXT AVAILABLE KEY IF NOT              
*  FOUND.                                                                       
*                                                                               
         L     R10,FRSTFILE                                                     
SEARCH   EQU   *                                                                
         CLC   0(7,R10),DCBACBP1                                                
         BE    STOPLOOP                                                         
         CLI   0(R10),X'00'                                                     
         BE    STOPLOOP                                                         
         LA    R10,12(R10)                                                      
         CLI   0(R10),X'FF'                                                     
         BNE   SEARCH                                                           
         MVC   ERRCODE,=C'EB    '                                               
         B     GOBACK                                                           
STOPLOOP EQU   *                                                                
         ST    R10,THISFILE                                                     
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOSCH EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
*  FILE SEARCH KEYS. THERE IS ROOM HERE FOR 50 FILES. THE FIRST                 
*  7 BYTES FOR EACH ENTRY CONTAINS THE DCB/ACB NAME. THE NEXT                   
*  BYTE IS FILLER. THE LAST 4 BYTES CONTAIN THE ADDRESS OF THE                  
*  FILE AREA FOR THIS PARTICULAR FILE. THUS EACH ENTRY OCCUPIES                 
*  12 BYTES. WHEN SEARCHING THRU THE TABLE YOU KNOW THAT ALL                    
*  ENTRIES HAVE BEEN EXAMINED WHEN LOW VALUES ARE ENCOUNTERED.                  
*  THE TABLE IS DELIMITED BY HIGH VALUES.                                       
*                                                                               
         DS    0F                                                               
FILEKEYS DC    600X'00'                                                         
         DC    X'FF'                                                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         END                                                                    
