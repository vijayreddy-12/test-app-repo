DLUIOERR START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 9  - WORK REGISTER                                                  
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*                                                                               
         USING DLUIOERR,R15                                                     
         STM   R0,R15,SYNADSAV                                                  
         DROP  R15                                                              
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  OPEN THE SNAP DUMP DATA SET AND MOVE IN THE ERROR CODE.                      
*                                                                               
         OPEN  (SNAPDCB,(OUTPUT))                                               
         MVC   ERRCODE,=C'EZ    '                                               
*                                                                               
*  DUMP THE REGISTERS AS THEY WERE ON ENTRY TO THIS EXIT.                       
*                                                                               
         LA    R9,SYNADSAV                                                      
         LR    R10,R9                                                           
         AH    R10,=H'60'                                                       
         SNAP  DCB=SNAPDCB,STORAGE=((9),(10)),STRHDR=HEADER1                    
*                                                                               
*  DUMP THE STATUS INDICATORS. THE ADDRESS OF THE STATUS INDICATORS             
*  IS IN REGISTER 0 ON ENTRY TO THIS EXIT.                                      
*                                                                               
         L     R9,SYNADSAV                                                      
         LR    R10,R9                                                           
         AH    R10,=H'12'                                                       
         SNAP  DCB=SNAPDCB,STORAGE=((9),(10)),STRHDR=HEADER2                    
*                                                                               
*  DUMP PARAMETER ONE FROM THE APPLICATION PROGRAM.                             
*                                                                               
         LR    R9,R3                                                            
         LR    R10,R3                                                           
         AH    R10,=H'256'                                                      
         SNAP  DCB=SNAPDCB,STORAGE=((9),(10)),STRHDR=HEADER3,          C        
               PDATA=(PSW,REGS)                                                 
*                                                                               
*  DUMP THE RECORD AREA.                                                        
*                                                                               
         LR    R9,R4                                                            
         LR    R10,R4                                                           
         AH    R10,=H'256'                                                      
         SNAP  DCB=SNAPDCB,STORAGE=((9),(10)),STRHDR=HEADER4,          C        
               PDATA=(PSW,REGS)                                                 
*                                                                               
*  DUMP THE AREA THAT CONTAINS THE ADDRESS OF THE FIRST FILE KEY, THE           
*  CURRENT FILE KEY ADDRESS AND THE ADDRESS OF THE COMMON AREA.                 
*                                                                               
         LR    R9,R5                                                            
         LR    R10,R5                                                           
         AH    R10,=H'12'                                                       
         SNAP  DCB=SNAPDCB,STORAGE=((9),(10)),STRHDR=HEADER5,          C        
               PDATA=(PSW,REGS)                                                 
*                                                                               
*  DUMP THE VIRTUAL STORAGE AREA FOR THE FILE.                                  
*                                                                               
         LR    R9,R6                                                            
         LR    R10,R6                                                           
         AH    R10,=H'512'                                                      
         SNAP  DCB=SNAPDCB,STORAGE=((9),(10)),STRHDR=HEADER6,          C        
               PDATA=(PSW,REGS)                                                 
*                                                                               
*  DUMP THE DCB.                                                                
*                                                                               
         L     R9,DCBAREA                                                       
         L     R10,DCBAREA                                                      
         A     R10,LDCBAREA                                                     
         SNAP  DCB=SNAPDCB,STORAGE=((9),(10)),STRHDR=HEADER7,          C        
               PDATA=(PSW,REGS)                                                 
*                                                                               
*  CLOSE THE SNAP DUMP DATA SET AND RETURN TO THE CALLING PROGRAM.              
*                                                                               
GOBACK   EQU   *                                                                
         CLOSE SNAPDCB                                                          
         LM    R0,R15,SYNADSAV                                                  
         RETURN                                                                 
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOERR EYECATCHER *****'                               
SYNADSAV DS    16F          SAVE AREA - SINCE I CAN'T USE R13                   
MYSAVE   DS    18F          SAVE AREA - FOR CALLED ROUTINES                     
*                                                                               
         DS    0F                                                               
HEADER1  DC    XL1'27',CL39'REGISTERS ON ENTRY TO SYNAD .. R0 - R15'            
HEADER2  DC    XL1'27',CL39'STATUS INDICATORS                      '            
HEADER3  DC    XL1'27',CL39'APPLICATION PROGRAM PARAMETER 1        '            
HEADER4  DC    XL1'27',CL39'FIRST 256 BYTES OF RECORD AREA         '            
HEADER5  DC    XL1'27',CL39'INTERNAL AREA                          '            
HEADER6  DC    XL1'27',CL39'FILE AREA GENERATED FOR THIS FILE      '            
HEADER7  DC    XL1'27',CL39'DCB FOR THE FILE                       '            
*                                                                               
         DS    0F                                                               
SNAPDCB  DCB   DDNAME=SYSUDUMP,                                        C        
               DSORG=PS,                                               C        
               RECFM=VBA,                                              C        
               BLKSIZE=1632,                                           C        
               LRECL=125,                                              C        
               MACRF=(W)                                                        
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
