DLUIOCNB START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 7  - USED IN GETMAIN                                                
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  IF THE FILE IS SEQUENTIAL GET STORAGE FOR THE DCB.                           
*  IF THE FILE IS VSAM GET STORAGE FOR THE ACB AND RPL.                         
*                                                                               
         CLI   FILETYPE,VSAMFILE                                                
         BE    VSAM                                                             
*                                                                               
*  THE AMOUNT OF STORAGE REQUIRED FOR THE DCB IS CONTAINED IN THE               
*  FIELD LDCBAREA.                                                              
*                                                                               
SEQ      EQU   *                                                                
         L     R7,LDCBAREA                                                      
         GETMAIN RU,LV=(7)                                                      
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,DCBAREA                                                       
         B     GOBACK                                                           
*                                                                               
*  THE AMOUNT OF STORAGE REQUIRED FOR THE ACB AND RPL IS CONTAINED              
*  IN THE FIELDS LACBAREA AND LRPLAREA RESPECTIVELY.                            
*                                                                               
VSAM     EQU   *                                                                
         L     R7,LACBAREA                                                      
         GETMAIN RU,LV=(7)                                                      
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,ACBAREA                                                       
         L     R7,LRPLAREA                                                      
         GETMAIN RU,LV=(7)                                                      
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,RPLAREA                                                       
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  UNABLE TO GET VIRTUAL STORAGE.                                               
*                                                                               
VISERR   EQU   *                                                                
         MVC   ERRCODE(2),=C'E1'                                                
         STC   R15,HEXERR                                                       
         MVI   HEXERR+1,X'00'                                                   
         CALL  DLUIOXPF                                                         
         B     GOBACK                                                           
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOCNB EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
