DLSREAD  START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 2  - WORK REGISTER                                                  
*  REGISTER 3  - PARAMETER 1 FROM CALLING PROGRAM                               
*  REGISTER 4  - PARAMETER 2 FROM CALLING PROGRAM                               
*  REGISTER 5  - PARAMETER 3 FROM CALLING PROGRAM                               
*  REGISTER 6  - PARAMETER 4 FROM CALLING PROGRAM                               
*  REGISTER 7  - PARAMETER 5 FROM CALLING PROGRAM                               
*  REGISTER 8  - PARAMETER 6 FROM CALLING PROGRAM                               
*  REGISTER 9  - PARAMETER 7 FROM CALLING PROGRAM                               
*  REGISTER 10 - POINTS TO THE FILE AREAS IN THIS PROGRAM                       
*  REGISTER 11 - POINTS TO COUNTER ADDRESS                                      
*  REGISTER 12 - BASE REGISTER                                                  
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R12,R0                                                           
         USING *,R12                                                            
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         LM    R3,R9,0(R1)                                                      
         USING DLP1,R3                                                          
         USING DLP2,R4                                                          
         USING DLP4,R6                                                          
         USING DLP5,R7                                                          
         USING DLP6,R8                                                          
         USING DLP7,R9                                                          
         USING DLUIOP1,R10                                                      
*                                                                               
*  TRY TO FIND THIS FILE IN THE FILE AREAS. IF THE AREA IS FOUND                
*  CHECK TO SEE IF THIS IS A RE-OPEN AND IF SO TREAT IT AS A NEW                
*  FILE.                                                                        
*                                                                               
FINDIT   EQU   *                                                                
         MVI   FIRSTSW,C' '                                                     
         LA    R10,PRMAREAS-49                                                  
         LA    R11,CNTAREAS-4                                                   
SCHLOOP  EQU   *                                                                
         LA    R10,49(R10)                                                      
         LA    R11,4(R11)                                                       
         CLI   DLSYSNUM,X'00'                                                   
         BE    NEWFILE                                                          
         CLC   SYSNNN,DLSYSNUM                                                  
         BNE   SCHLOOP                                                          
         CLI   DCBNAME,X'FF'                                                    
         BNE   FOUNDIT                                                          
*                                                                               
*  THIS IS THE FIRST TIME THRU FOR THIS FILE OR THE FILE IS                     
*  BEING RE-OPENED. SAVE THE SEARCH ARGUMENT AND THEN SET UP                    
*  THE SAVE AREA FOR THE FILE.                                                  
*                                                                               
NEWFILE  EQU   *                                                                
         MVI   FIRSTSW,C'1'                                                     
         ST    R9,0(R11)                                                        
         CLI   RETCODE,X'4C'                                                    
         BE    NEWFILEA                                                         
         ZAP   RETCODE,=P'0'                                                    
NEWFILEA EQU   *                                                                
         MVC   DLSYSNUM,SYSNNN                                                  
         MVC   DCBNAME(2),=C'SQ'                                                
         MVI   DCBNAME+2,C'I'                                                   
         MVC   DCBNAME+3(1),RECFORM                                             
         MVC   DCBNAME+4(3),SYSNNN+3                                            
         MVC   FUNCTION,=C'GETSEQ'                                              
         PACK  RECLGTH,RECSIZE                                                  
         ZAP   READCT,=P'0'                                                     
         ZAP   CORRCNT,=P'0'                                                    
         CLC   RECFORM(2),=C'F '                                                
         BE    NEWFILEB                                                         
         CLC   RECFORM(2),=C'V '                                                
         BE    NEWFILEC                                                         
         PACK  BLOCKSIZ,BLKSIZE                                                 
         B     FOUNDIT                                                          
NEWFILEB EQU   *                                                                
         MVC   BLOCKSIZ,RECLGTH                                                 
         B     FOUNDIT                                                          
NEWFILEC EQU   *                                                                
         MVC   BLOCKSIZ,RECLGTH                                                 
         AP    BLOCKSIZ,=P'4'                                                   
*                                                                               
*  IF THE PASSED RETURN CODE IS 4 THEN SET THE FUNCTION CODE TO CLOFIL.         
*  RESET THE RECORD LENGTH IF THIS IS NOT A SHORT CALL. SET UP THE              
*  PARAMETER ADDRESSES ( NOTE THAT THE ADDRESS OF THE IOAREA IS                 
*  REFRESHED ON EVERY CALL ) AND CALL DLUIOMAN. AFTER THE CALL THE              
*  RETURN CODE IS SET TO INDICATE WHAT HAPPENED DURING THE CALL AND             
*  THE ERROR CODE FROM DLUIOMAN IS SAVED. ON A FIRST CALL OR A RE-OPEN          
*  ISSUE AN OPEN OR IGNORE MESSAGE ( REGISTER 15 WILL BE NON ZERO IF            
*  THE FILE IS ASSIGNED IGNORE).                                                
*                                                                               
FOUNDIT  EQU   *                                                                
         CP    RETCODE,=P'4'                                                    
         BNE   FOUNDITA                                                         
         MVC   FUNCTION,=C'CLOFIL'                                              
FOUNDITA EQU   *                                                                
         CLM   R6,B'1000',=X'80'                                                
         BE    FOUNDITB                                                         
         PACK  RECLGTH,RECSIZE                                                  
         B     FOUNDITC                                                         
FOUNDITB EQU   *                                                                
         L     R9,0(R11)                                                        
FOUNDITC EQU   *                                                                
         CLC   RECFORM(2),=C'U '                                                
         BNE   FOUNDITD                                                         
         MVC   BLOCKSIZ,RECLGTH                                                 
FOUNDITD EQU   *                                                                
         LA    R2,DCBNAME                                                       
         ST    R2,DLUIOADR                                                      
         ST    R5,DLUIOADR+4                                                    
         MVI   DLUIOADR+8,X'80'                                                 
         LA    R2,BLOCKSIZ                                                      
         STCM  R2,B'0111',DLUIOADR+9                                            
         LA    R1,DLUIOADR                                                      
         CALL  DLUIOMAN                                                         
         ZAP   RECCOUNT,READCT                                                  
         SP    RECCOUNT,CORRCNT                                                 
         ST    R15,SAVER15                                                      
         ZAP   RETCODE,=P'0'                                                    
         MVC   SAVEERR,ERRCODE                                                  
         CLI   FIRSTSW,C' '                                                     
         BE    ISITCLSD                                                         
         CLC   SAVER15,=F'0'                                                    
         BE    NOTIGN                                                           
         MVC   MSG+10(5),=C'IGN  '                                              
         B     RESTOFIT                                                         
NOTIGN   EQU   *                                                                
         MVC   MSG+10(5),=C'OPEN '                                              
RESTOFIT EQU   *                                                                
         MVC   MSG+19(3),DCBNAME+4                                              
         MVC   MSG+23(6),=C'      '                                             
         MVC   MSG+29(8),=C'        '                                           
         LA    R1,WTLPARM                                                       
         CALL  WTL                                                              
*                                                                               
*  CHECK TO SEE IF THE FILE IS CLOSED.                                          
*                                                                               
ISITCLSD EQU   *                                                                
         CLI   FUNCTION,X'FF'                                                   
         BE    CLOSED                                                           
         CLC   FUNCTION,=C'CLOFIL'                                              
         BE    CLOSED                                                           
*                                                                               
*  CHECK TO SEE IF THE RECORD READ IS A /* OR /& CARD. IF IT IS                 
*  ADD 1 TO THE CORRECTION COUNTER AND GO READ ANOTHER RECORD.                  
*  IF IT IS NOT GO CHECK FOR ANY ERRORS FROM DLUIOMAN.                          
*                                                                               
         CLC   0(3,R5),=C'/* '                                                  
         BE    SPECCARD                                                         
         CLC   0(3,R5),=C'/&& '                                                 
         BNE   CHKERR                                                           
SPECCARD EQU   *                                                                
         AP    CORRCNT,=P'1'                                                    
         B     FINDIT                                                           
*                                                                               
*  THE FILE IS CLOSED. SET THE FIRST BYTE OF DCBNAME TO HIGH VALUES.            
*  IF THE FILE IS RE-OPENED A CHECK WILL BE MADE FOR HIGH VALUES AND            
*  THE AREA INITIALIZED AGAIN. SET THE RETURN CODE TO 4 AND PRINT               
*  THE FILE COUNT IF NOT ASSIGNED IGNORE.                                       
*                                                                               
CLOSED   EQU   *                                                                
         MVI   DCBNAME,X'FF'                                                    
         ZAP   RETCODE,=P'4'                                                    
         CLC   SAVER15,=F'0'                                                    
         BNE   GOBACK                                                           
         MVC   MSG+10(5),=C'CLOSE'                                              
         MVC   MSG+19(3),DCBNAME+4                                              
         MVC   MSG+23(6),=C'COUNT='                                             
         MVC   MSG+29(8),=X'4020202020202120'                                   
         ED    MSG+29(8),RECCOUNT                                               
         LA    R1,WTLPARM                                                       
         CALL  WTL                                                              
*                                                                               
*  CHECK THE ERROR CODE RETURNED FROM DLUIOMAN. IGNORE LABEL ERRORS             
*  SO THAT THIS WILL WORK ONLINE IN CMS.                                        
*                                                                               
CHKERR   EQU   *                                                                
         CLI   SAVEERR,C'E'                                                     
         BNE   GOBACK                                                           
         CLI   SAVEERR+1,C'8'                                                   
         BE    GOBACK                                                           
         CLI   SAVEERR+1,C'1'                                                   
         BNE   REALBAD                                                          
VISERR   EQU   *                                                                
         ZAP   RETCODE,=P'8'                                                    
         B     GOBACK                                                           
REALBAD  EQU   *                                                                
         ZAP   RETCODE,=P'9'                                                    
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLSREAD  EYECATCHER *****'                               
MYSAVE   DS    18F           THIS PROGRAM'S SAVE AREA                           
SAVER15  DS    F             REGISTER 15 SAVED HERE                             
DLUIOADR DS    3F            ADDRESSES OF PARAMETERS TO DLUIOMAN                
FIRSTSW  DS    CL1           FIRST TIME FOR FILE INDICATOR                      
SAVEERR  DS    CL6           ERROR CODE SAVED HERE                              
*                                                                               
WTLPARM  DC    A(MSGLGTH)                                                       
         DC    A(FLAG)                                                          
         DC    A(REPLY)                                                         
         DC    X'80'                                                            
         DC    AL3(REPLAREA)                                                    
MSGLGTH  DC    PL2'38'                                                          
CC       DC    CL1' '                                                           
MSG      DC    CL37' DLSREAD        SYS                  '                      
FLAG     DC    CL1'P'                                                           
REPLY    DC    CL3'NO '                                                         
REPLAREA DS    CL1                                                              
*                                                                               
CNTAREAS DS    44F           COUNT AREA ADDRESSES SAVED HERE                    
PRMAREAS DC    2156XL1'00'   FILE AREAS ( 44 FILES OF 49 BYTES EACH )           
*                                                                               
         LTORG                                                                  
*                                                                               
*  DESCRIPTION OF PARAMETER 1 FROM APPLICATION PROGRAM.                         
*                                                                               
DLP1     DSECT                                                                  
SYSNNN   DS    CL6                                                              
*                                                                               
*  DESCRIPTION OF PARAMETER 2 FROM APPLICATION PROGRAM.                         
*                                                                               
DLP2     DSECT                                                                  
RETCODE  DS    PL1                                                              
*                                                                               
*  DESCRIPTION OF PARAMETER 4 FROM APPLICATION PROGRAM.                         
*                                                                               
DLP4     DSECT                                                                  
RECSIZE  DS    CL5                                                              
*                                                                               
*  DESCRIPTION OF PARAMETER 5 FROM APPLICATION PROGRAM.                         
*                                                                               
DLP5     DSECT                                                                  
BLKSIZE  DS    CL5                                                              
*                                                                               
*  DESCRIPTION OF PARAMETER 6 FROM APPLICATION PROGRAM.                         
*                                                                               
DLP6     DSECT                                                                  
RECFORM  DS    CL3                                                              
*                                                                               
*  DESCRIPTION OF PARAMETER 7 FROM APPLICATION PROGRAM.                         
*                                                                               
DLP7     DSECT                                                                  
RECCOUNT DS    PL4                                                              
*                                                                               
*  DESCRIPTION OF THE AREA SET UP FOR EACH FILE. NOTE THAT THE                  
*  FIRST FIELD IS PARAMETER 1 FROM DLSREAD ( THIS IS USED AS                    
*  THE SEARCH ARGUMENT ) AND THE REMAINING FIELDS EXCEPT THE                    
*  LAST TWO FIELDS ARE IN THE FIRST PARAMETER TO DLUIOMAN. THE                  
*  SECOND LAST FIELD CONTAINS THE PASSED BLOCKSIZE AND IS                       
*  PARAMETER 3 TO DLUIOMAN. THE LAST FIELD IS A CORRECTION TO                   
*  THE RECORDS READ COUNT (SOME FILES CONTAIN /* AND OR /&                      
*  CARDS - THESE ARE BYPASSED BUT THE RECORD COUNT THEN NEEDS                   
*  TO BE REDUCED).                                                              
*                                                                               
DLUIOP1  DSECT                                                                  
DLSYSNUM DS    CL6                                                              
DCBNAME  DS    CL7                                                              
FUNCTION DS    CL6                                                              
ERRCODE  DS    CL6                                                              
RECLGTH  DS    PL5                                                              
READCT   DS    PL5                                                              
WRITECT  DS    PL5                                                              
BLOCKSIZ DS    PL5                                                              
CORRCNT  DS    PL4                                                              
         END                                                                    
