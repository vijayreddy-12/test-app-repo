DLUIODCB START                                                                  
*        EXTRN EOF                                                              
*        EXTRN DCBOXIT                                                          
*        EXTRN DLUIOERR                                                         
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  GO GET ENOUGH VIRTUAL STORAGE TO CONTAIN THE DCB. THEN MOVE THE              
*  DCB INTO THE VIRTUAL STORAGE AREA.                                           
*                                                                               
         LA    R10,DCBLGTH                                                      
         ST    R10,LDCBAREA                                                     
         CALL  DLUIOCNB                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
         STM   R2,R5,WORK1                                                      
         L     R2,DCBAREA                                                       
         LA    R3,DCBLGTH                                                       
         LA    R4,DCBSTART                                                      
         LA    R5,DCBLGTH                                                       
         MVCL  R2,R4                                                            
         LM    R2,R5,WORK1                                                      
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
EOF      LRL   15,*+8
         BR    15
         DC    V(EOF)
DCBOXIT  LRL   15,*+8
         BR    15
         DC    V(DCBOXIT)
DLUIOERR LRL   15,*+8
         BR    15
         DC    V(DLUIOERR)
         
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIODCB EYECATCHER *****'                               
MYSAVE   DS    18F    THIS PROGRAM'S SAVE AREA                                  
*                                                                               
DCBSTART DS    0D                                                               
         DCB   DDNAME=XXXXXXXX,                                        C        
               DSORG=PS,                                               C        
               EODAD=EOF,                                              C        
               EROPT=ABE,                                              C        
               EXLST=XITADDR,                                          C        
               MACRF=(GM),                                             C        
               SYNAD=DLUIOERR                                                   
         DS    0D                                                               
DCBLGTH  EQU   *-DCBSTART                                                       
*                                                                               
         DS    0F                                                               
XITADDR  DC    XL1'05',AL3(DCBOXIT)                                             
         DC    XL4'80000000'                                                    
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
