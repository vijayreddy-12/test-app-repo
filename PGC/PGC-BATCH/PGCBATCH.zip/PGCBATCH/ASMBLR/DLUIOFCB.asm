DLUIOFCB START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 7  - MAPS THE WORK DCB                                              
*  REGISTER 8  - MAPS THE JFCB                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOFLA,R6                                                      
         USING IHADCB,R7                                                        
         USING INFMJFCB,R8                                                      
         LA    R7,WORKDCB                                                       
         LA    R8,JFCBAREA                                                      
*                                                                               
*  DETERMINE THE DDNAME IN THE JCL. TRY TO GET THE NEW DDNAME AND               
*  IF NOT FOUND THEN TRY TO GET THE DDNAME FROM PREVIOUS I/O                    
*  ROUTINES.                                                                    
*                                                                               
GETNEW   EQU   *                                                                
         MVC   DCBDDNAM(7),DCBACBFA                                             
         MVI   DCBDDNAM+7,C' '                                                  
         RDJFCB WORKDCB                                                         
         LTR   R15,R15                                                          
         BNZ   GETOLD                                                           
         MVC   ACDCBACB(7),DCBACBFA                                             
         MVI   ACDCBACB+7,C' '                                                  
         B     GOTIT                                                            
GETOLD   EQU   *                                                                
         MVC   DCBDDNAM,PVDCBACB                                                
         RDJFCB WORKDCB                                                         
         LTR   R15,R15                                                          
         BNZ   NODDNAME                                                         
         MVC   ACDCBACB,PVDCBACB                                                
*                                                                               
*  WE'VE GOT THE JFCB. SAVE THE FILE ID.                                        
*                                                                               
GOTIT    EQU   *                                                                
         MVC   FILEID,JFCBDSNM                                                  
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  UNABLE TO FIND THE DDNAME.                                                   
*                                                                               
NODDNAME EQU   *                                                                
         MVC   ERRCODE,=C'E3    '                                               
         B     GOBACK                                                           
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOFCB EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         DS    0D                                                               
WORKDCB  DCB   DDNAME=XXXXXXXX,                                        C        
               DSORG=PS,                                               C        
               EXLST=JFCBXIT,                                          C        
               MACRF=(PM)                                                       
*                                                                               
         DS    0F                                                               
JFCBXIT  DC    XL1'07',AL3(JFCBAREA)                                            
         DC    XL4'80000000'                                                    
*                                                                               
         DS    0F                                                               
JFCBAREA DS    CL176                                                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOFLA                                                         
         DCBD  DSORG=PS                                                         
         DSECT                                                                  
         IEFJFCBN                                                               
         END                                                                    
