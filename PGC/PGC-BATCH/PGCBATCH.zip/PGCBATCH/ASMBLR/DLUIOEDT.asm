DLUIOEDT START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
*                                                                               
*  BRANCH TO THE APPROPRIATE LOGIC DEPENDING UPON THE FILE TYPE.                
*                                                                               
         CLC   DCBACBP1(2),=C'SQ'                                               
         BE    SEQ                                                              
         CLC   DCBACBP1(2),=C'VS'                                               
         BE    VSAM                                                             
         B     EDITERR                                                          
*                                                                               
*  THIS IS A SEQUENTIAL FILE.                                                   
*                                                                               
SEQ      EQU   *                                                                
         CLI   DCBACBP1+2,C'I'                                                  
         BE    SEQA                                                             
         CLI   DCBACBP1+2,C'O'                                                  
         BNE   EDITERR                                                          
SEQA     EQU   *                                                                
         CLI   DCBACBP1+3,C'F'                                                  
         BE    SEQB                                                             
         CLI   DCBACBP1+3,C'V'                                                  
         BNE   EDITERR                                                          
SEQB     EQU   *                                                                
         CLC   DCBACBP1+4(3),=C'IN '                                            
         BE    GOBACK                                                           
         CLC   DCBACBP1+4(3),=C'IPT'                                            
         BE    GOBACK                                                           
         CLI   DCBACBP1+4,C'0'                                                  
         BL    EDITERR                                                          
         CLI   DCBACBP1+4,C'9'                                                  
         BH    EDITERR                                                          
         CLI   DCBACBP1+5,C'0'                                                  
         BL    EDITERR                                                          
         CLI   DCBACBP1+5,C'9'                                                  
         BH    EDITERR                                                          
         CLI   DCBACBP1+6,C'0'                                                  
         BL    EDITERR                                                          
         CLI   DCBACBP1+6,C'9'                                                  
         BH    EDITERR                                                          
         B     GOBACK                                                           
*                                                                               
*  THIS IS A VSAM FILE.                                                         
*                                                                               
VSAM     EQU   *                                                                
         CLI   DCBACBP1+2,C'I'                                                  
         BE    VSAMA                                                            
         CLI   DCBACBP1+2,C'O'                                                  
         BNE   EDITERR                                                          
VSAMA    EQU   *                                                                
         CLI   DCBACBP1+3,C'F'                                                  
         BE    VSAMB                                                            
         CLI   DCBACBP1+3,C'V'                                                  
         BNE   EDITERR                                                          
VSAMB    EQU   *                                                                
         CLI   DCBACBP1+4,C'0'                                                  
         BL    EDITERR                                                          
         CLI   DCBACBP1+4,C'9'                                                  
         BH    EDITERR                                                          
         CLI   DCBACBP1+5,C'0'                                                  
         BL    EDITERR                                                          
         CLI   DCBACBP1+5,C'9'                                                  
         BH    EDITERR                                                          
         CLI   DCBACBP1+6,C'0'                                                  
         BL    EDITERR                                                          
         CLI   DCBACBP1+6,C'9'                                                  
         BH    EDITERR                                                          
         CLC   ACCTYPE,=C'KEYED'                                                
         BE    GOBACK                                                           
         CLC   ACCTYPE,=C'ENTRY'                                                
         BE    GOBACK                                                           
         CLC   ACCTYPE,=C'RLREC'                                                
         BNE   EDITERR                                                          
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  AN EDIT ERROR HAS BEEN FOUND.                                                
*                                                                               
EDITERR  EQU   *                                                                
         MVC   ERRCODE,=C'E2    '                                               
         B     GOBACK                                                           
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOEDT EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         END                                                                    
