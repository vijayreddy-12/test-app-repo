DLUIOMAN START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - ADDRESS OF FIRST PARAMETER FROM CALLING PROGRAM                
*  REGISTER 4  - ADDRESS OF SECOND PARAMETER FROM CALLING PROGRAM               
*  REGISTER 5  - ADDRESS OF THIRD PARAMETER FROM CALLING PROGRAM                
*  REGISTER 6  - ADDRESS OF FOURTH PARAMETER TO CALLED PROGRAM                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         LA    R14,MYSAVE                                                       
         ST    R14,8(R13)                                                       
         ST    R13,MYSAVE+4                                                     
         LR    R13,R14                                                          
         LM    R3,R5,0(R1)                                                      
         LA    R6,PARM4                                                         
*                                                                               
*  IF THIS IS THE FIRST CALL LOAD THE PHASE DLUIOSON. THIS IS THE NAME          
*  OF THE PHASE THAT HAS THE ACTUAL IO LOGIC. THE ENTRY POINT ADDRESS           
*  IS RETURNED IN REGISTER 1. ON FIRST CALL ZERO THE SEARCH KEY                 
*  POINTERS AND THE COMMON AREA ADDRESS. THIS ALERTS DLUIODRV THAT IT           
*  IS THE FIRST TIME THRU AND TO PUT ACTUAL ADDRESSES IN THESE FIELDS.          
*  DLUIODRV IS THE DRIVER ( CONTROLLER ) ROUTINE IN PHASE DLUIOSON.             
*                                                                               
         CLI   PASSFLAG,FRSTPASS                                                
         BNE   GOTIT                                                            
         MVI   PASSFLAG,NOTFIRST                                                
         LOAD  EP=DLUIOSON                                                      
         ST    R0,LOADPNT                                                       
         XC    FRSTFILE,FRSTFILE                                                
         XC    THISFILE,THISFILE                                                
         XC    COMMAREA,COMMAREA                                                
*                                                                               
*  AT THIS POINT THE FIELD 'LOADPNT' CONTAINS THE ADDRESS OF PHASE              
*  DLUIOSON. SET UP THE PARAMETER ADDRESSES AND BRANCH TO THE PHASE.            
*                                                                               
GOTIT    EQU   *                                                                
         STM   R3,R6,PARMADDR                                                   
         LA    R1,PARMADDR                                                      
         L     R15,LOADPNT                                                      
         BALR  R14,R15                                                          
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         LTORG                                                                  
         DC    C'***** DLUIOMAN EYECATCHER *****'                               
MYSAVE   DS    18F           THIS PROGRAM'S SAVE AREA                           
LOADPNT  DS    F             ADDRESS OF DLUIOSON PHASE SAVED HERE               
PARMADDR DS    4F            PARAMETER ADDRESSES                                
PASSFLAG DC    CL1'Y'        INDICATOR FOR THE FIRST TIME THRU                  
FRSTPASS EQU   C'Y'             - THIS IS THE FIRST PASS                        
NOTFIRST EQU   C'N'             - THIS IS NOT THE FIRST PASS                    
*                                                                               
PARM4    DS    0F            FOURTH PARAMETER TO CALLED PROGRAM                 
FRSTFILE DS    F             ADDRESS OF FIRST FILE'S SEARCH KEY                 
THISFILE DS    F             ADDRESS OF THIS FILE'S SEARCH KEY                  
COMMAREA DS    F             ADDRESS OF COMMON AREA                             
         END                                                                    
