DLUIOCLO START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 7  - POINTS TO DCB/ACB                                              
*  REGISTER 8  - WORK REGISTER                                                  
*  REGISTER 9  - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  CLOSE EITHER THIS FILE OR THEM ALL DEPENDING UPON THE FUNCTION               
*  CODE. SET THE INDICATOR TO FILE CLOSED.                                      
*                                                                               
         L     R9,THISFILE                                                      
         CLC   FUNCTION,=C'CLOALL'                                              
         BNE   CLOSEIT                                                          
         L     R9,FRSTFILE                                                      
CLOSEIT  EQU   *                                                                
         CLI   0(R9),X'00'                                                      
         BE    GOBACK                                                           
         L     R6,8(R9)                                                         
         LTR   R6,R6                                                            
         BZ    ANYMORE                                                          
         CLI   FILETYPE,VSAMFILE                                                
         BE    CLOSEACB                                                         
*                                                                               
*  CLOSE THE DCB. IF THIS IS AN INPUT FILE AND THE FUNCTION CODE                
*  IS NOT HIGH VALUES ( I.E. THE FILE IS BEING CLOSED EARLY ) THEN              
*  SET RECCNT TO ZERO SO THAT NO BALANCE CHECKING WILL BE DONE.                 
*                                                                               
CLOSEDCB EQU   *                                                                
         CLC   FUNCTION,=C'CLOALL'                                              
         BE    ANYMORE                                                          
         CLI   OPENIND,NOTOPEN                                                  
         BE    ANYMORE                                                          
         MVI   OPENIND,NOTOPEN                                                  
         L     R7,DCBAREA                                                       
         CLOSE ((7))                                                            
         FREEPOOL (7)                                                           
         CLI   DCBACBFA+2,C'O'                                                  
         BE    ANYMORE                                                          
         CLI   FUNCTION,X'FF'                                                   
         BE    ANYMORE                                                          
         ZAP   RECCNT,=P'0'                                                     
         B     ANYMORE                                                          
*                                                                               
*  CLOSE THE ACB. IF THERE IS AN ERROR IN THE CLOSE NOTE IT BUT                 
*  KEEP ON PROCESSING.                                                          
*                                                                               
CLOSEACB EQU   *                                                                
         CLI   OPENIND,NOTOPEN                                                  
         BE    ANYMORE                                                          
         MVI   OPENIND,NOTOPEN                                                  
         L     R7,ACBAREA                                                       
         CLOSE ((7))                                                            
         LTR   R15,R15                                                          
         BZ    ANYMORE                                                          
         BAL   R8,CLOSEERR                                                      
*                                                                               
*  CHECK TO SEE IF THERE ARE ANY MORE CLOSES TO BE DONE.                        
*                                                                               
ANYMORE  EQU   *                                                                
         CLC   FUNCTION,=C'CLOALL'                                              
         BNE   GOBACK                                                           
         LA    R9,12(R9)                                                        
         B     CLOSEIT                                                          
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  ERROR ENCOUNTERED WHILE CLOSING A FILE.                                      
*                                                                               
CLOSEERR EQU   *                                                                
         MVC   ERRCODE(2),=C'E9'                                                
         STC   R15,HEXERR                                                       
         SHOWCB ACB=(7),AREA=(S,WORK4),LENGTH=4,FIELDS=(ERROR)                  
         MVC   HEXERR+1(1),WORK4+3                                              
         CALL  DLUIOXPF                                                         
         BR    R8                                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOCLO EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
