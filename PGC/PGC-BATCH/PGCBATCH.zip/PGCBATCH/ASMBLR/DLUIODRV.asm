DLUIODRV START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 7  - ADDRESS OF THE COMMON AREA                                     
*  REGISTER 8  - ADDRESS OF PASSED BLOCKSIZE ( IF ANY )                         
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         LM    R3,R4,0(R1)                                                      
         L     R5,12(R1)                                                        
         L     R8,8(R1)                                                         
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
         USING DLUIOCOM,R7                                                      
*                                                                               
*  INITIALIZE THE ERROR CODE.                                                   
*                                                                               
         XC    ERRCODE,ERRCODE                                                  
*                                                                               
*  DETERMINE IF THIS IS THE FIRST TIME THRU.                                    
*                                                                               
         CLC   COMMAREA,=F'0'                                                   
         BNE   SEARCH                                                           
*                                                                               
*  ON FIRST CALL SET THE FIELD 'FRSTFILE' TO POINT TO THE SEARCH                
*  KEYS IN PROGRAM DLUIOSCH.                                                    
*                                                                               
         MVC   FRSTFILE,=V(FILEKEYS)                                            
*                                                                               
*  NOW GET STORAGE FOR A COMMON AREA FOR THE JOB. THIS AREA IS NOT              
*  UNIQUE TO A PARTICULAR FILE. IT IS AN AREA THAT CAN BE USED BY               
*  ANY FILE. AT PRESENT IT IS USED WITH THE CONTROL AND BALANCE                 
*  FILES. GET 128 BYTES FOR THIS AREA AND INITIALIZE IT TO ZEROES.              
*                                                                               
         GETMAIN RU,LV=128                                                      
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,COMMAREA                                                      
         LR    R7,R1                                                            
         XC    DLUIOCOM(128),DLUIOCOM                                           
*                                                                               
*  NOW GET STORAGE FOR INTERNAL FILES ( STORAGE IS NEEDED FOR THE               
*  PARAMETER LISTS AND RECAREAS ). THE FIRST IO AREA MUST BE LARGE              
*  ENOUGH TO HOLD THE BALANCE OR CONTROL RECORD AND THE SECOND AREA             
*  IS USED FOR THE MESSAGES. SAVE THE ADDRESSES OF THESE AREAS IN               
*  THE COMMON AREA JUST OBTAINED.                                               
*                                                                               
         GETMAIN RU,LV=256                                                      
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,INTRNLP1                                                      
         GETMAIN RU,LV=1920                                                     
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,INTRNLR1                                                      
         GETMAIN RU,LV=256                                                      
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,INTRNLP2                                                      
         GETMAIN RU,LV=256                                                      
         LTR   R15,R15                                                          
         BNZ   VISERR                                                           
         ST    R1,INTRNLR2                                                      
*                                                                               
*  SEARCH FOR THE DESIRED FILE. DLUIOSCH RETURNS THE ADDRESS OF                 
*  THE KEY IN THE FIELD 'THISFILE'. A FILE AREA MUST BE OBTAINED                
*  IF THE CORRESPONDING ADDRESS OF THE FILE AREA FOR THIS KEY IS                
*  ZERO. IF THE ADDRESS IS NOT ZERO THEN LOAD THAT ADDRESS INTO                 
*  REGISTER 6.                                                                  
*                                                                               
SEARCH   EQU   *                                                                
         CALL  DLUIOSCH                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
         L     R6,THISFILE                                                      
         L     R6,8(R6)                                                         
         LTR   R6,R6                                                            
         BNZ   DOREQ                                                            
*                                                                               
*  THIS IS THE FIRST CALL FOR THIS FILE. STARTUP LOGIC FOR A NEW                
*  FILE CONSISTS OF THE FOLLOWING:                                              
*     A) EDIT THE PASSED PARAMETERS                                             
*     B) GET VIRTUAL STORAGE FOR THE NEW FILE ( ROUTINE DLUIOGFA                
*        WILL CLEAR THE NEW AREA AND PUT ITS KEY AND FILE AREA                  
*        ADDRESS IN THE SEARCH AREA )                                           
*     C) POINT REGISTER 6 TO THE NEW AREA                                       
*     D) INITIALIZE FIELDS IN THE NEW FILE AREA                                 
*     E) DETERMINE IF A BLOCKSIZE WAS PASSED                                    
*     F) READ THE JFCB TO GET INFO ABOUT THE FILE                               
*     G) TRY AND READ THE CONTROL RECORD ( FOR BLOCKSIZE, COUNTS ... )          
*     H) CALCULATE THE BLOCKSIZE IF REQUIRED ( FOR DCB'S ONLY )                 
*     I) GENERATE THE DCB ( OR ACB )                                            
*                                                                               
         CALL  DLUIOEDT                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
         CALL  DLUIOGFA                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
         L     R6,THISFILE                                                      
         L     R6,8(R6)                                                         
         CALL  DLUIOINL                                                         
         ZAP   APPBLOCK,=P'0'                                                   
         CLM   R4,B'1000',=X'80'                                                
         BE    STARTUPA                                                         
         MVC   APPBLOCK,0(R8)                                                   
STARTUPA EQU   *                                                                
         CALL  DLUIOFCB                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
*        CALL  DLUIOCNT                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
         CLI   FILETYPE,VSAMFILE                                                
         BE    STARTUPV                                                         
STARTUPS EQU   *                                                                
         CALL  DLUIOBLK                                                         
         CALL  DLUIODCB                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
         B     DOREQ                                                            
STARTUPV EQU   *                                                                
         CALL  DLUIOACB                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    GOBACK                                                           
*                                                                               
*  CALL THE APPROPRIATE ROUTINE TO DO THE REQUEST. FOR SEQUENTIAL               
*  FILES CALL DLUIOSTA TO KEEP RECORD LENGTH STATISTICS ( ASSUMING              
*  THERE WAS NO ERROR DURING THE I/O ). IF THE FILE(S) IS CLOSED ON             
*  RETURN GO DO CLOSING PROCEDURES.                                             
*                                                                               
DOREQ    EQU   *                                                                
         CLI   FILETYPE,VSAMFILE                                                
         BE    VSAM                                                             
SEQ      EQU   *                                                                
         CALL  DLUIOSEQ                                                         
         CLI   ERRCODE,C'E'                                                     
         BE    SEQA                                                             
         CALL  DLUIOSTA                                                         
SEQA     EQU   *                                                                
         CLI   OPENIND,NOTOPEN                                                  
         BE    CLOSPROC                                                         
         B     GOBACK                                                           
VSAM     EQU   *                                                                
         CALL  DLUIOVSM                                                         
         CLI   OPENIND,NOTOPEN                                                  
         BE    CLOSPROC                                                         
         CLC   FUNCTION,=C'CLOALL'                                              
         BE    CLOSPROC                                                         
         B     GOBACK                                                           
*                                                                               
*  CREATE CONTROL AND BALANCE RECORDS FOR THE FILE(S). THIS WILL                
*  BE DONE FOR THIS FILE ONLY OR THEM ALL DEPENDING UPON THE                    
*  FUNCTION CODE. IF THE ADDRESS OF A FILE AREA IS ZERO THEN IT                 
*  HAS BEEN CLOSED PREVIOUSLY AND CONTROL AND BALANCE RECORDS ARE               
*  NOT CREATED.                                                                 
*                                                                               
CLOSPROC EQU   *                                                                
         L     R10,THISFILE                                                     
         CLC   FUNCTION,=C'CLOALL'                                              
         BNE   NEXTAREA                                                         
         L     R10,FRSTFILE                                                     
NEXTAREA EQU   *                                                                
         CLI   0(R10),X'00'                                                     
         BE    FREESTOR                                                         
         L     R6,8(R10)                                                        
         LTR   R6,R6                                                            
         BZ    ANYMORE                                                          
         CLI   FILETYPE,VSAMFILE                                                
         BE    CNTBAL                                                           
         CLC   FUNCTION,=C'CLOALL'                                              
         BE    ANYMORE                                                          
CNTBAL   EQU   *                                                                
*        CALL  DLUIOCNT                                                         
*        CALL  DLUIOBAL                                                         
ANYMORE  EQU   *                                                                
         CLC   FUNCTION,=C'CLOALL'                                              
         BNE   FREESTOR                                                         
         LA    R10,12(R10)                                                      
         B     NEXTAREA                                                         
*                                                                               
*  NOW FREE UP STORAGE USED BY THE FILE(S). DLUIOFVS FREES UP STORAGE           
*  FOR THIS FILE ONLY OR THEM ALL DEPENDING UPON THE FUNCTION CODE.             
*                                                                               
FREESTOR EQU   *                                                                
         CALL  DLUIOFVS                                                         
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  AN ERROR WAS DETECTED ON A GETMAIN.                                          
*                                                                               
VISERR   EQU   *                                                                
         MVC   ERRCODE,=C'E1    '                                               
         B     GOBACK                                                           
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIODRV EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         COPY  DLUIOCOM                                                         
         END                                                                    
