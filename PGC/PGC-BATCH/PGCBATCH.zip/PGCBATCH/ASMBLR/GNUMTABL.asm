GNUMTABL START                                                                  
GNUMTABL AMODE 24                                                               
GNUMTABL RMODE 24                                                               
*                                                                               
         COPY  REGISTER                                                         
**********************************************************************          
*                                                                    *          
*        THIS MODULE IS PASSED 3 PARAMETERS - PARA1 - TABLE NO       *          
*                                           - PARA2 - TABLE ARG      *          
*                                           - PARA3 - TABLE RETURN   *          
*        THE FIRST TIME THIS MODULE IS ENTERED IT LOADS  PHASE TABLE *          
*        'GNUMONIC'.                                                 *          
*                                                                    *          
*   NOTE ====> IF THIS PROGRAM CHANGES, CHECK PGM GWUTCNUM FOR       *          
*                REQUIRED CHANGES.   MARCUS/89                       *          
*                                                                    *          
*                          HISTORY                                   *  00170023
*                                                                    *  00170023
*********************************************************************** 00180023
*                                                                     * 00190023
*     GPSY-REL-1........                                              * 00190023
*                                                                     * 00190023
*    OCT/89  MARCUS DRURY       ADD A 3RD BASE ADDRESS BECAUSE OF THE *         
*                               INCRESE SIZE OF GNUMONIC              *         
*                                                                     *         
*    JUL/2004  TRUDY            ADD A 4TH BASE ADDRESS REGISTER DUE   *         
*                               TO INCREASE IN SIZE OF GNUMONIC       *         
*    15MAR2008 IBM GR           ENTERPRISE COMPILER UPGRADE           *         
*                               PROJECT - BUNDLE 5                    *         
*                                                                     *         
*********************************************************************** 00180023
*                                                                     *         
***********************************************************************         
*                                                                               
         STM   R14,R12,12(R13)          SAVE REGISTERS                          
         BALR  R11,0                    SET BASE REGISTER                       
         USING *,R11                                                            
         ST    R13,STOR13                                                       
         LA    R13,SAVEAREA                                                     
         LM    R2,R4,0(R1)              LOAD PARAMETERS R2 R3 R4                
         CLI   8(R1),X'80'                                                      
         BE    LOADPHAS                                                         
         NI    12(R1),X'80'                                                     
         L     R6,12(R1)                                                        
         L     R5,0(R6)                                                         
         B     TABLODED                                                         
*                                                                               
LOADPHAS EQU   *                                                                
         NOP   SETREG                                                           
         MVI   LOADPHAS+1,X'F0'         BRANCH TO TABLODED AFTER 1ST            
         LOAD  EP=GNUMONIC                                                      
         ST    R0,TABLAREA                                                      
SETREG   EQU   *                                                                
         L     R5,TABLAREA              SET UP 1ST BASE REGISTER                
TABLODED EQU   *                                                                
         MVC   TABNO,0(R2)              ALIGN PARA1 ON 1/2 WD BOUNDRY           
         LA    R10,4095(R5)                                                     
         LA    R10,1(R10)                                                       
         LA    R9,4095(R10)                                                     
         LA    R9,1(R9)                                                         
         LA    R2,4095(R9)                                                      
         LA    R2,1(R2)                                                         
         MVC   0(15,R4),SPACER          MOVE SPACE TO RETURN                    
         L     R6,TABNOALL              LOAD PARA1 INTO R6                      
         C     R6,16(R5)                GNUMONIC TABLE ACTUALLY STARTS          
*                                       IN 17TH BYTE OF AREA POINTED            
*                                       TO BY R5 - DUE TO 3RD BASE REG          
*                                       ADDED TO GNUMONIC                       
         BH    GETBACK                  NUMBER OF TABLE ENTS -YES BR            
         C     R6,ONEFULL               IS TABLE NO LESS THAN +1                
         BL    GETBACK                  YES- BR                                 
         MH    R6,TABENTLG              MULTIPLY TABLE NO. BY ENT. LGTH         
         AR    R6,R5                                                            
         A     R6,=F'24'                ADJUST R6 DUE TO 4TH BASE REG           
*                                       WHICH WAS ADDED TO GNUMONIC             
         MVC   COMPARG+1(1),0(R6)       MOVE CLC LGTH TO INST                   
         MVC   COMPTAB+2(2),6(R6)       MOVE ADDCON OF MNEMONIC TABLE           
COMPTAB  LA    R7,0                     IN LA INSTRUCTION                       
*                                                                               
COMPLOOP EQU   *                                                                
COMPARG  CLC   0(1,R3),0(R7)            COMPARE ARG TO TABLE ARG                
         BE    FOUNDIT                  EQUAL BR TO FOUNDIT                     
         BL    NOMATCH                  LOW  BR TO NOMATCH                      
         AH    R7,4(R6)                 ADD TABLE ENT LGTH TO R7                
         CLI   0(R7),C'*'               IS IT END OF TABLE                      
         BE    NOMATCH                  YES GO TO NO MATCH                      
         B     COMPLOOP                 NO SEARCH AGAIN                         
NOMATCH  EQU   *                                                                
         MVC   MOVEARG+1(1),2(R6)       MOVE ARG LENGTH TO INST LENGTH          
MOVEARG  MVC   0(1,R4),0(R3)            MOVE ARG TO RETURN                      
         B     GETBACK                  BR TO GETBACK                           
FOUNDIT  EQU   *                                                                
         MVC   HALFWORK,3(R6)           MOVE ARG LGTH TO WORK                   
         AH    R7,WORKHALF              ADD  ARG LGTH TO R7                     
         MVC   MOVEDESC+1(1),1(R6)      MOVE DESC LGTH TO MVC INST              
MOVEDESC MVC   0(1,R4),0(R7)            MOVE DESC TO RETURN                     
GETBACK  EQU   *                                                                
         L     R13,STOR13               RESET REGISTERS                         
         LM    R14,R12,12(R13)               AND                                
         BR    R14                         RETURN                               
*                                                                               
*                                                                               
         LTORG                                                                  
SAVEAREA DS    18F                                                              
STOR13   DS    F                                                                
*                                                                               
         DS    0F                                                               
TABENTLG DC    H'8'                                                             
ONEFULL  DC    F'1'                                                             
TABNOALL DS    0F                                                               
         DC    H'0'                                                             
TABNO    DS    H                                                                
WORKHALF DS    0H                                                               
         DC    X'00'                                                            
HALFWORK DS    CL1                                                              
SPACER   DC    CL15' '                                                          
TABLAREA DS    F                                                                
GNUMADDR DC    V(GNUMONIC)                                                      
*                                                                               
         END                                                                    
