DLUIOSEQ START                                                                  
         ENTRY EOF                                                              
         ENTRY DCBOXIT                                                          
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS (DATA AREA IN CALLER)                        
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 7  - POINTS TO THE DCB                                              
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
         USING IHADCB,R7                                                        
         L     R7,DCBAREA                                                       
*                                                                               
*  OPEN THE FILE IF REQUIRED.                                                   
*                                                                               
         CLI   OPENIND,FILEOPEN                                                 
         BE    OPENED                                                           
         MVC   DCBDDNAM,ACDCBACB                                                
         MVI   DCBMACR1,X'00'                                                   
         MVI   DCBMACR2,X'00'                                                   
         CLI   DCBACBFA+2,C'O'                                                  
         BE    OPENOUT                                                          
OPENIN   EQU   *                                                                
         OI    DCBMACR1,DCBMRGET                                                
         OI    DCBMACR1,DCBMRMVG                                                
         OPEN  ((7),(INPUT))                                                    
         B     SETOPIND                                                         
OPENOUT  EQU   *                                                                
         OI    DCBMACR2,DCBMRPUT                                                
         OI    DCBMACR2,DCBMRMVP                                                
         OPEN  ((7),(OUTPUT))                                                   
SETOPIND EQU   *                                                                
         MVI   OPENIND,FILEOPEN                                                 
*                                                                               
*  THE FILE IS OPEN OR HAS JUST BEEN OPENED. GO DO THE REQUEST.                 
*                                                                               
OPENED   EQU   *                                                                
         CLC   FUNCTION,=C'GETSEQ'                                              
         BE    GETSEQ                                                           
         CLC   FUNCTION,=C'ADDSEQ'                                              
         BE    ADDSEQ                                                           
         CLC   FUNCTION,=C'CLOFIL'                                              
         BE    CLOSEIT                                                          
         MVC   ERRCODE,=C'E2    '                                               
         B     GOBACK                                                           
*                                                                               
*  READ THE NEXT RECORD. IF A VARIABLE LENGTH RECORD WAS READ                   
*  RETURN THE RECORD LENGTH.                                                    
*                                                                               
GETSEQ   EQU   *                                                                
         GET   (7),(4)                                                          
         AP    SVREAD,=P'1'                                                     
         TM    DCBRECFM,DCBRECV                                                 
         BZ    GOBACK                                                           
         LH    R10,DCBLRECL                                                     
         CVD   R10,WORK1                                                        
         ZAP   RECLGTH,WORK1(8)                                                 
         B     GOBACK                                                           
*                                                                               
*  ADD SEQUENTIAL. SET THE RECORD LENGTH IF A VARIABLE LENGTH                   
*  RECORD IS BEING WRITTEN.                                                     
*                                                                               
ADDSEQ   EQU   *                                                                
         TM    DCBRECFM,DCBRECV                                                 
         BZ    ADDSEQA                                                          
         ZAP   WORK1(8),RECLGTH                                                 
         CVB   R10,WORK1                                                        
         STH   R10,DCBLRECL                                                     
         XC    2(2,R4),2(R4)    SET BYTES 3 AND 4 OF RDW TO X'0000'             
ADDSEQA  EQU   *                                                                
         PUT   (7),(4)                                                          
         AP    SVWRITE,=P'1'                                                    
         B     GOBACK                                                           
*                                                                               
*  CALL ROUTINE DLUIOCLO TO CLOSE THE FILE(S).                                  
*                                                                               
CLOSEIT  EQU   *                                                                
         CALL  DLUIOCLO                                                         
         B     GOBACK                                                           
*                                                                               
*  END OF FILE HAS BEEN REACHED. CALL ROUTINE DLUIOCLO TO CLOSE THE             
*  FILE. THE FUNCTION CODE IS SET TO HIGH VALUES TO INDICATE END OF             
*  FILE.                                                                        
*                                                                               
EOF      EQU   *                                                                
         MVI   FUNCTION,X'FF'                                                   
         MVC   FUNCTION+1(5),FUNCTION                                           
         CALL  DLUIOCLO                                                         
*                                                                               
*  RETURN THE RECORD COUNTS. THEN RETURN TO THE CALLING PROGRAM.                
*                                                                               
GOBACK   EQU   *                                                                
         DROP  R3                                                               
         USING DLUIOPR1,R10                                                     
         L     R10,PARM1ADR                                                     
         MVC   READCT,SVREAD                                                    
         MVC   WRITECT,SVWRITE                                                  
         DROP  R10                                                              
         USING DLUIOPR1,R3                                                      
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  DCB OPEN EXIT ROUTINE. THIS ROUTINE IS EXECUTED JUST BEFORE THE              
*  THE DCB IS OPENED.                                                           
*                                                                               
DCBOXIT  EQU   *                                                                
         ST    R14,SAVE14                                                       
         CLC   DCBLRECL,=X'0000'                                                
         BNE   DCBOXITA                                                         
         ZAP   WORK1(8),RECLGTH                                                 
         CVB   R10,WORK1                                                        
         STH   R10,DCBLRECL                                                     
DCBOXITA EQU   *                                                                
         CLC   DCBBLKSI,=X'0000'                                                
         BNE   DCBOXITB                                                         
         MVC   DCBBLKSI,BLKSIZE+2                                               
DCBOXITB EQU   *                                                                
         CLI   DCBRECFM,X'00'                                                   
         BNE   DCBOXITE                                                         
         CLC   DCBLRECL,DCBBLKSI                                                
         BE    DCBOXITC                                                         
         OI    DCBRECFM,DCBRECBR                                                
DCBOXITC EQU   *                                                                
         CLI   DCBACBFA+3,C'V'                                                  
         BE    DCBOXITD                                                         
         OI    DCBRECFM,DCBRECF                                                 
         B     DCBOXITE                                                         
DCBOXITD EQU   *                                                                
         OI    DCBRECFM,DCBRECV                                                 
DCBOXITE EQU   *                                                                
         L     R14,SAVE14                                                       
         RETURN                                                                 
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOSEQ EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
SAVE14   DS    F                                                                
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         DCBD  DSORG=PS                                                         
         END                                                                    
