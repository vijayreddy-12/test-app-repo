DLUIOBLK START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  SET UP THE BLOCK SIZE. THE CONTENTS OF THE FIELD APPBLOCK WILL               
*  BE ONE OF THE FOLLOWING:                                                     
*     A) ZERO INDICATING THAT A BLOCKSIZE MUST BE CALCULATED.                   
*     B) A VALID BLOCKSIZE PASSED FROM THE APPLICATION PROGRAM OR               
*        FROM THE CONTROL RECORD ( IN THAT ORDER OF PRIORITY ).                 
*        THIS IS CURRENTLY THE ONLY SITUATION HANDLED IN MVS. IT                
*        IS ASSUMED THAT THE APPLICATION PROGRAM PASSES THE BLOCK               
*        SIZE.                                                                  
*  BLOCK FIXED LENGTH OUTPUT FILES WITH A RECORD LENGTH OF 133 AT               
*  3990. THESE ARE FILES THAT ARE GOING TO BE MICRO FICHED.                     
*                                                                               
CALCBLK  EQU   *                                                                
         CP    APPBLOCK,=P'0'                                                   
         BE    CALCBLKA                                                         
         ZAP   WORK4(8),APPBLOCK                                                
         CVB   R10,WORK4                                                        
         ST    R10,BLKSIZE                                                      
         B     GOBACK                                                           
CALCBLKA EQU   *                                                                
*    CALCULATE OPTIMUM BLOCK SIZE HERE ..............                           
*    BLOCK AT 3990 FOR FIXED OUTPUT 133 RECORDS .....                           
*    FOR NOW FLAG THIS AS AN ERROR ..................                           
         MVC   ERRCODE,=C'E2    '                                               
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOBLK EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
