*********H************************************************************* 00041   
*     ***H     DATE       - 16APR94                                     00042   
*     ***H     PROGRAMMER - D.B. EMBURY                                 00043   
*     ***H     ACTION     - RATIONALIZED THE I.T.S. AND GLH VERSIONS OF 00045   
*     ***H                  THIS MODULE.  IT IS ESSENTIALLY THE GLH     00045   
*     ***H                  VERSION WITH AN IMPROVEMENT TO THE SAVE     00045   
*     ***H                  AREA LINKAGE LOGIC (TAKEN FROM THE I.T.S.   00045   
*     ***H                  VERSION).  WHERE THE LOGIC IS DIFFERENT,    00045   
*     ***H                  THE OTHER VERSION'S STATEMENTS ARE INCLUDED 00045   
*     ***H                  AS COMMENTS.                                00045   
*********H************************************************************* 00046   
         SPACE 2                                                        00047   
ZACCVSAM START                                                                  
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER 1 FROM CALLING PROGRAM                               
*  REGISTER 4  - PARAMETER 2 FROM CALLING PROGRAM                               
*  REGISTER 5  - PARAMETER 3 FROM CALLING PROGRAM                               
*  REGISTER 6  - PARAMETER 4 FROM CALLING PROGRAM                               
*  REGISTER 7  - USED AS BASE FOR DESCRIBING EACH FILE AREA                     
*  REGISTER 8  - ADDRESS OF RECORD COUNT FIELDS                                 
*  REGISTER 9  - WORK REGISTER                                                  
*  REGISTER 10 - BASE REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R10,R0                                                           
         USING *,R10,R11,R12                                                    
         LA    R11,2048(R10)                                                    
         LA    R11,2048(R11)                                                    
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
********C************************************************************** 00041   
*     **C*     THE FOLLOWING STATEMENT (COMMENTED OUT) IS FROM THE      00042   
*     **C*     GLH VERSION, IT WAS REPLACED BY THE 3 STATEMENTS         00042   
*     **C*     FOLLOWING IT WHICH ARE FROM THE I.T.S. VERSION.          00042   
********C************************************************************** 00041   
*        LA    R13,MYSAVE                                                       
         LA    R14,MYSAVE                                                       
         ST    R14,8(R13)                                                       
         LR    R13,R14                                                          
         LM    R3,R6,0(R1)                                                      
         USING ZACCP1,R3                                                        
         USING ZACCP2,R4                                                        
         USING ZACCP3,R5                                                        
         USING ZACCP4,R6                                                        
         USING DLUIOP1,R7                                                       
*                                                                               
*  TRY TO FIND THIS FILE IN THE FILE AREAS. IF THE AREA IS FOUND                
*  CHECK TO SEE IF THIS IS A RE-OPEN AND IF SO TREAT IT AS A NEW                
*  FILE.                                                                        
*                                                                               
         LA    R7,PRMAREAS-324                                                  
         LA    R8,CNTAREAS-4                                                    
SCHLOOP  EQU   *                                                                
         LA    R7,324(R7)                                                       
         LA    R8,4(R8)                                                         
         CLI   0(R7),X'00'                                                      
         BE    NEWFILE                                                          
         CLC   ZACBNAME,ZDDNAME                                                 
         BNE   SCHLOOP                                                          
         CLI   ACBNAME,X'FF'                                                    
         BNE   FOUNDIT                                                          
*                                                                               
*  THIS IS THE FIRST TIME THRU FOR THIS FILE OR THE FILE IS                     
*  BEING RE-OPENED. SAVE THE SEARCH ARGUMENT AND THE ADDRESS                    
*  OF THE APPLICATION PROGRAM RECORD COUNTS. THEN SET UP THE                    
*  FIRST PARAMETER FOR DLUIOMAN.                                                
*                                                                               
NEWFILE  EQU   *                                                                
         MVC   ZACBNAME,ZDDNAME                                                 
         LA    R9,ZREAD                                                         
         ST    R9,0(R8)                                                         
         MVC   ACBNAME(2),=C'VS'                                                
         MVC   ACBNAME+2(1),ZDDNAME+4                                           
         MVC   ACBNAME+3(1),ZRECTYPE                                            
         MVI   ACBNAME+4,C'0'                                                   
         MVC   ACBNAME+5(2),ZDDNAME+5                                           
         MVC   ACCTYPE,ZACCTYPE                                                 
         ZAP   PASSWORD(1),=P'0'                                                
********C************************************************************** 00041   
*     **C*     THE FOLLOWING 2 STATEMENTS (COMMENTED OUT) ARE FROM THE  00042   
*     **C*     I.T.S. VERSION. THEY WERE NOT IN THE GLH VERSION.        00042   
********C************************************************************** 00041   
*        CLC   ZFNCTION(3),=C'CLO'      IF WE REQUESTING A CLOSE                
*        BE    FOUNDIT                  DONT WORRY ABOUT OTHER PARMS            
         CLM   R5,B'1000',=X'80'                                                
         BE    FOUNDIT                                                          
         LH    R9,ZPASSWRD                                                      
         LTR   R9,R9                                                            
         BZ    FOUNDIT                                                          
         CVD   R9,WORKFLD                                                       
         ZAP   PASSWORD(1),WORKFLD                                              
         MVC   PASSWORD+1(8),ZPASSWRD+2                                         
*                                                                               
*  MOVE THE FUNCTION CODE AND KEY TO PARAMETER1. FOR OUTPUT                     
*  VARIABLE LENGTH FILES SET UP THE RECORD LENGTH ( FOR                         
*  FUNCTIONS PUTUPD, ADDRAN AND ADDSEQ ONLY ).                                  
*                                                                               
FOUNDIT  EQU   *                                                                
         MVC   FUNCTION,ZFNCTION                                                
         MVC   KEY,ZKEY                                                         
         CLI   ZDDNAME+4,C'I'                                                   
         BE    DOTHEIO                                                          
         CLI   ZRECTYPE,C'F'                                                    
         BE    DOTHEIO                                                          
         CLC   ZFNCTION(3),=C'PUT'                                              
         BE    SETLGTH                                                          
         CLC   ZFNCTION(3),=C'ADD'                                              
         BNE   DOTHEIO                                                          
SETLGTH  EQU   *                                                                
         LH    R9,ZRECLGTH                                                      
         CVD   R9,WORKFLD                                                       
         ZAP   RECLGTH,WORKFLD                                                  
*                                                                               
*  NOW CALL DLUIOMAN.                                                           
*                                                                               
DOTHEIO  EQU   *                                                                
         LA    R9,ACBNAME                                                       
         ST    R9,DLUIOADR                                                      
         MVI   DLUIOADR+4,X'80'                                                 
         STCM  R5,B'0111',DLUIOADR+5                                            
         LA    R1,DLUIOADR                                                      
         CALL  DLUIOMAN                                                         
*                                                                               
*  CLEAR THE ZACCVSAM ERROR CODE AREA AND UPDATE THE RECORD COUNTS.             
*                                                                               
         XC    ZERRCODE,ZERRCODE                                                
         L     R9,0(R8)                                                         
         ZAP   0(4,R9),READCT                                                   
         ZAP   4(4,R9),WRITECT                                                  
         ZAP   8(4,R9),UPDATECT                                                 
         ZAP   12(4,R9),DELETECT                                                
*                                                                               
*  RETURN THE RBA IN THE KEY FIELD FOR ENTRY SEQUENCED FILES                    
*  ( FOR FUNCTION SETLIM AND ALL READS AND WRITES ).                            
*                                                                               
         CLC   ZACCTYPE,=C'ENTRY'                                               
         BNE   RETLGTH                                                          
         CLC   ZFNCTION(3),=C'CLO'                                              
         BE    RETLGTH                                                          
         CLC   ZFNCTION,=C'DELETE'                                              
         BE    RETLGTH                                                          
         MVC   ZKEY(4),KEY                                                      
*                                                                               
*  IF THERE WAS NO ERROR AND IF THE FILE IS NOT CLOSED THEN                     
*  RETURN THE RECORD LENGTH FOR VARIABLE LENGTH FILES ( FOR                     
*  FUNCTIONS GETSEQ AND GETRAN ONLY ).                                          
*                                                                               
RETLGTH  EQU   *                                                                
         CLI   ERRCODE,C'E'                                                     
         BE    GOTANERR                                                         
         CLC   ZFNCTION(3),=C'CLO'                                              
         BE    CLOSED                                                           
         CLI   ZRECTYPE,C'F'                                                    
         BE    GOBACK                                                           
         CLC   ZFNCTION(3),=C'GET'                                              
         BNE   GOBACK                                                           
         ZAP   WORKFLD,RECLGTH                                                  
         CVB   R9,WORKFLD                                                       
         STH   R9,ZRECLGTH                                                      
         B     GOBACK                                                           
*                                                                               
*  SET UP THE ZACCVSAM ERROR CODE.                                              
*                                                                               
GOTANERR EQU   *                                                                
         CLI   ERRCODE+1,C'1'                                                   
         BE    ERR1                                                             
         CLI   ERRCODE+1,C'2'                                                   
         BE    ERR2                                                             
         CLI   ERRCODE+1,C'4'                                                   
         BE    ERR45                                                            
         CLI   ERRCODE+1,C'5'                                                   
         BE    ERR45                                                            
         CLI   ERRCODE+1,C'6'                                                   
         BE    ERR6                                                             
         CLI   ERRCODE+1,C'7'                                                   
         BE    ERR7                                                             
         CLI   ERRCODE+1,C'9'                                                   
         BE    ERR9                                                             
         CLI   ERRCODE+1,C'A'                                                   
         BE    ERRA                                                             
         MVC   ZERRCODE,ERRCODE+1                                               
         B     ISITCLSD                                                         
ERR1     EQU   *                                                                
         MVC   ZERRCODE,=C'S  SA'                                               
         B     ISITCLSD                                                         
ERR2     EQU   *                                                                
         MVC   ZERRCODE,=C'E  E?'                                               
         B     ISITCLSD                                                         
ERR45    EQU   *                                                                
         MVI   ZERRCODE,C'M'                                                    
         MVC   ZERRCODE+1(4),ERRCODE+2                                          
         B     ISITCLSD                                                         
ERR6     EQU   *                                                                
         MVI   ZERRCODE,C'O'                                                    
         MVC   ZERRCODE+1(4),ERRCODE+2                                          
         B     ISITCLSD                                                         
ERR7     EQU   *                                                                
         MVI   ZERRCODE,C'R'                                                    
         MVC   ZERRCODE+1(4),ERRCODE+2                                          
         B     ISITCLSD                                                         
ERR9     EQU   *                                                                
         MVI   ZERRCODE,C'C'                                                    
         MVC   ZERRCODE+1(4),ERRCODE+2                                          
         B     ISITCLSD                                                         
ERRA     EQU   *                                                                
         MVC   ZERRCODE,=C'S  SB'                                               
ISITCLSD EQU   *                                                                
         CLC   ZFNCTION(3),=C'CLO'                                              
         BE    CLOSED                                                           
         B     GOBACK                                                           
*                                                                               
*  THE FILE(S) IS CLOSED. MOVE HIGH VALUES TO BYTE 1 OF ACBNAME. IF             
*  THE FILE IS RE-OPENED A CHECK WILL BE MADE FOR HIGH VALUES AND               
*  THE AREA INITIALIZED AGAIN.                                                  
*                                                                               
CLOSED   EQU   *                                                                
         CLC   ZFNCTION,=C'CLOALL'                                              
         BNE   CLOLOOP                                                          
         LA    R7,PRMAREAS                                                      
CLOLOOP  EQU   *                                                                
         CLI   0(R7),X'00'                                                      
         BE    GOBACK                                                           
         MVI   ACBNAME,X'FF'                                                    
ANYMORE  EQU   *                                                                
         CLC   ZFNCTION,=C'CLOALL'                                              
         BNE   GOBACK                                                           
         LA    R7,324(R7)                                                       
         B     CLOLOOP                                                          
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** ZACCVSAM EYECATCHER *****'                               
MYSAVE   DS    18F           THIS PROGRAM'S SAVE AREA                           
DLUIOADR DS    2F            ADDRESSES OF PARAMETERS TO DLUIOMAN                
WORKFLD  DS    D             USED FOR CVD AND CVB INSTRUCTIONS                  
********C************************************************************** 00041   
*     **C*     THE FOLLOWING 5 STATEMENTS (COMMENTED OUT) ARE FROM THE  00042   
*     **C*     I.T.S. VERSION, THEY WERE REPLACED BY THE 3 STATEMENTS   00042   
*     **C*     FOLLOWING THEM TAKEN FROM THE GLH VERSION.               00042   
********C************************************************************** 00041   
*         DS    0F                                                              
*PRMAREAS DC    6480XL1'00'   FILE AREAS (20 FILES OF 324 BYTES EACH)           
*         DS    0F                                                              
*CNTAREAS DS    20F           COUNT FIELD ADDRESSES SAVED HERE                  
*         LTORG                                                                 
         LTORG                                                                  
CNTAREAS DS    50F           COUNT FIELD ADDRESSES SAVED HERE                   
PRMAREAS DC    16200XL1'00'  FILE AREAS ( 50 FILES OF 324 BYTES EACH )          
*                                                                               
*  DESCRIPTION OF PARAMETER 1 FROM APPLICATION PROGRAM.                         
*                                                                               
ZACCP1   DSECT                                                                  
ZDDNAME  DS    CL7                                                              
ZACCTYPE DS    CL5                                                              
ZRECTYPE DS    CL1                                                              
ZFNCTION DS    CL6                                                              
ZERRCODE DS    CL5                                                              
ZREAD    DS    PL4                                                              
ZWRITE   DS    PL4                                                              
ZUPDATE  DS    PL4                                                              
ZDELETE  DS    PL4                                                              
ZRECLGTH DS    H                                                                
*                                                                               
*  DESCRIPTION OF PARAMETER 2 FROM APPLICATION PROGRAM.                         
*                                                                               
ZACCP2   DSECT                                                                  
ZKEY     DS    CL1                                                              
*                                                                               
*  DESCRIPTION OF PARAMETER 3 FROM APPLICATION PROGRAM.                         
*                                                                               
ZACCP3   DSECT                                                                  
ZRECAREA DS    CL1                                                              
*                                                                               
*  DESCRIPTION OF PARAMETER 4 FROM APPLICATION PROGRAM.                         
*                                                                               
ZACCP4   DSECT                                                                  
ZPASSWRD DS    CL10                                                             
*                                                                               
*  DESCRIPTION OF EACH FILE AREA.                                               
*                                                                               
DLUIOP1  DSECT                                                                  
ZACBNAME DS    CL7                                                              
         DS    CL1                                                              
ACBNAME  DS    CL7                                                              
FUNCTION DS    CL6                                                              
ERRCODE  DS    CL6                                                              
RECLGTH  DS    PL5                                                              
READCT   DS    PL5                                                              
WRITECT  DS    PL5                                                              
UPDATECT DS    PL5                                                              
DELETECT DS    PL5                                                              
ACCTYPE  DS    CL5                                                              
PASSWORD DS    CL9                                                              
         DS    CL2                                                              
KEY      DS    CL255                                                            
         DS    CL1                                                              
         END                                                                    
