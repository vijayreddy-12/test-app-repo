DLUIOFVS START                                                                  
         PRINT NOGEN                                                            
         COPY  REGISTER                                                         
*                                                                               
*  REGISTER 3  - PARAMETER ADDRESS                                              
*  REGISTER 4  - PARAMETER ADDRESS                                              
*  REGISTER 5  - PARAMETER ADDRESS                                              
*  REGISTER 6  - ADDRESS OF THE FILE AREA                                       
*  REGISTER 7  - USED IN FREEMAIN                                               
*  REGISTER 8  - USED IN FREEMAIN                                               
*  REGISTER 9  - BAL REGISTER                                                   
*  REGISTER 10 - WORK REGISTER                                                  
*  REGISTER 11 - BASE REGISTER                                                  
*  REGISTER 12 - BASE REGISTER                                                  
*  REGISTER 13 - POINTS TO SAVE AREA                                            
*                                                                               
         SAVE  (14,12),,*                                                       
         BALR  R11,R0                                                           
         USING *,R11,R12                                                        
         LA    R12,2048(R11)                                                    
         LA    R12,2048(R12)                                                    
         ST    R13,MYSAVE+4                                                     
         LA    R13,MYSAVE                                                       
         USING DLUIOPR1,R3                                                      
         USING DLUIOREC,R4                                                      
         USING DLUIOINA,R5                                                      
         USING DLUIOFLA,R6                                                      
*                                                                               
*  FREE UP THE FILE AREA STORAGE FOR EITHER THIS FILE OR THEM ALL               
*  DEPENDING UPON THE FUNCTION CODE. ERRORS ARE NOTED BUT PROCESSING            
*  IS CONTINUED.                                                                
*                                                                               
         L     R10,THISFILE                                                     
         CLC   FUNCTION,=C'CLOALL'                                              
         BNE   SPECLCHK                                                         
         L     R10,FRSTFILE                                                     
*                                                                               
*  DO NOT FREE UP STORAGE FOR SPECIAL FILES ( CONTROL FILES, BALANCE            
*  FILES, MESSAGE FILES TO PRINTER ETC. ). IF THIS IS A SPECIAL FILE            
*  GO SEE IF THE NEXT FILE AREA IS TO BE PROCESSED.                             
*                                                                               
SPECLCHK EQU   *                                                                
         CLI   0(R10),X'00'                                                     
         BE    GOBACK                                                           
         L     R6,8(R10)                                                        
         LTR   R6,R6                                                            
         BZ    ANYMORE                                                          
         CLI   SPECLIND,SPECLFIL                                                
         BE    ANYMORE                                                          
*                                                                               
*  THIS IS NOT A SPECIAL FILE. DETERMINE IF THIS IS A SEQUENTIAL                
*  OR VSAM FILE AND THEN GO FREE UP THE APPROPRIATE STORAGE.                    
*                                                                               
         CLI   FILETYPE,VSAMFILE                                                
         BE    FREEVSM                                                          
*                                                                               
FREESEQ  EQU   *                                                                
         CLC   FUNCTION,=C'CLOALL'                                              
         BE    ANYMORE                                                          
         L     R7,LDCBAREA                                                      
         L     R8,DCBAREA                                                       
         FREEMAIN RU,LV=(7),A=(8)                                               
         LTR   R15,R15                                                          
         BZ    FREEREST                                                         
         BAL   R9,FREEERR                                                       
         B     FREEREST                                                         
*                                                                               
FREEVSM  EQU   *                                                                
         L     R7,LACBAREA                                                      
         L     R8,ACBAREA                                                       
         FREEMAIN RU,LV=(7),A=(8)                                               
         LTR   R15,R15                                                          
         BZ    FREEREST                                                         
         BAL   R9,FREEERR                                                       
*                                                                               
FREEREST EQU   *                                                                
         FREEMAIN RU,LV=512,A=(6)                                               
         LTR   R15,R15                                                          
         BZ    CLEARIT                                                          
         BAL   R9,FREEERR                                                       
*                                                                               
*  NOW ZERO THE ADDRESS IN THE SEARCH KEY AREA.                                 
*                                                                               
CLEARIT  EQU   *                                                                
         XC    8(4,R10),8(R10)                                                  
*                                                                               
*  CHECK TO SEE IF THERE ARE ANY MORE FILES TO BE DONE.                         
*                                                                               
ANYMORE  EQU   *                                                                
         CLC   FUNCTION,=C'CLOALL'                                              
         BNE   GOBACK                                                           
         LA    R10,12(R10)                                                      
         B     SPECLCHK                                                         
*                                                                               
*  RETURN TO THE CALLING PROGRAM.                                               
*                                                                               
GOBACK   EQU   *                                                                
         SR    R15,R15                                                          
         L     R13,MYSAVE+4                                                     
         RETURN (14,12),T,RC=(15)                                               
*                                                                               
*  ERROR ENCOUNTERED WHILE FREEING UP STORAGE.                                  
*                                                                               
FREEERR  EQU   *                                                                
         MVC   ERRCODE(2),=C'EA'                                                
         STC   R15,HEXERR                                                       
         MVI   HEXERR+1,X'00'                                                   
         CALL  DLUIOXPF                                                         
         BR    R9                                                               
*                                                                               
*  WORKING STORAGE.                                                             
*                                                                               
         DC    C'***** DLUIOFVS EYECATCHER *****'                               
MYSAVE   DS    18F          THIS PROGRAM'S SAVE AREA                            
*                                                                               
         LTORG                                                                  
         COPY  DLUIOPR1                                                         
         COPY  DLUIOREC                                                         
         COPY  DLUIOINA                                                         
         COPY  DLUIOFLA                                                         
         END                                                                    
