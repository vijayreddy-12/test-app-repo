//*     TYPRUN=SCAN,                                                            
//PGC1200  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A,LINES=99                                                       
//*LOGONID PGC                                                                  
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//*GBPROC JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*      TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                      
//*      TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                    
//*      PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                      
//*GBSET  INCLUDE MEMBER=J2SETD                                                 
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//GBLOAD INCLUDE MEMBER=J2FULL                                                  
//**********************************************************************        
//*  JOB DESCRIPTION - PGC1200                                         *        
//*  ---------------                                                   *        
//*  COMMISSION RECONCILIATION                                         *        
//**********************************************************************        
//**********************************************************************        
//*JCLPREP KEEP MODEL                                                           
//**********************************************************************        
//*--------------------------------------------------------------*              
//* HISTORY                                                                     
//* 01OCT08  ECU PROJECT  UPGRADED IN ENTERPRISE COMPILER PROJECT               
//*--------------------------------------------------------------*              
//*                                                                             
//PROC00  EXEC GC1200                 ** DOCUMENTATION ONLY                     
//*                                                                             
//PROC02  EXEC GC1210                                                           
//*                                                                             
//PROC03  EXEC GC1220                                                           
//*                                                                             
//PROC04  EXEC GC1230                                                           
//*                                                                             
//PROC05  EXEC GC1240                                                           
