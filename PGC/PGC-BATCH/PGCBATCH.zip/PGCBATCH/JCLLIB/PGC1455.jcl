//PGC1455  JOB (PP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A,LINES=9999,COPIES=1                                            
//*LOGONID PGC                                                                  
//GJPROCS JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                       
//*JPROCS JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*       TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                     
//*       TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                   
//*       PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                     
//*                                      SYSTEM:  CGLH FINANCIAL SYSTEM         
//*                                   FREQUENCY:  DAILY                         
//*                               PREREQUISITES:  NONE                          
//*                                    RESTARTS:  BY UCC7/11                    
//*                                                                             
//PROC01  EXEC GC1455,                                                          
//             COND=(0,NE)                                                      
//                                                                              
