//PGC1300  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A,LINES=99                                                       
//*LOGONID PGC                                                                  
//*     TYPRUN=SCAN,                                                            
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//*GBPROC JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*      TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                      
//*      TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                    
//*      PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                      
//*GBSET  INCLUDE MEMBER=J2SETD                                                 
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//GBLOAD INCLUDE MEMBER=J2DB2                                                   
//**********************************************************************        
//*  JOB DESCRIPTION - PGC1300                                         *        
//*  ---------------                                                   *        
//*  ADVANCE RENEWAL COMMISSIONS                                       *        
//**********************************************************************        
//**********************************************************************        
//*JCLPREP KEEP MODEL                                                           
//**********************************************************************        
//*--------------------------------------------------------------*              
//* HISTORY                                                                     
//* 01OCT08  ECU PROJECT  UPGRADED IN ENTERPRISE COMPILER PROJECT               
//*--------------------------------------------------------------*              
//*                                                                             
//PROC00  EXEC GC1300                 ** DOCUMENTATION ONLY                     
//*                                                                             
//PROC02  EXEC GC1310                                                           
