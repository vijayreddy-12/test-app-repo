//PGC1600  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A,L=999999                                                       
//*LOGONID PGC                                                                  
//GCPROCS JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                       
//*CPROCS JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*       TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                     
//*       TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                   
//*       PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                     
//*BSET  INCLUDE MEMBER=J2SETD                                                  
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//GBLOAD INCLUDE MEMBER=J2DB2                                                   
//**********************************************************************        
//*  JOB DESCRIPTION - PGC1600                                         *        
//*  ---------------                                                   *        
//*  CREATES A COMMISSION ACCOUNTING EXTRACT                           *        
//**********************************************************************        
//*                                                                             
//PROC01  EXEC GC1600                                                           
