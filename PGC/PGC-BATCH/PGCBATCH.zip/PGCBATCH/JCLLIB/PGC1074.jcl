//PGC1074  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A                                                                
//*LOGONID PGC                                                                  
//GCPROCS JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                       
//*********************************************************************         
//* JOB DESCRIPTION:                                                            
//*   CREATE AN EMPTY VERSION OF VOPSMEXT WITH JUST THE CURRENT SEQ #           
//*********************************************************************         
//*                                                                             
//GC107400 EXEC PGM=IEBGENER,                                                   
//             COND=(0,LT)                                                      
//SYSUT1    DD DSN=PGW.COMM.PROD.VOPSMNUM(0),                                   
//             DISP=SHR                                                         
//SYSUT2    DD DSN=PGW.COMM.PROD.VOPSMEXT,                                      
//             DISP=(NEW,CATLG,DELETE),                                         
//             UNIT=PROD,                                                       
//             SPACE=(TRK,(1,5),RLSE),                                          
//             DCB=(RECFM=FB,LRECL=66,BLKSIZE=29238)                            
//SYSIN     DD DUMMY                                                            
//SYSPRINT  DD DCB=RECFM=FBA,                                                   
//             SYSOUT=*                                                         
//*                                                                     **      
//* DELETE THE TRIGGER FILE PGW.COMM.PROD.VOPSMTRG.FTP (IF IT EXISTS)   **      
//* AS CAWLA DST (PRED FOR PGC1070) IS SET TO TRIGGER UPON DATA SET     **      
//* CREATION ONLY.                                                      **      
//*                                                                             
//GC107405 EXEC PGM=IDCAMS,COND=(0,LT)                                          
//SYSPRINT  DD SYSOUT=*                                                         
//SYSIN     DD *                                                                
 DELETE PGW.COMM.PROD.VOPSMTRG.FTP NONVSAM                                      
    SET LASTCC= 0                                                               
    SET MAXCC= 0                                                                
