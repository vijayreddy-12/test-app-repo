//PGC1063  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A                                                                
//*LOGONID PGC                                                                  
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//*GBPROC JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*      TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                      
//*      TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                    
//*      PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                      
//*GBSET  INCLUDE MEMBER=J2SETD                                                 
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//GBLOAD INCLUDE MEMBER=J2DB2                                                   
//**********************************************************                    
//*    JOB DESCRIPTION:  VO COMMISSIONS FEED CONTROL JOB                        
//*   THIS JOB IS CONDITIONED (THRU CTL-M) TO RUN                               
//*   ON COMPLETION OF JOB PGC1062.                                             
//**********************************************************                    
//*--------------------------------------------------------------*              
//* HISTORY                                                                     
//* 01OCT08  ECU PROJECT  UPGRADED IN ENTERPRISE COMPILER PROJECT               
//* 20JUN25  ADDED GC1063P                                                      
//*--------------------------------------------------------------*              
//*                                                                             
//PROC01  EXEC GC1063                                                           
//*                                                                             
//PROC02  EXEC GC1063P,COND=EVEN                                                
