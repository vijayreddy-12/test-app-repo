//PGC1065  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A                                                                
//*LOGONID PGC                                                                  
//GBPROC  JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                       
//**********************************************************                    
//*   JOB DESCRIPTION:                                                          
//*   CREATE AN EMPTY VERSION OF VODACOM                                        
//*   CREATE AN EMPTY VERSION OF VODACRF                                        
//**********************************************************                    
//*                                                                             
//PROC01  EXEC GC1065                                                           
