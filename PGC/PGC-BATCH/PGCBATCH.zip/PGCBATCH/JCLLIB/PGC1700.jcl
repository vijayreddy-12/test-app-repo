//*     TYPRUN=SCAN,                                                            
//PGC1700  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A,LINES=99                                                       
//*LOGONID PGC                                                                  
//*JCLPREP KEEP MODEL                                                           
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//*GBPROC JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*      TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                      
//*      TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                    
//*      PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                      
//*GBSET  INCLUDE MEMBER=J2SETD                                                 
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//GBLOAD INCLUDE MEMBER=J2DB2                                                   
//*************************************************************                 
//*  JOB DESCRIPTION - PGC1700                                *                 
//*  ---------------                                          *                 
//*  CREATES A COMMISSION SUPPLEMENTAL DATALOADER EXTRACT     *                 
//*************************************************************                 
//*--------------------------------------------------------------*              
//* HISTORY                                                                     
//* 24OCT08  ECU PROJECT  UPGRADED IN ENTERPRISE COMPILER PROJECT               
//*--------------------------------------------------------------*              
//*                                                                             
//PROC01  EXEC GC1700                                                           
