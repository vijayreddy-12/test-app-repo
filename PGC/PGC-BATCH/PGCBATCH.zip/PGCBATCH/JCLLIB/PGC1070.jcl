//PGC1070  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A                                                                
//*LOGONID PGC                                                                  
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//*GBPROC JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*      TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                      
//*      TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                    
//*      PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                      
//*GBSET  INCLUDE MEMBER=J2SETD                                                 
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//**********************************************************                    
//*    JOB DESCRIPTION:  FILEWATCH JOB                                          
//*    THIS JOB IS CONDITIONED (THRU CTL-M) TO RUN                              
//*    WHEN THE TRIGGER FILE VOPSMTRG ARRIVES.                                  
//*    THIS JOB DELETES THE TRIGGER FILE VOPSMTRG                               
//*    WHEN THE MAINFRAME HAS RECEIVED THE DATA FILES                           
//*    THAT COME WITH THIS TRIGGER FILE.                                        
//**********************************************************                    
//*--------------------------------------------------------------*              
//* HISTORY                                                                     
//* 01OCT08  ECU PROJECT  UPGRADED IN ENTERPRISE COMPILER PROJECT               
//*--------------------------------------------------------------*              
//*                                                                             
//PROC01  EXEC GC1070                                                           
