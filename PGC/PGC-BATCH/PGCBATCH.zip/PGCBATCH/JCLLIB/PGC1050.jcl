//PGC1050  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A,LINES=99                                                       
//*LOGONID PGC                                                                  
//*GCPROCS JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                      
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//**********************************************************************        
//*  JOB DESCRIPTION - PGC1050                                         *        
//*  ---------------                                                   *        
//*  1. TAKES PSR.PRODUCER.PROFILE.EXT DATASET (IF IT'S NOT EMPTY) AND *        
//*  CREATES THE VSAM FILE PGW.ADMN.PROD.PRODUCER.PROFILE.VSAM         *        
//*  2. - CHANGE FOR AGENCY RETIREMENT                                          
//*     TAKES PAG.VSAM.MDE -UNLOAD TO FLAT FILE,                                
//*   SORTS THE RECORDS, CREATES VSAM FILE PGW.ADMN.PROD.AGTADDR.VSAM*          
//**********************************************************************        
//*--------------------------------------------------------------*              
//* HISTORY                                                                     
//* 01OCT08  ECU PROJECT  UPGRADED IN ENTERPRISE COMPILER PROJECT               
//* 01DEC08  - USE FASAT VSAM FILE TO BUILD AGTADDR                             
//*--------------------------------------------------------------*              
//*                                                                             
//PROC01  EXEC GC1050                                                           
