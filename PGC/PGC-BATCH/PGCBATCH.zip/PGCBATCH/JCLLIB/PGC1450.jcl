//*     TYPRUN=SCAN,                                                            
//PGC1450  JOB (GP-GC91),GC,CLASS=P,MSGCLASS=A                                  
//*JCLPREP KEEP ROOM                                                            
/*JOBPARM R=GBXA,LINES=99                                                       
//*LOGONID PGC                                                                  
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//*GBPROC JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*      TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                      
//*      TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                    
//*      PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                      
//*GBSET  INCLUDE MEMBER=J2SETD                                                 
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//GBLOAD INCLUDE MEMBER=J2DB2                                                   
//*JCLPREP KEEP MODEL                                                           
//**********************************************************************        
//*  JOB DESCRIPTION - PGC1450                                         *        
//*  ---------------                                                   *        
//*  GPRINTAL - PRODUCES NAP AND COMM REPORTS.                         *        
//**********************************************************************        
//*--------------------------------------------------------------*              
//* HISTORY                                                                     
//* 01OCT08  ECU PROJECT  UPGRADED IN ENTERPRISE COMPILER PROJECT               
//*--------------------------------------------------------------*              
//*                                                                             
//PROC01  EXEC GC1450                                                           
//* #SCC,COND=(16,LT,GC145017)                                                  
//* #SCC,COND=(0,NE,*-GC145017)                                                 
