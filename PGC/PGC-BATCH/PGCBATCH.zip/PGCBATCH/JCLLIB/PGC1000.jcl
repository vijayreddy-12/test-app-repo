//PGC1000  JOB (GP-YA91),GC,CLASS=P,MSGCLASS=A                                  
/*JOBPARM R=M04A                                                                
//*LOGONID PGC                                                                  
//*------------------------------------------------------------------*          
//* DBA DB2 UTILITY JOB TO COPY ALL TS IN DGC01P                                
//* JOB HISTORY:                                                                
//* MAY 08, 2011 - ORIG JOB CREATION (BRIAN & BOB)                              
//* 28JUL2015         CREATE VTAPE INSTEAD OF XTAPE                             
//* (ELMER DELGADO)   CHANGED COPYDDN(PGCRM) TO COPYDDN(PGCLM)                  
//*------------------------------------------------------------------*          
//*                                                                             
//DISDB   EXEC PGM=IKJEFT01,                                                    
//             COND=(5,LT)                                                      
//STEPLIB   DD DSN=PCX.DB2.DSNLOAD,                                             
//             DISP=SHR                                                         
//SYSTSPRT  DD SYSOUT=*                                                         
//SYSPRINT  DD SYSOUT=*                                                         
//SYSTSIN   DD *                                                                
DSN SYSTEM(PDBC)                                                                
-DIS THREAD(*)                                                                  
-DIS UTIL(*)                                                                    
 -DISPLAY DATABASE(DGC01P) SPACENAM(*) RESTRICT LIMIT(*)                        
 -DISPLAY DATABASE(DGC01P) SPACENAM(*) CLAIMERS ACTIVE LIMIT(*)                 
 -DISPLAY DATABASE(DGC01P) SPACENAM(*) LOCKS ACTIVE LIMIT(*)                    
//*********************************************************************         
//*                                                                             
//COPYMOST EXEC DSNUPROC,                                                       
//             COND=(5,LT),                                                     
//             SYSTEM=PDBC                                                      
//TEMPLDEF  DD DSN=PEN.GLHNEW.PROD.STANDARD.CTLCARDS(DB2TMPGC),                 
//             DISP=SHR                                                         
//SYSIN     DD *                                                                
  OPTIONS TEMPLATEDD TEMPLDEF                                                   
                                                                                
  LISTDEF LIST_TS        INCLUDE TABLESPACES DATABASE DGC01P                    
  LISTDEF LIST_IDX INCLUDE LIST LIST_TS INDEXSPACES COPY YES                    
                                                                                
  LISTDEF LIST_ALL       INCLUDE LIST LIST_TS                                   
                         INCLUDE LIST LIST_IDX                                  
                                                                                
  COPY LIST LIST_ALL FULL YES SHRLEVEL REFERENCE                                
           PARALLEL(2) TAPEUNITS(2)                                             
           COPYDDN(PGCLM)                                                       
                                                                                
  QUIESCE LIST LIST_TS                                                          
