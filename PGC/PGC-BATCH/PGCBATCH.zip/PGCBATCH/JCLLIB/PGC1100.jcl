//PGC1100  JOB (GP-GC91),GC,CLASS=P,TIME=1440,                                  
//*        TYPRUN=SCAN,                                                         
//             MSGCLASS=A                                                       
/*JOBPARM R=M04A,L=100                                                          
//*LOGONID PGC                                                                  
//GBPROC JCLLIB ORDER=(PEN.GLHNEW.PROD.STANDARD.PROCLIB)                        
//*GBPROC JCLLIB ORDER=(TEN.GLHNEW.DEV.STANDARD.PROCLIB,                        
//*      TEN.GLHNEW.TEST.STANDARD.PROCLIB,                                      
//*      TEN.GLHNEW.ACCEPT.STANDARD.PROCLIB,                                    
//*      PEN.GLHNEW.PROD.STANDARD.PROCLIB)                                      
//*GBSET  INCLUDE MEMBER=J2SETD                                                 
//GBSET  INCLUDE MEMBER=J2SETP                                                  
//GBLOAD INCLUDE MEMBER=J2DB2                                                   
//**********************************************************************        
//*  JOB DESCRIPTION - PGC1100                                         *        
//*  ---------------                                                   *        
//*  UPDATES THE COMMISSION DATA BASE WITH EXTRACTS FROM THE GIPSY RUN *        
//**********************************************************************        
//*                                                                             
//PROC00  EXEC GC1100                 ** DOCUMENTATION ONLY                     
//*                                                                             
//PROC01  EXEC GC1110                                                           
